<?php
namespace EduCore\Workspace;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Privacy;
use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/**
 * Bulk people import (CSV) for EduCore Management: upload → validate → preview → confirm. Each row is created
 * through People::create (same role rules, guardian consent for minors, invitation e-mail), so the import can never
 * do more than the single "Add a person" form. The validated plan lives for one hour, bound to the uploader.
 */
final class PeopleImport {
	public const MAX_ROWS  = 500;
	public const MAX_BYTES = 2 * MB_IN_BYTES;
	public const COLUMNS   = array( 'email', 'first_name', 'last_name', 'roles', 'age_band', 'guardian_email', 'course_ids' );

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
		add_action( 'template_redirect', array( self::class, 'maybe_template' ), 5 );
	}

	private static function key( int $uid, string $token ): string {
		return 'ec_ws_pimp_' . $uid . '_' . preg_replace( '/[^a-f0-9]/', '', $token );
	}

	/** Role slugs accepted in the file: student, teacher… or ec_student, ec_teacher… */
	private static function role_slug( string $r ): string {
		$r = sanitize_key( $r );
		return '' === $r ? '' : ( 0 === strpos( $r, 'ec_' ) ? $r : 'ec_' . str_replace( array( 'academic-manager', 'manager' ), 'academic_manager', $r ) );
	}

	/**
	 * Parse and validate a CSV string. Nothing is written.
	 *
	 * @return array{rows:array,errors:int,valid:int}|\WP_Error
	 */
	public static function validate( int $actor, string $csv ) {
		if ( ! People::can_manage( $actor ) ) {
			return new \WP_Error( 'ec_pimp_forbidden', __( 'You cannot add people.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$csv  = preg_replace( '/^\xEF\xBB\xBF/', '', $csv );
		$fh   = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $fh, (string) $csv ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		rewind( $fh );
		$head = fgetcsv( $fh, 0, ',', '"', '' );
		if ( ! $head ) {
			return new \WP_Error( 'ec_pimp_empty', __( 'The file is empty.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		$head = array_map( static fn( $h ) => sanitize_key( str_replace( ' ', '_', strtolower( trim( (string) $h ) ) ) ), $head );
		if ( ! in_array( 'email', $head, true ) || ! in_array( 'roles', $head, true ) ) {
			return new \WP_Error( 'ec_pimp_head', __( 'The first line must contain at least the columns email and roles.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		$assignable = People::assignable( $actor );
		$seen       = array();
		$rows       = array();
		$line       = 1;
		while ( false !== ( $cells = fgetcsv( $fh, 0, ',', '"', '' ) ) ) {
			++$line;
			if ( array( null ) === $cells || '' === trim( implode( '', array_map( 'strval', $cells ) ) ) ) {
				continue;
			}
			if ( count( $rows ) >= self::MAX_ROWS ) {
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				/* translators: %d: maximum rows */
				return new \WP_Error( 'ec_pimp_big', sprintf( __( 'Import at most %d people per file.', 'educore-workspace' ), self::MAX_ROWS ), array( 'status' => 413 ) );
			}
			$r      = array_combine( $head, array_pad( array_slice( array_map( static fn( $c ) => trim( (string) $c ), $cells ), 0, count( $head ) ), count( $head ), '' ) );
			$errors = array();
			$warn   = array();
			$email  = sanitize_email( (string) ( $r['email'] ?? '' ) );
			if ( ! is_email( $email ) ) {
				$errors[] = __( 'Invalid e-mail address.', 'educore-workspace' );
			} elseif ( email_exists( $email ) ) {
				$errors[] = __( 'An account with this e-mail address already exists.', 'educore-workspace' );
			} elseif ( isset( $seen[ strtolower( $email ) ] ) ) {
				/* translators: %d: line number */
				$errors[] = sprintf( __( 'Same e-mail address as line %d.', 'educore-workspace' ), $seen[ strtolower( $email ) ] );
			}
			$seen[ strtolower( $email ) ] = $line;
			$roles                        = array_values( array_filter( array_map( array( self::class, 'role_slug' ), preg_split( '/[|;]/', (string) ( $r['roles'] ?? '' ) ) ) ) );
			if ( ! $roles ) {
				$errors[] = __( 'At least one role is required.', 'educore-workspace' );
			}
			foreach ( $roles as $role ) {
				if ( ! in_array( $role, $assignable, true ) ) {
					/* translators: %s: role */
					$errors[] = sprintf( __( 'Role not allowed: %s.', 'educore-workspace' ), $role );
				}
			}
			$band = (string) ( $r['age_band'] ?? '' );
			if ( '' !== $band && ! in_array( $band, Privacy::AGE_BANDS, true ) ) {
				/* translators: %s: allowed values */
				$errors[] = sprintf( __( 'Age band must be one of: %s.', 'educore-workspace' ), implode( ', ', Privacy::AGE_BANDS ) );
			}
			$minor = in_array( 'ec_student', $roles, true ) && in_array( $band, array( 'under15', '15to17' ), true );
			$g     = sanitize_email( (string) ( $r['guardian_email'] ?? '' ) );
			if ( $minor && ! is_email( $g ) ) {
				$warn[] = __( 'Minor without a guardian e-mail: the account will wait for consent until a guardian is added.', 'educore-workspace' );
			}
			$courses = array();
			foreach ( array_filter( preg_split( '/[|;\s]+/', (string) ( $r['course_ids'] ?? '' ) ) ) as $c ) {
				$cid = absint( $c );
				if ( ! $cid || ! Content::is_course( $cid ) ) {
					/* translators: %s: course id */
					$errors[] = sprintf( __( 'Unknown course: %s.', 'educore-workspace' ), $c );
				} elseif ( ! user_can( $actor, 'ec_manage_course_enrollments', $cid ) ) {
					/* translators: %d: course id */
					$errors[] = sprintf( __( 'You cannot enroll people in course %d.', 'educore-workspace' ), $cid );
				} else {
					$courses[] = $cid;
				}
			}
			$rows[] = array(
				'line'    => $line,
				'email'   => $email,
				'first'   => sanitize_text_field( (string) ( $r['first_name'] ?? '' ) ),
				'last'    => sanitize_text_field( (string) ( $r['last_name'] ?? '' ) ),
				'roles'   => $roles,
				'band'    => $band,
				'guardian'=> is_email( $g ) ? $g : '',
				'courses' => $courses,
				'errors'  => $errors,
				'warn'    => $warn,
			);
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $rows ) {
			return new \WP_Error( 'ec_pimp_empty', __( 'The file has no people in it.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		$bad = count( array_filter( $rows, static fn( $x ) => $x['errors'] ) );
		return array( 'rows' => $rows, 'errors' => $bad, 'valid' => count( $rows ) - $bad );
	}

	/** Store a validated plan for this uploader. */
	public static function stage( int $actor, array $plan ): string {
		$token = bin2hex( random_bytes( 12 ) );
		set_transient( self::key( $actor, $token ), $plan, HOUR_IN_SECONDS );
		return $token;
	}

	public static function plan( int $actor, string $token ): ?array {
		$p = get_transient( self::key( $actor, $token ) );
		return is_array( $p ) ? $p : null;
	}

	/** Create every valid row. @return array{created:int,failed:array}|\WP_Error */
	public static function commit( int $actor, string $token, bool $invite ) {
		$plan = self::plan( $actor, $token );
		if ( ! $plan || ! People::can_manage( $actor ) ) {
			return new \WP_Error( 'ec_pimp_expired', __( 'This import has expired or does not belong to you. Upload the file again.', 'educore-workspace' ), array( 'status' => 404 ) );
		}
		delete_transient( self::key( $actor, $token ) ); // Single use, before any write.
		$created = 0;
		$failed  = array();
		foreach ( $plan['rows'] as $r ) {
			if ( $r['errors'] ) {
				continue;
			}
			$id = People::create( $actor, array( 'email' => $r['email'], 'first' => $r['first'], 'last' => $r['last'], 'roles' => $r['roles'], 'age_band' => $r['band'], 'guardian_email' => $r['guardian'], 'invite' => $invite ) );
			if ( is_wp_error( $id ) ) {
				$failed[] = array( $r['line'], $id->get_error_message() );
				continue;
			}
			++$created;
			foreach ( $r['courses'] as $cid ) {
				$e = People::enroll( $actor, $cid, (int) $id );
				if ( is_wp_error( $e ) ) {
					$failed[] = array( $r['line'], $e->get_error_message() );
				}
			}
		}
		Audit::log( 'people.bulk_imported', 'user', 0, array( 'created' => $created, 'failed' => count( $failed ), 'invite' => $invite ) );
		return array( 'created' => $created, 'failed' => $failed );
	}

	/* ---------- REST ---------- */

	public static function routes(): void {
		$perm = static fn() => People::can_manage( get_current_user_id() );
		register_rest_route( 'educore/v1', '/manage/people/import', array( 'methods' => 'POST', 'callback' => array( self::class, 'rest_upload' ), 'permission_callback' => $perm ) );
		register_rest_route( 'educore/v1', '/manage/people/import/(?P<token>[a-f0-9]{24})', array( 'methods' => 'POST', 'callback' => array( self::class, 'rest_commit' ), 'permission_callback' => $perm, 'args' => array( 'invite' => array( 'default' => '1' ) ) ) );
	}

	public static function rest_upload( \WP_REST_Request $q ) {
		if ( ! RateLimiter::hit( 'rest_write' ) ) {
			return new \WP_Error( 'ec_ws_rate', __( 'Too many changes in a short time. Please wait a moment.', 'educore-workspace' ), array( 'status' => 429 ) );
		}
		$f = $q->get_file_params()['file'] ?? null;
		if ( ! is_array( $f ) || ! empty( $f['error'] ) || ! is_uploaded_file( (string) $f['tmp_name'] ) ) {
			return new \WP_Error( 'ec_pimp_upload', __( 'Choose a CSV file to import.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'file' => 'required' ) ) );
		}
		if ( (int) $f['size'] > self::MAX_BYTES || 'csv' !== strtolower( pathinfo( (string) $f['name'], PATHINFO_EXTENSION ) ) ) {
			return new \WP_Error( 'ec_pimp_upload', __( 'Upload a .csv file of at most 2 MB.', 'educore-workspace' ), array( 'status' => 415 ) );
		}
		$plan = self::validate( get_current_user_id(), (string) file_get_contents( (string) $f['tmp_name'] ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( is_wp_error( $plan ) ) {
			return $plan;
		}
		$token = self::stage( get_current_user_id(), $plan );
		return new \WP_REST_Response( array( 'ok' => true, 'url' => Pages::url( 'manage', array( 'v' => 'people-import', 'token' => $token ) ) ), 201 );
	}

	public static function rest_commit( \WP_REST_Request $q ) {
		$r = self::commit( get_current_user_id(), (string) $q['token'], ! in_array( (string) $q['invite'], array( '0', 'false', '' ), true ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new \WP_REST_Response( array( 'ok' => true, 'created' => $r['created'], 'failed' => $r['failed'], 'url' => Pages::url( 'manage', array( 'v' => 'people', 'ec_msg' => 'imported', 'n' => $r['created'] ) ) ) );
	}

	/* ---------- template download ---------- */

	public static function template_url(): string {
		return add_query_arg( array( 'ec_people_template' => 1 ), Pages::url( 'manage' ) );
	}

	public static function maybe_template(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- static example file, capability-checked.
		if ( empty( $_GET['ec_people_template'] ) ) {
			return;
		}
		if ( ! People::can_manage( get_current_user_id() ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to download this file.', 'educore-workspace' ), '', array( 'response' => 403 ) );
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="educore-people-template.csv"' );
		header( 'X-Content-Type-Options: nosniff' );
		echo "\xEF\xBB\xBF" . implode( ',', self::COLUMNS ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- static CSV.
		echo "learner@example.org,Mona,Hassan,student,15to17,parent@example.org,\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		echo "teacher@example.org,Karim,Adel,teacher|instructor,,,\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/* ---------- views ---------- */

	public static function view( int $uid ): string {
		Shell::title( __( 'Import people', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), Pages::url( 'manage' ) ), array( __( 'People', 'educore-workspace' ), Pages::url( 'manage', array( 'v' => 'people' ) ) ), array( __( 'Import people', 'educore-workspace' ) ) ) );
		if ( ! People::can_manage( $uid ) ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'You do not have access to this section.', 'educore-workspace' ) . '</div>';
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view parameter.
		$token = isset( $_GET['token'] ) ? sanitize_key( wp_unslash( $_GET['token'] ) ) : '';
		if ( '' === $token ) {
			$o  = '<form class="ec-card ec-ws-form ec-studio-narrow" data-ec-upload="manage/people/import" novalidate><p>' . esc_html__( 'Add many people at once from a CSV file. The file is checked first and nothing is created until you confirm.', 'educore-workspace' ) . '</p>';
			$o .= '<label class="ec-ws-field" for="ec-f-file"><span class="ec-ws-label">' . esc_html__( 'CSV file', 'educore-workspace' ) . ' <abbr title="' . esc_attr__( 'required', 'educore-workspace' ) . '">*</abbr></span><input id="ec-f-file" type="file" name="file" accept=".csv,text/csv" required aria-required="true"><span class="ec-muted">' . esc_html( sprintf( /* translators: 1: column list, 2: max rows */ __( 'Columns: %1$s. Roles separated by |. Up to %2$d people, 2 MB.', 'educore-workspace' ), implode( ', ', self::COLUMNS ), self::MAX_ROWS ) ) . '</span></label>';
			$o .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Check the file', 'educore-workspace' ) . '</button> <a class="ec-btn" href="' . esc_url( self::template_url() ) . '">' . esc_html__( 'Download the template', 'educore-workspace' ) . '</a></div></form>';
			return $o;
		}
		$plan = self::plan( $uid, $token );
		if ( ! $plan ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'This import has expired or does not belong to you. Upload the file again.', 'educore-workspace' ) . '</div><p><a class="ec-btn" href="' . esc_url( Pages::url( 'manage', array( 'v' => 'people-import' ) ) ) . '">' . esc_html__( 'Import people', 'educore-workspace' ) . '</a></p>';
		}
		$labels = People::role_labels();
		/* translators: 1: valid rows, 2: rows with errors */
		$o  = '<section class="ec-card ec-ws-section"><h2>' . esc_html( sprintf( __( '%1$d ready to create · %2$d with errors', 'educore-workspace' ), $plan['valid'], $plan['errors'] ) ) . '</h2><p class="ec-muted">' . esc_html__( 'Rows with errors are skipped. Fix them in the file and import it again later.', 'educore-workspace' ) . '</p>';
		if ( $plan['valid'] ) {
			/* translators: %d: number of people */
			$o .= '<form class="ec-ws-inline" data-ec-api="manage/people/import/' . esc_attr( $token ) . '" data-ec-method="POST"><label class="ec-ws-check"><input type="hidden" name="invite" value="0"><input type="checkbox" name="invite" value="1" checked> ' . esc_html__( 'Send each person an invitation to set their password', 'educore-workspace' ) . '</label> <button class="ec-btn ec-btn--primary" type="submit">' . esc_html( sprintf( _n( 'Create %d person', 'Create %d people', $plan['valid'], 'educore-workspace' ), $plan['valid'] ) ) . '</button></form>';
		}
		$o .= '</section><div class="ec-ws-table-wrap"><table class="ec-ws-table"><caption class="screen-reader-text">' . esc_html__( 'People in the file', 'educore-workspace' ) . '</caption><thead><tr><th scope="col">' . esc_html__( 'Line', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Person', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Roles', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Courses', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Result', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $plan['rows'] as $r ) {
			$res = $r['errors'] ? '<span class="ec-msg-error">✗ ' . esc_html( implode( ' ', $r['errors'] ) ) . '</span>' : '<span class="ec-chip ec-chip--publish">' . esc_html__( 'Ready', 'educore-workspace' ) . '</span>' . ( $r['warn'] ? '<br><span class="ec-msg-warn">⚠ ' . esc_html( implode( ' ', $r['warn'] ) ) . '</span>' : '' );
			$o  .= '<tr' . ( $r['errors'] ? ' class="is-invalid"' : '' ) . '><td>' . (int) $r['line'] . '</td><td>' . esc_html( trim( $r['first'] . ' ' . $r['last'] ) ) . '<br><span class="ec-muted">' . esc_html( $r['email'] ) . '</span></td><td>' . esc_html( implode( ', ', array_map( static fn( $x ) => $labels[ $x ] ?? $x, $r['roles'] ) ) ) . '</td><td>' . esc_html( implode( ', ', array_map( static fn( $c ) => get_the_title( $c ), $r['courses'] ) ) ) . '</td><td>' . $res . '</td></tr>';
		}
		return $o . '</tbody></table></div>';
	}
}
