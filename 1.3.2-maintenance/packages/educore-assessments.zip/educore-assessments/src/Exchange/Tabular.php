<?php
namespace EduCore\Assessments\Exchange;

use EduCore\Assessments\Types;

defined( 'ABSPATH' ) || exit;

/** CSV and XLSX share one column layout (header-based, order-independent). */
final class Tabular {
	public const COLUMNS = array( 'external_id', 'type', 'lesson_id', 'difficulty', 'points', 'usage', 'lang', 'tags', 'status', 'stem', 'options', 'correct', 'explanation', 'model_answer', 'min_words', 'code', 'language', 'image_id', 'scoring' );
	private const FORMULA = "=+-@\t\r";

	/** @return array{record:?array,error:?string} */
	public static function row_to_record( array $row ): array {
		$row = array_change_key_case( array_map( static fn( $v ) => is_string( $v ) ? self::unguard( $v ) : $v, $row ) );
		if ( ! array_filter( $row, static fn( $v ) => '' !== trim( (string) $v ) ) ) {
			return array( 'record' => null, 'error' => null ); // Blank line.
		}
		$built = Types::from_authoring( $row );
		if ( is_wp_error( $built ) ) {
			return array( 'record' => array( 'type' => (string) ( $row['type'] ?? '' ), 'stem' => (string) ( $row['stem'] ?? '' ) ), 'error' => $built->get_error_message() );
		}
		return array(
			'record' => array(
				'external_id' => (string) ( $row['external_id'] ?? '' ),
				'type'        => (string) $row['type'],
				'stem'        => (string) ( $row['stem'] ?? '' ),
				'payload'     => $built['payload'],
				'key'         => $built['key'],
				'explanation' => (string) ( $row['explanation'] ?? '' ),
				'points'      => $row['points'] ?? '',
				'difficulty'  => '' !== (string) ( $row['difficulty'] ?? '' ) ? (string) $row['difficulty'] : 'medium',
				'usage'       => '' !== (string) ( $row['usage'] ?? '' ) ? (string) $row['usage'] : 'any',
				'lang'        => (string) ( $row['lang'] ?? '' ),
				'tags'        => (string) ( $row['tags'] ?? '' ),
				'status'      => '' !== (string) ( $row['status'] ?? '' ) ? (string) $row['status'] : 'draft',
				'lesson_id'   => absint( $row['lesson_id'] ?? 0 ),
			),
			'error'  => null,
		);
	}

	public static function record_to_row( array $r ): array {
		$a = Types::to_authoring( $r['type'], $r['payload'], $r['key'] );
		$v = array(
			'external_id'  => $r['external_id'],
			'type'         => $r['type'],
			'lesson_id'    => $r['lesson_id'] ?: '',
			'difficulty'   => $r['difficulty'],
			'points'       => $r['points'],
			'usage'        => $r['usage'],
			'lang'         => $r['lang'],
			'tags'         => implode( ',', $r['tags'] ),
			'status'       => $r['status'],
			'stem'         => $r['stem'],
			'options'      => $a['options'],
			'correct'      => $a['correct'],
			'explanation'  => $r['explanation'],
			'model_answer' => $a['model_answer'],
			'min_words'    => 'essay' === $r['type'] ? (int) ( $r['payload']['min_words'] ?? 0 ) : '',
			'code'         => $a['code'],
			'language'     => $a['language'],
			'image_id'     => $a['image_id'],
			'scoring'      => $a['scoring'],
		);
		return array_map( static fn( $c ) => $v[ $c ], self::COLUMNS );
	}

	/** Spreadsheet-formula guard for CSV: a leading apostrophe, removed again on import. */
	public static function guard( $v ): string {
		$v = (string) $v;
		return ( '' !== $v && false !== strpos( self::FORMULA, $v[0] ) ) ? "'" . $v : $v;
	}

	public static function unguard( string $v ): string {
		return ( strlen( $v ) > 1 && "'" === $v[0] && false !== strpos( self::FORMULA, $v[1] ) ) ? substr( $v, 1 ) : $v;
	}

	/* ---------------- CSV ---------------- */

	/** @return array<int,array<string,string>>|\WP_Error line number => row */
	public static function read_csv( string $raw ) {
		$raw = (string) preg_replace( '/^\xEF\xBB\xBF/', '', $raw );
		if ( ! mb_check_encoding( $raw, 'UTF-8' ) ) {
			return new \WP_Error( 'ec_x_encoding', __( 'The CSV file is not UTF-8. In Excel use “Save as → CSV UTF-8”.', 'educore-assessments' ) );
		}
		$first = strtok( $raw, "\n" );
		$sep   = substr_count( (string) $first, ';' ) > substr_count( (string) $first, ',' ) ? ';' : ',';
		$fh    = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $fh, $raw ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		rewind( $fh );
		$head = fgetcsv( $fh, 0, $sep, '"', '' );
		if ( ! $head ) {
			return new \WP_Error( 'ec_x_empty', __( 'The file is empty.', 'educore-assessments' ) );
		}
		$head = array_map( static fn( $h ) => sanitize_key( trim( (string) $h ) ), $head );
		$rows = array();
		$line = 1;
		while ( ( $r = fgetcsv( $fh, 0, $sep, '"', '' ) ) !== false ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
			++$line;
			if ( array( null ) === $r ) {
				continue;
			}
			$rows[ $line ] = array_combine( $head, array_pad( array_slice( $r, 0, count( $head ) ), count( $head ), '' ) );
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return self::check_header( $head ) ?? $rows;
	}

	private static function check_header( array $head ): ?\WP_Error {
		$missing = array_diff( array( 'type', 'stem' ), $head );
		if ( $missing ) {
			/* translators: %s: column names */
			return new \WP_Error( 'ec_x_header', sprintf( __( 'Required column(s) missing from the header row: %s. Download the template for the expected layout.', 'educore-assessments' ), implode( ', ', $missing ) ) );
		}
		return null;
	}

	public static function write_csv( array $records ): string {
		$fh = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fputcsv( $fh, self::COLUMNS, ',', '"', '' );
		foreach ( $records as $r ) {
			fputcsv( $fh, array_map( array( self::class, 'guard' ), self::record_to_row( $r ) ), ',', '"', '' );
		}
		rewind( $fh );
		$csv = (string) stream_get_contents( $fh );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return "\xEF\xBB\xBF" . $csv;
	}

	/* ---------------- XLSX ---------------- */

	public static function write_xlsx( array $records ): string {
		$rows = array( self::COLUMNS );
		foreach ( $records as $r ) {
			$rows[] = self::record_to_row( $r );
		}
		return Xlsx::write( $rows, 'Questions' );
	}

	/** @return array<int,array<string,string>>|\WP_Error */
	public static function read_xlsx( string $path ) {
		$grid = Xlsx::read( $path );
		if ( is_wp_error( $grid ) ) {
			return $grid;
		}
		if ( ! $grid ) {
			return new \WP_Error( 'ec_x_empty', __( 'The file is empty.', 'educore-assessments' ) );
		}
		$first = array_key_first( $grid );
		$head  = array_map( static fn( $h ) => sanitize_key( trim( (string) $h ) ), $grid[ $first ] );
		unset( $grid[ $first ] );
		$rows = array();
		foreach ( $grid as $line => $cells ) {
			$row = array();
			foreach ( $head as $i => $h ) {
				if ( '' !== $h ) {
					$row[ $h ] = (string) ( $cells[ $i ] ?? '' );
				}
			}
			$rows[ $line ] = $row;
		}
		return self::check_header( $head ) ?? $rows;
	}
}
