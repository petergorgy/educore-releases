<?php
namespace EduCore\Recovery;

defined( 'ABSPATH' ) || exit;

/**
 * Logical database dump with a consistent read view (InnoDB consistent snapshot) and per-table
 * fingerprints (row count + SHA-256 over rows in primary-key order) used to prove restores.
 * Table names are written with the placeholder {{P}} instead of the site prefix.
 */
final class Dumper {
	public const PH    = '{{P}}';
	public const BATCH = 500;

	/** Tables per backup scope. Academic = EduCore tables + the WordPress tables they reference. */
	public static function tables( string $kind ): array {
		global $wpdb;
		$all = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix ) . '%' ) );
		$all = array_values( array_filter( $all, static fn( $t ) => ! preg_match( '/^' . preg_quote( $wpdb->prefix, '/' ) . '(ecrt|ecrs|ecold)/', $t ) ) );
		$own = $wpdb->prefix . 'ec_rc_backups';
		$all = array_values( array_diff( $all, array( $own ) ) ); // Backup history is never part of a restore.
		if ( 'academic' === $kind ) {
			$keep = array( 'users', 'usermeta', 'posts', 'postmeta', 'terms', 'term_taxonomy', 'term_relationships', 'termmeta', 'options' );
			return array_values( array_filter( $all, static fn( $t ) => 0 === strpos( $t, $wpdb->prefix . 'ec_' ) || in_array( substr( $t, strlen( $wpdb->prefix ) ), $keep, true ) ) );
		}
		return $all;
	}

	public static function rel( string $table ): string {
		global $wpdb;
		return self::PH . substr( $table, strlen( $wpdb->prefix ) );
	}

	/** Primary-key column list (falls back to all columns). */
	private static function order_by( string $table ): string {
		global $wpdb;
		$pk = $wpdb->get_col( "SHOW KEYS FROM `{$table}` WHERE Key_name = 'PRIMARY'", 4 ); // phpcs:ignore WordPress.DB.PreparedSQL -- identifier from SHOW TABLES.
		if ( ! $pk ) {
			$pk = $wpdb->get_col( "SHOW COLUMNS FROM `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		return implode( ',', array_map( static fn( $c ) => '`' . str_replace( '`', '', $c ) . '`', $pk ) );
	}

	/** @return array{rows:int,sha256:string} */
	public static function fingerprint( string $table ): array {
		global $wpdb;
		$h     = hash_init( 'sha256' );
		$rows  = 0;
		$order = self::order_by( $table );
		for ( $off = 0; ; $off += self::BATCH ) {
			$batch = $wpdb->get_results( "SELECT * FROM `{$table}` ORDER BY {$order} LIMIT {$off}, " . self::BATCH, ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL
			if ( ! $batch ) {
				break;
			}
			foreach ( $batch as $r ) {
				hash_update( $h, self::row_bytes( $r ) );
				++$rows;
			}
			if ( count( $batch ) < self::BATCH ) {
				break;
			}
		}
		return array( 'rows' => $rows, 'sha256' => hash_final( $h ) );
	}

	/** Byte-exact, unambiguous row serialisation for fingerprints (safe for binary data). */
	private static function row_bytes( array $r ): string {
		$out = '';
		foreach ( $r as $v ) {
			$out .= null === $v ? "\x00N" : strlen( (string) $v ) . ':' . $v;
			$out .= "\x1f";
		}
		return $out . "\x1e";
	}

	/**
	 * SQL literal. Values with non-ASCII or control bytes are written as hex so the dump stays pure ASCII:
	 * no character-set conversion, no line breaks inside statements, byte-exact round trip.
	 */
	public static function literal( $v ): string {
		if ( null === $v ) {
			return 'NULL';
		}
		$v = (string) $v;
		if ( '' === $v ) {
			return "''";
		}
		if ( preg_match( '/[^\x20-\x7E]/', $v ) ) {
			return '0x' . bin2hex( $v );
		}
		return "'" . str_replace( array( '\\', "'" ), array( '\\\\', "\\'" ), $v ) . "'";
	}

	private static function in_transaction(): bool {
		global $wpdb;
		$v = $wpdb->get_var( 'SELECT @@in_transaction' );
		return null !== $v && (int) $v > 0;
	}

	/**
	 * Write the dump. Returns per-table fingerprints (computed inside the same snapshot).
	 *
	 * @param string[] $tables
	 * @return array<string,array{rows:int,sha256:string}>
	 */
	public static function dump( array $tables, string $file ): array {
		global $wpdb;
		$fh   = fopen( $file, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$snap = ! self::in_transaction();
		if ( $snap ) {
			$wpdb->query( 'SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ' );
			$wpdb->query( 'START TRANSACTION WITH CONSISTENT SNAPSHOT' );
		}
		fwrite( $fh, "-- EduCore backup dump. One statement per line. Table prefix placeholder: " . self::PH . "\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$fp = array();
		foreach ( $tables as $t ) {
			$rel    = self::rel( $t );
			$create = $wpdb->get_row( "SHOW CREATE TABLE `{$t}`", ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL
			$ddl    = str_replace( array( "\r", "\n" ), ' ', str_replace( "`{$t}`", "`{$rel}`", (string) $create[1] ) );
			fwrite( $fh, "-- TABLE {$rel}\nDROP TABLE IF EXISTS `{$rel}`;\n{$ddl};\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$h     = hash_init( 'sha256' );
			$rows  = 0;
			$order = self::order_by( $t );
			for ( $off = 0; ; $off += self::BATCH ) {
				$batch = $wpdb->get_results( "SELECT * FROM `{$t}` ORDER BY {$order} LIMIT {$off}, " . self::BATCH, ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL
				if ( ! $batch ) {
					break;
				}
				$vals = array();
				foreach ( $batch as $r ) {
					hash_update( $h, self::row_bytes( $r ) );
					++$rows;
					$vals[] = '(' . implode( ',', array_map( array( self::class, 'literal' ), $r ) ) . ')';
				}
				fwrite( $fh, "INSERT INTO `{$rel}` VALUES " . implode( ',', $vals ) . ";\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( count( $batch ) < self::BATCH ) {
					break;
				}
			}
			$fp[ $rel ] = array( 'rows' => $rows, 'sha256' => hash_final( $h ) );
		}
		fwrite( $fh, "SET FOREIGN_KEY_CHECKS=1;\n-- END\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( $snap ) {
			$wpdb->query( 'COMMIT' );
		}
		return $fp;
	}

	/**
	 * Load a dump into tables named <$prefix><table>. Only tables listed in $only (relative names) are loaded.
	 *
	 * @return true|\WP_Error
	 */
	public static function load( string $file, string $prefix, array $only ) {
		global $wpdb;
		$fh      = fopen( $file, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$current = '';
		$ok      = true;
		$suppress = $wpdb->suppress_errors( true );
		while ( false !== ( $line = fgets( $fh ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
			$line = rtrim( $line, "\r\n" );
			if ( '' === $line ) {
				continue;
			}
			if ( 0 === strpos( $line, '-- TABLE ' ) ) {
				$current = substr( $line, 9 );
				continue;
			}
			if ( 0 === strpos( $line, '--' ) || 0 === strpos( $line, 'SET ' ) ) {
				continue;
			}
			if ( ! in_array( $current, $only, true ) ) {
				continue;
			}
			if ( false === $wpdb->query( str_replace( '`' . self::PH, '`' . $prefix, $line ) ) ) { // phpcs:ignore WordPress.DB.PreparedSQL -- statements generated by Dumper::dump().
				$ok = new \WP_Error( 'ec_rc_load', sprintf( /* translators: 1: table, 2: error */ __( 'Loading %1$s failed: %2$s', 'educore-recovery' ), $current, $wpdb->last_error ) );
				break;
			}
		}
		$wpdb->suppress_errors( $suppress );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $ok;
	}
}
