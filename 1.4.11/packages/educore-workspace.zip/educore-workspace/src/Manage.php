<?php
namespace EduCore\Workspace;

use EduCore\Core\Audit;
use EduCore\Core\Auth\Suspension;
use EduCore\Core\Content;
use EduCore\Core\Enrollment;
use EduCore\Core\I18n;
use EduCore\Core\Registry;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/** EduCore Management (`/manage/`): server-rendered views; changes go through the REST endpoints in Rest. */
final class Manage {

	public static function register(): void {
		add_shortcode( 'educore_manage', array( self::class, 'render' ) );
	}

	private static function url( array $args = array() ): string {
		return Pages::url( 'manage', $args );
	}

	private static function q( string $k ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view parameters.
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
	}

	public static function render(): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return '<div class="ec-card"><p>' . esc_html__( 'Please sign in.', 'educore-workspace' ) . '</p></div>';
		}
		if ( ! Navigation::can_manage( $uid ) ) {
			Shell::title( __( 'EduCore Management', 'educore-workspace' ) );
			return '<div class="ec-notice ec-notice--info" role="status">' . esc_html__( 'EduCore Management is for academic managers and administrators.', 'educore-workspace' ) . '</div>';
		}
		$v    = sanitize_key( self::q( 'v' ) ) ?: 'overview';
		$view = array(
			'overview' => 'overview',
			'people'   => 'people',
			'person'   => 'person',
			'courses'  => 'courses',
			'course'   => 'course',
			'audit'    => 'audit',
			'system'   => 'system',
			'settings' => 'settings',
			'analytics' => 'analytics',
			'programmes' => 'programmes',
			'success' => 'success',
			'people-import' => 'people_import',
			'programme' => 'programme',
			'certificates' => 'certificates',
			'search'   => 'search',
		)[ $v ] ?? 'overview';
		$html = self::flash() . self::{'view_' . $view}( $uid );
		return '<div class="ec-ws" data-ec-ws>' . $html . '</div>';
	}

	private static function flash(): string {
		$m = array(
			'created'  => __( 'The account was created.', 'educore-workspace' ),
			'saved'    => __( 'Changes saved.', 'educore-workspace' ),
			/* translators: %d: number of people */
			'imported' => sprintf( _n( '%d person was created from the import.', '%d people were created from the import.', (int) self::q( 'n' ), 'educore-workspace' ), (int) self::q( 'n' ) ),
		)[ sanitize_key( self::q( 'ec_msg' ) ) ] ?? '';
		return $m ? '<div class="ec-notice ec-notice--success" role="status">' . esc_html( $m ) . '</div>' : '';
	}

	private static function denied(): string {
		return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'You do not have access to this section.', 'educore-workspace' ) . '</div>';
	}

	private static function stat( string $label, $value, string $url = '' ): string {
		$v = '<span class="ec-ws-stat__v">' . esc_html( is_numeric( $value ) ? number_format_i18n( (float) $value ) : (string) $value ) . '</span><span class="ec-ws-stat__l">' . esc_html( $label ) . '</span>';
		return '<li class="ec-ws-stat">' . ( $url ? '<a href="' . esc_url( $url ) . '">' . $v . '</a>' : $v ) . '</li>';
	}

	/* ---------- Overview ---------- */

	private static function view_overview( int $uid ): string {
		global $wpdb;
		Shell::title( __( 'EduCore Management', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Overview', 'educore-workspace' ) ) ) );
		$counts   = count_users();
		$roles    = $counts['avail_roles'] ?? array();
		$courses  = wp_count_posts( Content::COURSE );
		$et       = \EduCore\Core\Schema::table( 'enrollments' );
		$active   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$et} WHERE status='active'" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$susp     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key=%s", Suspension::META ) );
		$out      = '<ul class="ec-ws-stats">';
		$out     .= self::stat( __( 'Students', 'educore-workspace' ), (int) ( $roles['ec_student'] ?? 0 ), self::url( array( 'v' => 'people', 'role' => 'ec_student' ) ) );
		$out     .= self::stat( __( 'Teaching staff', 'educore-workspace' ), (int) ( $roles['ec_instructor'] ?? 0 ) + (int) ( $roles['ec_teacher'] ?? 0 ) + (int) ( $roles['ec_tutor'] ?? 0 ), self::url( array( 'v' => 'people' ) ) );
		$out     .= self::stat( __( 'Guardians', 'educore-workspace' ), (int) ( $roles['ec_guardian'] ?? 0 ), self::url( array( 'v' => 'people', 'role' => 'ec_guardian' ) ) );
		$out     .= self::stat( __( 'Published courses', 'educore-workspace' ), (int) ( $courses->publish ?? 0 ), self::url( array( 'v' => 'courses' ) ) );
		$out     .= self::stat( __( 'Courses awaiting review', 'educore-workspace' ), (int) ( $courses->pending ?? 0 ), self::url( array( 'v' => 'courses', 'status' => 'pending' ) ) );
		$out     .= self::stat( __( 'Active enrollments', 'educore-workspace' ), $active );
		$out     .= self::stat( __( 'Suspended accounts', 'educore-workspace' ), $susp, self::url( array( 'v' => 'people', 'status' => 'suspended' ) ) );
		$out     .= '</ul>';
		$out     .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Recent activity', 'educore-workspace' ) . '</h2>' . self::audit_table( 8 ) . '</section>';
		return $out;
	}

	/* ---------- People ---------- */

	private static function view_people( int $uid ): string {
		if ( ! People::can_manage( $uid ) ) {
			return self::denied();
		}
		Shell::title( __( 'People', 'educore-workspace' ), '<a class="ec-btn ec-btn--primary" href="' . esc_url( self::url( array( 'v' => 'person', 'new' => 1 ) ) ) . '">' . esc_html__( 'Add a person', 'educore-workspace' ) . '</a> <a class="ec-btn" href="' . esc_url( self::url( array( 'v' => 'people-import' ) ) ) . '">' . esc_html__( 'Import people', 'educore-workspace' ) . '</a>' );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), self::url() ), array( __( 'People', 'educore-workspace' ) ) ) );
		$args   = array( 'q' => self::q( 'q' ), 'role' => self::q( 'role' ), 'status' => self::q( 'status' ), 'page' => max( 1, (int) self::q( 'pg' ) ) );
		$res    = People::search( $uid, $args );
		$labels = People::role_labels();
		$out    = '<form class="ec-ws-filters" method="get" action="' . esc_url( self::url() ) . '" role="search"><input type="hidden" name="v" value="people">';
		$out   .= '<label><span>' . esc_html__( 'Search', 'educore-workspace' ) . '</span><input type="search" name="q" value="' . esc_attr( $args['q'] ) . '" placeholder="' . esc_attr__( 'Name, e-mail or username', 'educore-workspace' ) . '"></label>';
		$out   .= '<label><span>' . esc_html__( 'Role', 'educore-workspace' ) . '</span><select name="role"><option value="">' . esc_html__( 'All roles', 'educore-workspace' ) . '</option>';
		foreach ( $labels as $k => $l ) {
			$out .= '<option value="' . esc_attr( $k ) . '"' . selected( $args['role'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		$out .= '</select></label><label><span>' . esc_html__( 'Status', 'educore-workspace' ) . '</span><select name="status"><option value="">' . esc_html__( 'Any', 'educore-workspace' ) . '</option><option value="suspended"' . selected( $args['status'], 'suspended', false ) . '>' . esc_html__( 'Suspended', 'educore-workspace' ) . '</option></select></label>';
		$out .= '<button class="ec-btn" type="submit">' . esc_html__( 'Filter', 'educore-workspace' ) . '</button></form>';
		/* translators: %d: number of people */
		$out .= '<p class="ec-muted" role="status">' . esc_html( sprintf( _n( '%d person', '%d people', $res['total'], 'educore-workspace' ), $res['total'] ) ) . '</p>';
		if ( ! $res['rows'] ) {
			return $out . '<div class="ec-ws-empty"><p>' . esc_html__( 'No one matches these filters.', 'educore-workspace' ) . '</p></div>';
		}
		$out .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><caption class="screen-reader-text">' . esc_html__( 'People', 'educore-workspace' ) . '</caption><thead><tr><th scope="col">' . esc_html__( 'Name', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'E-mail', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Roles', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $res['rows'] as $p ) {
			$r    = $p['technical'] ? '<span class="ec-chip">' . esc_html__( 'Technical administrator', 'educore-workspace' ) . '</span>' : implode( ' ', array_map( static fn( $x ) => '<span class="ec-chip">' . esc_html( $labels[ $x ] ?? $x ) . '</span>', $p['roles'] ) );
			$out .= '<tr><th scope="row"><a href="' . esc_url( self::url( array( 'v' => 'person', 'id' => $p['id'] ) ) ) . '">' . esc_html( $p['name'] ) . '</a></th><td>' . esc_html( $p['email'] ) . '</td><td>' . $r . '</td><td>' . ( $p['suspended'] ? '<span class="ec-chip ec-chip--warn">' . esc_html__( 'Suspended', 'educore-workspace' ) . '</span>' : esc_html__( 'Active', 'educore-workspace' ) ) . '</td></tr>';
		}
		$out .= '</tbody></table></div>' . self::pager( $res['pages'], $args['page'], array( 'v' => 'people', 'q' => $args['q'], 'role' => $args['role'], 'status' => $args['status'] ) );
		return $out;
	}

	private static function pager( int $pages, int $cur, array $args ): string {
		if ( $pages < 2 ) {
			return '';
		}
		$link = fn( int $i, string $label, string $rel = '' ) => '<li><a href="' . esc_url( self::url( array_filter( $args ) + array( 'pg' => $i ) ) ) . '"' . ( $rel ? ' rel="' . $rel . '"' : '' ) . '>' . esc_html( $label ) . '</a></li>';
		$o    = '<nav class="ec-ws-pager" aria-label="' . esc_attr__( 'Pages', 'educore-workspace' ) . '"><ul>';
		if ( $cur > 1 ) {
			$o .= $link( $cur - 1, __( 'Previous', 'educore-workspace' ), 'prev' );
		}
		$shown = array_unique( array_filter( array( 1, $cur - 2, $cur - 1, $cur, $cur + 1, $cur + 2, $pages ), static fn( $i ) => $i >= 1 && $i <= $pages ) );
		sort( $shown );
		$prev = 0;
		foreach ( $shown as $i ) {
			if ( $prev && $i > $prev + 1 ) {
				$o .= '<li aria-hidden="true">…</li>';
			}
			$o   .= $i === $cur ? '<li><span aria-current="page">' . esc_html( number_format_i18n( $i ) ) . '</span></li>' : $link( $i, number_format_i18n( $i ) );
			$prev = $i;
		}
		if ( $cur < $pages ) {
			$o .= $link( $cur + 1, __( 'Next', 'educore-workspace' ), 'next' );
		}
		return $o . '</ul></nav>';
	}

	private static function role_checks( int $uid, array $checked, bool $disabled = false ): string {
		$labels = People::role_labels();
		$ok     = People::assignable( $uid );
		$o      = '<fieldset class="ec-ws-roles"><legend>' . esc_html__( 'Roles', 'educore-workspace' ) . '</legend>';
		foreach ( $labels as $k => $l ) {
			if ( ! in_array( $k, $ok, true ) && ! in_array( $k, $checked, true ) ) {
				continue;
			}
			$o .= '<label class="ec-check"><input type="checkbox" name="roles[]" value="' . esc_attr( $k ) . '"' . checked( in_array( $k, $checked, true ), true, false ) . disabled( $disabled || ! in_array( $k, $ok, true ), true, false ) . '> ' . esc_html( $l ) . '</label>';
		}
		return $o . '</fieldset>';
	}

	private static function view_person( int $uid ): string {
		if ( ! People::can_manage( $uid ) ) {
			return self::denied();
		}
		$crumb = array( __( 'Management', 'educore-workspace' ), self::url() );
		if ( self::q( 'new' ) ) {
			Shell::title( __( 'Add a person', 'educore-workspace' ) );
			Shell::crumbs( array( $crumb, array( __( 'People', 'educore-workspace' ), self::url( array( 'v' => 'people' ) ) ), array( __( 'Add a person', 'educore-workspace' ) ) ) );
			$f  = '<form class="ec-card ec-ws-form" data-ec-api="manage/people" data-ec-method="POST" novalidate>';
			$f .= '<div class="ec-ws-grid">' . self::input( 'first', __( 'First name', 'educore-workspace' ) ) . self::input( 'last', __( 'Last name', 'educore-workspace' ) ) . self::input( 'email', __( 'E-mail address', 'educore-workspace' ), '', 'email', true ) . self::input( 'login', __( 'Username (optional)', 'educore-workspace' ) ) . '</div>';
			$f .= self::role_checks( $uid, array( 'ec_student' ) );
			$f .= '<div class="ec-ws-grid" data-ec-show-if="ec_student"><label><span>' . esc_html__( 'Age group (students)', 'educore-workspace' ) . '</span><select name="age_band"><option value="18plus">' . esc_html__( '18 or older', 'educore-workspace' ) . '</option><option value="15to17">' . esc_html__( '15 to 17', 'educore-workspace' ) . '</option><option value="under15">' . esc_html__( 'Under 15', 'educore-workspace' ) . '</option></select></label>';
			$f .= self::input( 'guardian_email', __( 'Guardian e-mail (minors: sends the consent request)', 'educore-workspace' ), '', 'email' ) . '</div>';
			$f .= '<label class="ec-check"><input type="checkbox" name="invite" value="1" checked> ' . esc_html__( 'E-mail an invitation so the person sets their own password', 'educore-workspace' ) . '</label>';
			$f .= '<p class="ec-muted">' . esc_html__( 'EduCore never sets or shows passwords. Learners under 18 can start once a guardian has given consent.', 'educore-workspace' ) . '</p>';
			$f .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Create account', 'educore-workspace' ) . '</button> <a class="ec-btn" href="' . esc_url( self::url( array( 'v' => 'people' ) ) ) . '">' . esc_html__( 'Cancel', 'educore-workspace' ) . '</a></div></form>';
			return $f;
		}
		$id = (int) self::q( 'id' );
		$p  = People::profile( $uid, $id );
		if ( ! $p ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'This person was not found.', 'educore-workspace' ) . '</div>';
		}
		$ed = $p['editable'];
		Shell::title( $p['name'] );
		Shell::crumbs( array( $crumb, array( __( 'People', 'educore-workspace' ), self::url( array( 'v' => 'people' ) ) ), array( $p['name'] ) ) );
		$o = '';
		if ( $p['technical'] ) {
			$o .= '<div class="ec-notice ec-notice--info" role="status">' . esc_html__( 'This is a technical administrator account. It is managed in WordPress by an administrator, not here.', 'educore-workspace' ) . '</div>';
		} elseif ( ! $ed ) {
			$o .= '<div class="ec-notice ec-notice--info" role="status">' . esc_html__( 'You can view this account but not change it.', 'educore-workspace' ) . '</div>';
		}
		$o .= '<div class="ec-ws-cols"><div>';
		$o .= '<form class="ec-card ec-ws-form" data-ec-api="manage/people/' . (int) $id . '" data-ec-method="POST" data-ec-dirty><h2>' . esc_html__( 'Profile', 'educore-workspace' ) . '</h2><fieldset' . disabled( ! $ed, true, false ) . ' class="ec-ws-plain"><div class="ec-ws-grid">';
		$o .= self::input( 'first', __( 'First name', 'educore-workspace' ), $p['first'] ) . self::input( 'last', __( 'Last name', 'educore-workspace' ), $p['last'] ) . self::input( 'name', __( 'Display name', 'educore-workspace' ), $p['name'] ) . self::input( 'email', __( 'E-mail address', 'educore-workspace' ), $p['email'], 'email', true ) . '</div>';
		$o .= self::role_checks( $uid, $p['roles'], ! $ed );
		$o .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Save changes', 'educore-workspace' ) . '</button></div></fieldset></form>';
		// Enrollments and teaching.
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Learning', 'educore-workspace' ) . '</h2>';
		$o .= $p['enrollments'] ? '<ul class="ec-ws-list">' . implode( '', array_map( static fn( $e ) => '<li><span>' . esc_html( $e['title'] ) . '</span><span class="ec-chip">' . esc_html( $e['status'] ) . '</span></li>', $p['enrollments'] ) ) . '</ul>' : '<p class="ec-muted">' . esc_html__( 'Not enrolled in any course.', 'educore-workspace' ) . '</p>';
		if ( $ed && user_can( $uid, 'ec_manage_all_courses' ) ) {
			$o .= '<form class="ec-ws-inline" data-ec-api="" data-ec-api-from="course" data-ec-api-tpl="manage/courses/{course}/enroll" data-ec-method="POST"><input type="hidden" name="user_id" value="' . (int) $id . '">' . self::course_select( 'course', __( 'Enroll in', 'educore-workspace' ) ) . '<button class="ec-btn" type="submit">' . esc_html__( 'Enroll', 'educore-workspace' ) . '</button></form>';
		}
		$o .= '</section>';
		if ( $p['teaching'] || ( $ed && user_can( $id, 'ec_access_workspace' ) ) ) {
			$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Teaching', 'educore-workspace' ) . '</h2>';
			$o .= $p['teaching'] ? '<ul class="ec-ws-list">' . implode( '', array_map( static fn( $t ) => '<li><span>' . esc_html( $t['title'] ) . '</span><span class="ec-chip">' . esc_html( (string) $t['role'] ) . '</span></li>', $p['teaching'] ) ) . '</ul>' : '<p class="ec-muted">' . esc_html__( 'No courses assigned yet.', 'educore-workspace' ) . '</p>';
			if ( $ed && user_can( $uid, 'ec_manage_all_courses' ) && user_can( $id, 'ec_access_workspace' ) ) {
				$o .= '<form class="ec-ws-inline" data-ec-api="" data-ec-api-from="course" data-ec-api-tpl="manage/courses/{course}/team" data-ec-method="POST"><input type="hidden" name="user_id" value="' . (int) $id . '">' . self::course_select( 'course', __( 'Course', 'educore-workspace' ) ) . '<label><span>' . esc_html__( 'As', 'educore-workspace' ) . '</span><select name="role"><option value="instructor">' . esc_html__( 'Instructor', 'educore-workspace' ) . '</option><option value="lead">' . esc_html__( 'Lead instructor', 'educore-workspace' ) . '</option><option value="grader">' . esc_html__( 'Grader', 'educore-workspace' ) . '</option></select></label><button class="ec-btn" type="submit">' . esc_html__( 'Assign', 'educore-workspace' ) . '</button></form>';
			}
			$o .= '</section>';
		}
		$o .= '</div><div>';
		// Account status card.
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Account', 'educore-workspace' ) . '</h2><dl class="ec-ws-dl"><dt>' . esc_html__( 'Username', 'educore-workspace' ) . '</dt><dd>' . esc_html( $p['login'] ) . '</dd><dt>' . esc_html__( 'Status', 'educore-workspace' ) . '</dt><dd>' . ( $p['suspended'] ? esc_html__( 'Suspended', 'educore-workspace' ) : esc_html__( 'Active', 'educore-workspace' ) ) . '</dd>';
		if ( in_array( 'ec_student', $p['roles'], true ) ) {
			$o .= '<dt>' . esc_html__( 'Consent', 'educore-workspace' ) . '</dt><dd>' . esc_html( self::consent_label( $p['consent'] ) ) . '</dd>';
		}
		$o .= '</dl>';
		if ( $ed && $id !== $uid ) {
			$o .= '<div class="ec-ws-actions ec-ws-actions--stack">';
			$o .= '<button class="ec-btn" type="button" data-ec-call="manage/people/' . (int) $id . '/invite" data-ec-method="POST">' . esc_html__( 'Send invitation e-mail', 'educore-workspace' ) . '</button>';
			$o .= '<button class="ec-btn" type="button" data-ec-call="manage/people/' . (int) $id . '/reset" data-ec-method="POST">' . esc_html__( 'Send password-reset e-mail', 'educore-workspace' ) . '</button>';
			$o .= $p['suspended']
				? '<button class="ec-btn" type="button" data-ec-call="manage/people/' . (int) $id . '/status" data-ec-method="POST" data-ec-body="{&quot;suspended&quot;:false}">' . esc_html__( 'Reactivate account', 'educore-workspace' ) . '</button>'
				: '<button class="ec-btn ec-btn--danger" type="button" data-ec-call="manage/people/' . (int) $id . '/status" data-ec-method="POST" data-ec-body="{&quot;suspended&quot;:true}" data-ec-confirm="' . esc_attr__( 'Suspend this account? The person is signed out everywhere and cannot sign in until reactivated. No data is deleted.', 'educore-workspace' ) . '">' . esc_html__( 'Suspend account', 'educore-workspace' ) . '</button>';
			$o .= '</div>';
		}
		$o .= '</section>';
		// Guardians.
		if ( in_array( 'ec_student', $p['roles'], true ) ) {
			$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Guardians', 'educore-workspace' ) . '</h2>';
			if ( $p['guardians'] ) {
				$o .= '<ul class="ec-ws-list">';
				foreach ( $p['guardians'] as $g ) {
					$o .= '<li><span>' . esc_html( $g['guardian_name'] ?: $g['guardian_email'] ) . ' <span class="ec-chip">' . esc_html( $g['status'] ) . '</span></span>' . ( $ed && 'revoked' !== $g['status'] ? '<button class="ec-btn ec-btn--small" type="button" data-ec-call="manage/guardian-links/' . (int) $g['id'] . '" data-ec-method="DELETE" data-ec-confirm="' . esc_attr__( 'Remove this guardian link?', 'educore-workspace' ) . '">' . esc_html__( 'Remove', 'educore-workspace' ) . '</button>' : '' ) . '</li>';
				}
				$o .= '</ul>';
			} else {
				$o .= '<p class="ec-muted">' . esc_html__( 'No guardian linked.', 'educore-workspace' ) . '</p>';
			}
			if ( $ed ) {
				$o .= '<form class="ec-ws-inline" data-ec-api="manage/people/' . (int) $id . '/guardians" data-ec-method="POST">' . self::guardian_select() . '<button class="ec-btn" type="submit">' . esc_html__( 'Link guardian', 'educore-workspace' ) . '</button></form>';
			}
			$o .= '</section>';
		}
		if ( $p['learners'] ) {
			$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Linked learners', 'educore-workspace' ) . '</h2><ul class="ec-ws-list">';
			foreach ( $p['learners'] as $l ) {
				$s  = get_userdata( (int) $l['student_id'] );
				$o .= '<li><a href="' . esc_url( self::url( array( 'v' => 'person', 'id' => (int) $l['student_id'] ) ) ) . '">' . esc_html( $s ? $s->display_name : '#' . $l['student_id'] ) . '</a><span class="ec-chip">' . esc_html( $l['status'] ) . '</span></li>';
			}
			$o .= '</ul></section>';
		}
		return $o . '</div></div>';
	}

	private static function consent_label( string $state ): string {
		return array(
			''                 => __( 'Recorded by the school (account created by staff)', 'educore-workspace' ),
			'granted'          => __( 'Given by the learner', 'educore-workspace' ),
			'granted_guardian' => __( 'Given by a guardian', 'educore-workspace' ),
			'pending_guardian' => __( 'Waiting for guardian consent', 'educore-workspace' ),
			'withdrawn'        => __( 'Withdrawn', 'educore-workspace' ),
		)[ $state ] ?? $state;
	}

	private static function input( string $name, string $label, string $value = '', string $type = 'text', bool $required = false ): string {
		$id = 'ec-f-' . $name;
		return '<label for="' . esc_attr( $id ) . '"><span>' . esc_html( $label ) . ( $required ? ' <abbr title="' . esc_attr__( 'required', 'educore-workspace' ) . '">*</abbr>' : '' ) . '</span><input id="' . esc_attr( $id ) . '" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . ( $required ? ' required aria-required="true"' : '' ) . ( 'email' === $type ? ' autocomplete="off"' : '' ) . '></label>';
	}

	private static function course_select( string $name, string $label ): string {
		$o = '<label><span>' . esc_html( $label ) . '</span><select name="' . esc_attr( $name ) . '" required>';
		foreach ( get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'private' ), 'numberposts' => 300, 'orderby' => 'title', 'order' => 'ASC' ) ) as $c ) {
			$o .= '<option value="' . (int) $c->ID . '">' . esc_html( get_the_title( $c ) ) . '</option>';
		}
		return $o . '</select></label>';
	}

	private static function guardian_select(): string {
		$o = '<label><span>' . esc_html__( 'Guardian account', 'educore-workspace' ) . '</span><select name="guardian_id" required><option value="">' . esc_html__( 'Choose…', 'educore-workspace' ) . '</option>';
		foreach ( get_users( array( 'role' => 'ec_guardian', 'number' => 500, 'orderby' => 'display_name' ) ) as $g ) {
			$o .= '<option value="' . (int) $g->ID . '">' . esc_html( $g->display_name . ' — ' . $g->user_email ) . '</option>';
		}
		return $o . '</select></label>';
	}

	/* ---------- Courses (status and teaching teams; the course builder arrives in increment B) ---------- */

	private static function view_courses( int $uid ): string {
		if ( ! user_can( $uid, 'ec_manage_all_courses' ) && ! People::can_manage( $uid ) ) {
			return self::denied();
		}
		Shell::title( __( 'Courses', 'educore-workspace' ), user_can( $uid, 'edit_ec_courses' ) ? '<a class="ec-btn ec-btn--primary" href="' . esc_url( Pages::url( 'studio', array( 'v' => 'new' ) ) ) . '">' . esc_html__( 'New course', 'educore-workspace' ) . '</a> <a class="ec-btn" href="' . esc_url( Pages::url( 'studio' ) ) . '">' . esc_html__( 'Course Studio', 'educore-workspace' ) . '</a>' : '' );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), self::url() ), array( __( 'Courses', 'educore-workspace' ) ) ) );
		$status = sanitize_key( self::q( 'status' ) );
		$st     = in_array( $status, array( 'publish', 'draft', 'pending', 'private' ), true ) ? array( $status ) : array( 'publish', 'draft', 'pending', 'private' );
		$posts  = get_posts( array( 'post_type' => Content::COURSE, 'post_status' => $st, 'numberposts' => 200, 'orderby' => 'modified', 's' => self::q( 'q' ) ) );
		$labels = array( 'publish' => __( 'Published', 'educore-workspace' ), 'draft' => __( 'Draft', 'educore-workspace' ), 'pending' => __( 'Awaiting review', 'educore-workspace' ), 'private' => __( 'Private', 'educore-workspace' ) );
		$o      = '<form class="ec-ws-filters" method="get" action="' . esc_url( self::url() ) . '" role="search"><input type="hidden" name="v" value="courses"><label><span>' . esc_html__( 'Search', 'educore-workspace' ) . '</span><input type="search" name="q" value="' . esc_attr( self::q( 'q' ) ) . '"></label><label><span>' . esc_html__( 'Status', 'educore-workspace' ) . '</span><select name="status"><option value="">' . esc_html__( 'Any', 'educore-workspace' ) . '</option>';
		foreach ( $labels as $k => $l ) {
			$o .= '<option value="' . esc_attr( $k ) . '"' . selected( $status, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		$o .= '</select></label><button class="ec-btn" type="submit">' . esc_html__( 'Filter', 'educore-workspace' ) . '</button></form>';
		if ( ! $posts ) {
			return $o . '<div class="ec-ws-empty"><p>' . esc_html__( 'No courses match.', 'educore-workspace' ) . '</p></div>';
		}
		$o .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><thead><tr><th scope="col">' . esc_html__( 'Course', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Teaching team', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Enrolled', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $posts as $c ) {
			$team = array_map( static fn( $r ) => ( get_userdata( (int) $r['user_id'] )->display_name ?? '#' ) . ' (' . $r['staff_role'] . ')', Staff::of_course( (int) $c->ID ) );
			$o   .= '<tr><th scope="row"><a href="' . esc_url( self::url( array( 'v' => 'course', 'id' => (int) $c->ID ) ) ) . '">' . esc_html( get_the_title( $c ) ) . '</a></th><td><span class="ec-chip">' . esc_html( $labels[ $c->post_status ] ?? $c->post_status ) . '</span></td><td>' . esc_html( implode( ', ', $team ) ?: '—' ) . '</td><td>' . esc_html( number_format_i18n( Enrollment::count_for_course( (int) $c->ID ) ) ) . '</td></tr>';
		}
		return $o . '</tbody></table></div>';
	}

	private static function view_course( int $uid ): string {
		$id = (int) self::q( 'id' );
		if ( ! Content::is_course( $id ) || ( ! user_can( $uid, 'ec_manage_all_courses' ) && ! People::can_manage( $uid ) ) ) {
			return self::denied();
		}
		$c = get_post( $id );
		Shell::title( get_the_title( $c ), user_can( $uid, 'edit_post', $id ) ? '<a class="ec-btn ec-btn--primary" href="' . esc_url( Pages::url( 'studio', array( 'course' => $id ) ) ) . '">' . esc_html__( 'Open in Course Studio', 'educore-workspace' ) . '</a>' : '' );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), self::url() ), array( __( 'Courses', 'educore-workspace' ), self::url( array( 'v' => 'courses' ) ) ), array( get_the_title( $c ) ) ) );
		$o  = '<div class="ec-ws-cols"><div><section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Outline', 'educore-workspace' ) . '</h2>';
		$ol = Content::outline( $id, array( 'publish', 'draft', 'pending', 'private' ) );
		if ( ! $ol ) {
			$o .= '<p class="ec-muted">' . esc_html__( 'No units yet.', 'educore-workspace' ) . '</p>';
		} else {
			$o .= '<ol class="ec-ws-outline">';
			foreach ( $ol as $u ) {
				$o .= '<li><strong>' . esc_html( get_the_title( $u['unit'] ) ) . '</strong><ol>' . implode( '', array_map( static fn( $l ) => '<li>' . esc_html( get_the_title( $l ) ) . '</li>', (array) $u['lessons'] ) ) . '</ol></li>';
			}
			$o .= '</ol>';
		}
		$o .= '</section></div><div><section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Teaching team', 'educore-workspace' ) . '</h2><ul class="ec-ws-list">';
		foreach ( Staff::of_course( $id ) as $r ) {
			$u  = get_userdata( (int) $r['user_id'] );
			$o .= '<li><span>' . esc_html( $u ? $u->display_name : '#' . $r['user_id'] ) . ' <span class="ec-chip">' . esc_html( $r['staff_role'] ) . '</span></span>' . ( user_can( $uid, 'ec_manage_all_courses' ) ? '<button class="ec-btn ec-btn--small" type="button" data-ec-call="manage/courses/' . (int) $id . '/team" data-ec-method="POST" data-ec-body="' . esc_attr( wp_json_encode( array( 'user_id' => (int) $r['user_id'], 'role' => 'remove' ) ) ) . '" data-ec-confirm="' . esc_attr__( 'Remove from the teaching team?', 'educore-workspace' ) . '">' . esc_html__( 'Remove', 'educore-workspace' ) . '</button>' : '' ) . '</li>';
		}
		$o .= '</ul>';
		if ( user_can( $uid, 'ec_manage_all_courses' ) ) {
			$o .= '<form class="ec-ws-inline" data-ec-api="manage/courses/' . (int) $id . '/team" data-ec-method="POST"><label><span>' . esc_html__( 'Person', 'educore-workspace' ) . '</span><select name="user_id" required>';
			foreach ( get_users( array( 'capability' => 'ec_access_workspace', 'number' => 500, 'orderby' => 'display_name' ) ) as $s ) {
				$o .= '<option value="' . (int) $s->ID . '">' . esc_html( $s->display_name ) . '</option>';
			}
			$o .= '</select></label><label><span>' . esc_html__( 'As', 'educore-workspace' ) . '</span><select name="role"><option value="instructor">' . esc_html__( 'Instructor', 'educore-workspace' ) . '</option><option value="lead">' . esc_html__( 'Lead instructor', 'educore-workspace' ) . '</option><option value="grader">' . esc_html__( 'Grader', 'educore-workspace' ) . '</option></select></label><button class="ec-btn" type="submit">' . esc_html__( 'Assign', 'educore-workspace' ) . '</button></form>';
		}
		/* translators: %s: number */
		$o .= '</section><section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Enrollment', 'educore-workspace' ) . '</h2><p>' . esc_html( sprintf( __( '%s learners enrolled.', 'educore-workspace' ), number_format_i18n( Enrollment::count_for_course( $id ) ) ) ) . '</p></section>' . Feedback::panel( $uid, $id ) . '</div></div>';
		return $o;
	}

	/* ---------- Audit, system, search ---------- */

	private static function audit_table( int $limit ): string {
		$rows = Audit::query( array( 'per_page' => $limit ) );
		if ( ! $rows ) {
			return '<p class="ec-muted">' . esc_html__( 'No activity recorded yet.', 'educore-workspace' ) . '</p>';
		}
		$o = '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><thead><tr><th scope="col">' . esc_html__( 'When', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Who', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'What', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Object', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$who = (int) ( $r['actor_id'] ?? 0 ) ? ( get_userdata( (int) $r['actor_id'] )->display_name ?? '#' . $r['actor_id'] ) : __( 'System', 'educore-workspace' );
			$o  .= '<tr><td>' . esc_html( get_date_from_gmt( (string) $r['created_at'], 'Y-m-d H:i' ) ) . '</td><td>' . esc_html( $who ) . '</td><td><code>' . esc_html( (string) $r['action'] ) . '</code></td><td>' . esc_html( trim( ( $r['object_type'] ?? '' ) . ' ' . ( (int) ( $r['object_id'] ?? 0 ) ?: '' ) ) ) . '</td></tr>';
		}
		return $o . '</tbody></table></div>';
	}

	private static function view_audit( int $uid ): string {
		if ( ! user_can( $uid, 'ec_view_audit_log' ) && ! user_can( $uid, 'manage_options' ) ) {
			return self::denied();
		}
		Shell::title( __( 'Audit log', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), self::url() ), array( __( 'Audit log', 'educore-workspace' ) ) ) );
		$action = substr( preg_replace( '/[^a-z0-9_.]/', '', strtolower( self::q( 'action' ) ) ), 0, 64 );
		$page   = max( 1, (int) self::q( 'paged' ) );
		$rows   = Audit::query( array( 'action' => $action, 'page' => $page, 'per_page' => 50 ) );
		$o      = '<form class="ec-ws-filters" method="get" action="' . esc_url( self::url() ) . '" role="search"><input type="hidden" name="v" value="audit"><label for="ec-au-action"><span>' . esc_html__( 'Action starts with', 'educore-workspace' ) . '</span><input id="ec-au-action" name="action" value="' . esc_attr( $action ) . '" placeholder="security. settings. certificate."></label><button class="ec-btn" type="submit">' . esc_html__( 'Filter', 'educore-workspace' ) . '</button></form>';
		if ( ! $rows ) {
			return $o . '<p class="ec-muted">' . esc_html__( 'No matching events.', 'educore-workspace' ) . '</p>';
		}
		$o .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><thead><tr><th scope="col">' . esc_html__( 'When', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Who', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'What', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Object', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Details', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$who = (int) ( $r['actor_id'] ?? 0 ) ? ( get_userdata( (int) $r['actor_id'] )->display_name ?? '#' . $r['actor_id'] ) : __( 'System', 'educore-workspace' );
			$ctx = (string) ( $r['context'] ?? '' );
			$o  .= '<tr><td>' . esc_html( get_date_from_gmt( (string) $r['created_at'], 'Y-m-d H:i' ) ) . '</td><td>' . esc_html( $who ) . '</td><td><code>' . esc_html( (string) $r['action'] ) . '</code></td><td>' . esc_html( trim( ( $r['object_type'] ?? '' ) . ' ' . ( (int) ( $r['object_id'] ?? 0 ) ?: '' ) ) ) . '</td><td>' . ( '' !== $ctx && '[]' !== $ctx ? '<code class="ec-audit-ctx">' . esc_html( mb_strimwidth( $ctx, 0, 300, '…' ) ) . '</code>' : '' ) . '</td></tr>';
		}
		$o .= '</tbody></table></div><nav class="ec-ws-pager" aria-label="' . esc_attr__( 'Pages', 'educore-workspace' ) . '"><ul>';
		if ( $page > 1 ) {
			$o .= '<li><a href="' . esc_url( self::url( array_filter( array( 'v' => 'audit', 'action' => $action, 'paged' => $page - 1 ) ) ) ) . '">' . esc_html__( 'Newer', 'educore-workspace' ) . '</a></li>';
		}
		if ( 50 === count( $rows ) ) {
			$o .= '<li><a href="' . esc_url( self::url( array_filter( array( 'v' => 'audit', 'action' => $action, 'paged' => $page + 1 ) ) ) ) . '">' . esc_html__( 'Older', 'educore-workspace' ) . '</a></li>';
		}
		return $o . '</ul></nav>';
	}

	private static function view_system( int $uid ): string {
		if ( ! user_can( $uid, 'ec_manage_settings' ) && ! user_can( $uid, 'manage_options' ) ) {
			return self::denied();
		}
		Shell::title( __( 'System status', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), self::url() ), array( __( 'System status', 'educore-workspace' ) ) ) );
		$o = '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Installed EduCore packages', 'educore-workspace' ) . '</h2><ul class="ec-ws-list">';
		foreach ( Registry::all() as $pkg => $ver ) {
			$o .= '<li><span>' . esc_html( $pkg ) . '</span><code>' . esc_html( (string) $ver ) . '</code></li>';
		}
		$o .= '</ul></section><section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Health', 'educore-workspace' ) . '</h2>';
		$o .= '<ul class="ec-ws-list">';
		foreach ( \EduCore\Core\Installer::environment_checks() as $c ) {
			$o .= '<li><span><strong>' . esc_html( (string) ( $c['label'] ?? '' ) ) . '</strong> — ' . esc_html( (string) ( $c['message'] ?? '' ) ) . '</span><span class="ec-chip' . ( 'pass' === ( $c['status'] ?? '' ) ? '' : ' ec-chip--warn' ) . '">' . esc_html( strtoupper( (string) ( $c['status'] ?? '' ) ) ) . '</span></li>';
		}
		$o .= '</ul>';
		$o .= '</section>';
		if ( current_user_can( 'manage_options' ) ) {
			$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Technical administration', 'educore-workspace' ) . '</h2><p>' . esc_html__( 'Backups and restores, updates, plugins and security settings stay in WordPress, for technical administrators only.', 'educore-workspace' ) . '</p><p class="ec-ws-actions"><a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-backups' ) ) . '">' . esc_html__( 'Backup & Recovery', 'educore-workspace' ) . '</a> <a class="ec-btn" href="' . esc_url( admin_url( 'update-core.php' ) ) . '">' . esc_html__( 'Updates', 'educore-workspace' ) . '</a> <a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-settings' ) ) . '">' . esc_html__( 'Technical settings', 'educore-workspace' ) . '</a></p></section>';
		}
		return $o;
	}

	/* ---------- Student success, people import ---------- */

	private static function view_success( int $uid ): string {
		return Success::render( $uid, 'manage' );
	}

	private static function view_people_import( int $uid ): string {
		return PeopleImport::view( $uid );
	}

	/* ---------- Programmes (institutional view) ---------- */

	private static function view_programmes( int $uid ): string {
		return Programmes::view_list( $uid );
	}

	private static function view_programme( int $uid ): string {
		return Programmes::view_detail( $uid );
	}

	/* ---------- Learning analytics ---------- */

	private static function view_analytics( int $uid ): string {
		return Insights::render( $uid, 'manage' );
	}

	/* ---------- Certificates ---------- */

	private static function view_certificates( int $uid ): string {
		Shell::title( __( 'Certificates', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), self::url() ), array( __( 'Certificates', 'educore-workspace' ) ) ) );
		if ( ! Certs::can( $uid ) ) {
			return self::denied();
		}
		$F   = '\EduCore\Workspace\Studio\View';
		$tab = in_array( self::q( 'tab' ), array( 'issued', 'templates', 'courses' ), true ) ? self::q( 'tab' ) : 'issued';
		$o   = '<nav class="ec-ws-tabs" aria-label="' . esc_attr__( 'Certificate sections', 'educore-workspace' ) . '"><ul>';
		foreach ( array( 'issued' => __( 'Issued', 'educore-workspace' ), 'templates' => __( 'Templates', 'educore-workspace' ), 'courses' => __( 'Course settings', 'educore-workspace' ) ) as $k => $l ) {
			$o .= '<li><a href="' . esc_url( self::url( array( 'v' => 'certificates', 'tab' => $k ) ) ) . '"' . ( $k === $tab ? ' aria-current="page"' : '' ) . '>' . esc_html( $l ) . '</a></li>';
		}
		$o      .= '</ul></nav>';
		$courses = get_posts( array( 'post_type' => Content::COURSE, 'post_status' => 'publish', 'numberposts' => 500, 'orderby' => 'title', 'order' => 'ASC' ) );
		$copts   = array( '' => __( 'Choose a course', 'educore-workspace' ) );
		foreach ( $courses as $c ) {
			$copts[ (string) $c->ID ] = get_the_title( $c ) ?: '#' . $c->ID;
		}
		if ( 'templates' === $tab ) {
			return $o . self::cert_templates();
		}
		if ( 'courses' === $tab ) {
			$tpls = array( '0' => __( 'Default (learner’s language)', 'educore-workspace' ) );
			foreach ( Certs::templates() as $t ) {
				if ( 'publish' === $t->post_status ) {
					$tpls[ (string) $t->ID ] = $t->post_title;
				}
			}
			$o .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><thead><tr><th scope="col">' . esc_html__( 'Course', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Certificate on completion', 'educore-workspace' ) . '</th></tr></thead><tbody>';
			foreach ( $courses as $c ) {
				$on  = 'no' !== get_post_meta( $c->ID, '_ec_cert_enabled', true );
				$sel = '<select name="template" aria-label="' . esc_attr__( 'Template', 'educore-workspace' ) . '">';
				foreach ( $tpls as $k => $l ) {
					$sel .= '<option value="' . esc_attr( $k ) . '"' . selected( (string) (int) get_post_meta( $c->ID, '_ec_cert_template', true ), $k, false ) . '>' . esc_html( $l ) . '</option>';
				}
				$sel .= '</select>';
				$o   .= '<tr><td>' . esc_html( get_the_title( $c ) ?: '#' . $c->ID ) . '</td><td><form class="ec-ws-inline" data-ec-api="manage/courses/' . (int) $c->ID . '/certificate" data-ec-method="POST" data-ec-after="stay"><label class="ec-ws-check"><input type="hidden" name="enabled" value="0"><input type="checkbox" name="enabled" value="1"' . checked( $on, true, false ) . '> ' . esc_html__( 'Issue', 'educore-workspace' ) . '</label> ' . $sel . ' <button class="ec-btn ec-btn--small" type="submit">' . esc_html__( 'Save', 'educore-workspace' ) . '</button></form></td></tr>';
			}
			return $o . '</tbody></table></div>';
		}
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Issue a certificate manually', 'educore-workspace' ) . '</h2><p class="ec-muted">' . esc_html__( 'Only enrolled learners can receive a certificate. If the course is not completed, a justification is required and recorded in the audit log.', 'educore-workspace' ) . '</p>';
		$o .= '<form class="ec-ws-form" data-ec-api="manage/certificates" data-ec-method="POST" novalidate><div class="ec-ws-grid">' . $F::field_text( 'email', __( 'Learner e-mail', 'educore-workspace' ), '', true, 'email' ) . $F::field_select( 'course_id', __( 'Course', 'educore-workspace' ), $copts, '' ) . '</div>' . $F::field_text( 'justification', __( 'Justification (only if the course is not completed)', 'educore-workspace' ), '' ) . '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Issue certificate', 'educore-workspace' ) . '</button></div></form></section>';
		$f   = array( 'q' => self::q( 'q' ), 'status' => self::q( 'status' ), 'course_id' => (int) self::q( 'course' ), 'page' => max( 1, (int) self::q( 'paged' ) ) );
		$res = Certs::search( $f );
		$o  .= '<form class="ec-ws-filters" method="get" action="' . esc_url( self::url() ) . '" role="search"><input type="hidden" name="v" value="certificates">' . $F::field_text( 'q', __( 'Search name, course or certificate ID', 'educore-workspace' ), $f['q'], false, 'search' ) . $F::field_select( 'status', __( 'Status', 'educore-workspace' ), array( '' => __( 'All', 'educore-workspace' ), 'valid' => __( 'Valid', 'educore-workspace' ), 'revoked' => __( 'Revoked', 'educore-workspace' ) ), $f['status'] ) . '<button class="ec-btn" type="submit">' . esc_html__( 'Filter', 'educore-workspace' ) . '</button></form>';
		/* translators: %d: number of certificates */
		$o .= '<p class="ec-muted" role="status">' . esc_html( sprintf( _n( '%d certificate', '%d certificates', (int) $res['total'], 'educore-workspace' ), (int) $res['total'] ) ) . '</p>';
		if ( ! $res['rows'] ) {
			return $o . '<div class="ec-ws-empty"><p>' . esc_html__( 'No certificates match.', 'educore-workspace' ) . '</p></div>';
		}
		$o .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><thead><tr><th scope="col">' . esc_html__( 'Learner', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Course', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Issued', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Actions', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $res['rows'] as $r ) {
			$id   = (int) $r['id'];
			$acts = '<a class="ec-btn ec-btn--small" href="' . esc_url( \EduCore\Certificates\Download::url( (string) $r['uid'] ) ) . '">PDF</a> <a class="ec-btn ec-btn--small" href="' . esc_url( \EduCore\Certificates\Verify::url( (string) $r['uid'] ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Verification page', 'educore-workspace' ) . '</a> <button class="ec-btn ec-btn--small" type="button" data-ec-call="manage/certificates/' . $id . '/regenerate">' . esc_html__( 'Regenerate PDF', 'educore-workspace' ) . '</button> ';
			if ( $r['revoked_at'] ) {
				$acts .= '<button class="ec-btn ec-btn--small" type="button" data-ec-call="manage/certificates/' . $id . '/reinstate" data-ec-confirm="' . esc_attr__( 'Reinstate this certificate? It will verify as valid again.', 'educore-workspace' ) . '">' . esc_html__( 'Reinstate', 'educore-workspace' ) . '</button>';
			} else {
				$acts .= '<form class="ec-ws-inline" data-ec-api="manage/certificates/' . $id . '/revoke" data-ec-method="POST" novalidate><label for="ec-rv-' . $id . '" class="screen-reader-text">' . esc_html__( 'Reason for revocation', 'educore-workspace' ) . '</label><input id="ec-rv-' . $id . '" name="reason" required minlength="5" placeholder="' . esc_attr__( 'Reason', 'educore-workspace' ) . '"> <button class="ec-btn ec-btn--small ec-btn--danger" type="submit">' . esc_html__( 'Revoke', 'educore-workspace' ) . '</button></form>';
			}
			$st  = $r['revoked_at'] ? '<span class="ec-chip ec-chip--warn">' . esc_html__( 'Revoked', 'educore-workspace' ) . '</span> <span class="ec-muted">' . esc_html( (string) $r['revoke_reason'] ) . '</span>' : '<span class="ec-chip ec-chip--publish">' . esc_html__( 'Valid', 'educore-workspace' ) . '</span>';
			$o  .= '<tr><td>' . esc_html( (string) $r['student_name'] ) . '<br><code class="ec-muted">' . esc_html( substr( (string) $r['uid'], 0, 12 ) ) . '…</code></td><td>' . esc_html( (string) $r['course_title'] ) . '</td><td>' . esc_html( get_date_from_gmt( (string) $r['issued_at'], get_option( 'date_format' ) ) ) . '</td><td>' . $st . '</td><td class="ec-ws-actions">' . $acts . '</td></tr>';
		}
		$o    .= '</tbody></table></div>';
		$pages = (int) ceil( $res['total'] / 25 );
		if ( $pages > 1 ) {
			$o .= '<nav class="ec-ws-pager" aria-label="' . esc_attr__( 'Pages', 'educore-workspace' ) . '"><ul>';
			for ( $p = max( 1, $f['page'] - 2 ); $p <= min( $pages, $f['page'] + 2 ); $p++ ) {
				$o .= '<li>' . ( $p === $f['page'] ? '<span aria-current="page">' . $p . '</span>' : '<a href="' . esc_url( self::url( array_filter( array( 'v' => 'certificates', 'q' => $f['q'], 'status' => $f['status'], 'paged' => $p ) ) ) ) . '">' . $p . '</a>' ) . '</li>';
			}
			$o .= '</ul></nav>';
		}
		return $o;
	}

	private static function cert_templates(): string {
		$F    = '\EduCore\Workspace\Studio\View';
		$edit = self::q( 'tpl' );
		if ( '' !== $edit ) {
			$id = 'new' === $edit ? 0 : (int) $edit;
			if ( $id && get_post_type( $id ) !== \EduCore\Certificates\Plugin::TEMPLATE ) {
				return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'Template not found.', 'educore-workspace' ) . '</div>';
			}
			$t = $id ? Certs::template_values( $id ) : array( 'title' => '', 'heading' => __( 'Certificate of Completion', 'educore-workspace' ), 'body' => "{student_name}\n{course_title}\n{issue_date}", 'orientation' => 'L', 'accent' => '#0b7f7a', 'sig_name' => '', 'sig_title' => '', 'lang' => I18n::current(), 'status' => 'publish' );
			$o = '<form class="ec-card ec-ws-form ec-studio-narrow" data-ec-api="manage/certificate-templates' . ( $id ? '/' . $id : '' ) . '" data-ec-method="POST"' . ( $id ? ' data-ec-after="stay"' : '' ) . ' data-ec-dirty novalidate>';
			$o .= $F::field_text( 'title', __( 'Template name', 'educore-workspace' ), (string) $t['title'], true ) . $F::field_text( 'heading', __( 'Heading', 'educore-workspace' ), (string) $t['heading'] );
			$o .= $F::field_area( 'body', __( 'Body (one line per row)', 'educore-workspace' ), (string) $t['body'], 6, __( 'Placeholders:', 'educore-workspace' ) . ' ' . implode( ' ', \EduCore\Certificates\Templates::PLACEHOLDERS ) );
			$o .= '<div class="ec-ws-grid">' . $F::field_select( 'lang', __( 'Language / direction', 'educore-workspace' ), I18n::labels(), (string) $t['lang'] ) . $F::field_select( 'orientation', __( 'Orientation', 'educore-workspace' ), array( 'L' => __( 'Landscape', 'educore-workspace' ), 'P' => __( 'Portrait', 'educore-workspace' ) ), (string) $t['orientation'] ) . $F::field_text( 'accent', __( 'Accent colour', 'educore-workspace' ), (string) $t['accent'], false, 'color' ) . '</div>';
			$o .= '<div class="ec-ws-grid">' . $F::field_text( 'sig_name', __( 'Signature name', 'educore-workspace' ), (string) $t['sig_name'] ) . $F::field_text( 'sig_title', __( 'Signature title', 'educore-workspace' ), (string) $t['sig_title'] ) . '</div>';
			$o .= $F::field_select( 'status', __( 'Status', 'educore-workspace' ), array( 'publish' => __( 'Available to courses', 'educore-workspace' ), 'draft' => __( 'Draft', 'educore-workspace' ) ), (string) $t['status'] );
			$o .= '<p class="ec-muted">' . esc_html__( 'Changes apply to certificates generated from now on. Regenerate a PDF to apply them to an issued certificate.', 'educore-workspace' ) . '</p>';
			return $o . '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Save template', 'educore-workspace' ) . '</button> <a class="ec-btn" href="' . esc_url( self::url( array( 'v' => 'certificates', 'tab' => 'templates' ) ) ) . '">' . esc_html__( 'Back', 'educore-workspace' ) . '</a></div></form>';
		}
		$o = '<p class="ec-ws-actions"><a class="ec-btn ec-btn--primary" href="' . esc_url( self::url( array( 'v' => 'certificates', 'tab' => 'templates', 'tpl' => 'new' ) ) ) . '">' . esc_html__( 'New template', 'educore-workspace' ) . '</a></p><ul class="ec-ws-list">';
		foreach ( Certs::templates() as $t ) {
			$v  = Certs::template_values( $t->ID );
			$o .= '<li><a href="' . esc_url( self::url( array( 'v' => 'certificates', 'tab' => 'templates', 'tpl' => $t->ID ) ) ) . '">' . esc_html( $t->post_title ) . '</a><span class="ec-muted">' . esc_html( strtoupper( (string) $v['lang'] ) . ' · ' . ( 'P' === $v['orientation'] ? __( 'Portrait', 'educore-workspace' ) : __( 'Landscape', 'educore-workspace' ) ) . ( 'draft' === $t->post_status ? ' · ' . __( 'Draft', 'educore-workspace' ) : '' ) ) . '</span></li>';
		}
		return $o . '</ul>';
	}

	/* ---------- Platform settings ---------- */

	private static function view_settings( int $uid ): string {
		if ( ! Settings::can( $uid ) ) {
			return self::denied();
		}
		Shell::title( __( 'Platform settings', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), self::url() ), array( __( 'Platform settings', 'educore-workspace' ) ) ) );
		if ( current_user_can( 'upload_files' ) ) {
			wp_enqueue_media();
		}
		$v    = Settings::values();
		$F    = '\EduCore\Workspace\Studio\View';
		$form = static fn( string $section, string $title, string $body, string $intro = '' ) => '<section class="ec-card ec-ws-section" aria-labelledby="ec-set-' . esc_attr( $section ) . '"><h2 id="ec-set-' . esc_attr( $section ) . '">' . esc_html( $title ) . '</h2>' . ( $intro ? '<p class="ec-muted">' . esc_html( $intro ) . '</p>' : '' ) . '<form class="ec-ws-form" data-ec-api="manage/settings/' . esc_attr( $section ) . '" data-ec-method="POST" data-ec-after="stay" data-ec-dirty novalidate>' . $body . '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Save', 'educore-workspace' ) . '</button></div></form></section>';
		$check = static fn( string $name, string $label, bool $on, string $help = '' ) => '<label class="ec-ws-check"><input type="hidden" name="' . esc_attr( $name ) . '" value="0"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( $on, true, false ) . '> ' . esc_html( $label ) . '</label>' . ( $help ? '<p class="ec-muted">' . esc_html( $help ) . '</p>' : '' );
		$o  = '<nav class="ec-ws-tabs" aria-label="' . esc_attr__( 'Settings sections', 'educore-workspace' ) . '"><ul>';
		foreach ( array( 'general' => __( 'General', 'educore-workspace' ), 'access' => __( 'Registration & consent', 'educore-workspace' ), 'engagement' => __( 'Engagement', 'educore-workspace' ), 'branding' => __( 'Branding', 'educore-workspace' ), 'technical' => __( 'Technical', 'educore-workspace' ) ) as $k => $l ) {
			$o .= '<li><a href="#ec-set-' . esc_attr( $k ) . '">' . esc_html( $l ) . '</a></li>';
		}
		$o .= '</ul></nav>';
		$o .= $form(
			'general',
			__( 'General', 'educore-workspace' ),
			'<div class="ec-ws-grid">' . $F::field_text( 'educore_support_email', __( 'Support e-mail', 'educore-workspace' ), $v['educore_support_email'], true, 'email' ) . $F::field_select( 'educore_default_lang', __( 'Default interface language', 'educore-workspace' ), I18n::labels(), $v['educore_default_lang'] ) . '</div>'
			. $F::field_text( 'educore_audit_retention_days', __( 'Audit log retention (days)', 'educore-workspace' ), (string) $v['educore_audit_retention_days'], true, 'number' ) . '<p class="ec-muted">' . esc_html__( '0 keeps the audit log forever; otherwise at least 90 days.', 'educore-workspace' ) . '</p>'
		);
		$open = 'open' === $v['educore_registration'];
		$o   .= $form(
			'access',
			__( 'Registration & consent', 'educore-workspace' ),
			$F::field_select( 'educore_registration', __( 'Self-registration', 'educore-workspace' ), array( 'closed' => __( 'Closed — accounts are created by the school', 'educore-workspace' ), 'open' => __( 'Open — anyone can create an account', 'educore-workspace' ) ), $v['educore_registration'] )
			. ( $open ? '' : $check( 'confirm_open', __( 'I confirm that self-registration may be opened (the privacy policy and terms are published).', 'educore-workspace' ), false ) )
			. $F::field_text( 'educore_consent_version', __( 'Consent text version', 'educore-workspace' ), $v['educore_consent_version'], true )
			. '<p class="ec-muted">' . esc_html__( 'Raise only when the privacy policy or terms change materially. Every new consent records this version.', 'educore-workspace' ) . '</p>'
			. $check( 'confirm_consent', __( 'I confirm that the updated policy for a new consent version is published.', 'educore-workspace' ), false )
			. $check( 'educore_admin_created_is_consented', __( 'Treat accounts created by staff as consented', 'educore-workspace' ), $v['educore_admin_created_is_consented'], __( 'Only when consent was collected offline, for example by the school.', 'educore-workspace' ) ),
			__( 'Changes here affect who can join and the consent evidence that is recorded. Each change is written to the audit log.', 'educore-workspace' )
		);
		$o .= $form(
			'engagement',
			__( 'Engagement', 'educore-workspace' ),
			'<div class="ec-ws-grid">' . $F::field_select( 'educore_gamification', __( 'Gamification', 'educore-workspace' ), array( 'on' => __( 'On (XP, badges, weekly goal)', 'educore-workspace' ), 'off' => __( 'Off', 'educore-workspace' ) ), $v['educore_gamification'] ) . $F::field_select( 'educore_leaderboards', __( 'Leaderboards', 'educore-workspace' ), array( 'off' => __( 'Off (default)', 'educore-workspace' ), 'on' => __( 'On — adult learners who opt in only', 'educore-workspace' ) ), $v['educore_leaderboards'] ) . '</div>'
		);
		$b     = $v['educore_brand'];
		$slots = array( 'logo' => __( 'Logo for light backgrounds', 'educore-workspace' ), 'logo_dark' => __( 'Logo for dark backgrounds', 'educore-workspace' ), 'mark' => __( 'Icon', 'educore-workspace' ), 'mark_dark' => __( 'Icon for dark backgrounds', 'educore-workspace' ) );
		$bb    = '<div class="ec-ws-grid">' . $F::field_text( 'brand_name', __( 'Platform name', 'educore-workspace' ), (string) $b['name'] ) . $F::field_text( 'brand_tagline', __( 'Tagline', 'educore-workspace' ), (string) $b['tagline'] ) . '</div>' . $F::field_text( 'brand_initiative', __( 'Initiative line', 'educore-workspace' ), (string) $b['initiative'] ) . '<div class="ec-ws-grid">';
		foreach ( $slots as $slot => $label ) {
			$id  = (int) $b[ $slot ];
			$bb .= '<div class="ec-ws-field"><span class="ec-ws-label">' . esc_html( $label ) . '</span><div class="ec-studio-cover" data-ec-media data-ec-media-title="' . esc_attr( $label ) . '"><input type="hidden" name="brand_' . esc_attr( $slot ) . '" value="' . $id . '"><span class="ec-studio-cover__preview' . ( false !== strpos( $slot, 'dark' ) ? ' ec-brand-dark' : '' ) . '"><img src="' . esc_url( \EduCore\Core\Branding::url( $slot ) ) . '" alt=""></span><button type="button" class="ec-btn" data-ec-media-pick>' . esc_html__( 'Choose image', 'educore-workspace' ) . '</button> <button type="button" class="ec-btn" data-ec-media-clear' . ( $id ? '' : ' hidden' ) . '>' . esc_html__( 'Use the official file', 'educore-workspace' ) . '</button></div></div>';
		}
		$o .= $form( 'branding', __( 'Branding', 'educore-workspace' ), $bb . '</div>', __( 'Leave a field empty to use the official EduCore identity. Uploaded logos replace the official files everywhere (header, sign-in, e-mails, certificates).', 'educore-workspace' ) );
		$t  = Settings::technical();
		$yn = static fn( bool $x ) => $x ? __( 'Yes', 'educore-workspace' ) : __( 'No', 'educore-workspace' );
		$o .= '<section class="ec-card ec-ws-section" aria-labelledby="ec-set-technical"><h2 id="ec-set-technical">' . esc_html__( 'Technical (read-only)', 'educore-workspace' ) . '</h2><p class="ec-muted">' . esc_html__( 'Releases, package installation, e-mail server credentials and uninstall behaviour are changed in WordPress by technical administrators.', 'educore-workspace' ) . '</p><dl class="ec-ws-kv">';
		$o .= '<dt>' . esc_html__( 'Release channel', 'educore-workspace' ) . '</dt><dd>' . esc_html( $t['channel'] ?: __( 'Not configured', 'educore-workspace' ) ) . '</dd>';
		$o .= '<dt>' . esc_html__( 'Last release check', 'educore-workspace' ) . '</dt><dd>' . esc_html( trim( $t['check_state'] . ' — ' . $t['check_msg'] . ( $t['checked_at'] ? ' (' . get_date_from_gmt( $t['checked_at'], get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) . ')' : '' ), ' —' ) ?: '—' ) . '</dd>';
		$o .= '<dt>' . esc_html__( 'Automatic maintenance updates', 'educore-workspace' ) . '</dt><dd>' . esc_html( $yn( $t['auto_update'] ) ) . '</dd>';
		$o .= '<dt>' . esc_html__( 'Own e-mail server (SMTP)', 'educore-workspace' ) . '</dt><dd>' . esc_html( $yn( $t['smtp'] ) ) . '</dd>';
		if ( null !== $t['mail_failed'] ) {
			$o .= '<dt>' . esc_html__( 'E-mail failures (7 days)', 'educore-workspace' ) . '</dt><dd>' . esc_html( number_format_i18n( $t['mail_failed'] ) ) . '</dd>';
		}
		$o .= '<dt>' . esc_html__( 'Delete data on uninstall', 'educore-workspace' ) . '</dt><dd>' . esc_html( $yn( $t['uninstall'] ) ) . '</dd></dl>';
		if ( current_user_can( 'manage_options' ) ) {
			$o .= '<p class="ec-ws-actions"><a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-settings' ) ) . '">' . esc_html__( 'Open technical settings (WordPress)', 'educore-workspace' ) . '</a> <a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-notifications' ) ) . '">' . esc_html__( 'E-mail delivery (WordPress)', 'educore-workspace' ) . '</a></p>';
		}
		return $o . '</section>';
	}

	private static function view_search( int $uid ): string {
		$term = self::q( 'q' );
		Shell::title( __( 'Search', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), self::url() ), array( __( 'Search', 'educore-workspace' ) ) ) );
		if ( '' === $term ) {
			return '<p class="ec-muted">' . esc_html__( 'Type a name, e-mail address or course title in the search box.', 'educore-workspace' ) . '</p>';
		}
		$o = '';
		if ( People::can_manage( $uid ) ) {
			$res = People::search( $uid, array( 'q' => $term ) );
			$o  .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'People', 'educore-workspace' ) . '</h2>' . ( $res['rows'] ? '<ul class="ec-ws-list">' . implode( '', array_map( fn( $p ) => '<li><a href="' . esc_url( self::url( array( 'v' => 'person', 'id' => $p['id'] ) ) ) . '">' . esc_html( $p['name'] ) . '</a><span class="ec-muted">' . esc_html( $p['email'] ) . '</span></li>', $res['rows'] ) ) . '</ul>' : '<p class="ec-muted">' . esc_html__( 'No people found.', 'educore-workspace' ) . '</p>' ) . '</section>';
		}
		$cs = get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'private' ), 's' => $term, 'numberposts' => 30 ) );
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Courses', 'educore-workspace' ) . '</h2>' . ( $cs ? '<ul class="ec-ws-list">' . implode( '', array_map( fn( $c ) => '<li><a href="' . esc_url( self::url( array( 'v' => 'course', 'id' => $c->ID ) ) ) . '">' . esc_html( get_the_title( $c ) ) . '</a></li>', $cs ) ) . '</ul>' : '<p class="ec-muted">' . esc_html__( 'No courses found.', 'educore-workspace' ) . '</p>' ) . '</section>';
		return $o;
	}
}
