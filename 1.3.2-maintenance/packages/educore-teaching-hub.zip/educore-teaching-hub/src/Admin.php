<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** wp-admin → EduCore → Teaching: responsibilities, classes, tutor approvals, safeguarding, settings, health. */
final class Admin {
	public const SLUG = 'educore-teaching';

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 20 );
		add_action( 'admin_init', array( self::class, 'handle' ) );
		add_filter( 'educore/install/checks', array( self::class, 'checks' ) );
	}

	public static function menu(): void {
		$cap = current_user_can( 'ec_manage_teaching' ) ? 'ec_manage_teaching' : ( current_user_can( 'ec_review_reports' ) ? 'ec_review_reports' : 'ec_approve_tutors' );
		add_submenu_page( 'educore', __( 'Teaching Management Center', 'educore-teaching-hub' ), __( 'Teaching', 'educore-teaching-hub' ), $cap, self::SLUG, array( self::class, 'page' ) );
	}

	private static function tabs(): array {
		$t = array();
		if ( current_user_can( 'ec_manage_teaching' ) ) {
			$t += array( 'overview' => __( 'Overview', 'educore-teaching-hub' ), 'people' => __( 'Responsibilities', 'educore-teaching-hub' ), 'classes' => __( 'Classes', 'educore-teaching-hub' ) );
		}
		if ( current_user_can( 'ec_approve_tutors' ) ) {
			$t['tutors'] = __( 'Tutor approvals', 'educore-teaching-hub' );
		}
		if ( current_user_can( 'ec_review_reports' ) ) {
			$t['safeguarding'] = __( 'Safeguarding', 'educore-teaching-hub' );
		}
		if ( current_user_can( 'ec_manage_teaching' ) ) {
			$t['settings'] = __( 'Settings', 'educore-teaching-hub' );
		}
		return $t;
	}

	private static function form( string $action, string $inner, array $hidden = array() ): string {
		$h = '<form method="post">' . wp_nonce_field( 'ec_th_admin_' . $action, '_ecthadmin', true, false ) . '<input type="hidden" name="ec_th_admin" value="' . esc_attr( $action ) . '">';
		foreach ( $hidden as $k => $v ) {
			$h .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( (string) $v ) . '">';
		}
		return $h . $inner . '</form>';
	}

	public static function page(): void {
		$tabs = self::tabs();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : (string) array_key_first( $tabs );
		if ( ! isset( $tabs[ $tab ] ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'educore-teaching-hub' ), 403 );
		}
		echo '<div class="wrap ec-admin"><h1>' . esc_html__( 'Teaching Management Center', 'educore-teaching-hub' ) . '</h1><nav class="nav-tab-wrapper">';
		foreach ( $tabs as $k => $label ) {
			echo '<a class="nav-tab' . ( $k === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . $k ) ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ok'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Saved.', 'educore-teaching-hub' ) . '</p></div>';
		}
		if ( isset( $_GET['err'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['err'] ) ) ) . '</p></div>';
		}
		// phpcs:enable
		$m = 'tab_' . $tab;
		self::$m();
		echo '</div>';
	}

	private static function tab_overview(): void {
		global $wpdb;
		$q  = static fn( string $sql ) => (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
		$rows = array(
			__( 'Active classes', 'educore-teaching-hub' )              => $q( 'SELECT COUNT(*) FROM ' . Schema::table( 'th_classes' ) . " WHERE status='active'" ),
			__( 'Students in classes', 'educore-teaching-hub' )         => $q( 'SELECT COUNT(DISTINCT student_id) FROM ' . Schema::table( 'th_class_members' ) . " WHERE status='active'" ),
			__( 'Teachers assigned', 'educore-teaching-hub' )           => $q( 'SELECT COUNT(DISTINCT user_id) FROM ' . Schema::table( 'th_class_staff' ) ),
			__( 'Submissions waiting for grading', 'educore-teaching-hub' ) => $q( 'SELECT COUNT(*) FROM ' . Schema::table( 'th_submissions' ) . " WHERE status='submitted'" ),
			__( 'Graded results not yet released', 'educore-teaching-hub' ) => $q( 'SELECT COUNT(*) FROM ' . Schema::table( 'th_submissions' ) . " WHERE status='graded' AND released=0" ),
			__( 'Tutor profiles awaiting approval', 'educore-teaching-hub' ) => $q( 'SELECT COUNT(*) FROM ' . Schema::table( 'th_tutor_profiles' ) . " WHERE status='pending'" ),
			__( 'Tutoring requests awaiting a decision', 'educore-teaching-hub' ) => $q( 'SELECT COUNT(*) FROM ' . Schema::table( 'th_sessions' ) . " WHERE status='requested'" ),
			__( 'Open safeguarding reports', 'educore-teaching-hub' )   => $q( 'SELECT COUNT(*) FROM ' . Schema::table( 'th_reports' ) . " WHERE status<>'closed'" ),
		);
		echo '<table class="widefat striped" style="max-width:640px"><tbody>';
		foreach ( $rows as $l => $v ) {
			echo '<tr><th>' . esc_html( $l ) . '</th><td>' . esc_html( number_format_i18n( $v ) ) . '</td></tr>';
		}
		echo '</tbody></table><h2>' . esc_html__( 'Grading backlog by teacher', 'educore-teaching-hub' ) . '</h2><table class="widefat striped" style="max-width:640px"><thead><tr><th>' . esc_html__( 'Teacher', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Waiting', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Oldest', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>';
		$back = $wpdb->get_results( 'SELECT cs.user_id, COUNT(*) n, MIN(s.submitted_at) oldest FROM ' . Schema::table( 'th_submissions' ) . ' s JOIN ' . Schema::table( 'th_assignments' ) . ' a ON a.id=s.assignment_id JOIN ' . Schema::table( 'th_class_staff' ) . " cs ON cs.class_id=a.class_id WHERE s.status='submitted' GROUP BY cs.user_id ORDER BY oldest ASC LIMIT 50", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $back as $b ) {
			echo '<tr><td>' . esc_html( ( get_userdata( (int) $b['user_id'] ) ?: new \WP_User() )->display_name ) . '</td><td>' . esc_html( $b['n'] ) . '</td><td>' . esc_html( Plugin::local( $b['oldest'] ) ) . '</td></tr>';
		}
		echo '</tbody></table><p><a class="button" href="' . esc_url( Portal::url( 'analytics' ) ) . '">' . esc_html__( 'Teaching analytics & export', 'educore-teaching-hub' ) . '</a></p>';
	}

	private static function tab_people(): void {
		echo '<p>' . esc_html__( 'One account can hold several responsibilities. Changes are recorded in the audit log.', 'educore-teaching-hub' ) . '</p>';
		echo self::form( 'responsibility', '<table class="form-table"><tr><th>' . esc_html__( 'User (e-mail or username)', 'educore-teaching-hub' ) . '</th><td><input class="regular-text" name="user" required></td></tr><tr><th>' . esc_html__( 'Responsibility', 'educore-teaching-hub' ) . '</th><td><select name="what"><option value="teacher">' . esc_html__( 'Teacher', 'educore-teaching-hub' ) . '</option><option value="instructor">' . esc_html__( 'Instructor', 'educore-teaching-hub' ) . '</option><option value="tutor">' . esc_html__( 'Tutor', 'educore-teaching-hub' ) . '</option></select> <select name="on"><option value="1">' . esc_html__( 'Grant', 'educore-teaching-hub' ) . '</option><option value="0">' . esc_html__( 'Revoke', 'educore-teaching-hub' ) . '</option></select></td></tr></table><p><button class="button button-primary">' . esc_html__( 'Apply', 'educore-teaching-hub' ) . '</button></p>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts.
		$users = get_users( array( 'role__in' => array( 'ec_teacher', 'ec_tutor', 'ec_instructor' ), 'number' => 300, 'orderby' => 'display_name' ) );
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Name', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Responsibilities', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Tutor profile', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>';
		foreach ( $users as $u ) {
			$p = Tutoring::profile( (int) $u->ID );
			echo '<tr><td>' . esc_html( $u->display_name ) . ' <span class="description">' . esc_html( $u->user_login ) . '</span></td><td>' . esc_html( implode( ', ', Caps::responsibilities( (int) $u->ID ) ) ) . '</td><td>' . esc_html( $p['status'] ?? '—' ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function tab_classes(): void {
		global $wpdb;
		$courses = get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending' ), 'numberposts' => 300, 'orderby' => 'title', 'order' => 'ASC' ) );
		$copts   = '<option value="0">—</option>';
		foreach ( $courses as $c ) {
			$copts .= '<option value="' . esc_attr( (string) $c->ID ) . '">' . esc_html( $c->post_title ) . '</option>';
		}
		echo '<h2>' . esc_html__( 'Create a class', 'educore-teaching-hub' ) . '</h2>';
		echo self::form( 'create_class', '<table class="form-table"><tr><th>' . esc_html__( 'Name', 'educore-teaching-hub' ) . '</th><td><input class="regular-text" name="name" required></td></tr><tr><th>' . esc_html__( 'Code', 'educore-teaching-hub' ) . '</th><td><input name="code"></td></tr><tr><th>' . esc_html__( 'Academic year', 'educore-teaching-hub' ) . '</th><td><input name="academic_year" placeholder="2026/2027"></td></tr><tr><th>' . esc_html__( 'Course', 'educore-teaching-hub' ) . '</th><td><select name="course_id">' . $copts . '</select></td></tr><tr><th>' . esc_html__( 'Schedule', 'educore-teaching-hub' ) . '</th><td><input class="regular-text" name="schedule" placeholder="Sun & Tue 10:00–11:30"></td></tr><tr><th>' . esc_html__( 'Lead teacher (e-mail or username)', 'educore-teaching-hub' ) . '</th><td><input class="regular-text" name="lead"></td></tr></table><p><button class="button button-primary">' . esc_html__( 'Create class', 'educore-teaching-hub' ) . '</button></p>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$rows = $wpdb->get_results( 'SELECT * FROM ' . Schema::table( 'th_classes' ) . ' ORDER BY status, name LIMIT 300', ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		$cnt  = Classes::member_counts( array_map( 'intval', wp_list_pluck( $rows, 'id' ) ) );
		echo '<h2>' . esc_html__( 'Classes', 'educore-teaching-hub' ) . '</h2><table class="widefat striped"><thead><tr><th>' . esc_html__( 'Class', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Staff', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Students', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Actions', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $c ) {
			$staff = array_map( static fn( $s ) => ( get_userdata( $s['user_id'] ) ?: new \WP_User() )->display_name . ' (' . $s['staff_role'] . ')', Classes::staff( (int) $c['id'] ) );
			echo '<tr><td><strong>' . esc_html( $c['name'] ) . '</strong> <span class="description">' . esc_html( $c['status'] . ' · ' . $c['academic_year'] . ( $c['course_id'] ? ' · ' . get_the_title( (int) $c['course_id'] ) : '' ) ) . '</span></td><td>' . esc_html( implode( ', ', $staff ) ) . '</td><td>' . esc_html( (string) ( $cnt[ (int) $c['id'] ] ?? 0 ) ) . '</td><td>';
			echo self::form( 'class_staff', '<input name="user" placeholder="' . esc_attr__( 'e-mail or username', 'educore-teaching-hub' ) . '" required> <select name="role"><option value="teacher">teacher</option><option value="lead">lead</option><option value="assistant">assistant</option><option value="remove">' . esc_html__( 'remove', 'educore-teaching-hub' ) . '</option></select> <button class="button">' . esc_html__( 'Staff', 'educore-teaching-hub' ) . '</button>', array( 'class_id' => $c['id'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo self::form( 'class_enrol', '<textarea name="students" rows="2" cols="30" placeholder="' . esc_attr__( 'Student e-mails/usernames, one per line', 'educore-teaching-hub' ) . '"></textarea> <button class="button">' . esc_html__( 'Enrol', 'educore-teaching-hub' ) . '</button>', array( 'class_id' => $c['id'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo self::form( 'class_status', '<button class="button-link">' . esc_html( 'active' === $c['status'] ? __( 'Archive', 'educore-teaching-hub' ) : __( 'Reactivate', 'educore-teaching-hub' ) ) . '</button>', array( 'class_id' => $c['id'], 'status' => 'active' === $c['status'] ? 'archived' : 'active' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function tab_tutors(): void {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT p.*, u.display_name, u.user_email FROM ' . Schema::table( 'th_tutor_profiles' ) . ' p JOIN ' . $wpdb->users . " u ON u.ID=p.user_id ORDER BY p.status='pending' DESC, p.updated_at DESC LIMIT 200", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		echo '<p>' . esc_html__( 'Verify qualifications before approving. Only approved profiles marked public appear in the tutor directory.', 'educore-teaching-hub' ) . '</p><table class="widefat striped"><thead><tr><th>' . esc_html__( 'Tutor', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Profile', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Status', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Decision', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $p ) {
			echo '<tr><td>' . esc_html( $p['display_name'] ) . '<br><span class="description">' . esc_html( $p['user_email'] ) . '</span></td><td><strong>' . esc_html( $p['headline'] ) . '</strong><br>' . esc_html( $p['subjects'] ) . '<br>' . esc_html( wp_trim_words( (string) $p['bio'], 30 ) ) . '<br><em>' . esc_html( (string) $p['qualifications'] ) . '</em></td><td>' . esc_html( $p['status'] . ( (int) $p['is_public'] ? ' · public' : '' ) ) . '</td><td>';
			echo self::form( 'tutor_review', '<select name="decision"><option value="approved">' . esc_html__( 'Approve', 'educore-teaching-hub' ) . '</option><option value="rejected">' . esc_html__( 'Request changes', 'educore-teaching-hub' ) . '</option><option value="suspended">' . esc_html__( 'Suspend', 'educore-teaching-hub' ) . '</option></select> <input name="note" placeholder="' . esc_attr__( 'Note to tutor', 'educore-teaching-hub' ) . '"> <button class="button">' . esc_html__( 'Save', 'educore-teaching-hub' ) . '</button>', array( 'user_id' => $p['user_id'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function tab_safeguarding(): void {
		$uid = get_current_user_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$thread = isset( $_GET['thread'] ) ? absint( $_GET['thread'] ) : 0;
		if ( $thread && ( $t = Comms::thread( $thread ) ) ) {
			echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=safeguarding' ) ) . '">← ' . esc_html__( 'All reports', 'educore-teaching-hub' ) . '</a></p><h2>' . esc_html( $t['subject'] ) . '</h2><p class="description">' . esc_html( $t['context_type'] . ' #' . $t['context_id'] . ' · ' . __( 'Your access is recorded in the audit log.', 'educore-teaching-hub' ) ) . '</p><ol>';
			foreach ( Comms::messages( $thread, $uid ) as $m ) {
				echo '<li' . ( (int) $m['hidden'] ? ' style="opacity:.6"' : '' ) . '><strong>' . esc_html( ( get_userdata( (int) $m['author_id'] ) ?: new \WP_User() )->display_name ) . '</strong> · ' . esc_html( Plugin::local( $m['created_at'] ) . ' · #' . $m['id'] . ( (int) $m['hidden'] ? ' · hidden' : '' ) ) . '<br>' . nl2br( esc_html( $m['body'] ) ) . '</li>';
			}
			echo '</ol>';
			return;
		}
		echo '<p>' . esc_html__( 'Concerns reported by learners, guardians or staff. Handle according to your safeguarding policy; hidden messages are kept for investigation.', 'educore-teaching-hub' ) . '</p><table class="widefat striped"><thead><tr><th>#</th><th>' . esc_html__( 'Reported', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Reason', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Status', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Review', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>';
		foreach ( Comms::reports() as $r ) {
			echo '<tr><td>' . esc_html( $r['id'] ) . '</td><td>' . esc_html( Plugin::local( $r['created_at'] ) ) . '<br>' . esc_html( ( get_userdata( (int) $r['reporter_id'] ) ?: new \WP_User() )->display_name ) . '<br><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=safeguarding&thread=' . (int) $r['thread_id'] ) ) . '">' . esc_html__( 'Open conversation', 'educore-teaching-hub' ) . '</a></td><td>' . nl2br( esc_html( $r['reason'] ) ) . ( $r['resolution'] ? '<br><em>' . esc_html( $r['resolution'] ) . '</em>' : '' ) . '</td><td>' . esc_html( $r['status'] ) . '</td><td>';
			echo self::form( 'report_review', '<select name="status"><option value="reviewing">' . esc_html__( 'Reviewing', 'educore-teaching-hub' ) . '</option><option value="closed">' . esc_html__( 'Closed', 'educore-teaching-hub' ) . '</option><option value="open">' . esc_html__( 'Open', 'educore-teaching-hub' ) . '</option></select> <select name="hide"><option value="-1">' . esc_html__( 'Message: no change', 'educore-teaching-hub' ) . '</option><option value="1">' . esc_html__( 'Hide message', 'educore-teaching-hub' ) . '</option><option value="0">' . esc_html__( 'Unhide message', 'educore-teaching-hub' ) . '</option></select> <select name="thread_status"><option value="">' . esc_html__( 'Conversation: no change', 'educore-teaching-hub' ) . '</option><option value="closed">' . esc_html__( 'Close conversation', 'educore-teaching-hub' ) . '</option><option value="open">' . esc_html__( 'Reopen', 'educore-teaching-hub' ) . '</option></select><br><textarea name="resolution" rows="2" cols="40" placeholder="' . esc_attr__( 'Notes / resolution', 'educore-teaching-hub' ) . '"></textarea> <button class="button">' . esc_html__( 'Save', 'educore-teaching-hub' ) . '</button>', array( 'report_id' => $r['id'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function tab_settings(): void {
		$s      = Settings::all();
		$labels = array(
			'file_types'               => __( 'Allowed file types (subset of pdf, docx, pptx, xlsx, odt, txt, png, jpg, jpeg)', 'educore-teaching-hub' ),
			'max_file_mb'              => __( 'Maximum file size (MB)', 'educore-teaching-hub' ),
			'max_files'                => __( 'Files per submission', 'educore-teaching-hub' ),
			'meeting_hosts'            => __( 'Approved conferencing hosts', 'educore-teaching-hub' ),
			'guardian_visibility'      => __( 'Guardians can read conversations of learners under 18', 'educore-teaching-hub' ),
			'staff_start_minor_thread' => __( 'Staff may open individual conversations with learners under 18', 'educore-teaching-hub' ),
			'minor_tutoring_guardian'  => __( 'Tutoring for learners under 18 requires guardian authorisation', 'educore-teaching-hub' ),
			'slot_minutes'             => __( 'Booking grid (minutes: 5, 10, 15 or 30)', 'educore-teaching-hub' ),
			'max_booking_days'         => __( 'Students can book up to (days ahead)', 'educore-teaching-hub' ),
			'alert_missing'            => __( 'Alert: missing assignments ≥', 'educore-teaching-hub' ),
			'alert_low_score_pct'      => __( 'Alert: average assignment score below (%)', 'educore-teaching-hub' ),
			'alert_decline_pct'        => __( 'Alert: score decline of at least (points)', 'educore-teaching-hub' ),
			'alert_inactive_days'      => __( 'Alert: no learning activity for (days; 0 = off)', 'educore-teaching-hub' ),
			'alert_absences'           => __( 'Alert: absences in 30 days ≥', 'educore-teaching-hub' ),
			'alert_failed_assessments' => __( 'Alert: failed assessment attempts ≥', 'educore-teaching-hub' ),
		);
		$rows = '';
		foreach ( $labels as $k => $l ) {
			$v     = $s[ $k ];
			$ctl   = in_array( $v, array( 'on', 'off' ), true ) ? '<select name="s[' . esc_attr( $k ) . ']"><option value="on"' . selected( $v, 'on', false ) . '>' . esc_html__( 'On', 'educore-teaching-hub' ) . '</option><option value="off"' . selected( $v, 'off', false ) . '>' . esc_html__( 'Off', 'educore-teaching-hub' ) . '</option></select>' : '<input class="regular-text" name="s[' . esc_attr( $k ) . ']" value="' . esc_attr( (string) $v ) . '">';
			$rows .= '<tr><th>' . esc_html( $l ) . '</th><td>' . $ctl . '</td></tr>';
		}
		echo self::form( 'settings', '<table class="form-table">' . $rows . '</table><p><button class="button button-primary">' . esc_html__( 'Save settings', 'educore-teaching-hub' ) . '</button></p>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function user_from( string $who ): ?\WP_User {
		$who = trim( $who );
		$u   = is_email( $who ) ? get_user_by( 'email', $who ) : get_user_by( 'login', $who );
		return $u ?: null;
	}

	public static function handle(): void {
		if ( empty( $_POST['ec_th_admin'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['ec_th_admin'] ) );
		check_admin_referer( 'ec_th_admin_' . $action, '_ecthadmin' );
		$in    = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitised per field.
		$uid   = get_current_user_id();
		$need  = array( 'tutor_review' => 'ec_approve_tutors', 'report_review' => 'ec_review_reports' );
		if ( ! current_user_can( $need[ $action ] ?? 'ec_manage_teaching' ) ) {
			wp_die( '', 403 );
		}
		$err = '';
		switch ( $action ) {
			case 'responsibility':
				$u = self::user_from( (string) $in['user'] );
				if ( ! $u ) {
					$err = __( 'User not found.', 'educore-teaching-hub' );
					break;
				}
				$what = sanitize_key( (string) $in['what'] );
				$on   = '1' === (string) $in['on'];
				Caps::set_responsibility( (int) $u->ID, $what, $on );
				Audit::log( 'teaching.responsibility_' . ( $on ? 'granted' : 'revoked' ), 'user', (int) $u->ID, array( 'what' => $what ) );
				break;
			case 'create_class':
				$id = Classes::create( $in, $uid );
				if ( is_wp_error( $id ) ) {
					$err = $id->get_error_message();
					break;
				}
				if ( ! empty( $in['lead'] ) ) {
					$u = self::user_from( (string) $in['lead'] );
					if ( $u ) {
						Caps::set_responsibility( (int) $u->ID, 'teacher', true );
						Classes::assign_staff( $id, (int) $u->ID, 'lead' );
					} else {
						$err = __( 'Class created, but the lead teacher was not found.', 'educore-teaching-hub' );
					}
				}
				break;
			case 'class_staff':
				$u = self::user_from( (string) $in['user'] );
				if ( ! $u ) {
					$err = __( 'User not found.', 'educore-teaching-hub' );
					break;
				}
				if ( 'remove' === $in['role'] ) {
					Classes::remove_staff( absint( $in['class_id'] ), (int) $u->ID );
				} else {
					Caps::set_responsibility( (int) $u->ID, 'teacher', true );
					Classes::assign_staff( absint( $in['class_id'] ), (int) $u->ID, sanitize_key( (string) $in['role'] ) );
				}
				break;
			case 'class_enrol':
				$fails = array();
				foreach ( preg_split( '/[\r\n,;]+/', (string) $in['students'] ) as $who ) {
					if ( '' === trim( $who ) ) {
						continue;
					}
					$u   = self::user_from( $who );
					$res = $u ? Classes::add_member( absint( $in['class_id'] ), (int) $u->ID, $uid ) : new \WP_Error( 'x', '' );
					if ( is_wp_error( $res ) ) {
						$fails[] = sanitize_text_field( $who );
					}
				}
				/* translators: %s: list */
				$err = $fails ? sprintf( __( 'Not enrolled (unknown or not a student): %s', 'educore-teaching-hub' ), implode( ', ', $fails ) ) : '';
				break;
			case 'class_status':
				Classes::set_status( absint( $in['class_id'] ), sanitize_key( (string) $in['status'] ) );
				break;
			case 'tutor_review':
				Tutoring::review( absint( $in['user_id'] ), sanitize_key( (string) $in['decision'] ), $uid, (string) ( $in['note'] ?? '' ) );
				break;
			case 'report_review':
				Comms::review( absint( $in['report_id'] ), $uid, sanitize_key( (string) $in['status'] ), (string) ( $in['resolution'] ?? '' ), (int) $in['hide'], sanitize_key( (string) ( $in['thread_status'] ?? '' ) ) );
				break;
			case 'settings':
				Settings::save( (array) ( $in['s'] ?? array() ) );
				Audit::log( 'teaching.settings_saved', 'settings', 0 );
				break;
		}
		$ref = remove_query_arg( array( 'ok', 'err' ), wp_validate_redirect( (string) wp_get_raw_referer(), admin_url( 'admin.php?page=' . self::SLUG ) ) );
		wp_safe_redirect( add_query_arg( $err ? array( 'err' => rawurlencode( $err ) ) : array( 'ok' => 1 ), $ref ) );
		exit;
	}

	/** Module health in EduCore → Setup checks. */
	public static function checks( array $checks ): array {
		$dir      = Files::dir();
		$checks[] = array( 'label' => 'Teaching Hub tables', 'status' => empty( Schema::missing_tables( Plugin::tables() ) ) ? 'pass' : 'fail', 'message' => __( 'Teaching Hub database tables.', 'educore-teaching-hub' ) );
		$checks[] = array( 'label' => 'Teaching Hub files', 'status' => is_dir( $dir ) && file_exists( $dir . '/.htaccess' ) ? 'pass' : 'warn', 'message' => __( 'Private assignment file store exists and denies web access (Apache/LiteSpeed). On nginx, add a deny rule for uploads/educore-teaching-hub/.', 'educore-teaching-hub' ) );
		$checks[] = array( 'label' => 'Teaching Hub page', 'status' => Pages::id( 'teaching-hub' ) ? 'pass' : 'warn', 'message' => __( 'The /teaching-hub/ page exists.', 'educore-teaching-hub' ) );
		return $checks;
	}
}
