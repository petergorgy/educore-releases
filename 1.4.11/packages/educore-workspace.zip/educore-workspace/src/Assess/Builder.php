<?php
namespace EduCore\Workspace\Assess;

use EduCore\Assessments\Assessments;
use EduCore\Assessments\Attempts;
use EduCore\Assessments\Questions;
use EduCore\Assessments\Types;
use EduCore\Core\Content;
use EduCore\Core\Staff;
use EduCore\Workspace\Studio\Courses;

defined( 'ABSPATH' ) || exit;

/**
 * Assessment Builder service. Same authority as wp-admin: `ec_manage_assessments` AND `ec_edit_course`;
 * publishing needs `ec_publish_courses` or the lead-instructor role on the course. In addition the builder
 * refuses to publish an assessment whose pools cannot be filled from the published bank (the learner would
 * otherwise meet a "not enough questions" error).
 */
final class Builder {
	public const SETTINGS = array( 'duration', 'attempts', 'shuffle_questions', 'shuffle_options', 'feedback', 'release', 'pass_mark', 'total_mark', 'opens_at', 'closes_at', 'instructions' );
	public const MAX_POOLS = 30;

	public static function available(): bool {
		return class_exists( Assessments::class ) && class_exists( Attempts::class );
	}

	public static function can( int $uid, int $course_id ): bool {
		return $uid > 0 && self::available() && Content::is_course( $course_id ) && user_can( $uid, 'ec_manage_assessments' ) && user_can( $uid, 'ec_edit_course', $course_id );
	}

	public static function can_any( int $uid ): bool {
		return $uid > 0 && self::available() && user_can( $uid, 'ec_manage_assessments' );
	}

	public static function can_publish( int $uid, int $course_id ): bool {
		return self::can( $uid, $course_id ) && ( user_can( $uid, 'ec_publish_courses' ) || Staff::has_role( $uid, $course_id, array( 'lead' ) ) );
	}

	/** @return \WP_Post[] */
	public static function courses( int $uid ): array {
		if ( ! self::can_any( $uid ) ) {
			return array();
		}
		return array_values( array_filter( Courses::mine( $uid ), static fn( $c ) => self::can( $uid, (int) $c->ID ) ) );
	}

	private static function deny(): \WP_Error {
		return new \WP_Error( 'ec_assess_forbidden', __( 'You cannot manage the assessments of this course.', 'educore-workspace' ), array( 'status' => 403 ) );
	}

	public static function get( int $uid, int $course_id, int $id ): ?array {
		if ( ! self::can( $uid, $course_id ) ) {
			return null;
		}
		$a = Assessments::get( $id );
		return ( $a && (int) $a['course_id'] === $course_id ) ? $a : null;
	}

	public static function list( int $uid, int $course_id ): array {
		return self::can( $uid, $course_id ) ? Assessments::for_course( $course_id, Assessments::STATUSES ) : array();
	}

	/**
	 * Pools from parallel form arrays (pool_qtype[], pool_lesson[], …). Rows referring to a lesson or a question
	 * outside the course are rejected rather than silently dropped.
	 *
	 * @return array|\WP_Error
	 */
	public static function pools_from( int $course_id, array $in ) {
		$col   = static fn( $k ) => array_values( (array) ( $in[ $k ] ?? array() ) );
		$types = $col( 'pool_qtype' );
		$less  = $col( 'pool_lesson' );
		$tags  = $col( 'pool_tag' );
		$diff  = $col( 'pool_difficulty' );
		$cnt   = $col( 'pool_count' );
		$pts   = $col( 'pool_points' );
		$qid   = $col( 'pool_question' );
		$n     = max( count( $types ), count( $cnt ), count( $qid ) );
		if ( $n > self::MAX_POOLS ) {
			return new \WP_Error( 'ec_assess_pools', __( 'Too many question pools (maximum 30).', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		$out = array();
		for ( $i = 0; $i < $n; $i++ ) {
			$q      = absint( $qid[ $i ] ?? 0 );
			$count  = absint( $cnt[ $i ] ?? 0 );
			$lesson = absint( $less[ $i ] ?? 0 );
			if ( ! $q && ! $count ) {
				continue;
			}
			if ( $lesson && Content::course_of( $lesson ) !== $course_id ) {
				return new \WP_Error( 'ec_assess_pools', __( 'A pool refers to a lesson outside this course.', 'educore-workspace' ), array( 'status' => 400 ) );
			}
			if ( $q ) {
				$row = Questions::get( $q );
				if ( ! $row || (int) $row['course_id'] !== $course_id ) {
					/* translators: %d: question id */
					return new \WP_Error( 'ec_assess_pools', sprintf( __( 'Question #%d is not in this course’s bank.', 'educore-workspace' ), $q ), array( 'status' => 400 ) );
				}
			}
			$type  = (string) ( $types[ $i ] ?? '' );
			$level = (string) ( $diff[ $i ] ?? '' );
			$out[] = array(
				'question_id' => $q,
				'qtype'       => in_array( $type, Types::ALL, true ) ? $type : '',
				'lesson_id'   => $lesson,
				'tag'         => sanitize_title( (string) ( $tags[ $i ] ?? '' ) ),
				'difficulty'  => in_array( $level, Questions::DIFFICULTY, true ) ? $level : '',
				'draw_count'  => $q ? 1 : min( 200, $count ),
				'points_each' => max( 0, (float) ( $pts[ $i ] ?? 0 ) ),
			);
		}
		return $out;
	}

	/**
	 * Can every pool be filled from published questions? Uses the attempt engine itself, so the answer is exactly
	 * what a learner would get.
	 *
	 * @return array{ok:bool,message:string,count:int,points:float}
	 */
	public static function readiness( array $a ): array {
		$r = Attempts::select_questions( $a, 'readiness-' . (int) $a['id'] );
		if ( is_wp_error( $r ) ) {
			return array( 'ok' => false, 'message' => $r->get_error_message(), 'count' => 0, 'points' => 0.0 );
		}
		return array( 'ok' => true, 'message' => '', 'count' => count( $r ), 'points' => (float) array_sum( wp_list_pluck( $r, 'points' ) ) );
	}

	/** Sample draw for the author preview (question ids in order). */
	public static function sample( array $a ): array {
		$r = Attempts::select_questions( $a, 'preview-' . wp_generate_password( 6, false ) );
		return is_wp_error( $r ) ? array() : $r;
	}

	/** @return int|\WP_Error */
	public static function save( int $uid, int $course_id, int $id, array $in ) {
		if ( ! self::can( $uid, $course_id ) ) {
			return self::deny();
		}
		$existing = null;
		if ( $id ) {
			$existing = self::get( $uid, $course_id, $id );
			if ( ! $existing ) {
				return new \WP_Error( 'ec_assess_not_found', __( 'Assessment not found in this course.', 'educore-workspace' ), array( 'status' => 404 ) );
			}
		}
		$status = in_array( $in['status'] ?? '', Assessments::STATUSES, true ) ? (string) $in['status'] : ( $existing['status'] ?? 'draft' );
		if ( 'published' === $status && ! self::can_publish( $uid, $course_id ) ) {
			return new \WP_Error( 'ec_assess_publish', __( 'Only a lead instructor or academic manager can publish assessments.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$data = array(
			'course_id' => $course_id,
			'title'     => (string) ( $in['title'] ?? ( $existing['title'] ?? '' ) ),
			'kind'      => (string) ( $in['kind'] ?? ( $existing['kind'] ?? 'quiz' ) ),
			'lesson_id' => absint( $in['lesson_id'] ?? ( $existing['lesson_id'] ?? 0 ) ),
			'status'    => 'published' === $status ? ( $existing['status'] ?? 'draft' ) : $status,
		);
		if ( $data['lesson_id'] && Content::course_of( $data['lesson_id'] ) !== $course_id ) {
			return new \WP_Error( 'ec_assess_invalid', __( 'The lesson does not belong to this course.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'lesson_id' => 'invalid' ) ) );
		}
		$settings = array();
		foreach ( self::SETTINGS as $k ) {
			if ( array_key_exists( 's_' . $k, $in ) ) {
				$settings[ $k ] = in_array( $k, array( 'shuffle_questions', 'shuffle_options' ), true ) ? ! empty( $in[ 's_' . $k ] ) && 'false' !== $in[ 's_' . $k ] : $in[ 's_' . $k ];
			}
		}
		if ( $settings ) {
			$data['settings'] = $settings;
		}
		if ( isset( $settings['opens_at'], $settings['closes_at'] ) && '' !== $settings['opens_at'] && '' !== $settings['closes_at'] && Assessments::local_to_utc( (string) $settings['closes_at'] ) <= Assessments::local_to_utc( (string) $settings['opens_at'] ) ) {
			return new \WP_Error( 'ec_assess_invalid', __( 'The closing time must be after the opening time.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 's_closes_at' => 'invalid' ) ) );
		}
		if ( ! empty( $in['pools_present'] ) ) {
			$pools = self::pools_from( $course_id, $in );
			if ( is_wp_error( $pools ) ) {
				return $pools;
			}
			$data['pools'] = $pools;
		}
		$res = Assessments::save( $data, $id );
		if ( is_wp_error( $res ) || 'published' !== $status || 'published' === ( $existing['status'] ?? '' ) ) {
			return $res;
		}
		return self::publish( $uid, $course_id, (int) $res );
	}

	/** Publish after the readiness gate. @return int|\WP_Error */
	public static function publish( int $uid, int $course_id, int $id ) {
		$a = self::get( $uid, $course_id, $id );
		if ( ! $a ) {
			return self::deny();
		}
		if ( ! self::can_publish( $uid, $course_id ) ) {
			return new \WP_Error( 'ec_assess_publish', __( 'Only a lead instructor or academic manager can publish assessments.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$ready = self::readiness( $a );
		if ( ! $ready['ok'] ) {
			/* translators: %s: reason */
			return new \WP_Error( 'ec_assess_not_ready', sprintf( __( 'Saved as a draft but not published: %s', 'educore-workspace' ), $ready['message'] ), array( 'status' => 409 ) );
		}
		return Assessments::save( array( 'status' => 'published' ), $id );
	}

	/** @return true|\WP_Error */
	public static function set_status( int $uid, int $course_id, int $id, string $status ) {
		if ( 'published' === $status ) {
			$r = self::publish( $uid, $course_id, $id );
			return is_wp_error( $r ) ? $r : true;
		}
		if ( ! self::get( $uid, $course_id, $id ) || ! in_array( $status, Assessments::STATUSES, true ) ) {
			return self::deny();
		}
		$r = Assessments::save( array( 'status' => $status ), $id );
		return is_wp_error( $r ) ? $r : true;
	}

	/** Copy an assessment (settings and pools) as a draft. @return int|\WP_Error */
	public static function duplicate( int $uid, int $course_id, int $id ) {
		$a = self::get( $uid, $course_id, $id );
		if ( ! $a ) {
			return self::deny();
		}
		$pools = array_map( static fn( $p ) => array_intersect_key( $p, array_flip( array( 'question_id', 'qtype', 'lesson_id', 'tag', 'difficulty', 'draw_count', 'points_each' ) ) ), Assessments::pools( $id ) );
		/* translators: %s: assessment title */
		$title = sprintf( __( '%s (copy)', 'educore-workspace' ), $a['title'] );
		$s     = $a['settings'];
		foreach ( array( 'opens_at', 'closes_at' ) as $k ) {
			$s[ $k ] = '' === (string) $s[ $k ] ? '' : Assessments::to_iso( (string) $s[ $k ] );
		}
		return Assessments::save( array( 'course_id' => $course_id, 'title' => $title, 'kind' => $a['kind'], 'lesson_id' => (int) $a['lesson_id'], 'status' => 'draft', 'settings' => $s, 'pools' => $pools ) );
	}

	/** One-click chapter examination template (existing domain helper). @return int|\WP_Error */
	public static function template( int $uid, int $course_id, int $lesson_id ) {
		if ( ! self::can( $uid, $course_id ) ) {
			return self::deny();
		}
		if ( $lesson_id && Content::course_of( $lesson_id ) !== $course_id ) {
			return new \WP_Error( 'ec_assess_invalid', __( 'The lesson does not belong to this course.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		return Assessments::chapter_one_template( $course_id, $lesson_id );
	}
}
