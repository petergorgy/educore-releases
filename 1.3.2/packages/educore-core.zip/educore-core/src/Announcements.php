<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Course announcements (private CPT; shown to enrolled students; notifications may e-mail them). */
final class Announcements {
	public const TYPE = 'ec_announcement';

	public static function register(): void {
		add_action( 'init', array( self::class, 'register_type' ) );
		add_filter( 'educore/dashboard/student', array( self::class, 'dashboard' ), 10, 2 );
	}

	public static function register_type(): void {
		register_post_type( self::TYPE, array( 'public' => false, 'show_ui' => false, 'show_in_rest' => false, 'supports' => array( 'title', 'editor', 'author' ), 'label' => __( 'Announcements', 'educore-core' ) ) );
	}

	public static function publish( int $course_id, string $title, string $body ): int {
		if ( '' === $title || '' === $body || ! Content::is_course( $course_id ) ) {
			return 0;
		}
		$id = (int) wp_insert_post( array( 'post_type' => self::TYPE, 'post_status' => 'publish', 'post_title' => $title, 'post_content' => $body, 'post_parent' => $course_id ) );
		if ( $id ) {
			Audit::log( 'announcement.published', 'course', $course_id, array( 'id' => $id ) );
			do_action( 'educore/events/announcement_published', $id, $course_id );
		}
		return $id;
	}

	/** @return \WP_Post[] */
	public static function for_courses( array $course_ids, int $limit = 5 ): array {
		if ( empty( $course_ids ) ) {
			return array();
		}
		return get_posts( array( 'post_type' => self::TYPE, 'post_status' => 'publish', 'post_parent__in' => array_map( 'intval', $course_ids ), 'posts_per_page' => $limit ) );
	}

	public static function dashboard( array $data, int $user_id ): array {
		$ids = array();
		foreach ( $data['courses'] as $c ) {
			if ( $c['accessible'] ) {
				$ids[] = (int) $c['course_id'];
			}
		}
		foreach ( self::for_courses( $ids ) as $a ) {
			$data['announcements'][] = array( 'title' => $a->post_title, 'meta' => get_the_title( $a->post_parent ) . ' · ' . wp_trim_words( $a->post_content, 18 ), 'url' => '' );
		}
		return $data;
	}
}
