<?php
namespace EduCore\Core\Rest;

use EduCore\Core\Catalog;
use EduCore\Core\Content;
use EduCore\Core\Privacy;
use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/** Public, read-only catalogue + guardian consent endpoint (token-authenticated). */
final class PublicController {

	public static function routes(): void {
		register_rest_route(
			Routes::NS,
			'/courses',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'list_courses' ),
				'permission_callback' => '__return_true', // Public catalogue (published courses only).
				'args'                => array(
					'q'          => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'subject'    => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
					'programme'  => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
					'difficulty' => array( 'type' => 'string', 'enum' => array( '', 'beginner', 'intermediate', 'advanced' ) ),
					'instructor' => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
					'price'      => array( 'type' => 'string', 'enum' => array( '', 'free', 'paid' ) ),
					'lang'       => array( 'type' => 'string', 'enum' => array( '', 'en', 'fr', 'ar' ) ),
					'page'       => array( 'type' => 'integer', 'default' => 1, 'minimum' => 1 ),
					'per_page'   => array( 'type' => 'integer', 'default' => 12, 'minimum' => 1, 'maximum' => 48 ),
				),
			)
		);
		register_rest_route(
			Routes::NS,
			'/courses/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'get_course' ),
				'permission_callback' => '__return_true', // Public course details; lesson bodies are never included.
				'args'                => array( 'id' => Routes::id_arg() ),
			)
		);
		register_rest_route(
			Routes::NS,
			'/guardian/confirm',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'guardian_confirm' ),
				'permission_callback' => '__return_true', // Authenticated by a single-use emailed token; rate limited.
				'args'                => array(
					'token'   => array( 'type' => 'string', 'required' => true ),
					'approve' => array( 'type' => 'boolean', 'required' => true ),
				),
			)
		);
	}

	public static function list_courses( \WP_REST_Request $r ): \WP_REST_Response {
		$res = Catalog::search( $r->get_params() );
		$out = array_map( array( Catalog::class, 'card' ), $res['posts'] );
		$response = new \WP_REST_Response( $out );
		$response->header( 'X-WP-Total', (string) $res['total'] );
		$response->header( 'X-WP-TotalPages', (string) $res['pages'] );
		return $response;
	}

	public static function get_course( \WP_REST_Request $r ) {
		$id = (int) $r['id'];
		if ( ! Content::is_course( $id ) || 'publish' !== get_post_status( $id ) ) {
			return Routes::error( 'educore_not_found', __( 'Course not found.', 'educore-core' ), 404 );
		}
		return new \WP_REST_Response( Catalog::details( $id ) );
	}

	public static function guardian_confirm( \WP_REST_Request $r ) {
		if ( ! RateLimiter::hit( 'guardian' ) ) {
			return Routes::error( 'educore_throttled', __( 'Too many requests.', 'educore-core' ), 429 );
		}
		$res = Privacy::confirm_guardian( (string) $r['token'], (bool) $r['approve'] );
		if ( is_wp_error( $res ) ) {
			$res->add_data( array( 'status' => 400 ) );
			return $res;
		}
		return new \WP_REST_Response( array( 'ok' => true ) );
	}
}
