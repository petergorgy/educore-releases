<?php
namespace EduCore\Identity;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Account-linking model: one row per (provider, stable subject) → one WordPress user. Tokens are never stored. */
final class Links {
	public static function table(): string {
		return Schema::table( 'identity_links' );
	}

	/** @return array<string,mixed>|null */
	public static function find( string $provider, string $subject ): ?array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE provider=%s AND subject=%s', $provider, $subject ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		return $r ?: null;
	}

	/** @return array<int,array<string,mixed>> */
	public static function for_user( int $uid ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE user_id=%d ORDER BY provider', $uid ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** @return true|\WP_Error */
	public static function add( int $uid, string $provider, array $id ) {
		global $wpdb;
		$existing = self::find( $provider, $id['sub'] );
		if ( $existing ) {
			return (int) $existing['user_id'] === $uid ? true : new \WP_Error( 'educore_id_taken', __( 'This sign-in account is already connected to a different EduCore account.', 'educore-identity' ) );
		}
		foreach ( self::for_user( $uid ) as $l ) {
			if ( $l['provider'] === $provider ) {
				return new \WP_Error( 'educore_id_one_per_provider', __( 'Your account already has a connection for this provider. Disconnect it first to use a different one.', 'educore-identity' ) );
			}
		}
		$ok = $wpdb->insert(
			self::table(),
			array(
				'user_id'        => $uid,
				'provider'       => $provider,
				'subject'        => mb_substr( (string) $id['sub'], 0, 191 ),
				'email'          => mb_substr( (string) ( $id['email'] ?? '' ), 0, 191 ),
				'email_verified' => ! empty( $id['email_verified'] ) ? 1 : 0,
				'display_name'   => mb_substr( (string) ( $id['name'] ?? '' ), 0, 191 ),
				'created_at'     => Schema::now(),
			)
		);
		return $ok ? true : new \WP_Error( 'educore_id_db', __( 'The connection could not be saved.', 'educore-identity' ) );
	}

	public static function touch( int $id ): void {
		global $wpdb;
		$wpdb->update( self::table(), array( 'last_login_at' => Schema::now() ), array( 'id' => $id ) );
	}

	public static function remove( int $uid, string $provider ): bool {
		global $wpdb;
		return (bool) $wpdb->delete( self::table(), array( 'user_id' => $uid, 'provider' => $provider ) );
	}

	public static function remove_user( int $uid ): void {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'user_id' => $uid ) );
	}
}
