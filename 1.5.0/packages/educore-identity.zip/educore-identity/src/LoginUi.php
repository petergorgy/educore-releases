<?php
namespace EduCore\Identity;

defined( 'ABSPATH' ) || exit;

/**
 * Sign-in screen: "Choose how you'd like to continue" with one button per available provider, above the usual
 * EduCore username/password form. Buttons use each provider's name and mark and lead to the provider's own consent
 * screen; EduCore never imitates a provider's sign-in form. Nothing is shown for providers that are not ready.
 */
final class LoginUi {
	public static function register(): void {
		add_filter( 'login_message', array( self::class, 'buttons' ), 20 );
		add_filter( 'wp_login_errors', array( self::class, 'errors' ), 20 );
		add_action( 'login_enqueue_scripts', array( self::class, 'assets' ), 20 );
		add_filter( 'the_content', array( self::class, 'register_notice' ), 5 );
	}

	public static function assets(): void {
		wp_enqueue_style( 'educore-identity', EDUCORE_ID_URL . 'assets/css/identity.css', array(), EDUCORE_ID_VERSION );
	}

	private static function is_plain_login(): bool {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display only.
		$a = sanitize_key( wp_unslash( $_REQUEST['action'] ?? 'login' ) );
		return 'login' === $a && ! isset( $_GET['checkemail'] ) && ! isset( $_REQUEST['interim-login'] ) && ! did_action( 'wp_login' );
		// phpcs:enable
	}

	public static function buttons( $message ) {
		$list = Providers::available_list();
		if ( ! $list || ! self::is_plain_login() ) {
			return $message;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- carried through to the round-trip, validated there.
		$redirect = wp_validate_redirect( esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ?? '' ) ), '' );
		$o        = '<section class="ec-sso" aria-labelledby="ec-sso-h"><p class="ec-sso__lead" id="ec-sso-h">' . esc_html__( 'Choose how you’d like to continue.', 'educore-identity' ) . '</p><ul class="ec-sso__list">';
		foreach ( $list as $p ) {
			/* translators: %s: provider name, e.g. Google */
			$o .= '<li><a class="ec-sso__btn ec-sso__btn--' . esc_attr( $p ) . '" href="' . esc_url( Flow::start_url( $p, $redirect ) ) . '" rel="nofollow">' . self::mark( $p ) . '<span>' . esc_html( sprintf( __( 'Continue with %s', 'educore-identity' ), Providers::label( $p ) ) ) . '</span></a></li>';
		}
		$o .= '</ul><p class="ec-sso__or"><span>' . esc_html__( 'or use your EduCore account', 'educore-identity' ) . '</span></p></section>';
		return $message . $o;
	}

	public static function errors( $errors ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
		$code = sanitize_key( wp_unslash( $_GET['educore_sso_error'] ?? '' ) );
		if ( '' === $code || ! ( $errors instanceof \WP_Error ) ) {
			return $errors;
		}
		$m = array(
			'not_linked'     => __( 'No EduCore account is connected to that sign-in yet. If you already have an EduCore account, sign in with your password and connect it from Preferences. Otherwise, ask your school for access.', 'educore-identity' ),
			'cancelled'      => __( 'Sign-in was cancelled. You can try again or use your EduCore password.', 'educore-identity' ),
			'state'          => __( 'That sign-in link has expired or was already used. Please start again.', 'educore-identity' ),
			'verify'         => __( 'We could not confirm that sign-in. Please try again or use your EduCore password.', 'educore-identity' ),
			'provider_error' => __( 'The sign-in service returned an error. Please try again or use your EduCore password.', 'educore-identity' ),
			'provider_down'  => __( 'That sign-in service is not reachable right now. Please use your EduCore password.', 'educore-identity' ),
			'unavailable'    => __( 'That sign-in option is not available.', 'educore-identity' ),
			'throttled'      => __( 'Too many sign-in attempts. Please wait a few minutes.', 'educore-identity' ),
			'suspended'      => __( 'This account is suspended. Contact support if you think this is a mistake.', 'educore-identity' ),
		);
		$errors->add( 'educore_sso_' . $code, $m[ $code ] ?? $m['verify'] );
		return $errors;
	}

	/** On EduCore's registration page after a social sign-in with an unknown identity (open registration only). */
	public static function register_notice( $content ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display only.
		if ( ! is_page() || 'register' !== sanitize_key( wp_unslash( $_GET['educore_sso'] ?? '' ) ) || empty( $_COOKIE[ Flow::PENDING ] ) ) {
			return $content;
		}
		$p = sanitize_key( wp_unslash( $_GET['provider'] ?? '' ) );
		// phpcs:enable
		if ( ! in_array( $p, Providers::KEYS, true ) ) {
			return $content;
		}
		/* translators: %1$s: provider name */
		$n = '<div class="ec-notice ec-notice--info" role="status">' . esc_html( sprintf( __( 'You signed in with %1$s, but no EduCore account is connected to it yet. Complete the form below to create your account; %1$s will be connected automatically. Learners under 18 still need a parent or guardian’s consent.', 'educore-identity' ), Providers::label( $p ) ) ) . '</div>';
		return $n . $content;
	}

	/** Provider marks (inline SVG, used as sign-in identifiers per each provider's branding guidance). */
	public static function mark( string $p ): string {
		$m = array(
			'google'    => '<svg viewBox="0 0 18 18" aria-hidden="true" focusable="false"><path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.92c1.7-1.57 2.68-3.88 2.68-6.62z"/><path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.92-2.26c-.8.54-1.84.86-3.04.86-2.34 0-4.32-1.58-5.03-3.7H.96v2.33A9 9 0 0 0 9 18z"/><path fill="#FBBC05" d="M3.97 10.72a5.4 5.4 0 0 1 0-3.44V4.95H.96a9 9 0 0 0 0 8.1l3.01-2.33z"/><path fill="#EA4335" d="M9 3.58c1.32 0 2.5.45 3.44 1.35l2.58-2.58A9 9 0 0 0 .96 4.95l3.01 2.33C4.68 5.16 6.66 3.58 9 3.58z"/></svg>',
			'microsoft' => '<svg viewBox="0 0 21 21" aria-hidden="true" focusable="false"><path fill="#F25022" d="M1 1h9v9H1z"/><path fill="#7FBA00" d="M11 1h9v9h-9z"/><path fill="#00A4EF" d="M1 11h9v9H1z"/><path fill="#FFB900" d="M11 11h9v9h-9z"/></svg>',
			'linkedin'  => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect width="24" height="24" rx="3" fill="#0A66C2"/><path fill="#fff" d="M7.1 9.4h-2.6V19h2.6zM5.8 5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zm13.7 8.5c0-2.6-.6-4.4-3.6-4.4-1.5 0-2.4.8-2.8 1.5V9.4h-2.5V19h2.6v-4.7c0-1.3.2-2.5 1.8-2.5s1.6 1.5 1.6 2.6V19h2.6z"/></svg>',
			'facebook'  => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="12" fill="#0866FF"/><path fill="#fff" d="M15.1 15.5l.5-3.2h-3.1v-2c0-.9.4-1.7 1.8-1.7h1.4V5.9s-1.3-.2-2.5-.2c-2.6 0-4.2 1.5-4.2 4.3v2.4H6.2v3.2H9V24h3.5v-8.5z"/></svg>',
		);
		return '<span class="ec-sso__mark">' . ( $m[ $p ] ?? '' ) . '</span>';
	}
}
