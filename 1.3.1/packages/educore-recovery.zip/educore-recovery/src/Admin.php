<?php
namespace EduCore\Recovery;

use EduCore\Core\Audit;

defined( 'ABSPATH' ) || exit;

/** wp-admin → EduCore → Backup & Recovery. */
final class Admin {
	public const SLUG = 'educore-backups';

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 30 );
		add_action( 'admin_init', array( self::class, 'handle' ) );
	}

	public static function menu(): void {
		add_submenu_page( 'educore', __( 'Backup & Recovery', 'educore-recovery' ), __( 'Backup & Recovery', 'educore-recovery' ), Plugin::CAP, self::SLUG, array( self::class, 'page' ) );
	}

	private static function url( array $args = array() ): string {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . self::SLUG ) );
	}

	private static function form( string $action, string $inner, array $hidden = array(), string $class = '' ): string {
		$h = '<form method="post" class="' . esc_attr( $class ) . '" style="display:inline">' . wp_nonce_field( 'ec_rc_' . $action, '_ecrc', true, false ) . '<input type="hidden" name="ec_rc" value="' . esc_attr( $action ) . '">';
		foreach ( $hidden as $k => $v ) {
			$h .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( (string) $v ) . '">';
		}
		return $h . $inner . '</form>';
	}

	private static function back( array $args ): void {
		wp_safe_redirect( self::url( $args ) );
		exit;
	}

	public static function handle(): void {
		if ( empty( $_POST['ec_rc'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['ec_rc'] ) );
		check_admin_referer( 'ec_rc_' . $action, '_ecrc' );
		if ( ! current_user_can( Plugin::CAP ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to manage backups.', 'educore-recovery' ), 403 );
		}
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		switch ( $action ) {
			case 'create':
				$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( $_POST['kind'] ) ) : 'academic';
				$r    = Backup::create( $kind, 'manual' );
				if ( is_wp_error( $r ) ) {
					self::back( array( 'err' => $r->get_error_message() ) );
				}
				$v = Verifier::verify( $r );
				self::back( $v['ok'] ? array( 'msg' => 'created' ) : array( 'err' => implode( '; ', $v['errors'] ) ) );
				break;
			case 'verify':
				$v = Verifier::verify( $id );
				self::back( $v['ok'] ? array( 'msg' => 'verified' ) : array( 'err' => implode( '; ', $v['errors'] ) ) );
				break;
			case 'test':
				$t = RestoreTest::run( $id );
				self::back( $t['ok'] ? array( 'msg' => 'tested' ) : array( 'err' => implode( '; ', (array) ( $t['report']['errors'] ?? array() ) ) ) );
				break;
			case 'delete':
				Backup::delete( $id );
				self::back( array( 'msg' => 'deleted' ) );
				break;
			case 'download':
				self::download( $id );
				break;
			case 'settings':
				Settings::save( wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitised field by field in Settings::save().
				Audit::log( 'backup.settings_saved', 'backup', 0 );
				self::back( array( 'msg' => 'saved', 'tab' => 'settings' ) );
				break;
			case 'token':
				$plain = Settings::cron_token( true );
				set_transient( 'educore_rc_token_' . get_current_user_id(), $plain, 10 * MINUTE_IN_SECONDS );
				Audit::log( 'backup.cron_token_regenerated', 'backup', 0 );
				self::back( array( 'msg' => 'token', 'tab' => 'settings' ) );
				break;
			case 'import':
				if ( ! current_user_can( 'manage_options' ) || empty( $_FILES['backup']['tmp_name'] ) || ! is_uploaded_file( $_FILES['backup']['tmp_name'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- path checked with is_uploaded_file().
					self::back( array( 'err' => __( 'No file was uploaded.', 'educore-recovery' ) ) );
				}
				$r = Importer::import( $_FILES['backup']['tmp_name'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				self::back( is_wp_error( $r ) ? array( 'err' => $r->get_error_message() ) : array( 'msg' => 'imported' ) );
				break;
			case 'gen_key':
				if ( ! current_user_can( 'manage_options' ) ) {
					wp_die( esc_html__( 'Only a site administrator can manage the encryption key.', 'educore-recovery' ), 403 );
				}
				$r = Settings::generate_key_file();
				Audit::log( is_wp_error( $r ) ? 'backup.key_generation_failed' : 'backup.key_generated', 'backup', 0, array( 'key_id' => Settings::key_id() ) );
				self::back( is_wp_error( $r ) ? array( 'err' => $r->get_error_message(), 'tab' => 'settings' ) : array( 'msg' => 'key', 'tab' => 'settings' ) );
				break;
			case 'dl_key':
				if ( ! current_user_can( 'manage_options' ) || ! Settings::key() ) {
					wp_die( esc_html__( 'Only a site administrator can manage the encryption key.', 'educore-recovery' ), 403 );
				}
				update_option( 'educore_rc_key_downloaded', gmdate( 'c' ) . ' ' . get_current_user_id(), false );
				Audit::log( 'backup.key_downloaded', 'backup', 0, array( 'key_id' => Settings::key_id() ) );
				nocache_headers();
				header( 'Content-Type: text/plain; charset=utf-8' );
				header( 'Content-Disposition: attachment; filename="educore-backup-key-' . Settings::key_id() . '.txt"' );
				echo "EduCore backup encryption key\nKey ID: " . Settings::key_id() . "\nSite: " . esc_url_raw( home_url() ) . "\nCreated for offline storage on " . gmdate( 'c' ) . "\n\nTo restore encrypted backups on a rebuilt site, add to wp-config.php:\ndefine( 'EDUCORE_BACKUP_KEY', '" . Settings::key_export() . "' );\n\nKeep this file offline and separate from the backup files.\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- plain-text download.
				exit;
			case 'encrypt_existing':
				if ( ! current_user_can( 'manage_options' ) || empty( $_POST['confirm_key_saved'] ) ) {
					self::back( array( 'err' => __( 'Confirm that the recovery key is stored offline first.', 'educore-recovery' ), 'tab' => 'settings' ) );
				}
				[ $ok, $bad, $msgs ] = Store::encrypt_existing();
				/* translators: 1: converted, 2: failed */
				self::back( $bad ? array( 'err' => sprintf( __( '%1$d backups encrypted, %2$d left unchanged.', 'educore-recovery' ), $ok, $bad ) . ' ' . implode( ' ', $msgs ), 'tab' => 'settings' ) : array( 'msg' => 'encrypted', 'n' => $ok, 'tab' => 'settings' ) );
				break;
			case 'restore':
				if ( ! current_user_can( 'manage_options' ) ) {
					wp_die( esc_html__( 'Only a site administrator can restore.', 'educore-recovery' ), 403 );
				}
				$r = Restore::run(
					$id,
					array(
						'confirm' => isset( $_POST['confirm'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['confirm'] ) ) ) : '',
						'uploads' => ! empty( $_POST['uploads'] ),
					)
				);
				set_transient( 'educore_rc_restore_result', $r, HOUR_IN_SECONDS );
				self::back( $r['ok'] ? array( 'msg' => 'restored' ) : array( 'restore' => $id, 'err' => implode( ' ', $r['errors'] ) ) );
				break;
		}
	}

	private static function download( int $id ): void {
		$b = Backup::get( $id );
		$p = ( $b && $b->file ) ? Store::path( $b->file ) : null;
		if ( ! $p ) {
			self::back( array( 'err' => __( 'The backup file is missing from storage.', 'educore-recovery' ) ) );
		}
		Audit::log( 'backup.downloaded', 'backup', $id, array( 'uid' => $b->uid ) );
		nocache_headers();
		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Disposition: attachment; filename="' . basename( $p ) . '"' );
		header( 'Content-Length: ' . filesize( $p ) );
		header( 'X-Content-Type-Options: nosniff' );
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		readfile( $p ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	private static function badge( string $s ): string {
		$map = array(
			'verified' => 'good', 'passed' => 'good', 'complete' => 'good',
			'failed' => 'bad', 'verify_failed' => 'bad',
			'running' => 'warn', 'not_verified' => 'warn', 'not_tested' => 'warn',
		);
		$labels = array(
			'verified' => __( 'Verified', 'educore-recovery' ), 'passed' => __( 'Passed', 'educore-recovery' ), 'complete' => __( 'Complete', 'educore-recovery' ),
			'failed' => __( 'Failed', 'educore-recovery' ), 'running' => __( 'Running', 'educore-recovery' ),
			'not_verified' => __( 'Not verified', 'educore-recovery' ), 'not_tested' => __( 'Not tested', 'educore-recovery' ),
		);
		$c = array( 'good' => '#00701a', 'bad' => '#b32d2e', 'warn' => '#8a5a00' )[ $map[ $s ] ?? 'warn' ];
		return '<strong style="color:' . $c . '">' . esc_html( $labels[ $s ] ?? $s ) . '</strong>';
	}

	private static function when( ?string $mysql ): string {
		return $mysql ? esc_html( get_date_from_gmt( $mysql, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ) : '—';
	}

	public static function page(): void {
		if ( ! current_user_can( Plugin::CAP ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to manage backups.', 'educore-recovery' ), 403 );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$tab     = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'overview';
		$restore = isset( $_GET['restore'] ) ? absint( $_GET['restore'] ) : 0;
		echo '<div class="wrap ec-admin"><h1>' . esc_html__( 'Backup & Recovery Center', 'educore-recovery' ) . '</h1>';
		$msgs = array(
			'created'  => __( 'Backup created and verified.', 'educore-recovery' ),
			'verified' => __( 'Backup verified: every checksum matches.', 'educore-recovery' ),
			'tested'   => __( 'Restore test passed: the backup was restored into isolated tables and matched exactly. Live data was not touched.', 'educore-recovery' ),
			'deleted'  => __( 'Backup deleted.', 'educore-recovery' ),
			'saved'    => __( 'Settings saved.', 'educore-recovery' ),
			'token'    => __( 'New server-cron URL generated. Copy it now; it is shown only once.', 'educore-recovery' ),
			'restored' => __( 'Restore completed and verified.', 'educore-recovery' ),
			'imported' => __( 'Backup imported. Verify and test it before restoring.', 'educore-recovery' ),
			'key'       => __( 'Encryption key created outside the web root. New backups are encrypted. Download the recovery key now and store it offline.', 'educore-recovery' ),
			'encrypted' => __( 'Existing backups were encrypted and re-verified; the unencrypted copies were removed.', 'educore-recovery' ),
		);
		$code = isset( $_GET['msg'] ) ? sanitize_key( wp_unslash( $_GET['msg'] ) ) : '';
		if ( isset( $msgs[ $code ] ) ) {
			echo '<div class="notice notice-success"><p>' . esc_html( $msgs[ $code ] ) . '</p></div>';
		}
		if ( isset( $_GET['err'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['err'] ) ) ) . '</p></div>';
		}
		// phpcs:enable
		if ( $restore ) {
			self::wizard( $restore );
			echo '</div>';
			return;
		}
		$tabs = array( 'overview' => __( 'Backups', 'educore-recovery' ), 'settings' => __( 'Schedule & retention', 'educore-recovery' ), 'dr' => __( 'Disaster recovery plan', 'educore-recovery' ) );
		echo '<nav class="nav-tab-wrapper">';
		foreach ( $tabs as $k => $l ) {
			echo '<a class="nav-tab' . ( $k === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url( array( 'tab' => $k ) ) ) . '">' . esc_html( $l ) . '</a>';
		}
		echo '</nav>';
		'settings' === $tab ? self::tab_settings() : ( 'dr' === $tab ? self::tab_dr() : self::tab_overview() );
		echo '</div>';
	}

	private static function cards(): void {
		$h  = Scheduler::health();
		$lv = $h['last_verified'];
		$lt = $h['last_tested'];
		$cards = array(
			__( 'Last verified backup', 'educore-recovery' ) => $lv ? self::when( $lv->created_at ) . '<br><small>' . esc_html( $lv->kind ) . '</small>' : '<strong style="color:#b32d2e">' . esc_html__( 'None', 'educore-recovery' ) . '</strong>',
			__( 'Last successful restore test', 'educore-recovery' ) => $lt ? self::when( $lt->restore_tested_at ) : '<strong style="color:#8a5a00">' . esc_html__( 'Never', 'educore-recovery' ) . '</strong>',
			__( 'Failed backups (7 days)', 'educore-recovery' ) => (string) (int) $h['failed_7d'],
			__( 'Storage used', 'educore-recovery' ) => esc_html( size_format( $h['storage_bytes'] ) ) . ( false !== $h['free_bytes'] ? '<br><small>' . esc_html( sprintf( /* translators: %s: size */ __( '%s free', 'educore-recovery' ), size_format( (float) $h['free_bytes'] ) ) ) . '</small>' : '' ),
			__( 'Encryption', 'educore-recovery' ) => $h['encrypted'] ? self::badge( 'passed' ) : '<strong style="color:#8a5a00">' . esc_html__( 'Off', 'educore-recovery' ) . '</strong>',
			__( 'Storage location', 'educore-recovery' ) => $h['outside_webroot'] ? esc_html__( 'Outside the web root', 'educore-recovery' ) : esc_html__( 'Protected folder inside uploads', 'educore-recovery' ),
		);
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin:16px 0">';
		foreach ( $cards as $label => $val ) {
			echo '<div class="card" style="margin:0;padding:12px 16px"><div style="color:#50575e">' . esc_html( $label ) . '</div><div style="font-size:1.15em;margin-top:4px">' . wp_kses_post( $val ) . '</div></div>';
		}
		echo '</div>';
	}

	private static function tab_overview(): void {
		self::cards();
		$opts = '';
		foreach ( Backup::kinds() as $k => $d ) {
			$opts .= '<option value="' . esc_attr( $k ) . '"' . selected( 'academic', $k, false ) . '>' . esc_html( $d['label'] ) . '</option>';
		}
		echo '<h2>' . esc_html__( 'Create a backup', 'educore-recovery' ) . '</h2><p>';
		echo self::form( 'create', '<label class="screen-reader-text" for="ec-rc-kind">' . esc_html__( 'Backup type', 'educore-recovery' ) . '</label><select id="ec-rc-kind" name="kind">' . $opts . '</select> ' . get_submit_button( __( 'Create & verify backup', 'educore-recovery' ), 'primary', 'submit', false ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		echo '</p>';
		if ( current_user_can( 'manage_options' ) ) {
			echo '<details><summary>' . esc_html__( 'Import a backup file from another installation', 'educore-recovery' ) . '</summary><form method="post" enctype="multipart/form-data">' . wp_nonce_field( 'ec_rc_import', '_ecrc', true, false ) . '<input type="hidden" name="ec_rc" value="import"><p><label for="ec-rc-file">' . esc_html__( 'Backup file (.zip or .zip.enc)', 'educore-recovery' ) . '</label> <input id="ec-rc-file" type="file" name="backup" accept=".zip,.enc" required> ' . get_submit_button( __( 'Import', 'educore-recovery' ), 'secondary', 'submit', false ) . '</p><p class="description">' . esc_html__( 'Large files: copy them to the server and use “wp educore backup import <file>”.', 'educore-recovery' ) . '</p></form></details>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
		echo '<h2>' . esc_html__( 'Backups', 'educore-recovery' ) . '</h2>';
		$rows = Backup::list( 100 );
		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'No backups yet.', 'educore-recovery' ) . '</p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th scope="col">' . esc_html__( 'Created', 'educore-recovery' ) . '</th><th scope="col">' . esc_html__( 'Type', 'educore-recovery' ) . '</th><th scope="col">' . esc_html__( 'Trigger', 'educore-recovery' ) . '</th><th scope="col">' . esc_html__( 'Size', 'educore-recovery' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-recovery' ) . '</th><th scope="col">' . esc_html__( 'Integrity', 'educore-recovery' ) . '</th><th scope="col">' . esc_html__( 'Restore test', 'educore-recovery' ) . '</th><th scope="col">' . esc_html__( 'Actions', 'educore-recovery' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $b ) {
			$acts = '';
			if ( 'complete' === $b->status ) {
				$acts .= self::form( 'verify', get_submit_button( __( 'Verify', 'educore-recovery' ), 'small', 'submit', false ), array( 'id' => $b->id ) ) . ' ';
				$acts .= self::form( 'test', get_submit_button( __( 'Test restore', 'educore-recovery' ), 'small', 'submit', false ), array( 'id' => $b->id ) ) . ' ';
				$acts .= self::form( 'download', get_submit_button( __( 'Download', 'educore-recovery' ), 'small', 'submit', false ), array( 'id' => $b->id ) ) . ' ';
				if ( current_user_can( 'manage_options' ) ) {
					$acts .= '<a class="button button-small" href="' . esc_url( self::url( array( 'restore' => $b->id ) ) ) . '">' . esc_html__( 'Restore…', 'educore-recovery' ) . '</a> ';
				}
			}
			$acts .= self::form( 'delete', '<button type="submit" class="button button-small button-link-delete" onclick="return confirm(this.dataset.q)" data-q="' . esc_attr__( 'Delete this backup permanently?', 'educore-recovery' ) . '">' . esc_html__( 'Delete', 'educore-recovery' ) . '</button>', array( 'id' => $b->id ) );
			echo '<tr><td>' . self::when( $b->created_at ) . '<br><code>' . esc_html( $b->uid ) . '</code></td><td>' . esc_html( $b->kind ) . ( (int) $b->encrypted ? ' 🔒' : '' ) . '</td><td>' . esc_html( $b->trigger_source ) . '</td><td>' . esc_html( size_format( (float) $b->size ) ) . '</td><td>' . self::badge( $b->status ) . ( $b->message ? '<br><small>' . esc_html( $b->message ) . '</small>' : '' ) . '</td><td>' . self::badge( $b->verify_status ) . '<br><small>' . self::when( $b->verified_at ) . '</small></td><td>' . self::badge( $b->restore_test_status ) . '<br><small>' . self::when( $b->restore_tested_at ) . '</small></td><td>' . $acts . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
		echo '</tbody></table>';
	}

	private static function tab_settings(): void {
		$s   = Settings::all();
		$chk = static fn( $k, $label ) => '<label><input type="checkbox" name="' . esc_attr( $k ) . '" value="on"' . checked( 'on', $s[ $k ], false ) . '> ' . esc_html( $label ) . '</label><br>';
		$num = static fn( $k, $label ) => '<label>' . esc_html( $label ) . ' <input type="number" min="0" max="365" class="small-text" name="' . esc_attr( $k ) . '" value="' . esc_attr( (string) $s[ $k ] ) . '"></label><br>';
		$inner  = '<h2>' . esc_html__( 'Schedule', 'educore-recovery' ) . '</h2><p>';
		$inner .= $chk( 'daily', __( 'Daily academic-data backup (verified automatically)', 'educore-recovery' ) );
		$inner .= $chk( 'weekly', __( 'Weekly full backup (verified automatically)', 'educore-recovery' ) );
		$inner .= $chk( 'predeploy', __( 'Back up before EduCore plugins or theme are updated (the update stops if the backup fails)', 'educore-recovery' ) );
		$inner .= '</p><h2>' . esc_html__( 'Retention', 'educore-recovery' ) . '</h2><p>';
		$inner .= $num( 'keep_daily', __( 'Daily backups to keep', 'educore-recovery' ) ) . $num( 'keep_weekly', __( 'Weekly backups to keep', 'educore-recovery' ) ) . $num( 'keep_predeploy', __( 'Pre-deployment backups to keep', 'educore-recovery' ) ) . $num( 'keep_manual', __( 'Manual backups to keep', 'educore-recovery' ) );
		$inner .= $num( 'max_file_mb', __( 'Skip single files larger than (MB, 0 = no limit)', 'educore-recovery' ) ) . '</p>' . get_submit_button( __( 'Save settings', 'educore-recovery' ), 'primary', 'submit', false );
		echo self::form( 'settings', $inner ); // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.

		echo '<h2>' . esc_html__( 'Reliable scheduling (server cron)', 'educore-recovery' ) . '</h2><p>' . esc_html__( 'WordPress cron only runs when the site has visitors. Add this command in cPanel → Cron Jobs, “Once Per Hour” (0 * * * *). It runs on the server itself, so host bot protection cannot block it.', 'educore-recovery' ) . '</p>';
		$cmd = '/usr/local/bin/php -q ' . wp_normalize_path( EDUCORE_RC_DIR ) . 'bin/cron.php >/dev/null 2>&1';
		echo '<p><label for="ec-rc-cron" class="screen-reader-text">' . esc_html__( 'Cron command', 'educore-recovery' ) . '</label><input id="ec-rc-cron" type="text" readonly class="large-text code" onfocus="this.select()" value="' . esc_attr( $cmd ) . '"></p>';
		/* translators: %s: PHP version */
		echo '<p class="description">' . esc_html( sprintf( __( 'If your host offers several PHP versions, use the PHP %s binary (for example /opt/cpanel/ea-php85/root/usr/bin/php).', 'educore-recovery' ), PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION ) ) . '</p>';
		$h   = Scheduler::health();
		$fmt = static fn( $o ) => ( $t = (string) get_option( $o, '' ) ) ? esc_html( get_date_from_gmt( gmdate( 'Y-m-d H:i:s', strtotime( $t ) ), get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ) : '—'; // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
		echo '<table class="widefat striped" style="max-width:640px"><tbody><tr><th scope="row">' . esc_html__( 'Last run by server cron', 'educore-recovery' ) . '</th><td>' . $fmt( 'educore_rc_last_tick_cli' ) . '</td></tr><tr><th scope="row">' . esc_html__( 'Last run by token URL', 'educore-recovery' ) . '</th><td>' . $fmt( 'educore_rc_last_tick_http' ) . '</td></tr><tr><th scope="row">' . esc_html__( 'Last run by WordPress cron', 'educore-recovery' ) . '</th><td>' . $fmt( 'educore_rc_last_tick_wp-cron' ) . '</td></tr></tbody></table>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<details><summary>' . esc_html__( 'Alternative: secret URL (only if your host allows command cron jobs to call the site)', 'educore-recovery' ) . '</summary>';
		$plain = get_transient( 'educore_rc_token_' . get_current_user_id() );
		if ( $plain ) {
			delete_transient( 'educore_rc_token_' . get_current_user_id() );
			echo '<p><input type="text" readonly class="large-text code" aria-label="' . esc_attr__( 'Cron URL', 'educore-recovery' ) . '" onfocus="this.select()" value="' . esc_attr( add_query_arg( 'educore_backup_cron', $plain, home_url( '/' ) ) ) . '"></p>';
		} else {
			echo '<p>' . ( get_option( 'educore_rc_cron_hash' ) ? esc_html__( 'A cron URL exists. It is stored hashed and cannot be shown again; generate a new one if you lost it (the old one stops working).', 'educore-recovery' ) : esc_html__( 'No cron URL has been generated yet.', 'educore-recovery' ) ) . '</p>';
		}
		echo self::form( 'token', get_submit_button( __( 'Generate new cron URL', 'educore-recovery' ), 'secondary', 'submit', false ) ) . '</details>'; // phpcs:ignore WordPress.Security.EscapeOutput

		echo '<h2>' . esc_html__( 'Encryption', 'educore-recovery' ) . '</h2>';
		$src = Settings::key_source();
		if ( 'none' === $src || 'invalid' === $src ) {
			if ( 'invalid' === $src ) {
				echo '<div class="notice notice-error inline"><p>' . esc_html__( 'EDUCORE_BACKUP_KEY in wp-config.php is not a valid 32-byte base64 key.', 'educore-recovery' ) . '</p></div>';
			}
			echo '<p>' . esc_html__( 'Encryption is off. Choose one:', 'educore-recovery' ) . '</p><ol><li>' . esc_html__( 'Recommended for this host: create a key file outside the web root (one click, below). Then download the recovery key and keep it offline.', 'educore-recovery' ) . '</li><li>' . esc_html__( 'Or add this line to wp-config.php (a new random key is shown on each visit; it is not stored anywhere):', 'educore-recovery' ) . '<br><input type="text" readonly class="large-text code" aria-label="' . esc_attr__( 'wp-config.php line', 'educore-recovery' ) . '" onfocus="this.select()" value="' . esc_attr( "define( 'EDUCORE_BACKUP_KEY', '" . base64_encode( random_bytes( 32 ) ) . "' );" ) . '"></li></ol>';
			if ( current_user_can( 'manage_options' ) && 'none' === $src ) {
				echo self::form( 'gen_key', get_submit_button( __( 'Create encryption key file', 'educore-recovery' ), 'primary', 'submit', false ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			return;
		}
		$dl = (string) get_option( 'educore_rc_key_downloaded', '' );
		echo '<table class="widefat striped" style="max-width:640px"><tbody>';
		echo '<tr><th scope="row">' . esc_html__( 'Status', 'educore-recovery' ) . '</th><td>' . self::badge( 'passed' ) . ' XChaCha20-Poly1305</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<tr><th scope="row">' . esc_html__( 'Key source', 'educore-recovery' ) . '</th><td>' . esc_html( 'wp-config' === $src ? __( 'wp-config.php (EDUCORE_BACKUP_KEY)', 'educore-recovery' ) : __( 'Key file outside the web root', 'educore-recovery' ) ) . '</td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Key ID (not secret)', 'educore-recovery' ) . '</th><td><code>' . esc_html( Settings::key_id() ) . '</code></td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Recovery key stored offline', 'educore-recovery' ) . '</th><td>' . ( $dl ? esc_html( sprintf( /* translators: %s: date */ __( 'Downloaded %s', 'educore-recovery' ), substr( $dl, 0, 19 ) ) ) : '<strong style="color:#b32d2e">' . esc_html__( 'Not yet downloaded', 'educore-recovery' ) . '</strong>' ) . '</td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Unencrypted backups on the server', 'educore-recovery' ) . '</th><td>' . esc_html( number_format_i18n( Store::unencrypted_count() ) ) . '</td></tr></tbody></table>';
		if ( current_user_can( 'manage_options' ) ) {
			echo '<p>' . self::form( 'dl_key', get_submit_button( __( 'Download recovery key (store it offline)', 'educore-recovery' ), $dl ? 'secondary' : 'primary', 'submit', false ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
			if ( Store::unencrypted_count() ) {
				$inner = '<p><label><input type="checkbox" name="confirm_key_saved" value="1" required> ' . esc_html__( 'I have stored the recovery key offline. Without it, encrypted backups cannot be restored on another server.', 'educore-recovery' ) . '</label></p>' . get_submit_button( __( 'Encrypt existing backups', 'educore-recovery' ), 'secondary', 'submit', false );
				echo self::form( 'encrypt_existing', $inner ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
		}
		echo '<p class="description">' . esc_html__( 'The key is never stored in the database or inside any backup. Archives record only the key ID, so a restore can tell you which key it needs.', 'educore-recovery' ) . '</p>';
	}

	private static function tab_dr(): void {
		$h  = Scheduler::health();
		$lr = (array) $h['last_restore'];
		$lt = $h['last_tested'];
		$rep = $lt ? json_decode( (string) $lt->restore_test_report, true ) : array();
		echo '<h2>' . esc_html__( 'Recovery objectives', 'educore-recovery' ) . '</h2><table class="widefat striped" style="max-width:820px"><tbody>';
		echo '<tr><th scope="row">' . esc_html__( 'Recovery point objective (RPO) by schedule', 'educore-recovery' ) . '</th><td>' . ( $h['rpo_target_h'] ? esc_html( sprintf( /* translators: %d: hours */ __( 'Up to %d hours of data loss', 'educore-recovery' ), $h['rpo_target_h'] ) ) : esc_html__( 'No schedule enabled', 'educore-recovery' ) ) . '</td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Measured restore-test duration', 'educore-recovery' ) . '</th><td>' . ( $rep ? esc_html( sprintf( /* translators: 1: seconds, 2: rows */ __( '%1$s s for %2$s rows (database only, isolated tables)', 'educore-recovery' ), $rep['seconds'] ?? '?', number_format_i18n( (int) ( $rep['rows'] ?? 0 ) ) ) ) : esc_html__( 'Not measured yet', 'educore-recovery' ) ) . '</td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Recovery time objective (RTO)', 'educore-recovery' ) . '</th><td>' . ( $lr ? esc_html( sprintf( /* translators: %s: seconds */ __( 'Last full restore took %s s of processing (plus human decision time).', 'educore-recovery' ), $lr['seconds'] ?? '?' ) ) : esc_html__( 'Not claimed: no full restore has been executed on this installation yet. Rehearse in an isolated copy before relying on a figure.', 'educore-recovery' ) ) . '</td></tr>';
		echo '</tbody></table>';
		echo '<h2>' . esc_html__( 'Restore procedure', 'educore-recovery' ) . '</h2><ol>';
		foreach ( array(
			__( 'Declare the incident and stop changes (announce maintenance).', 'educore-recovery' ),
			__( 'Choose the recovery point: the newest backup that is verified and restore-tested, created before the incident.', 'educore-recovery' ),
			__( 'If the site itself is damaged, reinstall WordPress and the signed EduCore release first, then this plugin.', 'educore-recovery' ),
			__( 'Upload or copy the backup into backup storage if needed, then open Restore… and review validation, compatibility and the impact preview.', 'educore-recovery' ),
			__( 'Type the confirmation phrase. A safety snapshot is taken automatically, the site enters maintenance mode, the backup is loaded into staging tables, checked, and swapped in atomically.', 'educore-recovery' ),
			__( 'Verify: sign in, open a course, a gradebook and a certificate; check the restore report.', 'educore-recovery' ),
			__( 'Record the incident, the recovery point and the measured duration.', 'educore-recovery' ),
		) as $step ) {
			echo '<li>' . esc_html( $step ) . '</li>';
		}
		echo '</ol><p>' . esc_html__( 'Never rehearse a restore on the live site. Use “Test restore” (isolated tables) or a separate staging copy.', 'educore-recovery' ) . '</p>';
		echo '<p>' . esc_html__( 'Off-site copies: download a verified backup regularly and keep it in a separate location (and the encryption key in yet another place). Backups on the same server do not protect against loss of that server.', 'educore-recovery' ) . '</p>';
	}

	private static function wizard( int $id ): void {
		echo '<p><a href="' . esc_url( self::url() ) . '">← ' . esc_html__( 'Back to backups', 'educore-recovery' ) . '</a></p>';
		if ( ! current_user_can( 'manage_options' ) ) {
			echo '<p>' . esc_html__( 'Only a site administrator can restore.', 'educore-recovery' ) . '</p>';
			return;
		}
		$p = Restore::preview( $id );
		echo '<h2>' . esc_html__( 'Restore wizard', 'educore-recovery' ) . '</h2><ol class="ec-steps"><li>' . esc_html__( 'Select', 'educore-recovery' ) . ' ✓</li>';
		if ( empty( $p['backup'] ) ) {
			echo '<li>' . esc_html__( 'Validate', 'educore-recovery' ) . ' ✗</li></ol><div class="notice notice-error inline"><p>' . esc_html( implode( ' ', $p['errors'] ) ) . '</p></div>';
			return;
		}
		echo '<li>' . esc_html__( 'Validate', 'educore-recovery' ) . ' ✓</li><li>' . esc_html__( 'Compatibility', 'educore-recovery' ) . ' ' . ( $p['ok'] ? '✓' : '✗' ) . '</li></ol>';
		if ( ! $p['ok'] ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html( implode( ' ', $p['errors'] ) ) . '</p></div>';
			return;
		}
		echo '<h3>' . esc_html__( 'Impact preview', 'educore-recovery' ) . '</h3><p>' . esc_html( sprintf( /* translators: 1: date, 2: hours */ __( 'Recovery point: %1$s (%2$s hours ago). Everything changed after this moment in the tables below will be lost.', 'educore-recovery' ), $p['created_at'], $p['age_hours'] ) ) . '</p>';
		echo '<table class="widefat striped" style="max-width:640px"><thead><tr><th scope="col">' . esc_html__( 'Table', 'educore-recovery' ) . '</th><th scope="col">' . esc_html__( 'Rows now', 'educore-recovery' ) . '</th><th scope="col">' . esc_html__( 'Rows after restore', 'educore-recovery' ) . '</th></tr></thead><tbody>';
		foreach ( $p['tables'] as $t => $r ) {
			$diff = $r['current'] !== $r['backup'];
			echo '<tr' . ( $diff ? ' style="font-weight:600"' : '' ) . '><td><code>' . esc_html( $t ) . '</code></td><td>' . ( null === $r['current'] ? '—' : esc_html( number_format_i18n( $r['current'] ) ) ) . '</td><td>' . esc_html( number_format_i18n( $r['backup'] ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
		$inner  = '<h3>' . esc_html__( 'Confirm', 'educore-recovery' ) . '</h3><p>' . esc_html__( 'A safety snapshot of the current data is taken first. The site is in maintenance mode during the swap. You may need to sign in again afterwards.', 'educore-recovery' ) . '</p>';
		if ( $p['has_uploads'] ) {
			$inner .= '<p><label><input type="checkbox" name="uploads" value="1"> ' . esc_html__( 'Also restore uploaded files (overwrites files with the same name; adds missing files; deletes nothing)', 'educore-recovery' ) . '</label></p>';
		}
		/* translators: %s: confirmation phrase */
		$inner .= '<p><label for="ec-rc-confirm">' . sprintf( esc_html__( 'Type %s to confirm:', 'educore-recovery' ), '<code>' . esc_html( $p['phrase'] ) . '</code>' ) . '</label><br><input id="ec-rc-confirm" name="confirm" type="text" class="regular-text" autocomplete="off" required></p>';
		$inner .= get_submit_button( __( 'Restore now', 'educore-recovery' ), 'primary button-hero', 'submit', false );
		echo self::form( 'restore', $inner, array( 'id' => $id ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
	}

	public static function checks( array $checks ): array {
		$h = Scheduler::health();
		$checks[] = array(
			'label'   => 'Backup storage',
			'status'  => '' === Store::dir() ? 'fail' : ( $h['outside_webroot'] ? 'pass' : 'warn' ),
			'message' => '' === Store::dir() ? __( 'No writable backup storage.', 'educore-recovery' ) : ( $h['outside_webroot'] ? __( 'Backups are stored outside the web root.', 'educore-recovery' ) : __( 'Backups are stored in a protected, randomly named folder inside uploads (outside the web root is not writable on this host).', 'educore-recovery' ) ),
		);
		$checks[] = array(
			'label'   => 'Backup files present',
			'status'  => $h['missing_files'] ? 'fail' : 'pass',
			/* translators: %d: count */
			'message' => $h['missing_files'] ? sprintf( __( '%d backup archives listed in the history are missing from storage. Investigate (files deleted outside EduCore, storage moved) and delete the stale entries.', 'educore-recovery' ), $h['missing_files'] ) : __( 'Every listed backup archive is present in storage.', 'educore-recovery' ),
		);
		$checks[] = array(
			'label'   => 'Recent verified backup',
			'status'  => $h['last_verified_h'] <= 48 ? 'pass' : 'warn',
			'message' => is_finite( $h['last_verified_h'] ) ? sprintf( /* translators: %s: hours */ __( 'Last verified backup %s hours ago.', 'educore-recovery' ), number_format_i18n( $h['last_verified_h'], 1 ) ) : __( 'No verified backup yet. Create one in EduCore → Backup & Recovery.', 'educore-recovery' ),
		);
		$checks[] = array(
			'label'   => 'Restore tested',
			'status'  => $h['last_tested'] ? 'pass' : 'warn',
			'message' => $h['last_tested'] ? __( 'A backup has passed a non-destructive restore test.', 'educore-recovery' ) : __( 'No backup has been restore-tested yet.', 'educore-recovery' ),
		);
		$enc_status = ! $h['encrypted'] ? 'warn' : ( ( '' === $h['key_downloaded'] || $h['unencrypted'] ) ? 'warn' : 'pass' );
		$checks[]   = array(
			'label'   => 'Backup encryption',
			'status'  => $enc_status,
			'message' => ! $h['encrypted'] ? __( 'Backups are not encrypted. Create a key in Backup & Recovery → Schedule & retention.', 'educore-recovery' ) : ( '' === $h['key_downloaded'] ? __( 'Backups are encrypted, but the recovery key has not been downloaded for offline storage yet.', 'educore-recovery' ) : ( $h['unencrypted'] ? __( 'Backups are encrypted; some older unencrypted backups remain (encrypt them or let retention remove them).', 'educore-recovery' ) : __( 'Backups are encrypted and the recovery key is stored offline.', 'educore-recovery' ) ) ),
		);
		$checks[]   = array(
			'label'   => 'Backup scheduling',
			'status'  => $h['server_tick_h'] <= 3 ? 'pass' : 'warn',
			'message' => $h['server_tick_h'] <= 3 ? __( 'A server cron job is running the backup scheduler.', 'educore-recovery' ) : __( 'Backups depend on WordPress cron (site traffic). Add the cPanel cron command from Backup & Recovery → Schedule & retention.', 'educore-recovery' ),
		);
		return $checks;
	}
}
