<?php
namespace EduCore\Assessments;

use EduCore\Core\Schema as CoreSchema;

defined( 'ABSPATH' ) || exit;

final class Schema {

	public static function tables(): array {
		return array(
			'question_banks'    => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				course_id BIGINT UNSIGNED NOT NULL,
				title VARCHAR(191) NOT NULL,
				owner_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY course_id (course_id)",
			'questions'         => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				bank_id BIGINT UNSIGNED NOT NULL,
				course_id BIGINT UNSIGNED NOT NULL,
				lesson_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				type VARCHAR(20) NOT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'draft',
				usage_scope VARCHAR(12) NOT NULL DEFAULT 'any',
				difficulty VARCHAR(12) NOT NULL DEFAULT 'medium',
				current_version_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				dedupe_hash CHAR(64) NOT NULL DEFAULT '',
				created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY bank_status (bank_id,status),
				KEY course_status (course_id,status),
				KEY lesson_id (lesson_id),
				KEY dedupe_hash (dedupe_hash)",
			'question_versions' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				question_id BIGINT UNSIGNED NOT NULL,
				version_no INT UNSIGNED NOT NULL,
				lang VARCHAR(10) NOT NULL DEFAULT 'en',
				stem LONGTEXT NOT NULL,
				payload LONGTEXT NOT NULL,
				answer_key LONGTEXT NOT NULL,
				explanation LONGTEXT NULL,
				points DECIMAL(8,2) NOT NULL DEFAULT 1,
				used TINYINT(1) NOT NULL DEFAULT 0,
				created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY question_version_lang (question_id,version_no,lang)",
			'question_tags'     => "question_id BIGINT UNSIGNED NOT NULL,
				tag VARCHAR(60) NOT NULL,
				PRIMARY KEY  (question_id,tag),
				KEY tag (tag)",
			'assessments'       => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				course_id BIGINT UNSIGNED NOT NULL,
				lesson_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				title VARCHAR(191) NOT NULL,
				kind VARCHAR(12) NOT NULL DEFAULT 'quiz',
				status VARCHAR(20) NOT NULL DEFAULT 'draft',
				settings LONGTEXT NOT NULL,
				created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY course_status (course_id,status),
				KEY lesson_id (lesson_id)",
			'assessment_pools'  => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				assessment_id BIGINT UNSIGNED NOT NULL,
				position INT NOT NULL DEFAULT 0,
				question_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				qtype VARCHAR(20) NOT NULL DEFAULT '',
				lesson_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				tag VARCHAR(60) NOT NULL DEFAULT '',
				difficulty VARCHAR(12) NOT NULL DEFAULT '',
				draw_count INT UNSIGNED NOT NULL DEFAULT 1,
				points_each DECIMAL(8,2) NOT NULL DEFAULT 0,
				PRIMARY KEY  (id),
				KEY assessment_id (assessment_id)",
			'attempts'          => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				assessment_id BIGINT UNSIGNED NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				attempt_no INT UNSIGNED NOT NULL,
				state VARCHAR(12) NOT NULL DEFAULT 'open',
				seed CHAR(32) NOT NULL,
				started_at DATETIME NOT NULL,
				deadline_at DATETIME NULL,
				submitted_at DATETIME NULL,
				expired TINYINT(1) NOT NULL DEFAULT 0,
				score DECIMAL(10,2) NULL,
				max_score DECIMAL(10,2) NOT NULL DEFAULT 0,
				percent DECIMAL(6,2) NULL,
				passed TINYINT(1) NULL,
				released TINYINT(1) NOT NULL DEFAULT 0,
				released_at DATETIME NULL,
				open_lock TINYINT(1) NULL DEFAULT 1,
				PRIMARY KEY  (id),
				UNIQUE KEY assessment_user_no (assessment_id,user_id,attempt_no),
				UNIQUE KEY one_open (assessment_id,user_id,open_lock),
				KEY user_state (user_id,state),
				KEY state_deadline (state,deadline_at)",
			'attempt_items'     => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				attempt_id BIGINT UNSIGNED NOT NULL,
				position INT UNSIGNED NOT NULL,
				question_version_id BIGINT UNSIGNED NOT NULL,
				points DECIMAL(8,2) NOT NULL DEFAULT 1,
				option_order LONGTEXT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY attempt_position (attempt_id,position),
				KEY question_version_id (question_version_id)",
			'responses'         => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				attempt_item_id BIGINT UNSIGNED NOT NULL,
				answer LONGTEXT NULL,
				saved_at DATETIME NOT NULL,
				auto_score DECIMAL(8,2) NULL,
				final_score DECIMAL(8,2) NULL,
				needs_grading TINYINT(1) NOT NULL DEFAULT 0,
				graded_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				graded_at DATETIME NULL,
				feedback LONGTEXT NULL,
				rubric_scores LONGTEXT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY attempt_item_id (attempt_item_id),
				KEY needs_grading (needs_grading)",
			'rubrics'           => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				assessment_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				question_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				criteria LONGTEXT NOT NULL,
				PRIMARY KEY  (id),
				KEY question_id (question_id),
				KEY assessment_id (assessment_id)",
			'practice_tries'    => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				question_id BIGINT UNSIGNED NOT NULL,
				tries INT UNSIGNED NOT NULL DEFAULT 0,
				solved TINYINT(1) NOT NULL DEFAULT 0,
				revealed TINYINT(1) NOT NULL DEFAULT 0,
				last_answer LONGTEXT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY user_question (user_id,question_id)",
		);
	}

	public static function install(): void {
		CoreSchema::migrate( 'educore_assessments_db_version', EDUCORE_ASSESSMENTS_DB_VERSION, self::tables() );
		if ( ! wp_next_scheduled( 'educore_assessments_expire' ) ) {
			wp_schedule_event( time() + 120, 'educore_five_minutes', 'educore_assessments_expire' );
		}
	}

	/** Cheap per-request check: only runs migrations when the stored version is behind. */
	public static function maybe_install(): void {
		if ( (int) get_option( 'educore_assessments_db_version', 0 ) < EDUCORE_ASSESSMENTS_DB_VERSION ) {
			self::install();
		}
	}

	public static function repair(): void {
		delete_option( 'educore_assessments_db_version' );
		self::install();
	}

	public static function t( string $name ): string {
		return CoreSchema::table( $name );
	}
}
