<?php
/**
 * Plugin Name:       EduCore Certificates
 * Plugin URI:        https://educore.gorgy.org
 * Description:       Completion certificates for EduCore: templates (EN/FR/AR), unique IDs, PDF generation with Arabic support, public verification and revocation.
 * Version:           1.0.1
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core
 * Author:            GORGY.ORG
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-certificates
 * Domain Path:       /languages
 *
 * Bundles mPDF 8.2.5 (GPL-2.0) and its dependencies in /lib (see lib/README.md).
 *
 * @package EduCore\Certificates
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_CERTIFICATES_VERSION', '1.0.1' );
define( 'EDUCORE_CERTIFICATES_DB_VERSION', 1 );
define( 'EDUCORE_CERTIFICATES_FILE', __FILE__ );
define( 'EDUCORE_CERTIFICATES_DIR', plugin_dir_path( __FILE__ ) );

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Certificates', '1.0.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Certificates\\', EDUCORE_CERTIFICATES_DIR . 'src/' );
		\EduCore\Certificates\Plugin::boot();
	}
);

add_action(
	'admin_notices',
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) && current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'EduCore Certificates requires the EduCore Core plugin. It has not been loaded.', 'educore-certificates' ) . '</p></div>';
		}
	}
);

register_activation_hook(
	__FILE__,
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die( esc_html__( 'Please activate EduCore Core first.', 'educore-certificates' ), '', array( 'back_link' => true ) );
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Certificates\\', EDUCORE_CERTIFICATES_DIR . 'src/' );
		\EduCore\Certificates\Plugin::install();
	}
);
