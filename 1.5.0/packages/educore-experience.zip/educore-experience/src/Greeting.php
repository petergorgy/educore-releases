<?php
namespace EduCore\Experience;

defined( 'ABSPATH' ) || exit;

/**
 * Time-of-day greeting line. Wording is neutral about when people "should" study or sleep.
 * Administrators can replace any template per language; {name} is optional.
 */
final class Greeting {

	/** Built-in template for a state, with or without a name placeholder, in the current (or given) language. */
	public static function builtin( string $state, bool $with_name, string $lang = '' ): string {
		$switched = false;
		if ( '' !== $lang && function_exists( 'switch_to_locale' ) ) {
			$switched = switch_to_locale( array( 'en' => 'en_US', 'fr' => 'fr_FR', 'ar' => 'ar' )[ $lang ] ?? 'en_US' );
		}
		$t = $with_name ? array(
			/* translators: {name} is replaced with the person's preferred name. */
			'midnight'  => __( 'Hello, {name}. It’s a quiet hour — your learning is right where you left it.', 'educore-experience' ),
			/* translators: {name} is replaced with the person's preferred name. */
			'dawn'      => __( 'Good morning, {name}. A new day, a fresh start.', 'educore-experience' ),
			/* translators: {name} is replaced with the person's preferred name. */
			'morning'   => __( 'Good morning, {name}! Ready for something new?', 'educore-experience' ),
			/* translators: {name} is replaced with the person's preferred name. */
			'noon'      => __( 'Good afternoon, {name}. Here’s where you left off.', 'educore-experience' ),
			/* translators: {name} is replaced with the person's preferred name. */
			'afternoon' => __( 'Welcome back, {name}. Let’s make some progress.', 'educore-experience' ),
			/* translators: {name} is replaced with the person's preferred name. */
			'dusk'      => __( 'Good evening, {name}. Here’s your summary for today.', 'educore-experience' ),
			/* translators: {name} is replaced with the person's preferred name. */
			'evening'   => __( 'Good evening, {name}. Ready for a little revision?', 'educore-experience' ),
			/* translators: {name} is replaced with the person's preferred name. */
			'night'     => __( 'Hello, {name}. Your progress is saved — continue whenever you’re ready.', 'educore-experience' ),
		) : array(
			'midnight'  => __( 'Hello. It’s a quiet hour — your learning is right where you left it.', 'educore-experience' ),
			'dawn'      => __( 'Good morning. A new day, a fresh start.', 'educore-experience' ),
			'morning'   => __( 'Good morning! Ready for something new?', 'educore-experience' ),
			'noon'      => __( 'Good afternoon. Here’s where you left off.', 'educore-experience' ),
			'afternoon' => __( 'Welcome back. Let’s make some progress.', 'educore-experience' ),
			'dusk'      => __( 'Good evening. Here’s your summary for today.', 'educore-experience' ),
			'evening'   => __( 'Good evening. Ready for a little revision?', 'educore-experience' ),
			'night'     => __( 'Hello. Your progress is saved — continue whenever you’re ready.', 'educore-experience' ),
		);
		$out = $t[ $state ] ?? $t['afternoon'];
		if ( $switched ) {
			restore_previous_locale();
		}
		return $out;
	}

	/** The name to greet with, or '' when none should be used. Never falls back to the e-mail address or login. */
	public static function name( int $uid ): string {
		$p = Prefs::get( $uid );
		if ( ! $p['greet_by_name'] ) {
			return '';
		}
		if ( '' !== $p['preferred_name'] ) {
			return $p['preferred_name'];
		}
		$u = get_userdata( $uid );
		if ( ! $u ) {
			return '';
		}
		$first = trim( (string) get_user_meta( $uid, 'first_name', true ) );
		if ( '' !== $first ) {
			return $first;
		}
		$dn = trim( (string) $u->display_name );
		// A display name equal to the login or an e-mail address is not a name the person chose to show.
		if ( '' === $dn || $dn === $u->user_login || is_email( $dn ) ) {
			return '';
		}
		return (string) strtok( $dn, ' ' );
	}

	public static function line( int $uid, string $state ): string {
		$name = self::name( $uid );
		$lang = class_exists( '\EduCore\Core\I18n' ) ? \EduCore\Core\I18n::current() : 'en';
		$cfg  = (array) Settings::get( 'greetings' );
		$tpl  = (string) ( $cfg[ $lang ][ $state ] ?? '' );
		if ( '' === $tpl ) {
			$tpl = self::builtin( $state, '' !== $name );
		}
		if ( '' === $name ) {
			// Custom template with {name} but no name to show: drop the placeholder and the comma before it.
			$tpl = (string) preg_replace( '/[,،]?\s*\{name\}/u', '', $tpl );
		}
		return str_replace( '{name}', $name, $tpl );
	}
}
