<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Versioned schema for educore-core. Other packages use Schema::install_tables() with their own definitions.
 */
final class Schema {

	public static function table( string $name ): string {
		global $wpdb;
		return $wpdb->prefix . 'ec_' . $name;
	}

	/** @return array<string,string> table => column/index body */
	public static function core_tables(): array {
		return array(
			'programmes'         => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				code VARCHAR(64) NOT NULL,
				name VARCHAR(191) NOT NULL,
				country CHAR(2) NOT NULL DEFAULT 'EG',
				lang VARCHAR(10) NOT NULL DEFAULT 'en',
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY code (code)",
			'academic_periods'   => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				programme_id BIGINT UNSIGNED NOT NULL,
				parent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				type VARCHAR(20) NOT NULL,
				label VARCHAR(191) NOT NULL,
				position INT NOT NULL DEFAULT 0,
				starts_on DATE NULL,
				ends_on DATE NULL,
				PRIMARY KEY  (id),
				KEY programme_id (programme_id),
				KEY parent_id (parent_id)",
			'subjects'           => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				programme_id BIGINT UNSIGNED NOT NULL,
				code VARCHAR(64) NOT NULL,
				name VARCHAR(191) NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY programme_code (programme_id,code)",
			'curriculum_map'     => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				course_id BIGINT UNSIGNED NOT NULL,
				programme_id BIGINT UNSIGNED NOT NULL,
				period_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				subject_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				PRIMARY KEY  (id),
				UNIQUE KEY course_period_subject (course_id,period_id,subject_id),
				KEY programme_id (programme_id)",
			'translation_groups' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				object_type VARCHAR(32) NOT NULL,
				group_id BIGINT UNSIGNED NOT NULL,
				object_id BIGINT UNSIGNED NOT NULL,
				lang VARCHAR(10) NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY object (object_type,object_id),
				UNIQUE KEY group_lang (object_type,group_id,lang)",
			'course_staff'       => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				course_id BIGINT UNSIGNED NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				staff_role VARCHAR(20) NOT NULL DEFAULT 'instructor',
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY course_user (course_id,user_id),
				KEY user_id (user_id)",
			'enrollments'        => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				course_id BIGINT UNSIGNED NOT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				source VARCHAR(20) NOT NULL DEFAULT 'admin',
				starts_at DATETIME NOT NULL,
				expires_at DATETIME NULL,
				completed_at DATETIME NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY user_course (user_id,course_id),
				KEY course_status (course_id,status)",
			'lesson_progress'    => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				lesson_id BIGINT UNSIGNED NOT NULL,
				course_id BIGINT UNSIGNED NOT NULL,
				state VARCHAR(20) NOT NULL DEFAULT 'started',
				active_seconds INT UNSIGNED NOT NULL DEFAULT 0,
				first_seen_at DATETIME NOT NULL,
				last_seen_at DATETIME NOT NULL,
				completed_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY user_lesson (user_id,lesson_id),
				KEY course_user (course_id,user_id)",
			'notes'              => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				lesson_id BIGINT UNSIGNED NOT NULL,
				type VARCHAR(12) NOT NULL DEFAULT 'note',
				body TEXT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY user_lesson (user_id,lesson_id)",
			'consents'           => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				consent_type VARCHAR(40) NOT NULL,
				version VARCHAR(20) NOT NULL,
				granted_by VARCHAR(12) NOT NULL DEFAULT 'self',
				guardian_link_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				granted_at DATETIME NOT NULL,
				withdrawn_at DATETIME NULL,
				evidence_hash CHAR(64) NOT NULL DEFAULT '',
				PRIMARY KEY  (id),
				KEY user_type (user_id,consent_type)",
			'guardian_links'     => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				student_id BIGINT UNSIGNED NOT NULL,
				guardian_email VARCHAR(191) NOT NULL,
				guardian_name VARCHAR(191) NOT NULL DEFAULT '',
				guardian_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				token_hash CHAR(64) NOT NULL DEFAULT '',
				status VARCHAR(20) NOT NULL DEFAULT 'pending',
				created_at DATETIME NOT NULL,
				verified_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY student_guardian (student_id,guardian_email),
				KEY token_hash (token_hash)",
			'audit_events'       => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				actor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				action VARCHAR(64) NOT NULL,
				object_type VARCHAR(32) NOT NULL DEFAULT '',
				object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				ip_hash CHAR(64) NOT NULL DEFAULT '',
				context LONGTEXT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY object (object_type,object_id),
				KEY action (action),
				KEY created_at (created_at)",
			'rate_limits'        => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				bucket VARCHAR(40) NOT NULL,
				key_hash CHAR(64) NOT NULL,
				window_start INT UNSIGNED NOT NULL,
				hits INT UNSIGNED NOT NULL DEFAULT 0,
				PRIMARY KEY  (id),
				UNIQUE KEY bucket_key_window (bucket,key_hash,window_start)",
			'activity'           => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				course_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				day DATE NOT NULL,
				events INT UNSIGNED NOT NULL DEFAULT 0,
				PRIMARY KEY  (id),
				UNIQUE KEY user_course_day (user_id,course_id,day),
				KEY day_course (day,course_id)",
			'search_index'       => "object_id BIGINT UNSIGNED NOT NULL,
				object_type VARCHAR(32) NOT NULL,
				lang VARCHAR(10) NOT NULL DEFAULT '',
				normalized LONGTEXT NOT NULL,
				PRIMARY KEY  (object_id),
				KEY object_type (object_type)",
		);
	}

	/**
	 * Create/upgrade tables via dbDelta. Idempotent.
	 *
	 * @param array<string,string> $tables
	 */
	public static function install_tables( array $tables ): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		foreach ( $tables as $name => $body ) {
			$sql = 'CREATE TABLE ' . self::table( $name ) . " (\n" . preg_replace( '/^\s+/m', '', $body ) . "\n) {$charset};";
			dbDelta( $sql );
		}
	}

	/** @param array<string,string> $tables */
	public static function missing_tables( array $tables ): array {
		global $wpdb;
		$missing = array();
		foreach ( array_keys( $tables ) as $name ) {
			$t = self::table( $name );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) !== $t ) {
				$missing[] = $name;
			}
		}
		return $missing;
	}

	/**
	 * Run versioned migrations for a package. $migrations: version(int) => callable.
	 */
	public static function migrate( string $option, int $target, array $tables, array $migrations = array() ): void {
		$current = (int) get_option( $option, 0 );
		if ( $current >= $target && empty( self::missing_tables( $tables ) ) ) {
			return;
		}
		self::install_tables( $tables );
		ksort( $migrations );
		foreach ( $migrations as $version => $callable ) {
			if ( $version > $current && $version <= $target ) {
				call_user_func( $callable );
			}
		}
		update_option( $option, $target, false );
	}

	public static function now(): string {
		return current_time( 'mysql', true );
	}
}
