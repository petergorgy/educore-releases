<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Lesson plans (+ reusable templates) linked to classes and published curriculum lessons; teaching calendar. */
final class Planner {
	public const FIELDS   = array( 'title', 'objectives', 'target', 'materials', 'activities', 'exercises', 'assessment', 'homework', 'notes' );
	public const STATUSES = array( 'planned', 'delivered', 'cancelled' );

	private static function t(): string {
		return Schema::table( 'th_lesson_plans' );
	}

	/** @return int|\WP_Error */
	public static function save( array $in, int $actor, int $id = 0 ) {
		global $wpdb;
		$title = sanitize_text_field( (string) ( $in['title'] ?? '' ) );
		if ( '' === $title ) {
			return new \WP_Error( 'ec_th_title', __( 'A title is required.', 'educore-teaching-hub' ) );
		}
		$class  = absint( $in['class_id'] ?? 0 );
		$lesson = absint( $in['lesson_id'] ?? 0 );
		if ( $lesson && Content::LESSON !== get_post_type( $lesson ) ) {
			return new \WP_Error( 'ec_th_lesson', __( 'Unknown curriculum lesson.', 'educore-teaching-hub' ) );
		}
		$date = sanitize_text_field( (string) ( $in['teach_date'] ?? '' ) );
		if ( '' !== $date && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return new \WP_Error( 'ec_th_date', __( 'Use the date format YYYY-MM-DD.', 'educore-teaching-hub' ) );
		}
		$row = array(
			'class_id'     => $class,
			'lesson_id'    => $lesson,
			'title'        => mb_substr( $title, 0, 190 ),
			'teach_date'   => '' === $date ? null : $date,
			'duration_min' => max( 5, min( 600, absint( $in['duration_min'] ?? 45 ) ) ),
			'status'       => in_array( $in['status'] ?? 'planned', self::STATUSES, true ) ? $in['status'] : 'planned',
			'is_template'  => empty( $in['is_template'] ) ? 0 : 1,
			'updated_at'   => Schema::now(),
		);
		foreach ( array_diff( self::FIELDS, array( 'title' ) ) as $f ) {
			$row[ $f ] = 'target' === $f ? mb_substr( sanitize_text_field( (string) ( $in[ $f ] ?? '' ) ), 0, 190 ) : sanitize_textarea_field( (string) ( $in[ $f ] ?? '' ) );
		}
		if ( $id ) {
			$wpdb->update( self::t(), $row, array( 'id' => $id ) );
		} else {
			$row['owner_id']   = $actor;
			$row['created_at'] = $row['updated_at'];
			$wpdb->insert( self::t(), $row );
			$id = (int) $wpdb->insert_id;
		}
		Audit::log( 'lesson_plan.saved', 'lesson_plan', $id, array( 'status' => $row['status'], 'class_id' => $class ) );
		return $id;
	}

	public static function get( int $id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t() . ' WHERE id=%d', $id ), ARRAY_A ) ?: null;
	}

	/** Owner, staff of the plan's class, or manager. */
	public static function can_edit( int $user_id, array $plan ): bool {
		return (int) $plan['owner_id'] === $user_id || Caps::is_manager( $user_id ) || ( (int) $plan['class_id'] && null !== Caps::class_role( $user_id, (int) $plan['class_id'] ) );
	}

	/** Copy a template (or plan) into a new planned lesson for a class/date. @return int|\WP_Error */
	public static function from_template( int $template_id, int $class_id, string $date, int $actor ) {
		$tpl = self::get( $template_id );
		if ( ! $tpl || ( (int) $tpl['owner_id'] !== $actor && ! Caps::is_manager( $actor ) ) ) {
			return new \WP_Error( 'ec_th_tpl', __( 'Template not found.', 'educore-teaching-hub' ) );
		}
		$in                = $tpl;
		$in['class_id']    = $class_id;
		$in['teach_date']  = $date;
		$in['is_template'] = 0;
		$in['status']      = 'planned';
		return self::save( $in, $actor );
	}

	/** @return array<int,array<string,mixed>> */
	public static function list_for( int $user_id, array $class_ids, string $from = '', string $to = '', bool $templates = false ): array {
		global $wpdb;
		$t     = self::t();
		$scope = array( $wpdb->prepare( 'owner_id=%d', $user_id ) );
		if ( $class_ids ) {
			$scope[] = 'class_id IN (' . implode( ',', array_map( 'intval', $class_ids ) ) . ')';
		}
		$where = '(' . implode( ' OR ', $scope ) . ')' . $wpdb->prepare( ' AND is_template=%d', $templates ? 1 : 0 );
		if ( $from ) {
			$where .= $wpdb->prepare( ' AND teach_date>=%s', $from );
		}
		if ( $to ) {
			$where .= $wpdb->prepare( ' AND teach_date<=%s', $to );
		}
		return $wpdb->get_results( "SELECT * FROM {$t} WHERE {$where} ORDER BY teach_date IS NULL, teach_date ASC, id ASC LIMIT 500", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/**
	 * Calendar items (local dates) for a user between two dates: lesson plans, assignment deadlines,
	 * tutoring sessions and (if installed) assessment closing times.
	 *
	 * @return array<string,array<int,array{type:string,title:string,time:string,url:string}>>
	 */
	public static function calendar( int $user_id, string $from, string $to ): array {
		global $wpdb;
		$days    = array();
		$add     = static function ( string $day, array $item ) use ( &$days ) {
			$days[ $day ][] = $item;
		};
		$classes = Caps::classes_of( $user_id );
		foreach ( self::list_for( $user_id, $classes, $from, $to ) as $p ) {
			$add( $p['teach_date'], array( 'type' => 'lesson', 'title' => $p['title'], 'time' => '', 'url' => Portal::url( 'planner', array( 'plan' => $p['id'] ) ) ) );
		}
		$tz_from = Plugin::local_to_utc( $from . ' 00:00' );
		$tz_to   = Plugin::local_to_utc( $to . ' 23:59' );
		if ( $classes ) {
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, title, due_at FROM ' . Schema::table( 'th_assignments' ) . " WHERE status='published' AND class_id IN (" . implode( ',', $classes ) . ') AND due_at BETWEEN %s AND %s', $tz_from, $tz_to ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
			foreach ( $rows as $r ) {
				$add( Plugin::local( $r['due_at'], 'Y-m-d' ), array( 'type' => 'deadline', 'title' => $r['title'], 'time' => Plugin::local( $r['due_at'], 'H:i' ), 'url' => Portal::url( 'assignment', array( 'id' => $r['id'] ) ) ) );
			}
		}
		if ( user_can( $user_id, 'ec_tutor_sessions' ) ) {
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, subject, starts_at, status FROM ' . Schema::table( 'th_sessions' ) . " WHERE tutor_id=%d AND status IN ('requested','confirmed','completed') AND starts_at BETWEEN %s AND %s", $user_id, $tz_from, $tz_to ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
			foreach ( $rows as $r ) {
				$add( Plugin::local( $r['starts_at'], 'Y-m-d' ), array( 'type' => 'session-' . $r['status'], 'title' => $r['subject'] ?: __( 'Tutoring session', 'educore-teaching-hub' ), 'time' => Plugin::local( $r['starts_at'], 'H:i' ), 'url' => Portal::url( 'session', array( 'id' => $r['id'] ) ) ) );
			}
		}
		/** Other packages (assessments) can add exam dates. */
		$days = (array) apply_filters( 'educore/th/calendar', $days, $user_id, $from, $to );
		ksort( $days );
		return $days;
	}
}
