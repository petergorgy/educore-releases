<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

final class Cron {
	public const HOURLY = 'educore_hourly';
	public const DAILY  = 'educore_daily';

	public static function register(): void {
		add_action( self::HOURLY, array( Enrollment::class, 'expire_due' ) );
		add_action( self::DAILY, array( RateLimiter::class, 'cleanup' ) );
		add_action( self::DAILY, array( self::class, 'retention' ) );
		add_action( 'init', array( self::class, 'schedule' ) );
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::HOURLY ) ) {
			wp_schedule_event( time() + 300, 'hourly', self::HOURLY );
		}
		if ( ! wp_next_scheduled( self::DAILY ) ) {
			wp_schedule_event( time() + 600, 'daily', self::DAILY );
		}
	}

	public static function unschedule(): void {
		wp_clear_scheduled_hook( self::HOURLY );
		wp_clear_scheduled_hook( self::DAILY );
	}

	public static function retention(): void {
		$days = (int) get_option( 'educore_audit_retention_days', 730 );
		if ( $days > 0 ) {
			Audit::purge_older_than( $days );
		}
	}
}
