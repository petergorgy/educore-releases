<?php
/**
 * Plugin Name:       EduCore Analytics
 * Plugin URI:        https://educore.gorgy.org
 * Description:       Learning analytics for EduCore: defined metrics, dashboards, drilldowns and CSV/XLSX exports from real records.
 * Version:           1.0.2
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core
 * Author:            GORGY.ORG
 * Author URI:        https://gorgy.org
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-analytics
 * Domain Path:       /languages
 *
 * @package EduCore\Analytics
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_ANALYTICS_VERSION', '1.0.2' );
define( 'EDUCORE_ANALYTICS_DB_VERSION', 1 );
define( 'EDUCORE_ANALYTICS_FILE', __FILE__ );
define( 'EDUCORE_ANALYTICS_DIR', plugin_dir_path( __FILE__ ) );
define( 'EDUCORE_ANALYTICS_URL', plugin_dir_url( __FILE__ ) );

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Analytics', '1.0.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Analytics\\', EDUCORE_ANALYTICS_DIR . 'src/' );
		\EduCore\Analytics\Plugin::boot();
	}
);

add_action(
	'admin_notices',
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) && current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'EduCore Analytics requires the EduCore Core plugin. It has not been loaded.', 'educore-analytics' ) . '</p></div>';
		}
	}
);

register_deactivation_hook( __FILE__, static fn() => wp_clear_scheduled_hook( 'educore_analytics_daily' ) );
