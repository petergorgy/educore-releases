<?php
namespace EduCore\Workspace\Assess;

use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/**
 * `educore/v1/bank/*` and `educore/v1/assess/*`. The permission callback is a coarse capability gate; every
 * callback passes the course id to the service, which re-checks capability + course scope + object ownership.
 */
final class Rest {
	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
		add_action( 'template_redirect', array( Bank::class, 'maybe_download' ), 5 );
	}

	public static function routes(): void {
		if ( ! Bank::available() ) {
			return;
		}
		$bank   = static fn() => Bank::can_any( get_current_user_id() );
		$assess = static fn() => Builder::can_any( get_current_user_id() );
		$int    = array( 'type' => 'integer', 'required' => true, 'minimum' => 1 );
		$r      = static function ( string $route, string $m, callable $cb, callable $perm, array $args = array() ) {
			register_rest_route( 'educore/v1', $route, array( 'methods' => $m, 'callback' => $cb, 'permission_callback' => $perm, 'args' => $args ) );
		};
		$c  = array( 'course' => $int );
		$ci = array( 'course' => $int, 'id' => $int );
		$r( '/bank/(?P<course>\d+)/questions', 'POST', array( self::class, 'q_create' ), $bank, $c );
		$r( '/bank/(?P<course>\d+)/questions/(?P<id>\d+)', 'POST', array( self::class, 'q_save' ), $bank, $ci );
		$r( '/bank/(?P<course>\d+)/questions/(?P<id>\d+)/status', 'POST', array( self::class, 'q_status' ), $bank, $ci + array( 'status' => array( 'type' => 'string', 'required' => true, 'enum' => array( 'draft', 'review', 'published', 'archived' ) ) ) );
		$r( '/bank/(?P<course>\d+)/questions/(?P<id>\d+)/duplicate', 'POST', array( self::class, 'q_duplicate' ), $bank, $ci );
		$r( '/bank/(?P<course>\d+)/imports', 'POST', array( self::class, 'import' ), $bank, $c );
		$r( '/bank/(?P<course>\d+)/imports/(?P<id>\d+)/mode', 'POST', array( self::class, 'import_mode' ), $bank, $ci + array( 'mode' => array( 'type' => 'string', 'required' => true, 'enum' => array( 'skip', 'update', 'duplicate' ) ) ) );
		$r( '/bank/(?P<course>\d+)/imports/(?P<id>\d+)/commit', 'POST', array( self::class, 'import_commit' ), $bank, $ci );
		$r( '/bank/(?P<course>\d+)/imports/(?P<id>\d+)/cancel', 'POST', array( self::class, 'import_cancel' ), $bank, $ci );
		$r( '/assess/(?P<course>\d+)/assessments', 'POST', array( self::class, 'a_create' ), $assess, $c );
		$r( '/assess/(?P<course>\d+)/assessments/(?P<id>\d+)', 'POST', array( self::class, 'a_save' ), $assess, $ci );
		$r( '/assess/(?P<course>\d+)/assessments/(?P<id>\d+)/status', 'POST', array( self::class, 'a_status' ), $assess, $ci + array( 'status' => array( 'type' => 'string', 'required' => true, 'enum' => array( 'draft', 'published', 'archived' ) ) ) );
		$r( '/assess/(?P<course>\d+)/assessments/(?P<id>\d+)/duplicate', 'POST', array( self::class, 'a_duplicate' ), $assess, $ci );
		$r( '/assess/(?P<course>\d+)/template', 'POST', array( self::class, 'a_template' ), $assess, $c + array( 'lesson_id' => array( 'type' => 'integer', 'default' => 0 ) ) );
	}

	private static function guard() {
		return RateLimiter::hit( 'rest_write' ) ? null : new \WP_Error( 'ec_ws_rate', __( 'Too many changes in a short time. Please wait a moment.', 'educore-workspace' ), array( 'status' => 429 ) );
	}

	private static function uid(): int {
		return get_current_user_id();
	}

	private static function ok( array $extra = array(), int $status = 200 ): \WP_REST_Response {
		return new \WP_REST_Response( array( 'ok' => true ) + $extra, $status );
	}

	/* ---------- questions ---------- */

	public static function q_create( \WP_REST_Request $q ) {
		$res = self::guard() ?? Bank::save( self::uid(), (int) $q['course'], 0, $q->get_params() );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$url = View::url( array( 'bank' => (int) $q['course'], 'q' => $res['id'], 'ec_msg' => $res['duplicates'] ? 'dup' : 'qsaved' ) );
		return self::ok( $res + array( 'url' => $url ), 201 );
	}

	public static function q_save( \WP_REST_Request $q ) {
		$res = self::guard() ?? Bank::save( self::uid(), (int) $q['course'], (int) $q['id'], $q->get_params() );
		return is_wp_error( $res ) ? $res : self::ok( $res );
	}

	public static function q_status( \WP_REST_Request $q ) {
		$res = self::guard() ?? Bank::set_status( self::uid(), (int) $q['course'], (int) $q['id'], (string) $q['status'] );
		return is_wp_error( $res ) ? $res : self::ok();
	}

	public static function q_duplicate( \WP_REST_Request $q ) {
		$res = self::guard() ?? Bank::duplicate( self::uid(), (int) $q['course'], (int) $q['id'] );
		return is_wp_error( $res ) ? $res : self::ok( array( 'id' => $res, 'url' => View::url( array( 'bank' => (int) $q['course'], 'q' => $res, 'ec_msg' => 'qcopied' ) ) ), 201 );
	}

	/* ---------- import ---------- */

	public static function import( \WP_REST_Request $q ) {
		$e = self::guard();
		if ( $e ) {
			return $e;
		}
		$files = $q->get_file_params();
		if ( empty( $files['file'] ) || ! is_array( $files['file'] ) ) {
			return new \WP_Error( 'ec_bank_upload', __( 'Choose a file to import.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'file' => 'required' ) ) );
		}
		$res = Bank::upload( self::uid(), (int) $q['course'], $files['file'], array( 'format' => (string) $q['format'], 'mode' => (string) $q['mode'], 'status' => (string) $q['status'], 'lang' => (string) $q['lang'] ) );
		return is_wp_error( $res ) ? $res : self::ok( array( 'job' => $res, 'url' => View::url( array( 'bank' => (int) $q['course'], 'job' => $res ) ) ), 201 );
	}

	private static function job_in_course( \WP_REST_Request $q ): bool {
		$job = Bank::job( self::uid(), (int) $q['id'] );
		return $job && (int) $job['course_id'] === (int) $q['course'];
	}

	public static function import_mode( \WP_REST_Request $q ) {
		if ( ! self::job_in_course( $q ) ) {
			return new \WP_Error( 'ec_bank_forbidden', __( 'Import not found.', 'educore-workspace' ), array( 'status' => 404 ) );
		}
		$res = self::guard() ?? Bank::set_mode( self::uid(), (int) $q['id'], (string) $q['mode'] );
		return is_wp_error( $res ) ? $res : self::ok( array( 'summary' => $res ) );
	}

	public static function import_commit( \WP_REST_Request $q ) {
		if ( ! self::job_in_course( $q ) ) {
			return new \WP_Error( 'ec_bank_forbidden', __( 'Import not found.', 'educore-workspace' ), array( 'status' => 404 ) );
		}
		$res = self::guard() ?? Bank::commit( self::uid(), (int) $q['id'] );
		return is_wp_error( $res ) ? $res : self::ok( array( 'summary' => $res ) );
	}

	public static function import_cancel( \WP_REST_Request $q ) {
		if ( ! self::job_in_course( $q ) ) {
			return new \WP_Error( 'ec_bank_forbidden', __( 'Import not found.', 'educore-workspace' ), array( 'status' => 404 ) );
		}
		$res = self::guard() ?? Bank::cancel( self::uid(), (int) $q['id'] );
		return is_wp_error( $res ) ? $res : self::ok( array( 'url' => View::url( array( 'bank' => (int) $q['course'], 'x' => 'import' ) ) ) );
	}

	/* ---------- assessments ---------- */

	public static function a_create( \WP_REST_Request $q ) {
		$res = self::guard() ?? Builder::save( self::uid(), (int) $q['course'], 0, $q->get_params() );
		return is_wp_error( $res ) ? $res : self::ok( array( 'id' => $res, 'url' => View::url( array( 'assess' => (int) $q['course'], 'a' => $res, 'ec_msg' => 'asaved' ) ) ), 201 );
	}

	public static function a_save( \WP_REST_Request $q ) {
		$res = self::guard() ?? Builder::save( self::uid(), (int) $q['course'], (int) $q['id'], $q->get_params() );
		return is_wp_error( $res ) ? $res : self::ok( array( 'id' => $res ) );
	}

	public static function a_status( \WP_REST_Request $q ) {
		$res = self::guard() ?? Builder::set_status( self::uid(), (int) $q['course'], (int) $q['id'], (string) $q['status'] );
		return is_wp_error( $res ) ? $res : self::ok();
	}

	public static function a_duplicate( \WP_REST_Request $q ) {
		$res = self::guard() ?? Builder::duplicate( self::uid(), (int) $q['course'], (int) $q['id'] );
		return is_wp_error( $res ) ? $res : self::ok( array( 'id' => $res, 'url' => View::url( array( 'assess' => (int) $q['course'], 'a' => $res, 'ec_msg' => 'acopied' ) ) ), 201 );
	}

	public static function a_template( \WP_REST_Request $q ) {
		$res = self::guard() ?? Builder::template( self::uid(), (int) $q['course'], (int) $q['lesson_id'] );
		return is_wp_error( $res ) ? $res : self::ok( array( 'id' => $res, 'url' => View::url( array( 'assess' => (int) $q['course'], 'a' => $res, 'ec_msg' => 'asaved' ) ) ), 201 );
	}
}
