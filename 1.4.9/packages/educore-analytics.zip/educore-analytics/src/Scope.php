<?php
namespace EduCore\Analytics;

use EduCore\Core\Content;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/** Who may see which analytics. Server-side, object-scoped through core meta capabilities. */
final class Scope {

	/** @return int[] courses whose records the user may analyse */
	public static function courses_for( int $user_id ): array {
		if ( user_can( $user_id, 'ec_manage_all_courses' ) ) {
			return array_map( 'intval', get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ), 'posts_per_page' => -1, 'fields' => 'ids' ) ) );
		}
		return array_values( array_filter( Staff::courses_of( $user_id ), static fn( $c ) => user_can( $user_id, 'ec_view_course_records', $c ) ) );
	}

	public static function is_global( int $user_id ): bool {
		return user_can( $user_id, 'ec_manage_all_courses' ) && user_can( $user_id, 'ec_view_analytics' );
	}

	/**
	 * Restrict filters to what the viewer may see. Returns WP_Error(403) when a requested course is out of scope.
	 *
	 * @return Filters|\WP_Error
	 */
	public static function apply( int $user_id, Filters $f ) {
		if ( ! user_can( $user_id, 'ec_view_analytics' ) ) {
			return new \WP_Error( 'educore_forbidden', __( 'You do not have access to analytics.', 'educore-analytics' ), array( 'status' => 403 ) );
		}
		$allowed = self::courses_for( $user_id );
		if ( null === $f->course_ids ) {
			$f->course_ids = $allowed;
			return $f;
		}
		foreach ( $f->course_ids as $c ) {
			if ( ! in_array( $c, $allowed, true ) ) {
				return new \WP_Error( 'educore_forbidden', __( 'You cannot view analytics for this course.', 'educore-analytics' ), array( 'status' => 403 ) );
			}
		}
		return $f;
	}

	/** Exports: ec_export_reports + course scope; global reports require manage-all. */
	public static function can_export( int $user_id, ?int $course_id ): bool {
		if ( ! user_can( $user_id, 'ec_export_reports' ) ) {
			return false;
		}
		if ( null === $course_id || 0 === $course_id ) {
			return user_can( $user_id, 'ec_manage_all_courses' );
		}
		return user_can( $user_id, 'ec_view_course_records', $course_id );
	}
}
