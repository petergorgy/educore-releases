<?php
namespace EduCore\Identity;

defined( 'ABSPATH' ) || exit;

/**
 * Facebook Login (manually built flow): exchange the code, inspect the token with debug_token (must belong to this app
 * and be valid), then read id/name/email with appsecret_proof. The access token is used once and discarded.
 */
final class Facebook {

	/** @return array{sub:string,email:string,email_verified:bool,name:string}|\WP_Error */
	public static function identity( string $p, string $code ) {
		$def    = Providers::def( $p );
		$cfg    = Providers::config( $p );
		$app    = (string) $cfg['client_id'];
		$secret = Providers::secret( $p );
		$tok_url = add_query_arg(
			array( 'client_id' => rawurlencode( $app ), 'redirect_uri' => rawurlencode( Providers::callback_url( $p ) ), 'client_secret' => rawurlencode( $secret ), 'code' => rawurlencode( $code ) ),
			Providers::expand( (string) $def['token'], $p )
		);
		$tok = Oidc::get_json( $tok_url, $p );
		if ( is_wp_error( $tok ) || empty( $tok['access_token'] ) ) {
			return new \WP_Error( 'educore_id_token', 'Facebook token exchange failed.' );
		}
		$at  = (string) $tok['access_token'];
		$dbg = Oidc::get_json( add_query_arg( array( 'input_token' => rawurlencode( $at ), 'access_token' => rawurlencode( $app . '|' . $secret ) ), (string) $def['debug'] ), $p );
		$d   = is_array( $dbg ) ? (array) ( $dbg['data'] ?? array() ) : array();
		if ( is_wp_error( $dbg ) || empty( $d['is_valid'] ) || (string) ( $d['app_id'] ?? '' ) !== $app || empty( $d['user_id'] ) ) {
			return new \WP_Error( 'educore_id_audience', 'Facebook token does not belong to this app.' );
		}
		$me = Oidc::get_json(
			add_query_arg( array( 'fields' => 'id,name,email', 'access_token' => rawurlencode( $at ), 'appsecret_proof' => hash_hmac( 'sha256', $at, $secret ) ), Providers::expand( (string) $def['me'], $p ) ),
			$p
		);
		if ( is_wp_error( $me ) || empty( $me['id'] ) || (string) $me['id'] !== (string) $d['user_id'] ) {
			return new \WP_Error( 'educore_id_sub', 'Facebook profile could not be confirmed.' );
		}
		return array(
			'sub'            => (string) $me['id'],
			'email'          => sanitize_email( (string) ( $me['email'] ?? '' ) ),
			'email_verified' => false, // Not reliable enough to match or create accounts by.
			'name'           => sanitize_text_field( (string) ( $me['name'] ?? '' ) ),
		);
	}
}
