<?php
namespace EduCore\Workspace;

use EduCore\Analytics\AssessmentSource;
use EduCore\Analytics\Dictionary;
use EduCore\Analytics\Export;
use EduCore\Analytics\Filters;
use EduCore\Analytics\Metrics;
use EduCore\Analytics\Scope;
use EduCore\Core\Curriculum;

defined( 'ABSPATH' ) || exit;

/**
 * Learning analytics in the workspace: `/manage/?v=analytics` (academic managers, administrators) and
 * `/studio/?v=analytics` (instructors). Read-only. Every number comes from EduCore\Analytics\Metrics after
 * Scope::apply() has limited the filters to the courses the viewer may analyse; exports reuse the analytics
 * package's nonce- and scope-checked download endpoint. Charts are rendered as accessible tables with CSS bars.
 */
final class Insights {

	public static function available(): bool {
		return class_exists( Metrics::class ) && class_exists( Scope::class );
	}

	public static function can( int $uid ): bool {
		return $uid > 0 && self::available() && user_can( $uid, 'ec_view_analytics' );
	}

	private static function q( string $k ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filters.
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
	}

	private static function def( string $id ): string {
		$m = Dictionary::get( $id );
		return $m ? ' <span class="ec-an-def" title="' . esc_attr( $m['definition'] ) . '">(' . esc_html( $id ) . ')</span>' : '';
	}

	private static function pct( $v ): string {
		return null === $v ? '—' : number_format_i18n( (float) $v, 1 ) . '%';
	}

	private static function table( array $head, array $rows, string $caption ): string {
		if ( ! $rows ) {
			return '<p class="ec-muted">' . esc_html__( 'No data in this range.', 'educore-workspace' ) . '</p>';
		}
		$o = '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><caption class="screen-reader-text">' . esc_html( $caption ) . '</caption><thead><tr>';
		foreach ( $head as $h ) {
			$o .= '<th scope="col">' . esc_html( $h ) . '</th>';
		}
		$o .= '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$o .= '<tr>';
			foreach ( $r as $c ) {
				$o .= '<td>' . ( is_array( $c ) ? $c['html'] : esc_html( (string) $c ) ) . '</td>';
			}
			$o .= '</tr>';
		}
		return $o . '</tbody></table></div>';
	}

	/** Horizontal bars for 0–100 values (with the numbers as text, so nothing depends on colour or shape). */
	private static function bars( array $pairs, string $caption, bool $percent = true ): string {
		if ( ! $pairs ) {
			return '<p class="ec-muted">' . esc_html__( 'No data in this range.', 'educore-workspace' ) . '</p>';
		}
		$max = $percent ? 100 : max( 1, max( array_map( 'floatval', array_values( $pairs ) ) ) );
		$o   = '<ul class="ec-an-bars" aria-label="' . esc_attr( $caption ) . '">';
		foreach ( $pairs as $label => $v ) {
			$w  = null === $v ? 0 : max( 0, min( 100, (float) $v * 100 / $max ) );
			$o .= '<li><span class="ec-an-bars__l">' . esc_html( (string) $label ) . '</span><span class="ec-an-bars__t" aria-hidden="true"><span style="inline-size:' . esc_attr( (string) round( $w, 1 ) ) . '%"></span></span><span class="ec-an-bars__v">' . esc_html( $percent ? self::pct( $v ) : number_format_i18n( (float) $v ) ) . '</span></li>';
		}
		return $o . '</ul>';
	}

	/** Label → value pairs that survive duplicate labels. */
	private static function numbered( array $rows, string $label, string $value ): array {
		$out = array();
		foreach ( array_values( $rows ) as $i => $r ) {
			$out[ ( $i + 1 ) . '. ' . $r[ $label ] ] = $r[ $value ];
		}
		return $out;
	}

	private static function export( string $type, Filters $f, bool $allowed ): string {
		if ( ! $allowed || ! class_exists( Export::class ) ) {
			return '';
		}
		return ' <span class="ec-an-export"><a class="ec-btn ec-btn--small" href="' . esc_url( Export::url( $type, 'csv', $f ) ) . '">CSV</a> <a class="ec-btn ec-btn--small" href="' . esc_url( Export::url( $type, 'xlsx', $f ) ) . '">XLSX</a></span>';
	}

	public static function render( int $uid, string $ws ): string {
		Shell::title( __( 'Learning analytics', 'educore-workspace' ) );
		$home = 'manage' === $ws ? array( __( 'Management', 'educore-workspace' ), Pages::url( 'manage' ) ) : array( __( 'Course Studio', 'educore-workspace' ), Pages::url( 'studio' ) );
		Shell::crumbs( array( $home, array( __( 'Learning analytics', 'educore-workspace' ) ) ) );
		if ( ! self::can( $uid ) ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'You do not have access to analytics.', 'educore-workspace' ) . '</div>';
		}
		$in = array();
		foreach ( array( 'from', 'to', 'course', 'programme', 'year' ) as $k ) {
			if ( '' !== self::q( $k ) ) {
				$in[ $k ] = self::q( $k );
			}
		}
		$f = Scope::apply( $uid, new Filters( $in ) );
		if ( is_wp_error( $f ) ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html( $f->get_error_message() ) . '</div>';
		}
		$allowed = Scope::courses_for( $uid );
		$course  = ( ! empty( $in['course'] ) && 1 === count( (array) $f->course_ids ) ) ? (int) $f->course_ids[0] : 0;
		$base    = Pages::url( $ws );
		$o       = '<form class="ec-ws-filters" method="get" action="' . esc_url( $base ) . '"><input type="hidden" name="v" value="analytics">';
		$o      .= '<label for="ec-an-from"><span>' . esc_html__( 'From', 'educore-workspace' ) . '</span><input id="ec-an-from" type="date" name="from" value="' . esc_attr( $f->from ) . '"></label>';
		$o      .= '<label for="ec-an-to"><span>' . esc_html__( 'To', 'educore-workspace' ) . '</span><input id="ec-an-to" type="date" name="to" value="' . esc_attr( $f->to ) . '"></label>';
		$o      .= '<label for="ec-an-course"><span>' . esc_html__( 'Course', 'educore-workspace' ) . '</span><select id="ec-an-course" name="course"><option value="">' . esc_html__( 'All my courses', 'educore-workspace' ) . '</option>';
		foreach ( $allowed as $c ) {
			$o .= '<option value="' . (int) $c . '"' . selected( $course, $c, false ) . '>' . esc_html( get_the_title( $c ) ?: '#' . $c ) . '</option>';
		}
		$o .= '</select></label>';
		if ( Scope::is_global( $uid ) ) {
			$o .= '<label for="ec-an-prog"><span>' . esc_html__( 'Programme', 'educore-workspace' ) . '</span><select id="ec-an-prog" name="programme"><option value="">' . esc_html__( 'All', 'educore-workspace' ) . '</option>';
			foreach ( Curriculum::programmes() as $p ) {
				$o .= '<option value="' . (int) $p['id'] . '"' . selected( $f->programme_id, (int) $p['id'], false ) . '>' . esc_html( $p['name'] ) . '</option>';
			}
			$o .= '</select></label>';
		}
		$o .= '<button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Apply', 'educore-workspace' ) . '</button></form>';

		// KPI tiles.
		$part = Metrics::participation( $f );
		$enr  = array_sum( wp_list_pluck( $part, 'enrolled' ) );
		$act  = array_sum( wp_list_pluck( $part, 'active' ) );
		$back = Metrics::grading_backlog( $f );
		$o   .= '<ul class="ec-ws-stats">';
		$o   .= '<li class="ec-ws-stat"><span class="ec-ws-stat__v">' . esc_html( number_format_i18n( Metrics::active_enrollments( $f ) ) ) . '</span><span class="ec-ws-stat__l">' . esc_html__( 'Active enrollments', 'educore-workspace' ) . self::def( 'A1' ) . '</span></li>';
		$o   .= '<li class="ec-ws-stat"><span class="ec-ws-stat__v">' . esc_html( $enr ? self::pct( $act * 100 / $enr ) : '—' ) . '</span><span class="ec-ws-stat__l">' . esc_html__( 'Participation in range', 'educore-workspace' ) . self::def( 'A2' ) . '</span></li>';
		$o   .= '<li class="ec-ws-stat"><span class="ec-ws-stat__v">' . esc_html( number_format_i18n( array_sum( wp_list_pluck( $part, 'completions' ) ) ) ) . '</span><span class="ec-ws-stat__l">' . esc_html__( 'Course completions in range', 'educore-workspace' ) . self::def( 'A3' ) . '</span></li>';
		if ( null !== $back ) {
			/* translators: %d: hours */
			$old = $back['oldest_hours'] ? ' · ' . sprintf( __( 'oldest %dh', 'educore-workspace' ), (int) $back['oldest_hours'] ) : '';
			$o  .= '<li class="ec-ws-stat"><span class="ec-ws-stat__v">' . esc_html( number_format_i18n( (int) $back['count'] ) . $old ) . '</span><span class="ec-ws-stat__l">' . esc_html__( 'Pending grading', 'educore-workspace' ) . self::def( 'I6' ) . '</span></li>';
		}
		$o .= '</ul>';

		if ( $course ) {
			$exp = Scope::can_export( $uid, $course );
			$e   = Metrics::engagement( $course, $f );
			$o  .= '<section class="ec-card ec-ws-section"><h2>' . esc_html( get_the_title( $course ) ) . '</h2><ul class="ec-ws-stats">';
			/* translators: 1: active learners, 2: enrolled learners */
			$o  .= '<li class="ec-ws-stat"><span class="ec-ws-stat__v">' . esc_html( self::pct( $e['rate_7'] ) ) . '</span><span class="ec-ws-stat__l">' . esc_html( sprintf( __( 'Active in 7 days (%1$d of %2$d)', 'educore-workspace' ), $e['active_7'], $e['enrolled'] ) ) . self::def( 'I1' ) . '</span></li>';
			/* translators: 1: active learners, 2: enrolled learners */
			$o  .= '<li class="ec-ws-stat"><span class="ec-ws-stat__v">' . esc_html( self::pct( $e['rate_30'] ) ) . '</span><span class="ec-ws-stat__l">' . esc_html( sprintf( __( 'Active in 30 days (%1$d of %2$d)', 'educore-workspace' ), $e['active_30'], $e['enrolled'] ) ) . self::def( 'I1' ) . '</span></li>';
			$imp = Metrics::course_improvement( $course, $f );
			if ( null !== $imp || AssessmentSource::attempts_available() ) {
				$o .= '<li class="ec-ws-stat"><span class="ec-ws-stat__v">' . esc_html( null === $imp ? '—' : ( $imp > 0 ? '+' : '' ) . number_format_i18n( (float) $imp, 1 ) ) . '</span><span class="ec-ws-stat__l">' . esc_html__( 'Average score improvement (points)', 'educore-workspace' ) . self::def( 'I5' ) . '</span></li>';
			}
			$o    .= '</ul>';
			$rates = Metrics::lesson_completion_rates( $course, $f );
			$o    .= '<h3>' . esc_html__( 'Lesson completion', 'educore-workspace' ) . self::def( 'I2' ) . self::export( 'lesson_completion', $f, $exp ) . '</h3>' . self::bars( self::numbered( $rates, 'lesson', 'rate' ), __( 'Lesson completion rate', 'educore-workspace' ) );
			$dist  = Metrics::score_distribution( $f );
			if ( null !== $dist ) {
				$labels = array();
				for ( $i = 0; $i < 10; $i++ ) {
					$labels[] = ( $i * 10 ) . '–' . ( 9 === $i ? 100 : $i * 10 + 9 ) . '%';
				}
				$o .= '<h3>' . esc_html__( 'Score distribution (attempts)', 'educore-workspace' ) . self::def( 'I3' ) . '</h3>' . self::bars( array_combine( $labels, array_map( 'intval', $dist ) ), __( 'Scored attempts by percentage band', 'educore-workspace' ), false );
				$dq = (array) Metrics::difficult_questions( $f );
				$o .= '<h3>' . esc_html__( 'Difficult questions', 'educore-workspace' ) . self::def( 'I4' ) . self::export( 'difficult_questions', $f, $exp ) . '</h3>';
				$bank = class_exists( '\EduCore\Workspace\Assess\Bank' ) && Assess\Bank::can( $uid, $course );
				$o   .= self::table(
					array( __( 'Question', 'educore-workspace' ), __( 'Lesson', 'educore-workspace' ), __( 'Responses', 'educore-workspace' ), __( 'Facility (p)', 'educore-workspace' ) ),
					array_map( static fn( $q ) => array( $bank ? array( 'html' => '<a href="' . esc_url( Pages::url( 'studio', array( 'bank' => $course, 'q' => (int) $q['question_id'] ) ) ) . '">#' . (int) $q['question_id'] . '</a>' ) : '#' . $q['question_id'], $q['lesson_id'] ? get_the_title( (int) $q['lesson_id'] ) : '', $q['responses'], $q['p'] ), $dq ),
					__( 'Difficult questions', 'educore-workspace' )
				);
			}
			$reason = array( 'inactive_14d' => __( 'No activity for 14 days', 'educore-workspace' ), 'low_progress' => __( 'Low progress', 'educore-workspace' ), 'low_scores' => __( 'Low scores', 'educore-workspace' ) );
			$o     .= '<h3>' . esc_html__( 'Learners at risk', 'educore-workspace' ) . self::def( 'I7' ) . self::export( 'at_risk', $f, $exp ) . '</h3>';
			$o     .= self::table(
				array( __( 'Learner', 'educore-workspace' ), __( 'Completion', 'educore-workspace' ), __( 'Assessment mean', 'educore-workspace' ), __( 'Reasons', 'educore-workspace' ), __( 'Action', 'educore-workspace' ) ),
				array_map(
					static function ( $r ) use ( $uid, $reason, $course, $ws ) {
						$name = user_can( $uid, 'ec_view_student', (int) $r['user_id'] ) ? ( get_userdata( (int) $r['user_id'] )->display_name ?? '#' . $r['user_id'] ) : __( 'Learner', 'educore-workspace' ) . ' #' . $r['user_id'];
						$map  = array( 'inactive_14d' => 'inactive', 'low_progress' => 'low_progress', 'low_scores' => 'low_scores' );
						$why  = $map[ ( (array) $r['reasons'] )[0] ?? '' ] ?? 'other';
						$plan = Success::can_course( $uid, $course ) ? array( 'html' => '<a class="ec-btn ec-btn--small" href="' . esc_url( Pages::url( $ws, array( 'v' => 'success', 'do' => 'new', 'course' => $course, 'learner' => (int) $r['user_id'], 'reason' => $why ) ) ) . '">' . esc_html__( 'Start a support plan', 'educore-workspace' ) . '</a>' ) : '';
						return array( $name, self::pct( $r['completion'] ), self::pct( $r['mean'] ), implode( ', ', array_map( static fn( $x ) => $reason[ $x ] ?? $x, (array) $r['reasons'] ) ), $plan );
					},
					Metrics::at_risk( $course, $f )
				),
				__( 'Learners at risk', 'educore-workspace' )
			);
			$o .= $exp ? '<p>' . esc_html__( 'Learner report:', 'educore-workspace' ) . self::export( 'course_students', $f, true ) . '</p>' : '';
			$o .= '</section>';
		} else {
			$o .= '<p class="ec-muted">' . esc_html__( 'Choose a course to see engagement, lesson completion, score distribution, difficult questions and learners at risk.', 'educore-workspace' ) . '</p>';
		}

		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Course participation', 'educore-workspace' ) . self::def( 'A2' ) . self::export( 'participation', $f, Scope::can_export( $uid, $course ?: null ) ) . '</h2>';
		$o .= self::table(
			array( __( 'Course', 'educore-workspace' ), __( 'Enrolled', 'educore-workspace' ), __( 'Active', 'educore-workspace' ), __( 'Participation', 'educore-workspace' ), __( 'Completions', 'educore-workspace' ) ),
			array_map( static fn( $r ) => array( $r['course'], $r['enrolled'], $r['active'], self::pct( $r['participation'] ), $r['completions'] ), $part ),
			__( 'Course participation', 'educore-workspace' )
		);
		$trend = Metrics::completion_trend( $f );
		$o    .= '<h3>' . esc_html__( 'Completions per month', 'educore-workspace' ) . self::def( 'A3' ) . '</h3>' . self::bars( $trend, __( 'Course completions per month', 'educore-workspace' ), false ) . '</section>';

		if ( Scope::is_global( $uid ) ) {
			$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Cohort comparison', 'educore-workspace' ) . self::def( 'A4' ) . '</h2>';
			foreach ( array( 'programme' => __( 'By programme', 'educore-workspace' ), 'year' => __( 'By academic year', 'educore-workspace' ) ) as $by => $label ) {
				$o .= '<h3>' . esc_html( $label ) . '</h3>' . self::table( array( __( 'Cohort', 'educore-workspace' ), __( 'Learners', 'educore-workspace' ), __( 'Mean completion', 'educore-workspace' ) ), array_map( static fn( $r ) => array( $r['label'], $r['learners'], self::pct( $r['mean_completion'] ) ), Metrics::cohorts( $f, $by ) ), $label );
			}
			$q = Metrics::assessment_quality( $f );
			if ( null !== $q ) {
				$o .= '<h3>' . esc_html__( 'Assessment quality', 'educore-workspace' ) . self::def( 'A5' ) . '</h3>' . self::table( array( __( 'Question', 'educore-workspace' ), __( 'Responses', 'educore-workspace' ), __( 'Facility (p)', 'educore-workspace' ), __( 'Flag', 'educore-workspace' ) ), array_map( static fn( $r ) => array( '#' . $r['question_id'], $r['responses'], $r['p'], 'too_hard' === $r['flag'] ? __( 'Too hard', 'educore-workspace' ) : __( 'Too easy', 'educore-workspace' ) ), $q ), __( 'Assessment quality', 'educore-workspace' ) );
			}
			$o .= '<h3>' . esc_html__( 'Lessons never opened', 'educore-workspace' ) . self::def( 'A6' ) . '</h3>' . self::table( array( __( 'Lesson', 'educore-workspace' ), __( 'Course', 'educore-workspace' ) ), array_map( static fn( $r ) => array( $r['lesson'], $r['course'] ), Metrics::unused_lessons( $f ) ), __( 'Lessons never opened', 'educore-workspace' ) ) . '</section>';
		}
		$o .= '<details class="ec-card ec-ws-section"><summary>' . esc_html__( 'Metric definitions', 'educore-workspace' ) . '</summary><dl class="ec-ws-kv">';
		foreach ( Dictionary::all() as $id => $m ) {
			$o .= '<dt>' . esc_html( $id . ' — ' . $m['name'] ) . '</dt><dd>' . esc_html( $m['definition'] ) . '</dd>';
		}
		return $o . '</dl></details>';
	}
}
