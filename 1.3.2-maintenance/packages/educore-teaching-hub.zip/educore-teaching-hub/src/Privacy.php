<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Joins EduCore's export/erase pipeline: a learner's Teaching Hub records are exportable and erasable. */
final class Privacy {

	public static function register(): void {
		add_filter( 'educore/privacy/export', array( self::class, 'export' ), 10, 2 );
		add_action( 'educore/privacy/erase', array( self::class, 'erase' ) );
	}

	/** @param array<int,array<string,mixed>> $items */
	public static function export( array $items, $user ): array {
		global $wpdb;
		if ( ! $user instanceof \WP_User ) {
			return $items;
		}
		$user_id = (int) $user->ID;
		$add = static function ( string $group, string $label, array $rows, array $fields ) use ( &$items ) {
			foreach ( $rows as $r ) {
				$data = array();
				foreach ( $fields as $k => $name ) {
					$data[] = array( 'name' => $name, 'value' => (string) ( $r[ $k ] ?? '' ) );
				}
				$items[] = array( 'group_id' => $group, 'group_label' => $label, 'item_id' => $group . '-' . ( $r['id'] ?? md5( wp_json_encode( $r ) ) ), 'data' => $data );
			}
		};
		$add( 'educore-th-submissions', __( 'EduCore assignments', 'educore-teaching-hub' ), $wpdb->get_results( $wpdb->prepare( 'SELECT s.id, a.title, s.status, s.submitted_at, s.score, s.feedback FROM ' . Schema::table( 'th_submissions' ) . ' s JOIN ' . Schema::table( 'th_assignments' ) . ' a ON a.id=s.assignment_id WHERE s.student_id=%d', $user_id ), ARRAY_A ) ?: array(), array( 'title' => 'Assignment', 'status' => 'Status', 'submitted_at' => 'Submitted', 'score' => 'Score (if released)', 'feedback' => 'Feedback' ) );
		$add( 'educore-th-attendance', __( 'EduCore attendance', 'educore-teaching-hub' ), $wpdb->get_results( $wpdb->prepare( 'SELECT id, context_type, occurs_on, status FROM ' . Schema::table( 'th_attendance' ) . ' WHERE student_id=%d', $user_id ), ARRAY_A ) ?: array(), array( 'context_type' => 'Context', 'occurs_on' => 'Date', 'status' => 'Status' ) );
		$add( 'educore-th-sessions', __( 'EduCore tutoring sessions', 'educore-teaching-hub' ), $wpdb->get_results( $wpdb->prepare( 'SELECT id, subject, starts_at, status, homework, feedback FROM ' . Schema::table( 'th_sessions' ) . ' WHERE student_id=%d OR tutor_id=%d', $user_id, $user_id ), ARRAY_A ) ?: array(), array( 'subject' => 'Subject', 'starts_at' => 'Starts (UTC)', 'status' => 'Status', 'homework' => 'Homework', 'feedback' => 'Feedback' ) );
		$add( 'educore-th-messages', __( 'EduCore messages', 'educore-teaching-hub' ), $wpdb->get_results( $wpdb->prepare( 'SELECT id, body, created_at FROM ' . Schema::table( 'th_messages' ) . ' WHERE author_id=%d', $user_id ), ARRAY_A ) ?: array(), array( 'created_at' => 'Date', 'body' => 'Message' ) );
		$add( 'educore-th-profile', __( 'EduCore tutor profile', 'educore-teaching-hub' ), $wpdb->get_results( $wpdb->prepare( 'SELECT user_id id, headline, bio, subjects, qualifications, status FROM ' . Schema::table( 'th_tutor_profiles' ) . ' WHERE user_id=%d', $user_id ), ARRAY_A ) ?: array(), array( 'headline' => 'Headline', 'bio' => 'Biography', 'subjects' => 'Subjects', 'qualifications' => 'Qualifications', 'status' => 'Status' ) );
		return $items;
	}

	/**
	 * Erase a learner's personal Teaching Hub data. Submission files and answers are deleted; grade
	 * records are anonymised (aggregates stay correct); message bodies are redacted (threads stay
	 * auditable for safeguarding without the erased person's words).
	 */
	public static function erase( $user ): void {
		global $wpdb;
		if ( ! $user instanceof \WP_User ) {
			return;
		}
		$user_id = (int) $user->ID;
		$subs = $wpdb->get_results( $wpdb->prepare( 'SELECT id, files FROM ' . Schema::table( 'th_submissions' ) . ' WHERE student_id=%d', $user_id ), ARRAY_A ) ?: array();
		foreach ( $subs as $s ) {
			foreach ( (array) json_decode( (string) $s['files'], true ) as $f ) {
				Files::delete( (string) ( $f['key'] ?? '' ) );
			}
		}
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . Schema::table( 'th_submissions' ) . " SET answer='', files=NULL, feedback='' WHERE student_id=%d", $user_id ) );
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . Schema::table( 'th_messages' ) . " SET body='[removed at the user’s request]' WHERE author_id=%d", $user_id ) );
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . Schema::table( 'th_sessions' ) . " SET objectives='', notes='', homework='', feedback='', follow_up='' WHERE student_id=%d", $user_id ) );
		$wpdb->delete( Schema::table( 'th_tutor_profiles' ), array( 'user_id' => $user_id ) );
		$wpdb->delete( Schema::table( 'th_availability' ), array( 'tutor_id' => $user_id ) );
		$wpdb->delete( Schema::table( 'th_unavailable' ), array( 'tutor_id' => $user_id ) );
	}
}
