<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Roles, primitive capabilities and object-scoped meta capabilities.
 *
 * Meta capabilities (always pass an object id):
 *   ec_edit_course( course_id )         edit content of a course (incl. its units/lessons)
 *   ec_grade_course( course_id )        grade submissions in a course
 *   ec_view_course_records( course_id ) see student records of a course
 *   ec_manage_course_enrollments( course_id )
 *   ec_view_student( student_id )       see one student's private records
 */
final class Roles {

	public const CONTENT_CAPS = array(
		'edit_ec_courses', 'edit_others_ec_courses', 'edit_published_ec_courses', 'edit_private_ec_courses',
		'publish_ec_courses', 'delete_ec_courses', 'delete_others_ec_courses', 'delete_published_ec_courses',
		'delete_private_ec_courses', 'read_private_ec_courses',
	);

	public const EC_CAPS = array(
		'ec_manage_settings', 'ec_manage_programmes', 'ec_manage_all_courses', 'ec_edit_assigned_courses',
		'ec_publish_courses', 'ec_manage_question_bank', 'ec_manage_assessments', 'ec_grade_submissions',
		'ec_release_grades', 'ec_manage_enrollments', 'ec_view_student_records', 'ec_view_analytics',
		'ec_export_reports', 'ec_manage_certificates', 'ec_manage_commerce', 'ec_view_audit_log', 'ec_learn',
		'ec_access_workspace',
	);

	/** @return array<string,array{label:string,caps:array<string,bool>}> */
	public static function definitions(): array {
		$content_all = array_fill_keys( self::CONTENT_CAPS, true );
		$manager     = array_merge(
			array( 'read' => true, 'upload_files' => true ),
			$content_all,
			array_fill_keys(
				array( 'ec_manage_programmes', 'ec_manage_all_courses', 'ec_edit_assigned_courses', 'ec_publish_courses', 'ec_manage_question_bank', 'ec_manage_assessments', 'ec_grade_submissions', 'ec_release_grades', 'ec_manage_enrollments', 'ec_view_student_records', 'ec_view_analytics', 'ec_export_reports', 'ec_manage_certificates', 'ec_view_audit_log', 'ec_access_workspace' ),
				true
			)
		);
		$instructor = array_merge(
			array( 'read' => true, 'upload_files' => true, 'edit_ec_courses' => true, 'edit_published_ec_courses' => true, 'delete_ec_courses' => true ),
			array_fill_keys( array( 'ec_edit_assigned_courses', 'ec_manage_question_bank', 'ec_manage_assessments', 'ec_grade_submissions', 'ec_release_grades', 'ec_manage_enrollments', 'ec_view_student_records', 'ec_view_analytics', 'ec_export_reports', 'ec_access_workspace' ), true )
		);
		return array(
			'ec_academic_manager' => array( 'label' => 'Academic Manager', 'caps' => $manager ),
			'ec_instructor'       => array( 'label' => 'Instructor', 'caps' => $instructor ),
			'ec_grader'           => array( 'label' => 'Grader', 'caps' => array( 'read' => true, 'ec_grade_submissions' => true, 'ec_view_student_records' => true, 'ec_access_workspace' => true ) ),
			'ec_student'          => array( 'label' => 'Student', 'caps' => array( 'read' => true, 'ec_learn' => true ) ),
			'ec_guardian'         => array( 'label' => 'Guardian', 'caps' => array( 'read' => true ) ),
		);
	}

	public static function install(): void {
		foreach ( self::definitions() as $slug => $def ) {
			remove_role( $slug );
			add_role( $slug, $def['label'], $def['caps'] );
		}
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( array_merge( self::CONTENT_CAPS, self::EC_CAPS ) as $cap ) {
				$admin->add_cap( $cap );
			}
			$admin->remove_cap( 'ec_learn' );
		}
	}

	public static function uninstall(): void {
		foreach ( array_keys( self::definitions() ) as $slug ) {
			remove_role( $slug );
		}
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( array_merge( self::CONTENT_CAPS, self::EC_CAPS ) as $cap ) {
				$admin->remove_cap( $cap );
			}
		}
	}

	public static function register(): void {
		add_filter( 'map_meta_cap', array( self::class, 'map_meta_cap' ), 10, 4 );
	}

	/**
	 * @param string[] $caps
	 * @param mixed[]  $args
	 * @return string[]
	 */
	public static function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array {
		$object_id = isset( $args[0] ) ? (int) $args[0] : 0;

		switch ( $cap ) {
			case 'ec_edit_course':
				return self::scoped( $user_id, $object_id, 'ec_manage_all_courses', 'ec_edit_assigned_courses', array( 'lead', 'instructor' ) );
			case 'ec_grade_course':
				return self::scoped( $user_id, $object_id, 'ec_manage_all_courses', 'ec_grade_submissions', array( 'lead', 'instructor', 'grader' ) );
			case 'ec_view_course_records':
				return self::scoped( $user_id, $object_id, 'ec_manage_all_courses', 'ec_view_student_records', array( 'lead', 'instructor', 'grader' ) );
			case 'ec_manage_course_enrollments':
				return self::scoped( $user_id, $object_id, 'ec_manage_all_courses', 'ec_manage_enrollments', array( 'lead', 'instructor' ) );
			case 'ec_view_student':
				if ( $object_id && $object_id === $user_id ) {
					return array( 'read' );
				}
				if ( user_can( $user_id, 'ec_manage_all_courses' ) ) {
					return array( 'ec_view_student_records' );
				}
				if ( Privacy::guardian_has_access( $user_id, $object_id ) ) {
					return array( 'read' );
				}
				foreach ( Staff::courses_of( $user_id ) as $course_id ) {
					if ( Enrollment::is_enrolled( $object_id, $course_id, false ) ) {
						return array( 'ec_view_student_records' );
					}
				}
				return array( 'do_not_allow' );
		}

		// Scope core WP post caps on EduCore content to assigned courses.
		if ( in_array( $cap, array( 'edit_post', 'delete_post', 'publish_post', 'read_post' ), true ) && $object_id ) {
			$post = get_post( $object_id );
			if ( $post && Content::is_content_type( $post->post_type ) && 'read_post' !== $cap ) {
				if ( user_can( $user_id, 'ec_manage_all_courses' ) ) {
					return $caps;
				}
				$course_id = Content::course_of( $post->ID );
				if ( 'auto-draft' === $post->post_status && (int) $post->post_author === $user_id ) {
					return array( 'edit_ec_courses' );
				}
				if ( ! $course_id || ! Staff::has_role( $user_id, $course_id, array( 'lead', 'instructor' ) ) ) {
					// Newly created own course not yet staffed (creation hook staffs it on save).
					if ( $post->ID === $course_id && (int) $post->post_author === $user_id && 'publish' !== $post->post_status ) {
						return array( 'edit_ec_courses' );
					}
					return array( 'do_not_allow' );
				}
				if ( 'publish_post' === $cap ) {
					return array( 'publish_ec_courses' );
				}
				return array( 'publish' === $post->post_status ? 'edit_published_ec_courses' : 'edit_ec_courses' );
			}
		}
		return $caps;
	}

	/** @param string[] $staff_roles */
	private static function scoped( int $user_id, int $course_id, string $global_cap, string $base_cap, array $staff_roles ): array {
		if ( user_can( $user_id, $global_cap ) ) {
			return array( $global_cap );
		}
		if ( $course_id && Staff::has_role( $user_id, $course_id, $staff_roles ) ) {
			return array( $base_cap );
		}
		return array( 'do_not_allow' );
	}
}
