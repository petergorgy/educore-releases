=== EduCore Analytics ===
Contributors: gorgyorg
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: lms, analytics, reports, education

Learning analytics, dashboards and exports for EduCore.

== Description ==

Part of the EduCore LMS (https://educore.gorgy.org), an initiative of GORGY.ORG.

* 23 precisely defined metrics for students, instructors and administrators (see docs/metric-dictionary.md).
* Filters by date range, course, programme and academic year; instructors only see their own courses; learner drill-down needs explicit permission.
* Charts with accessible data-table alternatives; "My progress" block for learners (own data only).
* CSV and XLSX exports with permission checks and spreadsheet formula-injection protection.

Requires EduCore Core. Assessment metrics appear when EduCore Assessments is active.

== Installation ==

1. Install and activate EduCore Core first.
2. Upload and activate this plugin.
3. Run EduCore → Setup wizard → "Run database & roles setup".

== Changelog ==

= 1.0.1 =
* Engagement metrics (DAU/WAU, consistency) use the new core activity log — no longer lower bounds.
* Performance: completion computed with one grouped query per course (dashboard 7.5 s → 0.8 s at scale).

= 1.0.0 =
* First release.
