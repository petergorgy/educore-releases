<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Programmes → academic periods (year, semester) → subjects, and course mappings. */
final class Curriculum {

	/** @return int|\WP_Error */
	public static function create_programme( string $code, string $name, string $country = 'EG', string $lang = 'en' ) {
		global $wpdb;
		$code = sanitize_key( $code );
		if ( '' === $code || '' === trim( $name ) ) {
			return new \WP_Error( 'educore_invalid', __( 'Code and name are required.', 'educore-core' ), array( 'status' => 400 ) );
		}
		$ok = $wpdb->insert( Schema::table( 'programmes' ), array( 'code' => $code, 'name' => sanitize_text_field( $name ), 'country' => strtoupper( substr( $country, 0, 2 ) ), 'lang' => I18n::sanitize_lang( $lang ), 'created_at' => Schema::now() ) );
		if ( ! $ok ) {
			return new \WP_Error( 'educore_duplicate', __( 'A programme with this code already exists.', 'educore-core' ), array( 'status' => 409 ) );
		}
		$id = (int) $wpdb->insert_id;
		Audit::log( 'curriculum.programme_created', 'programme', $id, array( 'code' => $code ) );
		return $id;
	}

	public static function add_period( int $programme_id, string $type, string $label, int $parent_id = 0, int $position = 0 ): int {
		global $wpdb;
		$type = in_array( $type, array( 'year', 'semester', 'term' ), true ) ? $type : 'year';
		$wpdb->insert( Schema::table( 'academic_periods' ), array( 'programme_id' => $programme_id, 'parent_id' => $parent_id, 'type' => $type, 'label' => sanitize_text_field( $label ), 'position' => $position ) );
		return (int) $wpdb->insert_id;
	}

	public static function add_subject( int $programme_id, string $code, string $name ): int {
		global $wpdb;
		$t = Schema::table( 'subjects' );
		$wpdb->query( $wpdb->prepare( "INSERT INTO {$t} (programme_id,code,name) VALUES (%d,%s,%s) ON DUPLICATE KEY UPDATE name=VALUES(name)", $programme_id, sanitize_key( $code ), sanitize_text_field( $name ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE programme_id=%d AND code=%s", $programme_id, sanitize_key( $code ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function map_course( int $course_id, int $programme_id, int $period_id = 0, int $subject_id = 0 ): bool {
		global $wpdb;
		$t = Schema::table( 'curriculum_map' );
		return false !== $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$t} (course_id,programme_id,period_id,subject_id) VALUES (%d,%d,%d,%d)", $course_id, $programme_id, $period_id, $subject_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function unmap_course( int $course_id ): void {
		global $wpdb;
		$wpdb->delete( Schema::table( 'curriculum_map' ), array( 'course_id' => $course_id ), array( '%d' ) );
	}

	/** @return array<int,array<string,mixed>> */
	public static function programmes(): array {
		global $wpdb;
		return $wpdb->get_results( 'SELECT * FROM ' . Schema::table( 'programmes' ) . ' ORDER BY name', ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** @return array<int,array<string,mixed>> */
	public static function periods( int $programme_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'academic_periods' ) . ' WHERE programme_id=%d ORDER BY parent_id, position, id', $programme_id ), ARRAY_A ) ?: array();
	}

	/** @return array<int,array<string,mixed>> */
	public static function subjects( int $programme_id = 0 ): array {
		global $wpdb;
		if ( $programme_id ) {
			return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'subjects' ) . ' WHERE programme_id=%d ORDER BY name', $programme_id ), ARRAY_A ) ?: array();
		}
		return $wpdb->get_results( 'SELECT * FROM ' . Schema::table( 'subjects' ) . ' ORDER BY name', ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** @return array<int,array<string,mixed>> */
	public static function mappings_for_course( int $course_id ): array {
		global $wpdb;
		$m = Schema::table( 'curriculum_map' );
		$p = Schema::table( 'programmes' );
		$a = Schema::table( 'academic_periods' );
		$s = Schema::table( 'subjects' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT m.*, p.name programme, a.label period, s.name subject FROM {$m} m LEFT JOIN {$p} p ON p.id=m.programme_id LEFT JOIN {$a} a ON a.id=m.period_id LEFT JOIN {$s} s ON s.id=m.subject_id WHERE m.course_id=%d", $course_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** @return int[] course ids matching programme/subject filters */
	public static function courses_matching( int $programme_id = 0, int $subject_id = 0 ): array {
		global $wpdb;
		$where  = array( '1=1' );
		$params = array();
		if ( $programme_id ) {
			$where[]  = 'programme_id=%d';
			$params[] = $programme_id;
		}
		if ( $subject_id ) {
			$where[]  = 'subject_id=%d';
			$params[] = $subject_id;
		}
		$sql = 'SELECT DISTINCT course_id FROM ' . Schema::table( 'curriculum_map' ) . ' WHERE ' . implode( ' AND ', $where );
		return array_map( 'intval', $params ? $wpdb->get_col( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_col( $sql ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/**
	 * Initial structure from the specification: Egyptian Baccalaureate — Second Year —
	 * Programming & Artificial Intelligence — Semester 1, Unit 1 (1.1–1.4) and Unit 2 (2.1–2.3).
	 * Creates STRUCTURE ONLY (draft, placeholder titles to be replaced with official titles). Idempotent.
	 *
	 * @return array{programme_id:int,course_id:int,created:bool}
	 */
	public static function seed_initial_structure(): array {
		global $wpdb;
		$existing = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Schema::table( 'programmes' ) . ' WHERE code=%s', 'eg-bac' ) );
		if ( $existing ) {
			$course = (int) get_option( 'educore_seed_course_id', 0 );
			return array( 'programme_id' => $existing, 'course_id' => $course, 'created' => false );
		}
		$pid      = (int) self::create_programme( 'eg-bac', 'Egyptian Baccalaureate', 'EG', 'en' );
		$year     = self::add_period( $pid, 'year', 'Second Year', 0, 2 );
		$semester = self::add_period( $pid, 'semester', 'Semester 1', $year, 1 );
		$subject  = self::add_subject( $pid, 'prog-ai', 'Programming & Artificial Intelligence' );
		$course   = (int) wp_insert_post(
			array(
				'post_type'   => Content::COURSE,
				'post_status' => 'draft',
				'post_title'  => 'Programming & Artificial Intelligence — Year 2, Semester 1',
			)
		);
		self::map_course( $course, $pid, $semester, $subject );
		$plan = array( 1 => 4, 2 => 3 );
		foreach ( $plan as $unit_no => $lessons ) {
			/* translators: %d: unit number */
			$unit = (int) wp_insert_post( array( 'post_type' => Content::UNIT, 'post_status' => 'draft', 'post_title' => sprintf( __( 'Unit %d', 'educore-core' ), $unit_no ), 'menu_order' => $unit_no ) );
			update_post_meta( $unit, '_ec_course_id', $course );
			for ( $i = 1; $i <= $lessons; $i++ ) {
				/* translators: 1: unit number, 2: lesson number */
				$lid = (int) wp_insert_post( array( 'post_type' => Content::LESSON, 'post_status' => 'draft', 'post_title' => sprintf( __( 'Lesson %1$d.%2$d', 'educore-core' ), $unit_no, $i ), 'menu_order' => $i ) );
				update_post_meta( $lid, '_ec_unit_id', $unit );
				update_post_meta( $lid, '_ec_course_id', $course );
			}
		}
		update_option( 'educore_seed_course_id', $course, false );
		Audit::log( 'curriculum.seeded', 'course', $course );
		return array( 'programme_id' => $pid, 'course_id' => $course, 'created' => true );
	}
}
