<?php
namespace EduCore\Assessments;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	private static bool $booted = false;

	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;
		\EduCore\Core\Registry::register( 'assessments', EDUCORE_ASSESSMENTS_VERSION );
		Schema::maybe_install();
		add_action( 'init', static fn() => load_plugin_textdomain( 'educore-assessments', false, dirname( plugin_basename( EDUCORE_ASSESSMENTS_FILE ) ) . '/languages' ) );
		Rest::register();
		Frontend::register();
		Integration::register();
		if ( is_admin() ) {
			Admin::register();
			Exchange\Center::register();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'educore questions', Exchange\Cli::class );
		}
		do_action( 'educore/assessments/loaded' );
	}
}
