<?php
namespace EduCore\TeachingHub;

defined( 'ABSPATH' ) || exit;

/**
 * REST API: /educore/v1/th/*. Every route has an endpoint-level permission callback; object-level checks
 * (class scope, assignment grading rights, session ownership, thread access) run inside the handler
 * and fail closed with 403/404. Responses are private/no-store (core Routes::private_headers).
 */
final class Rest {
	private const NS = 'educore/v1';

	public static function register(): void {
		add_action( 'educore/rest/routes', array( self::class, 'routes' ) );
	}

	private static function err( \WP_Error $e ): \WP_REST_Response {
		$data = $e->get_error_data();
		return new \WP_REST_Response( array( 'code' => $e->get_error_code(), 'message' => $e->get_error_message() ), is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 400 );
	}

	private static function deny( int $status = 403 ): \WP_REST_Response {
		return new \WP_REST_Response( array( 'code' => 'ec_th_forbidden', 'message' => __( 'You do not have access to this item.', 'educore-teaching-hub' ) ), $status );
	}

	private static function route( string $path, string $methods, callable $cb, callable $perm ): void {
		register_rest_route( self::NS, '/th' . $path, array( 'methods' => $methods, 'callback' => $cb, 'permission_callback' => $perm ) );
	}

	public static function routes(): void {
		$staff   = static fn() => current_user_can( 'ec_teach' ) || current_user_can( 'ec_tutor_sessions' ) || current_user_can( 'ec_manage_teaching' ) || current_user_can( 'ec_grade_submissions' );
		$teacher = static fn() => current_user_can( 'ec_teach' ) || current_user_can( 'ec_manage_teaching' );
		$tutor   = static fn() => current_user_can( 'ec_tutor_sessions' ) || current_user_can( 'ec_manage_teaching' );
		$manager = static fn() => current_user_can( 'ec_manage_teaching' );
		$user    = static fn() => is_user_logged_in();
		$public  = '__return_true';

		self::route( '/me', 'GET', array( self::class, 'me' ), $user );
		self::route( '/classes', 'GET', array( self::class, 'classes' ), $teacher );
		self::route( '/classes', 'POST', array( self::class, 'create_class' ), $manager );
		self::route( '/classes/(?P<id>\d+)', 'GET', array( self::class, 'class_detail' ), $teacher );
		self::route( '/classes/(?P<id>\d+)/members', 'POST', array( self::class, 'add_member' ), $teacher );
		self::route( '/classes/(?P<id>\d+)/members/(?P<student>\d+)', 'DELETE', array( self::class, 'remove_member' ), $teacher );
		self::route( '/classes/(?P<id>\d+)/transfer', 'POST', array( self::class, 'transfer' ), $teacher );
		self::route( '/students/(?P<id>\d+)', 'GET', array( self::class, 'student' ), $staff );
		self::route( '/plans', 'GET', array( self::class, 'plans' ), $teacher );
		self::route( '/plans', 'POST', array( self::class, 'save_plan' ), $teacher );
		self::route( '/plans/(?P<id>\d+)', 'POST', array( self::class, 'save_plan' ), $teacher );
		self::route( '/assignments', 'POST', array( self::class, 'save_assignment' ), $teacher );
		self::route( '/assignments/(?P<id>\d+)', 'GET', array( self::class, 'assignment' ), $user );
		self::route( '/assignments/(?P<id>\d+)/submit', 'POST', array( self::class, 'submit' ), $user );
		self::route( '/assignments/(?P<id>\d+)/release', 'POST', array( self::class, 'release' ), $staff );
		self::route( '/submissions/(?P<id>\d+)/grade', 'POST', array( self::class, 'grade' ), $staff );
		self::route( '/grading', 'GET', array( self::class, 'grading' ), $staff );
		self::route( '/attendance', 'POST', array( self::class, 'attendance' ), $staff );
		self::route( '/attention', 'GET', array( self::class, 'attention' ), $teacher );
		self::route( '/analytics', 'GET', array( self::class, 'analytics' ), $staff );
		self::route( '/tutors', 'GET', array( self::class, 'tutors' ), $public );
		self::route( '/tutors/(?P<id>\d+)/slots', 'GET', array( self::class, 'slots' ), $user );
		self::route( '/tutor/profile', 'POST', array( self::class, 'save_profile' ), $tutor );
		self::route( '/tutor/availability', 'POST', array( self::class, 'availability' ), $tutor );
		self::route( '/sessions', 'GET', array( self::class, 'sessions' ), $user );
		self::route( '/sessions', 'POST', array( self::class, 'request_session' ), $user );
		self::route( '/sessions/(?P<id>\d+)', 'GET', array( self::class, 'session' ), $user );
		self::route( '/sessions/(?P<id>\d+)/status', 'POST', array( self::class, 'session_status' ), $user );
		self::route( '/sessions/(?P<id>\d+)/reschedule', 'POST', array( self::class, 'reschedule' ), $tutor );
		self::route( '/threads', 'GET', array( self::class, 'threads' ), $user );
		self::route( '/threads', 'POST', array( self::class, 'start_thread' ), $user );
		self::route( '/threads/(?P<id>\d+)', 'GET', array( self::class, 'thread' ), $user );
		self::route( '/threads/(?P<id>\d+)/reply', 'POST', array( self::class, 'reply' ), $user );
		self::route( '/reports', 'POST', array( self::class, 'report' ), $user );
	}

	public static function me(): \WP_REST_Response {
		$uid = get_current_user_id();
		return new \WP_REST_Response( array( 'id' => $uid, 'responsibilities' => Caps::responsibilities( $uid ), 'classes' => Caps::classes_of( $uid ) ) );
	}

	public static function classes(): \WP_REST_Response {
		$ids    = Caps::classes_of( get_current_user_id() );
		$counts = Classes::member_counts( $ids );
		$out    = array();
		foreach ( $ids as $id ) {
			$c     = Classes::get( $id );
			$out[] = array( 'id' => $id, 'name' => $c['name'], 'academic_year' => $c['academic_year'], 'course_id' => (int) $c['course_id'], 'students' => $counts[ $id ] ?? 0 );
		}
		return new \WP_REST_Response( $out );
	}

	public static function create_class( \WP_REST_Request $r ): \WP_REST_Response {
		$id = Classes::create( (array) $r->get_params(), get_current_user_id() );
		return is_wp_error( $id ) ? self::err( $id ) : new \WP_REST_Response( array( 'id' => $id ), 201 );
	}

	public static function class_detail( \WP_REST_Request $r ): \WP_REST_Response {
		$id = (int) $r['id'];
		if ( ! current_user_can( 'ec_teach_class', $id ) ) {
			return self::deny();
		}
		$c = Classes::get( $id );
		if ( ! $c ) {
			return self::deny( 404 );
		}
		$students = array_map( static fn( $sid ) => array( 'id' => $sid, 'name' => get_userdata( $sid )->display_name ), Classes::members( $id ) );
		return new \WP_REST_Response( array( 'class' => $c, 'staff' => Classes::staff( $id ), 'students' => $students, 'groups' => Classes::groups_of_class( $id ) ) );
	}

	public static function add_member( \WP_REST_Request $r ): \WP_REST_Response {
		$id = (int) $r['id'];
		if ( ! current_user_can( 'ec_manage_class', $id ) ) {
			return self::deny();
		}
		$res = Classes::add_member( $id, absint( $r['student_id'] ), get_current_user_id() );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( array( 'ok' => true ) );
	}

	public static function remove_member( \WP_REST_Request $r ): \WP_REST_Response {
		$id = (int) $r['id'];
		if ( ! current_user_can( 'ec_manage_class', $id ) ) {
			return self::deny();
		}
		return new \WP_REST_Response( array( 'ok' => Classes::remove_member( $id, (int) $r['student'], get_current_user_id() ) ) );
	}

	public static function transfer( \WP_REST_Request $r ): \WP_REST_Response {
		$from = (int) $r['id'];
		$to   = absint( $r['to_class'] );
		if ( ! current_user_can( 'ec_manage_class', $from ) || ! current_user_can( 'ec_manage_class', $to ) ) {
			return self::deny();
		}
		$res = Classes::transfer( $from, $to, absint( $r['student_id'] ), get_current_user_id() );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( array( 'ok' => true ) );
	}

	public static function student( \WP_REST_Request $r ): \WP_REST_Response {
		$sid = (int) $r['id'];
		if ( ! current_user_can( 'ec_view_hub_student', $sid ) ) {
			return self::deny();
		}
		return new \WP_REST_Response( Portal::student_summary( $sid, get_current_user_id() ) );
	}

	public static function plans( \WP_REST_Request $r ): \WP_REST_Response {
		$uid = get_current_user_id();
		return new \WP_REST_Response( Planner::list_for( $uid, Caps::classes_of( $uid ), (string) $r['from'], (string) $r['to'], (bool) $r['templates'] ) );
	}

	public static function save_plan( \WP_REST_Request $r ): \WP_REST_Response {
		$uid = get_current_user_id();
		$id  = (int) ( $r['id'] ?? 0 );
		if ( $id ) {
			$plan = Planner::get( $id );
			if ( ! $plan || ! Planner::can_edit( $uid, $plan ) ) {
				return self::deny();
			}
		}
		$class = absint( $r['class_id'] );
		if ( $class && ! current_user_can( 'ec_teach_class', $class ) ) {
			return self::deny();
		}
		$res = Planner::save( (array) $r->get_params(), $uid, $id );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( array( 'id' => $res ), $id ? 200 : 201 );
	}

	public static function save_assignment( \WP_REST_Request $r ): \WP_REST_Response {
		$uid   = get_current_user_id();
		$id    = absint( $r['id'] );
		$class = absint( $r['class_id'] );
		if ( ! $class || ! current_user_can( 'ec_teach_class', $class ) || ( $id && ! current_user_can( 'ec_grade_assignment', $id ) ) ) {
			return self::deny();
		}
		$params = (array) $r->get_params();
		if ( isset( $params['targets'] ) ) {
			$params['targets'] = self::scoped_targets( (array) $params['targets'], $class );
		}
		$res = Assignments::save( $params, $uid, $id );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( array( 'id' => $res ), $id ? 200 : 201 );
	}

	/** Targets must stay inside the class: the class itself, its groups, or its members. */
	public static function scoped_targets( array $targets, int $class ): array {
		$members = Classes::members( $class );
		$groups  = array_map( 'intval', wp_list_pluck( Classes::groups_of_class( $class ), 'id' ) );
		return array_values(
			array_filter(
				array_map( static fn( $t ) => array( (string) ( $t[0] ?? $t['type'] ?? '' ), (int) ( $t[1] ?? $t['id'] ?? 0 ) ), $targets ),
				static fn( $t ) => ( 'class' === $t[0] && $t[1] === $class ) || ( 'group' === $t[0] && in_array( $t[1], $groups, true ) ) || ( 'student' === $t[0] && in_array( $t[1], $members, true ) )
			)
		);
	}

	public static function assignment( \WP_REST_Request $r ): \WP_REST_Response {
		$uid = get_current_user_id();
		$a   = Assignments::get( (int) $r['id'] );
		if ( ! $a ) {
			return self::deny( 404 );
		}
		if ( current_user_can( 'ec_grade_assignment', (int) $a['id'] ) ) {
			return new \WP_REST_Response( array( 'assignment' => $a, 'roster' => Assignments::roster( (int) $a['id'] ) ) );
		}
		if ( 'draft' === $a['status'] || ! Assignments::is_target( $a, $uid ) ) {
			return self::deny( 404 );
		}
		return new \WP_REST_Response( array( 'assignment' => Student::public_assignment( $a ), 'submission' => Student::public_submission( Assignments::submission( (int) $a['id'], $uid ) ) ) );
	}

	public static function submit( \WP_REST_Request $r ): \WP_REST_Response {
		$res = Assignments::submit( (int) $r['id'], get_current_user_id(), (string) $r['answer'], array(), (bool) $r['final'] );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( Student::public_submission( $res ) );
	}

	public static function grade( \WP_REST_Request $r ): \WP_REST_Response {
		$score = null === $r['score'] || '' === $r['score'] ? null : (float) $r['score'];
		$res   = Assignments::grade( (int) $r['id'], $score, (string) $r['feedback'], (array) ( $r['rubric_scores'] ?? array() ), get_current_user_id(), 'return' === $r['action'] ? 'return' : 'grade' );
		if ( is_wp_error( $res ) ) {
			return self::err( $res );
		}
		if ( $r['release'] ) {
			Assignments::release( (int) $res['assignment_id'], get_current_user_id(), (int) $res['id'] );
			$res = Assignments::submission_by_id( (int) $res['id'] );
		}
		return new \WP_REST_Response( $res );
	}

	public static function release( \WP_REST_Request $r ): \WP_REST_Response {
		if ( ! current_user_can( 'ec_grade_assignment', (int) $r['id'] ) ) {
			return self::deny();
		}
		return new \WP_REST_Response( array( 'released' => Assignments::release( (int) $r['id'], get_current_user_id() ) ) );
	}

	public static function grading(): \WP_REST_Response {
		return new \WP_REST_Response( Portal::grading_items( get_current_user_id() ) );
	}

	public static function attendance( \WP_REST_Request $r ): \WP_REST_Response {
		$ctx = (string) $r['context'];
		$cid = absint( $r['context_id'] );
		$ok  = 'class' === $ctx ? current_user_can( 'ec_teach_class', $cid ) : ( 'session' === $ctx && current_user_can( 'ec_manage_session', $cid ) );
		if ( ! $ok ) {
			return self::deny();
		}
		$res = Attendance::record( $ctx, $cid, (string) $r['date'], (array) $r['marks'], get_current_user_id(), (array) ( $r['notes'] ?? array() ) );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( array( 'changed' => $res ) );
	}

	public static function attention(): \WP_REST_Response {
		return new \WP_REST_Response( Alerts::for_classes( Caps::classes_of( get_current_user_id() ) ) );
	}

	public static function analytics( \WP_REST_Request $r ): \WP_REST_Response {
		$uid   = get_current_user_id();
		$range = Analytics::range( (string) $r['from'], (string) $r['to'] );
		$cls   = Caps::classes_of( $uid );
		if ( $r['class_id'] ) {
			$cls = in_array( (int) $r['class_id'], $cls, true ) ? array( (int) $r['class_id'] ) : array();
		}
		return new \WP_REST_Response( array( 'range' => $range, 'teaching' => Analytics::teaching( $uid, $cls, $range ), 'tutoring' => current_user_can( 'ec_tutor_sessions' ) ? Analytics::tutoring( $uid, $range ) : null ) );
	}

	/** Public directory: approved + public profiles only; never contact details. */
	public static function tutors(): \WP_REST_Response {
		return new \WP_REST_Response( array_map( array( Student::class, 'public_tutor' ), Tutoring::directory( true ) ) );
	}

	public static function slots( \WP_REST_Request $r ): \WP_REST_Response {
		return new \WP_REST_Response( array_map( static fn( $s ) => array( 'start_utc' => $s, 'local' => Plugin::local( $s ) ), Tutoring::free_starts( (int) $r['id'], min( 60, absint( $r['days'] ?: 14 ) ) ) ) );
	}

	public static function save_profile( \WP_REST_Request $r ): \WP_REST_Response {
		return new \WP_REST_Response( Tutoring::save_profile( get_current_user_id(), (array) $r->get_params(), (bool) $r['submit'] ) );
	}

	public static function availability( \WP_REST_Request $r ): \WP_REST_Response {
		$uid = get_current_user_id();
		$res = Tutoring::set_availability( $uid, (array) $r['windows'] );
		if ( is_wp_error( $res ) ) {
			return self::err( $res );
		}
		if ( null !== $r['unavailable'] ) {
			Tutoring::set_unavailable( $uid, (array) $r['unavailable'] );
		}
		return new \WP_REST_Response( array( 'windows' => Tutoring::availability( $uid ), 'unavailable' => Tutoring::unavailable( $uid ) ) );
	}

	public static function sessions(): \WP_REST_Response {
		$uid = get_current_user_id();
		$out = current_user_can( 'ec_tutor_sessions' ) ? Tutoring::for_tutor( $uid ) : array_map( array( Student::class, 'public_session' ), Tutoring::for_student( $uid ) );
		return new \WP_REST_Response( $out );
	}

	public static function request_session( \WP_REST_Request $r ): \WP_REST_Response {
		$res = Tutoring::request( get_current_user_id(), absint( $r['tutor_id'] ), (string) $r['start_utc'], (array) $r->get_params() );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( array( 'id' => $res ), 201 );
	}

	public static function session( \WP_REST_Request $r ): \WP_REST_Response {
		$s = Tutoring::get( (int) $r['id'] );
		if ( ! $s || ! Tutoring::can_view( get_current_user_id(), $s ) ) {
			return self::deny( 404 );
		}
		return new \WP_REST_Response( current_user_can( 'ec_manage_session', (int) $s['id'] ) ? $s : Student::public_session( $s ) );
	}

	public static function session_status( \WP_REST_Request $r ): \WP_REST_Response {
		$res = Tutoring::transition( (int) $r['id'], (string) $r['status'], get_current_user_id(), (array) $r->get_params() );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( current_user_can( 'ec_manage_session', (int) $r['id'] ) ? $res : Student::public_session( $res ) );
	}

	public static function reschedule( \WP_REST_Request $r ): \WP_REST_Response {
		$start = $r['start_utc'] ? (string) $r['start_utc'] : (string) Plugin::local_to_utc( (string) $r['start'] );
		$res   = Tutoring::reschedule( (int) $r['id'], $start, get_current_user_id() );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( $res );
	}

	public static function threads(): \WP_REST_Response {
		return new \WP_REST_Response( Comms::threads_for( get_current_user_id() ) );
	}

	public static function start_thread( \WP_REST_Request $r ): \WP_REST_Response {
		$res = Comms::start( get_current_user_id(), (string) $r['context_type'], absint( $r['context_id'] ), (string) $r['subject'], (string) $r['body'], absint( $r['student_id'] ) );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( array( 'id' => $res ), 201 );
	}

	public static function thread( \WP_REST_Request $r ): \WP_REST_Response {
		$uid = get_current_user_id();
		$t   = Comms::thread( (int) $r['id'] );
		if ( ! $t || 'none' === Comms::access( $uid, $t ) ) {
			return self::deny( 404 );
		}
		return new \WP_REST_Response( array( 'thread' => $t, 'access' => Comms::access( $uid, $t ), 'messages' => Comms::messages( (int) $t['id'], $uid ) ) );
	}

	public static function reply( \WP_REST_Request $r ): \WP_REST_Response {
		$res = Comms::reply( get_current_user_id(), (int) $r['id'], (string) $r['body'] );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( array( 'id' => $res ), 201 );
	}

	public static function report( \WP_REST_Request $r ): \WP_REST_Response {
		$res = Comms::report( get_current_user_id(), absint( $r['thread_id'] ), absint( $r['message_id'] ), (string) $r['reason'] );
		return is_wp_error( $res ) ? self::err( $res ) : new \WP_REST_Response( array( 'id' => $res ), 201 );
	}
}
