<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Student dashboard / history view models (data only; rendering is in Frontend). */
final class Dashboard {

	public static function student( int $user_id ): array {
		$courses = array();
		$next    = array();
		$total_l = 0;
		$done_l  = 0;
		foreach ( Enrollment::for_user( $user_id ) as $e ) {
			$cid = (int) $e['course_id'];
			if ( 'publish' !== get_post_status( $cid ) ) {
				continue;
			}
			$s        = Progress::course_summary( $user_id, $cid );
			$total_l += $s['total'];
			$done_l  += $s['completed'];
			$current  = Enrollment::is_enrolled( $user_id, $cid );
			$courses[] = array(
				'course_id'   => $cid,
				'title'       => get_the_title( $cid ),
				'url'         => get_permalink( $cid ),
				'status'      => $e['status'],
				'accessible'  => $current,
				'expires_at'  => $e['expires_at'],
				'progress'    => $s,
				'continue'    => $s['next_lesson'] ? get_permalink( $s['next_lesson'] ) : get_permalink( $cid ),
			);
			if ( $current && $s['next_lesson'] ) {
				$next[] = array( 'lesson_id' => $s['next_lesson'], 'title' => get_the_title( $s['next_lesson'] ), 'course' => get_the_title( $cid ), 'url' => get_permalink( $s['next_lesson'] ) );
			}
		}
		$data = array(
			'user'         => array( 'name' => ( get_userdata( $user_id ) ?: new \WP_User() )->display_name ),
			'courses'      => $courses,
			'overall'      => array( 'completed' => $done_l, 'total' => $total_l, 'percent' => $total_l ? (int) floor( $done_l * 100 / $total_l ) : 0 ),
			'recommended'  => array_slice( $next, 0, 3 ),
			'goal'         => Gamification::weekly_goal( $user_id ),
			'achievements' => Gamification::achievements( $user_id ),
			'xp'           => Gamification::xp( $user_id ),
			'upcoming'     => array(),
			'pending'      => array(),
			'results'      => array(),
			'certificates' => array(),
			'announcements'=> array(),
			'consent'      => Privacy::has_required_consent( $user_id ),
		);
		/** Assessments, certificates, notifications enrich the dashboard. */
		return apply_filters( 'educore/dashboard/student', $data, $user_id );
	}

	public static function history( int $user_id ): array {
		global $wpdb;
		$lp   = Schema::table( 'lesson_progress' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT lesson_id, course_id, completed_at, active_seconds FROM {$lp} WHERE user_id=%d AND state='completed' ORDER BY completed_at DESC LIMIT 500", $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$completed = array();
		foreach ( $rows as $r ) {
			$completed[] = array(
				'lesson'         => get_the_title( (int) $r['lesson_id'] ),
				'course'         => get_the_title( (int) $r['course_id'] ),
				'completed_at'   => $r['completed_at'],
				'active_minutes' => (int) round( $r['active_seconds'] / 60 ),
			);
		}
		$weekly = $wpdb->get_results( $wpdb->prepare( "SELECT YEARWEEK(completed_at, 3) wk, MIN(DATE(completed_at)) week_start, COUNT(*) n FROM {$lp} WHERE user_id=%d AND state='completed' AND completed_at >= %s GROUP BY wk ORDER BY wk", $user_id, gmdate( 'Y-m-d', time() - 84 * DAY_IN_SECONDS ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$enrollments = array();
		foreach ( Enrollment::for_user( $user_id ) as $e ) {
			$enrollments[] = array( 'course' => get_the_title( (int) $e['course_id'] ), 'status' => $e['status'], 'since' => $e['starts_at'], 'completed_at' => $e['completed_at'], 'source' => $e['source'] );
		}
		return apply_filters(
			'educore/dashboard/history',
			array(
				'completed_lessons' => $completed,
				'weekly'            => $weekly ?: array(),
				'enrollments'       => $enrollments,
				'attempts'          => array(),
				'certificates'      => array(),
			),
			$user_id
		);
	}
}
