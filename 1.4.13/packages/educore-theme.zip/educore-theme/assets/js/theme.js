/* EduCore theme: dark-mode toggle (persisted) and reduced-motion-aware page fade. */
(function () {
	'use strict';
	var root = document.documentElement;
	var cfg = window.EduCoreTheme || {};
	function store(v) { try { localStorage.setItem('educore-theme', v); } catch (e) { /* storage unavailable */ } }
	function sync(btn) {
		var dark = root.getAttribute('data-theme') === 'dark';
		btn.setAttribute('aria-pressed', dark ? 'true' : 'false');
		btn.setAttribute('aria-label', dark ? (cfg.toLight || 'Light mode') : (cfg.toDark || 'Dark mode'));
	}
	document.querySelectorAll('[data-ect-theme-toggle]').forEach(function (btn) {
		sync(btn);
		btn.addEventListener('click', function () {
			var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
			var apply = function () { root.setAttribute('data-theme', next); store(next); document.querySelectorAll('[data-ect-theme-toggle]').forEach(sync); };
			var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
			if (document.startViewTransition && !reduce) { quiet(document.startViewTransition(apply)); } else { apply(); }
		});
	});
	/* An in-page transition can be skipped by the browser (e.g. tab hidden); that is not an error. */
	function quiet(vt) { if (vt) { ['ready', 'finished', 'updateCallbackDone'].forEach(function (k) { if (vt[k] && vt[k].catch) { vt[k].catch(function () {}); } }); } }
	/* Close the mobile <details> menu on Escape and return focus to its summary. */
	document.addEventListener('keydown', function (e) {
		if (e.key !== 'Escape') { return; }
		document.querySelectorAll('.ect-menu[open]').forEach(function (d) { d.removeAttribute('open'); d.querySelector('summary').focus(); });
	});
	/* 1.3.0 — product tour: big play button over the poster; native controls take over once playing. */
	document.querySelectorAll('[data-ect-video]').forEach(function (fig) {
		var v = fig.querySelector('video'); var b = fig.querySelector('.ect-video__play');
		if (!v || !b) { return; }
		b.hidden = false; v.controls = false;
		b.addEventListener('click', function () { b.hidden = true; v.controls = true; var p = v.play(); if (p && p.catch) { p.catch(function () { b.hidden = false; }); } v.focus(); });
		v.addEventListener('play', function () { b.hidden = true; v.controls = true; });
		v.addEventListener('ended', function () { b.hidden = false; });
	});
	/* Scroll reveal; everything is shown at once if the observer is unavailable or motion is reduced. */
	var items = document.querySelectorAll('.ect-reveal');
	if (items.length && 'IntersectionObserver' in window) {
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target); } });
		}, { rootMargin: '0px 0px -8% 0px' });
		items.forEach(function (el, i) { el.style.transitionDelay = (i % 4) * 70 + 'ms'; io.observe(el); });
	} else { items.forEach(function (el) { el.classList.add('is-visible'); }); }
})();
