<?php
/**
 * Plugin Name:       EduCore Identity
 * Plugin URI:        https://educore.gorgy.org
 * Description:       Unified identity for EduCore: sign in with Google, Microsoft, LinkedIn or Facebook alongside the existing EduCore password. Every method resolves to the same WordPress account through stable provider subject identifiers. Providers stay hidden until configured and tested; social sign-in never opens registration, grants roles or bypasses guardian consent or two-factor authentication.
 * Version:           1.0.0
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core
 * EduCore Requires Core: 1.2.0
 * Author:            GORGY.ORG
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-identity
 * Domain Path:       /languages
 *
 * @package EduCore\Identity
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_ID_VERSION', '1.0.0' );
define( 'EDUCORE_ID_FILE', __FILE__ );
define( 'EDUCORE_ID_DIR', plugin_dir_path( __FILE__ ) );
define( 'EDUCORE_ID_URL', plugin_dir_url( __FILE__ ) );

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Identity', '1.2.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Identity\\', EDUCORE_ID_DIR . 'src/' );
		\EduCore\Identity\Plugin::boot();
	}
);

register_activation_hook(
	__FILE__,
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) || version_compare( EDUCORE_CORE_VERSION, '1.2.0', '<' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die( esc_html__( 'EduCore Identity needs EduCore Core 1.2.0 or newer.', 'educore-identity' ), '', array( 'back_link' => true ) );
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Identity\\', EDUCORE_ID_DIR . 'src/' );
		\EduCore\Identity\Plugin::install();
	}
);
