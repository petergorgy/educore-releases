<?php
namespace EduCore\Recovery;

use EduCore\Core\Audit;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Schedules (WP-Cron tick + a token URL for a real server cron), pre-deployment backups and retention. */
final class Scheduler {
	public const LOCK = 'educore_rc_lock';

	private static function last( string $kind, string $trigger = '' ): ?object {
		global $wpdb;
		$t   = Backup::table();
		$sql = $trigger
			? $wpdb->prepare( "SELECT * FROM {$t} WHERE kind = %s AND trigger_source = %s AND status = 'complete' ORDER BY id DESC LIMIT 1", $kind, $trigger ) // phpcs:ignore WordPress.DB.PreparedSQL
			: $wpdb->prepare( "SELECT * FROM {$t} WHERE kind = %s AND status = 'complete' ORDER BY id DESC LIMIT 1", $kind ); // phpcs:ignore WordPress.DB.PreparedSQL
		return $wpdb->get_row( $sql ) ?: null; // phpcs:ignore WordPress.DB.PreparedSQL
	}

	private static function age( ?object $b ): float {
		return $b ? ( time() - strtotime( $b->created_at . ' UTC' ) ) / 3600 : INF;
	}

	/** Run whatever is due. Returns a log of actions. */
	public static function run_due( string $source = 'wp-cron' ): array {
		global $wpdb;
		$log = array();
		if ( get_transient( self::LOCK ) ) {
			return array( 'locked' );
		}
		set_transient( self::LOCK, 1, 2 * HOUR_IN_SECONDS );
		try {
			$t = Backup::table();
			// Backups interrupted by a crash or timeout are marked failed.
			$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status = 'failed', message = %s WHERE status = 'running' AND created_at < %s", 'Interrupted (timeout or crash).', gmdate( 'Y-m-d H:i:s', time() - 2 * HOUR_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			$s = Settings::all();
			if ( 'on' === $s['daily'] && self::age( self::last( 'academic', 'scheduled' ) ) >= 23 ) {
				$log[] = self::scheduled( 'academic' );
			}
			if ( 'on' === $s['weekly'] && self::age( self::last( 'full', 'scheduled' ) ) >= 24 * 7 - 1 ) {
				$log[] = self::scheduled( 'full' );
			}
			$log[] = 'pruned:' . self::prune();
			update_option( 'educore_rc_last_tick', gmdate( 'c' ), false );
			update_option( 'educore_rc_last_tick_' . sanitize_key( $source ), gmdate( 'c' ), false );
		} finally {
			delete_transient( self::LOCK );
		}
		return $log;
	}

	private static function scheduled( string $kind ): string {
		$id = Backup::create( $kind, 'scheduled' );
		if ( is_wp_error( $id ) ) {
			return "{$kind}:failed:" . $id->get_error_message();
		}
		$v = Verifier::verify( $id );
		return "{$kind}:{$id}:" . ( $v['ok'] ? 'verified' : 'verify_failed' );
	}

	/** Retention per trigger. Returns number of backups removed. */
	public static function prune(): int {
		global $wpdb;
		$t     = Backup::table();
		$s     = Settings::all();
		$rules = array(
			array( 'academic', 'scheduled', $s['keep_daily'] ),
			array( 'full', 'scheduled', $s['keep_weekly'] ),
			array( 'predeploy', 'predeploy', $s['keep_predeploy'] ),
			array( '', 'manual', $s['keep_manual'] ),
			array( '', 'pre_restore', 3 ),
		);
		$n = 0;
		foreach ( $rules as [ $kind, $trigger, $keep ] ) {
			$ids = $kind
				? $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t} WHERE kind = %s AND trigger_source = %s AND status = 'complete' ORDER BY id DESC LIMIT 1000 OFFSET %d", $kind, $trigger, max( 1, (int) $keep ) ) ) // phpcs:ignore WordPress.DB.PreparedSQL
				: $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t} WHERE trigger_source = %s AND status = 'complete' ORDER BY id DESC LIMIT 1000 OFFSET %d", $trigger, max( 1, (int) $keep ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			foreach ( $ids as $id ) {
				Backup::delete( (int) $id ) && ++$n;
			}
		}
		$old = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t} WHERE status = 'failed' AND created_at < %s", gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $old as $id ) {
			Backup::delete( (int) $id ) && ++$n;
		}
		// Orphaned temporary files (crashed runs).
		foreach ( (array) glob( Store::dir() . '/tmp-*' ) as $f ) {
			if ( filemtime( $f ) < time() - DAY_IN_SECONDS ) {
				wp_delete_file( $f );
			}
		}
		return $n;
	}

	/** Server-cron entry point: https://site/?educore_backup_cron=TOKEN (independent of WP-Cron traffic). */
	public static function cron_endpoint(): void {
		if ( ! isset( $_GET['educore_backup_cron'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- authenticated by secret token.
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET['educore_backup_cron'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$hash  = (string) get_option( 'educore_rc_cron_hash', '' );
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		if ( '' === $hash || ! hash_equals( $hash, hash( 'sha256', $token ) ) ) {
			status_header( 403 );
			exit( 'forbidden' );
		}
		if ( get_transient( 'educore_rc_cron_recent' ) ) {
			exit( 'ok: recently run' );
		}
		set_transient( 'educore_rc_cron_recent', 1, 5 * MINUTE_IN_SECONDS );
		ignore_user_abort( true );
		exit( 'ok: ' . esc_html( implode( '; ', self::run_due( 'http' ) ) ) );
	}

	/**
	 * Before WordPress overwrites an EduCore plugin or the EduCore theme, take (or reuse) a verified
	 * pre-deployment backup. If it cannot be made, the update is stopped.
	 *
	 * @param bool|\WP_Error $response
	 * @return bool|\WP_Error
	 */
	public static function pre_deployment( $response, $extra ) {
		if ( is_wp_error( $response ) || 'on' !== Settings::get( 'predeploy' ) ) {
			return $response;
		}
		$target = (string) ( $extra['plugin'] ?? ( $extra['theme'] ?? '' ) );
		if ( ! preg_match( '#^educore[-/]#', $target ) ) {
			return $response;
		}
		$recent = self::last( 'predeploy' );
		if ( $recent && self::age( $recent ) < 1 && 'verified' === $recent->verify_status ) {
			return $response; // One backup covers a bulk update.
		}
		$id = Backup::create( 'predeploy', 'predeploy' );
		if ( ! is_wp_error( $id ) ) {
			$v = Verifier::verify( $id );
			if ( $v['ok'] ) {
				return $response;
			}
			$id = new \WP_Error( 'ec_rc_predeploy', implode( '; ', $v['errors'] ) );
		}
		/** Allow an owner to proceed without a pre-deployment backup (default: no). */
		if ( apply_filters( 'educore/recovery/allow_deploy_without_backup', false ) ) {
			Audit::log( 'backup.predeploy_skipped', 'backup', 0, array( 'target' => $target ) );
			return $response;
		}
		return new \WP_Error( 'ec_rc_predeploy', __( 'Update stopped: the pre-deployment backup could not be created and verified.', 'educore-recovery' ) . ' ' . $id->get_error_message() );
	}

	/** Complete backups whose archive is no longer in storage (deleted outside EduCore, storage moved, disk loss). */
	public static function missing_files(): int {
		$n = 0;
		foreach ( Backup::list( 500 ) as $b ) {
			if ( 'complete' === $b->status && ( ! $b->file || ! Store::path( $b->file ) ) ) {
				++$n;
			}
		}
		return $n;
	}

	/** Hours since a server-side (cPanel cron or token URL) run; INF if never. */
	public static function server_tick_age(): float {
		$ages = array();
		foreach ( array( 'cli', 'http' ) as $src ) {
			$t = (string) get_option( 'educore_rc_last_tick_' . $src, '' );
			if ( $t ) {
				$ages[] = ( time() - strtotime( $t ) ) / 3600;
			}
		}
		return $ages ? min( $ages ) : INF;
	}

	/** Health facts for the dashboard and install checks. */
	public static function health(): array {
		global $wpdb;
		$t      = Backup::table();
		$last   = $wpdb->get_row( "SELECT * FROM {$t} WHERE status = 'complete' AND verify_status = 'verified' ORDER BY id DESC LIMIT 1" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$tested = $wpdb->get_row( "SELECT * FROM {$t} WHERE restore_test_status = 'passed' ORDER BY restore_tested_at DESC LIMIT 1" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$failed = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE status = 'failed' AND created_at > %s", gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$used   = (int) $wpdb->get_var( "SELECT COALESCE(SUM(size),0) FROM {$t} WHERE status = 'complete'" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$tick   = (string) get_option( 'educore_rc_last_tick', '' );
		return array(
			'last_verified'   => $last,
			'last_verified_h' => self::age( $last ),
			'last_tested'     => $tested,
			'failed_7d'       => $failed,
			'storage_bytes'   => $used,
			'free_bytes'      => function_exists( 'disk_free_space' ) ? @disk_free_space( Store::dir() ) : false, // phpcs:ignore WordPress.PHP.NoSilencedErrors
			'last_tick'       => $tick,
			'tick_age_h'      => $tick ? ( time() - strtotime( $tick ) ) / 3600 : INF,
			'encrypted'       => (bool) Settings::key(),
			'outside_webroot' => Store::outside_webroot(),
			'rpo_target_h'    => 'on' === Settings::get( 'daily' ) ? 24 : ( 'on' === Settings::get( 'weekly' ) ? 168 : null ),
			'last_restore'    => get_option( 'educore_rc_last_restore', array() ),
			'server_tick_h'   => self::server_tick_age(),
			'missing_files'   => self::missing_files(),
			'unencrypted'     => Store::unencrypted_count(),
			'key_source'      => Settings::key_source(),
			'key_downloaded'  => (string) get_option( 'educore_rc_key_downloaded', '' ),
		);
	}
}
