<?php
namespace EduCore\Certificates;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Issuance, revocation and lookup of certificates. */
final class Certificates {

	public static function get( int $id ): ?array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'certificates' ) . ' WHERE id=%d', $id ), ARRAY_A );
		return $r ?: null;
	}

	public static function by_uid( string $uid ): ?array {
		global $wpdb;
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $uid ) ) {
			return null;
		}
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'certificates' ) . ' WHERE uid=%s', $uid ), ARRAY_A );
		return $r ?: null;
	}

	/** @return array<int,array<string,mixed>> */
	public static function for_user( int $user_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'certificates' ) . ' WHERE user_id=%d ORDER BY issued_at DESC', $user_id ), ARRAY_A ) ?: array();
	}

	public static function on_course_completed( int $user_id, int $course_id ): void {
		if ( 'no' === get_post_meta( $course_id, '_ec_cert_enabled', true ) ) {
			return;
		}
		self::issue( $user_id, $course_id );
	}

	/**
	 * Issue (idempotent per user+course+template). Returns certificate id.
	 *
	 * @return int|\WP_Error
	 */
	public static function issue( int $user_id, int $course_id, int $template_id = 0 ) {
		global $wpdb;
		$user = get_userdata( $user_id );
		if ( ! $user || ! Content::is_course( $course_id ) ) {
			return new \WP_Error( 'educore_invalid', __( 'Unknown learner or course.', 'educore-certificates' ), array( 'status' => 404 ) );
		}
		$template_id = $template_id ?: Templates::for_course( $course_id, $user_id );
		$t           = Schema::table( 'certificates' );
		$existing    = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND course_id=%d AND template_id=%d", $user_id, $course_id, $template_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( $existing ) {
			if ( $existing['revoked_at'] ) {
				return new \WP_Error( 'educore_revoked', __( 'This certificate was revoked. Reinstate it instead of issuing a new one.', 'educore-certificates' ), array( 'status' => 409 ) );
			}
			return (int) $existing['id'];
		}
		$uid = bin2hex( random_bytes( 16 ) );
		$ok  = $wpdb->insert(
			$t,
			array(
				'uid'          => $uid,
				'user_id'      => $user_id,
				'course_id'    => $course_id,
				'template_id'  => $template_id,
				'student_name' => mb_substr( $user->display_name, 0, 191 ),
				'course_title' => mb_substr( get_the_title( $course_id ), 0, 255 ),
				'issued_at'    => Schema::now(),
				'issued_by'    => get_current_user_id(),
			)
		);
		if ( ! $ok ) {
			// Lost a race with a concurrent issue: return the winner.
			$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE user_id=%d AND course_id=%d AND template_id=%d", $user_id, $course_id, $template_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			return $id ?: new \WP_Error( 'educore_failed', __( 'Could not issue the certificate.', 'educore-certificates' ) );
		}
		$id = (int) $wpdb->insert_id;
		try {
			Pdf::generate( $id );
		} catch ( \Throwable $e ) {
			// The record is valid without a file; the PDF is regenerated on first download.
			Audit::log( 'certificate.pdf_failed', 'certificate', $id, array( 'error' => mb_substr( $e->getMessage(), 0, 200 ) ) );
		}
		Audit::log( 'certificate.issued', 'certificate', $id, array( 'user_id' => $user_id, 'course_id' => $course_id ) );
		do_action( 'educore/events/certificate_issued', $id, $user_id, $course_id );
		return $id;
	}

	public static function revoke( int $id, string $reason ): bool {
		global $wpdb;
		$reason = sanitize_text_field( $reason );
		if ( '' === $reason ) {
			return false;
		}
		$ok = (bool) $wpdb->query( $wpdb->prepare( 'UPDATE ' . Schema::table( 'certificates' ) . ' SET revoked_at=%s, revoke_reason=%s WHERE id=%d AND revoked_at IS NULL', Schema::now(), mb_substr( $reason, 0, 255 ), $id ) );
		if ( $ok ) {
			Audit::log( 'certificate.revoked', 'certificate', $id, array( 'reason' => $reason ) );
			do_action( 'educore/events/certificate_revoked', $id );
		}
		return $ok;
	}

	public static function reinstate( int $id ): bool {
		global $wpdb;
		$ok = (bool) $wpdb->query( $wpdb->prepare( 'UPDATE ' . Schema::table( 'certificates' ) . " SET revoked_at=NULL, revoke_reason='' WHERE id=%d AND revoked_at IS NOT NULL", $id ) );
		if ( $ok ) {
			Audit::log( 'certificate.reinstated', 'certificate', $id );
		}
		return $ok;
	}

	/** Public verification payload — no e-mail or internal ids. */
	public static function public_view( array $c ): array {
		return array(
			'certificate_id' => $c['uid'],
			'status'         => $c['revoked_at'] ? 'revoked' : 'valid',
			'student_name'   => $c['student_name'],
			'course_title'   => $c['course_title'],
			'issued_on'      => gmdate( 'Y-m-d', strtotime( $c['issued_at'] . ' UTC' ) ),
			'revoked_on'     => $c['revoked_at'] ? gmdate( 'Y-m-d', strtotime( $c['revoked_at'] . ' UTC' ) ) : null,
		);
	}

	public static function dashboard( array $data, int $user_id ): array {
		foreach ( self::for_user( $user_id ) as $c ) {
			if ( ! $c['revoked_at'] ) {
				$data['certificates'][] = array( 'title' => $c['course_title'], 'meta' => wp_date( get_option( 'date_format' ), strtotime( $c['issued_at'] . ' UTC' ) ), 'url' => Download::url( $c['uid'] ) );
			}
		}
		return $data;
	}

	public static function history( array $data, int $user_id ): array {
		foreach ( self::for_user( $user_id ) as $c ) {
			$data['certificates'][] = array( 'course' => $c['course_title'] . ( $c['revoked_at'] ? ' (' . __( 'revoked', 'educore-certificates' ) . ')' : '' ), 'issued' => $c['issued_at'], 'link' => $c['revoked_at'] ? Verify::url( $c['uid'] ) : Download::url( $c['uid'] ) );
		}
		return $data;
	}

	public static function export( array $data, $user ): array {
		if ( ! $user ) {
			return $data;
		}
		foreach ( self::for_user( (int) $user->ID ) as $c ) {
			$data[] = array(
				'group_id'    => 'educore-certificates',
				'group_label' => __( 'Certificates', 'educore-certificates' ),
				'item_id'     => 'certificate-' . $c['id'],
				'data'        => array(
					array( 'name' => 'certificate_id', 'value' => $c['uid'] ),
					array( 'name' => 'course', 'value' => $c['course_title'] ),
					array( 'name' => 'issued_at', 'value' => $c['issued_at'] ),
					array( 'name' => 'status', 'value' => $c['revoked_at'] ? 'revoked' : 'valid' ),
				),
			);
		}
		return $data;
	}
}
