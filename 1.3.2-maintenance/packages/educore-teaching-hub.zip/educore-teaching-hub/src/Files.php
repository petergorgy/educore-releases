<?php
namespace EduCore\TeachingHub;

defined( 'ABSPATH' ) || exit;

/**
 * Private file store for assignment attachments and submissions:
 * uploads/educore-teaching-hub/<random>.<ext>, web access denied, served only via Files::serve()
 * after an object-level permission check. Extension + real MIME type are both validated.
 */
final class Files {
	private const MIMES = array(
		'pdf'  => array( 'application/pdf' ),
		'docx' => array( 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip' ),
		'pptx' => array( 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip' ),
		'xlsx' => array( 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip' ),
		'odt'  => array( 'application/vnd.oasis.opendocument.text', 'application/zip' ),
		'txt'  => array( 'text/plain' ),
		'png'  => array( 'image/png' ),
		'jpg'  => array( 'image/jpeg' ),
		'jpeg' => array( 'image/jpeg' ),
	);

	public static function dir(): string {
		$up = wp_upload_dir( null, false );
		return trailingslashit( $up['basedir'] ) . 'educore-teaching-hub';
	}

	public static function ensure_dir(): string {
		$dir = self::dir();
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		$guards = array(
			'.htaccess'  => "# EduCore Teaching Hub: files are served only through the authenticated endpoint.\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n",
			'index.php'  => "<?php\n// Silence is golden.\n",
			'web.config' => "<?xml version=\"1.0\"?><configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
		);
		foreach ( $guards as $f => $c ) {
			if ( ! file_exists( "$dir/$f" ) ) {
				file_put_contents( "$dir/$f", $c ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
		}
		return $dir;
	}

	/** @return string[] allowed extensions (settings ∩ known safe list). */
	public static function allowed(): array {
		return array_values( array_intersect( array_map( 'trim', explode( ',', (string) Settings::get( 'file_types' ) ) ), array_keys( self::MIMES ) ) );
	}

	/**
	 * Validate and store one uploaded file ($_FILES entry).
	 *
	 * @return array{key:string,name:string,size:int}|\WP_Error
	 */
	public static function store( array $file ) {
		if ( ! isset( $file['tmp_name'], $file['name'], $file['size'] ) || UPLOAD_ERR_OK !== (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			return new \WP_Error( 'ec_th_upload', __( 'The file could not be uploaded.', 'educore-teaching-hub' ) );
		}
		$max = (int) Settings::get( 'max_file_mb' ) * MB_IN_BYTES;
		if ( (int) $file['size'] <= 0 || (int) $file['size'] > $max ) {
			/* translators: %d: megabytes */
			return new \WP_Error( 'ec_th_size', sprintf( __( 'Files must be smaller than %d MB.', 'educore-teaching-hub' ), (int) Settings::get( 'max_file_mb' ) ) );
		}
		$name = sanitize_file_name( wp_basename( (string) $file['name'] ) );
		$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, self::allowed(), true ) ) {
			/* translators: %s: list of extensions */
			return new \WP_Error( 'ec_th_type', sprintf( __( 'Allowed file types: %s.', 'educore-teaching-hub' ), implode( ', ', self::allowed() ) ) );
		}
		$tmp = (string) $file['tmp_name'];
		if ( ! self::mime_ok( $tmp, $ext ) ) {
			return new \WP_Error( 'ec_th_type', __( 'The file content does not match its type.', 'educore-teaching-hub' ) );
		}
		$key  = bin2hex( random_bytes( 16 ) ) . '.' . $ext;
		$dest = self::ensure_dir() . '/' . $key;
		$ok   = is_uploaded_file( $tmp ) ? move_uploaded_file( $tmp, $dest ) : ( defined( 'EDUCORE_TH_TESTING' ) && copy( $tmp, $dest ) );
		if ( ! $ok ) {
			return new \WP_Error( 'ec_th_upload', __( 'The file could not be saved.', 'educore-teaching-hub' ) );
		}
		return array( 'key' => $key, 'name' => mb_substr( $name, 0, 150 ), 'size' => (int) $file['size'] );
	}

	public static function mime_ok( string $path, string $ext ): bool {
		if ( ! is_readable( $path ) || ! function_exists( 'finfo_open' ) ) {
			return false;
		}
		$fi   = finfo_open( FILEINFO_MIME_TYPE );
		$mime = (string) finfo_file( $fi, $path );
		return in_array( $mime, self::MIMES[ $ext ] ?? array(), true );
	}

	/** Absolute path for a stored key, or null (rejects traversal). */
	public static function path( string $key ): ?string {
		if ( ! preg_match( '/^[a-f0-9]{32}\.[a-z0-9]{2,5}$/', $key ) ) {
			return null;
		}
		$p = self::dir() . '/' . $key;
		return is_file( $p ) ? $p : null;
	}

	public static function delete( string $key ): void {
		$p = self::path( $key );
		if ( $p ) {
			wp_delete_file( $p );
		}
	}

	/** Normalise $_FILES[field] (single or multiple) into a list of file arrays. */
	public static function from_request( string $field ): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- callers verify the nonce first.
		$f = $_FILES[ $field ] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- each entry is validated by Files::store() (size, extension, real MIME type) before use.
		if ( ! is_array( $f ) || ! isset( $f['name'] ) ) {
			return array();
		}
		if ( ! is_array( $f['name'] ) ) {
			return UPLOAD_ERR_NO_FILE === (int) $f['error'] ? array() : array( $f );
		}
		$out = array();
		foreach ( array_keys( $f['name'] ) as $i ) {
			if ( UPLOAD_ERR_NO_FILE !== (int) $f['error'][ $i ] ) {
				$out[] = array( 'name' => $f['name'][ $i ], 'type' => $f['type'][ $i ], 'tmp_name' => $f['tmp_name'][ $i ], 'error' => $f['error'][ $i ], 'size' => $f['size'][ $i ] );
			}
		}
		return $out;
	}

	/** Stream a file to an authorised viewer (caller has checked permission). */
	public static function serve( string $key, string $download_name ): void {
		$p = self::path( $key );
		if ( ! $p ) {
			status_header( 404 );
			exit;
		}
		\EduCore\Core\Access::no_cache_headers();
		header( 'Content-Type: application/octet-stream' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Disposition: attachment; filename="' . rawurlencode( sanitize_file_name( $download_name ) ) . '"' );
		header( 'Content-Length: ' . filesize( $p ) );
		readfile( $p ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}
}
