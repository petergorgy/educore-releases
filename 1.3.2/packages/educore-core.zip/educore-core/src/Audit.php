<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Append-only audit trail. IPs are stored as salted hashes, never raw. */
final class Audit {
	private const REDACT = array( 'password', 'pass', 'token', 'secret', 'answer_key', 'api_key', 'card' );

	public static function log( string $action, string $object_type = '', int $object_id = 0, array $context = array() ): void {
		global $wpdb;
		$table = Schema::table( 'audit_events' );
		$wpdb->insert(
			$table,
			array(
				'actor_id'    => get_current_user_id(),
				'action'      => substr( $action, 0, 64 ),
				'object_type' => substr( $object_type, 0, 32 ),
				'object_id'   => $object_id,
				'ip_hash'     => self::ip_hash(),
				'context'     => wp_json_encode( self::redact( $context ) ),
				'created_at'  => Schema::now(),
			),
			array( '%d', '%s', '%s', '%d', '%s', '%s', '%s' )
		);
		/** Fires after any audited domain action. */
		do_action( 'educore/audit/logged', $action, $object_type, $object_id, $context );
	}

	public static function redact( array $context ): array {
		foreach ( $context as $k => $v ) {
			foreach ( self::REDACT as $needle ) {
				if ( false !== stripos( (string) $k, $needle ) ) {
					$context[ $k ] = '[redacted]';
					continue 2;
				}
			}
			if ( is_array( $v ) ) {
				$context[ $k ] = self::redact( $v );
			}
		}
		return $context;
	}

	public static function ip_hash(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return '' === $ip ? '' : hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
	}

	/** @return array<int,array<string,mixed>> */
	public static function query( array $args = array() ): array {
		global $wpdb;
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['action'] ) ) {
			$where[]  = 'action LIKE %s';
			$params[] = $wpdb->esc_like( (string) $args['action'] ) . '%';
		}
		if ( ! empty( $args['actor_id'] ) ) {
			$where[]  = 'actor_id = %d';
			$params[] = (int) $args['actor_id'];
		}
		$limit    = min( 200, max( 1, (int) ( $args['per_page'] ?? 50 ) ) );
		$offset   = max( 0, ( (int) ( $args['page'] ?? 1 ) - 1 ) * $limit );
		$params[] = $limit;
		$params[] = $offset;
		$sql      = 'SELECT * FROM ' . Schema::table( 'audit_events' ) . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT %d OFFSET %d';
		return $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function purge_older_than( int $days ): int {
		global $wpdb;
		return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . Schema::table( 'audit_events' ) . ' WHERE created_at < %s', gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
	}
}
