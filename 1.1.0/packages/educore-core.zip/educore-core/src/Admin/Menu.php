<?php
namespace EduCore\Core\Admin;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Curriculum;
use EduCore\Core\Enrollment;
use EduCore\Core\Installer;
use EduCore\Core\Pages;
use EduCore\Core\Registry;
use EduCore\Core\Schema;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/** EduCore administration center (core modules). Other packages add submenus to 'educore'. */
final class Menu {

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ) );
		add_action( 'admin_init', array( self::class, 'handle' ) );
		add_action( 'admin_init', array( self::class, 'activation_redirect' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'assets' ) );
	}

	public static function menu(): void {
		add_menu_page( 'EduCore', 'EduCore', 'ec_access_workspace', 'educore', array( self::class, 'overview' ), 'dashicons-welcome-learn-more', 3 );
		add_submenu_page( 'educore', __( 'Overview', 'educore-core' ), __( 'Overview', 'educore-core' ), 'ec_access_workspace', 'educore', array( self::class, 'overview' ) );
		add_submenu_page( 'educore', __( 'Curriculum editor', 'educore-core' ), __( 'Curriculum editor', 'educore-core' ), 'edit_ec_courses', 'educore-curriculum', array( self::class, 'curriculum' ) );
		add_submenu_page( 'educore', __( 'Programmes', 'educore-core' ), __( 'Programmes', 'educore-core' ), 'ec_manage_programmes', 'educore-programmes', array( self::class, 'programmes' ) );
		add_submenu_page( 'educore', __( 'Enrollments', 'educore-core' ), __( 'Enrollments', 'educore-core' ), 'ec_manage_enrollments', 'educore-enrollments', array( self::class, 'enrollments' ) );
		add_submenu_page( 'educore', __( 'Instructors', 'educore-core' ), __( 'Instructor assignments', 'educore-core' ), 'ec_manage_all_courses', 'educore-staff', array( self::class, 'staff' ) );
		add_submenu_page( 'educore', __( 'Audit log', 'educore-core' ), __( 'Security & audit', 'educore-core' ), 'ec_view_audit_log', 'educore-audit', array( self::class, 'audit' ) );
		add_submenu_page( 'educore', __( 'Settings', 'educore-core' ), __( 'Settings', 'educore-core' ), 'ec_manage_settings', 'educore-settings', array( self::class, 'settings' ) );
		add_submenu_page( 'educore', __( 'Setup wizard', 'educore-core' ), __( 'Setup wizard', 'educore-core' ), 'ec_manage_settings', 'educore-setup', array( self::class, 'setup' ) );
	}

	public static function assets( string $hook ): void {
		if ( false === strpos( $hook, 'educore' ) ) {
			return;
		}
		wp_enqueue_style( 'educore-admin', EDUCORE_CORE_URL . 'assets/css/admin.css', array(), EDUCORE_CORE_VERSION );
		wp_enqueue_script( 'educore-admin', EDUCORE_CORE_URL . 'assets/js/admin.js', array(), EDUCORE_CORE_VERSION, true );
		wp_localize_script( 'educore-admin', 'EduCoreAdmin', array( 'rest' => esc_url_raw( rest_url( 'educore/v1/' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ), 'saved' => __( 'Order saved', 'educore-core' ), 'error' => __( 'Could not save order', 'educore-core' ) ) );
	}

	public static function activation_redirect(): void {
		if ( get_transient( 'educore_activation_redirect' ) && current_user_can( 'ec_manage_settings' ) && ! wp_doing_ajax() ) {
			delete_transient( 'educore_activation_redirect' );
			if ( ! get_option( 'educore_setup_done' ) ) {
				wp_safe_redirect( admin_url( 'admin.php?page=educore-setup' ) );
				exit;
			}
		}
	}

	private static function header( string $title ): void {
		echo '<div class="wrap ec-admin"><h1>' . esc_html( $title ) . '</h1>';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ec_done'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Done.', 'educore-core' ) . '</p></div>';
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ec_err'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['ec_err'] ) ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
	}

	private static function form_open( string $action ): void {
		echo '<form method="post">';
		wp_nonce_field( 'educore_admin_' . $action, '_ecnonce' );
		echo '<input type="hidden" name="educore_admin_action" value="' . esc_attr( $action ) . '">';
	}

	/* ---------- Overview ---------- */

	public static function overview(): void {
		global $wpdb;
		self::header( __( 'EduCore — Overview', 'educore-core' ) );
		$e   = Schema::table( 'enrollments' );
		$lp  = Schema::table( 'lesson_progress' );
		$students = (int) count( get_users( array( 'role' => 'ec_student', 'fields' => 'ID' ) ) );
		$active   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT user_id) FROM {$lp} WHERE last_seen_at >= %s", gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$instr    = (int) count( get_users( array( 'role__in' => array( 'ec_instructor' ), 'fields' => 'ID' ) ) );
		$courses  = (int) wp_count_posts( Content::COURSE )->publish;
		$enr      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$e} WHERE status IN ('active','completed')" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$done     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$e} WHERE status='completed'" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$tiles    = array(
			__( 'Students', 'educore-core' )            => number_format_i18n( $students ),
			__( 'Active students (30 days)', 'educore-core' ) => number_format_i18n( $active ),
			__( 'Instructors', 'educore-core' )         => number_format_i18n( $instr ),
			__( 'Published courses', 'educore-core' )   => number_format_i18n( $courses ),
			__( 'Enrollments', 'educore-core' )         => number_format_i18n( $enr ),
			__( 'Completion rate', 'educore-core' )     => $enr ? round( $done * 100 / $enr ) . '%' : '—',
		);
		$tiles = apply_filters( 'educore/admin/overview_tiles', $tiles );
		echo '<div class="ec-tiles">';
		foreach ( $tiles as $label => $value ) {
			echo '<div class="ec-tile"><span class="ec-tile__v">' . esc_html( (string) $value ) . '</span><span class="ec-tile__l">' . esc_html( $label ) . '</span></div>';
		}
		echo '</div><p class="description">' . esc_html__( 'Definitions: Students = users with the Student role. Active = learners with any lesson activity in the last 30 days. Completion rate = completed enrollments ÷ active+completed enrollments.', 'educore-core' ) . '</p>';
		echo '<h2>' . esc_html__( 'Platform health', 'educore-core' ) . '</h2><table class="widefat striped"><tbody>';
		foreach ( Installer::environment_checks() as $c ) {
			echo '<tr><td><span class="ec-status ec-status--' . esc_attr( $c['status'] ) . '">' . esc_html( strtoupper( $c['status'] ) ) . '</span></td><td>' . esc_html( $c['label'] ) . '</td><td>' . esc_html( $c['message'] ) . '</td></tr>';
		}
		echo '</tbody></table><h2>' . esc_html__( 'Installed EduCore packages', 'educore-core' ) . '</h2><ul>';
		foreach ( Registry::all() as $pkg => $ver ) {
			echo '<li><code>' . esc_html( $pkg ) . '</code> ' . esc_html( $ver ) . '</li>';
		}
		echo '</ul>';
		do_action( 'educore/admin/overview' );
		echo '</div>';
	}

	/* ---------- Curriculum editor (drag & drop + keyboard) ---------- */

	public static function curriculum(): void {
		self::header( __( 'Curriculum editor', 'educore-core' ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$course = isset( $_GET['course'] ) ? absint( $_GET['course'] ) : 0;
		$ids    = current_user_can( 'ec_manage_all_courses' ) ? get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'future' ), 'posts_per_page' => 500, 'fields' => 'ids' ) ) : Staff::courses_of( get_current_user_id() );
		echo '<form method="get"><input type="hidden" name="page" value="educore-curriculum"><label>' . esc_html__( 'Course', 'educore-core' ) . ' <select name="course" onchange="this.form.submit()"><option value="0">—</option>';
		foreach ( $ids as $id ) {
			echo '<option value="' . esc_attr( (string) $id ) . '"' . selected( $course, (int) $id, false ) . '>' . esc_html( get_the_title( $id ) ) . '</option>';
		}
		echo '</select></label> <noscript><button class="button">' . esc_html__( 'Open', 'educore-core' ) . '</button></noscript></form>';
		if ( ! $course || ! current_user_can( 'ec_edit_course', $course ) ) {
			echo '</div>';
			return;
		}
		echo '<p class="description">' . esc_html__( 'Drag items to reorder, or focus an item and use Alt + Arrow Up / Arrow Down. Order is saved automatically.', 'educore-core' ) . '</p>';
		echo '<div id="ec-live" class="screen-reader-text" aria-live="polite"></div>';
		$units = Content::units( $course, array( 'publish', 'draft', 'pending', 'future', 'ec_archived' ) );
		echo '<ol class="ec-sortable ec-units" data-ec-sortable>';
		foreach ( $units as $u ) {
			echo '<li class="ec-sort-item" draggable="true" tabindex="0" data-id="' . esc_attr( (string) $u->ID ) . '"><span class="ec-handle" aria-hidden="true">⋮⋮</span> <strong>' . esc_html( $u->post_title ) . '</strong> <em>(' . esc_html( $u->post_status ) . ')</em> <a href="' . esc_url( get_edit_post_link( $u->ID ) ) . '">' . esc_html__( 'Edit', 'educore-core' ) . '</a>';
			echo '<ol class="ec-sortable ec-lessons-admin" data-ec-sortable>';
			foreach ( Content::lessons_of_unit( $u->ID, array( 'publish', 'draft', 'pending', 'future', 'ec_archived' ) ) as $l ) {
				echo '<li class="ec-sort-item" draggable="true" tabindex="0" data-id="' . esc_attr( (string) $l->ID ) . '"><span class="ec-handle" aria-hidden="true">⋮⋮</span> ' . esc_html( $l->post_title ) . ' <em>(' . esc_html( $l->post_status ) . ')</em> <a href="' . esc_url( get_edit_post_link( $l->ID ) ) . '">' . esc_html__( 'Edit', 'educore-core' ) . '</a></li>';
			}
			echo '</ol>';
			self::form_open( 'add_lesson' );
			echo '<input type="hidden" name="unit_id" value="' . esc_attr( (string) $u->ID ) . '"><input name="title" required placeholder="' . esc_attr__( 'New lesson title', 'educore-core' ) . '"> <button class="button">' . esc_html__( 'Add lesson', 'educore-core' ) . '</button></form>';
			echo '</li>';
		}
		echo '</ol>';
		self::form_open( 'add_unit' );
		echo '<input type="hidden" name="course_id" value="' . esc_attr( (string) $course ) . '"><input name="title" required placeholder="' . esc_attr__( 'New unit title', 'educore-core' ) . '"> <button class="button button-primary">' . esc_html__( 'Add unit', 'educore-core' ) . '</button></form>';
		echo '<h2>' . esc_html__( 'Course actions', 'educore-core' ) . '</h2>';
		self::form_open( 'bulk_status' );
		echo '<input type="hidden" name="course_id" value="' . esc_attr( (string) $course ) . '"><select name="status"><option value="pending">' . esc_html__( 'Submit all drafts for review', 'educore-core' ) . '</option>';
		if ( current_user_can( 'publish_ec_courses' ) ) {
			echo '<option value="publish">' . esc_html__( 'Publish course, units and lessons', 'educore-core' ) . '</option>';
		}
		echo '<option value="ec_archived">' . esc_html__( 'Archive course', 'educore-core' ) . '</option></select> <button class="button">' . esc_html__( 'Apply', 'educore-core' ) . '</button></form>';
		self::form_open( 'duplicate' );
		echo '<input type="hidden" name="course_id" value="' . esc_attr( (string) $course ) . '"><button class="button">' . esc_html__( 'Duplicate course', 'educore-core' ) . '</button></form>';
		echo '</div>';
	}

	/* ---------- Programmes ---------- */

	public static function programmes(): void {
		self::header( __( 'Programmes, periods and subjects', 'educore-core' ) );
		echo '<p class="description">' . esc_html__( 'Hierarchy: Programme → Academic year → Semester → Subject → Course (Units → Lessons).', 'educore-core' ) . '</p>';
		foreach ( Curriculum::programmes() as $p ) {
			echo '<div class="ec-panel"><h2>' . esc_html( $p['name'] ) . ' <code>' . esc_html( $p['code'] ) . '</code></h2><ul>';
			foreach ( Curriculum::periods( (int) $p['id'] ) as $per ) {
				echo '<li>' . ( $per['parent_id'] ? '— ' : '' ) . esc_html( ucfirst( $per['type'] ) . ': ' . $per['label'] ) . '</li>';
			}
			echo '</ul><p><strong>' . esc_html__( 'Subjects:', 'educore-core' ) . '</strong> ' . esc_html( implode( ', ', wp_list_pluck( Curriculum::subjects( (int) $p['id'] ), 'name' ) ) ) . '</p>';
			self::form_open( 'add_period' );
			echo '<input type="hidden" name="programme_id" value="' . esc_attr( $p['id'] ) . '"><select name="type"><option value="year">' . esc_html__( 'Academic year', 'educore-core' ) . '</option><option value="semester">' . esc_html__( 'Semester', 'educore-core' ) . '</option></select> <select name="parent_id"><option value="0">' . esc_html__( '(top level)', 'educore-core' ) . '</option>';
			foreach ( Curriculum::periods( (int) $p['id'] ) as $per ) {
				if ( 'year' === $per['type'] ) {
					echo '<option value="' . esc_attr( $per['id'] ) . '">' . esc_html( $per['label'] ) . '</option>';
				}
			}
			echo '</select> <input name="label" required placeholder="' . esc_attr__( 'Label', 'educore-core' ) . '"> <button class="button">' . esc_html__( 'Add period', 'educore-core' ) . '</button></form>';
			self::form_open( 'add_subject' );
			echo '<input type="hidden" name="programme_id" value="' . esc_attr( $p['id'] ) . '"><input name="code" required placeholder="' . esc_attr__( 'code', 'educore-core' ) . '" size="10"> <input name="name" required placeholder="' . esc_attr__( 'Subject name', 'educore-core' ) . '"> <button class="button">' . esc_html__( 'Add subject', 'educore-core' ) . '</button></form></div>';
		}
		echo '<h2>' . esc_html__( 'New programme', 'educore-core' ) . '</h2>';
		self::form_open( 'add_programme' );
		echo '<input name="code" required placeholder="code"> <input name="name" required placeholder="' . esc_attr__( 'Programme name', 'educore-core' ) . '"> <input name="country" value="EG" size="3"> <button class="button button-primary">' . esc_html__( 'Create', 'educore-core' ) . '</button></form>';
		echo '<h2>' . esc_html__( 'Initial structure', 'educore-core' ) . '</h2><p>' . esc_html__( 'Creates the Egyptian Baccalaureate › Second Year › Semester 1 › Programming & AI structure with Unit 1 (Lessons 1.1–1.4) and Unit 2 (Lessons 2.1–2.3) as drafts. Titles are placeholders; no lesson content is generated.', 'educore-core' ) . '</p>';
		self::form_open( 'seed_structure' );
		echo '<button class="button">' . esc_html__( 'Create initial structure', 'educore-core' ) . '</button></form></div>';
	}

	/* ---------- Enrollments ---------- */

	public static function enrollments(): void {
		self::header( __( 'Enrollments', 'educore-core' ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$course = isset( $_GET['course'] ) ? absint( $_GET['course'] ) : 0;
		$ids    = current_user_can( 'ec_manage_all_courses' ) ? get_posts( array( 'post_type' => Content::COURSE, 'post_status' => 'any', 'posts_per_page' => 500, 'fields' => 'ids' ) ) : Staff::courses_of( get_current_user_id() );
		echo '<form method="get"><input type="hidden" name="page" value="educore-enrollments"><select name="course" onchange="this.form.submit()"><option value="0">—</option>';
		foreach ( $ids as $id ) {
			echo '<option value="' . esc_attr( (string) $id ) . '"' . selected( $course, (int) $id, false ) . '>' . esc_html( get_the_title( $id ) ) . '</option>';
		}
		echo '</select></form>';
		if ( ! $course || ! current_user_can( 'ec_manage_course_enrollments', $course ) ) {
			echo '</div>';
			return;
		}
		self::form_open( 'enroll' );
		echo '<input type="hidden" name="course_id" value="' . esc_attr( (string) $course ) . '"><textarea name="emails" rows="3" cols="60" placeholder="' . esc_attr__( 'E-mail addresses, one per line', 'educore-core' ) . '"></textarea><br><label>' . esc_html__( 'Access expires (optional)', 'educore-core' ) . ' <input type="date" name="expires"></label> <button class="button button-primary">' . esc_html__( 'Enroll', 'educore-core' ) . '</button></form>';
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Student', 'educore-core' ) . '</th><th>' . esc_html__( 'Status', 'educore-core' ) . '</th><th>' . esc_html__( 'Source', 'educore-core' ) . '</th><th>' . esc_html__( 'Expires', 'educore-core' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( Enrollment::for_course( $course ) as $e ) {
			$u = get_userdata( (int) $e['user_id'] );
			echo '<tr><td>' . esc_html( $u ? $u->display_name . ' <' . $u->user_email . '>' : '#' . $e['user_id'] ) . '</td><td>' . esc_html( $e['status'] ) . '</td><td>' . esc_html( $e['source'] ) . '</td><td>' . esc_html( (string) $e['expires_at'] ) . '</td><td>';
			self::form_open( 'enroll_status' );
			echo '<input type="hidden" name="course_id" value="' . esc_attr( (string) $course ) . '"><input type="hidden" name="user_id" value="' . esc_attr( $e['user_id'] ) . '"><select name="status">';
			foreach ( Enrollment::STATUSES as $s ) {
				echo '<option' . selected( $e['status'], $s, false ) . '>' . esc_html( $s ) . '</option>';
			}
			echo '</select> <button class="button button-small">' . esc_html__( 'Update', 'educore-core' ) . '</button></form></td></tr>';
		}
		echo '</tbody></table></div>';
	}

	/* ---------- Staff ---------- */

	public static function staff(): void {
		self::header( __( 'Instructor assignments', 'educore-core' ) );
		$staff_users = get_users( array( 'role__in' => array( 'ec_instructor', 'ec_grader', 'ec_academic_manager' ) ) );
		self::form_open( 'assign_staff' );
		echo '<select name="course_id" required><option value="">' . esc_html__( 'Course', 'educore-core' ) . '</option>';
		foreach ( get_posts( array( 'post_type' => Content::COURSE, 'post_status' => 'any', 'posts_per_page' => 500 ) ) as $c ) {
			echo '<option value="' . esc_attr( (string) $c->ID ) . '">' . esc_html( $c->post_title ) . '</option>';
		}
		echo '</select> <select name="user_id" required><option value="">' . esc_html__( 'Staff member', 'educore-core' ) . '</option>';
		foreach ( $staff_users as $u ) {
			echo '<option value="' . esc_attr( (string) $u->ID ) . '">' . esc_html( $u->display_name . ' (' . implode( ', ', $u->roles ) . ')' ) . '</option>';
		}
		echo '</select> <select name="role"><option value="lead">' . esc_html__( 'Lead instructor', 'educore-core' ) . '</option><option value="instructor">' . esc_html__( 'Instructor', 'educore-core' ) . '</option><option value="grader">' . esc_html__( 'Grader', 'educore-core' ) . '</option><option value="remove">' . esc_html__( 'Remove', 'educore-core' ) . '</option></select> <button class="button button-primary">' . esc_html__( 'Save', 'educore-core' ) . '</button></form>';
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Course', 'educore-core' ) . '</th><th>' . esc_html__( 'Staff', 'educore-core' ) . '</th></tr></thead><tbody>';
		foreach ( get_posts( array( 'post_type' => Content::COURSE, 'post_status' => 'any', 'posts_per_page' => 500 ) ) as $c ) {
			$list = array_map( static fn( $r ) => ( get_userdata( (int) $r['user_id'] )->display_name ?? '?' ) . ' — ' . $r['staff_role'], Staff::of_course( $c->ID ) );
			echo '<tr><td>' . esc_html( $c->post_title ) . '</td><td>' . esc_html( implode( '; ', $list ) ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	/* ---------- Audit ---------- */

	public static function audit(): void {
		self::header( __( 'Security & audit log', 'educore-core' ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$action = isset( $_GET['filter'] ) ? sanitize_text_field( wp_unslash( $_GET['filter'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		echo '<form method="get"><input type="hidden" name="page" value="educore-audit"><input name="filter" value="' . esc_attr( $action ) . '" placeholder="' . esc_attr__( 'Action prefix, e.g. security.', 'educore-core' ) . '"> <button class="button">' . esc_html__( 'Filter', 'educore-core' ) . '</button></form>';
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Time (UTC)', 'educore-core' ) . '</th><th>' . esc_html__( 'Actor', 'educore-core' ) . '</th><th>' . esc_html__( 'Action', 'educore-core' ) . '</th><th>' . esc_html__( 'Object', 'educore-core' ) . '</th><th>' . esc_html__( 'Context', 'educore-core' ) . '</th></tr></thead><tbody>';
		foreach ( Audit::query( array( 'action' => $action, 'page' => $page, 'per_page' => 50 ) ) as $r ) {
			$actor = $r['actor_id'] ? ( get_userdata( (int) $r['actor_id'] )->user_login ?? '#' . $r['actor_id'] ) : '—';
			echo '<tr><td>' . esc_html( $r['created_at'] ) . '</td><td>' . esc_html( $actor ) . '</td><td><code>' . esc_html( $r['action'] ) . '</code></td><td>' . esc_html( $r['object_type'] . ' #' . $r['object_id'] ) . '</td><td><code>' . esc_html( (string) $r['context'] ) . '</code></td></tr>';
		}
		echo '</tbody></table><p><a class="button" href="' . esc_url( add_query_arg( 'paged', $page + 1 ) ) . '">' . esc_html__( 'Older', 'educore-core' ) . '</a></p></div>';
	}

	/* ---------- Settings ---------- */

	public static function settings(): void {
		self::header( __( 'EduCore settings', 'educore-core' ) );
		self::form_open( 'settings' );
		$o = static fn( $k, $d = '' ) => get_option( $k, $d );
		echo '<table class="form-table"><tbody>';
		echo '<tr><th>' . esc_html__( 'Support e-mail', 'educore-core' ) . '</th><td><input type="email" class="regular-text" name="educore_support_email" value="' . esc_attr( $o( 'educore_support_email', 'support@educore.gorgy.org' ) ) . '"></td></tr>';
		echo '<tr><th>' . esc_html__( 'Default interface language', 'educore-core' ) . '</th><td><select name="educore_default_lang">';
		foreach ( \EduCore\Core\I18n::labels() as $c => $l ) {
			echo '<option value="' . esc_attr( $c ) . '"' . selected( $o( 'educore_default_lang', 'en' ), $c, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></td></tr>';
		echo '<tr><th>' . esc_html__( 'Self-registration', 'educore-core' ) . '</th><td><select name="educore_registration"><option value="open"' . selected( $o( 'educore_registration', 'open' ), 'open', false ) . '>' . esc_html__( 'Open', 'educore-core' ) . '</option><option value="closed"' . selected( $o( 'educore_registration', 'open' ), 'closed', false ) . '>' . esc_html__( 'Closed', 'educore-core' ) . '</option></select></td></tr>';
		echo '<tr><th>' . esc_html__( 'Consent text version', 'educore-core' ) . '</th><td><input name="educore_consent_version" value="' . esc_attr( $o( 'educore_consent_version', '1.0' ) ) . '" size="6"><p class="description">' . esc_html__( 'Increase when the privacy policy or terms change materially.', 'educore-core' ) . '</p></td></tr>';
		echo '<tr><th>' . esc_html__( 'Accounts created by administrators', 'educore-core' ) . '</th><td><label><input type="checkbox" name="educore_admin_created_is_consented" value="1"' . checked( (bool) $o( 'educore_admin_created_is_consented', true ), true, false ) . '> ' . esc_html__( 'Treat as consented (only when consent was collected offline, e.g. by the school)', 'educore-core' ) . '</label></td></tr>';
		echo '<tr><th>' . esc_html__( 'Gamification', 'educore-core' ) . '</th><td><select name="educore_gamification"><option value="on"' . selected( $o( 'educore_gamification', 'on' ), 'on', false ) . '>' . esc_html__( 'On (XP, badges, weekly goal)', 'educore-core' ) . '</option><option value="off"' . selected( $o( 'educore_gamification', 'on' ), 'off', false ) . '>' . esc_html__( 'Off', 'educore-core' ) . '</option></select></td></tr>';
		echo '<tr><th>' . esc_html__( 'Leaderboards', 'educore-core' ) . '</th><td><select name="educore_leaderboards"><option value="off"' . selected( $o( 'educore_leaderboards', 'off' ), 'off', false ) . '>' . esc_html__( 'Off (default)', 'educore-core' ) . '</option><option value="on"' . selected( $o( 'educore_leaderboards', 'off' ), 'on', false ) . '>' . esc_html__( 'On — adult learners who opt in only', 'educore-core' ) . '</option></select></td></tr>';
		echo '<tr><th>' . esc_html__( 'Audit log retention (days)', 'educore-core' ) . '</th><td><input type="number" min="0" name="educore_audit_retention_days" value="' . esc_attr( (string) $o( 'educore_audit_retention_days', 730 ) ) . '"><p class="description">' . esc_html__( '0 keeps logs forever.', 'educore-core' ) . '</p></td></tr>';
		do_action( 'educore/admin/settings_rows' );
		echo '</tbody></table><button class="button button-primary">' . esc_html__( 'Save settings', 'educore-core' ) . '</button></form>';
		echo '<h2>' . esc_html__( 'Uninstall behaviour', 'educore-core' ) . '</h2><p>' . esc_html__( 'Deleting the plugin keeps all academic records unless you explicitly confirm data removal below.', 'educore-core' ) . '</p>';
		self::form_open( 'uninstall_pref' );
		echo '<label><input type="checkbox" name="confirm1" value="1"> ' . esc_html__( 'I understand that uninstalling will permanently delete all EduCore data.', 'educore-core' ) . '</label><br><label>' . esc_html__( 'Type DELETE ALL DATA to confirm:', 'educore-core' ) . ' <input name="confirm2"></label> <button class="button">' . esc_html__( 'Save uninstall preference', 'educore-core' ) . '</button> <em>' . esc_html( 'yes' === $o( 'educore_uninstall_delete_data' ) ? __( 'Currently: delete on uninstall', 'educore-core' ) : __( 'Currently: keep data on uninstall', 'educore-core' ) ) . '</em></form></div>';
	}

	/* ---------- Setup wizard ---------- */

	public static function setup(): void {
		self::header( __( 'EduCore setup wizard', 'educore-core' ) );
		echo '<ol class="ec-steps"><li><h2>' . esc_html__( '1. Environment checks', 'educore-core' ) . '</h2><table class="widefat striped"><tbody>';
		foreach ( Installer::environment_checks() as $c ) {
			echo '<tr><td><span class="ec-status ec-status--' . esc_attr( $c['status'] ) . '">' . esc_html( strtoupper( $c['status'] ) ) . '</span></td><td>' . esc_html( $c['label'] ) . '</td><td>' . esc_html( $c['message'] ) . '</td></tr>';
		}
		echo '</tbody></table></li>';
		echo '<li><h2>' . esc_html__( '2. Database and roles', 'educore-core' ) . '</h2><p>' . esc_html__( 'Creates or upgrades EduCore tables for all active packages and re-applies roles. Safe to run again.', 'educore-core' ) . '</p>';
		self::form_open( 'repair' );
		echo '<button class="button">' . esc_html__( 'Run database & roles setup', 'educore-core' ) . '</button></form></li>';
		echo '<li><h2>' . esc_html__( '3. Default pages', 'educore-core' ) . '</h2><p>' . esc_html__( 'Creates Courses, My learning, Profile, Register, Guardian consent, Instructor workspace, About, Contact and DRAFT legal pages. Existing pages are kept.', 'educore-core' ) . '</p><ul>';
		foreach ( Pages::definitions() as $key => $def ) {
			$id = Pages::id( $key );
			echo '<li>' . esc_html( $def['title'] ) . ': ' . ( $id ? '<a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html( get_post_status( $id ) ?: '?' ) . '</a>' : esc_html__( 'missing', 'educore-core' ) ) . '</li>';
		}
		echo '</ul>';
		self::form_open( 'pages' );
		echo '<button class="button">' . esc_html__( 'Create missing pages', 'educore-core' ) . '</button></form></li>';
		echo '<li><h2>' . esc_html__( '4. Finish', 'educore-core' ) . '</h2><p>' . esc_html__( 'No demo students, grades, testimonials or courses are created. For staging, use: wp educore sample-data (refused when WP_ENVIRONMENT_TYPE is production).', 'educore-core' ) . '</p>';
		self::form_open( 'finish' );
		echo '<button class="button button-primary">' . esc_html__( 'Mark setup as complete', 'educore-core' ) . '</button></form></li></ol></div>';
	}

	/* ---------- POST handler ---------- */

	public static function handle(): void {
		if ( empty( $_POST['educore_admin_action'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['educore_admin_action'] ) );
		check_admin_referer( 'educore_admin_' . $action, '_ecnonce' );
		$p   = static fn( $k ) => isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : '';
		$int = static fn( $k ) => isset( $_POST[ $k ] ) ? absint( $_POST[ $k ] ) : 0;
		$err = '';
		switch ( $action ) {
			case 'add_unit':
				$cid = $int( 'course_id' );
				if ( ! current_user_can( 'ec_edit_course', $cid ) ) {
					wp_die( '', 403 );
				}
				$id = wp_insert_post( array( 'post_type' => Content::UNIT, 'post_status' => 'draft', 'post_title' => $p( 'title' ), 'menu_order' => 99 ) );
				update_post_meta( $id, '_ec_course_id', $cid );
				break;
			case 'add_lesson':
				$unit = $int( 'unit_id' );
				$cid  = Content::course_of( $unit );
				if ( get_post_type( $unit ) !== Content::UNIT || ! current_user_can( 'ec_edit_course', $cid ) ) {
					wp_die( '', 403 );
				}
				$id = wp_insert_post( array( 'post_type' => Content::LESSON, 'post_status' => 'draft', 'post_title' => $p( 'title' ), 'menu_order' => 99 ) );
				update_post_meta( $id, '_ec_unit_id', $unit );
				update_post_meta( $id, '_ec_course_id', $cid );
				break;
			case 'bulk_status':
				$cid    = $int( 'course_id' );
				$status = $p( 'status' );
				if ( ! current_user_can( 'ec_edit_course', $cid ) || ! in_array( $status, array( 'pending', 'publish', 'ec_archived' ), true ) || ( 'publish' === $status && ! current_user_can( 'publish_ec_courses' ) ) ) {
					wp_die( '', 403 );
				}
				$items = array( $cid );
				foreach ( Content::outline( $cid, array( 'draft', 'pending', 'publish', 'future' ) ) as $row ) {
					$items[] = $row['unit']->ID;
					foreach ( $row['lessons'] as $l ) {
						$items[] = $l->ID;
					}
				}
				foreach ( $items as $id ) {
					$cur = get_post_status( $id );
					if ( 'pending' === $status && 'draft' !== $cur ) {
						continue;
					}
					if ( 'ec_archived' === $status && $id !== $cid ) {
						continue;
					}
					wp_update_post( array( 'ID' => $id, 'post_status' => $status ) );
				}
				Audit::log( 'course.status_bulk', 'course', $cid, array( 'status' => $status ) );
				break;
			case 'duplicate':
				$cid = $int( 'course_id' );
				if ( ! current_user_can( 'ec_edit_course', $cid ) ) {
					wp_die( '', 403 );
				}
				$new = Content::duplicate_course( $cid, get_current_user_id() );
				wp_safe_redirect( admin_url( 'admin.php?page=educore-curriculum&course=' . $new . '&ec_done=1' ) );
				exit;
			case 'add_programme':
				if ( ! current_user_can( 'ec_manage_programmes' ) ) {
					wp_die( '', 403 );
				}
				$r   = Curriculum::create_programme( $p( 'code' ), $p( 'name' ), $p( 'country' ) ?: 'EG' );
				$err = is_wp_error( $r ) ? $r->get_error_message() : '';
				break;
			case 'add_period':
				if ( ! current_user_can( 'ec_manage_programmes' ) ) {
					wp_die( '', 403 );
				}
				Curriculum::add_period( $int( 'programme_id' ), $p( 'type' ), $p( 'label' ), $int( 'parent_id' ) );
				break;
			case 'add_subject':
				if ( ! current_user_can( 'ec_manage_programmes' ) ) {
					wp_die( '', 403 );
				}
				Curriculum::add_subject( $int( 'programme_id' ), $p( 'code' ), $p( 'name' ) );
				break;
			case 'seed_structure':
				if ( ! current_user_can( 'ec_manage_programmes' ) ) {
					wp_die( '', 403 );
				}
				Curriculum::seed_initial_structure();
				break;
			case 'enroll':
				$cid = $int( 'course_id' );
				if ( ! current_user_can( 'ec_manage_course_enrollments', $cid ) ) {
					wp_die( '', 403 );
				}
				$exp    = $p( 'expires' ) ? gmdate( 'Y-m-d 23:59:59', strtotime( $p( 'expires' ) ) ) : null;
				$emails = preg_split( '/[\s,;]+/', isset( $_POST['emails'] ) ? sanitize_textarea_field( wp_unslash( $_POST['emails'] ) ) : '' );
				$miss   = array();
				foreach ( array_filter( (array) $emails ) as $email ) {
					$u = get_user_by( 'email', sanitize_email( $email ) );
					if ( $u ) {
						Enrollment::enroll( (int) $u->ID, $cid, 'admin', $exp );
					} else {
						$miss[] = $email;
					}
				}
				/* translators: %s: list of e-mails */
				$err = $miss ? sprintf( __( 'No account found for: %s', 'educore-core' ), implode( ', ', $miss ) ) : '';
				break;
			case 'enroll_status':
				$cid = $int( 'course_id' );
				if ( ! current_user_can( 'ec_manage_course_enrollments', $cid ) ) {
					wp_die( '', 403 );
				}
				Enrollment::set_status( $int( 'user_id' ), $cid, $p( 'status' ) );
				break;
			case 'assign_staff':
				if ( ! current_user_can( 'ec_manage_all_courses' ) ) {
					wp_die( '', 403 );
				}
				if ( 'remove' === $p( 'role' ) ) {
					Staff::remove( $int( 'course_id' ), $int( 'user_id' ) );
				} elseif ( ! Staff::assign( $int( 'course_id' ), $int( 'user_id' ), $p( 'role' ) ) ) {
					$err = __( 'Assignment failed.', 'educore-core' );
				}
				break;
			case 'settings':
				if ( ! current_user_can( 'ec_manage_settings' ) ) {
					wp_die( '', 403 );
				}
				update_option( 'educore_support_email', sanitize_email( $p( 'educore_support_email' ) ) );
				update_option( 'educore_default_lang', \EduCore\Core\I18n::sanitize_lang( $p( 'educore_default_lang' ) ) );
				update_option( 'educore_registration', 'closed' === $p( 'educore_registration' ) ? 'closed' : 'open' );
				update_option( 'educore_consent_version', substr( $p( 'educore_consent_version' ), 0, 20 ) ?: '1.0' );
				update_option( 'educore_admin_created_is_consented', ! empty( $_POST['educore_admin_created_is_consented'] ) );
				update_option( 'educore_gamification', 'off' === $p( 'educore_gamification' ) ? 'off' : 'on' );
				update_option( 'educore_leaderboards', 'on' === $p( 'educore_leaderboards' ) ? 'on' : 'off' );
				update_option( 'educore_audit_retention_days', $int( 'educore_audit_retention_days' ) );
				do_action( 'educore/admin/settings_save' );
				Audit::log( 'settings.updated', 'settings', 0 );
				break;
			case 'uninstall_pref':
				if ( ! current_user_can( 'ec_manage_settings' ) ) {
					wp_die( '', 403 );
				}
				$yes = ! empty( $_POST['confirm1'] ) && 'DELETE ALL DATA' === $p( 'confirm2' );
				update_option( 'educore_uninstall_delete_data', $yes ? 'yes' : 'no' );
				Audit::log( 'settings.uninstall_pref', 'settings', 0, array( 'delete' => $yes ) );
				break;
			case 'repair':
				if ( ! current_user_can( 'ec_manage_settings' ) ) {
					wp_die( '', 403 );
				}
				delete_option( 'educore_core_roles_version' );
				\EduCore\Core\Plugin::maybe_upgrade();
				do_action( 'educore/install/repair' );
				break;
			case 'pages':
				if ( ! current_user_can( 'ec_manage_settings' ) ) {
					wp_die( '', 403 );
				}
				Pages::create_missing();
				flush_rewrite_rules();
				break;
			case 'finish':
				if ( ! current_user_can( 'ec_manage_settings' ) ) {
					wp_die( '', 403 );
				}
				update_option( 'educore_setup_done', 1 );
				break;
			default:
				return;
		}
		$ref = wp_validate_redirect( (string) wp_get_raw_referer(), admin_url( 'admin.php?page=educore' ) );
		wp_safe_redirect( $err ? add_query_arg( 'ec_err', rawurlencode( $err ), $ref ) : add_query_arg( 'ec_done', 1, remove_query_arg( 'ec_err', $ref ) ) );
		exit;
	}
}
