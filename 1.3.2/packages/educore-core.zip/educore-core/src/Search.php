<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Language-aware search index. Arabic text is normalised (diacritics removed,
 * alef/yaa/taa-marbuta variants unified); Latin text is lowercased with accents folded.
 */
final class Search {

	public static function normalize( string $text ): string {
		$text = wp_strip_all_tags( $text );
		// Arabic diacritics (tashkeel) and tatweel.
		$text = preg_replace( '/[\x{0610}-\x{061A}\x{064B}-\x{065F}\x{0670}\x{06D6}-\x{06ED}\x{0640}]/u', '', $text );
		$text = strtr(
			$text,
			array(
				'أ' => 'ا', 'إ' => 'ا', 'آ' => 'ا', 'ٱ' => 'ا',
				'ى' => 'ي', 'ئ' => 'ي', 'ؤ' => 'و', 'ة' => 'ه',
			)
		);
		$text = remove_accents( $text );
		$text = mb_strtolower( $text, 'UTF-8' );
		$text = preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $text );
		return trim( (string) $text );
	}

	public static function index_post( \WP_Post $post ): void {
		global $wpdb;
		if ( ! in_array( $post->post_type, array( Content::COURSE, Content::LESSON ), true ) ) {
			return;
		}
		$wpdb->replace(
			Schema::table( 'search_index' ),
			array(
				'object_id'   => $post->ID,
				'object_type' => $post->post_type,
				'lang'        => (string) get_post_meta( $post->ID, '_ec_lang', true ),
				'normalized'  => self::normalize( $post->post_title . ' ' . $post->post_excerpt . ' ' . $post->post_content ),
			),
			array( '%d', '%s', '%s', '%s' )
		);
	}

	public static function remove( int $post_id ): void {
		global $wpdb;
		$wpdb->delete( Schema::table( 'search_index' ), array( 'object_id' => $post_id ), array( '%d' ) );
	}

	/**
	 * @return int[] matching object ids (all terms must match).
	 */
	public static function find( string $query, string $object_type, int $limit = 200 ): array {
		global $wpdb;
		$terms = array_filter( explode( ' ', self::normalize( $query ) ) );
		if ( empty( $terms ) ) {
			return array();
		}
		$where  = array( 'object_type = %s' );
		$params = array( $object_type );
		foreach ( array_slice( $terms, 0, 6 ) as $t ) {
			$where[]  = 'normalized LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $t ) . '%';
		}
		$params[] = $limit;
		$sql      = 'SELECT object_id FROM ' . Schema::table( 'search_index' ) . ' WHERE ' . implode( ' AND ', $where ) . ' LIMIT %d';
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( $sql, $params ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}
}
