<?php
/**
 * Title: EduCore learning benefits
 * Slug: educore-theme/benefits
 * Categories: educore-theme, features
 * Description: Four learning benefits in cards.
 */
$items = array(
	array( '📘', __( 'Clear, short lessons', 'educore-theme' ), __( 'Every lesson states its objectives and ends with a summary, so you always know what you learned.', 'educore-theme' ) ),
	array( '✍️', __( 'Practice with feedback', 'educore-theme' ), __( 'Quizzes and exams give instant feedback and explanations, so mistakes become learning.', 'educore-theme' ) ),
	array( '📈', __( 'See your progress', 'educore-theme' ), __( 'Track completed lessons, scores and weekly goals on your personal dashboard.', 'educore-theme' ) ),
	array( '🌍', __( 'Your language', 'educore-theme' ), __( 'Use EduCore in English, Français or العربية — switch at any time.', 'educore-theme' ) ),
);
?>
<!-- wp:group {"align":"full","backgroundColor":"surface","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-surface-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:heading {"align":"wide"} --><h2 class="wp-block-heading alignwide"><?php esc_html_e( 'Why learn with EduCore', 'educore-theme' ); ?></h2><!-- /wp:heading -->
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<?php foreach ( $items as $it ) : ?>
<!-- wp:column {"className":"ect-card","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}}} -->
<div class="wp-block-column ect-card" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)">
<!-- wp:paragraph {"className":"ect-icon"} --><p class="ect-icon" aria-hidden="true"><?php echo esc_html( $it[0] ); ?></p><!-- /wp:paragraph -->
<!-- wp:heading {"level":3} --><h3 class="wp-block-heading"><?php echo esc_html( $it[1] ); ?></h3><!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color"><?php echo esc_html( $it[2] ); ?></p><!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<?php endforeach; ?>
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
