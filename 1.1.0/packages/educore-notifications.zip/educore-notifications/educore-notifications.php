<?php
/**
 * Plugin Name:       EduCore Notifications
 * Plugin URI:        https://educore.gorgy.org
 * Description:       Transactional e-mail for EduCore: persistent queue with retries, EN/FR/AR templates, delivery log and learner preferences.
 * Version:           1.1.0
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core
 * Author:            GORGY.ORG
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-notifications
 * Domain Path:       /languages
 *
 * @package EduCore\Notifications
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_NOTIFICATIONS_VERSION', '1.1.0' );
define( 'EDUCORE_NOTIFICATIONS_DB_VERSION', 1 );
define( 'EDUCORE_NOTIFICATIONS_FILE', __FILE__ );
define( 'EDUCORE_NOTIFICATIONS_DIR', plugin_dir_path( __FILE__ ) );

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Notifications', '1.0.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Notifications\\', EDUCORE_NOTIFICATIONS_DIR . 'src/' );
		\EduCore\Notifications\Plugin::boot();
	}
);

add_action(
	'admin_notices',
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) && current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'EduCore Notifications requires the EduCore Core plugin. It has not been loaded.', 'educore-notifications' ) . '</p></div>';
		}
	}
);

register_activation_hook(
	__FILE__,
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die( esc_html__( 'Please activate EduCore Core first.', 'educore-notifications' ), '', array( 'back_link' => true ) );
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Notifications\\', EDUCORE_NOTIFICATIONS_DIR . 'src/' );
		\EduCore\Notifications\Plugin::install();
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		wp_clear_scheduled_hook( 'educore_notifications_worker' );
		wp_clear_scheduled_hook( 'educore_notifications_reminders' );
	}
);
