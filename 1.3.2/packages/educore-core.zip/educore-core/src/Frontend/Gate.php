<?php
namespace EduCore\Core\Frontend;

use EduCore\Core\Access;
use EduCore\Core\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Server-side protection of lesson content in every output channel (templates, REST, feeds,
 * excerpts, search), plus non-cacheable headers for signed-in users.
 */
final class Gate {
	private static bool $rendering = false;

	public static function register(): void {
		add_filter( 'the_content', array( self::class, 'filter_content' ), 0 );
		add_filter( 'get_the_excerpt', array( self::class, 'filter_excerpt' ), 100, 2 );
		add_filter( 'rest_prepare_' . Content::LESSON, array( self::class, 'filter_rest' ), 10, 3 );
		add_filter( 'rest_prepare_' . Content::UNIT, array( self::class, 'filter_rest' ), 10, 3 );
		add_action( 'template_redirect', array( self::class, 'headers' ), 1 );
		add_action( 'pre_get_posts', array( self::class, 'exclude_from_search' ) );
	}

	public static function rendering(): bool {
		return self::$rendering;
	}

	/** Run a callback with the recursion guard set (used by blocks that render post content). */
	public static function guarded( callable $fn ) {
		$prev            = self::$rendering;
		self::$rendering = true;
		try {
			return $fn();
		} finally {
			self::$rendering = $prev;
		}
	}

	public static function filter_content( $content ) {
		$post = get_post();
		if ( ! $post || self::$rendering ) {
			return $content;
		}
		if ( Content::LESSON === $post->post_type ) {
			$uid = get_current_user_id();
			if ( ! Access::can_view_lesson( $uid, $post->ID ) ) {
				// Replace (not hide) the body so it never reaches the browser.
				return Views::gate( Content::course_of( $post->ID ) );
			}
			if ( is_singular( Content::LESSON ) && in_the_loop() && is_main_query() && ! self::template_has_block( 'educore/lesson-reader' ) ) {
				return self::guarded( static fn() => Views::lesson_reader( $post->ID, $content ) );
			}
		}
		if ( Content::COURSE === $post->post_type && is_singular( Content::COURSE ) && in_the_loop() && is_main_query() && ! self::template_has_block( 'educore/course-outline' ) ) {
			return self::guarded( static fn() => Views::course_details( $post->ID, $content ) );
		}
		return $content;
	}

	/** True when the active block template already renders the given block. */
	private static function template_has_block( string $block ): bool {
		global $_wp_current_template_content;
		return is_string( $_wp_current_template_content ) && false !== strpos( $_wp_current_template_content, 'wp:' . $block );
	}

	public static function filter_excerpt( $excerpt, $post = null ) {
		$post = get_post( $post );
		if ( $post && Content::LESSON === $post->post_type && ! Access::can_view_lesson( get_current_user_id(), $post->ID ) ) {
			return '';
		}
		return $excerpt;
	}

	public static function filter_rest( $response, $post, $request ) {
		if ( current_user_can( 'edit_post', $post->ID ) ) {
			return $response;
		}
		if ( Content::LESSON === $post->post_type && Access::can_view_lesson( get_current_user_id(), $post->ID ) ) {
			return $response;
		}
		$data = $response->get_data();
		foreach ( array( 'content', 'excerpt' ) as $field ) {
			if ( isset( $data[ $field ] ) ) {
				$data[ $field ] = array( 'rendered' => '', 'protected' => true );
			}
		}
		unset( $data['meta'] );
		$response->set_data( $data );
		return $response;
	}

	public static function headers(): void {
		if ( is_user_logged_in() ) {
			Access::no_cache_headers();
		}
	}

	public static function exclude_from_search( \WP_Query $q ): void {
		if ( ! is_admin() && $q->is_main_query() && $q->is_search() ) {
			$types = $q->get( 'post_type' );
			if ( empty( $types ) || 'any' === $types ) {
				$q->set( 'post_type', array( 'post', 'page', Content::COURSE ) );
			}
		}
	}
}
