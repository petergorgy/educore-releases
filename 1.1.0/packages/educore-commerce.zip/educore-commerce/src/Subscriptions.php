<?php
namespace EduCore\Commerce;

defined( 'ABSPATH' ) || exit;

/**
 * Optional bridge to WooCommerce Subscriptions (a separately licensed plugin).
 * STATUS: NOT TESTED — the plugin is not available in the development environment.
 * Behaviour: an active subscription grants access to the courses of its products until the next
 * payment date (+1 day grace); cancelled, expired or on-hold subscriptions revoke access.
 */
final class Subscriptions {

	public static function register(): void {
		if ( ! class_exists( '\WC_Subscriptions' ) && ! function_exists( 'wcs_get_subscription' ) ) {
			return;
		}
		add_action( 'woocommerce_subscription_status_active', array( self::class, 'activate' ) );
		foreach ( array( 'cancelled', 'expired', 'on-hold' ) as $s ) {
			add_action( 'woocommerce_subscription_status_' . $s, array( self::class, 'deactivate' ) );
		}
		add_action( 'woocommerce_subscription_renewal_payment_complete', array( self::class, 'activate' ) );
	}

	/** @param \WC_Subscription $sub */
	public static function activate( $sub ): void {
		$user = (int) $sub->get_user_id();
		$next = (int) $sub->get_time( 'next_payment' );
		$ends = $next ? gmdate( 'Y-m-d H:i:s', $next + DAY_IN_SECONDS ) : null;
		foreach ( $sub->get_items() as $item ) {
			$pid = (int) ( $item->get_variation_id() ?: $item->get_product_id() );
			foreach ( Woo::courses_of_product( $pid ) ?: Woo::courses_of_product( (int) $item->get_product_id() ) as $course ) {
				Entitlements::grant( $user, $course, (int) $sub->get_id(), $pid, $ends, 'subscription' );
			}
		}
	}

	/** @param \WC_Subscription $sub */
	public static function deactivate( $sub ): void {
		Entitlements::revoke_order( (int) $sub->get_id(), 'cancelled' );
	}
}
