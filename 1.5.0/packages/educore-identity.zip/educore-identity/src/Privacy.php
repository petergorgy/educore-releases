<?php
namespace EduCore\Identity;

defined( 'ABSPATH' ) || exit;

/** Connected sign-in methods in data exports; removed on erasure and when an account is deleted. */
final class Privacy {
	public static function register(): void {
		add_filter( 'educore/privacy/export', array( self::class, 'export' ), 10, 2 );
		add_filter( 'wp_privacy_personal_data_erasers', array( self::class, 'erasers' ) );
		add_action( 'deleted_user', array( Links::class, 'remove_user' ) );
		add_action( 'admin_init', array( self::class, 'policy_text' ) );
	}

	public static function export( $data, $user ) {
		$data = (array) $data;
		$uid  = $user instanceof \WP_User ? $user->ID : (int) $user;
		foreach ( Links::for_user( $uid ) as $l ) {
			$data[] = array(
				'group_id'    => 'educore-identity',
				'group_label' => __( 'Connected sign-in methods', 'educore-identity' ),
				'item_id'     => 'identity-' . $l['id'],
				'data'        => array(
					array( 'name' => __( 'Provider', 'educore-identity' ), 'value' => Providers::label( (string) $l['provider'] ) ),
					array( 'name' => __( 'E-mail at the provider', 'educore-identity' ), 'value' => (string) $l['email'] ),
					array( 'name' => __( 'Connected', 'educore-identity' ), 'value' => (string) $l['created_at'] ),
					array( 'name' => __( 'Last used', 'educore-identity' ), 'value' => (string) $l['last_login_at'] ),
				),
			);
		}
		return $data;
	}

	public static function erasers( array $e ): array {
		$e['educore-identity'] = array(
			'eraser_friendly_name' => __( 'EduCore connected sign-in methods', 'educore-identity' ),
			'callback'             => static function ( $email ) {
				$u = get_user_by( 'email', $email );
				$n = $u ? count( Links::for_user( $u->ID ) ) : 0;
				if ( $n ) {
					Links::remove_user( $u->ID );
				}
				return array( 'items_removed' => $n > 0, 'items_retained' => false, 'messages' => array(), 'done' => true );
			},
		);
		return $e;
	}

	/** Suggested privacy-policy text (Settings → Privacy). For legal review; EduCore does not publish it. */
	public static function policy_text(): void {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}
		wp_add_privacy_policy_content(
			'EduCore Identity',
			'<p>' . esc_html__( 'Suggested text (for legal review): If you choose to sign in with Google, Microsoft, LinkedIn or Facebook, you are sent to that company to confirm your identity. We receive an identifier for your account at that company and, where you allow it, your name and e-mail address. We use them only to sign you in to EduCore. We do not receive or store your password or access to your other data there, and we do not post anything on your behalf. You can disconnect the account at any time in Preferences; your EduCore password keeps working. The provider’s own privacy policy applies to what happens on their side.', 'educore-identity' ) . '</p>'
		);
	}
}
