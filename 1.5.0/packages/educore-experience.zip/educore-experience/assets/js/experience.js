/* EduCore Experience: keeps the time-of-day appearance current, preview on the Preferences page, explicit device
   location, reading position. No timers are trusted while a tab sleeps: the state is recomputed on wake/focus. */
(function () {
	'use strict';
	var cfg = window.EduCoreXPConfig || null;
	var xp = window.EduCoreXP || {};
	var root = document.documentElement;
	if (!cfg) { return; }

	var pending = null;

	function wall(tz) {
		try {
			var parts = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date());
			var h = 0, m = 0;
			parts.forEach(function (p) { if (p.type === 'hour') { h = +p.value; } if (p.type === 'minute') { m = +p.value; } });
			return h * 60 + m;
		} catch (e) { var d = new Date(); return d.getHours() * 60 + d.getMinutes(); }
	}
	function fixedState() {
		var t = wall(cfg.tz), s = cfg.states[0];
		for (var i = 0; i < cfg.schedule.length; i++) { if (t >= cfg.schedule[i]) { s = cfg.states[i]; } }
		return s;
	}
	function solarState() {
		if (!cfg.solar || !cfg.solar.days || Date.now() / 1000 > cfg.solar.until + 86400) { return null; }
		var now = Date.now() / 1000, s = null;
		cfg.solar.days.forEach(function (day) {
			cfg.states.forEach(function (st) { if (now >= day[st]) { s = st; } });
		});
		return s;
	}
	function modeNow() {
		if (!cfg.user) {
			try { var v = localStorage.getItem('educore-xp-anon'); if (v) { return v; } var o = localStorage.getItem('educore-theme'); if (o === 'dark' || o === 'light') { return o; } } catch (e) { /* no storage */ }
		}
		return cfg.mode;
	}
	/** @return {{state:string, dark:boolean}} */
	function compute(mode) {
		var s = '';
		if (cfg.states.indexOf(mode) > -1) { s = mode; }
		else if (mode === 'auto') { s = fixedState(); }
		else if (mode === 'solar') { s = solarState() || fixedState(); }
		var dark = s ? cfg.dark.indexOf(s) > -1 : (mode === 'dark' || (mode === 'system' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches));
		return { state: s, dark: dark };
	}
	function examActive() {
		return !!document.querySelector('form.ec-attempt, [data-ec-timer], [data-ec-attempt]');
	}
	function apply(r, opts) {
		opts = opts || {};
		var cur = root.getAttribute('data-educore-time-theme') || '';
		var curDark = root.getAttribute('data-theme') === 'dark';
		if (cur === r.state && curDark === r.dark) { return; }
		if (cfg.defer && examActive() && !opts.force) { pending = r; return; }
		var animate = !opts.instant && cfg.motion !== 'reduce' && !(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
		if (animate) { root.classList.add('ec-xp-transition'); setTimeout(function () { root.classList.remove('ec-xp-transition'); }, 1400); }
		if (r.state) { root.setAttribute('data-educore-time-theme', r.state); } else { root.removeAttribute('data-educore-time-theme'); }
		root.setAttribute('data-theme', r.dark ? 'dark' : 'light');
		document.querySelectorAll('[data-ec-theme-toggle], [data-ect-theme-toggle]').forEach(function (b) { b.setAttribute('aria-pressed', r.dark ? 'true' : 'false'); });
	}
	function tick(opts) {
		if (pending && !(cfg.defer && examActive())) { var p = pending; pending = null; apply(p, { force: true }); return; }
		apply(compute(modeNow()), opts);
	}
	tick({ instant: true });
	setInterval(tick, 30000);
	document.addEventListener('visibilitychange', function () { if (!document.hidden) { tick(); } });
	window.addEventListener('focus', function () { tick(); });
	window.addEventListener('pageshow', function () { tick({ instant: true }); });
	if (window.matchMedia) { try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () { tick(); }); } catch (e) { /* old browsers */ } }

	/* The light/dark buttons in the header and the workspace shell become a quick manual override. */
	document.addEventListener('click', function (e) {
		var btn = e.target.closest && e.target.closest('[data-ec-theme-toggle], [data-ect-theme-toggle]');
		if (!btn) { return; }
		e.preventDefault(); e.stopPropagation();
		var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
		setMode(next, true);
	}, true);

	function setMode(mode, persist) {
		cfg.mode = mode;
		apply(compute(mode), { force: true });
		root.setAttribute('data-ec-mode', mode);
		if (!persist) { return; }
		if (!cfg.user) {
			try { localStorage.setItem('educore-xp-anon', mode); localStorage.removeItem('educore-theme'); } catch (e) { /* no storage */ }
			return;
		}
		save({ appearance: mode });
	}
	function save(body) {
		if (!xp.rest || !xp.nonce) { return Promise.resolve(null); }
		return fetch(xp.rest + 'me/preferences', { method: 'POST', keepalive: true, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': xp.nonce }, body: JSON.stringify(body) })
			.then(function (r) { return r.ok ? r.json() : null; })
			.then(function (j) { if (j && j.appearance) { cfg = Object.assign(cfg, j.appearance); window.EduCoreXPConfig = cfg; } return j; })
			.catch(function () { return null; });
	}

	/* Preferences page: live preview, explicit device location, "now" hint for the chosen time zone. */
	var form = document.querySelector('[data-ec-xp-prefs], .ec-xp-tour__form');
	if (form) {
		form.addEventListener('change', function (e) {
			var t = e.target;
			if (t.name === 'appearance') { cfg.mode = t.value; apply(compute(t.value), { force: true }); }
			if (t.name === 'contrast') { t.checked ? root.setAttribute('data-ec-contrast', 'high') : root.removeAttribute('data-ec-contrast'); }
			if (t.name === 'motion') { t.checked ? root.setAttribute('data-ec-motion', 'reduce') : root.removeAttribute('data-ec-motion'); }
			if (t.name === 'density') { t.checked ? root.setAttribute('data-ec-density', 'compact') : root.removeAttribute('data-ec-density'); }
			if (t.name === 'reading') { t.checked ? root.setAttribute('data-ec-reading', 'spacious') : root.removeAttribute('data-ec-reading'); }
			if (t.name === 'font_scale') { t.value === '100' ? root.removeAttribute('data-ec-font') : root.setAttribute('data-ec-font', t.value); }
			if (t.name === 'timezone') { cfg.tz = t.value || cfg.tz; hint(); tick({ instant: true }); }
		});
		var hint = function () {
			var el = form.querySelector('[data-ec-xp-tznow]'); var sel = form.querySelector('select[name="timezone"]');
			if (!el || !sel) { return; }
			try { el.textContent = new Intl.DateTimeFormat(document.documentElement.lang || undefined, { timeZone: sel.value || cfg.tz, hour: '2-digit', minute: '2-digit', weekday: 'long' }).format(new Date()); } catch (e) { el.textContent = ''; }
		};
		hint();
		var sug = form.querySelector('[data-ec-xp-tzsuggest]'); var tzs = form.querySelector('select[name="timezone"]');
		try {
			var dev = Intl.DateTimeFormat().resolvedOptions().timeZone;
			if (sug && tzs && dev && !tzs.value && dev !== cfg.tz) {
				var b = document.createElement('button'); b.type = 'button'; b.className = 'ec-link'; b.textContent = (document.documentElement.lang || '').indexOf('ar') === 0 ? 'استخدم منطقة جهازي: ' + dev : (document.documentElement.lang || '').indexOf('fr') === 0 ? 'Utiliser le fuseau de mon appareil : ' + dev : 'Use my device’s time zone: ' + dev;
				b.addEventListener('click', function () { tzs.value = dev; tzs.dispatchEvent(new Event('change', { bubbles: true })); b.remove(); });
				sug.appendChild(b);
			}
		} catch (e) { /* no Intl */ }
		var locate = form.querySelector('[data-ec-xp-locate]');
		if (locate && navigator.geolocation) {
			locate.hidden = false;
			locate.addEventListener('click', function () {
				var st = form.querySelector('[data-ec-xp-locate-status]');
				navigator.geolocation.getCurrentPosition(function (pos) {
					form.querySelector('[data-ec-xp-lat]').value = pos.coords.latitude.toFixed(2);
					form.querySelector('[data-ec-xp-lng]').value = pos.coords.longitude.toFixed(2);
					var city = form.querySelector('select[name="solar_city"]'); if (city) { city.value = ''; }
					if (st) { st.textContent = locate.getAttribute('data-ok') || '✓'; }
				}, function () { if (st) { st.textContent = locate.getAttribute('data-fail') || '—'; } }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 3600000 });
			});
		}
	}

	/* Reading position on lessons (signed-in only). Offers a jump button; never scrolls on its own. */
	if (xp.user && xp.lesson) {
		var last = 0, timer = null;
		var ratio = function () { var h = document.documentElement.scrollHeight - innerHeight; return h > 0 ? Math.min(1, Math.max(0, scrollY / h)) : 0; };
		var send = function (keep) {
			var r = Math.round(ratio() * 1000) / 1000;
			if (Math.abs(r - last) < 0.02) { return; }
			last = r;
			fetch(xp.rest + 'me/resume', { method: 'POST', credentials: 'same-origin', keepalive: !!keep, headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': xp.nonce }, body: JSON.stringify({ lesson: xp.lesson, position: r }) }).catch(function () {});
		};
		window.addEventListener('scroll', function () { clearTimeout(timer); timer = setTimeout(send, 4000); }, { passive: true });
		document.addEventListener('visibilitychange', function () { if (document.hidden) { send(true); } });
		window.addEventListener('pagehide', function () { send(true); });
		if (xp.resumeAt > 0.05 && /[?&]ec_resume=1/.test(location.search)) {
			var main = document.querySelector('.ec-reader, main, .ec-app-main');
			if (main) {
				var b = document.createElement('button');
				b.type = 'button'; b.className = 'ec-btn ec-xp-resume';
				b.textContent = (xp.i18n && xp.i18n.jump) || 'Jump to where I left off';
				b.addEventListener('click', function () {
					var h = document.documentElement.scrollHeight - innerHeight;
					window.scrollTo({ top: Math.round(h * xp.resumeAt), behavior: cfg.motion === 'reduce' ? 'auto' : 'smooth' });
					b.remove();
				});
				main.insertBefore(b, main.firstChild);
			}
		}
	}
})();
