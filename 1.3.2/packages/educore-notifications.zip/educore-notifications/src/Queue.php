<?php
namespace EduCore\Notifications;

use EduCore\Core\Audit;
use EduCore\Core\I18n;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Persistent, idempotent e-mail queue.
 * Status: queued → sending → accepted_by_mta | queued (retry) | failed; or cancelled.
 * "accepted_by_mta" means the mail server accepted the message. Inbox delivery is never claimed.
 */
final class Queue {
	public const BATCH    = 25;
	public const BUDGET   = 20;      // seconds per run.
	public const BACKOFF  = array( 300, 1800, 7200 ); // 5 min, 30 min, 2 h.
	public const MAX_TRY  = 4;       // first attempt + 3 retries.
	public const STATUSES = array( 'queued', 'sending', 'accepted_by_mta', 'failed', 'cancelled' );

	/**
	 * Queue a message for a user (int) or an e-mail address (string).
	 *
	 * @param int|string $recipient
	 * @return int job id; 0 when skipped by preference or duplicate.
	 */
	public static function enqueue( string $event, $recipient, array $vars, string $key, array $opts = array() ): int {
		global $wpdb;
		$user_id = 0;
		$email   = '';
		$lang    = isset( $opts['lang'] ) ? I18n::sanitize_lang( $opts['lang'] ) : 'en';
		if ( is_int( $recipient ) || ctype_digit( (string) $recipient ) ) {
			$user = get_userdata( (int) $recipient );
			if ( ! $user ) {
				return 0;
			}
			$user_id = (int) $user->ID;
			$email   = $user->user_email;
			if ( ! isset( $opts['lang'] ) ) {
				$lang = I18n::sanitize_lang( get_user_meta( $user_id, 'educore_lang', true ) ?: get_option( 'educore_default_lang', 'en' ) );
			}
			$vars = array_merge( array( 'name' => $user->display_name ), $vars );
			if ( ! Prefs::allows( $user_id, $event ) ) {
				return 0;
			}
		} else {
			$email = sanitize_email( (string) $recipient );
		}
		if ( ! is_email( $email ) ) {
			return 0;
		}
		$msg = Templates::render( $event, $lang, $vars );
		$now = Schema::now();
		$ok  = $wpdb->query(
			$wpdb->prepare(
				'INSERT IGNORE INTO ' . Schema::table( 'notification_jobs' ) . ' (event,recipient_id,recipient_email,channel,lang,subject,body,payload,status,tries,max_tries,next_try_at,idempotency_key,created_at) VALUES (%s,%d,%s,%s,%s,%s,%s,%s,%s,0,%d,%s,%s,%s)', // phpcs:ignore WordPress.DB.PreparedSQL
				$event,
				$user_id,
				$email,
				'email',
				$lang,
				mb_substr( $msg['subject'], 0, 250 ),
				$msg['html'],
				wp_json_encode( array( 'text' => $msg['text'] ) ),
				'queued',
				(int) ( $opts['max_tries'] ?? self::MAX_TRY ),
				$now,
				substr( $event . ':' . $key, 0, 191 ),
				$now
			)
		);
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	public static function get( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'notification_jobs' ) . ' WHERE id=%d', $id ), ARRAY_A );
		return $row ?: null;
	}

	/** Worker: send due jobs within the batch and time budget. Returns counts. */
	public static function process(): array {
		global $wpdb;
		$t     = Schema::table( 'notification_jobs' );
		$start = microtime( true );
		$stats = array( 'accepted' => 0, 'retry' => 0, 'failed' => 0 );
		// Recover jobs stuck in "sending" (e.g. a PHP process killed by the host).
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status='queued' WHERE status='sending' AND next_try_at < %s", gmdate( 'Y-m-d H:i:s', time() - 900 ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t} WHERE status='queued' AND next_try_at <= %s ORDER BY id ASC LIMIT %d", Schema::now(), self::BATCH ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $ids as $id ) {
			if ( microtime( true ) - $start > self::BUDGET ) {
				break;
			}
			// Atomic claim so concurrent cron runs never double-send.
			$claimed = $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status='sending', next_try_at=%s WHERE id=%d AND status='queued'", Schema::now(), $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			if ( 1 !== (int) $claimed ) {
				continue;
			}
			$job    = self::get( (int) $id );
			$result = Mailer::send( $job );
			$tries  = (int) $job['tries'] + 1;
			if ( true === $result ) {
				$wpdb->update( $t, array( 'status' => 'accepted_by_mta', 'tries' => $tries, 'sent_at' => Schema::now(), 'last_error' => '' ), array( 'id' => $id ) );
				++$stats['accepted'];
			} elseif ( $tries >= (int) $job['max_tries'] ) {
				$wpdb->update( $t, array( 'status' => 'failed', 'tries' => $tries, 'last_error' => mb_substr( (string) $result, 0, 500 ) ), array( 'id' => $id ) );
				Audit::log( 'notification.failed', 'notification', (int) $id, array( 'event' => $job['event'] ) );
				++$stats['failed'];
			} else {
				$delay = self::BACKOFF[ min( $tries - 1, count( self::BACKOFF ) - 1 ) ];
				$wpdb->update( $t, array( 'status' => 'queued', 'tries' => $tries, 'next_try_at' => gmdate( 'Y-m-d H:i:s', time() + $delay ), 'last_error' => mb_substr( (string) $result, 0, 500 ) ), array( 'id' => $id ) );
				++$stats['retry'];
			}
		}
		return $stats;
	}

	public static function retry( int $id ): bool {
		global $wpdb;
		return (bool) $wpdb->query( $wpdb->prepare( 'UPDATE ' . Schema::table( 'notification_jobs' ) . " SET status='queued', next_try_at=%s, tries=0 WHERE id=%d AND status IN ('failed','cancelled')", Schema::now(), $id ) );
	}

	public static function cancel( int $id ): bool {
		global $wpdb;
		return (bool) $wpdb->query( $wpdb->prepare( 'UPDATE ' . Schema::table( 'notification_jobs' ) . " SET status='cancelled' WHERE id=%d AND status='queued'", $id ) );
	}

	/** @return array<string,int> */
	public static function counts( int $days = 7 ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) n FROM ' . Schema::table( 'notification_jobs' ) . ' WHERE created_at >= %s GROUP BY status', gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ), ARRAY_A );
		$out  = array_fill_keys( self::STATUSES, 0 );
		foreach ( $rows as $r ) {
			$out[ $r['status'] ] = (int) $r['n'];
		}
		return $out;
	}
}
