<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Teaching Hub e-mails go through the EduCore Notifications queue (same retries, delivery log, learner
 * preferences). Without the Notifications package nothing is sent and nothing breaks.
 */
final class Notify {

	public static function register(): void {
		add_filter( 'educore/notifications/templates', array( self::class, 'templates' ) );
		add_action( 'educore/th/assignment_published', array( self::class, 'assignment_published' ) );
		add_action( 'educore/th/submitted', array( self::class, 'submitted' ), 10, 3 );
		add_action( 'educore/th/released', array( self::class, 'released' ) );
		add_action( 'educore/th/returned', array( self::class, 'returned' ) );
		add_action( 'educore/th/session_requested', array( self::class, 'session_requested' ) );
		foreach ( array( 'confirmed', 'declined', 'cancelled' ) as $st ) {
			add_action( 'educore/th/session_' . $st, static fn( $id ) => self::session_status( (int) $id, $st ) );
		}
		add_action( 'educore/th/session_rescheduled', static fn( $id ) => self::session_status( (int) $id, 'rescheduled' ) );
		add_action( 'educore/th/guardian_session_request', array( self::class, 'guardian_request' ), 10, 3 );
		add_action( 'educore/th/message_posted', array( self::class, 'message_posted' ), 10, 3 );
		add_action( 'educore/th/concern_reported', array( self::class, 'concern' ) );
		add_action( 'educore/th/tutor_reviewed', array( self::class, 'tutor_reviewed' ), 10, 2 );
		add_action( 'educore/th/class_member_added', array( self::class, 'class_joined' ), 10, 2 );
	}

	private static function q( string $event, $to, array $vars, string $key ): void {
		if ( class_exists( '\EduCore\Notifications\Queue' ) ) {
			\EduCore\Notifications\Queue::enqueue( $event, $to, $vars, $key );
		}
	}

	private static function hub_url( string $view = '', array $args = array() ): string {
		return Portal::url( $view, $args );
	}

	private static function dash_url(): string {
		return \EduCore\Core\Pages::url( 'dashboard' );
	}

	public static function assignment_published( int $id ): void {
		$a = Assignments::get( $id );
		if ( ! $a ) {
			return;
		}
		foreach ( Assignments::roster( $id ) as $r ) {
			self::q( 'th_assignment', (int) $r['student_id'], array( 'title' => $a['title'], 'date' => Plugin::local( $a['due_at'] ), 'url' => self::dash_url() ), "a{$id}:u{$r['student_id']}" );
		}
	}

	public static function submitted( int $sid, int $assignment_id, int $student_id ): void {
		$a = Assignments::get( $assignment_id );
		foreach ( Comms::context_staff( 'assignment', $assignment_id ) as $uid ) {
			self::q( 'th_submission', (int) $uid, array( 'title' => $a['title'], 'url' => self::hub_url( 'assignment', array( 'id' => $assignment_id ) ) ), "s{$sid}:t" . time() . ":u{$uid}" );
		}
		self::q( 'attempt_received', $student_id, array( 'title' => $a['title'], 'date' => Plugin::local( Schema::now() ) ), "ths{$sid}:" . time() );
	}

	public static function released( int $sid ): void {
		$s = Assignments::submission_by_id( $sid );
		$a = $s ? Assignments::get( (int) $s['assignment_id'] ) : null;
		if ( $a ) {
			self::q( 'grade_released', (int) $s['student_id'], array( 'title' => $a['title'], 'url' => self::dash_url() ), "thr{$sid}:" . time() );
		}
	}

	public static function returned( int $sid ): void {
		$s = Assignments::submission_by_id( $sid );
		$a = $s ? Assignments::get( (int) $s['assignment_id'] ) : null;
		if ( $a ) {
			self::q( 'th_returned', (int) $s['student_id'], array( 'title' => $a['title'], 'url' => self::dash_url() ), "thret{$sid}:" . time() );
		}
	}

	public static function session_requested( int $id ): void {
		$s = Tutoring::get( $id );
		if ( $s ) {
			self::q( 'th_session_request', (int) $s['tutor_id'], array( 'title' => $s['subject'], 'date' => Plugin::local( $s['starts_at'] ), 'url' => self::hub_url( 'session', array( 'id' => $id ) ) ), "sr{$id}" );
		}
	}

	public static function session_status( int $id, string $status ): void {
		$s = Tutoring::get( $id );
		if ( ! $s ) {
			return;
		}
		foreach ( Tutoring::participants( $id ) as $uid ) {
			self::q( 'th_session_' . $status, (int) $uid, array( 'title' => $s['subject'], 'date' => Plugin::local( $s['starts_at'] ), 'url' => self::dash_url() ), "ss{$id}:{$status}:" . md5( $s['updated_at'] ) . ":u{$uid}" );
		}
	}

	public static function guardian_request( int $id, string $email, string $url ): void {
		$s = Tutoring::get( $id );
		$u = $s ? get_userdata( (int) $s['student_id'] ) : null;
		if ( $s && $u ) {
			self::q( 'th_guardian_session', $email, array( 'name' => '', 'title' => $u->display_name, 'date' => Plugin::local( $s['starts_at'] ), 'url' => $url ), "gs{$id}:" . md5( $email ) );
		}
	}

	/** Notify the other participants; guardians of minors get a copy when guardian visibility is on. */
	public static function message_posted( int $thread_id, int $message_id, int $author ): void {
		$t = Comms::thread( $thread_id );
		if ( ! $t ) {
			return;
		}
		$to = Comms::context_staff( $t['context_type'], (int) $t['context_id'] );
		if ( (int) $t['student_id'] ) {
			$to[] = (int) $t['student_id'];
		} else {
			$to = array_merge( $to, Comms::context_students( $t['context_type'], (int) $t['context_id'] ) );
		}
		foreach ( array_unique( array_diff( $to, array( $author ) ) ) as $uid ) {
			self::q( 'th_message', (int) $uid, array( 'title' => $t['subject'], 'url' => user_can( (int) $uid, 'ec_access_workspace' ) ? self::hub_url( 'messages', array( 'thread' => $thread_id ) ) : self::dash_url() ), "m{$message_id}:u{$uid}" );
		}
		if ( (int) $t['student_id'] && 'on' === Settings::get( 'guardian_visibility' ) && \EduCore\Core\Privacy::is_minor( (int) $t['student_id'] ) ) {
			foreach ( Tutoring::guardian_emails( (int) $t['student_id'] ) as $email ) {
				self::q( 'th_guardian_copy', $email, array( 'name' => '', 'title' => $t['subject'], 'url' => \EduCore\Core\Pages::url( 'guardian' ) ), "gm{$message_id}:" . md5( $email ) );
			}
		}
	}

	public static function concern( int $report_id ): void {
		foreach ( get_users( array( 'capability' => 'ec_review_reports', 'fields' => 'ID', 'number' => 20 ) ) as $uid ) {
			self::q( 'th_concern', (int) $uid, array( 'title' => '#' . $report_id, 'url' => admin_url( 'admin.php?page=educore-teaching&tab=safeguarding' ) ), "c{$report_id}:u{$uid}" );
		}
	}

	public static function tutor_reviewed( int $user_id, string $decision ): void {
		self::q( 'th_tutor_' . $decision, $user_id, array( 'url' => self::hub_url( 'profile' ) ), "tr{$user_id}:{$decision}:" . time() );
	}

	public static function class_joined( int $class_id, int $student_id ): void {
		$c = Classes::get( $class_id );
		if ( $c ) {
			self::q( 'th_class_joined', $student_id, array( 'course' => $c['name'], 'url' => self::dash_url() ), "cj{$class_id}:u{$student_id}" );
		}
	}

	/** EN / FR / AR templates (placeholders as in EduCore Notifications). */
	public static function templates( array $all ): array {
		$t = array(
			'th_assignment'       => array(
				'en' => array( 'subject' => 'New assignment: {title}', 'body' => array( 'Hello {name},', 'Your teacher set a new assignment, “{title}”. Deadline: {date}.' ), 'cta' => 'Open my assignments' ),
				'fr' => array( 'subject' => 'Nouveau devoir : {title}', 'body' => array( 'Bonjour {name},', 'Votre enseignant(e) a donné un nouveau devoir, « {title} ». Date limite : {date}.' ), 'cta' => 'Voir mes devoirs' ),
				'ar' => array( 'subject' => 'واجب جديد: {title}', 'body' => array( 'مرحبًا {name}،', 'أضاف مدرّسك واجبًا جديدًا بعنوان «{title}». آخر موعد للتسليم: {date}.' ), 'cta' => 'افتح واجباتي' ),
			),
			'th_submission'       => array(
				'en' => array( 'subject' => 'New submission: {title}', 'body' => array( 'Hello {name},', 'A student submitted work for “{title}”. It is waiting in your grading center.' ), 'cta' => 'Open grading center' ),
				'fr' => array( 'subject' => 'Nouvelle copie : {title}', 'body' => array( 'Bonjour {name},', 'Un(e) élève a rendu un travail pour « {title} ». Il vous attend dans le centre de correction.' ), 'cta' => 'Ouvrir le centre de correction' ),
				'ar' => array( 'subject' => 'تسليم جديد: {title}', 'body' => array( 'مرحبًا {name}،', 'سلّم أحد الطلاب عملًا في «{title}». إنه بانتظارك في مركز التصحيح.' ), 'cta' => 'افتح مركز التصحيح' ),
			),
			'th_returned'         => array(
				'en' => array( 'subject' => 'Please revise: {title}', 'body' => array( 'Hello {name},', 'Your teacher returned “{title}” with feedback and asks you to revise and resubmit it.' ), 'cta' => 'See the feedback' ),
				'fr' => array( 'subject' => 'À reprendre : {title}', 'body' => array( 'Bonjour {name},', 'Votre enseignant(e) vous a rendu « {title} » avec des commentaires et vous demande de le reprendre puis de le renvoyer.' ), 'cta' => 'Voir les commentaires' ),
				'ar' => array( 'subject' => 'يرجى المراجعة: {title}', 'body' => array( 'مرحبًا {name}،', 'أعاد مدرّسك «{title}» مع ملاحظات ويطلب منك مراجعته وإعادة تسليمه.' ), 'cta' => 'اطّلع على الملاحظات' ),
			),
			'th_session_request'  => array(
				'en' => array( 'subject' => 'Tutoring request: {date}', 'body' => array( 'Hello {name},', 'You have a new tutoring request ({title}) for {date}. Please confirm or decline it.' ), 'cta' => 'Review the request' ),
				'fr' => array( 'subject' => 'Demande de tutorat : {date}', 'body' => array( 'Bonjour {name},', 'Vous avez une nouvelle demande de tutorat ({title}) pour le {date}. Merci de l’accepter ou de la refuser.' ), 'cta' => 'Voir la demande' ),
				'ar' => array( 'subject' => 'طلب جلسة دعم: {date}', 'body' => array( 'مرحبًا {name}،', 'لديك طلب جلسة دعم جديد ({title}) بتاريخ {date}. يرجى قبوله أو رفضه.' ), 'cta' => 'راجع الطلب' ),
			),
			'th_session_confirmed'   => array(
				'en' => array( 'subject' => 'Tutoring session confirmed: {date}', 'body' => array( 'Hello {name},', 'Your tutoring session ({title}) on {date} is confirmed.' ), 'cta' => 'Open my sessions' ),
				'fr' => array( 'subject' => 'Séance de tutorat confirmée : {date}', 'body' => array( 'Bonjour {name},', 'Votre séance de tutorat ({title}) du {date} est confirmée.' ), 'cta' => 'Voir mes séances' ),
				'ar' => array( 'subject' => 'تم تأكيد جلسة الدعم: {date}', 'body' => array( 'مرحبًا {name}،', 'تم تأكيد جلسة الدعم ({title}) بتاريخ {date}.' ), 'cta' => 'افتح جلساتي' ),
			),
			'th_session_declined'    => array(
				'en' => array( 'subject' => 'Tutoring request declined', 'body' => array( 'Hello {name},', 'Your tutoring request ({title}) for {date} could not be accepted. You can choose another time.' ) ),
				'fr' => array( 'subject' => 'Demande de tutorat refusée', 'body' => array( 'Bonjour {name},', 'Votre demande de tutorat ({title}) pour le {date} n’a pas pu être acceptée. Vous pouvez choisir un autre créneau.' ) ),
				'ar' => array( 'subject' => 'تعذّر قبول طلب الدعم', 'body' => array( 'مرحبًا {name}،', 'تعذّر قبول طلب جلسة الدعم ({title}) بتاريخ {date}. يمكنك اختيار موعد آخر.' ) ),
			),
			'th_session_cancelled'   => array(
				'en' => array( 'subject' => 'Tutoring session cancelled: {date}', 'body' => array( 'Hello {name},', 'The tutoring session ({title}) on {date} was cancelled.' ) ),
				'fr' => array( 'subject' => 'Séance de tutorat annulée : {date}', 'body' => array( 'Bonjour {name},', 'La séance de tutorat ({title}) du {date} a été annulée.' ) ),
				'ar' => array( 'subject' => 'أُلغيت جلسة الدعم: {date}', 'body' => array( 'مرحبًا {name}،', 'أُلغيت جلسة الدعم ({title}) بتاريخ {date}.' ) ),
			),
			'th_session_rescheduled' => array(
				'en' => array( 'subject' => 'Tutoring session moved to {date}', 'body' => array( 'Hello {name},', 'Your tutoring session ({title}) now takes place on {date}.' ), 'cta' => 'Open my sessions' ),
				'fr' => array( 'subject' => 'Séance de tutorat déplacée au {date}', 'body' => array( 'Bonjour {name},', 'Votre séance de tutorat ({title}) a désormais lieu le {date}.' ), 'cta' => 'Voir mes séances' ),
				'ar' => array( 'subject' => 'تم نقل جلسة الدعم إلى {date}', 'body' => array( 'مرحبًا {name}،', 'أصبحت جلسة الدعم ({title}) بتاريخ {date}.' ), 'cta' => 'افتح جلساتي' ),
			),
			'th_guardian_session' => array(
				'en' => array( 'subject' => 'Please authorise a tutoring session for {title}', 'body' => array( 'Hello,', '{title} asked for a tutoring session on {date}. A tutor can confirm it only after you authorise it.' ), 'cta' => 'Review the request' ),
				'fr' => array( 'subject' => 'Autorisation d’une séance de tutorat pour {title}', 'body' => array( 'Bonjour,', '{title} a demandé une séance de tutorat le {date}. Le tuteur ne peut la confirmer qu’après votre autorisation.' ), 'cta' => 'Voir la demande' ),
				'ar' => array( 'subject' => 'يرجى الموافقة على جلسة دعم لـ {title}', 'body' => array( 'مرحبًا،', 'طلب {title} جلسة دعم بتاريخ {date}. لا يمكن للمدرّس تأكيدها إلا بعد موافقتك.' ), 'cta' => 'راجع الطلب' ),
			),
			'th_message'          => array(
				'en' => array( 'subject' => 'New message: {title}', 'body' => array( 'Hello {name},', 'There is a new message in “{title}” on EduCore. For safety, please reply on the platform.' ), 'cta' => 'Read the message' ),
				'fr' => array( 'subject' => 'Nouveau message : {title}', 'body' => array( 'Bonjour {name},', 'Un nouveau message est arrivé dans « {title} » sur EduCore. Par sécurité, merci de répondre sur la plateforme.' ), 'cta' => 'Lire le message' ),
				'ar' => array( 'subject' => 'رسالة جديدة: {title}', 'body' => array( 'مرحبًا {name}،', 'وصلت رسالة جديدة في «{title}» على EduCore. حفاظًا على الأمان، يرجى الرد عبر المنصة.' ), 'cta' => 'اقرأ الرسالة' ),
			),
			'th_guardian_copy'    => array(
				'en' => array( 'subject' => 'Message in your child’s conversation: {title}', 'body' => array( 'Hello,', 'A new message was posted in “{title}”, a conversation your child takes part in on EduCore. You can read it in your guardian area.' ), 'cta' => 'Open guardian area' ),
				'fr' => array( 'subject' => 'Message dans une conversation de votre enfant : {title}', 'body' => array( 'Bonjour,', 'Un nouveau message a été publié dans « {title} », une conversation à laquelle votre enfant participe sur EduCore. Vous pouvez le lire dans votre espace parent.' ), 'cta' => 'Ouvrir l’espace parent' ),
				'ar' => array( 'subject' => 'رسالة في محادثة لطفلك: {title}', 'body' => array( 'مرحبًا،', 'نُشرت رسالة جديدة في «{title}»، وهي محادثة يشارك فيها طفلك على EduCore. يمكنك قراءتها في مساحة وليّ الأمر.' ), 'cta' => 'افتح مساحة وليّ الأمر' ),
			),
			'th_concern'          => array(
				'en' => array( 'subject' => 'Safeguarding concern reported {title}', 'body' => array( 'Hello {name},', 'A concern about a conversation was reported on EduCore and needs review.' ), 'cta' => 'Review concerns' ),
				'fr' => array( 'subject' => 'Signalement de protection {title}', 'body' => array( 'Bonjour {name},', 'Une conversation a fait l’objet d’un signalement sur EduCore et doit être examinée.' ), 'cta' => 'Examiner les signalements' ),
				'ar' => array( 'subject' => 'بلاغ حماية {title}', 'body' => array( 'مرحبًا {name}،', 'تم الإبلاغ عن محادثة على EduCore وتحتاج إلى مراجعة.' ), 'cta' => 'مراجعة البلاغات' ),
			),
			'th_tutor_approved'   => array(
				'en' => array( 'subject' => 'Your tutor profile is approved', 'body' => array( 'Hello {name},', 'Your EduCore tutor profile was approved. Students can now request sessions in your available times.' ), 'cta' => 'Open the Teaching Hub' ),
				'fr' => array( 'subject' => 'Votre profil de tuteur est approuvé', 'body' => array( 'Bonjour {name},', 'Votre profil de tuteur EduCore a été approuvé. Les élèves peuvent maintenant demander des séances sur vos créneaux.' ), 'cta' => 'Ouvrir l’espace enseignant' ),
				'ar' => array( 'subject' => 'تمت الموافقة على ملفك كمدرّس دعم', 'body' => array( 'مرحبًا {name}،', 'تمت الموافقة على ملفك كمدرّس دعم في EduCore. يمكن للطلاب الآن طلب جلسات في أوقاتك المتاحة.' ), 'cta' => 'افتح مركز التدريس' ),
			),
			'th_tutor_rejected'   => array(
				'en' => array( 'subject' => 'Your tutor profile needs changes', 'body' => array( 'Hello {name},', 'Your tutor profile was not approved yet. Please review the comments in the Teaching Hub and resubmit.' ), 'cta' => 'Open my profile' ),
				'fr' => array( 'subject' => 'Votre profil de tuteur doit être modifié', 'body' => array( 'Bonjour {name},', 'Votre profil de tuteur n’a pas encore été approuvé. Consultez les remarques dans l’espace enseignant puis soumettez-le à nouveau.' ), 'cta' => 'Ouvrir mon profil' ),
				'ar' => array( 'subject' => 'ملفك كمدرّس دعم يحتاج إلى تعديلات', 'body' => array( 'مرحبًا {name}،', 'لم تتم الموافقة على ملفك بعد. يرجى مراجعة الملاحظات في مركز التدريس ثم إعادة الإرسال.' ), 'cta' => 'افتح ملفي' ),
			),
			'th_tutor_suspended'  => array(
				'en' => array( 'subject' => 'Your tutor profile is suspended', 'body' => array( 'Hello {name},', 'Your tutor profile is suspended and hidden from students. Please contact the EduCore team.' ) ),
				'fr' => array( 'subject' => 'Votre profil de tuteur est suspendu', 'body' => array( 'Bonjour {name},', 'Votre profil de tuteur est suspendu et n’est plus visible des élèves. Merci de contacter l’équipe EduCore.' ) ),
				'ar' => array( 'subject' => 'تم تعليق ملفك كمدرّس دعم', 'body' => array( 'مرحبًا {name}،', 'تم تعليق ملفك ولم يعد ظاهرًا للطلاب. يرجى التواصل مع فريق EduCore.' ) ),
			),
			'th_class_joined'     => array(
				'en' => array( 'subject' => 'You joined the class {course}', 'body' => array( 'Hello {name},', 'You were added to the class “{course}”. Your assignments and announcements will appear on your dashboard.' ), 'cta' => 'Open my learning' ),
				'fr' => array( 'subject' => 'Vous avez rejoint la classe {course}', 'body' => array( 'Bonjour {name},', 'Vous avez été ajouté(e) à la classe « {course} ». Vos devoirs et annonces apparaîtront sur votre tableau de bord.' ), 'cta' => 'Ouvrir mon espace' ),
				'ar' => array( 'subject' => 'انضممت إلى الفصل {course}', 'body' => array( 'مرحبًا {name}،', 'تمت إضافتك إلى الفصل «{course}». ستظهر واجباتك والإعلانات في لوحتك.' ), 'cta' => 'افتح مساحتي' ),
			),
		);
		return array_merge( $all, $t );
	}
}
