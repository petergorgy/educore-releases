<?php
namespace EduCore\Experience;

use EduCore\Core\Audit;
use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/**
 * Per-account experience preferences (user meta `educore_xp_prefs`, one JSON array).
 * Signed-in preferences live only on the server: nothing personal is kept in shared browser storage.
 */
final class Prefs {
	public const META = 'educore_xp_prefs';

	public const MODES      = array( 'auto', 'solar', 'system', 'light', 'dark', 'midnight', 'dawn', 'morning', 'noon', 'afternoon', 'dusk', 'evening', 'night' );
	public const FONT       = array( 90, 100, 110, 125, 150 );
	public const DAYS       = array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' );
	public const SLOTS      = array( '', 'morning', 'afternoon', 'evening' );
	/** Dashboard widgets a learner may hide (core sections are hidden through the dashboard data filter). */
	public const WIDGETS    = array( 'welcome', 'suggestions', 'goals', 'upcoming', 'pending', 'results', 'announcements', 'certificates', 'achievements' );
	public const ORDERABLE  = array( 'welcome', 'suggestions', 'goals' );

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	public static function defaults(): array {
		return array(
			'preferred_name'   => '',
			'pronunciation'    => '',
			'greet_by_name'    => true,
			'timezone'         => '',
			'appearance'       => Settings::get( 'default_mode' ),
			'solar_city'       => '',
			'solar_lat'        => null,
			'solar_lng'        => null,
			'font_scale'       => 100,
			'contrast'         => 'standard',
			'motion'           => 'system',
			'density'          => 'comfortable',
			'reading'          => 'standard',
			'hidden_widgets'   => array(),
			'widget_order'     => self::ORDERABLE,
			'interests'        => array(),
			'study_days'       => array(),
			'study_slot'       => '',
			'practice_goal'    => 0,
			'goals_paused'     => false,
			'onboarded_at'     => '',
		);
	}

	public static function get( int $uid ): array {
		$raw = $uid ? get_user_meta( $uid, self::META, true ) : array();
		$p   = array_merge( self::defaults(), is_array( $raw ) ? $raw : array() );
		$p['lessons_goal'] = $uid ? max( 1, (int) ( get_user_meta( $uid, 'educore_weekly_goal', true ) ?: 3 ) ) : 3;
		return $p;
	}

	/**
	 * Validate and merge a partial update. Unknown keys are ignored; invalid values are rejected with a reason.
	 *
	 * @return array|\WP_Error the saved preferences
	 */
	public static function update( int $uid, array $in ) {
		$p   = self::get( $uid );
		$err = new \WP_Error();
		foreach ( $in as $k => $v ) {
			switch ( $k ) {
				case 'preferred_name':
				case 'pronunciation':
					$v = trim( sanitize_text_field( (string) $v ) );
					if ( mb_strlen( $v ) > ( 'preferred_name' === $k ? 60 : 80 ) ) {
						$err->add( 'educore_xp_too_long', __( 'That text is too long.', 'educore-experience' ) );
						break;
					}
					$p[ $k ] = $v;
					break;
				case 'greet_by_name':
				case 'goals_paused':
					$p[ $k ] = (bool) rest_sanitize_boolean( $v );
					break;
				case 'timezone':
					$v = (string) $v;
					if ( '' !== $v && ! Clock::valid_tz( $v ) ) {
						$err->add( 'educore_xp_tz', __( 'Please choose a time zone from the list.', 'educore-experience' ) );
						break;
					}
					$p['timezone'] = $v;
					break;
				case 'appearance':
					if ( ! in_array( $v, self::MODES, true ) ) {
						$err->add( 'educore_xp_mode', __( 'Unknown appearance.', 'educore-experience' ) );
						break;
					}
					$p['appearance'] = $v;
					break;
				case 'solar_city':
					$v = sanitize_key( (string) $v );
					if ( '' !== $v && ! Cities::get( $v ) ) {
						$err->add( 'educore_xp_city', __( 'Please choose a city from the list.', 'educore-experience' ) );
						break;
					}
					$p['solar_city'] = $v;
					if ( '' !== $v ) {
						$p['solar_lat'] = null;
						$p['solar_lng'] = null;
					}
					break;
				case 'solar_coords':
					// Only sent after the person pressed "Use my device location" and the browser asked them. Stored rounded (≈1 km).
					if ( null === $v || '' === $v ) {
						$p['solar_lat'] = null;
						$p['solar_lng'] = null;
						break;
					}
					$lat = isset( $v['lat'] ) ? (float) $v['lat'] : 999;
					$lng = isset( $v['lng'] ) ? (float) $v['lng'] : 999;
					if ( $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 ) {
						$err->add( 'educore_xp_coords', __( 'That location is not valid.', 'educore-experience' ) );
						break;
					}
					$p['solar_lat']  = round( $lat, 2 );
					$p['solar_lng']  = round( $lng, 2 );
					$p['solar_city'] = '';
					break;
				case 'font_scale':
					if ( ! in_array( (int) $v, self::FONT, true ) ) {
						$err->add( 'educore_xp_font', __( 'Unknown text size.', 'educore-experience' ) );
						break;
					}
					$p['font_scale'] = (int) $v;
					break;
				case 'contrast':
					$p['contrast'] = 'high' === $v ? 'high' : 'standard';
					break;
				case 'motion':
					$p['motion'] = 'reduce' === $v ? 'reduce' : 'system';
					break;
				case 'density':
					$p['density'] = 'compact' === $v ? 'compact' : 'comfortable';
					break;
				case 'reading':
					$p['reading'] = 'spacious' === $v ? 'spacious' : 'standard';
					break;
				case 'hidden_widgets':
					$p['hidden_widgets'] = array_values( array_intersect( self::WIDGETS, array_map( 'strval', (array) $v ) ) );
					break;
				case 'widget_order':
					$order = array_values( array_unique( array_intersect( array_map( 'strval', (array) $v ), self::ORDERABLE ) ) );
					$p['widget_order'] = array_merge( $order, array_values( array_diff( self::ORDERABLE, $order ) ) );
					break;
				case 'interests':
					$valid           = array_map( static fn( $s ) => (int) $s['id'], self::subjects() );
					$p['interests'] = array_values( array_intersect( $valid, array_map( 'intval', (array) $v ) ) );
					break;
				case 'study_days':
					$p['study_days'] = array_values( array_intersect( self::DAYS, array_map( 'strval', (array) $v ) ) );
					break;
				case 'study_slot':
					$p['study_slot'] = in_array( $v, self::SLOTS, true ) ? $v : '';
					break;
				case 'lessons_goal':
					update_user_meta( $uid, 'educore_weekly_goal', max( 1, min( 50, absint( $v ) ) ) );
					break;
				case 'practice_goal':
					$p['practice_goal'] = max( 0, min( 200, (int) $v ) );
					break;
				case 'onboarded':
					$p['onboarded_at'] = $v ? gmdate( 'Y-m-d H:i:s' ) : '';
					break;
			}
		}
		if ( $err->has_errors() ) {
			$err->add_data( array( 'status' => 400 ) );
			return $err;
		}
		unset( $p['lessons_goal'] );
		update_user_meta( $uid, self::META, $p );
		return self::get( $uid );
	}

	/** @return array<int,array{id:int,name:string}> */
	public static function subjects(): array {
		if ( ! class_exists( '\EduCore\Core\Curriculum' ) || ! method_exists( '\EduCore\Core\Curriculum', 'subjects' ) ) {
			return array();
		}
		return array_map( static fn( $s ) => array( 'id' => (int) $s['id'], 'name' => (string) $s['name'] ), (array) \EduCore\Core\Curriculum::subjects() );
	}

	/** What the browser may know: no e-mail, no ids beyond the account's own choices. */
	public static function public_view( int $uid ): array {
		$p = self::get( $uid );
		unset( $p['onboarded_at'] );
		return $p;
	}

	public static function routes(): void {
		$auth = static fn() => is_user_logged_in();
		register_rest_route(
			'educore/v1',
			'/me/preferences',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => $auth,
					'callback'            => static fn() => rest_ensure_response( array( 'preferences' => self::public_view( get_current_user_id() ), 'appearance' => Appearance::config( get_current_user_id() ) ) ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => $auth,
					'callback'            => array( self::class, 'rest_update' ),
				),
			)
		);
		register_rest_route(
			'educore/v1',
			'/me/resume',
			array(
				'methods'             => 'POST',
				'permission_callback' => $auth,
				'callback'            => array( Resume::class, 'rest_save' ),
				'args'                => array(
					'lesson'   => array( 'type' => 'integer', 'required' => true ),
					'position' => array( 'type' => 'number', 'required' => true ),
				),
			)
		);
	}

	public static function rest_update( \WP_REST_Request $r ) {
		$uid = get_current_user_id();
		if ( ! RateLimiter::hit( 'xp_prefs', (string) $uid ) ) {
			return new \WP_Error( 'educore_rate_limited', __( 'Too many changes in a short time. Please wait a moment.', 'educore-experience' ), array( 'status' => 429 ) );
		}
		$body = (array) $r->get_json_params();
		$res  = self::update( $uid, $body );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		Audit::log( 'experience.preferences_saved', 'user', $uid, array( 'keys' => array_slice( array_keys( $body ), 0, 20 ) ) );
		return rest_ensure_response( array( 'preferences' => self::public_view( $uid ), 'appearance' => Appearance::config( $uid ) ) );
	}
}
