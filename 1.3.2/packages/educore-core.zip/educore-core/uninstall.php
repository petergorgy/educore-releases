<?php
/**
 * EduCore Core uninstall. Academic records are KEPT unless the administrator explicitly
 * opted in (two confirmations in Settings → Uninstall behaviour).
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( 'yes' !== get_option( 'educore_uninstall_delete_data' ) ) {
	return;
}

global $wpdb;
$tables = array( 'programmes', 'academic_periods', 'subjects', 'curriculum_map', 'translation_groups', 'course_staff', 'enrollments', 'lesson_progress', 'notes', 'consents', 'guardian_links', 'audit_events', 'rate_limits', 'search_index', 'activity' );
foreach ( $tables as $t ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'ec_' . $t ); // phpcs:ignore WordPress.DB.PreparedSQL
}
foreach ( array( 'ec_course', 'ec_unit', 'ec_lesson', 'ec_announcement' ) as $type ) {
	$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s", $type ) );
	foreach ( $ids as $id ) {
		wp_delete_post( (int) $id, true );
	}
}
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'educore\_%'" );
$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'educore\_%'" );
foreach ( array( 'ec_academic_manager', 'ec_instructor', 'ec_grader', 'ec_student', 'ec_guardian' ) as $role ) {
	remove_role( $role );
}
