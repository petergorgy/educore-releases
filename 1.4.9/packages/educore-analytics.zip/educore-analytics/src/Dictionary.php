<?php
namespace EduCore\Analytics;

defined( 'ABSPATH' ) || exit;

/**
 * Metric dictionary — the single source of truth for definitions shown in dashboards and docs.
 * privacy: own = learner sees own value; course = course staff; global = academic managers/admins.
 */
final class Dictionary {

	/** @return array<string,array{name:string,level:string,definition:string,formula:string,sources:string,filters:string,privacy:string,requires:string}> */
	public static function all(): array {
		$lp = 'ec_lesson_progress';
		$en = 'ec_enrollments';
		$at = 'ec_attempts, ec_assessments';
		$it = 'ec_attempt_items, ec_responses, ec_question_versions, ec_questions';
		return array(
			'S1' => array( 'name' => 'Course completion %', 'level' => 'student', 'definition' => 'Share of a course\'s published lessons (in published units) the learner has completed.', 'formula' => 'completed published lessons ÷ published lessons × 100, 1 dp', 'sources' => "$lp, posts", 'filters' => 'course', 'privacy' => 'own, course', 'requires' => 'core' ),
			'S2' => array( 'name' => 'Lesson progress', 'level' => 'student', 'definition' => 'Per enrolled course: published lessons, lessons opened (started), lessons completed.', 'formula' => 'counts of ec_lesson_progress rows for published lesson ids', 'sources' => "$lp, $en", 'filters' => 'course', 'privacy' => 'own, course', 'requires' => 'core' ),
			'S3' => array( 'name' => 'Assessment mean %', 'level' => 'student', 'definition' => 'Mean percentage over scored attempts (state graded|released, max_score > 0) submitted in the date range.', 'formula' => 'AVG(score ÷ max_score × 100), 1 dp', 'sources' => $at, 'filters' => 'date, course', 'privacy' => 'own, course', 'requires' => 'assessments' ),
			'S4' => array( 'name' => 'Score improvement', 'level' => 'student', 'definition' => 'For each assessment with ≥ 2 scored attempts in range: last % − first % (by submission time); averaged across those assessments.', 'formula' => 'mean(last − first), percentage points, 1 dp', 'sources' => $at, 'filters' => 'date, course', 'privacy' => 'own, course', 'requires' => 'assessments' ),
			'S5' => array( 'name' => 'Topic strengths / weaknesses', 'level' => 'student', 'definition' => 'Mean item score % grouped by the lesson each question is mapped to. Strength ≥ 75, weakness < 50.', 'formula' => 'AVG(COALESCE(final_score, auto_score) ÷ points × 100) per lesson', 'sources' => "$at, $it", 'filters' => 'date, course', 'privacy' => 'own, course', 'requires' => 'assessments' ),
			'S6' => array( 'name' => 'Attempts per assessment', 'level' => 'student', 'definition' => 'Number of non-open attempts per assessment submitted in range.', 'formula' => 'COUNT(attempts) GROUP BY assessment', 'sources' => $at, 'filters' => 'date, course', 'privacy' => 'own, course', 'requires' => 'assessments' ),
			'S7' => array( 'name' => 'Learning consistency', 'level' => 'student', 'definition' => 'Distinct UTC days with learning activity in the 28 days ending today. Activity = a first_seen, last_seen or completed timestamp in ec_lesson_progress.', 'formula' => 'COUNT(DISTINCT day) and ÷ 28 × 100', 'sources' => $lp, 'filters' => 'course', 'privacy' => 'own, course', 'requires' => 'core' ),
			'S8' => array( 'name' => 'Pending activities', 'level' => 'student', 'definition' => 'In currently accessible enrollments: published lessons not completed, and assessments never attempted.', 'formula' => 'counts', 'sources' => "$lp, $en, $at", 'filters' => 'course', 'privacy' => 'own, course', 'requires' => 'core (+assessments for assessment count)' ),
			'I1' => array( 'name' => 'Engagement (7 / 30 days)', 'level' => 'course', 'definition' => 'Enrolled learners (active|completed) with activity in the last 7 / 30 days ÷ enrolled learners.', 'formula' => 'active ÷ enrolled × 100', 'sources' => "$lp, $en", 'filters' => 'course, cohort', 'privacy' => 'course', 'requires' => 'core' ),
			'I2' => array( 'name' => 'Lesson completion rate', 'level' => 'course', 'definition' => 'Per published lesson: enrolled learners who completed it ÷ enrolled learners.', 'formula' => 'completed ÷ enrolled × 100', 'sources' => "$lp, $en", 'filters' => 'course, cohort', 'privacy' => 'course', 'requires' => 'core' ),
			'I3' => array( 'name' => 'Score distribution', 'level' => 'course', 'definition' => 'Scored attempts in range bucketed by percentage: [0,10), [10,20) … [90,100].', 'formula' => 'bucket = min(9, floor(% ÷ 10))', 'sources' => $at, 'filters' => 'date, course, cohort', 'privacy' => 'course', 'requires' => 'assessments' ),
			'I4' => array( 'name' => 'Difficult questions', 'level' => 'course', 'definition' => 'Questions with ≥ 5 scored responses in range whose correct rate (p-value) is below 0.40. Correct = item score ≥ item points.', 'formula' => 'p = correct ÷ responses', 'sources' => "$at, $it", 'filters' => 'date, course, cohort', 'privacy' => 'course', 'requires' => 'assessments' ),
			'I5' => array( 'name' => 'Course improvement', 'level' => 'course', 'definition' => 'Mean of S4 across enrolled learners for whom S4 is computable.', 'formula' => 'mean(S4)', 'sources' => $at, 'filters' => 'date, course, cohort', 'privacy' => 'course', 'requires' => 'assessments' ),
			'I6' => array( 'name' => 'Grading backlog', 'level' => 'course', 'definition' => 'Attempts in state submitted (awaiting manual grading) and the age of the oldest in hours.', 'formula' => 'COUNT, now − MIN(submitted_at)', 'sources' => $at, 'filters' => 'course', 'privacy' => 'course', 'requires' => 'assessments' ),
			'I7' => array( 'name' => 'At-risk learners', 'level' => 'course', 'definition' => 'Active enrollments meeting any rule: no course activity in 14 days; or enrolled ≥ 30 days with S1 < 25 %; or S3 (all time) < 50 %.', 'formula' => 'rule evaluation per learner', 'sources' => "$lp, $en, $at", 'filters' => 'course, cohort', 'privacy' => 'course (names shown only with ec_view_student)', 'requires' => 'core (+assessments for score rule)' ),
			'A1' => array( 'name' => 'Active enrollments', 'level' => 'global', 'definition' => 'Enrollments in status active whose expiry is empty or in the future.', 'formula' => 'COUNT', 'sources' => $en, 'filters' => 'course, cohort', 'privacy' => 'global, course', 'requires' => 'core' ),
			'A2' => array( 'name' => 'Course participation', 'level' => 'global', 'definition' => 'Per course: enrolled learners, learners with activity in range, participation % and course completions in range.', 'formula' => 'active ÷ enrolled × 100', 'sources' => "$lp, $en", 'filters' => 'date, course, cohort', 'privacy' => 'global, course', 'requires' => 'core' ),
			'A3' => array( 'name' => 'Completion trend', 'level' => 'global', 'definition' => 'Course completions (enrollment completed_at) per calendar month in range.', 'formula' => 'COUNT GROUP BY YYYY-MM', 'sources' => $en, 'filters' => 'date, course, cohort', 'privacy' => 'global, course', 'requires' => 'core' ),
			'A4' => array( 'name' => 'Cohort comparison', 'level' => 'global', 'definition' => 'Learners grouped by profile programme or academic year: learner count and mean S1 over their active|completed enrollments.', 'formula' => 'mean(S1)', 'sources' => "$en, usermeta", 'filters' => 'course', 'privacy' => 'global', 'requires' => 'core' ),
			'A5' => array( 'name' => 'Assessment quality', 'level' => 'global', 'definition' => 'Questions with ≥ 5 scored responses and p < 0.20 (too hard) or p > 0.95 (too easy).', 'formula' => 'p-value thresholds', 'sources' => "$at, $it", 'filters' => 'date, course, cohort', 'privacy' => 'global, course', 'requires' => 'assessments' ),
			'A6' => array( 'name' => 'Content utilisation', 'level' => 'global', 'definition' => 'Published lessons that no learner has ever opened.', 'formula' => 'lessons with 0 progress rows', 'sources' => "$lp, posts", 'filters' => 'course', 'privacy' => 'global, course', 'requires' => 'core' ),
			'A7' => array( 'name' => 'Platform engagement (DAU / WAU)', 'level' => 'global', 'definition' => 'Distinct learners with activity on a day (DAU) / in the 7 days ending that day (WAU). Source: ec_activity (one row per learner, course and UTC day; written on every lesson view, heartbeat, completion and assessment submission since 1.0.1) UNION the lesson_progress timestamps (first/last/completed) for history recorded before 1.0.1.', 'formula' => 'COUNT(DISTINCT user)', 'sources' => "$lp, ec_analytics_daily (cache)", 'filters' => 'date, course, cohort', 'privacy' => 'global', 'requires' => 'core' ),
		);
	}

	public static function get( string $id ): array {
		return self::all()[ $id ] ?? array();
	}

	/** Markdown rendering (used to generate docs/metric-dictionary.md). */
	public static function markdown(): string {
		$md = "# EduCore Analytics — Metric dictionary\n\nGenerated from `EduCore\\Analytics\\Dictionary`. All timestamps are UTC; date ranges are inclusive calendar days.\n\n| ID | Metric | Level | Definition | Formula | Sources | Filters | Visible to | Requires |\n|---|---|---|---|---|---|---|---|---|\n";
		foreach ( self::all() as $id => $m ) {
			$md .= sprintf( "| %s | %s | %s | %s | %s | %s | %s | %s | %s |\n", $id, $m['name'], $m['level'], $m['definition'], $m['formula'], $m['sources'], $m['filters'], $m['privacy'], $m['requires'] );
		}
		return $md;
	}
}
