<?php
namespace EduCore\Notifications;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Per-user, per-event e-mail opt-outs. Essential events cannot be disabled. */
final class Prefs {

	public static function register(): void {
		add_filter( 'educore/profile/form_fields', array( self::class, 'fields' ), 10, 2 );
		add_filter( 'educore/profile/form_input', array( self::class, 'input' ), 10, 2 );
		add_filter( 'educore/profile/update', array( self::class, 'save_from_profile' ), 10, 3 );
		add_filter( 'educore/profile/get', array( self::class, 'profile_get' ), 10, 2 );
	}

	public static function allows( int $user_id, string $event ): bool {
		global $wpdb;
		if ( in_array( $event, Templates::ESSENTIAL, true ) ) {
			return true;
		}
		$v = $wpdb->get_var( $wpdb->prepare( 'SELECT enabled FROM ' . Schema::table( 'notification_prefs' ) . " WHERE user_id=%d AND event=%s AND channel='email'", $user_id, $event ) );
		return null === $v || '1' === (string) $v;
	}

	public static function set( int $user_id, string $event, bool $enabled ): void {
		global $wpdb;
		if ( in_array( $event, Templates::ESSENTIAL, true ) || ! in_array( $event, Templates::events(), true ) ) {
			return;
		}
		$wpdb->query( $wpdb->prepare( 'INSERT INTO ' . Schema::table( 'notification_prefs' ) . " (user_id,event,channel,enabled) VALUES (%d,%s,'email',%d) ON DUPLICATE KEY UPDATE enabled=VALUES(enabled)", $user_id, $event, $enabled ? 1 : 0 ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function fields( string $html, int $user_id ): string {
		$html .= '<fieldset class="ec-field"><legend>' . esc_html__( 'E-mail notifications', 'educore-notifications' ) . '</legend><input type="hidden" name="ec_notify_present" value="1">';
		foreach ( Templates::labels() as $event => $label ) {
			if ( 'grading_needed' === $event && ! user_can( $user_id, 'ec_grade_submissions' ) ) {
				continue;
			}
			$html .= '<label class="ec-check"><input type="checkbox" name="ec_notify[]" value="' . esc_attr( $event ) . '"' . checked( self::allows( $user_id, $event ), true, false ) . '> ' . esc_html( $label ) . '</label>';
		}
		$html .= '<small class="ec-muted">' . esc_html__( 'Security and account messages are always sent.', 'educore-notifications' ) . '</small></fieldset>';
		return $html;
	}

	public static function input( array $in, array $post ): array {
		if ( ! empty( $post['ec_notify_present'] ) ) {
			$in['notify'] = array_map( 'sanitize_key', (array) wp_unslash( $post['ec_notify'] ?? array() ) );
		}
		return $in;
	}

	/** @param true|\WP_Error $res */
	public static function save_from_profile( $res, int $user_id, array $in ) {
		if ( true === $res && isset( $in['notify'] ) && is_array( $in['notify'] ) ) {
			foreach ( array_keys( Templates::labels() ) as $event ) {
				self::set( $user_id, $event, in_array( $event, $in['notify'], true ) );
			}
		}
		return $res;
	}

	public static function profile_get( array $p, int $user_id ): array {
		$p['notifications'] = array();
		foreach ( array_keys( Templates::labels() ) as $event ) {
			$p['notifications'][ $event ] = self::allows( $user_id, $event );
		}
		return $p;
	}
}
