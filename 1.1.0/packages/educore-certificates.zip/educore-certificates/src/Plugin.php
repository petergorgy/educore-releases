<?php
namespace EduCore\Certificates;

use EduCore\Core\Registry;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	public const TEMPLATE = 'ec_cert_template';

	public static function tables(): array {
		return array(
			'certificates' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				uid CHAR(32) NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				course_id BIGINT UNSIGNED NOT NULL,
				template_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				student_name VARCHAR(191) NOT NULL DEFAULT '',
				course_title VARCHAR(255) NOT NULL DEFAULT '',
				issued_at DATETIME NOT NULL,
				issued_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				revoked_at DATETIME NULL,
				revoke_reason VARCHAR(255) NOT NULL DEFAULT '',
				pdf_path VARCHAR(255) NOT NULL DEFAULT '',
				sha256 CHAR(64) NOT NULL DEFAULT '',
				PRIMARY KEY  (id),
				UNIQUE KEY uid (uid),
				UNIQUE KEY user_course_template (user_id,course_id,template_id),
				KEY course_id (course_id)",
		);
	}

	public static function migrate(): void {
		Schema::migrate( 'educore_certificates_db_version', EDUCORE_CERTIFICATES_DB_VERSION, self::tables() );
	}

	public static function install(): void {
		self::migrate();
		self::register_type();
		Templates::ensure_defaults();
		Storage::ensure_dir();
		Verify::ensure_page();
	}

	public static function boot(): void {
		Registry::register( 'certificates', EDUCORE_CERTIFICATES_VERSION );
		self::migrate();
		add_action(
			'educore/install/repair',
			static function () {
				self::migrate();
				Templates::ensure_defaults();
				Storage::ensure_dir();
				Verify::ensure_page();
			}
		);
		add_action( 'init', array( self::class, 'register_type' ) );
		add_action( 'init', static fn() => load_plugin_textdomain( 'educore-certificates', false, dirname( plugin_basename( EDUCORE_CERTIFICATES_FILE ) ) . '/languages' ) );
		add_action( 'educore/events/course_completed', array( Certificates::class, 'on_course_completed' ), 20, 2 );
		add_filter( 'educore/notifications/certificate_url', static fn( $url, $id ) => ( $c = Certificates::get( (int) $id ) ) ? Verify::url( $c['uid'] ) : $url, 10, 2 );
		add_filter( 'educore/dashboard/student', array( Certificates::class, 'dashboard' ), 10, 2 );
		add_filter( 'educore/dashboard/history', array( Certificates::class, 'history' ), 10, 2 );
		add_filter( 'educore/privacy/export', array( Certificates::class, 'export' ), 10, 2 );
		add_action( 'template_redirect', array( Download::class, 'handle' ) );
		add_action( 'educore/rest/routes', array( Rest::class, 'routes' ) );
		add_filter( 'educore/blocks', array( Verify::class, 'block' ) );
		if ( is_admin() ) {
			Admin::register();
		}
	}

	public static function register_type(): void {
		register_post_type(
			self::TEMPLATE,
			array(
				'label'        => __( 'Certificate templates', 'educore-certificates' ),
				'labels'       => array( 'name' => __( 'Certificate templates', 'educore-certificates' ), 'singular_name' => __( 'Certificate template', 'educore-certificates' ), 'add_new_item' => __( 'Add certificate template', 'educore-certificates' ) ),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => 'educore',
				'show_in_rest' => false,
				'supports'     => array( 'title' ),
				'capabilities' => array(
					'edit_post'          => 'ec_manage_certificates',
					'read_post'          => 'ec_manage_certificates',
					'delete_post'        => 'ec_manage_certificates',
					'edit_posts'         => 'ec_manage_certificates',
					'edit_others_posts'  => 'ec_manage_certificates',
					'publish_posts'      => 'ec_manage_certificates',
					'read_private_posts' => 'ec_manage_certificates',
					'delete_posts'       => 'ec_manage_certificates',
					'create_posts'       => 'ec_manage_certificates',
				),
				'map_meta_cap' => false,
			)
		);
	}
}
