<?php
namespace EduCore\Experience;

defined( 'ABSPATH' ) || exit;

/** Experience data in personal-data exports and erasure requests. */
final class Privacy {
	public const KEYS = array( Prefs::META, Resume::LAST, Resume::POSITIONS );

	public static function register(): void {
		add_filter( 'educore/privacy/export', array( self::class, 'export' ), 10, 2 );
		add_filter( 'wp_privacy_personal_data_erasers', array( self::class, 'erasers' ) );
		add_action( 'deleted_user', array( self::class, 'erase_user' ) );
	}

	public static function data( int $uid ): array {
		$p = Prefs::get( $uid );
		return array(
			'preferences'      => $p,
			'last_lesson'      => Resume::last( $uid ),
			'reading_position' => get_user_meta( $uid, Resume::POSITIONS, true ) ?: array(),
		);
	}

	/** Appends one WordPress-exporter item to EduCore's personal-data export. */
	public static function export( $data, $user ) {
		$data = (array) $data;
		$uid  = $user instanceof \WP_User ? $user->ID : (int) $user;
		if ( ! $uid ) {
			return $data;
		}
		$rows = array();
		foreach ( self::data( $uid ) as $group => $values ) {
			foreach ( (array) $values as $k => $v ) {
				$rows[] = array( 'name' => $group . ': ' . $k, 'value' => is_scalar( $v ) || null === $v ? (string) $v : (string) wp_json_encode( $v ) );
			}
		}
		$data[] = array( 'group_id' => 'educore-experience', 'group_label' => __( 'EduCore experience', 'educore-experience' ), 'item_id' => 'xp-' . $uid, 'data' => $rows );
		return $data;
	}

	public static function erasers( array $e ): array {
		$e['educore-experience'] = array(
			'eraser_friendly_name' => __( 'EduCore experience preferences', 'educore-experience' ),
			'callback'             => static function ( $email ) {
				$u = get_user_by( 'email', $email );
				if ( $u ) {
					self::erase_user( $u->ID );
				}
				return array( 'items_removed' => (bool) $u, 'items_retained' => false, 'messages' => array(), 'done' => true );
			},
		);
		return $e;
	}

	public static function erase_user( $uid ): void {
		foreach ( self::KEYS as $k ) {
			delete_user_meta( (int) $uid, $k );
		}
	}
}
