<?php
namespace EduCore\Assessments\Exchange;

use EduCore\Assessments\Admin as AssessAdmin;
use EduCore\Assessments\Questions;
use EduCore\Assessments\Types;
use EduCore\Core\Content;
use EduCore\Core\I18n;

defined( 'ABSPATH' ) || exit;

/** wp-admin → EduCore → Question Import & Export: wizard, export, jobs, templates and format guide. */
final class Center {
	public const SLUG = 'educore-question-exchange';
	public const CAP  = 'ec_manage_question_bank';

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 25 );
		add_action( 'admin_init', array( self::class, 'handle' ) );
		add_action( 'admin_post_educore_qx_download', array( self::class, 'download' ) );
	}

	public static function menu(): void {
		add_submenu_page( 'educore', __( 'Question Import & Export', 'educore-assessments' ), __( 'Question Import & Export', 'educore-assessments' ), self::CAP, self::SLUG, array( self::class, 'page' ) );
	}

	private static function url( array $a = array() ): string {
		return add_query_arg( $a, admin_url( 'admin.php?page=' . self::SLUG ) );
	}

	private static function back( array $a ): void {
		wp_safe_redirect( self::url( $a ) );
		exit;
	}

	private static function nonce_field( string $action ): string {
		return wp_nonce_field( 'ec_qx_' . $action, '_ecqx', true, false ) . '<input type="hidden" name="ec_qx" value="' . esc_attr( $action ) . '">';
	}

	private static function job_for_user( int $id ): ?array {
		$job = Jobs::get( $id );
		return ( $job && Jobs::can_import( (int) $job['course_id'] ) ) ? $job : null;
	}

	public static function handle(): void {
		if ( empty( $_POST['ec_qx'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['ec_qx'] ) );
		check_admin_referer( 'ec_qx_' . $action, '_ecqx' );
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to manage question banks.', 'educore-assessments' ), 403 );
		}
		$job_id = isset( $_POST['job'] ) ? absint( $_POST['job'] ) : 0;
		switch ( $action ) {
			case 'upload':
				$course = isset( $_POST['course'] ) ? absint( $_POST['course'] ) : 0;
				$file   = $_FILES['file'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validated below.
				if ( ! $file || ! empty( $file['error'] ) || ! is_uploaded_file( (string) $file['tmp_name'] ) ) {
					self::back( array( 'err' => __( 'No file was uploaded (or it exceeds the server upload limit).', 'educore-assessments' ) ) );
				}
				$r = Jobs::create(
					$course,
					(string) $file['tmp_name'],
					sanitize_file_name( (string) $file['name'] ),
					isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'auto',
					array(
						'mode'   => isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'skip',
						'status' => isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '',
						'lang'   => isset( $_POST['lang'] ) ? sanitize_key( wp_unslash( $_POST['lang'] ) ) : '',
					)
				);
				self::back( is_wp_error( $r ) ? array( 'err' => $r->get_error_message() ) : array( 'job' => $r ) );
				break;
			case 'mode':
				if ( self::job_for_user( $job_id ) ) {
					Jobs::set_mode( $job_id, isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'skip' );
				}
				self::back( array( 'job' => $job_id ) );
				break;
			case 'commit':
				if ( ! self::job_for_user( $job_id ) ) {
					wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'educore-assessments' ), 403 );
				}
				$r = Jobs::commit( $job_id );
				self::back( is_wp_error( $r ) ? array( 'job' => $job_id, 'err' => $r->get_error_message() ) : array( 'job' => $job_id, 'msg' => 'done' ) );
				break;
			case 'cancel':
				if ( self::job_for_user( $job_id ) ) {
					Jobs::cancel( $job_id );
				}
				self::back( array( 'tab' => 'jobs' ) );
				break;
		}
	}

	public static function download(): void {
		$what = isset( $_GET['what'] ) ? sanitize_key( wp_unslash( $_GET['what'] ) ) : '';
		check_admin_referer( 'ec_qx_dl_' . $what );
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to manage question banks.', 'educore-assessments' ), 403 );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- verified above.
		if ( 'export' === $what ) {
			$course = isset( $_GET['course'] ) ? absint( $_GET['course'] ) : 0;
			$format = isset( $_GET['format'] ) ? sanitize_key( wp_unslash( $_GET['format'] ) ) : 'native';
			if ( ! in_array( $course, AssessAdmin::my_courses(), true ) || ! isset( Formats::all()[ $format ] ) ) {
				wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'educore-assessments' ), 403 );
			}
			$filters = array();
			foreach ( array( 'status', 'type', 'difficulty', 'tag' ) as $k ) {
				$filters[ $k ] = isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
			}
			$filters['lesson_id'] = isset( $_GET['lesson_id'] ) ? absint( $_GET['lesson_id'] ) : 0;
			$x = Exporter::export( $course, $format, $filters );
			if ( $x['skipped'] ) {
				set_transient( 'educore_qx_skipped_' . get_current_user_id(), $x['skipped'], HOUR_IN_SECONDS );
			}
			self::send( $x['bytes'], $x['filename'], $x['mime'] );
		}
		if ( 'report' === $what ) {
			$job = isset( $_GET['job'] ) ? absint( $_GET['job'] ) : 0;
			if ( ! self::job_for_user( $job ) ) {
				wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'educore-assessments' ), 403 );
			}
			self::send( Jobs::report_csv( $job ), 'import-report-' . $job . '.csv', 'text/csv' );
		}
		if ( 'template' === $what ) {
			$f = isset( $_GET['format'] ) && 'xlsx' === $_GET['format'] ? 'xlsx' : 'csv';
			$s = array();
			self::send( Formats::write( $f, self::examples(), $s ), 'educore-questions-template.' . $f, Formats::all()[ $f ]['mime'] );
		}
		// phpcs:enable
		wp_die( esc_html__( 'Unknown download.', 'educore-assessments' ), 400 );
	}

	private static function send( string $bytes, string $name, string $mime ): void {
		nocache_headers();
		header( 'Content-Type: ' . $mime . '; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $name ) . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		echo $bytes; // phpcs:ignore WordPress.Security.EscapeOutput -- file download.
		exit;
	}

	/** One example per question type (also used by tests and the format guide). */
	public static function examples(): array {
		$rows = array(
			array( 'type' => 'single', 'stem' => 'Which planet is closest to the Sun?', 'options' => "Mercury\nVenus\nEarth", 'correct' => '1', 'explanation' => 'Mercury orbits closest to the Sun.' ),
			array( 'type' => 'multiple', 'stem' => 'Which are prime numbers?', 'options' => "2\n4\n5\n9", 'correct' => '1,3', 'scoring' => 'partial' ),
			array( 'type' => 'truefalse', 'stem' => 'Water boils at 100 °C at sea level.', 'correct' => 'true' ),
			array( 'type' => 'short', 'stem' => 'Capital of France?', 'correct' => "Paris\nparis" ),
			array( 'type' => 'essay', 'stem' => 'Explain photosynthesis.', 'model_answer' => 'Plants convert light energy…', 'min_words' => '80' ),
			array( 'type' => 'fill_blanks', 'stem' => 'H[[1]]O is the formula of [[2]].', 'correct' => "1: 2\n2: water|H2O" ),
			array( 'type' => 'matching', 'stem' => 'Match the countries and capitals.', 'options' => "Egypt | Cairo\nFrance | Paris\nJapan | Tokyo" ),
			array( 'type' => 'ordering', 'stem' => 'Order from smallest to largest.', 'options' => "Atom\nCell\nOrgan\nOrganism" ),
			array( 'type' => 'code', 'stem' => 'What does this print?', 'code' => 'print(2 ** 3)', 'language' => 'python', 'correct' => '8' ),
		);
		$out = array();
		foreach ( $rows as $i => $row ) {
			$b = Types::from_authoring( $row );
			$out[] = Record::normalise(
				array(
					'external_id' => 'example-' . ( $i + 1 ),
					'type'        => $row['type'],
					'stem'        => $row['stem'],
					'payload'     => $b['payload'],
					'key'         => $b['key'],
					'explanation' => $row['explanation'] ?? '',
					'lang'        => 'en',
					'tags'        => 'example',
				)
			);
		}
		return $out;
	}

	private static function badge( string $s ): string {
		$c = array( 'valid' => '#00701a', 'created' => '#00701a', 'updated' => '#00701a', 'new_version' => '#00701a', 'unchanged' => '#50575e', 'skipped' => '#50575e', 'invalid' => '#b32d2e', 'failed' => '#b32d2e' );
		return '<strong style="color:' . ( $c[ $s ] ?? '#50575e' ) . '">' . esc_html( self::label( $s ) ) . '</strong>';
	}

	public static function label( string $k ): string {
		$l = array(
			'valid'         => __( 'Valid', 'educore-assessments' ),
			'invalid'       => __( 'Invalid', 'educore-assessments' ),
			'failed'        => __( 'Failed', 'educore-assessments' ),
			'create'        => __( 'Will be created', 'educore-assessments' ),
			'update'        => __( 'Will update the existing question', 'educore-assessments' ),
			'new_version'   => __( 'Will add a new version (existing version was used in attempts)', 'educore-assessments' ),
			'unchanged'     => __( 'Unchanged', 'educore-assessments' ),
			'skip_existing' => __( 'Skipped: already in the bank', 'educore-assessments' ),
			'skip_in_file'  => __( 'Skipped: duplicate inside the file', 'educore-assessments' ),
			'created'       => __( 'Created', 'educore-assessments' ),
			'updated'       => __( 'Updated', 'educore-assessments' ),
			'skipped'       => __( 'Skipped', 'educore-assessments' ),
			'validated'     => __( 'Awaiting confirmation', 'educore-assessments' ),
			'importing'     => __( 'Importing (interrupted — run again to resume)', 'educore-assessments' ),
			'completed'     => __( 'Completed', 'educore-assessments' ),
			'cancelled'     => __( 'Cancelled', 'educore-assessments' ),
		);
		return $l[ $k ] ?? $k;
	}

	public static function page(): void {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to manage question banks.', 'educore-assessments' ), 403 );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display only.
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'import';
		$job = isset( $_GET['job'] ) ? absint( $_GET['job'] ) : 0;
		echo '<div class="wrap ec-admin"><h1>' . esc_html__( 'Question Import & Export Center', 'educore-assessments' ) . '</h1>';
		if ( isset( $_GET['err'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['err'] ) ) ) . '</p></div>';
		}
		$code = isset( $_GET['msg'] ) ? sanitize_key( wp_unslash( $_GET['msg'] ) ) : '';
		// phpcs:enable
		if ( 'done' === $code ) {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Import finished. The report below shows what happened to every question.', 'educore-assessments' ) . '</p></div>';
		}
		$skipped = get_transient( 'educore_qx_skipped_' . get_current_user_id() );
		if ( $skipped ) {
			delete_transient( 'educore_qx_skipped_' . get_current_user_id() );
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'Your last export left out questions this format cannot carry:', 'educore-assessments' ) . '</p><ul style="list-style:disc;padding-inline-start:20px">';
			foreach ( array_slice( (array) $skipped, 0, 50 ) as $s ) {
				echo '<li>' . esc_html( $s ) . '</li>';
			}
			echo '</ul></div>';
		}
		if ( $job ) {
			self::job_view( $job );
			echo '</div>';
			return;
		}
		$tabs = array( 'import' => __( 'Import', 'educore-assessments' ), 'export' => __( 'Export', 'educore-assessments' ), 'jobs' => __( 'Import history', 'educore-assessments' ), 'guide' => __( 'Formats & templates', 'educore-assessments' ) );
		echo '<nav class="nav-tab-wrapper">';
		foreach ( $tabs as $k => $l ) {
			echo '<a class="nav-tab' . ( $k === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url( array( 'tab' => $k ) ) ) . '">' . esc_html( $l ) . '</a>';
		}
		echo '</nav>';
		$m = 'tab_' . ( isset( $tabs[ $tab ] ) ? $tab : 'import' );
		self::$m();
		echo '</div>';
	}

	private static function course_select( string $id ): string {
		$h = '<select id="' . esc_attr( $id ) . '" name="course" required>';
		foreach ( AssessAdmin::my_courses() as $c ) {
			$h .= '<option value="' . esc_attr( (string) $c ) . '">' . esc_html( get_the_title( $c ) ?: '#' . $c ) . '</option>';
		}
		return $h . '</select>';
	}

	private static function tab_import(): void {
		echo '<ol class="ec-steps" style="display:flex;gap:24px;list-style:decimal;padding-inline-start:20px"><li><strong>' . esc_html__( 'Upload', 'educore-assessments' ) . '</strong></li><li>' . esc_html__( 'Validate & preview', 'educore-assessments' ) . '</li><li>' . esc_html__( 'Confirm import', 'educore-assessments' ) . '</li><li>' . esc_html__( 'Report', 'educore-assessments' ) . '</li></ol>';
		echo '<form method="post" enctype="multipart/form-data">' . self::nonce_field( 'upload' ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<table class="form-table" role="presentation"><tbody>';
		echo '<tr><th scope="row"><label for="qx-course">' . esc_html__( 'Target course', 'educore-assessments' ) . '</label></th><td>' . self::course_select( 'qx-course' ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<tr><th scope="row"><label for="qx-file">' . esc_html__( 'File', 'educore-assessments' ) . '</label></th><td><input id="qx-file" type="file" name="file" required accept=".zip,.xlsx,.csv,.json,.xml,.txt,.gift"><p class="description">' . esc_html( sprintf( /* translators: 1: MB, 2: count */ __( 'Up to %1$d MB and %2$d questions per file.', 'educore-assessments' ), min( Formats::MAX_BYTES, wp_max_upload_size() ) / 1048576, Formats::MAX_ITEMS ) ) . '</p></td></tr>';
		echo '<tr><th scope="row"><label for="qx-format">' . esc_html__( 'Format', 'educore-assessments' ) . '</label></th><td><select id="qx-format" name="format"><option value="auto">' . esc_html__( 'Detect from the file', 'educore-assessments' ) . '</option>';
		foreach ( Formats::all() as $k => $f ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $f['label'] ) . '</option>';
		}
		echo '</select></td></tr><tr><th scope="row">' . esc_html__( 'When a question already exists', 'educore-assessments' ) . '</th><td><fieldset>';
		foreach ( Jobs::modes() as $k => $l ) {
			echo '<label><input type="radio" name="mode" value="' . esc_attr( $k ) . '"' . checked( 'skip', $k, false ) . '> ' . esc_html( $l ) . '</label><br>';
		}
		echo '</fieldset></td></tr><tr><th scope="row"><label for="qx-status">' . esc_html__( 'Status of imported questions', 'educore-assessments' ) . '</label></th><td><select id="qx-status" name="status"><option value="">' . esc_html__( 'As given in the file (draft if missing)', 'educore-assessments' ) . '</option><option value="draft">' . esc_html__( 'Draft', 'educore-assessments' ) . '</option><option value="review">' . esc_html__( 'In review', 'educore-assessments' ) . '</option><option value="published">' . esc_html__( 'Published (lead instructors only)', 'educore-assessments' ) . '</option></select></td></tr>';
		echo '<tr><th scope="row"><label for="qx-lang">' . esc_html__( 'Language when the file does not say', 'educore-assessments' ) . '</label></th><td><select id="qx-lang" name="lang">';
		foreach ( array_keys( I18n::LANGS ) as $l ) {
			echo '<option value="' . esc_attr( $l ) . '">' . esc_html( strtoupper( $l ) ) . '</option>';
		}
		echo '</select></td></tr></tbody></table>';
		submit_button( __( 'Upload & validate (nothing is imported yet)', 'educore-assessments' ) );
		echo '</form>';
	}

	private static function job_view( int $id ): void {
		$job = self::job_for_user( $id );
		echo '<p><a href="' . esc_url( self::url( array( 'tab' => 'jobs' ) ) ) . '">← ' . esc_html__( 'Import history', 'educore-assessments' ) . '</a></p>';
		if ( ! $job ) {
			echo '<p>' . esc_html__( 'Import not found.', 'educore-assessments' ) . '</p>';
			return;
		}
		$s = $job['summary'];
		/* translators: 1: file, 2: course, 3: format */
		echo '<h2>' . esc_html( sprintf( __( '%1$s → %2$s (%3$s)', 'educore-assessments' ), $job['filename'], get_the_title( (int) $job['course_id'] ), $job['format'] ) ) . '</h2>';
		echo '<p>' . esc_html__( 'Status:', 'educore-assessments' ) . ' <strong>' . esc_html( self::label( $job['status'] ) ) . '</strong></p>';
		$cards = array( __( 'Questions in file', 'educore-assessments' ) => (int) ( $s['total'] ?? 0 ), __( 'Valid', 'educore-assessments' ) => (int) ( $s['valid'] ?? 0 ), __( 'Invalid', 'educore-assessments' ) => (int) ( $s['invalid'] ?? 0 ), __( 'With warnings', 'educore-assessments' ) => (int) ( $s['with_warnings'] ?? 0 ) );
		foreach ( ( 'validated' === $job['status'] ? (array) ( $s['actions'] ?? array() ) : (array) ( $s['results'] ?? array() ) ) as $k => $n ) {
			$cards[ self::label( $k ) ] = (int) $n;
		}
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:12px 0">';
		foreach ( $cards as $l => $n ) {
			echo '<div class="card" style="margin:0;padding:10px 14px"><div style="color:#50575e">' . esc_html( $l ) . '</div><div style="font-size:1.5em;font-weight:600">' . esc_html( number_format_i18n( $n ) ) . '</div></div>';
		}
		echo '</div><p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=educore_qx_download&what=report&job=' . $id ), 'ec_qx_dl_report' ) ) . '">' . esc_html__( 'Download full report (CSV)', 'educore-assessments' ) . '</a></p>';
		if ( 'validated' === $job['status'] || 'importing' === $job['status'] ) {
			echo '<form method="post" style="margin:12px 0">' . self::nonce_field( 'mode' ) . '<input type="hidden" name="job" value="' . esc_attr( (string) $id ) . '"><label for="qx-mode2">' . esc_html__( 'When a question already exists', 'educore-assessments' ) . '</label> <select id="qx-mode2" name="mode">'; // phpcs:ignore WordPress.Security.EscapeOutput
			foreach ( Jobs::modes() as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $job['mode'], $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select> ' . get_submit_button( __( 'Recalculate preview', 'educore-assessments' ), 'secondary', 'submit', false ) . '</form>'; // phpcs:ignore WordPress.Security.EscapeOutput
			$n = array_sum( array_intersect_key( (array) ( $s['actions'] ?? array() ), array_flip( array( 'create', 'update', 'new_version' ) ) ) );
			echo '<form method="post" style="display:inline">' . self::nonce_field( 'commit' ) . '<input type="hidden" name="job" value="' . esc_attr( (string) $id ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput
			/* translators: %d: count */
			submit_button( sprintf( _n( 'Import %d question', 'Import %d questions', $n, 'educore-assessments' ), $n ), 'primary', 'submit', false, $n ? array() : array( 'disabled' => 'disabled' ) );
			echo '</form> <form method="post" style="display:inline">' . self::nonce_field( 'cancel' ) . '<input type="hidden" name="job" value="' . esc_attr( (string) $id ) . '">' . get_submit_button( __( 'Cancel', 'educore-assessments' ), 'secondary', 'submit', false ) . '</form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<h3>' . esc_html__( 'Questions', 'educore-assessments' ) . '</h3><table class="widefat striped"><thead><tr><th scope="col">' . esc_html__( 'Line', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'Type', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'Question', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'Result', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'Messages', 'educore-assessments' ) . '</th></tr></thead><tbody>';
		foreach ( Jobs::items( $id, 500 ) as $it ) {
			$rec  = (array) json_decode( (string) $it['record'], true );
			$msgs = (array) json_decode( (string) $it['messages'], true );
			$res  = 'valid' === $it['status'] ? '<span>' . esc_html( self::label( $it['action'] ) ) . '</span>' : self::badge( $it['status'] );
			$ml   = implode( '<br>', array_map( static fn( $m ) => ( 'e' === $m[0] ? '<span style="color:#b32d2e">✗ ' : '<span style="color:#8a5a00">⚠ ' ) . esc_html( $m[1] ) . '</span>', $msgs ) );
			$link = (int) $it['question_id'] && ! in_array( $it['status'], array( 'valid', 'invalid' ), true ) ? ' <a href="' . esc_url( admin_url( 'admin.php?page=educore-questions&course=' . $job['course_id'] . '&ec_action=edit&id=' . $it['question_id'] ) ) . '">#' . (int) $it['question_id'] . '</a>' : '';
			echo '<tr><td>' . esc_html( (string) $it['line'] ) . '</td><td>' . esc_html( (string) ( $rec['type'] ?? '' ) ) . '</td><td>' . esc_html( mb_substr( wp_strip_all_tags( (string) ( $rec['stem'] ?? '' ) ), 0, 140 ) ) . '</td><td>' . $res . $link . '</td><td>' . $ml . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
		echo '</tbody></table>';
	}

	private static function tab_export(): void {
		echo '<form method="get" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="educore_qx_download"><input type="hidden" name="what" value="export">' . wp_nonce_field( 'ec_qx_dl_export', '_wpnonce', false, false ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<table class="form-table" role="presentation"><tbody>';
		echo '<tr><th scope="row"><label for="qx-ecourse">' . esc_html__( 'Course', 'educore-assessments' ) . '</label></th><td>' . self::course_select( 'qx-ecourse' ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<tr><th scope="row"><label for="qx-eformat">' . esc_html__( 'Format', 'educore-assessments' ) . '</label></th><td><select id="qx-eformat" name="format">';
		foreach ( Formats::all() as $k => $f ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $f['label'] ) . '</option>';
		}
		echo '</select><p class="description">' . esc_html__( 'Moodle GIFT and Moodle XML cannot carry fill-in-the-blank, ordering, code and image questions; those are listed after the download.', 'educore-assessments' ) . '</p></td></tr>';
		echo '<tr><th scope="row"><label for="qx-estatus">' . esc_html__( 'Status', 'educore-assessments' ) . '</label></th><td><select id="qx-estatus" name="status"><option value="">' . esc_html__( 'All except archived', 'educore-assessments' ) . '</option>';
		foreach ( Questions::STATUSES as $st ) {
			echo '<option value="' . esc_attr( $st ) . '">' . esc_html( ucfirst( $st ) ) . '</option>';
		}
		echo '</select></td></tr><tr><th scope="row"><label for="qx-etype">' . esc_html__( 'Type', 'educore-assessments' ) . '</label></th><td><select id="qx-etype" name="type"><option value="">' . esc_html__( 'All types', 'educore-assessments' ) . '</option>';
		foreach ( Types::labels() as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $l ) . '</option>';
		}
		echo '</select></td></tr><tr><th scope="row"><label for="qx-ediff">' . esc_html__( 'Difficulty', 'educore-assessments' ) . '</label></th><td><select id="qx-ediff" name="difficulty"><option value="">' . esc_html__( 'Any', 'educore-assessments' ) . '</option>';
		foreach ( Questions::DIFFICULTY as $d ) {
			echo '<option value="' . esc_attr( $d ) . '">' . esc_html( ucfirst( $d ) ) . '</option>';
		}
		echo '</select></td></tr><tr><th scope="row"><label for="qx-etag">' . esc_html__( 'Tag', 'educore-assessments' ) . '</label></th><td><input id="qx-etag" type="text" name="tag" class="regular-text"></td></tr></tbody></table>';
		submit_button( __( 'Download export', 'educore-assessments' ) );
		echo '</form>';
	}

	private static function tab_jobs(): void {
		$rows = Jobs::recent( 50 );
		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'No imports yet.', 'educore-assessments' ) . '</p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th scope="col">' . esc_html__( 'Date', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'File', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'Course', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'By', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'Summary', 'educore-assessments' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$s   = (array) json_decode( (string) $r['summary'], true );
			$sum = array();
			foreach ( (array) ( $s['results'] ?? $s['actions'] ?? array() ) as $k => $n ) {
				$sum[] = self::label( $k ) . ': ' . $n;
			}
			$u = get_userdata( (int) $r['user_id'] );
			echo '<tr><td>' . esc_html( get_date_from_gmt( $r['created_at'], get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ) . '</td><td><a href="' . esc_url( self::url( array( 'job' => $r['id'] ) ) ) . '">' . esc_html( $r['filename'] ) . '</a> <small>(' . esc_html( $r['format'] ) . ')</small></td><td>' . esc_html( get_the_title( (int) $r['course_id'] ) ) . '</td><td>' . esc_html( $u ? $u->display_name : '—' ) . '</td><td>' . esc_html( self::label( $r['status'] ) ) . '</td><td>' . esc_html( implode( ' · ', $sum ) ) . ( ! empty( $s['invalid'] ) ? ' · ' . esc_html( self::label( 'invalid' ) . ': ' . $s['invalid'] ) : '' ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function tab_guide(): void {
		$dl = static fn( $f ) => esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=educore_qx_download&what=template&format=' . $f ), 'ec_qx_dl_template' ) );
		echo '<h2>' . esc_html__( 'Templates', 'educore-assessments' ) . '</h2><p><a class="button" href="' . $dl( 'xlsx' ) . '">' . esc_html__( 'Excel template (.xlsx)', 'educore-assessments' ) . '</a> <a class="button" href="' . $dl( 'csv' ) . '">' . esc_html__( 'CSV template', 'educore-assessments' ) . '</a></p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<p>' . esc_html__( 'Both templates contain one example of every question type. Keep the header row; columns may be in any order; only "type" and "stem" are always required.', 'educore-assessments' ) . '</p>';
		echo '<h2>' . esc_html__( 'Spreadsheet columns', 'educore-assessments' ) . '</h2><table class="widefat striped" style="max-width:980px"><tbody>';
		$cols = array(
			'external_id'  => __( 'Your own stable ID. Used to update the same question later (mode “update”).', 'educore-assessments' ),
			'type'         => implode( ', ', Types::ALL ),
			'stem'         => __( 'Question text (basic HTML allowed). Fill-in-the-blank: mark blanks [[1]], [[2]]…', 'educore-assessments' ),
			'options'      => __( 'One option per line. Matching: "left | right" per line (" | answer" adds an extra wrong answer). Ordering: items in the correct order.', 'educore-assessments' ),
			'correct'      => __( 'Single/image: option number. Multiple: numbers like 1,3. True/false: true or false. Short: accepted answers, one per line. Fill-in: "1: answer|alternative" per line. Code: expected output.', 'educore-assessments' ),
			'scoring'      => __( 'Multiple and ordering only: all_or_nothing (default) or partial.', 'educore-assessments' ),
			'points / difficulty / usage / lang / status / tags' => __( 'Optional. difficulty: easy, medium, hard. usage: any, practice, assessment. lang: en, fr, ar. status: draft, review, published. tags: comma-separated.', 'educore-assessments' ),
			'explanation / model_answer / min_words / code / language / image_id / lesson_id' => __( 'Optional, by type. lesson_id must belong to the target course.', 'educore-assessments' ),
		);
		foreach ( $cols as $c => $d ) {
			echo '<tr><th scope="row"><code>' . esc_html( $c ) . '</code></th><td>' . esc_html( $d ) . '</td></tr>';
		}
		echo '</tbody></table><h2>' . esc_html__( 'Format coverage', 'educore-assessments' ) . '</h2>';
		echo '<table class="widefat striped" style="max-width:980px"><thead><tr><th scope="col">' . esc_html__( 'Format', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'Question types', 'educore-assessments' ) . '</th><th scope="col">' . esc_html__( 'Notes', 'educore-assessments' ) . '</th></tr></thead><tbody>';
		$cov = array(
			array( __( 'EduCore package', 'educore-assessments' ), __( 'All 10, including images', 'educore-assessments' ), __( 'Lossless; checksummed. Use it to move banks between EduCore sites.', 'educore-assessments' ) ),
			array( 'Excel / CSV / JSON', __( 'All 10', 'educore-assessments' ), __( 'Image questions need the image to exist in the target media library (image_id).', 'educore-assessments' ) ),
			array( 'Moodle XML', __( 'single, multiple, true/false, short, essay, matching (+ numerical as short)', 'educore-assessments' ), __( 'Cloze, drag-and-drop, calculated and embedded images are not imported; answer feedback is not kept.', 'educore-assessments' ) ),
			array( 'GIFT', __( 'single, multiple, true/false, short, essay, matching, missing word (+ numerical as short)', 'educore-assessments' ), __( 'Answer feedback is not kept; numerical tolerance is not supported.', 'educore-assessments' ) ),
		);
		foreach ( $cov as $c ) {
			echo '<tr><td>' . esc_html( $c[0] ) . '</td><td>' . esc_html( $c[1] ) . '</td><td>' . esc_html( $c[2] ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}
}
