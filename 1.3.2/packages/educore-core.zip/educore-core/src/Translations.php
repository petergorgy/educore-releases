<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Content translations (independent of interface translation, spec §15).
 * A translated course is a full copy (units + lessons) in another content language, linked
 * through ec_translation_groups at course and lesson level. Copies start as drafts.
 */
final class Translations {

	public static function register(): void {
		add_action( 'add_meta_boxes', array( self::class, 'meta_box' ) );
		add_action( 'admin_post_educore_translate', array( self::class, 'handle_create' ) );
		add_filter( 'educore/course/after_details', array( self::class, 'course_links' ), 5, 2 );
		add_filter( 'educore/lesson/after_content', array( self::class, 'lesson_links' ), 1, 2 );
	}

	public static function lang_of( int $post_id ): string {
		return I18n::sanitize_lang( get_post_meta( $post_id, '_ec_lang', true ) ?: I18n::DEFAULT );
	}

	/** @return array<string,int> lang => post id, including the post itself */
	public static function versions( int $post_id ): array {
		$type = (string) get_post_type( $post_id );
		$map  = I18n::translations( $type, $post_id );
		if ( ! $map ) {
			$map = array( self::lang_of( $post_id ) => $post_id );
		}
		return $map;
	}

	/** Link two posts as translations of each other (creates the group when needed). */
	public static function link( int $source_id, int $target_id ): void {
		$type  = (string) get_post_type( $source_id );
		$group = 0;
		$map   = I18n::translations( $type, $source_id );
		if ( $map ) {
			global $wpdb;
			$group = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT group_id FROM ' . Schema::table( 'translation_groups' ) . ' WHERE object_type=%s AND object_id=%d', $type, $source_id ) );
		}
		if ( ! $group ) {
			$group = $source_id;
			I18n::link_translation( $type, $source_id, $group, self::lang_of( $source_id ) );
		}
		I18n::link_translation( $type, $target_id, $group, self::lang_of( $target_id ) );
	}

	/**
	 * Create a draft copy of a course in $lang and link course + lessons pairwise.
	 *
	 * @return int|\WP_Error new course id
	 */
	public static function create_course_translation( int $course_id, string $lang, int $user_id ) {
		$lang = I18n::sanitize_lang( $lang );
		if ( ! Content::is_course( $course_id ) ) {
			return new \WP_Error( 'educore_no_course', __( 'Course not found.', 'educore-core' ) );
		}
		$existing = self::versions( $course_id );
		if ( isset( $existing[ $lang ] ) ) {
			return new \WP_Error( 'educore_translation_exists', __( 'A version in this language already exists.', 'educore-core' ) );
		}
		$new = Content::duplicate_course( $course_id, $user_id );
		if ( ! $new ) {
			return new \WP_Error( 'educore_failed', __( 'Could not create the translation.', 'educore-core' ) );
		}
		// Title: keep source title with a language marker the translator replaces.
		wp_update_post( array( 'ID' => $new, 'post_title' => get_the_title( $course_id ) . ' [' . strtoupper( $lang ) . ']' ) );
		update_post_meta( $new, '_ec_lang', $lang );
		foreach ( Curriculum::mappings_for_course( $course_id ) as $m ) {
			Curriculum::map_course( $new, (int) $m['programme_id'], (int) $m['period_id'], (int) $m['subject_id'] );
		}
		self::link( $course_id, $new );
		$src = self::flat_lessons( $course_id );
		$dst = self::flat_lessons( $new );
		foreach ( $src as $i => $lid ) {
			if ( isset( $dst[ $i ] ) ) {
				update_post_meta( $dst[ $i ], '_ec_lang', $lang );
				self::link( $lid, $dst[ $i ] );
			}
		}
		// Teaching staff of the source course also staff the translation.
		foreach ( Staff::of_course( $course_id ) as $row ) {
			if ( (int) $row['user_id'] !== $user_id ) {
				Staff::assign( $new, (int) $row['user_id'], (string) $row['staff_role'] );
			}
		}
		Audit::log( 'course.translation_created', 'course', $new, array( 'source' => $course_id, 'lang' => $lang ) );
		return $new;
	}

	/** @return int[] lessons of a course in outline order (any status) */
	private static function flat_lessons( int $course_id ): array {
		$ids = array();
		foreach ( Content::outline( $course_id, array( 'publish', 'draft', 'pending', 'future', 'private' ) ) as $row ) {
			foreach ( $row['lessons'] as $l ) {
				$ids[] = (int) $l->ID;
			}
		}
		return $ids;
	}

	/* ---------- admin ---------- */

	public static function meta_box(): void {
		foreach ( array( Content::COURSE, Content::LESSON ) as $type ) {
			add_meta_box( 'ec_translations', __( 'Translations', 'educore-core' ), array( self::class, 'render_box' ), $type, 'side' );
		}
	}

	public static function render_box( \WP_Post $post ): void {
		$versions = self::versions( $post->ID );
		$labels   = I18n::labels();
		echo '<p>' . esc_html__( 'Content language:', 'educore-core' ) . ' <strong>' . esc_html( $labels[ self::lang_of( $post->ID ) ] ?? '' ) . '</strong></p><ul>';
		foreach ( $labels as $code => $label ) {
			if ( $code === self::lang_of( $post->ID ) ) {
				continue;
			}
			echo '<li>' . esc_html( $label ) . ': ';
			if ( isset( $versions[ $code ] ) ) {
				$id = $versions[ $code ];
				echo current_user_can( 'edit_post', $id ) ? '<a href="' . esc_url( (string) get_edit_post_link( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a>' : esc_html( get_the_title( $id ) );
				echo ' <em>(' . esc_html( (string) get_post_status( $id ) ) . ')</em>';
			} elseif ( Content::COURSE === $post->post_type && 'auto-draft' !== $post->post_status && current_user_can( 'ec_edit_course', $post->ID ) && current_user_can( 'edit_ec_courses' ) ) {
				$url = wp_nonce_url( admin_url( 'admin-post.php?action=educore_translate&course=' . $post->ID . '&lang=' . $code ), 'educore_translate_' . $post->ID );
				/* translators: %s: language name */
				echo '<a class="button button-small" href="' . esc_url( $url ) . '">' . esc_html( sprintf( __( 'Create %s copy', 'educore-core' ), $label ) ) . '</a>';
			} else {
				echo '<em>' . esc_html__( 'none', 'educore-core' ) . '</em>';
			}
			echo '</li>';
		}
		echo '</ul>';
		if ( Content::LESSON === $post->post_type ) {
			echo '<p class="description">' . esc_html__( 'Lesson translations are created together with their course translation.', 'educore-core' ) . '</p>';
		} else {
			echo '<p class="description">' . esc_html__( 'Creates a draft copy of the whole course (units and lessons) for translation, linked to this one.', 'educore-core' ) . '</p>';
		}
	}

	public static function handle_create(): void {
		$course = isset( $_GET['course'] ) ? absint( $_GET['course'] ) : 0;
		check_admin_referer( 'educore_translate_' . $course );
		if ( ! current_user_can( 'ec_edit_course', $course ) || ! current_user_can( 'edit_ec_courses' ) ) {
			wp_die( '', 403 );
		}
		$lang = isset( $_GET['lang'] ) ? sanitize_key( wp_unslash( $_GET['lang'] ) ) : '';
		$res  = self::create_course_translation( $course, $lang, get_current_user_id() );
		if ( is_wp_error( $res ) ) {
			wp_die( esc_html( $res->get_error_message() ), '', array( 'back_link' => true ) );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=educore-curriculum&course=' . $res . '&ec_done=1' ) );
		exit;
	}

	/* ---------- frontend ---------- */

	private static function links( int $post_id ): string {
		$labels = I18n::labels();
		$items  = array();
		foreach ( self::versions( $post_id ) as $code => $id ) {
			if ( $id === $post_id || 'publish' !== get_post_status( $id ) ) {
				continue;
			}
			$items[] = '<a lang="' . esc_attr( $code ) . '" hreflang="' . esc_attr( $code ) . '" href="' . esc_url( (string) get_permalink( $id ) ) . '">' . esc_html( $labels[ $code ] ?? $code ) . '</a>';
		}
		return $items ? '<p class="ec-translations">' . esc_html__( 'Also available in:', 'educore-core' ) . ' ' . implode( ' · ', $items ) . '</p>' : '';
	}

	public static function course_links( string $html, int $course_id ): string {
		return self::links( $course_id ) . $html;
	}

	public static function lesson_links( string $html, int $lesson_id ): string {
		return self::links( $lesson_id ) . $html;
	}
}
