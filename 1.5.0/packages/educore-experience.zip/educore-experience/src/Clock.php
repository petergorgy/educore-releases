<?php
namespace EduCore\Experience;

defined( 'ABSPATH' ) || exit;

/**
 * Local time and the eight display states.
 *
 * Fixed mode: mutually exclusive windows in the person's IANA time zone (defaults below; editable by administrators).
 * Solar mode: windows follow the sun at a chosen city (or rounded device location the person shared on purpose):
 *   Midnight 00:00 → Dawn start · Dawn: civil twilight begins → sunrise · Morning: sunrise → solar noon − 15 min ·
 *   Noon: solar noon ± 15 min · Afternoon → sunset − 45 min · Dusk → end of civil twilight ·
 *   Evening → + N hours (default 3) · Night → 24:00. Polar day/night or missing data falls back to the fixed windows.
 */
final class Clock {
	public const STATES = array( 'midnight', 'dawn', 'morning', 'noon', 'afternoon', 'dusk', 'evening', 'night' );
	public const DARK   = array( 'midnight', 'evening', 'night' );

	/** Default fixed schedule: state => start (HH:MM). Each state runs until the next one starts. */
	public const FIXED = array(
		'midnight'  => '00:00',
		'dawn'      => '05:00',
		'morning'   => '06:00',
		'noon'      => '11:45',
		'afternoon' => '12:15',
		'dusk'      => '17:00',
		'evening'   => '18:15',
		'night'     => '21:00',
	);

	public static function valid_tz( string $tz ): bool {
		return in_array( $tz, \DateTimeZone::listIdentifiers(), true );
	}

	/** User's explicit zone → institution zone → platform (WordPress) zone → UTC. */
	public static function tz_for( int $uid ): string {
		$p = $uid ? Prefs::get( $uid ) : array();
		foreach ( array( (string) ( $p['timezone'] ?? '' ), (string) Settings::get( 'institution_tz' ), (string) wp_timezone_string() ) as $tz ) {
			if ( '' !== $tz && self::valid_tz( $tz ) ) {
				return $tz;
			}
		}
		return 'UTC';
	}

	/** @return array<string,int> state => start minute of day, validated (sorted, starts at 00:00, no duplicates). */
	public static function schedule(): array {
		$cfg = (array) Settings::get( 'schedule' );
		$out = array();
		foreach ( self::STATES as $s ) {
			$hm        = (string) ( $cfg[ $s ] ?? self::FIXED[ $s ] );
			$out[ $s ] = self::minutes( $hm ) ?? self::minutes( self::FIXED[ $s ] );
		}
		return self::valid_schedule( $out ) ? $out : array_map( array( self::class, 'minutes' ), self::FIXED );
	}

	public static function valid_schedule( array $starts ): bool {
		$prev = -1;
		foreach ( self::STATES as $i => $s ) {
			$m = $starts[ $s ] ?? null;
			if ( null === $m || ( 0 === $i && 0 !== $m ) || $m <= $prev || $m > 1439 ) {
				return false;
			}
			$prev = $m;
		}
		return true;
	}

	public static function minutes( string $hm ): ?int {
		if ( ! preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', $hm, $m ) ) {
			return null;
		}
		return (int) $m[1] * 60 + (int) $m[2];
	}

	public static function state_for_minute( int $minute, ?array $starts = null ): string {
		$starts = $starts ?? self::schedule();
		$state  = 'midnight';
		foreach ( self::STATES as $s ) {
			if ( $minute >= $starts[ $s ] ) {
				$state = $s;
			}
		}
		return $state;
	}

	/** Fixed-schedule state at a moment in a zone. */
	public static function fixed_state( int $ts, string $tz ): string {
		$d = ( new \DateTimeImmutable( '@' . $ts ) )->setTimezone( new \DateTimeZone( $tz ) );
		return self::state_for_minute( (int) $d->format( 'G' ) * 60 + (int) $d->format( 'i' ) );
	}

	/**
	 * Solar boundaries (UTC timestamps) for the local day containing $ts, or null when the sun does not
	 * rise/set that day (polar day/night) or the location is unknown.
	 *
	 * @return array<string,int>|null state => start timestamp
	 */
	public static function solar_day( int $ts, string $tz, float $lat, float $lng ): ?array {
		$zone  = new \DateTimeZone( $tz );
		$local = ( new \DateTimeImmutable( '@' . $ts ) )->setTimezone( $zone );
		$mid   = $local->setTime( 0, 0 )->getTimestamp();
		$next  = $local->setTime( 0, 0 )->modify( '+1 day' )->getTimestamp();
		$noon  = $local->setTime( 12, 0 )->getTimestamp();
		$i     = date_sun_info( $noon, $lat, $lng );
		foreach ( array( 'sunrise', 'sunset', 'transit', 'civil_twilight_begin', 'civil_twilight_end' ) as $k ) {
			if ( ! isset( $i[ $k ] ) || ! is_int( $i[ $k ] ) ) {
				return null; // true/false = polar day/night.
			}
		}
		$hours = max( 1, min( 6, (int) Settings::get( 'evening_hours' ) ) );
		$dawn  = min( $i['civil_twilight_begin'], $i['sunrise'] - 15 * 60 );
		$b     = array(
			'midnight'  => $mid,
			'dawn'      => $dawn,
			'morning'   => $i['sunrise'],
			'noon'      => $i['transit'] - 15 * 60,
			'afternoon' => $i['transit'] + 15 * 60,
			'dusk'      => $i['sunset'] - 45 * 60,
			'evening'   => max( $i['civil_twilight_end'], $i['sunset'] + 15 * 60 ),
			'night'     => min( $next - 60, max( $i['civil_twilight_end'], $i['sunset'] + 15 * 60 ) + $hours * 3600 ),
		);
		$prev = $mid - 1;
		foreach ( self::STATES as $s ) {
			if ( $b[ $s ] <= $prev || $b[ $s ] >= $next ) {
				return null; // Extreme latitudes: windows collapse; use the fixed schedule.
			}
			$prev = $b[ $s ];
		}
		return $b;
	}

	/** @return array{lat:float,lng:float,label:string}|null */
	public static function solar_location( array $p ): ?array {
		if ( null !== ( $p['solar_lat'] ?? null ) && null !== ( $p['solar_lng'] ?? null ) ) {
			return array( 'lat' => (float) $p['solar_lat'], 'lng' => (float) $p['solar_lng'], 'label' => __( 'Your device location (rounded)', 'educore-experience' ) );
		}
		$c = Cities::get( (string) ( $p['solar_city'] ?? '' ) );
		return $c ? array( 'lat' => $c['lat'], 'lng' => $c['lng'], 'label' => $c['name'] ) : null;
	}

	/**
	 * The state for a person now (or at $ts), honouring their appearance mode.
	 *
	 * @return array{state:string,source:string,tz:string}
	 */
	public static function state( int $uid, ?int $ts = null ): array {
		$ts = $ts ?? time();
		$tz = self::tz_for( $uid );
		$p  = Prefs::get( $uid );
		if ( 'solar' === $p['appearance'] ) {
			$loc = self::solar_location( $p );
			$day = $loc ? self::solar_day( $ts, $tz, $loc['lat'], $loc['lng'] ) : null;
			if ( $day ) {
				$state = 'midnight';
				foreach ( self::STATES as $s ) {
					if ( $ts >= $day[ $s ] ) {
						$state = $s;
					}
				}
				return array( 'state' => $state, 'source' => 'solar', 'tz' => $tz );
			}
			return array( 'state' => self::fixed_state( $ts, $tz ), 'source' => 'fixed-fallback', 'tz' => $tz );
		}
		return array( 'state' => self::fixed_state( $ts, $tz ), 'source' => 'fixed', 'tz' => $tz );
	}

	/** Localised date (and optional time) in the interface language and the given zone. */
	public static function format( int $ts, string $tz, bool $with_time = false, bool $weekday = false ): string {
		$lang = class_exists( '\EduCore\Core\I18n' ) ? \EduCore\Core\I18n::current() : 'en';
		if ( class_exists( '\IntlDateFormatter' ) ) {
			$loc     = array( 'en' => 'en_GB', 'fr' => 'fr_FR', 'ar' => 'ar_EG' )[ $lang ] ?? 'en_GB';
			$pattern = ( $weekday ? 'EEEE ' : '' ) . 'd MMMM' . ( $with_time ? ' y, HH:mm' : ( $weekday ? '' : ' y' ) );
			$f       = new \IntlDateFormatter( $loc, \IntlDateFormatter::NONE, \IntlDateFormatter::NONE, $tz, \IntlDateFormatter::GREGORIAN, $pattern );
			$out     = $f->format( $ts );
			if ( false !== $out ) {
				return (string) $out;
			}
		}
		$fmt = ( $weekday ? 'l ' : '' ) . 'j F' . ( $with_time ? ' Y, H:i' : ( $weekday ? '' : ' Y' ) );
		return wp_date( $fmt, $ts, new \DateTimeZone( $tz ) );
	}
}
