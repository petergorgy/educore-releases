<?php
namespace EduCore\Experience;

defined( 'ABSPATH' ) || exit;

/**
 * Adaptive Daylight Experience: puts the appearance attributes on <html> before first paint, everywhere EduCore renders
 * (theme pages, the workspace shell and the sign-in screen). The browser then keeps the state current on its own
 * (experience.js), re-checking after the tab wakes up or regains focus.
 *
 * <html data-educore-time-theme="dawn" data-theme="light" data-ec-font="110" data-ec-contrast="high" …>
 */
final class Appearance {

	public static function register(): void {
		add_action( 'wp_head', array( self::class, 'head' ), 2 );
		add_action( 'login_head', array( self::class, 'head' ), 2 );
		add_action( 'login_enqueue_scripts', array( Plugin::class, 'assets' ) );
	}

	public static function labels(): array {
		return array(
			'midnight'  => __( 'Midnight', 'educore-experience' ),
			'dawn'      => __( 'Dawn', 'educore-experience' ),
			'morning'   => __( 'Morning', 'educore-experience' ),
			'noon'      => __( 'Noon', 'educore-experience' ),
			'afternoon' => __( 'Afternoon', 'educore-experience' ),
			'dusk'      => __( 'Dusk', 'educore-experience' ),
			'evening'   => __( 'Evening', 'educore-experience' ),
			'night'     => __( 'Night', 'educore-experience' ),
		);
	}

	public static function mode_labels(): array {
		return array(
			'auto'   => __( 'Automatic — time of day', 'educore-experience' ),
			'solar'  => __( 'Automatic — sunrise and sunset', 'educore-experience' ),
			'system' => __( 'Follow my device (light or dark)', 'educore-experience' ),
			'light'  => __( 'Light', 'educore-experience' ),
			'dark'   => __( 'Dark', 'educore-experience' ),
		) + self::labels();
	}

	/**
	 * Client configuration. Signed-in: from the account (never from shared browser storage).
	 * Visitors: platform defaults; a visitor's own light/dark choice may be kept on their device.
	 */
	public static function config( int $uid ): array {
		$p     = $uid ? Prefs::get( $uid ) : array_merge( Prefs::defaults(), array( 'appearance' => Settings::get( 'default_mode' ) ) );
		$tz    = Clock::tz_for( $uid );
		$solar = null;
		if ( $uid && 'solar' === $p['appearance'] ) {
			$loc = Clock::solar_location( $p );
			if ( $loc ) {
				$days = array();
				foreach ( array( '-1 day', 'now', '+1 day', '+2 days' ) as $rel ) {
					$day = Clock::solar_day( (int) strtotime( $rel ), $tz, $loc['lat'], $loc['lng'] );
					if ( $day ) {
						$days[] = $day;
					}
				}
				$solar = $days ? array( 'days' => $days, 'until' => time() + DAY_IN_SECONDS ) : null;
			}
		}
		return array(
			'user'     => $uid ? 1 : 0,
			'mode'     => $p['appearance'],
			'tz'       => $tz,
			'schedule' => array_values( Clock::schedule() ),
			'states'   => Clock::STATES,
			'dark'     => Clock::DARK,
			'solar'    => $solar,
			'defer'    => (bool) Settings::get( 'defer_in_exams' ),
			'font'     => (int) $p['font_scale'],
			'contrast' => $p['contrast'],
			'motion'   => $p['motion'],
			'density'  => $p['density'],
			'reading'  => $p['reading'],
			'now'      => Clock::state( $uid )['state'],
		);
	}

	public static function head(): void {
		$cfg = self::config( get_current_user_id() );
		// Minimal, dependency-free bootstrap; experience.js takes over after load. Runs before CSS paints.
		$js = 'window.EduCoreXPConfig=' . wp_json_encode( $cfg ) . ';'
			. '(function(c){var d=document.documentElement,m=c.mode;'
			. 'if(!c.user){try{var v=localStorage.getItem("educore-xp-anon")||"";if(v){m=v;}else{var o=localStorage.getItem("educore-theme");if(o==="dark"||o==="light"){m=o;}}}catch(e){}}'
			. 'var s=c.now,st=c.states.indexOf(m)>-1?m:null;'
			. 'if(st){s=st;}else if(m==="auto"||m==="solar"){try{var p=new Intl.DateTimeFormat("en-GB",{timeZone:c.tz,hour:"2-digit",minute:"2-digit",hourCycle:"h23"}).formatToParts(new Date()),h=0,n=0;p.forEach(function(x){if(x.type==="hour"){h=+x.value;}if(x.type==="minute"){n=+x.value;}});'
			. 'if(m==="auto"||!c.solar){var t=h*60+n;for(var i=0;i<c.schedule.length;i++){if(t>=c.schedule[i]){s=c.states[i];}}}}catch(e){}}else{s="";}'
			. 'var dk=s?c.dark.indexOf(s)>-1:(m==="dark"||(m==="system"&&window.matchMedia&&matchMedia("(prefers-color-scheme: dark)").matches));'
			. 'if(s){d.setAttribute("data-educore-time-theme",s);}else{d.removeAttribute("data-educore-time-theme");}'
			. 'd.setAttribute("data-theme",dk?"dark":"light");d.setAttribute("data-ec-mode",m);'
			. 'if(c.font!==100){d.setAttribute("data-ec-font",c.font);}if(c.contrast==="high"){d.setAttribute("data-ec-contrast","high");}'
			. 'if(c.motion==="reduce"){d.setAttribute("data-ec-motion","reduce");}if(c.density==="compact"){d.setAttribute("data-ec-density","compact");}if(c.reading==="spacious"){d.setAttribute("data-ec-reading","spacious");}'
			. '})(window.EduCoreXPConfig);';
		echo '<script id="educore-xp-boot">' . $js . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- JSON-encoded config + static script.
	}

	/** Small decorative illustration for the welcome card (aria-hidden by the caller). */
	public static function icon( string $state ): string {
		$sun   = '<circle cx="32" cy="32" r="11"/><g stroke-linecap="round"><path d="M32 9v6M32 49v6M9 32h6M49 32h6M15.7 15.7l4.2 4.2M44.1 44.1l4.2 4.2M15.7 48.3l4.2-4.2M44.1 19.9l4.2-4.2"/></g>';
		$moon  = '<path d="M41 12a20 20 0 1 0 11 30A16 16 0 0 1 41 12z"/>';
		$horiz = '<path d="M8 44h48" stroke-linecap="round"/><path d="M18 44a14 14 0 0 1 28 0"/><g stroke-linecap="round"><path d="M32 18v5M17 27l3.5 3.5M47 27l-3.5 3.5"/></g>';
		$stars = '<g fill="currentColor" stroke="none"><circle cx="14" cy="16" r="1.6"/><circle cx="50" cy="12" r="1.2"/><circle cx="54" cy="30" r="1.4"/><circle cx="10" cy="40" r="1.1"/></g>';
		$map   = array(
			'midnight'  => $moon . $stars,
			'dawn'      => $horiz,
			'morning'   => $sun,
			'noon'      => $sun,
			'afternoon' => $sun,
			'dusk'      => $horiz,
			'evening'   => $moon,
			'night'     => $moon . $stars,
		);
		return '<svg viewBox="0 0 64 64" width="64" height="64" fill="none" stroke="currentColor" stroke-width="2.2" focusable="false">' . ( $map[ $state ] ?? $sun ) . '</svg>';
	}
}
