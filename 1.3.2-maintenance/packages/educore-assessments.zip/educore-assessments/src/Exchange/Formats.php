<?php
namespace EduCore\Assessments\Exchange;

defined( 'ABSPATH' ) || exit;

/** Format registry and dispatch (readers produce items; writers consume canonical records). */
final class Formats {
	public const NATIVE_FORMAT  = 'educore-question-bank';
	public const NATIVE_VERSION = 1;
	public const MAX_BYTES      = 20 * 1048576;
	public const MAX_ITEMS      = 5000;
	private const MEDIA_RE      = '#^media/[a-f0-9]{40}\.(png|jpe?g|gif|webp)$#';

	public static function all(): array {
		return array(
			'native'    => array( 'label' => __( 'EduCore package (.zip) — lossless, includes images', 'educore-assessments' ), 'ext' => 'zip', 'mime' => 'application/zip' ),
			'xlsx'      => array( 'label' => __( 'Excel (.xlsx)', 'educore-assessments' ), 'ext' => 'xlsx', 'mime' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ),
			'csv'       => array( 'label' => __( 'CSV (UTF-8)', 'educore-assessments' ), 'ext' => 'csv', 'mime' => 'text/csv' ),
			'json'      => array( 'label' => __( 'JSON (EduCore structure)', 'educore-assessments' ), 'ext' => 'json', 'mime' => 'application/json' ),
			'moodlexml' => array( 'label' => __( 'Moodle XML', 'educore-assessments' ), 'ext' => 'xml', 'mime' => 'application/xml' ),
			'gift'      => array( 'label' => __( 'Moodle GIFT (.txt / .gift)', 'educore-assessments' ), 'ext' => 'gift.txt', 'mime' => 'text/plain' ),
		);
	}

	public static function detect( string $filename, string $path ): string {
		$name = strtolower( $filename );
		if ( preg_match( '/\.zip$/', $name ) ) {
			return 'native';
		}
		foreach ( array( 'xlsx' => '/\.xlsx$/', 'csv' => '/\.csv$/', 'json' => '/\.json$/', 'moodlexml' => '/\.xml$/', 'gift' => '/\.(gift|txt)$/' ) as $f => $re ) {
			if ( preg_match( $re, $name ) ) {
				return $f;
			}
		}
		$head = (string) file_get_contents( $path, false, null, 0, 512 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( 0 === strpos( $head, 'PK' ) ) {
			return 'native';
		}
		return str_contains( $head, '<quiz' ) ? 'moodlexml' : ( preg_match( '/^\s*[\[{]/', $head ) ? 'json' : 'gift' );
	}

	/**
	 * @return array<int,array{line:int,record:?array,error:?string,warnings:string[]}>|\WP_Error
	 */
	public static function read( string $format, string $path ) {
		if ( ! is_readable( $path ) || filesize( $path ) > self::MAX_BYTES ) {
			/* translators: %d: MB */
			return new \WP_Error( 'ec_x_size', sprintf( __( 'The file is missing or larger than %d MB.', 'educore-assessments' ), self::MAX_BYTES / 1048576 ) );
		}
		$items = array();
		$push  = static function ( int $line, ?array $rec, ?string $err, array $warn = array() ) use ( &$items ) {
			$items[] = array( 'line' => $line, 'record' => $rec, 'error' => $err, 'warnings' => $warn );
		};
		switch ( $format ) {
			case 'csv':
			case 'xlsx':
				$rows = 'csv' === $format ? Tabular::read_csv( (string) file_get_contents( $path ) ) : Tabular::read_xlsx( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( is_wp_error( $rows ) ) {
					return $rows;
				}
				foreach ( $rows as $line => $row ) {
					$r = Tabular::row_to_record( $row );
					if ( null === $r['record'] && null === $r['error'] ) {
						continue;
					}
					$push( (int) $line, $r['record'], $r['error'] );
				}
				break;
			case 'json':
				$data = json_decode( (string) file_get_contents( $path ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( ! is_array( $data ) ) {
					return new \WP_Error( 'ec_x_json', __( 'The JSON file could not be read.', 'educore-assessments' ) );
				}
				$list = isset( $data['questions'] ) && is_array( $data['questions'] ) ? $data['questions'] : ( array_is_list( $data ) ? $data : null );
				if ( null === $list ) {
					return new \WP_Error( 'ec_x_json', __( 'The JSON file has no "questions" list.', 'educore-assessments' ) );
				}
				foreach ( array_values( $list ) as $i => $r ) {
					is_array( $r ) ? $push( $i + 1, self::structured( $r ), null ) : $push( $i + 1, null, __( 'Not a question object.', 'educore-assessments' ) );
				}
				break;
			case 'native':
				$pkg = self::open_package( $path );
				if ( is_wp_error( $pkg ) ) {
					return $pkg;
				}
				foreach ( $pkg['questions'] as $i => $r ) {
					$rec = is_array( $r ) ? self::structured( $r ) : null;
					if ( $rec && ! empty( $r['media']['image'] ) ) {
						$rec['media'] = array( 'image' => (string) $r['media']['image'] );
						if ( ! in_array( $rec['media']['image'], $pkg['media'], true ) ) {
							$push( $i + 1, $rec, __( 'The image referenced by this question is missing from the package.', 'educore-assessments' ) );
							continue;
						}
					}
					$rec ? $push( $i + 1, $rec, null ) : $push( $i + 1, null, __( 'Not a question object.', 'educore-assessments' ) );
				}
				break;
			case 'gift':
			case 'moodlexml':
				$raw = (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( ! mb_check_encoding( $raw, 'UTF-8' ) ) {
					return new \WP_Error( 'ec_x_encoding', __( 'The file is not UTF-8 encoded.', 'educore-assessments' ) );
				}
				$res = 'gift' === $format ? Gift::read( $raw ) : MoodleXml::read( $raw );
				if ( is_wp_error( $res ) ) {
					return $res;
				}
				foreach ( $res as $line => $r ) {
					$push( (int) $line, $r['record'], $r['error'], $r['warnings'] );
				}
				break;
			default:
				return new \WP_Error( 'ec_x_format', __( 'Unknown format.', 'educore-assessments' ) );
		}
		if ( ! $items ) {
			return new \WP_Error( 'ec_x_empty', __( 'No questions were found in the file.', 'educore-assessments' ) );
		}
		if ( count( $items ) > self::MAX_ITEMS ) {
			/* translators: %d: max */
			return new \WP_Error( 'ec_x_many', sprintf( __( 'Too many questions in one file (maximum %d). Split the file.', 'educore-assessments' ), self::MAX_ITEMS ) );
		}
		return $items;
	}

	/** Structured (JSON/native) object → record. */
	private static function structured( array $r ): array {
		$key = (array) ( $r['key'] ?? array() );
		if ( isset( $r['scoring'] ) && 'partial' === $r['scoring'] ) {
			$key['scoring'] = 'partial';
		}
		$r['key'] = $key;
		return $r;
	}

	/**
	 * Open and verify a native package (manifest, checksums, safe entry names, size limits).
	 *
	 * @return array{manifest:array,questions:array,media:string[]}|\WP_Error
	 */
	public static function open_package( string $path ) {
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $path, \ZipArchive::RDONLY ) ) {
			return new \WP_Error( 'ec_x_zip', __( 'The package is not a valid ZIP file.', 'educore-assessments' ) );
		}
		$total = 0;
		$media = array();
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$st     = $zip->statIndex( $i );
			$total += (int) $st['size'];
			$n      = (string) $st['name'];
			if ( in_array( $n, array( 'manifest.json', 'questions.json' ), true ) || 'media/' === $n ) {
				continue;
			}
			if ( ! preg_match( self::MEDIA_RE, $n ) ) {
				$zip->close();
				/* translators: %s: entry name */
				return new \WP_Error( 'ec_x_entry', sprintf( __( 'Unexpected file in package: %s', 'educore-assessments' ), $n ) );
			}
			$media[] = $n;
		}
		if ( $zip->numFiles > self::MAX_ITEMS + 10 || $total > 5 * self::MAX_BYTES ) {
			$zip->close();
			return new \WP_Error( 'ec_x_size', __( 'The package is too large once uncompressed.', 'educore-assessments' ) );
		}
		$man = json_decode( (string) $zip->getFromName( 'manifest.json' ), true );
		$qj  = (string) $zip->getFromName( 'questions.json' );
		if ( ! is_array( $man ) || self::NATIVE_FORMAT !== ( $man['format'] ?? '' ) ) {
			$zip->close();
			return new \WP_Error( 'ec_x_manifest', __( 'This ZIP is not an EduCore question package (manifest missing).', 'educore-assessments' ) );
		}
		if ( (int) ( $man['format_version'] ?? 0 ) > self::NATIVE_VERSION ) {
			$zip->close();
			return new \WP_Error( 'ec_x_version', __( 'The package was created by a newer EduCore version. Update EduCore first.', 'educore-assessments' ) );
		}
		if ( ! hash_equals( (string) ( $man['questions_sha256'] ?? '' ), hash( 'sha256', $qj ) ) ) {
			$zip->close();
			return new \WP_Error( 'ec_x_checksum', __( 'Package checksum mismatch: the questions file was modified or damaged.', 'educore-assessments' ) );
		}
		foreach ( $media as $m ) {
			if ( basename( $m, '.' . pathinfo( $m, PATHINFO_EXTENSION ) ) !== sha1( (string) $zip->getFromName( $m ) ) ) {
				$zip->close();
				/* translators: %s: entry */
				return new \WP_Error( 'ec_x_checksum', sprintf( __( 'Package checksum mismatch for %s.', 'educore-assessments' ), $m ) );
			}
		}
		$zip->close();
		$qs = json_decode( $qj, true );
		return is_array( $qs ) ? array( 'manifest' => $man, 'questions' => $qs, 'media' => $media ) : new \WP_Error( 'ec_x_json', __( 'The questions file could not be read.', 'educore-assessments' ) );
	}

	/**
	 * @param array[]  $records canonical records
	 * @param string[] $skipped receives notes about records the format cannot carry
	 */
	public static function write( string $format, array $records, array &$skipped, array $context = array() ): string {
		switch ( $format ) {
			case 'csv':
				return Tabular::write_csv( $records );
			case 'xlsx':
				return Tabular::write_xlsx( $records );
			case 'gift':
				return Gift::write( $records, $skipped );
			case 'moodlexml':
				return MoodleXml::write( $records, $skipped );
			case 'json':
				return (string) wp_json_encode( array( 'format' => 'educore-questions', 'format_version' => 1, 'questions' => self::structured_out( $records, $skipped, false ) ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
			case 'native':
				return self::write_package( $records, $skipped, $context );
		}
		return '';
	}

	private static function structured_out( array $records, array &$skipped, bool $media, array &$files = array() ): array {
		$out = array();
		foreach ( $records as $r ) {
			$o = $r;
			unset( $o['media'] );
			if ( 'image' === $r['type'] ) {
				$file = get_attached_file( (int) ( $r['payload']['image_id'] ?? 0 ) );
				if ( $media && $file && is_readable( $file ) ) {
					$bin  = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
					$ext  = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
					$ext  = 'jpeg' === $ext ? 'jpg' : $ext;
					$name = 'media/' . sha1( $bin ) . '.' . $ext;
					if ( preg_match( self::MEDIA_RE, $name ) ) {
						$files[ $name ] = $bin;
						$o['media']     = array( 'image' => $name );
					}
				} elseif ( ! $media ) {
					$skipped[] = $r['external_id'] . ': ' . __( 'image file not included (only the EduCore package carries images)', 'educore-assessments' );
				}
			}
			$out[] = $o;
		}
		return $out;
	}

	private static function write_package( array $records, array &$skipped, array $context ): string {
		$files = array();
		$qs    = (string) wp_json_encode( self::structured_out( $records, $skipped, true, $files ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		$man   = array(
			'format'           => self::NATIVE_FORMAT,
			'format_version'   => self::NATIVE_VERSION,
			'generator'        => 'EduCore Assessments ' . EDUCORE_ASSESSMENTS_VERSION,
			'exported_at'      => gmdate( 'c' ),
			'source'           => array( 'site' => home_url(), 'course_id' => (int) ( $context['course_id'] ?? 0 ), 'course' => (string) ( $context['course_title'] ?? '' ) ),
			'count'            => count( $records ),
			'questions_sha256' => hash( 'sha256', $qs ),
			'media'            => array_keys( $files ),
		);
		$tmp = wp_tempnam( 'educore-qpkg' );
		$zip = new \ZipArchive();
		$zip->open( $tmp, \ZipArchive::CREATE | \ZipArchive::OVERWRITE );
		$zip->addFromString( 'manifest.json', (string) wp_json_encode( $man, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
		$zip->addFromString( 'questions.json', $qs );
		foreach ( $files as $n => $bin ) {
			$zip->addFromString( $n, $bin );
		}
		$zip->close();
		$bin = (string) file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		wp_delete_file( $tmp );
		return $bin;
	}

	/** Bring a packaged image into the media library (deduplicated by content hash). */
	public static function import_media( string $package, string $entry ): int {
		global $wpdb;
		$zip = new \ZipArchive();
		if ( ! preg_match( self::MEDIA_RE, $entry ) || true !== $zip->open( $package, \ZipArchive::RDONLY ) ) {
			return 0;
		}
		$bin = (string) $zip->getFromName( $entry );
		$zip->close();
		$sha = sha1( $bin );
		$id  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_ec_media_sha1' AND meta_value=%s LIMIT 1", $sha ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $id && get_post( $id ) ) {
			return $id;
		}
		if ( false === @getimagesizefromstring( $bin ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return 0;
		}
		$up = wp_upload_bits( 'question-' . substr( $sha, 0, 12 ) . '.' . pathinfo( $entry, PATHINFO_EXTENSION ), null, $bin );
		if ( ! empty( $up['error'] ) ) {
			return 0;
		}
		$ft = wp_check_filetype( $up['file'] );
		$id = wp_insert_attachment( array( 'post_mime_type' => $ft['type'], 'post_title' => 'Question image ' . substr( $sha, 0, 8 ), 'post_status' => 'inherit' ), $up['file'] );
		if ( ! $id || is_wp_error( $id ) ) {
			return 0;
		}
		require_once ABSPATH . 'wp-admin/includes/image.php';
		wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $up['file'] ) );
		update_post_meta( $id, '_ec_media_sha1', $sha );
		return (int) $id;
	}
}
