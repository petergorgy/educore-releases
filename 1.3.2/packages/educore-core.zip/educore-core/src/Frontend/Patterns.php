<?php
namespace EduCore\Core\Frontend;

defined( 'ABSPATH' ) || exit;

/**
 * Block patterns for About and DRAFT legal pages. Legal texts are templates for review by the
 * site owner and counsel — they are not legal advice and are created as drafts.
 */
final class Patterns {

	public static function register(): void {
		register_block_pattern_category( 'educore', array( 'label' => __( 'EduCore', 'educore-core' ) ) );
		$p = static fn( string $t ) => '<!-- wp:paragraph --><p>' . esc_html( $t ) . '</p><!-- /wp:paragraph -->';
		$h = static fn( string $t ) => '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html( $t ) . '</h2><!-- /wp:heading -->';
		$support = esc_html( (string) get_option( 'educore_support_email', 'support@educore.gorgy.org' ) );

		register_block_pattern(
			'educore/about',
			array(
				'title'      => __( 'About EduCore', 'educore-core' ),
				'categories' => array( 'educore' ),
				'content'    => $p( __( 'EduCore is a learning platform built to help students learn, practise and truly understand — one lesson at a time.', 'educore-core' ) )
					. $h( __( 'Our approach to learning', 'educore-core' ) )
					. $p( __( 'Every course is organised into short lessons with clear objectives, followed by practice and feedback. Progress is measured by what you complete and master, not by time spent on a page.', 'educore-core' ) )
					. $p( __( 'We start with the Egyptian secondary curriculum and design every course to be available in English, French and Arabic.', 'educore-core' ) )
					. $h( __( 'Part of GORGY.ORG', 'educore-core' ) )
					. '<!-- wp:paragraph --><p>' . wp_kses_post( __( 'EduCore is one of the educational initiatives of <a href="https://gorgy.org">GORGY.ORG</a>.', 'educore-core' ) ) . '</p><!-- /wp:paragraph -->',
			)
		);
		register_block_pattern(
			'educore/legal-privacy',
			array(
				'title'      => __( 'Privacy policy (draft template)', 'educore-core' ),
				'categories' => array( 'educore' ),
				'content'    => $h( __( 'Who we are', 'educore-core' ) ) . $p( __( 'EduCore (educore.gorgy.org) is operated as part of GORGY.ORG. Contact: ', 'educore-core' ) . $support )
					. $h( __( 'What we collect', 'educore-core' ) ) . $p( __( 'Account data (name, e-mail, password hash, age band), optional profile data (mobile number, academic year, programme, preferred language, profile picture), learning records (enrollments, lesson progress, notes, assessment answers, grades, certificates), consent records, and security logs in which IP addresses are stored only as one-way hashes.', 'educore-core' ) )
					. $h( __( 'Children and guardian consent', 'educore-core' ) ) . $p( __( 'Learners under 18 can only start learning after a parent or legal guardian confirms consent by e-mail. Leaderboards never include learners under 18.', 'educore-core' ) )
					. $h( __( 'Why we use it', 'educore-core' ) ) . $p( __( 'To provide courses, track progress, grade assessments, issue certificates, send service e-mails you can control, keep the platform secure, and meet legal obligations. We do not sell personal data.', 'educore-core' ) )
					. $h( __( 'How long we keep it', 'educore-core' ) ) . $p( __( '[Owner to confirm retention periods for learning records, security logs and consent evidence.]', 'educore-core' ) )
					. $h( __( 'Your rights', 'educore-core' ) ) . $p( __( 'You may request access to, correction of, export of, or deletion of your data, and withdraw consent, by writing to the support address above.', 'educore-core' ) )
					. $h( __( 'Hosting and transfers', 'educore-core' ) ) . $p( __( '[Owner to state the hosting location and any transfer of data outside Egypt, as required by Law No. 151 of 2020 and its Executive Regulations.]', 'educore-core' ) ),
			)
		);
		register_block_pattern(
			'educore/legal-terms',
			array(
				'title'      => __( 'Terms of service (draft template)', 'educore-core' ),
				'categories' => array( 'educore' ),
				'content'    => $h( __( 'Using EduCore', 'educore-core' ) ) . $p( __( 'You must provide accurate registration information and keep your password confidential. Learners under 18 need guardian consent.', 'educore-core' ) )
					. $h( __( 'Academic integrity', 'educore-core' ) ) . $p( __( 'Assessments must be completed by you alone. Sharing answers or attempting to bypass assessment rules may lead to invalidated results.', 'educore-core' ) )
					. $h( __( 'Content', 'educore-core' ) ) . $p( __( 'Course materials are for your personal learning and may not be redistributed.', 'educore-core' ) )
					. $h( __( 'Changes and contact', 'educore-core' ) ) . $p( __( '[Owner to complete: governing law, liability, termination, contact details.]', 'educore-core' ) ),
			)
		);
		register_block_pattern(
			'educore/legal-cookies',
			array(
				'title'      => __( 'Cookie information (draft template)', 'educore-core' ),
				'categories' => array( 'educore' ),
				'content'    => $p( __( 'EduCore uses only strictly necessary cookies: WordPress login cookies to keep you signed in, and the "educore_lang" cookie to remember your language. We do not use advertising or third-party tracking cookies. [Owner to update if analytics or embedded video providers are added.]', 'educore-core' ) ),
			)
		);
		register_block_pattern(
			'educore/legal-subscriptions',
			array(
				'title'      => __( 'Subscription policy (draft template)', 'educore-core' ),
				'categories' => array( 'educore' ),
				'content'    => $p( __( 'Paid courses and plans give access for the period shown at purchase. Access ends automatically when the period expires, a payment fails, or an order is cancelled or refunded. [Owner to complete: prices, renewal, refunds and cancellation rules, payment provider.]', 'educore-core' ) ),
			)
		);
	}
}
