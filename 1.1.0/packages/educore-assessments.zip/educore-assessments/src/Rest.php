<?php
namespace EduCore\Assessments;

use EduCore\Core\Access;
use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/** REST endpoints (namespace educore/v1). Student payloads never contain answer keys before review is allowed. */
final class Rest {

	public static function register(): void {
		add_action( 'educore/rest/routes', array( self::class, 'routes' ) );
	}

	private static function err( string $code, string $msg, int $status ): \WP_Error {
		return new \WP_Error( $code, $msg, array( 'status' => $status ) );
	}

	private static function id(): array {
		return array( 'type' => 'integer', 'required' => true, 'minimum' => 1, 'sanitize_callback' => 'absint' );
	}

	private static function throttle( string $bucket ): ?\WP_Error {
		return RateLimiter::hit( $bucket, 'u' . get_current_user_id() ) ? null : self::err( 'educore_throttled', __( 'Too many requests. Please slow down.', 'educore-assessments' ), 429 );
	}

	public static function owns_attempt( \WP_REST_Request $r ): bool {
		$at = Attempts::get( (int) $r['id'] );
		return is_user_logged_in() && $at && (int) $at['user_id'] === get_current_user_id();
	}

	private static function can_edit_course( int $course_id ): bool {
		return $course_id > 0 && current_user_can( 'ec_edit_course', $course_id );
	}

	public static function routes( string $ns ): void {
		$logged = static fn() => is_user_logged_in();
		$id     = array( 'id' => self::id() );

		// ---- learner ----
		register_rest_route( $ns, '/assessments/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => array( self::class, 'summary' ), 'permission_callback' => $logged, 'args' => $id ) );
		register_rest_route( $ns, '/assessments/(?P<id>\d+)/attempts', array( 'methods' => 'POST', 'callback' => array( self::class, 'start' ), 'permission_callback' => $logged, 'args' => $id ) );
		register_rest_route( $ns, '/attempts/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => static fn( $r ) => new \WP_REST_Response( Attempts::student_view( (int) $r['id'] ) ), 'permission_callback' => array( self::class, 'owns_attempt' ), 'args' => $id ) );
		register_rest_route( $ns, '/attempts/(?P<id>\d+)/answers', array( 'methods' => 'POST', 'callback' => array( self::class, 'save' ), 'permission_callback' => array( self::class, 'owns_attempt' ), 'args' => array_merge( $id, array( 'answers' => array( 'type' => 'object', 'required' => true ) ) ) ) );
		register_rest_route( $ns, '/attempts/(?P<id>\d+)/submit', array( 'methods' => 'POST', 'callback' => array( self::class, 'submit' ), 'permission_callback' => array( self::class, 'owns_attempt' ), 'args' => $id ) );
		register_rest_route( $ns, '/lessons/(?P<id>\d+)/practice', array( 'methods' => 'GET', 'callback' => static fn( $r ) => new \WP_REST_Response( Practice::lesson_items( get_current_user_id(), (int) $r['id'] ) ), 'permission_callback' => static fn( $r ) => is_user_logged_in() && Access::can_view_lesson( get_current_user_id(), (int) $r['id'] ), 'args' => $id ) );
		register_rest_route( $ns, '/practice/(?P<id>\d+)', array( 'methods' => 'POST', 'callback' => array( self::class, 'practice' ), 'permission_callback' => $logged, 'args' => array_merge( $id, array( 'answer' => array( 'required' => false ) ) ) ) );

		// ---- staff: question bank ----
		register_rest_route(
			$ns,
			'/questions',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( self::class, 'list_questions' ),
					'permission_callback' => static fn( $r ) => current_user_can( 'ec_manage_question_bank' ) && self::can_edit_course( (int) $r['course_id'] ),
					'args'                => array( 'course_id' => self::id(), 'lesson_id' => array( 'type' => 'integer' ), 'type' => array( 'type' => 'string' ), 'status' => array( 'type' => 'string' ), 'search' => array( 'type' => 'string' ), 'page' => array( 'type' => 'integer', 'default' => 1 ) ),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( self::class, 'save_question' ),
					'permission_callback' => static fn( $r ) => current_user_can( 'ec_manage_question_bank' ) && self::can_edit_course( (int) $r['course_id'] ),
					'args'                => array( 'course_id' => self::id() ),
				),
			)
		);
		$q_perm = static function ( \WP_REST_Request $r ) {
			$q = Questions::get( (int) $r['id'] );
			return $q && current_user_can( 'ec_manage_question_bank' ) && self::can_edit_course( (int) $q['course_id'] );
		};
		register_rest_route(
			$ns,
			'/questions/(?P<id>\d+)',
			array(
				array( 'methods' => 'GET', 'callback' => static fn( $r ) => new \WP_REST_Response( array_merge( Questions::full( (int) $r['id'] ), array( 'history' => Questions::history( (int) $r['id'] ) ) ) ), 'permission_callback' => $q_perm, 'args' => $id ),
				array( 'methods' => 'PUT', 'callback' => array( self::class, 'save_question' ), 'permission_callback' => $q_perm, 'args' => $id ),
			)
		);
		register_rest_route( $ns, '/questions/(?P<id>\d+)/status', array( 'methods' => 'POST', 'callback' => array( self::class, 'question_status' ), 'permission_callback' => $q_perm, 'args' => array_merge( $id, array( 'status' => array( 'type' => 'string', 'enum' => Questions::STATUSES, 'required' => true ) ) ) ) );
		register_rest_route(
			$ns,
			'/courses/(?P<id>\d+)/questions/export',
			array(
				'methods'             => 'GET',
				'callback'            => static fn( $r ) => new \WP_REST_Response( 'csv' === $r['format'] ? array( 'csv' => ImportExport::export_csv( (int) $r['id'] ) ) : ImportExport::export_structured( (int) $r['id'] ) ),
				'permission_callback' => static fn( $r ) => current_user_can( 'ec_manage_question_bank' ) && self::can_edit_course( (int) $r['id'] ),
				'args'                => array_merge( $id, array( 'format' => array( 'type' => 'string', 'enum' => array( 'json', 'csv' ), 'default' => 'json' ) ) ),
			)
		);
		register_rest_route(
			$ns,
			'/courses/(?P<id>\d+)/questions/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'import' ),
				'permission_callback' => static fn( $r ) => current_user_can( 'ec_manage_question_bank' ) && self::can_edit_course( (int) $r['id'] ),
				'args'                => array_merge( $id, array( 'format' => array( 'type' => 'string', 'enum' => array( 'json', 'csv' ), 'required' => true ), 'data' => array( 'required' => true ) ) ),
			)
		);
		register_rest_route( $ns, '/courses/(?P<id>\d+)/questions/coverage', array( 'methods' => 'GET', 'callback' => static fn( $r ) => new \WP_REST_Response( Questions::coverage( (int) $r['id'] ) ), 'permission_callback' => static fn( $r ) => self::can_edit_course( (int) $r['id'] ), 'args' => $id ) );

		// ---- staff: assessments ----
		register_rest_route(
			$ns,
			'/courses/(?P<id>\d+)/assessments',
			array(
				array( 'methods' => 'GET', 'callback' => static fn( $r ) => new \WP_REST_Response( array_map( static fn( $a ) => Assessments::for_api( $a ) + array( 'pools' => Assessments::pools( (int) $a['id'] ) ), Assessments::for_course( (int) $r['id'], Assessments::STATUSES ) ) ), 'permission_callback' => static fn( $r ) => self::can_edit_course( (int) $r['id'] ), 'args' => $id ),
				array( 'methods' => 'POST', 'callback' => array( self::class, 'save_assessment' ), 'permission_callback' => static fn( $r ) => current_user_can( 'ec_manage_assessments' ) && self::can_edit_course( (int) $r['id'] ), 'args' => $id ),
			)
		);
		register_rest_route(
			$ns,
			'/assessments/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( self::class, 'save_assessment' ),
				'permission_callback' => static function ( $r ) {
					$a = Assessments::get( (int) $r['id'] );
					return $a && current_user_can( 'ec_manage_assessments' ) && self::can_edit_course( (int) $a['course_id'] );
				},
				'args'                => $id,
			)
		);
		register_rest_route(
			$ns,
			'/assessments/(?P<id>\d+)/release',
			array(
				'methods'             => 'POST',
				'callback'            => static fn( $r ) => new \WP_REST_Response( array( 'released' => Grading::release_assessment( (int) $r['id'] ) ) ),
				'permission_callback' => static function ( $r ) {
					$a = Assessments::get( (int) $r['id'] );
					return $a && current_user_can( 'ec_release_grades' ) && current_user_can( 'ec_grade_course', (int) $a['course_id'] );
				},
				'args'                => $id,
			)
		);

		// ---- staff: grading ----
		register_rest_route( $ns, '/grading/queue', array( 'methods' => 'GET', 'callback' => array( self::class, 'queue' ), 'permission_callback' => static fn() => current_user_can( 'ec_grade_submissions' ), 'args' => array( 'course_id' => array( 'type' => 'integer', 'default' => 0 ) ) ) );
		register_rest_route(
			$ns,
			'/responses/(?P<id>\d+)/grade',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'grade' ),
				'permission_callback' => static fn( $r ) => current_user_can( 'ec_grade_submissions' ) && current_user_can( 'ec_grade_course', Grading::course_of_response( (int) $r['id'] ) ),
				'args'                => array_merge( $id, array( 'score' => array( 'type' => 'number', 'required' => true ), 'feedback' => array( 'type' => 'string', 'default' => '' ), 'rubric' => array( 'type' => 'array', 'default' => array() ) ) ),
			)
		);
		$att_staff = static fn( $r ) => current_user_can( 'ec_grade_course', Grading::course_of_attempt( (int) $r['id'] ) );
		register_rest_route( $ns, '/staff/attempts/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => array( self::class, 'staff_attempt' ), 'permission_callback' => $att_staff, 'args' => $id ) );
		register_rest_route(
			$ns,
			'/attempts/(?P<id>\d+)/release',
			array(
				'methods'             => 'POST',
				'callback'            => static function ( $r ) {
					$res = Attempts::release( (int) $r['id'] );
					return is_wp_error( $res ) ? $res : new \WP_REST_Response( array( 'released' => true ) );
				},
				'permission_callback' => static fn( $r ) => current_user_can( 'ec_release_grades' ) && current_user_can( 'ec_grade_course', Grading::course_of_attempt( (int) $r['id'] ) ),
				'args'                => $id,
			)
		);
	}

	/* ---------- learner callbacks ---------- */

	public static function summary( \WP_REST_Request $r ) {
		$a   = Assessments::get( (int) $r['id'] );
		$uid = get_current_user_id();
		if ( ! $a || 'published' !== $a['status'] || ! Access::can_access_course( $uid, (int) $a['course_id'] ) ) {
			return self::err( 'educore_not_found', __( 'Assessment not found.', 'educore-assessments' ), 404 );
		}
		return new \WP_REST_Response( Frontend::summary_data( $a, $uid ) );
	}

	public static function start( \WP_REST_Request $r ) {
		$e = self::throttle( 'attempt' );
		if ( $e ) {
			return $e;
		}
		$id = Attempts::start( (int) $r['id'], get_current_user_id() );
		return is_wp_error( $id ) ? $id : new \WP_REST_Response( Attempts::student_view( $id ), 201 );
	}

	public static function save( \WP_REST_Request $r ) {
		$e = self::throttle( 'autosave' );
		if ( $e ) {
			return $e;
		}
		$res = Attempts::save( (int) $r['id'], get_current_user_id(), (array) $r['answers'] );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$at = Attempts::get( (int) $r['id'] );
		return new \WP_REST_Response( array( 'saved' => true, 'seconds_left' => $at['deadline_at'] ? max( 0, strtotime( $at['deadline_at'] . ' UTC' ) - time() ) : null ) );
	}

	public static function submit( \WP_REST_Request $r ) {
		$e = self::throttle( 'attempt' );
		if ( $e ) {
			return $e;
		}
		if ( $r->get_param( 'answers' ) ) {
			$saved = Attempts::save( (int) $r['id'], get_current_user_id(), (array) $r['answers'] );
			if ( is_wp_error( $saved ) && 'educore_time_up' !== $saved->get_error_code() ) {
				return $saved;
			}
		}
		$at = Attempts::get( (int) $r['id'] );
		if ( 'open' === $at['state'] ) {
			$res = Attempts::submit( (int) $r['id'], Attempts::past_grace( $at ) );
			if ( is_wp_error( $res ) ) {
				return $res;
			}
		}
		return new \WP_REST_Response( Attempts::student_view( (int) $r['id'] ) );
	}

	public static function practice( \WP_REST_Request $r ) {
		$e = self::throttle( 'attempt' );
		if ( $e ) {
			return $e;
		}
		$res = Practice::check( get_current_user_id(), (int) $r['id'], $r->get_param( 'answer' ) );
		return is_wp_error( $res ) ? $res : new \WP_REST_Response( $res );
	}

	/* ---------- staff callbacks ---------- */

	public static function list_questions( \WP_REST_Request $r ): \WP_REST_Response {
		$res  = Questions::search( $r->get_params() );
		$resp = new \WP_REST_Response( $res['rows'] );
		$resp->header( 'X-WP-Total', (string) $res['total'] );
		return $resp;
	}

	/** Accepts either structured (payload/key) or authoring fields (options/correct…). */
	public static function save_question( \WP_REST_Request $r ) {
		$p    = $r->get_json_params() ?: $r->get_params();
		$id   = (int) ( $r['id'] ?? 0 );
		$data = $p;
		if ( ! isset( $p['key'] ) ) {
			$built = Types::from_authoring( $p );
			if ( is_wp_error( $built ) ) {
				return $built;
			}
			$data['payload'] = $built['payload'];
			$data['key']     = $built['key'];
		}
		if ( isset( $data['status'] ) && 'published' === $data['status'] ) {
			$course = $id ? (int) Questions::get( $id )['course_id'] : (int) ( $p['course_id'] ?? 0 );
			if ( ! Questions::can_publish( get_current_user_id(), $course ) ) {
				$data['status'] = 'review';
			}
		}
		$res = Questions::save( $data, $id );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		if ( isset( $p['rubric'] ) && is_array( $p['rubric'] ) ) {
			Grading::set_rubric( $res, $p['rubric'] );
		}
		$q   = Questions::get( $res );
		$dup = Questions::duplicates( (int) $q['course_id'], $q['dedupe_hash'], $res );
		return new \WP_REST_Response( array( 'id' => $res, 'duplicates' => $dup ), $id ? 200 : 201 );
	}

	public static function question_status( \WP_REST_Request $r ) {
		$res = Questions::set_status( (int) $r['id'], (string) $r['status'] );
		return is_wp_error( $res ) ? $res : new \WP_REST_Response( array( 'status' => $r['status'] ) );
	}

	public static function import( \WP_REST_Request $r ) {
		$data = $r['data'];
		if ( 'csv' === $r['format'] ) {
			$rows       = ImportExport::parse_csv( (string) $data );
			$structured = false;
		} else {
			$rows       = is_string( $data ) ? (array) json_decode( $data, true ) : (array) $data;
			$structured = true;
		}
		return new \WP_REST_Response( ImportExport::import_rows( (int) $r['id'], $rows, $structured ) );
	}

	public static function save_assessment( \WP_REST_Request $r ) {
		$p      = $r->get_json_params() ?: $r->get_params();
		$route  = $r->get_route();
		$is_new = false !== strpos( $route, '/courses/' );
		if ( $is_new ) {
			$p['course_id'] = (int) $r['id'];
		}
		if ( 'published' === ( $p['status'] ?? '' ) && ! current_user_can( 'ec_publish_courses' ) && ! \EduCore\Core\Staff::has_role( get_current_user_id(), (int) ( $is_new ? $r['id'] : Assessments::get( (int) $r['id'] )['course_id'] ), array( 'lead' ) ) ) {
			return self::err( 'educore_forbidden', __( 'Only a lead instructor or academic manager can publish assessments.', 'educore-assessments' ), 403 );
		}
		$res = Assessments::save( $p, $is_new ? 0 : (int) $r['id'] );
		return is_wp_error( $res ) ? $res : new \WP_REST_Response( array( 'id' => $res ), $is_new ? 201 : 200 );
	}

	public static function queue( \WP_REST_Request $r ): \WP_REST_Response {
		$rows = array();
		foreach ( Grading::queue( get_current_user_id(), (int) $r['course_id'] ) as $row ) {
			$ver    = Questions::version( (int) $row['question_version_id'] );
			$rows[] = array(
				'response_id'  => (int) $row['response_id'],
				'attempt_id'   => (int) $row['attempt_id'],
				'assessment'   => $row['title'],
				'course_id'    => (int) $row['course_id'],
				'student'      => get_userdata( (int) $row['user_id'] )->display_name ?? '',
				'submitted_at' => $row['submitted_at'],
				'points'       => (float) $row['points'],
				'stem'         => $ver['stem'],
				'model_answer' => (string) ( $ver['answer_key']['model_answer'] ?? '' ),
				'rubric'       => Grading::rubric( (int) $ver['question_id'] ),
				'answer'       => json_decode( (string) $row['answer'], true ),
			);
		}
		return new \WP_REST_Response( $rows );
	}

	public static function grade( \WP_REST_Request $r ) {
		$res = Grading::grade( (int) $r['id'], (float) $r['score'], (string) $r['feedback'], (array) $r['rubric'] );
		return is_wp_error( $res ) ? $res : new \WP_REST_Response( array( 'graded' => true ) );
	}

	public static function staff_attempt( \WP_REST_Request $r ): \WP_REST_Response {
		$at    = Attempts::get( (int) $r['id'] );
		$items = array();
		foreach ( Attempts::items( (int) $r['id'] ) as $i ) {
			$ver     = Questions::version( (int) $i['question_version_id'] );
			$items[] = array(
				'item_id'      => (int) $i['id'],
				'response_id'  => (int) $i['response_id'],
				'type'         => Attempts::type_of( $ver ),
				'stem'         => $ver['stem'],
				'key'          => $ver['answer_key'],
				'answer'       => null === $i['answer'] ? null : json_decode( (string) $i['answer'], true ),
				'points'       => (float) $i['points'],
				'final_score'  => null === $i['final_score'] ? null : (float) $i['final_score'],
				'needs_grading'=> (bool) $i['needs_grading'],
				'feedback'     => (string) $i['feedback'],
			);
		}
		return new \WP_REST_Response( array( 'attempt' => $at, 'items' => $items ) );
	}
}
