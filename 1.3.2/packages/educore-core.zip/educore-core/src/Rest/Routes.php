<?php
namespace EduCore\Core\Rest;

use EduCore\Core\Access;

defined( 'ABSPATH' ) || exit;

final class Routes {
	public const NS = 'educore/v1';

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
		add_filter( 'rest_post_dispatch', array( self::class, 'private_headers' ), 10, 3 );
	}

	public static function routes(): void {
		PublicController::routes();
		LearnerController::routes();
		StaffController::routes();
		AdminController::routes();
		/** Other packages register their routes in the same namespace. */
		do_action( 'educore/rest/routes', self::NS );
	}

	/** Every EduCore REST response is private / non-cacheable except the anonymous public catalogue. */
	public static function private_headers( $response, $server, $request ) {
		$route = $request->get_route();
		if ( 0 === strpos( $route, '/' . self::NS ) && $response instanceof \WP_REST_Response ) {
			$public = is_user_logged_in() ? false : (bool) preg_match( '#^/educore/v1/(courses(/\d+)?|certificates/verify/[A-Za-z0-9-]+)$#', $route );
			$response->header( 'Cache-Control', $public ? 'public, max-age=300' : 'private, no-store, max-age=0' );
			if ( ! $public ) {
				$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
			}
		}
		return $response;
	}

	/** Helpers for controllers. */
	public static function id_arg(): array {
		return array( 'type' => 'integer', 'required' => true, 'minimum' => 1, 'sanitize_callback' => 'absint' );
	}

	public static function logged_in(): bool {
		return is_user_logged_in();
	}

	public static function error( string $code, string $message, int $status ): \WP_Error {
		return new \WP_Error( $code, $message, array( 'status' => $status ) );
	}

	public static function throttle( string $bucket ): ?\WP_Error {
		if ( ! \EduCore\Core\RateLimiter::hit( $bucket, 'u' . get_current_user_id() . '|' . \EduCore\Core\RateLimiter::client_key() ) ) {
			return self::error( 'educore_throttled', __( 'Too many requests. Please slow down.', 'educore-core' ), 429 );
		}
		return null;
	}
}
