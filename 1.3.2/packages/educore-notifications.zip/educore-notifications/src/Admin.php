<?php
namespace EduCore\Notifications;

use EduCore\Core\Audit;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

final class Admin {

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 20 );
		add_action( 'admin_init', array( self::class, 'handle' ) );
		add_filter( 'educore/admin/overview_tiles', array( self::class, 'tiles' ) );
	}

	public static function menu(): void {
		add_submenu_page( 'educore', __( 'Notifications', 'educore-notifications' ), __( 'Notifications', 'educore-notifications' ), 'ec_manage_settings', 'educore-notifications', array( self::class, 'page' ) );
	}

	public static function tiles( array $tiles ): array {
		$c = Queue::counts( 7 );
		$tiles[ __( 'E-mail failures (7 days)', 'educore-notifications' ) ] = number_format_i18n( $c['failed'] );
		$tiles[ __( 'E-mails queued', 'educore-notifications' ) ]           = number_format_i18n( $c['queued'] + $c['sending'] );
		return $tiles;
	}

	private static function nonce_field( string $action ): string {
		return wp_nonce_field( 'educore_notif_' . $action, '_ecnonce', true, false ) . '<input type="hidden" name="educore_notif_action" value="' . esc_attr( $action ) . '">';
	}

	public static function page(): void {
		global $wpdb;
		if ( ! current_user_can( 'ec_manage_settings' ) ) {
			wp_die( '', 403 );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filters.
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$event  = isset( $_GET['event'] ) ? sanitize_key( wp_unslash( $_GET['event'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable
		echo '<div class="wrap ec-admin"><h1>' . esc_html__( 'Notifications', 'educore-notifications' ) . '</h1>';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ec_done'] ) ) {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Done.', 'educore-notifications' ) . '</p></div>';
		}
		$c = Queue::counts( 7 );
		echo '<p>' . esc_html__( 'Last 7 days:', 'educore-notifications' ) . ' ';
		foreach ( $c as $s => $n ) {
			echo '<span class="ec-chip">' . esc_html( $s . ': ' . $n ) . '</span> ';
		}
		echo '</p><p class="description">' . esc_html__( '“accepted_by_mta” means the mail server accepted the message. It does not prove the message reached the inbox.', 'educore-notifications' ) . '</p>';

		echo '<form method="get"><input type="hidden" name="page" value="educore-notifications"><select name="status"><option value="">' . esc_html__( 'All statuses', 'educore-notifications' ) . '</option>';
		foreach ( Queue::STATUSES as $s ) {
			echo '<option' . selected( $status, $s, false ) . '>' . esc_html( $s ) . '</option>';
		}
		echo '</select> <select name="event"><option value="">' . esc_html__( 'All events', 'educore-notifications' ) . '</option>';
		foreach ( Templates::events() as $e ) {
			echo '<option' . selected( $event, $e, false ) . '>' . esc_html( $e ) . '</option>';
		}
		echo '</select> <button class="button">' . esc_html__( 'Filter', 'educore-notifications' ) . '</button></form>';

		$where  = array( '1=1' );
		$params = array();
		if ( in_array( $status, Queue::STATUSES, true ) ) {
			$where[]  = 'status=%s';
			$params[] = $status;
		}
		if ( in_array( $event, Templates::events(), true ) ) {
			$where[]  = 'event=%s';
			$params[] = $event;
		}
		$params[] = 50;
		$params[] = ( $paged - 1 ) * 50;
		$rows     = $wpdb->get_results( $wpdb->prepare( 'SELECT id,event,recipient_email,lang,subject,status,tries,next_try_at,last_error,created_at,sent_at FROM ' . Schema::table( 'notification_jobs' ) . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT %d OFFSET %d', $params ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		echo '<p class="description">' . esc_html__( 'Status meaning: queued = waiting; sending = handed to the mailer now; accepted_by_mta = the mail server accepted the message (this does not prove inbox delivery — confirm with test mailboxes or your mail provider’s delivery reports); failed = all retries used; cancelled = stopped by an administrator.', 'educore-notifications' ) . '</p>';
		echo '<table class="widefat striped"><thead><tr><th>#</th><th>' . esc_html__( 'Event', 'educore-notifications' ) . '</th><th>' . esc_html__( 'Recipient', 'educore-notifications' ) . '</th><th>' . esc_html__( 'Subject', 'educore-notifications' ) . '</th><th>' . esc_html__( 'Status', 'educore-notifications' ) . '</th><th>' . esc_html__( 'Tries', 'educore-notifications' ) . '</th><th>' . esc_html__( 'Created / sent (UTC)', 'educore-notifications' ) . '</th><th>' . esc_html__( 'Last error', 'educore-notifications' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><td>' . esc_html( $r['id'] ) . '</td><td><code>' . esc_html( $r['event'] ) . '</code> ' . esc_html( $r['lang'] ) . '</td><td>' . esc_html( $r['recipient_email'] ) . '</td><td>' . esc_html( $r['subject'] ) . '</td><td>' . esc_html( $r['status'] ) . '</td><td>' . esc_html( $r['tries'] ) . '</td><td>' . esc_html( $r['created_at'] . ' / ' . ( $r['sent_at'] ?: '—' ) ) . '</td><td>' . esc_html( $r['last_error'] ) . '</td><td>';
			if ( in_array( $r['status'], array( 'failed', 'cancelled' ), true ) ) {
				echo '<form method="post">' . self::nonce_field( 'retry' ) . '<input type="hidden" name="id" value="' . esc_attr( $r['id'] ) . '"><button class="button button-small">' . esc_html__( 'Retry', 'educore-notifications' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
			} elseif ( 'queued' === $r['status'] ) {
				echo '<form method="post">' . self::nonce_field( 'cancel' ) . '<input type="hidden" name="id" value="' . esc_attr( $r['id'] ) . '"><button class="button button-small">' . esc_html__( 'Cancel', 'educore-notifications' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</td></tr>';
		}
		echo '</tbody></table><p><a class="button" href="' . esc_url( add_query_arg( 'paged', $paged + 1 ) ) . '">' . esc_html__( 'Older', 'educore-notifications' ) . '</a></p>';

		echo '<h2>' . esc_html__( 'Mail settings', 'educore-notifications' ) . '</h2><form method="post">' . self::nonce_field( 'settings' ) . '<table class="form-table"><tbody>'; // phpcs:ignore WordPress.Security.EscapeOutput
		$o    = static fn( $k, $d = '' ) => (string) get_option( $k, $d );
		$rows = array(
			array( __( 'From address', 'educore-notifications' ), '<input type="email" class="regular-text" name="educore_mail_from" value="' . esc_attr( $o( 'educore_mail_from', 'support@educore.gorgy.org' ) ) . '">' ),
			array( __( 'From name', 'educore-notifications' ), '<input class="regular-text" name="educore_mail_from_name" value="' . esc_attr( $o( 'educore_mail_from_name', 'EduCore' ) ) . '">' ),
			array( __( 'SMTP host (empty = PHP mail)', 'educore-notifications' ), '<input class="regular-text" name="educore_smtp_host" value="' . esc_attr( $o( 'educore_smtp_host' ) ) . '" placeholder="mail.educore.gorgy.org">' ),
			array( __( 'SMTP port', 'educore-notifications' ), '<input type="number" name="educore_smtp_port" value="' . esc_attr( $o( 'educore_smtp_port', '587' ) ) . '">' ),
			array( __( 'Encryption', 'educore-notifications' ), '<select name="educore_smtp_encryption"><option value="tls"' . selected( $o( 'educore_smtp_encryption', 'tls' ), 'tls', false ) . '>STARTTLS</option><option value="ssl"' . selected( $o( 'educore_smtp_encryption', 'tls' ), 'ssl', false ) . '>SSL/TLS</option><option value="none"' . selected( $o( 'educore_smtp_encryption', 'tls' ), 'none', false ) . '>' . esc_html__( 'None', 'educore-notifications' ) . '</option></select>' ),
			array( __( 'SMTP username', 'educore-notifications' ), '<input class="regular-text" name="educore_smtp_user" autocomplete="off" value="' . esc_attr( $o( 'educore_smtp_user' ) ) . '">' ),
			array( __( 'SMTP password', 'educore-notifications' ), '<input type="password" class="regular-text" name="educore_smtp_pass" autocomplete="new-password" value="" placeholder="' . esc_attr( '' !== Mailer::password() ? __( '(saved — leave empty to keep)', 'educore-notifications' ) : '' ) . '"> <label><input type="checkbox" name="educore_smtp_pass_clear" value="1"> ' . esc_html__( 'Clear saved password', 'educore-notifications' ) . '</label>' ),
		);
		foreach ( $rows as $r ) {
			echo '<tr><th>' . esc_html( $r[0] ) . '</th><td>' . $r[1] . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
		echo '</tbody></table><button class="button button-primary">' . esc_html__( 'Save', 'educore-notifications' ) . '</button></form>';
		echo '<h2>' . esc_html__( 'Send a test e-mail', 'educore-notifications' ) . '</h2><form method="post">' . self::nonce_field( 'test' ) . '<input type="email" name="to" required value="' . esc_attr( wp_get_current_user()->user_email ) . '"> <button class="button">' . esc_html__( 'Queue and send now', 'educore-notifications' ) . '</button></form></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function handle(): void {
		if ( empty( $_POST['educore_notif_action'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['educore_notif_action'] ) );
		check_admin_referer( 'educore_notif_' . $action, '_ecnonce' );
		if ( ! current_user_can( 'ec_manage_settings' ) ) {
			wp_die( '', 403 );
		}
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		switch ( $action ) {
			case 'retry':
				Queue::retry( $id );
				break;
			case 'cancel':
				Queue::cancel( $id );
				break;
			case 'settings':
				foreach ( array( 'educore_mail_from' => 'sanitize_email', 'educore_mail_from_name' => 'sanitize_text_field', 'educore_smtp_host' => 'sanitize_text_field', 'educore_smtp_user' => 'sanitize_text_field', 'educore_smtp_encryption' => 'sanitize_key' ) as $k => $fn ) {
					update_option( $k, call_user_func( $fn, isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				}
				update_option( 'educore_smtp_port', isset( $_POST['educore_smtp_port'] ) ? absint( $_POST['educore_smtp_port'] ) : 587 );
				if ( ! empty( $_POST['educore_smtp_pass_clear'] ) ) {
					Mailer::set_password( '' );
				} elseif ( ! empty( $_POST['educore_smtp_pass'] ) ) {
					Mailer::set_password( (string) wp_unslash( $_POST['educore_smtp_pass'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- passwords are not sanitised.
				}
				Audit::log( 'notifications.settings_updated', 'settings', 0, array( 'smtp_host' => get_option( 'educore_smtp_host' ) ) );
				break;
			case 'test':
				$to = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : '';
				Queue::enqueue( 'test', $to, array(), 'test:' . microtime( true ), array( 'max_tries' => 1 ) );
				Queue::process();
				break;
		}
		wp_safe_redirect( add_query_arg( 'ec_done', 1, wp_get_referer() ?: admin_url( 'admin.php?page=educore-notifications' ) ) );
		exit;
	}
}
