<?php
namespace EduCore\Workspace;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Enrollment;
use EduCore\Core\RateLimiter;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Course feedback (gap F02): enrolled learners who have completed at least one lesson rate a course (1–5) with an
 * optional comment, and can change it later. Staff see aggregates and comments; comments are anonymous to the
 * course team and named only for academic managers, who can hide an inappropriate comment (the rating still counts).
 * Nothing is public.
 */
final class Feedback {
	public const MIN_COMPLETED = 1;

	public static function register(): void {
		add_filter( 'educore/course/after_details', array( self::class, 'learner_box' ), 20, 2 );
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	private static function t(): string {
		return Schema::table( 'ws_feedback' );
	}

	public static function completed_lessons( int $uid, int $course_id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Schema::table( 'lesson_progress' ) . " WHERE user_id=%d AND course_id=%d AND state='completed'", $uid, $course_id ) );
	}

	public static function can_give( int $uid, int $course_id ): bool {
		return $uid > 0 && Content::is_course( $course_id ) && Enrollment::is_enrolled( $uid, $course_id, false ) && self::completed_lessons( $uid, $course_id ) >= self::MIN_COMPLETED;
	}

	public static function can_read( int $uid, int $course_id ): bool {
		return $uid > 0 && ( user_can( $uid, 'ec_manage_all_courses' ) || user_can( $uid, 'ec_view_course_records', $course_id ) );
	}

	public static function mine( int $uid, int $course_id ): ?array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t() . ' WHERE course_id=%d AND user_id=%d', $course_id, $uid ), ARRAY_A );
		return $r ?: null;
	}

	/** @return true|\WP_Error */
	public static function submit( int $uid, int $course_id, int $rating, string $comment ) {
		global $wpdb;
		if ( ! self::can_give( $uid, $course_id ) ) {
			return new \WP_Error( 'ec_feedback_forbidden', __( 'You can rate a course after completing at least one of its lessons.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		if ( $rating < 1 || $rating > 5 ) {
			return new \WP_Error( 'ec_feedback_rating', __( 'Choose a rating from 1 to 5.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'rating' => 'invalid' ) ) );
		}
		$comment = mb_substr( trim( sanitize_textarea_field( $comment ) ), 0, 2000 );
		$now     = Schema::now();
		$cur     = self::mine( $uid, $course_id );
		if ( $cur ) {
			$wpdb->update( self::t(), array( 'rating' => $rating, 'comment' => $comment, 'status' => 'visible', 'updated_at' => $now ), array( 'id' => (int) $cur['id'] ) );
		} else {
			$wpdb->insert( self::t(), array( 'course_id' => $course_id, 'user_id' => $uid, 'rating' => $rating, 'comment' => $comment, 'status' => 'visible', 'created_at' => $now, 'updated_at' => $now ) );
		}
		Audit::log( 'feedback.submitted', 'course', $course_id, array( 'rating' => $rating, 'updated' => (bool) $cur ) );
		return true;
	}

	/** @return true|\WP_Error */
	public static function moderate( int $uid, int $id, string $status ) {
		global $wpdb;
		if ( ! user_can( $uid, 'ec_manage_all_courses' ) ) {
			return new \WP_Error( 'ec_feedback_forbidden', __( 'Only academic managers can moderate feedback.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$st = 'hidden' === $status ? 'hidden' : 'visible';
		if ( ! $wpdb->update( self::t(), array( 'status' => $st ), array( 'id' => $id ) ) && ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t() . ' WHERE id=%d', $id ) ) ) {
			return new \WP_Error( 'ec_feedback_missing', __( 'Feedback not found.', 'educore-workspace' ), array( 'status' => 404 ) );
		}
		Audit::log( 'feedback.' . $st, 'feedback', $id );
		return true;
	}

	/** @return array{count:int,average:?float,dist:array<int,int>} */
	public static function summary( int $course_id ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT rating, COUNT(*) n FROM ' . self::t() . ' WHERE course_id=%d GROUP BY rating', $course_id ), ARRAY_A ) ?: array();
		$dist = array_fill( 1, 5, 0 );
		$sum  = 0;
		$n    = 0;
		foreach ( $rows as $r ) {
			$dist[ (int) $r['rating'] ] = (int) $r['n'];
			$sum                       += (int) $r['rating'] * (int) $r['n'];
			$n                         += (int) $r['n'];
		}
		return array( 'count' => $n, 'average' => $n ? round( $sum / $n, 2 ) : null, 'dist' => $dist );
	}

	public static function comments( int $course_id, bool $include_hidden ): array {
		global $wpdb;
		$sql = 'SELECT * FROM ' . self::t() . " WHERE course_id=%d AND comment<>''" . ( $include_hidden ? '' : " AND status='visible'" ) . ' ORDER BY updated_at DESC LIMIT 100';
		return $wpdb->get_results( $wpdb->prepare( $sql, $course_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/* ---------- learner box on the course page ---------- */

	public static function learner_box( $html, $course_id ) {
		$uid = get_current_user_id();
		if ( ! $uid || ! Enrollment::is_enrolled( $uid, (int) $course_id, false ) ) {
			return $html;
		}
		$mine = self::mine( $uid, (int) $course_id );
		$o    = '<section class="ec-card ec-feedback" aria-labelledby="ec-fb-h"><h2 id="ec-fb-h">' . esc_html__( 'Your feedback on this course', 'educore-workspace' ) . '</h2>';
		if ( ! self::can_give( $uid, (int) $course_id ) ) {
			return $html . $o . '<p class="ec-muted">' . esc_html__( 'You can rate this course after completing your first lesson.', 'educore-workspace' ) . '</p></section>';
		}
		$o .= '<form class="ec-feedback__form" data-ec-feedback="' . (int) $course_id . '"><fieldset><legend>' . esc_html__( 'Rating', 'educore-workspace' ) . '</legend><div class="ec-feedback__stars" style="display:flex;flex-wrap:wrap;gap:.75rem 1.25rem">';
		for ( $i = 1; $i <= 5; $i++ ) {
			/* translators: %d: number of stars */
			$o .= '<label style="display:inline-flex;align-items:center;gap:.35rem;min-block-size:44px"><input type="radio" name="rating" value="' . $i . '" required' . checked( (int) ( $mine['rating'] ?? 0 ), $i, false ) . '> <span>' . esc_html( sprintf( _n( '%d star', '%d stars', $i, 'educore-workspace' ), $i ) ) . '</span></label>';
		}
		$o .= '</div></fieldset><label for="ec-fb-c" style="display:block;margin-block:.75rem .35rem">' . esc_html__( 'Comment (optional) — shared with the teaching team without your name', 'educore-workspace' ) . '</label><textarea id="ec-fb-c" name="comment" rows="3" maxlength="2000" style="inline-size:100%">' . esc_textarea( (string) ( $mine['comment'] ?? '' ) ) . '</textarea>';
		$o .= '<p><button class="ec-btn ec-btn--primary" type="submit">' . esc_html( $mine ? __( 'Update my feedback', 'educore-workspace' ) : __( 'Send feedback', 'educore-workspace' ) ) . '</button> <span class="ec-feedback__status" role="status" aria-live="polite"></span></p></form>';
		$o .= '<script>(function(){var f=document.querySelector(\'form[data-ec-feedback="' . (int) $course_id . '"]\');if(!f||f.dataset.b){return;}f.dataset.b=1;f.addEventListener("submit",function(e){e.preventDefault();var s=f.querySelector(".ec-feedback__status"),r=f.querySelector("input[name=rating]:checked");if(!r){s.textContent=' . wp_json_encode( __( 'Choose a rating first.', 'educore-workspace' ) ) . ';return;}fetch(' . wp_json_encode( esc_url_raw( rest_url( 'educore/v1/feedback/' . (int) $course_id ) ) ) . ',{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json","X-WP-Nonce":' . wp_json_encode( wp_create_nonce( 'wp_rest' ) ) . '},body:JSON.stringify({rating:+r.value,comment:f.comment.value})}).then(function(x){return x.json().then(function(j){s.textContent=x.ok?' . wp_json_encode( __( 'Thank you — your feedback was saved.', 'educore-workspace' ) ) . ':(j.message||"Error");});});});})();</script>';
		return $html . $o . '</section>';
	}

	/* ---------- staff panel ---------- */

	public static function panel( int $uid, int $course_id ): string {
		if ( ! self::can_read( $uid, $course_id ) ) {
			return '';
		}
		$s   = self::summary( $course_id );
		$mgr = user_can( $uid, 'ec_manage_all_courses' );
		$o   = '<section class="ec-card ec-ws-section" aria-labelledby="ec-fbp-' . $course_id . '"><h2 id="ec-fbp-' . $course_id . '">' . esc_html__( 'Learner feedback', 'educore-workspace' ) . '</h2>';
		if ( ! $s['count'] ) {
			return $o . '<p class="ec-muted">' . esc_html__( 'No feedback yet.', 'educore-workspace' ) . '</p></section>';
		}
		/* translators: 1: average rating, 2: number of ratings */
		$o  .= '<p class="ec-feedback__avg">' . esc_html( sprintf( _n( '%1$s / 5 from %2$d rating', '%1$s / 5 from %2$d ratings', $s['count'], 'educore-workspace' ), number_format_i18n( (float) $s['average'], 1 ), $s['count'] ) ) . '</p><ul class="ec-an-bars" aria-label="' . esc_attr__( 'Ratings by number of stars', 'educore-workspace' ) . '">';
		for ( $i = 5; $i >= 1; $i-- ) {
			$w  = $s['count'] ? round( $s['dist'][ $i ] * 100 / $s['count'], 1 ) : 0;
			/* translators: %d: number of stars */
			$o .= '<li><span class="ec-an-bars__l">' . esc_html( sprintf( _n( '%d star', '%d stars', $i, 'educore-workspace' ), $i ) ) . '</span><span class="ec-an-bars__t" aria-hidden="true"><span style="inline-size:' . esc_attr( (string) $w ) . '%"></span></span><span class="ec-an-bars__v">' . esc_html( number_format_i18n( $s['dist'][ $i ] ) ) . '</span></li>';
		}
		$o .= '</ul><h3>' . esc_html__( 'Comments', 'educore-workspace' ) . '</h3>';
		$c  = self::comments( $course_id, $mgr );
		if ( ! $c ) {
			return $o . '<p class="ec-muted">' . esc_html__( 'No comments.', 'educore-workspace' ) . '</p></section>';
		}
		$o .= '<ul class="ec-ws-list ec-feedback__comments">';
		foreach ( $c as $r ) {
			$who = $mgr ? ( get_userdata( (int) $r['user_id'] )->display_name ?? '' ) . ' · ' : '';
			$act = $mgr ? ' <button type="button" class="ec-btn ec-btn--small" data-ec-call="feedback/moderate/' . (int) $r['id'] . '" data-ec-body="' . esc_attr( (string) wp_json_encode( array( 'status' => 'hidden' === $r['status'] ? 'visible' : 'hidden' ) ) ) . '">' . esc_html( 'hidden' === $r['status'] ? __( 'Show to the team', 'educore-workspace' ) : __( 'Hide from the team', 'educore-workspace' ) ) . '</button>' : '';
			/* translators: %d: rating from 1 to 5 */
			$o  .= '<li><span><span class="ec-muted">' . esc_html( $who . sprintf( __( '%d/5', 'educore-workspace' ), (int) $r['rating'] ) . ' · ' . get_date_from_gmt( $r['updated_at'], get_option( 'date_format' ) ) ) . ( 'hidden' === $r['status'] ? ' · ' . esc_html__( 'Hidden', 'educore-workspace' ) : '' ) . '</span><br>' . esc_html( $r['comment'] ) . '</span>' . $act . '</li>';
		}
		return $o . '</ul></section>';
	}

	/* ---------- REST ---------- */

	public static function routes(): void {
		register_rest_route( 'educore/v1', '/feedback/(?P<course>\d+)', array( 'methods' => 'POST', 'callback' => array( self::class, 'rest_submit' ), 'permission_callback' => 'is_user_logged_in', 'args' => array( 'course' => array( 'type' => 'integer', 'required' => true ), 'rating' => array( 'type' => 'integer', 'required' => true ), 'comment' => array( 'type' => 'string', 'default' => '' ) ) ) );
		register_rest_route( 'educore/v1', '/feedback/moderate/(?P<id>\d+)', array( 'methods' => 'POST', 'callback' => array( self::class, 'rest_moderate' ), 'permission_callback' => static fn() => current_user_can( 'ec_manage_all_courses' ), 'args' => array( 'id' => array( 'type' => 'integer', 'required' => true ), 'status' => array( 'type' => 'string', 'enum' => array( 'visible', 'hidden' ), 'required' => true ) ) ) );
	}

	public static function rest_submit( \WP_REST_Request $q ) {
		if ( ! RateLimiter::hit( 'rest_write' ) ) {
			return new \WP_Error( 'ec_ws_rate', __( 'Too many changes in a short time. Please wait a moment.', 'educore-workspace' ), array( 'status' => 429 ) );
		}
		$r = self::submit( get_current_user_id(), (int) $q['course'], (int) $q['rating'], (string) $q['comment'] );
		return is_wp_error( $r ) ? $r : new \WP_REST_Response( array( 'ok' => true ) );
	}

	public static function rest_moderate( \WP_REST_Request $q ) {
		$r = self::moderate( get_current_user_id(), (int) $q['id'], (string) $q['status'] );
		return is_wp_error( $r ) ? $r : new \WP_REST_Response( array( 'ok' => true ) );
	}
}
