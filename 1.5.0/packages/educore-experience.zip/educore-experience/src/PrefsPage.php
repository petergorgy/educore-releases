<?php
namespace EduCore\Experience;

use EduCore\Core\I18n;
use EduCore\Core\Pages as CorePages;

defined( 'ABSPATH' ) || exit;

/**
 * "My EduCore → Preferences". A plain form that works without JavaScript (admin-post); experience.js adds a live
 * appearance preview and the optional, explicitly requested device-location button.
 */
final class PrefsPage {
	public static function register(): void {
		add_shortcode( 'educore_preferences', array( self::class, 'render' ) );
		add_action( 'admin_post_educore_xp_prefs', array( self::class, 'save' ) );
	}

	private static function sections( int $uid ): array {
		$learner = user_can( $uid, 'ec_learn' );
		$s       = array(
			'profile'       => __( 'About me', 'educore-experience' ),
			'language'      => __( 'Language and time', 'educore-experience' ),
			'appearance'    => __( 'Appearance', 'educore-experience' ),
			'accessibility' => __( 'Reading and accessibility', 'educore-experience' ),
			'dashboard'     => __( 'My dashboard', 'educore-experience' ),
		);
		if ( $learner ) {
			$s['goals'] = __( 'Study goals and routine', 'educore-experience' );
		}
		$s['notifications'] = __( 'Notifications', 'educore-experience' );
		$extra              = (array) apply_filters( 'educore/experience/preferences_sections', array(), $uid );
		foreach ( $extra as $k => $def ) {
			$s[ sanitize_key( $k ) ] = (string) ( $def['label'] ?? $k );
		}
		$s['privacy'] = __( 'Privacy', 'educore-experience' );
		return $s;
	}

	public static function render(): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return '<div class="ec-card"><p>' . esc_html__( 'Please sign in to change your preferences.', 'educore-experience' ) . '</p><p><a class="ec-btn ec-btn--primary" href="' . esc_url( wp_login_url( Plugin::url( 'preferences' ) ) ) . '">' . esc_html__( 'Sign in', 'educore-experience' ) . '</a></p></div>';
		}
		if ( class_exists( '\EduCore\Workspace\Shell' ) ) {
			\EduCore\Workspace\Shell::title( __( 'My preferences', 'educore-experience' ) );
		}
		$p    = Prefs::get( $uid );
		$secs = self::sections( $uid );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display flags only.
		$msg  = sanitize_key( $_GET['ec_xp'] ?? '' );
		// phpcs:enable
		$o = '<div class="ec-xp-prefs">';
		if ( 'saved' === $msg ) {
			$o .= '<div class="ec-notice ec-notice--success" role="status">' . esc_html__( 'Your preferences were saved.', 'educore-experience' ) . '</div>';
		} elseif ( 'error' === $msg ) {
			$o .= '<div class="ec-notice ec-notice--error" role="alert">' . esc_html( (string) get_transient( 'educore_xp_prefs_error_' . $uid ) ?: __( 'Your preferences were not saved.', 'educore-experience' ) ) . '</div>';
		}
		$o .= '<nav class="ec-xp-prefs__toc" aria-label="' . esc_attr__( 'Preference sections', 'educore-experience' ) . '"><ul>';
		foreach ( $secs as $k => $l ) {
			$o .= '<li><a href="#ec-xp-s-' . esc_attr( $k ) . '">' . esc_html( $l ) . '</a></li>';
		}
		$o .= '</ul></nav>';
		$o .= '<form class="ec-xp-prefs__form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-ec-xp-prefs>';
		$o .= '<input type="hidden" name="action" value="educore_xp_prefs">' . wp_nonce_field( 'educore_xp_prefs', '_wpnonce', true, false );

		// About me.
		$o .= self::open( 'profile', $secs['profile'], __( 'How EduCore greets you. Your full name, photo and contact details are in My profile.', 'educore-experience' ) . ' <a href="' . esc_url( CorePages::url( 'profile' ) ) . '">' . esc_html__( 'Open My profile', 'educore-experience' ) . '</a>' );
		$o .= self::text( 'preferred_name', __( 'Preferred name (optional)', 'educore-experience' ), $p['preferred_name'], 60, __( 'For example a short form of your name. Leave empty to use your first name.', 'educore-experience' ) );
		$o .= self::text( 'pronunciation', __( 'How to pronounce my name (optional)', 'educore-experience' ), $p['pronunciation'], 80, __( 'Shown to your teachers next to your name, for example “sah-RAH”.', 'educore-experience' ) );
		$o .= self::check( 'greet_by_name', __( 'Greet me by name on my dashboard', 'educore-experience' ), (bool) $p['greet_by_name'] );
		$o .= '</fieldset>';

		// Language and time.
		$lang = I18n::sanitize_lang( get_user_meta( $uid, 'educore_lang', true ) ?: I18n::DEFAULT );
		$o   .= self::open( 'language', $secs['language'], '' );
		$o   .= '<p class="ec-field"><label for="ec-xp-lang">' . esc_html__( 'Language', 'educore-experience' ) . '</label><select id="ec-xp-lang" name="lang">';
		foreach ( I18n::labels() as $code => $label ) {
			$o .= '<option value="' . esc_attr( $code ) . '" lang="' . esc_attr( $code ) . '"' . selected( $lang, $code, false ) . '>' . esc_html( $label ) . '</option>';
		}
		$o  .= '</select></p>';
		$def = (string) ( Settings::get( 'institution_tz' ) ?: wp_timezone_string() );
		/* translators: %s: time zone name */
		$o .= '<p class="ec-field"><label for="ec-xp-tz">' . esc_html__( 'My time zone', 'educore-experience' ) . '</label>' . Settings::tz_select( 'timezone', (string) $p['timezone'], 'ec-xp-tz', sprintf( __( 'School default (%s)', 'educore-experience' ), str_replace( '_', ' ', $def ) ) ) . '<span class="ec-field__help ec-muted" id="ec-xp-tz-now" data-ec-xp-tznow></span></p>';
		$o .= '</fieldset>';

		// Appearance.
		$o .= self::open( 'appearance', $secs['appearance'], __( 'Automatic modes change EduCore’s colours gently through the day. Text always keeps a readable contrast.', 'educore-experience' ) );
		$o .= '<div class="ec-xp-modes" role="radiogroup" aria-labelledby="ec-xp-s-appearance-h">';
		foreach ( Appearance::mode_labels() as $k => $l ) {
			$o .= '<label class="ec-xp-mode" data-ec-xp-swatch="' . esc_attr( $k ) . '"><input type="radio" name="appearance" value="' . esc_attr( $k ) . '"' . checked( $p['appearance'], $k, false ) . '><span class="ec-xp-mode__chip" aria-hidden="true"></span><span>' . esc_html( $l ) . '</span></label>';
		}
		$o   .= '</div>';
		$city = '<p class="ec-field"><label for="ec-xp-city">' . esc_html__( 'City for sunrise and sunset', 'educore-experience' ) . '</label><select id="ec-xp-city" name="solar_city"><option value="">' . esc_html__( '— Choose a city —', 'educore-experience' ) . '</option>';
		foreach ( Cities::all() as $c ) {
			$city .= '<option value="' . esc_attr( $c['key'] ) . '"' . selected( $p['solar_city'], $c['key'], false ) . '>' . esc_html( $c['name'] ) . '</option>';
		}
		$city .= '</select></p>';
		$loc   = null !== $p['solar_lat']
			? '<p class="ec-muted">' . esc_html__( 'Using your device location (rounded to about 1 km).', 'educore-experience' ) . ' <label><input type="checkbox" name="clear_coords" value="1"> ' . esc_html__( 'Forget my device location', 'educore-experience' ) . '</label></p>'
			: '';
		$o    .= '<div class="ec-xp-solar" data-ec-xp-solar>' . $city . $loc
			. '<p><button type="button" class="ec-btn" data-ec-xp-locate data-ok="' . esc_attr__( 'Location received. Save to use it.', 'educore-experience' ) . '" data-fail="' . esc_attr__( 'Location was not shared. You can choose a city instead.', 'educore-experience' ) . '" hidden>' . esc_html__( 'Use my device location instead', 'educore-experience' ) . '</button> <span class="ec-muted" data-ec-xp-locate-status role="status"></span></p>'
			. '<input type="hidden" name="solar_lat" value="" data-ec-xp-lat><input type="hidden" name="solar_lng" value="" data-ec-xp-lng>'
			. '<p class="ec-muted">' . esc_html__( 'Your browser asks before sharing your location. Without a city or location, EduCore uses the time-of-day schedule.', 'educore-experience' ) . '</p></div>';
		$o    .= '</fieldset>';

		// Accessibility.
		$o .= self::open( 'accessibility', $secs['accessibility'], __( 'These settings always win over the automatic appearance.', 'educore-experience' ) );
		$o .= self::select( 'font_scale', __( 'Text size', 'educore-experience' ), (string) $p['font_scale'], array( '90' => __( 'Smaller', 'educore-experience' ), '100' => __( 'Standard', 'educore-experience' ), '110' => __( 'Larger', 'educore-experience' ), '125' => __( 'Large', 'educore-experience' ), '150' => __( 'Extra large', 'educore-experience' ) ) );
		$o .= self::check( 'contrast', __( 'High contrast', 'educore-experience' ), 'high' === $p['contrast'], 'high' );
		$o .= self::check( 'motion', __( 'Reduce motion and animations', 'educore-experience' ), 'reduce' === $p['motion'], 'reduce' );
		$o .= self::check( 'density', __( 'Compact layout (less spacing)', 'educore-experience' ), 'compact' === $p['density'], 'compact' );
		$o .= self::check( 'reading', __( 'More space between lines in lessons', 'educore-experience' ), 'spacious' === $p['reading'], 'spacious' );
		$o .= '</fieldset>';

		// Dashboard.
		$labels = array(
			'welcome'       => __( 'Welcome card', 'educore-experience' ),
			'suggestions'   => __( 'Suggested for you', 'educore-experience' ),
			'goals'         => __( 'My study goals', 'educore-experience' ),
			'upcoming'      => __( 'Upcoming assessments', 'educore-experience' ),
			'pending'       => __( 'Pending work', 'educore-experience' ),
			'results'       => __( 'Recent results', 'educore-experience' ),
			'announcements' => __( 'Announcements', 'educore-experience' ),
			'certificates'  => __( 'Certificates', 'educore-experience' ),
			'achievements'  => __( 'Achievements', 'educore-experience' ),
		);
		$avail = user_can( $uid, 'ec_learn' ) ? Prefs::WIDGETS : array( 'welcome' );
		$o    .= self::open( 'dashboard', $secs['dashboard'], __( 'Choose what appears on your home page and in which order.', 'educore-experience' ) );
		$o    .= '<fieldset class="ec-xp-sub"><legend>' . esc_html__( 'Show these sections', 'educore-experience' ) . '</legend><input type="hidden" name="widgets_sent" value="1">';
		foreach ( $avail as $w ) {
			$o .= '<label class="ec-xp-check"><input type="checkbox" name="show[]" value="' . esc_attr( $w ) . '"' . checked( ! in_array( $w, $p['hidden_widgets'], true ), true, false ) . '> ' . esc_html( $labels[ $w ] ) . '</label>';
		}
		$o .= '</fieldset>';
		if ( user_can( $uid, 'ec_learn' ) ) {
			$o .= '<fieldset class="ec-xp-sub"><legend>' . esc_html__( 'Order at the top of My learning', 'educore-experience' ) . '</legend>';
			foreach ( $p['widget_order'] as $i => $w ) {
				$o .= '<p class="ec-field ec-field--inline"><label for="ec-xp-ord-' . esc_attr( $w ) . '">' . esc_html( $labels[ $w ] ) . '</label><select id="ec-xp-ord-' . esc_attr( $w ) . '" name="order[' . esc_attr( $w ) . ']">';
				foreach ( range( 1, count( Prefs::ORDERABLE ) ) as $n ) {
					$o .= '<option value="' . esc_attr( (string) $n ) . '"' . selected( $i + 1, $n, false ) . '>' . esc_html( number_format_i18n( $n ) ) . '</option>';
				}
				$o .= '</select></p>';
			}
			$o .= '</fieldset>';
		}
		$o .= '</fieldset>';

		// Goals.
		if ( isset( $secs['goals'] ) ) {
			$o .= self::open( 'goals', $secs['goals'], __( 'Goals are for you only. There are no streaks to lose and no reminders unless you ask for them.', 'educore-experience' ) );
			$o .= self::number( 'lessons_goal', __( 'Lessons per week', 'educore-experience' ), (int) $p['lessons_goal'], 1, 50 );
			$o .= self::number( 'practice_goal', __( 'Practice questions per week (0 = no goal)', 'educore-experience' ), (int) $p['practice_goal'], 0, 200 );
			$o .= self::check( 'goals_paused', __( 'Pause my goals for now', 'educore-experience' ), (bool) $p['goals_paused'] );
			$o .= '<fieldset class="ec-xp-sub"><legend>' . esc_html__( 'When I usually study (optional)', 'educore-experience' ) . '</legend><div class="ec-xp-days">';
			$dn = array( 'mon' => __( 'Mon', 'educore-experience' ), 'tue' => __( 'Tue', 'educore-experience' ), 'wed' => __( 'Wed', 'educore-experience' ), 'thu' => __( 'Thu', 'educore-experience' ), 'fri' => __( 'Fri', 'educore-experience' ), 'sat' => __( 'Sat', 'educore-experience' ), 'sun' => __( 'Sun', 'educore-experience' ) );
			foreach ( $dn as $k => $l ) {
				$o .= '<label class="ec-xp-check"><input type="checkbox" name="study_days[]" value="' . esc_attr( $k ) . '"' . checked( in_array( $k, $p['study_days'], true ), true, false ) . '> ' . esc_html( $l ) . '</label>';
			}
			$o .= '</div></fieldset>';
			$o .= self::select( 'study_slot', __( 'Usual time of day', 'educore-experience' ), (string) $p['study_slot'], array( '' => __( 'No preference', 'educore-experience' ), 'morning' => __( 'Morning', 'educore-experience' ), 'afternoon' => __( 'Afternoon', 'educore-experience' ), 'evening' => __( 'Evening', 'educore-experience' ) ) );
			$subjects = Prefs::subjects();
			if ( $subjects ) {
				$o .= '<fieldset class="ec-xp-sub"><legend>' . esc_html__( 'Subjects I am interested in', 'educore-experience' ) . '</legend>';
				foreach ( $subjects as $s ) {
					$o .= '<label class="ec-xp-check"><input type="checkbox" name="interests[]" value="' . esc_attr( (string) $s['id'] ) . '"' . checked( in_array( $s['id'], $p['interests'], true ), true, false ) . '> ' . esc_html( $s['name'] ) . '</label>';
				}
				$o .= '</fieldset>';
			}
			$o .= '<input type="hidden" name="goals_sent" value="1"></fieldset>';
		}

		// Notifications.
		$o .= self::open( 'notifications', $secs['notifications'], __( 'Choose which e-mails you receive in My profile, under Notifications.', 'educore-experience' ) . ' <a href="' . esc_url( CorePages::url( 'profile' ) ) . '#ec-notifications">' . esc_html__( 'Open notification settings', 'educore-experience' ) . '</a>' ) . '</fieldset>';

		// Privacy.
		$o .= self::open( 'privacy', $secs['privacy'], __( 'Your preferences belong to your account. They are not shared with other people using this device, they are included when you ask for a copy of your data, and they are deleted with your account.', 'educore-experience' ) ) . '</fieldset>';

		$o .= '<p class="ec-xp-prefs__save"><button type="submit" class="ec-btn ec-btn--primary">' . esc_html__( 'Save my preferences', 'educore-experience' ) . '</button></p></form>';
		// Sections from other packages carry their own forms (e.g. connected sign-in methods), so they sit outside the main form.
		$extra = (array) apply_filters( 'educore/experience/preferences_sections', array(), $uid );
		if ( $extra ) {
			$o .= '<div class="ec-xp-prefs__extra">';
			foreach ( $extra as $k => $def ) {
				$o .= '<section class="ec-card ec-xp-prefs__sec" id="ec-xp-s-' . esc_attr( sanitize_key( $k ) ) . '" aria-labelledby="ec-xp-s-' . esc_attr( sanitize_key( $k ) ) . '-h"><h2 id="ec-xp-s-' . esc_attr( sanitize_key( $k ) ) . '-h">' . esc_html( (string) ( $def['label'] ?? $k ) ) . '</h2>' . ( ! empty( $def['intro'] ) ? '<p class="ec-muted">' . esc_html( (string) $def['intro'] ) . '</p>' : '' ) . (string) ( $def['html'] ?? '' ) . '</section>';
			}
			$o .= '</div>';
		}
		return $o . '</div>';
	}

	private static function open( string $key, string $label, string $intro_html ): string {
		return '<fieldset class="ec-card ec-xp-prefs__sec" id="ec-xp-s-' . esc_attr( $key ) . '"><legend class="screen-reader-text">' . esc_html( $label ) . '</legend><h2 id="ec-xp-s-' . esc_attr( $key ) . '-h">' . esc_html( $label ) . '</h2>' . ( $intro_html ? '<p class="ec-muted">' . wp_kses( $intro_html, array( 'a' => array( 'href' => true ) ) ) . '</p>' : '' );
	}

	private static function text( string $name, string $label, string $value, int $max, string $help ): string {
		return '<p class="ec-field"><label for="ec-xp-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label><input type="text" id="ec-xp-' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" maxlength="' . esc_attr( (string) $max ) . '" value="' . esc_attr( $value ) . '" aria-describedby="ec-xp-' . esc_attr( $name ) . '-help" autocomplete="off"><span class="ec-field__help ec-muted" id="ec-xp-' . esc_attr( $name ) . '-help">' . esc_html( $help ) . '</span></p>';
	}

	private static function number( string $name, string $label, int $value, int $min, int $max ): string {
		return '<p class="ec-field"><label for="ec-xp-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label><input type="number" id="ec-xp-' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" min="' . esc_attr( (string) $min ) . '" max="' . esc_attr( (string) $max ) . '" value="' . esc_attr( (string) $value ) . '"></p>';
	}

	private static function check( string $name, string $label, bool $on, string $value = '1' ): string {
		return '<p class="ec-xp-check"><label><input type="checkbox" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . checked( $on, true, false ) . '> ' . esc_html( $label ) . '</label></p>';
	}

	private static function select( string $name, string $label, string $value, array $opts ): string {
		$o = '<p class="ec-field"><label for="ec-xp-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label><select id="ec-xp-' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '">';
		foreach ( $opts as $k => $l ) {
			$o .= '<option value="' . esc_attr( (string) $k ) . '"' . selected( $value, (string) $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		return $o . '</select></p>';
	}

	/** Maps the plain form to a preferences update. Unchecked boxes mean "off" for the fields on the form. */
	public static function from_form( array $in, int $uid ): array {
		$u = array(
			'preferred_name' => (string) ( $in['preferred_name'] ?? '' ),
			'pronunciation'  => (string) ( $in['pronunciation'] ?? '' ),
			'greet_by_name'  => ! empty( $in['greet_by_name'] ),
			'timezone'       => (string) ( $in['timezone'] ?? '' ),
			'appearance'     => (string) ( $in['appearance'] ?? 'auto' ),
			'font_scale'     => (int) ( $in['font_scale'] ?? 100 ),
			'contrast'       => empty( $in['contrast'] ) ? 'standard' : 'high',
			'motion'         => empty( $in['motion'] ) ? 'system' : 'reduce',
			'density'        => empty( $in['density'] ) ? 'comfortable' : 'compact',
			'reading'        => empty( $in['reading'] ) ? 'standard' : 'spacious',
		);
		if ( isset( $in['solar_city'] ) ) {
			$u['solar_city'] = (string) $in['solar_city'];
		}
		if ( '' !== (string) ( $in['solar_lat'] ?? '' ) && '' !== (string) ( $in['solar_lng'] ?? '' ) ) {
			$u['solar_coords'] = array( 'lat' => (float) $in['solar_lat'], 'lng' => (float) $in['solar_lng'] );
		} elseif ( ! empty( $in['clear_coords'] ) ) {
			$u['solar_coords'] = null;
		}
		if ( ! empty( $in['widgets_sent'] ) ) {
			$avail               = user_can( $uid, 'ec_learn' ) ? Prefs::WIDGETS : array( 'welcome' );
			$show                = array_map( 'strval', (array) ( $in['show'] ?? array() ) );
			$keep_hidden         = array_diff( Prefs::get( $uid )['hidden_widgets'], $avail );
			$u['hidden_widgets'] = array_values( array_merge( $keep_hidden, array_diff( $avail, $show ) ) );
		}
		if ( isset( $in['order'] ) && is_array( $in['order'] ) ) {
			$ord = array_map( 'intval', $in['order'] );
			asort( $ord );
			$u['widget_order'] = array_keys( $ord );
		}
		if ( ! empty( $in['goals_sent'] ) ) {
			$u['lessons_goal']  = (int) ( $in['lessons_goal'] ?? 3 );
			$u['practice_goal'] = (int) ( $in['practice_goal'] ?? 0 );
			$u['goals_paused']  = ! empty( $in['goals_paused'] );
			$u['study_days']    = (array) ( $in['study_days'] ?? array() );
			$u['study_slot']    = (string) ( $in['study_slot'] ?? '' );
			$u['interests']     = (array) ( $in['interests'] ?? array() );
		}
		return $u;
	}

	public static function save(): void {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'educore_xp_prefs' ) ) {
			wp_die( esc_html__( 'Please sign in again.', 'educore-experience' ), 403 );
		}
		$in   = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validated in Prefs::update().
		$back = Plugin::url( 'preferences' );
		$res  = Prefs::update( $uid, self::from_form( (array) $in, $uid ) );
		if ( is_wp_error( $res ) ) {
			set_transient( 'educore_xp_prefs_error_' . $uid, $res->get_error_message(), 120 );
			wp_safe_redirect( add_query_arg( 'ec_xp', 'error', $back ) );
			exit;
		}
		if ( isset( $in['lang'] ) ) {
			update_user_meta( $uid, 'educore_lang', I18n::sanitize_lang( (string) $in['lang'] ) );
		}
		\EduCore\Core\Audit::log( 'experience.preferences_saved', 'user', $uid, array( 'via' => 'form' ) );
		wp_safe_redirect( add_query_arg( array( 'ec_xp' => 'saved', 'lang' => I18n::sanitize_lang( (string) ( $in['lang'] ?? I18n::current() ) ) ), $back ) );
		exit;
	}
}
