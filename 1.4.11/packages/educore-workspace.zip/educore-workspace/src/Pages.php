<?php
namespace EduCore\Workspace;

use EduCore\Core\Pages as CorePages;

defined( 'ABSPATH' ) || exit;

/**
 * Workspace pages. New pages only where nothing exists; existing EduCore pages are reused so bookmarks keep working:
 * /dashboard/ (student), /teaching-hub/ (teacher), /guardian/ (guardian portal + consent), /workspace/ (instructor).
 */
final class Pages {
	public const OPTION = 'educore_ws_pages';

	public static function register(): void {}

	public static function definitions(): array {
		return array(
			'manage' => array( 'title' => 'EduCore Management', 'content' => '<!-- wp:shortcode -->[educore_manage]<!-- /wp:shortcode -->' ),
			'tutor'  => array( 'title' => 'Tutor workspace', 'content' => '<!-- wp:shortcode -->[educore_tutor_workspace]<!-- /wp:shortcode -->' ),
			'studio' => array( 'title' => 'Course Studio', 'content' => '<!-- wp:shortcode -->[educore_studio]<!-- /wp:shortcode -->' ),
			'help'   => array( 'title' => 'User guide', 'content' => '<!-- wp:shortcode -->[educore_help]<!-- /wp:shortcode -->' ),
		);
	}

	public static function create_missing(): array {
		$pages = (array) get_option( self::OPTION, array() );
		foreach ( self::definitions() as $key => $def ) {
			if ( ! empty( $pages[ $key ] ) && get_post( (int) $pages[ $key ] ) ) {
				continue;
			}
			$existing = get_page_by_path( $key );
			if ( $existing ) {
				// Never take over or overwrite an unrelated page that already uses this address.
				if ( false !== strpos( (string) $existing->post_content, '[educore_' ) ) {
					$pages[ $key ] = (int) $existing->ID;
				}
				continue;
			}
			$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $def['title'], 'post_name' => $key, 'post_content' => $def['content'], 'comment_status' => 'closed' ), true );
			if ( ! is_wp_error( $id ) ) {
				$pages[ $key ] = (int) $id;
			}
		}
		update_option( self::OPTION, $pages, false );
		return $pages;
	}

	public static function id( string $key ): int {
		$pages = (array) get_option( self::OPTION, array() );
		return (int) ( $pages[ $key ] ?? 0 );
	}

	public static function url( string $key, array $args = array() ): string {
		$id  = self::id( $key );
		$url = $id && 'publish' === get_post_status( $id ) ? (string) get_permalink( $id ) : home_url( '/' . $key . '/' );
		return $args ? add_query_arg( $args, $url ) : $url;
	}

	/**
	 * Which workspace a page belongs to (null = ordinary public page).
	 *
	 * @return string|null manage|teaching-hub|tutor|student|guardian|instructor
	 */
	public static function workspace_of( int $page_id ): ?string {
		if ( ! $page_id ) {
			return null;
		}
		$map = array(
			'manage' => self::id( 'manage' ),
			'tutor'  => self::id( 'tutor' ),
			'studio' => self::id( 'studio' ),
			'help'   => self::id( 'help' ),
		);
		if ( class_exists( '\EduCore\TeachingHub\Pages' ) ) {
			$map['teaching-hub'] = \EduCore\TeachingHub\Pages::id( 'teaching-hub' );
		}
		$map['student']    = CorePages::id( 'dashboard' );
		$map['instructor'] = CorePages::id( 'workspace' );
		$map['guardian']   = CorePages::id( 'guardian' );
		foreach ( array( 'history', 'profile' ) as $k ) {
			$map[ 'student:' . $k ] = CorePages::id( $k );
		}
		foreach ( $map as $ws => $id ) {
			if ( $id && $id === $page_id ) {
				return strtok( $ws, ':' );
			}
		}
		return null;
	}
}
