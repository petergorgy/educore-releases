<?php
namespace EduCore\Analytics;

defined( 'ABSPATH' ) || exit;

/** REST: /educore/v1/analytics/report (scoped staff), /educore/v1/analytics/me (own data). */
final class Rest {

	public static function register(): void {
		add_action( 'educore/rest/routes', array( self::class, 'routes' ) );
		add_action( 'admin_post_educore_analytics_export', array( Export::class, 'download' ) );
	}

	public static function routes( string $ns ): void {
		register_rest_route(
			$ns,
			'/analytics/report',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'report' ),
				'permission_callback' => static fn() => is_user_logged_in() && current_user_can( 'ec_export_reports' ),
				'args'                => array(
					'type'      => array( 'type' => 'string', 'enum' => Export::TYPES, 'required' => true ),
					'course'    => array( 'type' => 'integer', 'default' => 0, 'sanitize_callback' => 'absint' ),
					'from'      => array( 'type' => 'string' ),
					'to'        => array( 'type' => 'string' ),
					'programme' => array( 'type' => 'integer' ),
					'year'      => array( 'type' => 'string' ),
				),
			)
		);
		register_rest_route(
			$ns,
			'/analytics/me',
			array(
				'methods'             => 'GET',
				'callback'            => static fn() => new \WP_REST_Response( Block::data( get_current_user_id() ) ),
				'permission_callback' => static fn() => is_user_logged_in(),
			)
		);
	}

	public static function report( \WP_REST_Request $r ) {
		$f    = new Filters( $r->get_params() );
		$rows = Export::rows( (string) $r['type'], $f, get_current_user_id() );
		return is_wp_error( $rows ) ? $rows : new \WP_REST_Response( array( 'header' => array_shift( $rows ), 'rows' => $rows ) );
	}
}
