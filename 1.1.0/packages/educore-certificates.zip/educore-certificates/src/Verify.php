<?php
namespace EduCore\Certificates;

use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/** Public verification page/block. Shows only name, course, issue date and status. */
final class Verify {

	public static function ensure_page(): int {
		$id = (int) get_option( 'educore_cert_verify_page', 0 );
		if ( $id && get_post( $id ) ) {
			return $id;
		}
		$id = (int) wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => __( 'Verify a certificate', 'educore-certificates' ), 'post_name' => 'verify-certificate', 'post_content' => '<!-- wp:educore/certificate-verify /-->' ) );
		update_option( 'educore_cert_verify_page', $id, false );
		return $id;
	}

	public static function url( string $uid ): string {
		$id   = (int) get_option( 'educore_cert_verify_page', 0 );
		$base = $id && 'publish' === get_post_status( $id ) ? (string) get_permalink( $id ) : home_url( '/verify-certificate/' );
		return add_query_arg( 'code', $uid, $base );
	}

	public static function block( array $blocks ): array {
		$blocks['certificate-verify'] = array( 'title' => __( 'EduCore: Verify certificate', 'educore-certificates' ), 'render' => array( self::class, 'render' ) );
		return $blocks;
	}

	public static function render(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public lookup.
		$code = isset( $_GET['code'] ) ? sanitize_key( wp_unslash( $_GET['code'] ) ) : '';
		$out  = '<div class="ec-verify"><form class="ec-form ec-card" method="get"><label class="ec-field"><span>' . esc_html__( 'Certificate ID', 'educore-certificates' ) . '</span><input name="code" required pattern="[a-fA-F0-9]{32}" value="' . esc_attr( $code ) . '" dir="ltr"></label><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Verify', 'educore-certificates' ) . '</button></form>';
		if ( '' !== $code ) {
			if ( ! RateLimiter::hit( 'verify' ) ) {
				return $out . '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'Too many lookups. Please try again in a minute.', 'educore-certificates' ) . '</div></div>';
			}
			$c = Certificates::by_uid( $code );
			if ( ! $c ) {
				$out .= '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'No certificate exists with this ID.', 'educore-certificates' ) . '</div>';
			} else {
				$v     = Certificates::public_view( $c );
				$valid = 'valid' === $v['status'];
				$out  .= '<div class="ec-card ec-verify__result" role="status"><p class="' . ( $valid ? 'ec-badge-done ec-badge-done--lg' : 'ec-notice ec-notice--error' ) . '">' . esc_html( $valid ? __( 'Valid certificate', 'educore-certificates' ) : __( 'This certificate has been revoked', 'educore-certificates' ) ) . '</p>';
				$out  .= '<dl><dt>' . esc_html__( 'Awarded to', 'educore-certificates' ) . '</dt><dd>' . esc_html( $v['student_name'] ) . '</dd><dt>' . esc_html__( 'Course', 'educore-certificates' ) . '</dt><dd>' . esc_html( $v['course_title'] ) . '</dd><dt>' . esc_html__( 'Issued on', 'educore-certificates' ) . '</dt><dd>' . esc_html( wp_date( get_option( 'date_format' ), strtotime( $v['issued_on'] ) ) ) . '</dd></dl></div>';
			}
		}
		return $out . '</div>';
	}
}
