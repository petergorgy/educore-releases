<?php
namespace EduCore\Assessments\Exchange;

defined( 'ABSPATH' ) || exit;

/**
 * Moodle GIFT text format.
 * Supported: multiple choice (single and multiple answer, % weights), true/false, short answer,
 * numerical (exact value → short answer), matching, essay, missing-word, ::title::, $CATEGORY,
 * general feedback (####). Per-answer feedback is not stored by EduCore (reported as a warning).
 */
final class Gift {
	private const SPECIAL = array( '~', '=', '#', '{', '}', ':' );

	/** @return array<int,array{record:?array,error:?string,warnings:string[]}> keyed by line */
	public static function read( string $raw ): array {
		$raw   = str_replace( array( "\r\n", "\r" ), "\n", (string) preg_replace( '/^\xEF\xBB\xBF/', '', $raw ) );
		$lines = explode( "\n", $raw );
		$out   = array();
		$block = array();
		$start = 0;
		$cat   = '';
		$flush = static function () use ( &$block, &$start, &$out, &$cat ) {
			$text = trim( implode( "\n", $block ) );
			if ( '' !== $text ) {
				if ( preg_match( '/^\$CATEGORY:\s*(.+)$/m', $text, $m ) && ! str_contains( $text, '{' ) ) {
					$cat = trim( $m[1] );
				} else {
					$out[ $start ] = self::question( $text, $cat );
				}
			}
			$block = array();
		};
		foreach ( $lines as $i => $line ) {
			if ( preg_match( '/^\s*\/\//', $line ) ) {
				continue;
			}
			if ( '' === trim( $line ) ) {
				$flush();
				continue;
			}
			if ( ! $block ) {
				$start = $i + 1;
			}
			$block[] = $line;
		}
		$flush();
		return $out;
	}

	private static function find( string $s, string $ch, int $from = 0 ): int {
		$n = strlen( $s );
		for ( $i = $from; $i < $n; $i++ ) {
			if ( '\\' === $s[ $i ] ) {
				++$i;
				continue;
			}
			if ( $s[ $i ] === $ch ) {
				return $i;
			}
		}
		return -1;
	}

	public static function unescape( string $s ): string {
		return trim( str_replace( array( '\\~', '\\=', '\\#', '\\{', '\\}', '\\:', '\\n' ), array( '~', '=', '#', '{', '}', ':', "\n" ), $s ) );
	}

	public static function escape( string $s ): string {
		return str_replace( array( '\\', '~', '=', '#', '{', '}', ':', "\n" ), array( '\\\\', '\\~', '\\=', '\\#', '\\{', '\\}', '\\:', '\\n' ), $s );
	}

	private static function text_format( string $s ): string {
		$fmt = 'moodle';
		if ( preg_match( '/^\[(html|moodle|plain|markdown)\]/', $s, $m ) ) {
			$fmt = $m[1];
			$s   = substr( $s, strlen( $m[0] ) );
		}
		$s = self::unescape( $s );
		return 'html' === $fmt ? $s : nl2br( esc_html( $s ), false );
	}

	/** @return array{record:?array,error:?string,warnings:string[]} */
	private static function question( string $q, string $cat ): array {
		$warn  = array();
		$title = '';
		if ( 0 === strpos( $q, '::' ) ) {
			$end = strpos( $q, '::', 2 );
			if ( false !== $end ) {
				$title = self::unescape( substr( $q, 2, $end - 2 ) );
				$q     = ltrim( substr( $q, $end + 2 ) );
			}
		}
		$open = self::find( $q, '{' );
		$close = $open >= 0 ? self::find( $q, '}', $open ) : -1;
		if ( $open < 0 || $close < 0 ) {
			return array( 'record' => null, 'error' => __( 'No answer block {…} found (description-only items are not questions).', 'educore-assessments' ), 'warnings' => array() );
		}
		$before = trim( substr( $q, 0, $open ) );
		$after  = trim( substr( $q, $close + 1 ) );
		$ans    = trim( substr( $q, $open + 1, $close - $open - 1 ) );
		$stem   = self::text_format( $before );
		if ( '' !== $after ) {
			$stem .= ' _____ ' . self::text_format( $after );
		}
		$expl = '';
		$gf   = strpos( $ans, '####' );
		if ( false !== $gf ) {
			$expl = self::text_format( substr( $ans, $gf + 4 ) );
			$ans  = trim( substr( $ans, 0, $gf ) );
		}
		$rec = array(
			'external_id' => $title,
			'stem'        => $stem,
			'explanation' => $expl,
			'tags'        => '' !== $cat ? array( 'cat-' . sanitize_title( (string) preg_replace( '#^\$\w+\$/?#', '', $cat ) ) ) : array(),
		);
		// Essay.
		if ( '' === $ans ) {
			return array( 'record' => $rec + array( 'type' => 'essay', 'payload' => array( 'min_words' => 0 ), 'key' => array( 'model_answer' => '' ) ), 'error' => null, 'warnings' => $warn );
		}
		// True/false.
		if ( preg_match( '/^(T|TRUE|F|FALSE)\s*(#.*)?$/is', $ans, $m ) ) {
			if ( ! empty( $m[2] ) ) {
				$warn[] = __( 'Answer feedback is not stored.', 'educore-assessments' );
			}
			return array( 'record' => $rec + array( 'type' => 'truefalse', 'payload' => array(), 'key' => array( 'correct' => in_array( strtoupper( $m[1] ), array( 'T', 'TRUE' ), true ) ) ), 'error' => null, 'warnings' => $warn );
		}
		// Numerical.
		if ( '#' === $ans[0] ) {
			$vals = array();
			foreach ( self::split( substr( $ans, 1 ) ) as $a ) {
				if ( '~' === $a['mark'] || ( null !== $a['weight'] && $a['weight'] < 100 ) ) {
					if ( null !== $a['weight'] && $a['weight'] > 0 ) {
						$warn[] = __( 'Partially correct answers are not supported; only fully correct answers are kept.', 'educore-assessments' );
					}
					continue; // Wrong, partial or catch-all answers are never accepted.
				}
				if ( preg_match( '/^(-?[\d.]+)(?::([\d.]+))?$/', trim( $a['text'] ), $m ) ) {
					$vals[] = $m[1];
					if ( ! empty( $m[2] ) && (float) $m[2] > 0 ) {
						$warn[] = __( 'Numerical tolerance is not supported; only the exact value is accepted.', 'educore-assessments' );
					}
				} elseif ( preg_match( '/^(-?[\d.]+)\.\.(-?[\d.]+)$/', trim( $a['text'] ) ) ) {
					return array( 'record' => $rec + array( 'type' => 'short' ), 'error' => __( 'Numerical ranges (min..max) are not supported.', 'educore-assessments' ), 'warnings' => array() );
				}
			}
			if ( ! $vals ) {
				return array( 'record' => $rec + array( 'type' => 'short' ), 'error' => __( 'No fully correct answer.', 'educore-assessments' ), 'warnings' => array() );
			}
			$warn[] = __( 'Numerical question imported as short answer (exact value).', 'educore-assessments' );
			return array( 'record' => $rec + array( 'type' => 'short', 'payload' => array(), 'key' => array( 'accepted' => $vals ) ), 'error' => null, 'warnings' => array_values( array_unique( $warn ) ) );
		}
		$items = self::split( $ans );
		if ( ! $items ) {
			return array( 'record' => $rec + array( 'type' => 'short' ), 'error' => __( 'The answer block could not be read.', 'educore-assessments' ), 'warnings' => array() );
		}
		if ( array_filter( $items, static fn( $a ) => $a['feedback'] ) ) {
			$warn[] = __( 'Answer feedback is not stored.', 'educore-assessments' );
		}
		// Matching.
		if ( array_filter( $items, static fn( $a ) => str_contains( $a['raw'], '->' ) ) ) {
			$left  = array();
			$right = array();
			$pairs = array();
			$n     = 0;
			foreach ( $items as $a ) {
				$parts = explode( '->', $a['raw'], 2 );
				$l     = self::unescape( $parts[0] );
				$r     = self::unescape( $parts[1] ?? '' );
				++$n;
				// Identical answers are one choice (Moodle shows each distinct answer once).
				$rid = array_search( esc_html( $r ), array_column( $right, 'text', 'id' ), true );
				if ( false === $rid ) {
					$rid     = 'r' . $n;
					$right[] = array( 'id' => $rid, 'text' => esc_html( $r ) );
				}
				if ( '' !== $l ) {
					$left[]             = array( 'id' => 'l' . $n, 'text' => esc_html( $l ) );
					$pairs[ 'l' . $n ] = $rid;
				}
			}
			return array( 'record' => $rec + array( 'type' => 'matching', 'payload' => array( 'left' => $left, 'right' => $right ), 'key' => array( 'pairs' => $pairs ) ), 'error' => null, 'warnings' => $warn );
		}
		$has_wrong = (bool) array_filter( $items, static fn( $a ) => '~' === $a['mark'] );
		// Short answer: only "=" answers.
		if ( ! $has_wrong ) {
			$acc = array_values( array_map( static fn( $a ) => $a['text'], array_filter( $items, static fn( $a ) => null === $a['weight'] || $a['weight'] >= 100 ) ) );
			if ( count( $acc ) < count( $items ) ) {
				$warn[] = __( 'Partially correct short answers are not supported; only fully correct answers are kept.', 'educore-assessments' );
			}
			return array( 'record' => $rec + array( 'type' => 'short', 'payload' => array(), 'key' => array( 'accepted' => $acc ) ), 'error' => null, 'warnings' => $warn );
		}
		// Multiple choice.
		$opts    = array();
		$correct = array();
		$partial = false;
		foreach ( $items as $i => $a ) {
			$id     = chr( 97 + $i );
			$opts[] = array( 'id' => $id, 'text' => esc_html( $a['text'] ) );
			$w      = '=' === $a['mark'] ? 100.0 : ( $a['weight'] ?? 0.0 );
			if ( $w > 0 ) {
				$correct[] = $id;
				if ( $w < 100 ) {
					$partial = true;
				}
			}
		}
		$partial = $partial && ! array_filter( $items, static fn( $a ) => null !== $a['weight'] && $a['weight'] < 0 );
		$single  = 1 === count( $correct ) && 1 === count( array_filter( $items, static fn( $a ) => '=' === $a['mark'] ) );
		if ( $single ) {
			return array( 'record' => $rec + array( 'type' => 'single', 'payload' => array( 'options' => $opts ), 'key' => array( 'correct' => $correct[0] ) ), 'error' => null, 'warnings' => $warn );
		}
		$key = array( 'correct' => $correct );
		if ( $partial ) {
			$key['scoring'] = 'partial';
		}
		return array( 'record' => $rec + array( 'type' => 'multiple', 'payload' => array( 'options' => $opts ), 'key' => $key ), 'error' => null, 'warnings' => $warn );
	}

	/** Split an answer block into =/~ items. @return array<int,array{mark:string,weight:?float,text:string,raw:string,feedback:bool}> */
	private static function split( string $ans ): array {
		$items = array();
		$cur   = null;
		$n     = strlen( $ans );
		$buf   = '';
		$mark  = '';
		for ( $i = 0; $i <= $n; $i++ ) {
			$ch = $i < $n ? $ans[ $i ] : null;
			if ( '\\' === $ch && $i + 1 < $n ) {
				$buf .= $ch . $ans[ $i + 1 ];
				++$i;
				continue;
			}
			if ( null === $ch || '=' === $ch || '~' === $ch ) {
				if ( '' !== $mark || '' !== trim( $buf ) ) {
					// "->" contains no = / ~, so matching survives; a lone leading text without mark is "=".
					$items[] = array( $mark ?: '=', $buf );
				}
				$mark = (string) $ch;
				$buf  = '';
				continue;
			}
			$buf .= $ch;
		}
		$out = array();
		foreach ( $items as [ $m, $b ] ) {
			$b      = trim( $b );
			$weight = null;
			if ( preg_match( '/^%(-?[\d.]+)%/', $b, $mm ) ) {
				$weight = (float) $mm[1];
				$b      = substr( $b, strlen( $mm[0] ) );
			}
			$b   = (string) preg_replace( '/^\[(html|moodle|plain|markdown)\]/', '', ltrim( $b ) );
			$fb  = self::find( $b, '#' );
			$raw = $fb >= 0 ? substr( $b, 0, $fb ) : $b;
			$out[] = array( 'mark' => $m, 'weight' => $weight, 'text' => self::unescape( $raw ), 'raw' => $raw, 'feedback' => $fb >= 0 );
		}
		return $out;
	}

	/** @param string[] $skipped receives "external_id: reason" for records GIFT cannot represent */
	public static function write( array $records, array &$skipped ): string {
		$out = "// EduCore question export (GIFT)\n\n";
		foreach ( $records as $r ) {
			$t    = $r['type'];
			$stem = '[html]' . self::escape( (string) $r['stem'] );
			$body = null;
			switch ( $t ) {
				case 'single':
				case 'multiple':
					$correct = (array) $r['key']['correct'];
					$parts   = array();
					$n       = count( $correct );
					foreach ( $r['payload']['options'] as $o ) {
						$txt = self::escape( html_entity_decode( wp_strip_all_tags( (string) $o['text'] ), ENT_QUOTES, 'UTF-8' ) );
						if ( 'single' === $t ) {
							$parts[] = ( in_array( $o['id'], $correct, true ) ? '=' : '~' ) . $txt;
						} else {
							$partial = 'partial' === ( $r['key']['scoring'] ?? '' );
							$w       = in_array( $o['id'], $correct, true ) ? self::pct( 100 / $n ) : ( $partial ? '0' : self::pct( -100 / max( 1, count( $r['payload']['options'] ) - $n ) ) );
							$parts[] = '~%' . $w . '%' . $txt;
						}
					}
					$body = implode( ' ', $parts );
					break;
				case 'truefalse':
					$body = ! empty( $r['key']['correct'] ) ? 'TRUE' : 'FALSE';
					break;
				case 'short':
					$body = implode( ' ', array_map( static fn( $a ) => '=' . self::escape( (string) $a ), (array) $r['key']['accepted'] ) );
					break;
				case 'essay':
					$body = '';
					break;
				case 'matching':
					$right = array();
					foreach ( $r['payload']['right'] as $x ) {
						$right[ $x['id'] ] = html_entity_decode( wp_strip_all_tags( (string) $x['text'] ), ENT_QUOTES, 'UTF-8' );
					}
					$parts = array();
					foreach ( $r['payload']['left'] as $l ) {
						$parts[] = '=' . self::escape( html_entity_decode( wp_strip_all_tags( (string) $l['text'] ), ENT_QUOTES, 'UTF-8' ) ) . ' -> ' . self::escape( $right[ $r['key']['pairs'][ $l['id'] ] ] ?? '' );
					}
					$body = implode( ' ', $parts );
					break;
			}
			if ( null === $body ) {
				/* translators: %s: question type */
				$skipped[] = $r['external_id'] . ': ' . sprintf( __( '%s questions cannot be represented in GIFT', 'educore-assessments' ), $t );
				continue;
			}
			if ( '' !== (string) $r['explanation'] ) {
				$body .= ' ####[html]' . self::escape( (string) $r['explanation'] );
			}
			$out .= '::' . self::escape( $r['external_id'] ) . '::' . $stem . ' {' . $body . "}\n\n";
		}
		return $out;
	}

	private static function pct( float $v ): string {
		return rtrim( rtrim( number_format( $v, 5, '.', '' ), '0' ), '.' );
	}
}
