=== EduCore Teaching & Tutoring Hub ===
Contributors: gorgyorg
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.1.0
License: GPLv2 or later

Teachers, instructors and tutors for EduCore: classes, groups, lesson planning, assignments, attendance, grading center, private tutoring with conflict-free booking, safeguarded communication and teaching analytics.

== Description ==
* One account can be teacher, instructor and tutor; permissions are capability- and object-scoped.
* Frontend workspace at /teaching-hub/ (role-aware navigation, works without JavaScript).
* Assignments with rubrics, partial credit, late rules, resubmission, private file store, auditable grade changes and explicit release.
* Attendance for classes and tutoring sessions with audited changes and CSV export.
* Private tutoring: admin-approved profiles, weekly availability, atomic slot locking, guardian authorisation for minors.
* Safeguarding: no free 1:1 messaging; context-bound conversations, guardian visibility, concern reports, audited reviewer access.
* Attention Center: configurable, explainable alerts. Teaching analytics separates workload from delivery indicators.
* Uses EduCore Core enrolment, Assessments grading queue, Notifications queue and Analytics XLSX export — no duplicate stores.

== Changelog ==
= 1.1.0 =
* First release.
