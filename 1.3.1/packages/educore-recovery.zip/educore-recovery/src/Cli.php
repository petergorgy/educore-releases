<?php
namespace EduCore\Recovery;

defined( 'ABSPATH' ) || exit;

/**
 * Manage EduCore backups.
 */
final class Cli {

	/**
	 * Create and verify a backup.
	 *
	 * [--kind=<kind>]
	 * : full, academic, configuration or predeploy. Default: academic.
	 *
	 * @param array $args
	 * @param array $assoc
	 */
	public function create( $args, $assoc ): void {
		$id = Backup::create( $assoc['kind'] ?? 'academic', 'manual' );
		if ( is_wp_error( $id ) ) {
			\WP_CLI::error( $id->get_error_message() );
		}
		$v = Verifier::verify( $id );
		$b = Backup::get( $id );
		$v['ok'] ? \WP_CLI::success( "Backup {$b->uid} ({$b->file}, " . size_format( (float) $b->size ) . ") created and verified ({$v['checked']} entries)." ) : \WP_CLI::error( implode( '; ', $v['errors'] ) );
	}

	/**
	 * List backups.
	 *
	 * [--format=<format>]
	 * : table, json, csv. Default: table.
	 *
	 * @subcommand list
	 * @param array $args
	 * @param array $assoc
	 */
	public function list_( $args, $assoc ): void {
		$rows = array_map( static fn( $b ) => array( 'id' => $b->id, 'uid' => $b->uid, 'kind' => $b->kind, 'trigger' => $b->trigger_source, 'status' => $b->status, 'size' => $b->size, 'encrypted' => $b->encrypted, 'verify' => $b->verify_status, 'restore_test' => $b->restore_test_status, 'created_at' => $b->created_at ), Backup::list( 200 ) );
		\WP_CLI\Utils\format_items( $assoc['format'] ?? 'table', $rows, array( 'id', 'uid', 'kind', 'trigger', 'status', 'size', 'encrypted', 'verify', 'restore_test', 'created_at' ) );
	}

	private function find( string $uid ): object {
		$b = Backup::by_uid( $uid );
		if ( ! $b ) {
			\WP_CLI::error( "No backup {$uid}." );
		}
		return $b;
	}

	/**
	 * Verify a backup's checksums.
	 *
	 * <uid>
	 * : Backup ID.
	 *
	 * @param array $args
	 */
	public function verify( $args ): void {
		$v = Verifier::verify( (int) $this->find( $args[0] )->id );
		$v['ok'] ? \WP_CLI::success( "Verified {$v['checked']} entries." ) : \WP_CLI::error( implode( '; ', $v['errors'] ) );
	}

	/**
	 * Non-destructive restore test into isolated tables.
	 *
	 * <uid>
	 * : Backup ID.
	 *
	 * @subcommand restore-test
	 * @param array $args
	 */
	public function restore_test( $args ): void {
		$t = RestoreTest::run( (int) $this->find( $args[0] )->id );
		foreach ( (array) ( $t['report']['tables'] ?? array() ) as $name => $r ) {
			\WP_CLI::log( sprintf( '%-40s %8d / %8d %s', $name, $r['restored'], $r['expected'], $r['match'] ? 'OK' : 'MISMATCH' ) );
		}
		$t['ok'] ? \WP_CLI::success( "Restore test passed in {$t['report']['seconds']} s." ) : \WP_CLI::error( implode( '; ', (array) $t['report']['errors'] ) );
	}

	/**
	 * Restore a backup into THIS site (destructive; a safety snapshot is taken first).
	 *
	 * <uid>
	 * : Backup ID.
	 *
	 * --confirm=<phrase>
	 * : Must be exactly "RESTORE <uid>".
	 *
	 * [--uploads]
	 * : Also restore uploaded files from a full backup.
	 *
	 * @param array $args
	 * @param array $assoc
	 */
	public function restore( $args, $assoc ): void {
		$b = $this->find( $args[0] );
		$r = Restore::run( (int) $b->id, array( 'confirm' => (string) ( $assoc['confirm'] ?? '' ), 'uploads' => ! empty( $assoc['uploads'] ) ) );
		if ( ! $r['ok'] ) {
			\WP_CLI::error( implode( ' ', $r['errors'] ) );
		}
		\WP_CLI::success( sprintf( 'Restored %d tables / %d rows / %d files in %s s; verified. Safety snapshot id: %d.', $r['report']['tables'], $r['report']['rows'], $r['report']['files'], $r['report']['seconds'], $r['safety'] ) );
	}

	/**
	 * Import a backup file (copied from elsewhere) into this site's backup storage.
	 *
	 * <file>
	 * : Path to an educore-*.zip or .zip.enc file.
	 *
	 * @param array $args
	 */
	public function import( $args ): void {
		$r = Importer::import( $args[0] );
		is_wp_error( $r ) ? \WP_CLI::error( $r->get_error_message() ) : \WP_CLI::success( "Imported as backup id {$r}. Verify it, then restore-test or restore." );
	}

	/**
	 * Encrypt archives created before encryption was enabled (verified before and after).
	 *
	 * @subcommand encrypt-existing
	 * @param array $args
	 */
	public function encrypt_existing( $args ): void {
		[ $ok, $bad, $msgs ] = Store::encrypt_existing();
		foreach ( $msgs as $m ) {
			\WP_CLI::warning( $m );
		}
		$bad ? \WP_CLI::error( "{$ok} encrypted, {$bad} left unchanged." ) : \WP_CLI::success( "{$ok} backups encrypted and re-verified." );
	}

	/**
	 * Show encryption key status (never the key itself).
	 *
	 * @subcommand key-status
	 * @param array $args
	 */
	public function key_status( $args ): void {
		\WP_CLI::log( 'source: ' . Settings::key_source() . '; key id: ' . ( Settings::key_id() ?: '-' ) . '; offline copy: ' . ( get_option( 'educore_rc_key_downloaded' ) ? 'downloaded' : 'not downloaded' ) . '; unencrypted archives: ' . Store::unencrypted_count() );
	}

	/**
	 * Run due schedules and retention now.
	 *
	 * @param array $args
	 */
	public function run( $args ): void {
		\WP_CLI::log( implode( "\n", Scheduler::run_due( 'cli' ) ) );
	}
}
