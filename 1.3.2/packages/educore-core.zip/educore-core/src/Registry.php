<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Registry of loaded EduCore packages, used for graceful degradation checks. */
final class Registry {
	/** @var array<string,string> */
	private static array $packages = array();

	public static function register( string $package, string $version ): void {
		self::$packages[ $package ] = $version;
	}

	public static function has( string $package ): bool {
		return isset( self::$packages[ $package ] );
	}

	/** @return array<string,string> */
	public static function all(): array {
		return self::$packages;
	}
}
