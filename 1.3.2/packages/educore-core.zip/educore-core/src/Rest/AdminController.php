<?php
namespace EduCore\Core\Rest;

use EduCore\Core\Audit;
use EduCore\Core\Curriculum;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/** Programme/curriculum structure, staff assignment and audit (manager/admin). */
final class AdminController {

	public static function routes(): void {
		register_rest_route(
			Routes::NS,
			'/programmes',
			array(
				array( 'methods' => 'GET', 'callback' => array( self::class, 'programmes' ), 'permission_callback' => array( Routes::class, 'logged_in' ) ),
				array(
					'methods'             => 'POST',
					'callback'            => array( self::class, 'create_programme' ),
					'permission_callback' => static fn() => current_user_can( 'ec_manage_programmes' ),
					'args'                => array(
						'code'    => array( 'type' => 'string', 'required' => true ),
						'name'    => array( 'type' => 'string', 'required' => true ),
						'country' => array( 'type' => 'string', 'default' => 'EG' ),
					),
				),
			)
		);
		register_rest_route(
			Routes::NS,
			'/courses/(?P<id>\d+)/staff',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'assign_staff' ),
				'permission_callback' => static fn() => current_user_can( 'ec_manage_all_courses' ),
				'args'                => array(
					'id'      => Routes::id_arg(),
					'user_id' => Routes::id_arg(),
					'role'    => array( 'type' => 'string', 'enum' => array_merge( Staff::ROLES, array( 'remove' ) ), 'required' => true ),
				),
			)
		);
		register_rest_route(
			Routes::NS,
			'/audit',
			array(
				'methods'             => 'GET',
				'callback'            => static fn( \WP_REST_Request $r ) => new \WP_REST_Response( Audit::query( $r->get_params() ) ),
				'permission_callback' => static fn() => current_user_can( 'ec_view_audit_log' ),
				'args'                => array(
					'action'   => array( 'type' => 'string' ),
					'page'     => array( 'type' => 'integer', 'default' => 1 ),
					'per_page' => array( 'type' => 'integer', 'default' => 50, 'maximum' => 200 ),
				),
			)
		);
	}

	public static function programmes(): \WP_REST_Response {
		$out = array();
		foreach ( Curriculum::programmes() as $p ) {
			$p['periods']  = Curriculum::periods( (int) $p['id'] );
			$p['subjects'] = Curriculum::subjects( (int) $p['id'] );
			$out[]         = $p;
		}
		return new \WP_REST_Response( $out );
	}

	public static function create_programme( \WP_REST_Request $r ) {
		$id = Curriculum::create_programme( (string) $r['code'], (string) $r['name'], (string) $r['country'] );
		return is_wp_error( $id ) ? $id : new \WP_REST_Response( array( 'id' => $id ), 201 );
	}

	public static function assign_staff( \WP_REST_Request $r ) {
		if ( 'remove' === $r['role'] ) {
			Staff::remove( (int) $r['id'], (int) $r['user_id'] );
			return new \WP_REST_Response( array( 'removed' => true ) );
		}
		$u = get_userdata( (int) $r['user_id'] );
		if ( ! $u || ! user_can( $u, 'ec_access_workspace' ) ) {
			return Routes::error( 'educore_not_staff', __( 'User must have an Instructor, Grader or Academic Manager role.', 'educore-core' ), 400 );
		}
		return Staff::assign( (int) $r['id'], (int) $r['user_id'], (string) $r['role'] )
			? new \WP_REST_Response( array( 'assigned' => true ) )
			: Routes::error( 'educore_failed', __( 'Assignment failed.', 'educore-core' ), 400 );
	}
}
