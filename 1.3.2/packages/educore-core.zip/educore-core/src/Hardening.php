<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Public-surface hardening (1.1.0): security headers, no username disclosure to anonymous
 * visitors (REST users, author archives, oEmbed, sitemaps) and a debug-display health check.
 */
final class Hardening {

	public static function register(): void {
		add_action( 'send_headers', array( self::class, 'headers' ) );
		add_filter( 'rest_endpoints', array( self::class, 'rest_endpoints' ) );
		add_action( 'template_redirect', array( self::class, 'block_author_enumeration' ), 1 );
		add_filter( 'oembed_response_data', array( self::class, 'oembed' ) );
		add_filter( 'wp_sitemaps_add_provider', static fn( $provider, $name ) => 'users' === $name ? false : $provider, 10, 2 );
		add_filter( 'educore/install/checks', array( self::class, 'checks' ) );
		add_filter( 'login_redirect', array( self::class, 'login_redirect' ), 20, 3 );
		add_filter( 'show_admin_bar', array( self::class, 'admin_bar' ) );
		add_action( 'admin_init', array( self::class, 'keep_learners_out_of_admin' ), 1 );
		// admin_menu fires before core's "not allowed to access this page" check, so learners are redirected
		// to My learning instead of meeting a bare WordPress 403 on screens such as plugins.php.
		add_action( 'admin_menu', array( self::class, 'keep_learners_out_of_admin' ), 0 );
	}

	/** Learners and guardians have no back-office role: no wp-admin, no toolbar. */
	public static function is_learner( $user ): bool {
		return $user instanceof \WP_User && $user->exists() && ! user_can( $user, 'edit_posts' ) && ! user_can( $user, 'ec_access_workspace' ) && ! user_can( $user, 'manage_options' );
	}

	/** After login, learners land on "My learning" (unless a specific front-end page was requested). */
	public static function login_redirect( $redirect_to, $requested, $user ) {
		if ( ! self::is_learner( $user ) ) {
			return $redirect_to;
		}
		$admin = (string) admin_url();
		if ( '' === (string) $requested || 0 === strpos( (string) $redirect_to, $admin ) ) {
			return Pages::url( 'dashboard' );
		}
		return $redirect_to;
	}

	public static function admin_bar( $show ) {
		return self::is_learner( wp_get_current_user() ) ? false : $show;
	}

	public static function keep_learners_out_of_admin(): void {
		if ( wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( sanitize_text_field( wp_unslash( $_SERVER['SCRIPT_NAME'] ) ) ) : '';
		if ( 'admin-post.php' === $script || ! self::is_learner( wp_get_current_user() ) ) {
			return;
		}
		wp_safe_redirect( Pages::url( 'dashboard' ) );
		exit;
	}

	public static function headers(): void {
		if ( headers_sent() || 'off' === get_option( 'educore_security_headers', 'on' ) ) {
			return;
		}
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()' );
	}

	/** Anonymous visitors cannot list users or read a user record (logged-in editors keep core behaviour). */
	public static function rest_endpoints( array $endpoints ): array {
		if ( is_user_logged_in() ) {
			return $endpoints;
		}
		foreach ( array_keys( $endpoints ) as $route ) {
			if ( 0 === strpos( $route, '/wp/v2/users' ) ) {
				unset( $endpoints[ $route ] );
			}
		}
		return $endpoints;
	}

	public static function block_author_enumeration(): void {
		if ( is_user_logged_in() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing check.
		if ( is_author() || isset( $_GET['author'] ) ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
		}
	}

	public static function oembed( $data ) {
		if ( is_array( $data ) ) {
			unset( $data['author_name'], $data['author_url'] );
		}
		return $data;
	}

	/** @param array<int,array<string,mixed>> $checks */
	public static function checks( array $checks ): array {
		$display  = defined( 'WP_DEBUG_DISPLAY' ) ? (bool) WP_DEBUG_DISPLAY : true;
		$checks[] = array(
			'label'   => 'Debug display',
			'status'  => $display ? 'warn' : 'pass',
			'message' => __( 'Set define( \'WP_DEBUG_DISPLAY\', false ); in wp-config.php so PHP errors can never be shown to visitors.', 'educore-core' ),
		);
		return $checks;
	}
}
