<?php
namespace EduCore\Assessments;

use EduCore\Core\Access;
use EduCore\Core\Frontend\Views;

defined( 'ABSPATH' ) || exit;

/** Learner-facing rendering: assessment player block, course assessment list, quick practice. */
final class Frontend {

	public static function register(): void {
		add_filter( 'educore/blocks', array( self::class, 'blocks' ) );
		add_filter( 'educore/lesson/after_content', array( self::class, 'lesson_after' ), 10, 3 );
		add_filter( 'educore/course/after_details', array( self::class, 'course_after' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( self::class, 'assets' ) );
	}

	public static function assets(): void {
		wp_register_style( 'educore-assessments', EDUCORE_ASSESSMENTS_URL . 'assets/css/assessments.css', array( 'educore-core' ), EDUCORE_ASSESSMENTS_VERSION );
		wp_register_script( 'educore-assessments', EDUCORE_ASSESSMENTS_URL . 'assets/js/player.js', array( 'educore-core' ), EDUCORE_ASSESSMENTS_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script(
			'educore-assessments',
			'EduCoreAssess',
			array(
				'i18n' => array(
					'start'        => __( 'Start', 'educore-assessments' ),
					'resume'       => __( 'Resume attempt', 'educore-assessments' ),
					'submit'       => __( 'Submit answers', 'educore-assessments' ),
					'confirm'      => __( 'Submit your answers now? You cannot change them afterwards.', 'educore-assessments' ),
					/* translators: %d: number of unanswered questions */
					'unanswered'   => __( 'You have %d unanswered question(s).', 'educore-assessments' ),
					'saved'        => __( 'All changes saved', 'educore-assessments' ),
					'saving'       => __( 'Saving…', 'educore-assessments' ),
					'offline'      => __( 'Not saved — check your connection. We will retry.', 'educore-assessments' ),
					'timeLeft'     => __( 'Time left', 'educore-assessments' ),
					'fiveMin'      => __( '5 minutes left.', 'educore-assessments' ),
					'oneMin'       => __( '1 minute left.', 'educore-assessments' ),
					'timeUp'       => __( 'Time is up — submitting your answers.', 'educore-assessments' ),
					/* translators: 1: question number, 2: total questions */
					'question'     => __( 'Question %1$d of %2$d', 'educore-assessments' ),
					/* translators: %s: points */
					'points'       => __( '%s pt', 'educore-assessments' ),
					'true'         => __( 'True', 'educore-assessments' ),
					'false'        => __( 'False', 'educore-assessments' ),
					/* translators: %d: blank number */
					'blank'        => __( 'Blank %d', 'educore-assessments' ),
					'choose'       => __( 'Choose…', 'educore-assessments' ),
					'up'           => __( 'Move up', 'educore-assessments' ),
					'down'         => __( 'Move down', 'educore-assessments' ),
					'output'       => __( 'What does this code print?', 'educore-assessments' ),
					'submitted'    => __( 'Your answers were submitted.', 'educore-assessments' ),
					'awaiting'     => __( 'Your result will be available once it has been graded and released.', 'educore-assessments' ),
					/* translators: 1: score, 2: maximum score, 3: percent */
					'score'        => __( 'Score: %1$s / %2$s (%3$s%%)', 'educore-assessments' ),
					'passed'       => __( 'Passed', 'educore-assessments' ),
					'notPassed'    => __( 'Not passed yet', 'educore-assessments' ),
					'correct'      => __( 'Correct!', 'educore-assessments' ),
					'incorrect'    => __( 'Not quite.', 'educore-assessments' ),
					'partial'      => __( 'Partly correct.', 'educore-assessments' ),
					/* translators: %d: remaining tries */
					'triesLeft'    => __( 'Tries left: %d', 'educore-assessments' ),
					'check'        => __( 'Check answer', 'educore-assessments' ),
					'modelAnswer'  => __( 'Model answer', 'educore-assessments' ),
					'answer'       => __( 'Correct answer', 'educore-assessments' ),
					'explanation'  => __( 'Explanation', 'educore-assessments' ),
					'manualNote'   => __( 'Essay answers are not graded automatically — compare with the model answer.', 'educore-assessments' ),
					'yourAnswer'   => __( 'Your answer', 'educore-assessments' ),
					'feedback'     => __( 'Instructor feedback', 'educore-assessments' ),
					/* translators: %d: word count */
					'words'        => __( '%d words', 'educore-assessments' ),
				),
			)
		);
	}

	public static function blocks( array $blocks ): array {
		$blocks['assessment'] = array(
			'title'  => __( 'EduCore: Assessment', 'educore-assessments' ),
			'render' => array( self::class, 'render_block' ),
			'attrs'  => array( 'assessmentId' => array( 'type' => 'number', 'default' => 0 ) ),
		);
		return $blocks;
	}

	public static function summary_data( array $a, int $uid ): array {
		$attempts = Attempts::for_user( (int) $a['id'], $uid );
		$open     = Attempts::open_attempt( (int) $a['id'], $uid );
		$released = array_values( array_filter( $attempts, static fn( $x ) => (int) $x['released'] ) );
		$last     = $released ? end( $released ) : null;
		$can      = Attempts::can_take( $a, $uid );
		$rem      = Attempts::remaining( $a, $uid );
		return array(
			'id'           => (int) $a['id'],
			'title'        => $a['title'],
			'kind'         => $a['kind'],
			'instructions' => $a['settings']['instructions'],
			'duration'     => (int) $a['settings']['duration'],
			'attempts'     => (int) $a['settings']['attempts'],
			'used'         => count( $attempts ),
			'remaining'    => $rem,
			'open_attempt' => $open ? (int) $open['id'] : 0,
			'can_start'    => ! is_wp_error( $can ) && ( $open || null === $rem || $rem > 0 ),
			'blocked'      => is_wp_error( $can ) ? $can->get_error_message() : '',
			'closes_at'    => Assessments::to_iso( $a['settings']['closes_at'] ),
			'opens_at'     => Assessments::to_iso( $a['settings']['opens_at'] ),
			'closes_local' => Assessments::format_local( $a['settings']['closes_at'] ),
			'opens_local'  => Assessments::format_local( $a['settings']['opens_at'] ),
			'pass_mark'    => (float) $a['settings']['pass_mark'],
			'last_result'  => $last ? array_merge( Attempts::result( $last, $a ), array( 'attempt_id' => (int) $last['id'] ) ) : null,
			'pending'      => count( array_filter( $attempts, static fn( $x ) => in_array( $x['state'], array( 'submitted', 'graded' ), true ) && ! (int) $x['released'] ) ),
		);
	}

	public static function render_block( array $attrs = array() ): string {
		$id = (int) ( $attrs['assessmentId'] ?? 0 );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only selection.
		if ( ! $id && isset( $_GET['ec_assessment'] ) ) {
			$id = absint( $_GET['ec_assessment'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
		return self::player( $id );
	}

	public static function player( int $id ): string {
		$a   = $id ? Assessments::get( $id ) : null;
		$uid = get_current_user_id();
		if ( ! $a || 'published' !== $a['status'] ) {
			return '';
		}
		if ( ! $uid ) {
			return Views::notice( __( 'Log in to take this assessment.', 'educore-assessments' ), 'info' );
		}
		if ( ! Access::can_access_course( $uid, (int) $a['course_id'] ) ) {
			return Views::notice( __( 'Enroll in the course to take this assessment.', 'educore-assessments' ), 'info' );
		}
		wp_enqueue_style( 'educore-assessments' );
		wp_enqueue_script( 'educore-assessments' );
		$s     = self::summary_data( $a, $uid );
		$kinds = array( 'practice' => __( 'Practice', 'educore-assessments' ), 'quiz' => __( 'Quiz', 'educore-assessments' ), 'exam' => __( 'Examination', 'educore-assessments' ) );
		$out   = '<section class="ec-assess ec-card" id="ec-assessment-' . esc_attr( (string) $id ) . '" data-ec-assessment="' . esc_attr( (string) $id ) . '" aria-labelledby="ec-as-h-' . esc_attr( (string) $id ) . '">';
		$out  .= '<header class="ec-assess__head"><p class="ec-course-card__eyebrow">' . esc_html( $kinds[ $a['kind'] ] ?? '' ) . '</p><h2 id="ec-as-h-' . esc_attr( (string) $id ) . '">' . esc_html( $a['title'] ) . '</h2><p class="ec-chips">';
		if ( $s['duration'] ) {
			/* translators: %d: minutes */
			$out .= '<span class="ec-chip">' . esc_html( sprintf( __( '%d minutes', 'educore-assessments' ), $s['duration'] ) ) . '</span>';
		}
		/* translators: 1: used, 2: allowed */
		$out .= '<span class="ec-chip">' . esc_html( $s['attempts'] ? sprintf( __( 'Attempts: %1$d of %2$d', 'educore-assessments' ), $s['used'], $s['attempts'] ) : __( 'Unlimited attempts', 'educore-assessments' ) ) . '</span>';
		/* translators: %s: pass mark */
		$out .= '<span class="ec-chip">' . esc_html( sprintf( __( 'Pass mark %s%%', 'educore-assessments' ), number_format_i18n( $s['pass_mark'] ) ) ) . '</span>';
		if ( $s['opens_local'] && strtotime( (string) $a['settings']['opens_at'] . ' UTC' ) > time() ) {
			/* translators: %s: local date, time and timezone */
			$out .= '<span class="ec-chip">' . esc_html( sprintf( __( 'Opens %s', 'educore-assessments' ), $s['opens_local'] ) ) . '</span>';
		}
		if ( $s['closes_local'] ) {
			/* translators: %s: local date, time and timezone */
			$out .= '<span class="ec-chip">' . esc_html( sprintf( __( 'Closes %s', 'educore-assessments' ), $s['closes_local'] ) ) . '</span>';
		}
		$out .= '</p></header>';
		if ( $s['instructions'] ) {
			$out .= '<p>' . nl2br( esc_html( $s['instructions'] ) ) . '</p>';
		}
		if ( $s['last_result'] ) {
			$r = $s['last_result'];
			/* translators: 1: mark, 2: of, 3: percent */
			$out .= '<p class="ec-assess__last"><strong>' . esc_html( sprintf( __( 'Latest released result: %1$s / %2$s (%3$s%%)', 'educore-assessments' ), number_format_i18n( $r['mark'], 2 ), number_format_i18n( $r['mark_of'], 2 ), number_format_i18n( $r['percent'], 1 ) ) ) . '</strong> — ' . esc_html( $r['passed'] ? __( 'Passed', 'educore-assessments' ) : __( 'Not passed yet', 'educore-assessments' ) ) . ' <button type="button" class="ec-btn ec-btn--ghost ec-btn--sm" data-ec-review="' . esc_attr( (string) $r['attempt_id'] ) . '">' . esc_html__( 'Review', 'educore-assessments' ) . '</button></p>';
		}
		if ( $s['pending'] ) {
			$out .= Views::notice( __( 'A submitted attempt is awaiting grading or release.', 'educore-assessments' ), 'info' );
		}
		if ( $s['blocked'] ) {
			$out .= Views::notice( $s['blocked'], 'info' );
		} elseif ( $s['can_start'] ) {
			$label = $s['open_attempt'] ? __( 'Resume attempt', 'educore-assessments' ) : __( 'Start', 'educore-assessments' );
			$out  .= '<p><button type="button" class="ec-btn ec-btn--primary" data-ec-start="' . esc_attr( (string) $id ) . '">' . esc_html( $label ) . '</button></p>';
		} else {
			$out .= '<p class="ec-muted">' . esc_html__( 'You have used all attempts for this assessment.', 'educore-assessments' ) . '</p>';
		}
		$out .= '<div class="ec-assess__player" data-ec-player aria-live="polite"></div></section>';
		return $out;
	}

	/** Quick practice + linked quiz under lesson content. */
	public static function lesson_after( string $html, int $lesson_id, int $uid ): string {
		if ( ! $uid ) {
			return $html;
		}
		$linked = (int) get_post_meta( $lesson_id, '_ec_assessment_id', true );
		if ( $linked ) {
			$html .= self::player( $linked );
		}
		$items = Practice::lesson_items( $uid, $lesson_id );
		if ( ! $items ) {
			return $html;
		}
		wp_enqueue_style( 'educore-assessments' );
		wp_enqueue_script( 'educore-assessments' );
		$html .= '<section class="ec-practice ec-card" aria-labelledby="ec-practice-h"><h2 id="ec-practice-h">' . esc_html__( 'Quick practice', 'educore-assessments' ) . '</h2>';
		$html .= '<p class="ec-muted">' . esc_html__( 'Multiple-choice questions allow 3 tries, true/false 1 try and essays 1 submission. The answer is revealed afterwards.', 'educore-assessments' ) . '</p>';
		$html .= '<div data-ec-practice="' . esc_attr( wp_json_encode( $items ) ) . '"></div></section>';
		return $html;
	}

	public static function course_after( string $html, int $course_id ): string {
		$uid = get_current_user_id();
		if ( ! $uid || ! Access::can_access_course( $uid, $course_id ) ) {
			return $html;
		}
		$list = array_filter( Assessments::for_course( $course_id ), static fn( $a ) => 'practice' !== $a['kind'] );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$selected = isset( $_GET['ec_assessment'] ) ? absint( $_GET['ec_assessment'] ) : 0;
		if ( ! $list ) {
			return $html;
		}
		$html .= '<section class="ec-section" id="ec-assessments"><h2>' . esc_html__( 'Quizzes and examinations', 'educore-assessments' ) . '</h2><ul class="ec-assess-list">';
		foreach ( $list as $a ) {
			$s     = self::summary_data( $a, $uid );
			$meta  = $s['last_result'] ? sprintf( '%s%%', number_format_i18n( $s['last_result']['percent'], 1 ) ) : ( $s['closes_local'] ? sprintf( /* translators: %s: local date, time and timezone, e.g. "31 Oct 2026, 21:00 EET" */ __( 'Closes %s', 'educore-assessments' ), $s['closes_local'] ) : '' );
			$html .= '<li><a href="' . esc_url( add_query_arg( 'ec_assessment', (int) $a['id'], get_permalink( $course_id ) ) . '#ec-assessment-' . (int) $a['id'] ) . '">' . esc_html( $a['title'] ) . '</a> <span class="ec-muted">' . esc_html( $meta ) . '</span></li>';
		}
		$html .= '</ul>';
		if ( $selected ) {
			$a = Assessments::get( $selected );
			if ( $a && (int) $a['course_id'] === $course_id ) {
				$html .= self::player( $selected );
			}
		}
		return $html . '</section>';
	}
}
