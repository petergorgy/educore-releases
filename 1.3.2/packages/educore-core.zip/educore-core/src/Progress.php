<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Lesson progress. Completion follows the lesson's rule:
 *   manual  – learner marks complete
 *   view    – opening the lesson completes it
 *   time    – N seconds of measured active time
 *   other   – registered by packages via educore/progress/check_rule (e.g. assessment pass)
 */
final class Progress {
	public const HEARTBEAT_MAX = 120; // max seconds credited per heartbeat (idle cut-off).

	/**
	 * Daily activity log (one row per learner, course and UTC day). Accurate DAU/WAU/consistency
	 * independent of lesson_progress timestamps, which keep only first/last/completed.
	 */
	public static function log_activity( int $user_id, int $course_id ): void {
		global $wpdb;
		if ( $user_id <= 0 ) {
			return;
		}
		$wpdb->query( $wpdb->prepare( 'INSERT INTO ' . Schema::table( 'activity' ) . ' (user_id,course_id,day,events) VALUES (%d,%d,%s,1) ON DUPLICATE KEY UPDATE events = events + 1', $user_id, $course_id, gmdate( 'Y-m-d' ) ) );
	}

	public static function touch( int $user_id, int $lesson_id ): void {
		global $wpdb;
		$course_id = Content::course_of( $lesson_id );
		self::log_activity( $user_id, $course_id );
		$now       = Schema::now();
		$wpdb->query( $wpdb->prepare( 'INSERT INTO ' . Schema::table( 'lesson_progress' ) . " (user_id,lesson_id,course_id,state,first_seen_at,last_seen_at) VALUES (%d,%d,%d,'started',%s,%s) ON DUPLICATE KEY UPDATE last_seen_at = VALUES(last_seen_at)", $user_id, $lesson_id, $course_id, $now, $now ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( 'view' === self::rule( $lesson_id ) ) {
			self::complete( $user_id, $lesson_id, 'view' );
		}
	}

	public static function heartbeat( int $user_id, int $lesson_id, int $seconds ): int {
		global $wpdb;
		$seconds = max( 0, min( self::HEARTBEAT_MAX, $seconds ) );
		self::touch( $user_id, $lesson_id ); // touch() also logs daily activity.
		$t = Schema::table( 'lesson_progress' );
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET active_seconds = active_seconds + %d, last_seen_at = %s WHERE user_id=%d AND lesson_id=%d", $seconds, Schema::now(), $user_id, $lesson_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT active_seconds FROM {$t} WHERE user_id=%d AND lesson_id=%d", $user_id, $lesson_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( 'time' === self::rule( $lesson_id ) && $total >= (int) get_post_meta( $lesson_id, '_ec_completion_secs', true ) ) {
			self::complete( $user_id, $lesson_id, 'time' );
		}
		return $total;
	}

	public static function rule( int $lesson_id ): string {
		return (string) ( get_post_meta( $lesson_id, '_ec_completion_rule', true ) ?: 'manual' );
	}

	/**
	 * @param string $via manual|view|time|<package rule>
	 * @return bool|\WP_Error
	 */
	public static function complete( int $user_id, int $lesson_id, string $via = 'manual' ) {
		global $wpdb;
		$rule = self::rule( $lesson_id );
		if ( $via !== $rule && ! ( 'manual' === $via && 'manual' === $rule ) ) {
			$ok = apply_filters( 'educore/progress/check_rule', false, $rule, $user_id, $lesson_id, $via );
			if ( ! $ok ) {
				return new \WP_Error( 'educore_rule_not_met', __( 'This lesson is completed automatically when its requirement is met.', 'educore-core' ), array( 'status' => 409 ) );
			}
		}
		if ( self::is_complete( $user_id, $lesson_id ) ) {
			return true;
		}
		$course_id = Content::course_of( $lesson_id );
		$now       = Schema::now();
		$wpdb->query( $wpdb->prepare( 'INSERT INTO ' . Schema::table( 'lesson_progress' ) . " (user_id,lesson_id,course_id,state,first_seen_at,last_seen_at,completed_at) VALUES (%d,%d,%d,'completed',%s,%s,%s) ON DUPLICATE KEY UPDATE state='completed', completed_at=VALUES(completed_at)", $user_id, $lesson_id, $course_id, $now, $now, $now ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		do_action( 'educore/events/lesson_completed', $user_id, $lesson_id, $course_id );
		self::maybe_complete_course( $user_id, $course_id );
		return true;
	}

	public static function is_complete( int $user_id, int $lesson_id ): bool {
		global $wpdb;
		return 'completed' === $wpdb->get_var( $wpdb->prepare( 'SELECT state FROM ' . Schema::table( 'lesson_progress' ) . ' WHERE user_id=%d AND lesson_id=%d', $user_id, $lesson_id ) );
	}

	/** @return int[] completed lesson ids for a course */
	public static function completed_ids( int $user_id, int $course_id ): array {
		global $wpdb;
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT lesson_id FROM ' . Schema::table( 'lesson_progress' ) . " WHERE user_id=%d AND course_id=%d AND state='completed'", $user_id, $course_id ) ) );
	}

	/** @return array{completed:int,total:int,percent:int,next_lesson:int,active_seconds:int} */
	public static function course_summary( int $user_id, int $course_id ): array {
		global $wpdb;
		$ids       = Content::lesson_ids( $course_id );
		$completed = array_values( array_intersect( $ids, self::completed_ids( $user_id, $course_id ) ) );
		$next      = 0;
		foreach ( $ids as $id ) {
			if ( ! in_array( $id, $completed, true ) ) {
				$next = $id;
				break;
			}
		}
		$secs = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(active_seconds),0) FROM ' . Schema::table( 'lesson_progress' ) . ' WHERE user_id=%d AND course_id=%d', $user_id, $course_id ) );
		$total = count( $ids );
		return array(
			'completed'      => count( $completed ),
			'total'          => $total,
			'percent'        => $total ? (int) floor( count( $completed ) * 100 / $total ) : 0,
			'next_lesson'    => $next,
			'active_seconds' => $secs,
		);
	}

	/**
	 * Bulk progress for many learners of one course in two queries (no N+1).
	 *
	 * @param int[] $user_ids
	 * @return array<int,array{completed:int,total:int,percent:int}>
	 */
	public static function bulk_course_summary( int $course_id, array $user_ids ): array {
		global $wpdb;
		$lessons = Content::lesson_ids( $course_id );
		$total   = count( $lessons );
		$out     = array();
		foreach ( $user_ids as $u ) {
			$out[ (int) $u ] = array( 'completed' => 0, 'total' => $total, 'percent' => 0 );
		}
		if ( ! $total || ! $user_ids ) {
			return $out;
		}
		$u_in = implode( ',', array_map( 'intval', $user_ids ) );
		$l_in = implode( ',', array_map( 'intval', $lessons ) );
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT user_id, COUNT(*) n FROM ' . Schema::table( 'lesson_progress' ) . " WHERE course_id=%d AND state='completed' AND user_id IN ({$u_in}) AND lesson_id IN ({$l_in}) GROUP BY user_id", $course_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL -- integer lists.
		foreach ( $rows as $r ) {
			$n                              = (int) $r['n'];
			$out[ (int) $r['user_id'] ] = array( 'completed' => $n, 'total' => $total, 'percent' => (int) floor( $n * 100 / $total ) );
		}
		return $out;
	}

	public static function maybe_complete_course( int $user_id, int $course_id ): void {
		$s = self::course_summary( $user_id, $course_id );
		$e = Enrollment::get( $user_id, $course_id );
		if ( $s['total'] > 0 && $s['completed'] === $s['total'] && $e && 'active' === $e['status'] ) {
			$extra_ok = apply_filters( 'educore/progress/course_complete_ready', true, $user_id, $course_id );
			if ( $extra_ok ) {
				Enrollment::set_status( $user_id, $course_id, 'completed' );
				do_action( 'educore/events/course_completed', $user_id, $course_id );
			}
		}
	}

	/** Days (Y-m-d, UTC) with any learning activity in the last $days days. */
	public static function active_days( int $user_id, int $days = 28 ): array {
		global $wpdb;
		return $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT DATE(last_seen_at) d FROM ' . Schema::table( 'lesson_progress' ) . ' WHERE user_id=%d AND last_seen_at >= %s ORDER BY d DESC', $user_id, gmdate( 'Y-m-d', time() - $days * DAY_IN_SECONDS ) ) );
	}
}
