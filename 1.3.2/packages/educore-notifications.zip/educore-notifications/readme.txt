=== EduCore Notifications ===
Contributors: gorgyorg
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: lms, email, notifications, smtp

Reliable, queued e-mail notifications for EduCore in English, French and Arabic.

== Description ==

Part of the EduCore LMS (https://educore.gorgy.org), an initiative of GORGY.ORG.

* Persistent database queue with retries (5 min, 30 min, 2 h) and delivery log; a message is only marked "accepted by mail server" when the mailer actually accepted it.
* Events: enrollment, announcements, submissions, results, completion, certificates, guardian consent, access expiry, exam reminders, account security.
* Templates in English, French and Arabic (right-to-left), sent in each learner's language.
* SMTP settings for support@educore.gorgy.org; the password is stored encrypted and never shown.
* Learners can opt out of non-essential messages.

Requires EduCore Core. On cPanel, add a real cron job so the queue runs every 5 minutes.

== Installation ==

1. Install and activate EduCore Core first.
2. Upload and activate this plugin.
3. Run EduCore → Setup wizard → "Run database & roles setup".

== Changelog ==
= 1.1.0 =
* Templates filter (educore/notifications/templates) so other EduCore packages use the same queue.
* Delivery log explains status meanings; "accepted_by_mta" is never presented as inbox delivery.


= 1.0.0 =
* First release.
