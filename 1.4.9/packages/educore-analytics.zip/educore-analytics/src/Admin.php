<?php
namespace EduCore\Analytics;

use EduCore\Core\Curriculum;

defined( 'ABSPATH' ) || exit;

/** Analytics dashboards in the EduCore administration center. */
final class Admin {

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 20 );
		add_action( 'admin_enqueue_scripts', array( self::class, 'assets' ) );
	}

	public static function menu(): void {
		add_submenu_page( 'educore', __( 'Analytics', 'educore-analytics' ), __( 'Analytics', 'educore-analytics' ), 'ec_view_analytics', 'educore-analytics', array( self::class, 'page' ) );
	}

	public static function assets( string $hook ): void {
		if ( false === strpos( $hook, 'educore-analytics' ) ) {
			return; // Chart.js only on analytics screens.
		}
		wp_enqueue_style( 'educore-analytics', EDUCORE_ANALYTICS_URL . 'assets/css/analytics.css', array(), EDUCORE_ANALYTICS_VERSION );
		wp_enqueue_script( 'chartjs', EDUCORE_ANALYTICS_URL . 'assets/js/chart.umd.min.js', array(), '4.6.1', true );
		wp_enqueue_script( 'educore-analytics', EDUCORE_ANALYTICS_URL . 'assets/js/analytics.js', array( 'chartjs' ), EDUCORE_ANALYTICS_VERSION, true );
	}

	/** Overview tiles on the core Overview screen. */
	public static function overview_tiles( array $tiles ): array {
		global $wpdb;
		$uid = get_current_user_id();
		$f   = new Filters();
		$f->course_ids = Scope::courses_for( $uid );
		$backlog       = Metrics::grading_backlog( $f );
		if ( null !== $backlog ) {
			$tiles[ __( 'Pending grading', 'educore-analytics' ) ] = number_format_i18n( $backlog['count'] );
		}
		$jobs = \EduCore\Core\Schema::table( 'notification_jobs' );
		if ( user_can( $uid, 'ec_manage_settings' ) && AssessmentSource::has( 'notification_jobs', array( 'status', 'next_try_at' ) ) ) {
			$tiles[ __( 'Notification failures (7 days)', 'educore-analytics' ) ] = number_format_i18n( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$jobs} WHERE status='failed' AND next_try_at >= %s", gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		return $tiles;
	}

	private static function chart( string $id, string $type, array $labels, array $datasets, string $caption, array $headers ): string {
		$cfg = wp_json_encode( array( 'type' => $type, 'labels' => array_values( $labels ), 'datasets' => $datasets ) );
		$out = '<figure class="ec-chart"><figcaption>' . esc_html( $caption ) . '</figcaption><div class="ec-chart__canvas"><canvas id="' . esc_attr( $id ) . '" role="img" aria-label="' . esc_attr( $caption ) . '" data-ec-chart="' . esc_attr( (string) $cfg ) . '"></canvas></div>';
		$out .= '<details class="ec-chart__table"><summary>' . esc_html__( 'Data table', 'educore-analytics' ) . '</summary><table class="widefat striped"><thead><tr>';
		foreach ( $headers as $h ) {
			$out .= '<th scope="col">' . esc_html( $h ) . '</th>';
		}
		$out .= '</tr></thead><tbody>';
		foreach ( array_values( $labels ) as $i => $label ) {
			$out .= '<tr><th scope="row">' . esc_html( (string) $label ) . '</th>';
			foreach ( $datasets as $ds ) {
				$v    = $ds['data'][ $i ] ?? null;
				$out .= '<td>' . esc_html( null === $v ? '—' : (string) $v ) . '</td>';
			}
			$out .= '</tr>';
		}
		return $out . '</tbody></table></details></figure>';
	}

	private static function table( array $headers, array $rows ): string {
		if ( ! $rows ) {
			return '<p class="description">' . esc_html__( 'No data for this selection.', 'educore-analytics' ) . '</p>';
		}
		$out = '<table class="widefat striped"><thead><tr>';
		foreach ( $headers as $h ) {
			$out .= '<th scope="col">' . esc_html( $h ) . '</th>';
		}
		$out .= '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$out .= '<tr>';
			foreach ( $r as $cell ) {
				$out .= '<td>' . ( is_array( $cell ) ? $cell['html'] : esc_html( null === $cell ? '—' : (string) $cell ) ) . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput -- 'html' cells are built escaped below.
			}
			$out .= '</tr>';
		}
		return $out . '</tbody></table>';
	}

	private static function def( string $id ): string {
		$m = Dictionary::get( $id );
		return $m ? ' <abbr class="ec-def" title="' . esc_attr( $id . ': ' . $m['definition'] ) . '">ⓘ</abbr>' : '';
	}

	public static function page(): void {
		$uid = get_current_user_id();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filters.
		$in      = array_map( static fn( $v ) => sanitize_text_field( wp_unslash( $v ) ), array_intersect_key( $_GET, array_flip( array( 'from', 'to', 'course', 'programme', 'year' ) ) ) );
		$student = isset( $_GET['student'] ) ? absint( $_GET['student'] ) : 0;
		// phpcs:enable
		$f = Scope::apply( $uid, new Filters( $in ) );
		echo '<div class="wrap ec-admin ec-analytics"><h1>' . esc_html__( 'Learning analytics', 'educore-analytics' ) . '</h1>';
		if ( is_wp_error( $f ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( $f->get_error_message() ) . '</p></div></div>';
			return;
		}
		$allowed = Scope::courses_for( $uid );
		$course  = ( 1 === count( (array) $f->course_ids ) && ! empty( $in['course'] ) ) ? (int) $f->course_ids[0] : 0;

		// Filters.
		echo '<form method="get" class="ec-an-filters"><input type="hidden" name="page" value="educore-analytics">';
		echo '<label>' . esc_html__( 'From', 'educore-analytics' ) . ' <input type="date" name="from" value="' . esc_attr( $f->from ) . '"></label> ';
		echo '<label>' . esc_html__( 'To', 'educore-analytics' ) . ' <input type="date" name="to" value="' . esc_attr( $f->to ) . '"></label> ';
		echo '<label>' . esc_html__( 'Course', 'educore-analytics' ) . ' <select name="course"><option value="">' . esc_html__( 'All my courses', 'educore-analytics' ) . '</option>';
		foreach ( $allowed as $c ) {
			echo '<option value="' . esc_attr( (string) $c ) . '"' . selected( $course, $c, false ) . '>' . esc_html( get_the_title( $c ) ) . '</option>';
		}
		echo '</select></label> <label>' . esc_html__( 'Programme', 'educore-analytics' ) . ' <select name="programme"><option value="">' . esc_html__( 'All', 'educore-analytics' ) . '</option>';
		foreach ( Curriculum::programmes() as $p ) {
			echo '<option value="' . esc_attr( $p['id'] ) . '"' . selected( $f->programme_id, (int) $p['id'], false ) . '>' . esc_html( $p['name'] ) . '</option>';
		}
		echo '</select></label> <label>' . esc_html__( 'Academic year', 'educore-analytics' ) . ' <input name="year" size="10" value="' . esc_attr( $f->academic_year ) . '"></label> <button class="button button-primary">' . esc_html__( 'Apply', 'educore-analytics' ) . '</button></form>';

		if ( $student ) {
			self::student_view( $uid, $student, $f );
			echo '</div>';
			return;
		}

		// KPI tiles.
		$backlog = Metrics::grading_backlog( $f );
		$dist_f  = Metrics::score_distribution( $f );
		$tiles   = array(
			'A1' => array( __( 'Active enrollments', 'educore-analytics' ), number_format_i18n( Metrics::active_enrollments( $f ) ) ),
		);
		$part   = Metrics::participation( $f );
		$enr    = array_sum( wp_list_pluck( $part, 'enrolled' ) );
		$act    = array_sum( wp_list_pluck( $part, 'active' ) );
		$tiles['A2'] = array( __( 'Participation in range', 'educore-analytics' ), $enr ? round( $act * 100 / $enr, 1 ) . '%' : '—' );
		$tiles['A3'] = array( __( 'Course completions in range', 'educore-analytics' ), number_format_i18n( array_sum( wp_list_pluck( $part, 'completions' ) ) ) );
		if ( null !== $backlog ) {
			$tiles['I6'] = array( __( 'Pending grading', 'educore-analytics' ), number_format_i18n( $backlog['count'] ) . ( $backlog['oldest_hours'] ? ' · ' . sprintf( /* translators: %d hours */ __( 'oldest %dh', 'educore-analytics' ), $backlog['oldest_hours'] ) : '' ) );
		}
		echo '<div class="ec-tiles">';
		foreach ( $tiles as $id => [ $label, $value ] ) {
			echo '<div class="ec-tile"><span class="ec-tile__v">' . esc_html( (string) $value ) . '</span><span class="ec-tile__l">' . esc_html( $label ) . self::def( $id ) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- def() escapes.
		}
		echo '</div>';

		$export = static function ( string $type, Filters $f ) {
			return '<a class="button" href="' . esc_url( Export::url( $type, 'csv', $f ) ) . '">CSV</a> <a class="button" href="' . esc_url( Export::url( $type, 'xlsx', $f ) ) . '">XLSX</a>';
		};
		$can_export_course = $course && Scope::can_export( $uid, $course );

		if ( $course ) {
			$e = Metrics::engagement( $course, $f );
			echo '<h2>' . esc_html( get_the_title( $course ) ) . '</h2><div class="ec-tiles">';
			/* translators: 1: active, 2: enrolled */
			echo '<div class="ec-tile"><span class="ec-tile__v">' . esc_html( null === $e['rate_7'] ? '—' : $e['rate_7'] . '%' ) . '</span><span class="ec-tile__l">' . esc_html( sprintf( __( 'Engagement 7 days (%1$d of %2$d)', 'educore-analytics' ), $e['active_7'], $e['enrolled'] ) ) . self::def( 'I1' ) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			/* translators: 1: active, 2: enrolled */
			echo '<div class="ec-tile"><span class="ec-tile__v">' . esc_html( null === $e['rate_30'] ? '—' : $e['rate_30'] . '%' ) . '</span><span class="ec-tile__l">' . esc_html( sprintf( __( 'Engagement 30 days (%1$d of %2$d)', 'educore-analytics' ), $e['active_30'], $e['enrolled'] ) ) . self::def( 'I1' ) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			$imp = Metrics::course_improvement( $course, $f );
			if ( null !== $imp || \EduCore\Analytics\AssessmentSource::attempts_available() ) {
				echo '<div class="ec-tile"><span class="ec-tile__v">' . esc_html( null === $imp ? '—' : ( $imp > 0 ? '+' : '' ) . $imp ) . '</span><span class="ec-tile__l">' . esc_html__( 'Average score improvement (points)', 'educore-analytics' ) . self::def( 'I5' ) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</div>';

			$rates = Metrics::lesson_completion_rates( $course, $f );
			echo '<h3>' . esc_html__( 'Lesson completion rate', 'educore-analytics' ) . self::def( 'I2' ) . ( $can_export_course ? ' ' . $export( 'lesson_completion', $f ) : '' ) . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo self::chart( 'ec-lessons', 'bar', wp_list_pluck( $rates, 'lesson' ), array( array( 'label' => __( 'Completion %', 'educore-analytics' ), 'data' => wp_list_pluck( $rates, 'rate' ) ) ), __( 'Lesson completion rate (%)', 'educore-analytics' ), array( __( 'Lesson', 'educore-analytics' ), __( 'Completion %', 'educore-analytics' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput

			if ( null !== $dist_f ) {
				$labels = array();
				for ( $i = 0; $i < 10; $i++ ) {
					$labels[] = ( $i * 10 ) . '–' . ( 9 === $i ? 100 : $i * 10 + 9 );
				}
				echo '<h3>' . esc_html__( 'Score distribution', 'educore-analytics' ) . self::def( 'I3' ) . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
				echo self::chart( 'ec-dist', 'bar', $labels, array( array( 'label' => __( 'Attempts', 'educore-analytics' ), 'data' => $dist_f ) ), __( 'Scored attempts by percentage band', 'educore-analytics' ), array( __( 'Band %', 'educore-analytics' ), __( 'Attempts', 'educore-analytics' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
				$dq = (array) Metrics::difficult_questions( $f );
				echo '<h3>' . esc_html__( 'Difficult questions', 'educore-analytics' ) . self::def( 'I4' ) . ( $can_export_course ? ' ' . $export( 'difficult_questions', $f ) : '' ) . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
				echo self::table( array( __( 'Question', 'educore-analytics' ), __( 'Lesson', 'educore-analytics' ), __( 'Responses', 'educore-analytics' ), 'p' ), array_map( static fn( $q ) => array( '#' . $q['question_id'], $q['lesson_id'] ? get_the_title( $q['lesson_id'] ) : '', $q['responses'], $q['p'] ), $dq ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			}

			$risk = Metrics::at_risk( $course, $f );
			echo '<h3>' . esc_html__( 'At-risk learners', 'educore-analytics' ) . self::def( 'I7' ) . ( $can_export_course ? ' ' . $export( 'at_risk', $f ) : '' ) . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
			$reason_l = array( 'inactive_14d' => __( 'No activity 14 days', 'educore-analytics' ), 'low_progress' => __( 'Low progress', 'educore-analytics' ), 'low_scores' => __( 'Low scores', 'educore-analytics' ) );
			echo self::table( // phpcs:ignore WordPress.Security.EscapeOutput
				array( __( 'Learner', 'educore-analytics' ), __( 'Completion %', 'educore-analytics' ), __( 'Mean %', 'educore-analytics' ), __( 'Reasons', 'educore-analytics' ) ),
				array_map(
					static function ( $r ) use ( $uid, $course, $reason_l, $f ) {
						$name = current_user_can( 'ec_view_student', $r['user_id'] ) ? ( get_userdata( $r['user_id'] )->display_name ?? '#' . $r['user_id'] ) : '#' . $r['user_id'];
						$link = current_user_can( 'ec_view_student', $r['user_id'] ) ? array( 'html' => '<a href="' . esc_url( add_query_arg( array_merge( array( 'page' => 'educore-analytics', 'student' => $r['user_id'] ), $f->to_query_args() ), admin_url( 'admin.php' ) ) ) . '">' . esc_html( $name ) . '</a>' ) : $name;
						return array( $link, $r['completion'], $r['mean'], implode( ', ', array_map( static fn( $x ) => $reason_l[ $x ] ?? $x, $r['reasons'] ) ) );
					},
					$risk
				)
			);
			if ( $can_export_course ) {
				echo '<p>' . esc_html__( 'Learner report:', 'educore-analytics' ) . ' ' . $export( 'course_students', $f ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
		}

		// Cross-course / administrative views.
		echo '<h2>' . esc_html__( 'Course participation', 'educore-analytics' ) . self::def( 'A2' ) . ( Scope::can_export( $uid, $course ?: null ) ? ' ' . $export( 'participation', $f ) : '' ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::table( array( __( 'Course', 'educore-analytics' ), __( 'Enrolled', 'educore-analytics' ), __( 'Active', 'educore-analytics' ), __( 'Participation %', 'educore-analytics' ), __( 'Completions', 'educore-analytics' ) ), array_map( static fn( $r ) => array( $r['course'], $r['enrolled'], $r['active'], $r['participation'], $r['completions'] ), $part ) ); // phpcs:ignore WordPress.Security.EscapeOutput

		$trend = Metrics::completion_trend( $f );
		echo '<h2>' . esc_html__( 'Completion trend', 'educore-analytics' ) . self::def( 'A3' ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::chart( 'ec-trend', 'line', array_keys( $trend ), array( array( 'label' => __( 'Completions', 'educore-analytics' ), 'data' => array_values( $trend ) ) ), __( 'Course completions per month', 'educore-analytics' ), array( __( 'Month', 'educore-analytics' ), __( 'Completions', 'educore-analytics' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput

		$days = ( strtotime( $f->to ) - strtotime( $f->from ) ) / DAY_IN_SECONDS;
		if ( $days <= 120 ) {
			$unfiltered = Scope::is_global( $uid ) && empty( $in['course'] ) && ! $f->has_cohort();
			$dau        = Aggregator::series( 'dau', $f, $unfiltered );
			$wau        = Aggregator::series( 'wau', $f, $unfiltered );
			echo '<h2>' . esc_html__( 'Platform engagement', 'educore-analytics' ) . self::def( 'A7' ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo self::chart( 'ec-dau', 'line', array_keys( $dau ), array( array( 'label' => 'DAU', 'data' => array_values( $dau ) ), array( 'label' => 'WAU', 'data' => array_values( $wau ) ) ), __( 'Daily and weekly active learners', 'educore-analytics' ), array( __( 'Day', 'educore-analytics' ), 'DAU', 'WAU' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		} else {
			echo '<p class="description">' . esc_html__( 'Choose a range of 120 days or less to see daily engagement.', 'educore-analytics' ) . '</p>';
		}

		if ( Scope::is_global( $uid ) ) {
			echo '<h2>' . esc_html__( 'Cohort comparison', 'educore-analytics' ) . self::def( 'A4' ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput
			foreach ( array( 'programme' => __( 'By programme', 'educore-analytics' ), 'year' => __( 'By academic year', 'educore-analytics' ) ) as $by => $label ) {
				echo '<h3>' . esc_html( $label ) . '</h3>' . self::table( array( __( 'Cohort', 'educore-analytics' ), __( 'Learners', 'educore-analytics' ), __( 'Mean completion %', 'educore-analytics' ) ), array_map( static fn( $r ) => array( $r['label'], $r['learners'], $r['mean_completion'] ), Metrics::cohorts( $f, $by ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			$q = Metrics::assessment_quality( $f );
			if ( null !== $q ) {
				echo '<h2>' . esc_html__( 'Assessment quality', 'educore-analytics' ) . self::def( 'A5' ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput
				echo self::table( array( __( 'Question', 'educore-analytics' ), __( 'Responses', 'educore-analytics' ), 'p', __( 'Flag', 'educore-analytics' ) ), array_map( static fn( $r ) => array( '#' . $r['question_id'], $r['responses'], $r['p'], 'too_hard' === $r['flag'] ? __( 'Too hard', 'educore-analytics' ) : __( 'Too easy', 'educore-analytics' ) ), $q ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '<h2>' . esc_html__( 'Content never opened', 'educore-analytics' ) . self::def( 'A6' ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo self::table( array( __( 'Lesson', 'educore-analytics' ), __( 'Course', 'educore-analytics' ) ), array_map( static fn( $r ) => array( $r['lesson'], $r['course'] ), Metrics::unused_lessons( $f ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		}

		if ( null === Metrics::score_distribution( $f ) ) {
			echo '<p class="description">' . esc_html__( 'Assessment metrics are hidden because EduCore Assessments is not active.', 'educore-analytics' ) . '</p>';
		}
		echo '<details class="ec-dictionary"><summary>' . esc_html__( 'Metric definitions', 'educore-analytics' ) . '</summary><dl>';
		foreach ( Dictionary::all() as $id => $m ) {
			echo '<dt><strong>' . esc_html( $id . ' — ' . $m['name'] ) . '</strong></dt><dd>' . esc_html( $m['definition'] . ' Formula: ' . $m['formula'] . '.' ) . '</dd>';
		}
		echo '</dl></details></div>';
	}

	private static function student_view( int $viewer, int $student, Filters $f ): void {
		if ( ! current_user_can( 'ec_view_student', $student ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'You cannot view this learner.', 'educore-analytics' ) . '</p></div>';
			return;
		}
		$u = get_userdata( $student );
		/* translators: %s: learner name */
		echo '<h2>' . esc_html( sprintf( __( 'Learner: %s', 'educore-analytics' ), $u ? $u->display_name : '#' . $student ) ) . '</h2>';
		$c   = Metrics::consistency( $student, $f );
		$p   = Metrics::pending_activities( $student, $f );
		$num = static fn( $v ) => null === $v ? '—' : (string) $v;
		echo '<div class="ec-tiles">';
		foreach ( array( 'S3' => array( __( 'Assessment mean %', 'educore-analytics' ), $num( Metrics::assessment_mean( $student, $f ) ) ), 'S4' => array( __( 'Score improvement', 'educore-analytics' ), $num( Metrics::score_improvement( $student, $f ) ) ), 'S7' => array( __( 'Active days (28)', 'educore-analytics' ), (string) $c['active_days'] ), 'S8' => array( __( 'Pending lessons / assessments', 'educore-analytics' ), $p['lessons'] . ' / ' . $num( $p['assessments'] ) ) ) as $id => [ $l, $v ] ) {
			echo '<div class="ec-tile"><span class="ec-tile__v">' . esc_html( $v ) . '</span><span class="ec-tile__l">' . esc_html( $l ) . self::def( $id ) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div><h3>' . esc_html__( 'Lesson progress', 'educore-analytics' ) . self::def( 'S2' ) . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::table( array( __( 'Course', 'educore-analytics' ), __( 'Lessons', 'educore-analytics' ), __( 'Started', 'educore-analytics' ), __( 'Completed', 'educore-analytics' ), __( 'Completion %', 'educore-analytics' ) ), array_map( static fn( $r ) => array( $r['title'], $r['total'], $r['started'], $r['completed'], $r['completion'] ), Metrics::lesson_progress( $student, $f ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		$t = Metrics::topic_strengths( $student, $f );
		if ( null !== $t ) {
			echo '<h3>' . esc_html__( 'Topic strengths and weaknesses', 'educore-analytics' ) . self::def( 'S5' ) . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo self::table( array( __( 'Lesson', 'educore-analytics' ), __( 'Mean %', 'educore-analytics' ), __( 'Items', 'educore-analytics' ), __( 'Band', 'educore-analytics' ) ), array_map( static fn( $r ) => array( $r['lesson'], $r['mean'], $r['items'], $r['band'] ), $t ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<p><a class="button" href="' . esc_url( remove_query_arg( 'student' ) ) . '">' . esc_html__( 'Back', 'educore-analytics' ) . '</a></p>';
	}
}
