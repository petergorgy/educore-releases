<?php
namespace EduCore\Commerce;

use EduCore\Core\Enrollment;

defined( 'ABSPATH' ) || exit;

/**
 * Server-side access rules for paid courses (core filter educore/access/can_access_course).
 * Staff never reach this filter (core grants them access first).
 * A paid course requires: current enrollment AND (active entitlement OR an enrollment created
 * manually by staff — source admin|import — which acts as a documented manual grant/scholarship).
 */
final class Gate {

	public static function register(): void {
		add_filter( 'educore/access/can_access_course', array( self::class, 'can_access' ), 10, 3 );
		add_filter( 'educore/access/can_self_enroll', array( self::class, 'can_self_enroll' ), 10, 4 );
	}

	public static function is_paid( int $course_id ): bool {
		return 'paid' === get_post_meta( $course_id, '_ec_enroll_mode', true );
	}

	public static function can_access( bool $allowed, int $user_id, int $course_id ): bool {
		if ( ! $allowed || ! self::is_paid( $course_id ) ) {
			return $allowed;
		}
		$e = Enrollment::get( $user_id, $course_id );
		if ( $e && in_array( $e['source'], array( 'admin', 'import' ), true ) ) {
			return true;
		}
		return Entitlements::has_active( $user_id, $course_id );
	}

	public static function can_self_enroll( bool $allowed, int $user_id, int $course_id, string $mode ): bool {
		return 'paid' === $mode ? false : $allowed;
	}
}
