<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Consent, guardian consent for minors, and WordPress personal-data export/erasure.
 *
 * Learner consent state (user meta educore_consent_state):
 *   granted          adult who accepted terms/privacy
 *   pending_guardian minor awaiting guardian confirmation (cannot enroll or attempt)
 *   granted_guardian guardian confirmed
 */
final class Privacy {
	public const AGE_BANDS = array( 'under15', '15to17', '18plus' );

	public static function register(): void {
		add_filter( 'wp_privacy_personal_data_exporters', array( self::class, 'exporters' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( self::class, 'erasers' ) );
		add_action( 'admin_init', array( self::class, 'privacy_policy_text' ) );
	}

	public static function consent_version(): string {
		return (string) get_option( 'educore_consent_version', '1.0' );
	}

	public static function record_consent( int $user_id, string $type, string $granted_by = 'self', int $guardian_link_id = 0 ): int {
		global $wpdb;
		$evidence = hash( 'sha256', implode( '|', array( $user_id, $type, self::consent_version(), $granted_by, $guardian_link_id, Schema::now(), Audit::ip_hash() ) ) );
		$wpdb->insert(
			Schema::table( 'consents' ),
			array(
				'user_id'          => $user_id,
				'consent_type'     => $type,
				'version'          => self::consent_version(),
				'granted_by'       => $granted_by,
				'guardian_link_id' => $guardian_link_id,
				'granted_at'       => Schema::now(),
				'evidence_hash'    => $evidence,
			)
		);
		Audit::log( 'privacy.consent_granted', 'user', $user_id, array( 'type' => $type, 'by' => $granted_by ) );
		return (int) $wpdb->insert_id;
	}

	public static function withdraw_consent( int $user_id, string $type ): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . Schema::table( 'consents' ) . ' SET withdrawn_at=%s WHERE user_id=%d AND consent_type=%s AND withdrawn_at IS NULL', Schema::now(), $user_id, $type ) );
		if ( 'learning' === $type ) {
			update_user_meta( $user_id, 'educore_consent_state', 'withdrawn' );
		}
		Audit::log( 'privacy.consent_withdrawn', 'user', $user_id, array( 'type' => $type ) );
	}

	/** Learners need valid consent before enrolling or attempting. Staff are exempt. */
	public static function has_required_consent( int $user_id ): bool {
		if ( user_can( $user_id, 'ec_access_workspace' ) || user_can( $user_id, 'manage_options' ) ) {
			return true;
		}
		$state = get_user_meta( $user_id, 'educore_consent_state', true );
		if ( '' === $state ) {
			// Accounts created outside the EduCore registration (e.g. by an administrator) are
			// treated as consented by the creating administrator only if the site allows it.
			return (bool) get_option( 'educore_admin_created_is_consented', true );
		}
		return in_array( $state, array( 'granted', 'granted_guardian' ), true );
	}

	public static function is_minor( int $user_id ): bool {
		return in_array( get_user_meta( $user_id, 'educore_age_band', true ), array( 'under15', '15to17' ), true );
	}

	/**
	 * Start guardian verification for a minor. Returns the plain token (sent by e-mail only).
	 *
	 * @return string|\WP_Error
	 */
	public static function request_guardian_consent( int $student_id, string $guardian_email, string $guardian_name = '' ) {
		global $wpdb;
		$guardian_email = sanitize_email( $guardian_email );
		if ( ! is_email( $guardian_email ) ) {
			return new \WP_Error( 'educore_bad_email', __( 'Please enter a valid guardian e-mail address.', 'educore-core' ) );
		}
		$student = get_userdata( $student_id );
		if ( ! $student || strtolower( $student->user_email ) === strtolower( $guardian_email ) ) {
			return new \WP_Error( 'educore_guardian_same', __( 'The guardian e-mail must be different from the student e-mail.', 'educore-core' ) );
		}
		if ( ! RateLimiter::hit( 'guardian', 'g:' . $student_id ) ) {
			return new \WP_Error( 'educore_throttled', __( 'Too many requests. Please try later.', 'educore-core' ) );
		}
		$token = wp_generate_password( 40, false, false );
		$t     = Schema::table( 'guardian_links' );
		$wpdb->query( $wpdb->prepare( "INSERT INTO {$t} (student_id,guardian_email,guardian_name,token_hash,status,created_at) VALUES (%d,%s,%s,%s,'pending',%s) ON DUPLICATE KEY UPDATE token_hash=VALUES(token_hash), status='pending', guardian_name=VALUES(guardian_name), created_at=VALUES(created_at)", $student_id, $guardian_email, sanitize_text_field( $guardian_name ), hash( 'sha256', $token ), Schema::now() ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		update_user_meta( $student_id, 'educore_consent_state', 'pending_guardian' );
		$url = add_query_arg( array( 'educore_guardian' => rawurlencode( $token ) ), Pages::url( 'guardian' ) );
		do_action( 'educore/events/guardian_consent_requested', $student_id, $guardian_email, $url );
		/** Notifications package returns false here and delivers through its queue instead. */
		if ( apply_filters( 'educore/privacy/send_guardian_mail_directly', true, $student_id ) ) {
			/* translators: 1: student display name, 2: site name */
			$subject = sprintf( __( 'Consent request: %1$s wants to join %2$s', 'educore-core' ), $student->display_name, get_bloginfo( 'name' ) );
			/* translators: 1: student display name, 2: url */
			$body = sprintf( __( "Hello,\n\n%1\$s registered on EduCore and listed you as parent or guardian. Because the learner is under 18, we need your consent before they can start learning.\n\nReview and confirm here (valid 7 days):\n%2\$s\n\nIf you do not recognise this request, ignore this e-mail.", 'educore-core' ), $student->display_name, $url );
			wp_mail( $guardian_email, $subject, $body );
		}
		Audit::log( 'privacy.guardian_requested', 'user', $student_id );
		return $token;
	}

	/** @return array<string,mixed>|null pending link for a token (valid 7 days) */
	public static function find_guardian_link( string $token ): ?array {
		global $wpdb;
		if ( strlen( $token ) < 20 ) {
			return null;
		}
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'guardian_links' ) . " WHERE token_hash=%s AND status='pending'", hash( 'sha256', $token ) ), ARRAY_A );
		if ( ! $row || strtotime( $row['created_at'] . ' UTC' ) < time() - 7 * DAY_IN_SECONDS ) {
			return null;
		}
		return $row;
	}

	/** @return bool|\WP_Error */
	public static function confirm_guardian( string $token, bool $approve ) {
		global $wpdb;
		$link = self::find_guardian_link( $token );
		if ( ! $link ) {
			return new \WP_Error( 'educore_bad_token', __( 'This consent link is invalid or has expired.', 'educore-core' ) );
		}
		$status = $approve ? 'verified' : 'declined';
		$wpdb->update( Schema::table( 'guardian_links' ), array( 'status' => $status, 'verified_at' => Schema::now(), 'token_hash' => '' ), array( 'id' => (int) $link['id'] ) );
		if ( $approve ) {
			self::record_consent( (int) $link['student_id'], 'learning', 'guardian', (int) $link['id'] );
			update_user_meta( (int) $link['student_id'], 'educore_consent_state', 'granted_guardian' );
		} else {
			update_user_meta( (int) $link['student_id'], 'educore_consent_state', 'declined' );
			Audit::log( 'privacy.guardian_declined', 'user', (int) $link['student_id'] );
		}
		return true;
	}

	/** Guardian user account (role ec_guardian) linked + verified to the student. */
	public static function guardian_has_access( int $guardian_user_id, int $student_id ): bool {
		global $wpdb;
		if ( ! $guardian_user_id || ! $student_id || ! user_can( $guardian_user_id, 'read' ) ) {
			return false;
		}
		$user = get_userdata( $guardian_user_id );
		if ( ! $user || ! in_array( 'ec_guardian', (array) $user->roles, true ) ) {
			return false;
		}
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Schema::table( 'guardian_links' ) . " WHERE student_id=%d AND status='verified' AND (guardian_user_id=%d OR guardian_email=%s)", $student_id, $guardian_user_id, $user->user_email ) );
	}

	/* ---------- WordPress privacy tools ---------- */

	public static function exporters( array $exporters ): array {
		$exporters['educore-core'] = array(
			'exporter_friendly_name' => __( 'EduCore learning records', 'educore-core' ),
			'callback'               => array( self::class, 'export' ),
		);
		return $exporters;
	}

	public static function erasers( array $erasers ): array {
		$erasers['educore-core'] = array(
			'eraser_friendly_name' => __( 'EduCore learning records', 'educore-core' ),
			'callback'             => array( self::class, 'erase' ),
		);
		return $erasers;
	}

	public static function export( string $email, int $page = 1 ): array {
		global $wpdb;
		$user = get_user_by( 'email', $email );
		$data = array();
		if ( $user ) {
			$sets = array(
				'enrollments'     => __( 'Enrollments', 'educore-core' ),
				'lesson_progress' => __( 'Lesson progress', 'educore-core' ),
				'notes'           => __( 'Notes and bookmarks', 'educore-core' ),
				'consents'        => __( 'Consents', 'educore-core' ),
			);
			foreach ( $sets as $table => $label ) {
				$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( $table ) . ' WHERE user_id=%d', $user->ID ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
				foreach ( $rows as $row ) {
					$items = array();
					foreach ( $row as $k => $v ) {
						$items[] = array( 'name' => $k, 'value' => (string) $v );
					}
					$data[] = array( 'group_id' => 'educore-' . $table, 'group_label' => $label, 'item_id' => $table . '-' . $row['id'], 'data' => $items );
				}
			}
			foreach ( array( 'educore_age_band', 'educore_mobile', 'educore_lang', 'educore_consent_state', 'educore_programme_id', 'educore_academic_year' ) as $meta ) {
				$v = get_user_meta( $user->ID, $meta, true );
				if ( '' !== $v ) {
					$data[] = array( 'group_id' => 'educore-profile', 'group_label' => __( 'Learner profile', 'educore-core' ), 'item_id' => 'profile-' . $meta, 'data' => array( array( 'name' => $meta, 'value' => (string) $v ) ) );
				}
			}
		}
		/** Other packages append their records. */
		$data = apply_filters( 'educore/privacy/export', $data, $user );
		return array( 'data' => $data, 'done' => true );
	}

	public static function erase( string $email, int $page = 1 ): array {
		global $wpdb;
		$user    = get_user_by( 'email', $email );
		$removed = false;
		$keep    = array();
		if ( $user ) {
			foreach ( array( 'notes', 'lesson_progress', 'enrollments' ) as $table ) {
				$removed = (bool) $wpdb->delete( Schema::table( $table ), array( 'user_id' => $user->ID ), array( '%d' ) ) || $removed;
			}
			foreach ( array( 'educore_mobile', 'educore_programme_id', 'educore_academic_year' ) as $meta ) {
				delete_user_meta( $user->ID, $meta );
			}
			$keep[] = __( 'Consent records are retained as legal evidence of consent.', 'educore-core' );
			do_action( 'educore/privacy/erase', $user );
			Audit::log( 'privacy.erased', 'user', $user->ID );
		}
		return array( 'items_removed' => $removed, 'items_retained' => ! empty( $keep ), 'messages' => $keep, 'done' => true );
	}

	public static function privacy_policy_text(): void {
		if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
			wp_add_privacy_policy_content(
				'EduCore',
				wp_kses_post( wpautop( __( 'EduCore stores learning records (enrollments, lesson progress, assessment attempts, grades and certificates), the consent you or your guardian gave, and optional profile fields (preferred language, academic year, mobile number). Learners under 18 need verified guardian consent before learning. IP addresses in security logs are stored only as one-way hashes. You can request an export or erasure of your data from the site administrator.', 'educore-core' ) ) )
			);
		}
	}
}
