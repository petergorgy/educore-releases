<?php
namespace EduCore\Notifications;

use EduCore\Core\Enrollment;
use EduCore\Core\Pages;
use EduCore\Core\Schema;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/** Domain event listeners → queued messages. Each uses an idempotency key. */
final class Events {

	public static function register(): void {
		add_action( 'educore/events/enrolled', array( self::class, 'enrolled' ), 10, 3 );
		add_action( 'educore/events/announcement_published', array( self::class, 'announcement' ), 10, 2 );
		add_action( 'educore/events/attempt_submitted', array( self::class, 'attempt_submitted' ), 10, 2 );
		add_action( 'educore/events/grade_released', array( self::class, 'grade_released' ), 10, 2 );
		add_action( 'educore/events/course_completed', array( self::class, 'course_completed' ), 10, 2 );
		add_action( 'educore/events/certificate_issued', array( self::class, 'certificate_issued' ), 10, 3 );
		add_action( 'educore/events/guardian_consent_requested', array( self::class, 'guardian' ), 10, 3 );
		add_filter( 'educore/privacy/send_guardian_mail_directly', '__return_false' );
		add_action( 'educore/events/enrollment_status', array( self::class, 'enrollment_status' ), 10, 3 );
		add_action( 'educore/events/entitlement_expiring', array( self::class, 'entitlement_expiring' ), 10, 3 );
		add_action( 'after_password_reset', array( self::class, 'password_reset' ) );
		add_action( 'profile_update', array( self::class, 'profile_update' ), 10, 3 );
	}

	private static function date( ?string $mysql_utc = null ): string {
		$ts = $mysql_utc ? strtotime( $mysql_utc . ' UTC' ) : time();
		return wp_date( 'Y-m-d', $ts );
	}

	public static function enrolled( int $user_id, int $course_id, string $source = '' ): void {
		Queue::enqueue( 'enrolled', $user_id, array( 'course' => get_the_title( $course_id ), 'url' => (string) get_permalink( $course_id ) ), "u{$user_id}:c{$course_id}:" . gmdate( 'YmdH' ) );
	}

	public static function announcement( int $announcement_id, int $course_id ): void {
		$post = get_post( $announcement_id );
		if ( ! $post ) {
			return;
		}
		foreach ( Enrollment::for_course( $course_id, 5000 ) as $e ) {
			if ( ! Enrollment::is_enrolled( (int) $e['user_id'], $course_id ) ) {
				continue;
			}
			Queue::enqueue( 'announcement', (int) $e['user_id'], array( 'course' => get_the_title( $course_id ), 'title' => $post->post_title, 'message' => wp_strip_all_tags( $post->post_content ), 'url' => (string) get_permalink( $course_id ) ), "a{$announcement_id}:u" . $e['user_id'] );
		}
	}

	/**
	 * Context of an attempt. The assessments package may provide it through the
	 * educore/notifications/attempt_context filter; otherwise a best-effort lookup is used.
	 *
	 * @return array{title:string,course_id:int,needs_grading:bool,url:string,grading_url:string}
	 */
	public static function attempt_context( int $attempt_id ): array {
		global $wpdb;
		$ctx = array( 'title' => '', 'course_id' => 0, 'needs_grading' => false, 'url' => '', 'grading_url' => '' );
		$at  = Schema::table( 'attempts' );
		$as  = Schema::table( 'assessments' );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $at ) ) === $at && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $as ) ) === $as ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT s.* FROM {$at} t JOIN {$as} s ON s.id = t.assessment_id WHERE t.id = %d", $attempt_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
			if ( $row ) {
				$ctx['course_id'] = (int) ( $row['course_id'] ?? 0 );
				$ctx['title']     = (string) ( $row['title'] ?? '' );
			}
		}
		$ctx = (array) apply_filters( 'educore/notifications/attempt_context', $ctx, $attempt_id );
		if ( '' === $ctx['title'] ) {
			$ctx['title'] = __( 'your assessment', 'educore-notifications' );
		}
		return $ctx;
	}

	public static function attempt_submitted( int $attempt_id, int $user_id ): void {
		$ctx = self::attempt_context( $attempt_id );
		Queue::enqueue( 'attempt_received', $user_id, array( 'title' => $ctx['title'], 'date' => self::date(), 'url' => $ctx['url'] ), "att{$attempt_id}" );
		if ( ! empty( $ctx['needs_grading'] ) && $ctx['course_id'] ) {
			foreach ( Staff::of_course( (int) $ctx['course_id'] ) as $s ) {
				Queue::enqueue( 'grading_needed', (int) $s['user_id'], array( 'title' => $ctx['title'], 'course' => get_the_title( (int) $ctx['course_id'] ), 'url' => $ctx['grading_url'] ), "att{$attempt_id}:staff" . $s['user_id'] );
			}
		}
	}

	public static function grade_released( int $attempt_id, int $user_id ): void {
		$ctx = self::attempt_context( $attempt_id );
		Queue::enqueue( 'grade_released', $user_id, array( 'title' => $ctx['title'], 'url' => $ctx['url'] ?: Pages::url( 'history' ) ), "att{$attempt_id}" );
	}

	public static function course_completed( int $user_id, int $course_id ): void {
		Queue::enqueue( 'course_completed', $user_id, array( 'course' => get_the_title( $course_id ), 'url' => Pages::url( 'dashboard' ) ), "u{$user_id}:c{$course_id}" );
	}

	public static function certificate_issued( int $certificate_id, int $user_id, int $course_id ): void {
		$url = (string) apply_filters( 'educore/notifications/certificate_url', '', $certificate_id );
		Queue::enqueue( 'certificate_issued', $user_id, array( 'course' => get_the_title( $course_id ), 'url' => $url ), "cert{$certificate_id}" );
	}

	public static function guardian( int $student_id, string $guardian_email, string $url ): void {
		$student = get_userdata( $student_id );
		if ( ! $student ) {
			return;
		}
		$lang = (string) get_user_meta( $student_id, 'educore_lang', true ) ?: 'en';
		Queue::enqueue( 'guardian_consent', $guardian_email, array( 'name' => $student->display_name, 'url' => $url ), "s{$student_id}:" . md5( $url ), array( 'lang' => $lang ) );
	}

	public static function enrollment_status( int $user_id, int $course_id, string $status ): void {
		if ( 'expired' === $status ) {
			Queue::enqueue( 'enrollment_expired', $user_id, array( 'course' => get_the_title( $course_id ), 'url' => (string) get_permalink( $course_id ) ), "u{$user_id}:c{$course_id}:" . gmdate( 'Ymd' ) );
		}
	}

	public static function entitlement_expiring( int $user_id, int $course_id, string $ends_at ): void {
		Queue::enqueue( 'entitlement_expiring', $user_id, array( 'course' => get_the_title( $course_id ), 'date' => self::date( $ends_at ), 'url' => (string) get_permalink( $course_id ) ), "u{$user_id}:c{$course_id}:{$ends_at}" );
	}

	public static function password_reset( $user ): void {
		if ( $user instanceof \WP_User ) {
			Queue::enqueue( 'password_changed', (int) $user->ID, array( 'date' => self::date() ), 'u' . $user->ID . ':' . microtime( true ) );
		}
	}

	public static function profile_update( int $user_id, $old_user, array $userdata = array() ): void {
		$new = get_userdata( $user_id );
		if ( $old_user instanceof \WP_User && $new && $old_user->user_pass !== $new->user_pass ) {
			Queue::enqueue( 'password_changed', $user_id, array( 'date' => self::date() ), 'u' . $user_id . ':' . md5( $new->user_pass ) );
		}
	}

	/**
	 * Daily reminders. Packages add items through the educore/notifications/reminders filter:
	 * array of [ 'user_id' => int, 'key' => string, 'title' => string, 'due' => 'Y-m-d H:i:s' UTC, 'url' => string ].
	 */
	public static function reminders(): int {
		$items = (array) apply_filters( 'educore/notifications/reminders', array() );
		$n     = 0;
		foreach ( $items as $it ) {
			if ( empty( $it['user_id'] ) || empty( $it['key'] ) ) {
				continue;
			}
			$n += Queue::enqueue( 'reminder', (int) $it['user_id'], array( 'title' => (string) ( $it['title'] ?? '' ), 'date' => self::date( $it['due'] ?? null ), 'url' => (string) ( $it['url'] ?? '' ) ), 'rem:' . $it['key'] ) ? 1 : 0;
		}
		return $n;
	}
}
