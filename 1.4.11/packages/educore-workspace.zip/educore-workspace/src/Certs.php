<?php
namespace EduCore\Workspace;

use EduCore\Certificates\Certificates;
use EduCore\Certificates\Pdf;
use EduCore\Certificates\Plugin as CertPlugin;
use EduCore\Certificates\Templates;
use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Enrollment;
use EduCore\Core\I18n;
use EduCore\Core\RateLimiter;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Certificate administration in EduCore Management (`/manage/?v=certificates`). Wraps the certificates domain with
 * governance the wp-admin page lacked: a manual issue needs an enrolment, and issuing without a recorded
 * completion needs a written justification (audited). Revocation always needs a reason.
 */
final class Certs {
	public const CAP = 'ec_manage_certificates';

	public static function available(): bool {
		return class_exists( Certificates::class );
	}

	public static function can( int $uid ): bool {
		return $uid > 0 && self::available() && user_can( $uid, self::CAP );
	}

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	public static function routes(): void {
		if ( ! self::available() ) {
			return;
		}
		$perm = static fn() => self::can( get_current_user_id() );
		$id   = array( 'id' => array( 'type' => 'integer', 'required' => true, 'minimum' => 1 ) );
		$r    = static fn( string $route, callable $cb, array $args = array() ) => register_rest_route( 'educore/v1', $route, array( 'methods' => 'POST', 'callback' => $cb, 'permission_callback' => $perm, 'args' => $args ) );
		$r( '/manage/certificates', array( self::class, 'rest_issue' ), array( 'email' => array( 'type' => 'string', 'required' => true ), 'course_id' => array( 'type' => 'integer', 'required' => true ) ) );
		$r( '/manage/certificates/(?P<id>\d+)/revoke', array( self::class, 'rest_revoke' ), $id + array( 'reason' => array( 'type' => 'string', 'required' => true ) ) );
		$r( '/manage/certificates/(?P<id>\d+)/reinstate', array( self::class, 'rest_reinstate' ), $id );
		$r( '/manage/certificates/(?P<id>\d+)/regenerate', array( self::class, 'rest_regenerate' ), $id );
		$r( '/manage/certificate-templates', array( self::class, 'rest_template' ) );
		$r( '/manage/certificate-templates/(?P<id>\d+)', array( self::class, 'rest_template' ), $id );
		$r( '/manage/courses/(?P<id>\d+)/certificate', array( self::class, 'rest_course' ), $id );
	}

	private static function guard() {
		return RateLimiter::hit( 'rest_write' ) ? null : new \WP_Error( 'ec_ws_rate', __( 'Too many changes in a short time. Please wait a moment.', 'educore-workspace' ), array( 'status' => 429 ) );
	}

	private static function deny(): \WP_Error {
		return new \WP_Error( 'ec_cert_forbidden', __( 'You cannot manage certificates.', 'educore-workspace' ), array( 'status' => 403 ) );
	}

	private static function out( $r, array $extra = array() ) {
		return is_wp_error( $r ) ? $r : new \WP_REST_Response( array( 'ok' => true ) + $extra );
	}

	/* ---------- queries ---------- */

	public static function get( int $id ): ?array {
		return self::available() ? Certificates::get( $id ) : null;
	}

	/** @return array{rows:array,total:int} */
	public static function search( array $f ): array {
		global $wpdb;
		$t      = Schema::table( 'certificates' );
		$where  = array( '1=1' );
		$params = array();
		if ( '' !== trim( (string) ( $f['q'] ?? '' ) ) ) {
			$like     = '%' . $wpdb->esc_like( mb_substr( sanitize_text_field( (string) $f['q'] ), 0, 100 ) ) . '%';
			$where[]  = '(student_name LIKE %s OR course_title LIKE %s OR uid LIKE %s)';
			$params   = array_merge( $params, array( $like, $like, $like ) );
		}
		if ( ! empty( $f['course_id'] ) ) {
			$where[]  = 'course_id=%d';
			$params[] = (int) $f['course_id'];
		}
		if ( 'valid' === ( $f['status'] ?? '' ) ) {
			$where[] = 'revoked_at IS NULL';
		} elseif ( 'revoked' === ( $f['status'] ?? '' ) ) {
			$where[] = 'revoked_at IS NOT NULL';
		}
		$per    = 25;
		$page   = max( 1, (int) ( $f['page'] ?? 1 ) );
		$base   = "FROM {$t} WHERE " . implode( ' AND ', $where );
		$total  = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) $base", $params ) ) : $wpdb->get_var( "SELECT COUNT(*) $base" ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT * $base ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $params, array( $per, ( $page - 1 ) * $per ) ) ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		return array( 'rows' => $rows, 'total' => $total );
	}

	/** @return \WP_Post[] */
	public static function templates(): array {
		return self::available() ? get_posts( array( 'post_type' => CertPlugin::TEMPLATE, 'post_status' => array( 'publish', 'draft' ), 'numberposts' => 100, 'orderby' => 'title', 'order' => 'ASC' ) ) : array();
	}

	/* ---------- actions ---------- */

	/** @return int|\WP_Error certificate id */
	public static function issue( int $uid, string $email, int $course_id, string $justification = '' ) {
		if ( ! self::can( $uid ) ) {
			return self::deny();
		}
		$user = get_user_by( 'email', sanitize_email( $email ) );
		if ( ! $user ) {
			return new \WP_Error( 'ec_cert_user', __( 'No account uses this e-mail address.', 'educore-workspace' ), array( 'status' => 404, 'params' => array( 'email' => 'invalid' ) ) );
		}
		if ( ! Content::is_course( $course_id ) || 'publish' !== get_post_status( $course_id ) ) {
			return new \WP_Error( 'ec_cert_course', __( 'Choose a published course.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'course_id' => 'invalid' ) ) );
		}
		$e = Enrollment::get( (int) $user->ID, $course_id );
		if ( ! $e ) {
			return new \WP_Error( 'ec_cert_enrol', __( 'This learner is not enrolled in the course. Certificates are only issued to enrolled learners.', 'educore-workspace' ), array( 'status' => 409 ) );
		}
		$completed     = 'completed' === ( $e['status'] ?? '' );
		$justification = trim( sanitize_text_field( $justification ) );
		if ( ! $completed && mb_strlen( $justification ) < 10 ) {
			return new \WP_Error( 'ec_cert_justify', __( 'The learner has not completed the course. Give a justification (at least 10 characters) to issue anyway.', 'educore-workspace' ), array( 'status' => 409, 'params' => array( 'justification' => 'required' ) ) );
		}
		$res = Certificates::issue( (int) $user->ID, $course_id );
		if ( ! is_wp_error( $res ) ) {
			Audit::log( 'certificate.manual_issue', 'certificate', (int) $res, array( 'course_id' => $course_id, 'completed' => $completed, 'justification' => $completed ? '' : $justification ) );
		}
		return is_wp_error( $res ) ? new \WP_Error( $res->get_error_code(), $res->get_error_message(), array( 'status' => 409 ) ) : (int) $res;
	}

	/** @return true|\WP_Error */
	public static function revoke( int $uid, int $id, string $reason ) {
		if ( ! self::can( $uid ) || ! self::get( $id ) ) {
			return self::deny();
		}
		if ( mb_strlen( trim( $reason ) ) < 5 ) {
			return new \WP_Error( 'ec_cert_reason', __( 'Give the reason for revocation (at least 5 characters). It is shown on the public verification page.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'reason' => 'required' ) ) );
		}
		return Certificates::revoke( $id, $reason ) ? true : new \WP_Error( 'ec_cert_state', __( 'This certificate is already revoked.', 'educore-workspace' ), array( 'status' => 409 ) );
	}

	/** @return true|\WP_Error */
	public static function reinstate( int $uid, int $id ) {
		if ( ! self::can( $uid ) || ! self::get( $id ) ) {
			return self::deny();
		}
		return Certificates::reinstate( $id ) ? true : new \WP_Error( 'ec_cert_state', __( 'This certificate is not revoked.', 'educore-workspace' ), array( 'status' => 409 ) );
	}

	/** @return true|\WP_Error */
	public static function regenerate( int $uid, int $id ) {
		if ( ! self::can( $uid ) || ! self::get( $id ) ) {
			return self::deny();
		}
		try {
			Pdf::generate( $id );
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'ec_cert_pdf', __( 'PDF generation failed. Check the server error log.', 'educore-workspace' ), array( 'status' => 500 ) );
		}
		Audit::log( 'certificate.regenerated', 'certificate', $id );
		return true;
	}

	/** Create (id 0) or update a template. Same sanitisers as the wp-admin meta box. @return int|\WP_Error */
	public static function save_template( int $uid, int $id, array $in ) {
		if ( ! self::can( $uid ) ) {
			return self::deny();
		}
		if ( $id && get_post_type( $id ) !== CertPlugin::TEMPLATE ) {
			return new \WP_Error( 'ec_cert_tpl', __( 'Template not found.', 'educore-workspace' ), array( 'status' => 404 ) );
		}
		$title = sanitize_text_field( (string) ( $in['title'] ?? '' ) );
		$body  = sanitize_textarea_field( (string) ( $in['body'] ?? '' ) );
		if ( '' === $title || '' === trim( $body ) ) {
			return new \WP_Error( 'ec_cert_tpl', __( 'A template needs a name and a body.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'title' => 'required', 'body' => 'required' ) ) );
		}
		if ( ! str_contains( $body, '{student_name}' ) || ! str_contains( $body, '{course_title}' ) ) {
			return new \WP_Error( 'ec_cert_tpl', __( 'The body must contain {student_name} and {course_title}.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'body' => 'invalid' ) ) );
		}
		$accent = sanitize_hex_color( (string) ( $in['accent'] ?? '' ) ) ?: '#0b7f7a';
		$meta   = array(
			'_ec_cert_heading'     => sanitize_text_field( (string) ( $in['heading'] ?? '' ) ),
			'_ec_cert_body'        => $body,
			'_ec_cert_lang'        => I18n::sanitize_lang( (string) ( $in['lang'] ?? 'en' ) ),
			'_ec_cert_orientation' => 'P' === ( $in['orientation'] ?? '' ) ? 'P' : 'L',
			'_ec_cert_accent'      => $accent,
			'_ec_cert_sig_name'    => sanitize_text_field( (string) ( $in['sig_name'] ?? '' ) ),
			'_ec_cert_sig_title'   => sanitize_text_field( (string) ( $in['sig_title'] ?? '' ) ),
		);
		$post = array( 'post_type' => CertPlugin::TEMPLATE, 'post_title' => $title, 'post_status' => 'draft' === ( $in['status'] ?? '' ) ? 'draft' : 'publish' );
		$res  = $id ? wp_update_post( $post + array( 'ID' => $id ), true ) : wp_insert_post( $post, true );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		foreach ( $meta as $k => $v ) {
			update_post_meta( (int) $res, $k, $v );
		}
		Audit::log( $id ? 'certificate.template_updated' : 'certificate.template_created', 'certificate_template', (int) $res );
		return (int) $res;
	}

	/** Per-course certificate setting. @return true|\WP_Error */
	public static function save_course( int $uid, int $course_id, array $in ) {
		if ( ! self::can( $uid ) ) {
			return self::deny();
		}
		if ( ! Content::is_course( $course_id ) ) {
			return new \WP_Error( 'ec_cert_course', __( 'Course not found.', 'educore-workspace' ), array( 'status' => 404 ) );
		}
		$tpl = absint( $in['template'] ?? 0 );
		if ( $tpl && ( get_post_type( $tpl ) !== CertPlugin::TEMPLATE || 'publish' !== get_post_status( $tpl ) ) ) {
			return new \WP_Error( 'ec_cert_tpl', __( 'Choose a published template.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		$on = in_array( $in['enabled'] ?? '', array( true, '1', 1, 'yes', 'on' ), true );
		update_post_meta( $course_id, '_ec_cert_enabled', $on ? 'yes' : 'no' );
		update_post_meta( $course_id, '_ec_cert_template', $tpl );
		Audit::log( 'certificate.course_settings', 'course', $course_id, array( 'enabled' => $on, 'template' => $tpl ) );
		return true;
	}

	/* ---------- REST ---------- */

	public static function rest_issue( \WP_REST_Request $q ) {
		$r = self::guard() ?? self::issue( get_current_user_id(), (string) $q['email'], (int) $q['course_id'], (string) $q['justification'] );
		return self::out( $r, is_wp_error( $r ) ? array() : array( 'id' => $r ) );
	}

	public static function rest_revoke( \WP_REST_Request $q ) {
		return self::out( self::guard() ?? self::revoke( get_current_user_id(), (int) $q['id'], (string) $q['reason'] ) );
	}

	public static function rest_reinstate( \WP_REST_Request $q ) {
		return self::out( self::guard() ?? self::reinstate( get_current_user_id(), (int) $q['id'] ) );
	}

	public static function rest_regenerate( \WP_REST_Request $q ) {
		return self::out( self::guard() ?? self::regenerate( get_current_user_id(), (int) $q['id'] ) );
	}

	public static function rest_template( \WP_REST_Request $q ) {
		$r = self::guard() ?? self::save_template( get_current_user_id(), (int) $q['id'], $q->get_params() );
		return self::out( $r, is_wp_error( $r ) ? array() : array( 'id' => $r, 'url' => (int) $q['id'] ? '' : Pages::url( 'manage', array( 'v' => 'certificates', 'tab' => 'templates', 'tpl' => $r ) ) ) );
	}

	public static function rest_course( \WP_REST_Request $q ) {
		return self::out( self::guard() ?? self::save_course( get_current_user_id(), (int) $q['id'], $q->get_params() ) );
	}

	/** For the certificate template preview. */
	public static function template_values( int $id ): array {
		$p = get_post( $id );
		return Templates::get( $id ) + array( 'title' => $p ? $p->post_title : '', 'status' => $p ? $p->post_status : 'publish' );
	}
}
