<?php
namespace EduCore\Workspace\Assess;

use EduCore\Assessments\Assessments;
use EduCore\Assessments\Exchange\Center;
use EduCore\Assessments\Exchange\Formats;
use EduCore\Assessments\Exchange\Jobs;
use EduCore\Assessments\Questions;
use EduCore\Assessments\Types;
use EduCore\Core\Content;
use EduCore\Core\I18n;
use EduCore\Workspace\Pages;
use EduCore\Workspace\Shell;
use EduCore\Workspace\Studio\Courses;
use EduCore\Workspace\Studio\View as Studio;

defined( 'ABSPATH' ) || exit;

/**
 * Question Bank Center and Assessment Builder, rendered inside the Course Studio (`/studio/?bank=<course>`,
 * `/studio/?assess=<course>`). Views only read; all writes go through Assess\Rest → Bank / Builder.
 */
final class View {

	public static function url( array $args = array() ): string {
		return Pages::url( 'studio', $args );
	}

	private static function q( string $k ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view parameters.
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
	}

	private static function flash(): string {
		$m = array(
			'qsaved'  => __( 'Question saved.', 'educore-workspace' ),
			'qcopied' => __( 'A draft copy of the question was created.', 'educore-workspace' ),
			'dup'     => __( 'Saved. A question with the same content already exists in this bank — check for duplicates.', 'educore-workspace' ),
			'asaved'  => __( 'Assessment saved.', 'educore-workspace' ),
			'acopied' => __( 'A draft copy of the assessment was created.', 'educore-workspace' ),
		)[ sanitize_key( self::q( 'ec_msg' ) ) ] ?? '';
		return $m ? Studio::notice( $m, 'dup' === sanitize_key( self::q( 'ec_msg' ) ) ? 'warn' : 'success' ) : '';
	}

	public static function status_label( string $s ): string {
		return array(
			'draft'     => __( 'Draft', 'educore-workspace' ),
			'review'    => __( 'In review', 'educore-workspace' ),
			'published' => __( 'Published', 'educore-workspace' ),
			'archived'  => __( 'Archived', 'educore-workspace' ),
		)[ $s ] ?? $s;
	}

	public static function status_chip( string $s ): string {
		return self::chip( $s );
	}

	private static function chip( string $s ): string {
		$map = array( 'published' => 'publish', 'review' => 'pending', 'draft' => 'draft', 'archived' => 'trash' );
		return '<span class="ec-chip ec-chip--' . esc_attr( $map[ $s ] ?? $s ) . '">' . esc_html( self::status_label( $s ) ) . '</span>';
	}

	private static function kinds(): array {
		return array( 'practice' => __( 'Practice', 'educore-workspace' ), 'quiz' => __( 'Quiz', 'educore-workspace' ), 'exam' => __( 'Exam', 'educore-workspace' ) );
	}

	private static function difficulties( bool $any = false ): array {
		return ( $any ? array( '' => __( 'Any difficulty', 'educore-workspace' ) ) : array() ) + array( 'easy' => __( 'Easy', 'educore-workspace' ), 'medium' => __( 'Medium', 'educore-workspace' ), 'hard' => __( 'Hard', 'educore-workspace' ) );
	}

	/** Lesson options of a course: [id => "Unit › Lesson"]. */
	private static function lessons( int $course_id, string $none ): array {
		$o = array( '' => $none );
		foreach ( Content::units( $course_id, Courses::EDITABLE ) as $u ) {
			foreach ( Content::lessons_of_unit( $u->ID, Courses::EDITABLE ) as $l ) {
				$o[ (string) $l->ID ] = get_the_title( $u ) . ' › ' . get_the_title( $l );
			}
		}
		return $o;
	}

	private static function tabs( int $course_id, string $cur ): string {
		$uid  = get_current_user_id();
		$tabs = array();
		if ( Bank::can( $uid, $course_id ) ) {
			$tabs['questions'] = array( __( 'Questions', 'educore-workspace' ), self::url( array( 'bank' => $course_id ) ) );
			$tabs['import']    = array( __( 'Import', 'educore-workspace' ), self::url( array( 'bank' => $course_id, 'x' => 'import' ) ) );
			$tabs['export']    = array( __( 'Export', 'educore-workspace' ), self::url( array( 'bank' => $course_id, 'x' => 'export' ) ) );
		}
		if ( Builder::can( $uid, $course_id ) ) {
			$tabs['assessments'] = array( __( 'Assessments', 'educore-workspace' ), self::url( array( 'assess' => $course_id ) ) );
		}
		if ( Courses::can_edit( $uid, $course_id ) ) {
			$tabs['course'] = array( __( 'Course builder', 'educore-workspace' ), self::url( array( 'course' => $course_id, 'step' => 'assessments' ) ) );
		}
		$o = '<nav class="ec-ws-tabs" aria-label="' . esc_attr__( 'Course assessment tools', 'educore-workspace' ) . '"><ul>';
		foreach ( $tabs as $k => $t ) {
			$o .= '<li><a href="' . esc_url( $t[1] ) . '"' . ( $k === $cur ? ' aria-current="page"' : '' ) . '>' . esc_html( $t[0] ) . '</a></li>';
		}
		return $o . '</ul></nav>';
	}

	private static function crumbs( int $course_id, string $section, string $section_url, string $leaf = '' ): void {
		$c = array( array( __( 'Course Studio', 'educore-workspace' ), self::url() ), array( get_the_title( $course_id ), self::url( array( 'course' => $course_id ) ) ) );
		$c[] = $leaf ? array( $section, $section_url ) : array( $section );
		if ( $leaf ) {
			$c[] = array( $leaf );
		}
		Shell::crumbs( $c );
	}

	/** Course picker for `?v=bank` and `?v=assessments`. */
	public static function picker( int $uid, string $which ): string {
		$bank    = 'bank' === $which;
		$courses = $bank ? Bank::courses( $uid ) : Builder::courses( $uid );
		Shell::title( $bank ? __( 'Question banks', 'educore-workspace' ) : __( 'Assessments', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Course Studio', 'educore-workspace' ), self::url() ), array( $bank ? __( 'Question banks', 'educore-workspace' ) : __( 'Assessments', 'educore-workspace' ) ) ) );
		if ( ! ( $bank ? Bank::can_any( $uid ) : Builder::can_any( $uid ) ) ) {
			return Studio::notice( __( 'You do not have access to this area.', 'educore-workspace' ), 'error' );
		}
		if ( ! $courses ) {
			return '<div class="ec-ws-empty"><p>' . esc_html__( 'You are not on the teaching team of any course yet.', 'educore-workspace' ) . '</p></div>';
		}
		$o = '<p class="ec-muted">' . esc_html__( 'Choose a course.', 'educore-workspace' ) . '</p><div class="ec-ws-table-wrap"><table class="ec-ws-table"><thead><tr><th scope="col">' . esc_html__( 'Course', 'educore-workspace' ) . '</th><th scope="col">' . esc_html( $bank ? __( 'Questions', 'educore-workspace' ) : __( 'Assessments', 'educore-workspace' ) ) . '</th><th scope="col">' . esc_html__( 'Published', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $courses as $c ) {
			if ( $bank ) {
				$all = Questions::search( array( 'course_id' => $c->ID, 'per_page' => 1 ) )['total'];
				$pub = Questions::search( array( 'course_id' => $c->ID, 'status' => 'published', 'per_page' => 1 ) )['total'];
			} else {
				$rows = Builder::list( $uid, (int) $c->ID );
				$all  = count( $rows );
				$pub  = count( array_filter( $rows, static fn( $a ) => 'published' === $a['status'] ) );
			}
			$o .= '<tr><td><a href="' . esc_url( self::url( array( $bank ? 'bank' : 'assess' => $c->ID ) ) ) . '">' . esc_html( get_the_title( $c ) ) . '</a></td><td>' . (int) $all . '</td><td>' . (int) $pub . '</td></tr>';
		}
		return $o . '</tbody></table></div>';
	}

	/* ===================== Question bank ===================== */

	public static function bank( int $uid, int $course_id ): string {
		if ( ! Bank::can( $uid, $course_id ) ) {
			Shell::title( __( 'Question bank', 'educore-workspace' ) );
			return Studio::notice( __( 'You cannot manage the question bank of this course.', 'educore-workspace' ), 'error' );
		}
		if ( (int) self::q( 'job' ) ) {
			return self::job( $uid, $course_id, (int) self::q( 'job' ) );
		}
		if ( '' !== self::q( 'q' ) ) {
			return self::flash() . self::editor( $uid, $course_id, 'new' === self::q( 'q' ) ? 0 : (int) self::q( 'q' ) );
		}
		switch ( sanitize_key( self::q( 'x' ) ) ) {
			case 'import':
				return self::import( $uid, $course_id );
			case 'export':
				return self::export( $uid, $course_id );
		}
		return self::flash() . self::questions( $uid, $course_id );
	}

	private static function questions( int $uid, int $course_id ): string {
		$new = '<a class="ec-btn ec-btn--primary" href="' . esc_url( self::url( array( 'bank' => $course_id, 'q' => 'new' ) ) ) . '">' . esc_html__( 'New question', 'educore-workspace' ) . '</a>';
		Shell::title( __( 'Question bank', 'educore-workspace' ), $new );
		self::crumbs( $course_id, __( 'Question bank', 'educore-workspace' ), '' );
		$f   = array();
		foreach ( array( 'type', 'status', 'difficulty', 'lesson_id', 'search', 'page' ) as $k ) {
			$f[ $k ] = self::q( $k );
		}
		$res = Bank::search( $uid, $course_id, $f );
		$o   = self::tabs( $course_id, 'questions' );
		$o  .= '<form class="ec-ws-filters" method="get" action="' . esc_url( self::url() ) . '" role="search"><input type="hidden" name="bank" value="' . (int) $course_id . '">';
		$o  .= Studio::field_text( 'search', __( 'Search question text', 'educore-workspace' ), $f['search'], false, 'search' );
		$o  .= Studio::field_select( 'type', __( 'Type', 'educore-workspace' ), array( '' => __( 'All types', 'educore-workspace' ) ) + Types::labels(), $f['type'] );
		$o  .= Studio::field_select( 'status', __( 'Status', 'educore-workspace' ), array( '' => __( 'All statuses', 'educore-workspace' ), 'draft' => self::status_label( 'draft' ), 'review' => self::status_label( 'review' ), 'published' => self::status_label( 'published' ), 'archived' => self::status_label( 'archived' ) ), $f['status'] );
		$o  .= Studio::field_select( 'difficulty', __( 'Difficulty', 'educore-workspace' ), self::difficulties( true ), $f['difficulty'] );
		$o  .= Studio::field_select( 'lesson_id', __( 'Lesson', 'educore-workspace' ), self::lessons( $course_id, __( 'All lessons', 'educore-workspace' ) ), $f['lesson_id'] );
		$o  .= '<button class="ec-btn" type="submit">' . esc_html__( 'Filter', 'educore-workspace' ) . '</button></form>';
		/* translators: %d: number of questions */
		$o .= '<p class="ec-muted" role="status">' . esc_html( sprintf( _n( '%d question', '%d questions', (int) $res['total'], 'educore-workspace' ), (int) $res['total'] ) ) . '</p>';
		if ( ! $res['rows'] ) {
			return $o . '<div class="ec-ws-empty"><p>' . esc_html__( 'No questions match.', 'educore-workspace' ) . '</p><p>' . $new . ' <a class="ec-btn" href="' . esc_url( self::url( array( 'bank' => $course_id, 'x' => 'import' ) ) ) . '">' . esc_html__( 'Import questions', 'educore-workspace' ) . '</a></p></div>';
		}
		$labels = Types::labels();
		$pub    = Bank::can_publish( $uid, $course_id );
		$o     .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><thead><tr><th scope="col">#</th><th scope="col">' . esc_html__( 'Question', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Type', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Difficulty', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Points', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Actions', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $res['rows'] as $r ) {
			$id    = (int) $r['id'];
			$edit  = self::url( array( 'bank' => $course_id, 'q' => $id ) );
			$base  = 'bank/' . $course_id . '/questions/' . $id;
			$acts  = '<a class="ec-btn ec-btn--small" href="' . esc_url( $edit ) . '">' . esc_html__( 'Edit', 'educore-workspace' ) . '</a> ';
			$acts .= '<button class="ec-btn ec-btn--small" type="button" data-ec-call="' . esc_attr( $base . '/duplicate' ) . '">' . esc_html__( 'Duplicate', 'educore-workspace' ) . '</button> ';
			if ( 'draft' === $r['status'] ) {
				$acts .= '<button class="ec-btn ec-btn--small" type="button" data-ec-call="' . esc_attr( $base . '/status' ) . '" data-ec-body="' . esc_attr( '{"status":"review"}' ) . '">' . esc_html__( 'Submit for review', 'educore-workspace' ) . '</button> ';
			}
			if ( $pub && in_array( $r['status'], array( 'draft', 'review' ), true ) ) {
				$acts .= '<button class="ec-btn ec-btn--small ec-btn--primary" type="button" data-ec-call="' . esc_attr( $base . '/status' ) . '" data-ec-body="' . esc_attr( '{"status":"published"}' ) . '">' . esc_html__( 'Publish', 'educore-workspace' ) . '</button> ';
			}
			if ( 'archived' !== $r['status'] ) {
				$acts .= '<button class="ec-btn ec-btn--small ec-btn--danger" type="button" data-ec-call="' . esc_attr( $base . '/status' ) . '" data-ec-body="' . esc_attr( '{"status":"archived"}' ) . '" data-ec-confirm="' . esc_attr__( 'Archive this question? It will no longer be drawn into assessments; past attempts keep it.', 'educore-workspace' ) . '">' . esc_html__( 'Archive', 'educore-workspace' ) . '</button>';
			} else {
				$acts .= '<button class="ec-btn ec-btn--small" type="button" data-ec-call="' . esc_attr( $base . '/status' ) . '" data-ec-body="' . esc_attr( '{"status":"draft"}' ) . '">' . esc_html__( 'Restore as draft', 'educore-workspace' ) . '</button>';
			}
			$o .= '<tr><td>' . $id . '</td><td><a href="' . esc_url( $edit ) . '">' . esc_html( mb_strimwidth( wp_strip_all_tags( (string) $r['stem'] ), 0, 110, '…' ) ?: __( '(image question)', 'educore-workspace' ) ) . '</a> <span class="ec-muted">v' . (int) $r['version_no'] . '</span></td><td>' . esc_html( $labels[ $r['type'] ] ?? $r['type'] ) . '</td><td>' . esc_html( self::difficulties()[ $r['difficulty'] ] ?? $r['difficulty'] ) . '</td><td>' . esc_html( (string) ( 0 + (float) $r['points'] ) ) . '</td><td>' . self::chip( (string) $r['status'] ) . '</td><td class="ec-ws-actions">' . $acts . '</td></tr>';
		}
		$o .= '</tbody></table></div>';
		return $o . self::pager( (int) $res['total'], 25, max( 1, (int) $f['page'] ), array_filter( $f ) + array( 'bank' => $course_id ) );
	}

	private static function pager( int $total, int $per, int $page, array $args ): string {
		$pages = (int) ceil( $total / $per );
		if ( $pages < 2 ) {
			return '';
		}
		$o = '<nav class="ec-ws-pager" aria-label="' . esc_attr__( 'Pages', 'educore-workspace' ) . '"><ul>';
		foreach ( array_unique( array_filter( array( 1, $page - 2, $page - 1, $page, $page + 1, $page + 2, $pages ), static fn( $p ) => $p >= 1 && $p <= $pages ) ) as $p ) {
			$o .= '<li>' . ( $p === $page ? '<span aria-current="page">' . (int) $p . '</span>' : '<a href="' . esc_url( self::url( array( 'page' => $p ) + $args ) ) . '">' . (int) $p . '</a>' ) . '</li>';
		}
		return $o . '</ul></nav>';
	}

	/** Which authoring fields each type uses (drives show/hide in bank.js; the server ignores the rest). */
	private static function field_types(): array {
		return array(
			'options'      => 'single,multiple,image,matching,ordering',
			'correct'      => 'single,multiple,image,truefalse,short,fill_blanks,code',
			'scoring'      => 'multiple,ordering',
			'image_id'     => 'image',
			'code'         => 'code',
			'language'     => 'code',
			'model_answer' => 'essay',
			'min_words'    => 'essay',
			'rubric'       => 'essay,short,code,fill_blanks',
		);
	}

	private static function typed( string $field, string $html ): string {
		return '<div data-ec-types="' . esc_attr( self::field_types()[ $field ] ) . '">' . $html . '</div>';
	}

	private static function editor( int $uid, int $course_id, int $id ): string {
		$q   = $id ? Bank::question( $uid, $course_id, $id ) : null;
		$sec = self::url( array( 'bank' => $course_id ) );
		if ( $id && ! $q ) {
			Shell::title( __( 'Question bank', 'educore-workspace' ) );
			return Studio::notice( __( 'Question not found in this course.', 'educore-workspace' ), 'error' );
		}
		$v = $q ? Bank::authoring( $q ) : array( 'type' => 'single', 'stem' => '', 'options' => '', 'correct' => '', 'scoring' => '', 'image_id' => '', 'code' => '', 'language' => 'python', 'model_answer' => '', 'min_words' => '', 'explanation' => '', 'points' => '1', 'difficulty' => 'medium', 'usage' => 'any', 'lang' => I18n::current(), 'tags' => '', 'lesson_id' => '', 'status' => 'draft', 'rubric' => '' );
		/* translators: %d: question id */
		$title = $q ? sprintf( __( 'Question #%d', 'educore-workspace' ), $id ) : __( 'New question', 'educore-workspace' );
		Shell::title( $title, $q ? self::chip( (string) $q['status'] ) : '' );
		self::crumbs( $course_id, __( 'Question bank', 'educore-workspace' ), $sec, $title );
		if ( current_user_can( 'upload_files' ) ) {
			wp_enqueue_media();
		}
		$pub    = Bank::can_publish( $uid, $course_id );
		$path   = 'bank/' . $course_id . '/questions' . ( $q ? '/' . $id : '' );
		$help   = array(
			'options' => __( 'One per line. Matching: "left | right" per line (" | right" adds a distractor). Ordering: items in the correct order.', 'educore-workspace' ),
			'correct' => __( 'Choice: number of the correct option (several: 1,3). True/False: true or false. Short answer: accepted answers, one per line. Blanks: "1: answer|alternative" per blank. Code: expected output.', 'educore-workspace' ),
		);
		$o  = self::tabs( $course_id, 'questions' );
		$o .= '<div class="ec-bank-editor"><form class="ec-card ec-ws-form" data-ec-api="' . esc_attr( $path ) . '" data-ec-method="POST" data-ec-dirty' . ( $q ? ' data-ec-after="stay"' : '' ) . ' data-ec-bank-form novalidate>';
		$o .= '<div class="ec-ws-grid">' . Studio::field_select( 'type', __( 'Question type', 'educore-workspace' ), Types::labels(), (string) $v['type'] ) . Studio::field_select( 'lesson_id', __( 'Lesson / objective', 'educore-workspace' ), self::lessons( $course_id, __( 'Whole course', 'educore-workspace' ) ), (string) $v['lesson_id'] ) . '</div>';
		$o .= Studio::field_area( 'stem', __( 'Question text', 'educore-workspace' ), (string) $v['stem'], 4, __( 'Basic formatting is allowed. For fill in the blanks mark each blank as [[1]], [[2]]…', 'educore-workspace' ) );
		$o .= self::typed( 'options', Studio::field_area( 'options', __( 'Options', 'educore-workspace' ), (string) $v['options'], 5, $help['options'] ) );
		$o .= self::typed( 'correct', Studio::field_area( 'correct', __( 'Correct answer', 'educore-workspace' ), (string) $v['correct'], 3, $help['correct'] ) );
		$o .= self::typed( 'scoring', Studio::field_select( 'scoring', __( 'Scoring', 'educore-workspace' ), array( 'all' => __( 'All or nothing', 'educore-workspace' ), 'partial' => __( 'Partial credit', 'educore-workspace' ) ), (string) ( $v['scoring'] ?: 'all' ) ) );
				$img = (int) $v['image_id'];
		$o  .= self::typed( 'image_id', '<div class="ec-ws-field"><span class="ec-ws-label">' . esc_html__( 'Image', 'educore-workspace' ) . '</span><div class="ec-studio-cover" data-ec-media data-ec-media-title="' . esc_attr__( 'Choose the question image', 'educore-workspace' ) . '"><input type="hidden" name="image_id" value="' . $img . '"><span class="ec-studio-cover__preview">' . ( $img ? wp_get_attachment_image( $img, 'medium', false, array( 'alt' => '' ) ) : '' ) . '</span><button type="button" class="ec-btn" data-ec-media-pick>' . esc_html__( 'Choose image', 'educore-workspace' ) . '</button> <button class="ec-btn" type="button" data-ec-media-clear' . ( $img ? '' : ' hidden' ) . '>' . esc_html__( 'Remove', 'educore-workspace' ) . '</button></div><span class="ec-muted">' . esc_html__( 'Describe the image in the media library (alternative text) so every learner can answer.', 'educore-workspace' ) . '</span></div>' );
		$o .= self::typed( 'code', Studio::field_area( 'code', __( 'Code snippet', 'educore-workspace' ), (string) $v['code'], 5 ) );
		$o .= self::typed( 'language', Studio::field_text( 'language', __( 'Programming language', 'educore-workspace' ), (string) $v['language'] ) );
		$o .= self::typed( 'model_answer', Studio::field_area( 'model_answer', __( 'Model answer (shown to graders)', 'educore-workspace' ), (string) $v['model_answer'], 4 ) );
		$o .= self::typed( 'min_words', Studio::field_text( 'min_words', __( 'Minimum words', 'educore-workspace' ), (string) $v['min_words'], false, 'number' ) );
		$o .= self::typed( 'rubric', Studio::field_area( 'rubric', __( 'Grading rubric', 'educore-workspace' ), (string) $v['rubric'], 3, __( 'One criterion per line: "Criterion | points". Every change is kept as a new rubric version.', 'educore-workspace' ) ) );
		$o .= Studio::field_area( 'explanation', __( 'Explanation / feedback', 'educore-workspace' ), (string) $v['explanation'], 2 );
		$o .= '<div class="ec-ws-grid">' . Studio::field_text( 'points', __( 'Points', 'educore-workspace' ), (string) $v['points'], false, 'number' ) . Studio::field_select( 'difficulty', __( 'Difficulty', 'educore-workspace' ), self::difficulties(), (string) $v['difficulty'] ) . Studio::field_select( 'usage', __( 'Use in', 'educore-workspace' ), array( 'any' => __( 'Practice and assessments', 'educore-workspace' ), 'practice' => __( 'Practice only', 'educore-workspace' ), 'assessment' => __( 'Assessments only', 'educore-workspace' ) ), (string) $v['usage'] ) . '</div>';
		$o .= '<div class="ec-ws-grid">' . Studio::field_select( 'lang', __( 'Language', 'educore-workspace' ), I18n::labels(), (string) $v['lang'] ) . Studio::field_text( 'tags', __( 'Tags (comma separated)', 'educore-workspace' ), (string) $v['tags'] ) . '</div>';
		$st = array( 'draft' => self::status_label( 'draft' ), 'review' => __( 'Submit for review', 'educore-workspace' ) );
		if ( $pub || 'published' === $v['status'] ) {
			$st['published'] = self::status_label( 'published' );
		}
		if ( $q ) {
			$st['archived'] = self::status_label( 'archived' );
		}
		$o .= Studio::field_select( 'status', __( 'Status', 'educore-workspace' ), $st, (string) $v['status'] );
		if ( ! $pub ) {
			$o .= '<p class="ec-muted">' . esc_html__( 'A lead instructor or academic manager publishes questions after review.', 'educore-workspace' ) . '</p>';
		}
		$o .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Save question', 'educore-workspace' ) . '</button> <a class="ec-btn" href="' . esc_url( $sec ) . '">' . esc_html__( 'Back to the bank', 'educore-workspace' ) . '</a></div></form>';
		$o .= $q ? self::preview( $q ) : '';
		return $o . '</div>';
	}

	/** Author preview: what the learner sees, followed by the key (staff-only page). */
	private static function preview( array $q ): string {
		$v    = $q['version'];
		$view = Types::public_view( (string) $q['type'], (array) $v['payload'], null, 'preview' );
		$key  = (array) $v['answer_key'];
		$o    = '<aside class="ec-card ec-ws-section ec-bank-preview" aria-labelledby="ec-qprev"><h2 id="ec-qprev">' . esc_html__( 'Learner preview', 'educore-workspace' ) . '</h2>';
		$o   .= '<div class="ec-bank-stem">' . wp_kses_post( (string) $v['stem'] ) . '</div>';
		if ( ! empty( $view['image'] ) ) {
			$o .= '<p><img src="' . esc_url( $view['image'] ) . '" alt="' . esc_attr( (string) $view['alt'] ) . '" loading="lazy"></p>';
		}
		if ( ! empty( $view['code'] ) ) {
			$o .= '<pre class="ec-bank-code"><code>' . esc_html( $view['code'] ) . '</code></pre>';
		}
		$right = static fn( $id ) => in_array( $id, (array) ( $key['correct'] ?? array() ), true ) || ( $key['correct'] ?? null ) === $id;
		if ( ! empty( $view['options'] ) ) {
			$o .= '<ul class="ec-bank-opts">';
			foreach ( $view['options'] as $opt ) {
				$ok = $right( $opt['id'] );
				$o .= '<li' . ( $ok ? ' class="is-correct"' : '' ) . '>' . wp_kses_post( (string) $opt['text'] ) . ( $ok ? ' <span class="ec-chip ec-chip--publish">' . esc_html__( 'Correct', 'educore-workspace' ) . '</span>' : '' ) . '</li>';
			}
			$o .= '</ul>';
		}
		if ( 'truefalse' === $q['type'] ) {
			$o .= '<p>' . esc_html__( 'Correct answer:', 'educore-workspace' ) . ' <strong>' . esc_html( ! empty( $key['correct'] ) ? __( 'True', 'educore-workspace' ) : __( 'False', 'educore-workspace' ) ) . '</strong></p>';
		}
		if ( ! empty( $view['left'] ) ) {
			$right_text = array_column( (array) ( $q['version']['payload']['right'] ?? array() ), 'text', 'id' );
			$o         .= '<table class="ec-ws-table"><tbody>';
			foreach ( $view['left'] as $l ) {
				$o .= '<tr><td>' . wp_kses_post( (string) $l['text'] ) . '</td><td>→ ' . wp_kses_post( (string) ( $right_text[ $key['pairs'][ $l['id'] ] ?? '' ] ?? '' ) ) . '</td></tr>';
			}
			$o .= '</tbody></table>';
		}
		if ( 'ordering' === $q['type'] ) {
			$texts = array_column( (array) ( $v['payload']['items'] ?? array() ), 'text', 'id' );
			$o    .= '<ol>' . implode( '', array_map( static fn( $id ) => '<li>' . wp_kses_post( (string) ( $texts[ $id ] ?? '' ) ) . '</li>', (array) ( $key['order'] ?? array() ) ) ) . '</ol>';
		}
		foreach ( array( 'accepted' => __( 'Accepted answers:', 'educore-workspace' ), 'expected' => __( 'Expected output:', 'educore-workspace' ) ) as $k => $label ) {
			if ( ! empty( $key[ $k ] ) ) {
				$o .= '<p>' . esc_html( $label ) . ' <strong>' . esc_html( implode( ' · ', (array) $key[ $k ] ) ) . '</strong></p>';
			}
		}
		if ( ! empty( $key['blanks'] ) ) {
			$o .= '<ol>' . implode( '', array_map( static fn( $alts ) => '<li>' . esc_html( implode( ' | ', (array) $alts ) ) . '</li>', (array) $key['blanks'] ) ) . '</ol>';
		}
		if ( '' !== (string) $v['explanation'] ) {
			$o .= '<p class="ec-muted">' . wp_kses_post( (string) $v['explanation'] ) . '</p>';
		}
		$hist = Questions::history( (int) $q['id'] );
		$o   .= '<h3>' . esc_html__( 'Versions', 'educore-workspace' ) . '</h3><ul class="ec-ws-list">';
		foreach ( $hist as $h ) {
			/* translators: %d: version number */
			$o .= '<li><span>' . esc_html( sprintf( __( 'Version %d', 'educore-workspace' ), (int) $h['version_no'] ) ) . ' · ' . esc_html( get_date_from_gmt( (string) $h['created_at'], get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ) . '</span>' . ( (int) $h['used'] ? '<span class="ec-chip ec-chip--warn">' . esc_html__( 'Used in attempts (locked)', 'educore-workspace' ) . '</span>' : '' ) . '</li>';
		}
		return $o . '</ul><p class="ec-muted">' . esc_html__( 'A version that learners have answered is never changed: saving creates a new version.', 'educore-workspace' ) . '</p></aside>';
	}

	/* ---------- Import / export ---------- */

	private static function import( int $uid, int $course_id ): string {
		Shell::title( __( 'Import questions', 'educore-workspace' ) );
		self::crumbs( $course_id, __( 'Question bank', 'educore-workspace' ), self::url( array( 'bank' => $course_id ) ), __( 'Import', 'educore-workspace' ) );
		$o   = self::tabs( $course_id, 'import' );
		$fmt = array( 'auto' => __( 'Detect from the file', 'educore-workspace' ) ) + array_map( static fn( $f ) => $f['label'], Formats::all() );
		$st  = array( '' => __( 'Keep the status in the file (default: draft)', 'educore-workspace' ), 'draft' => self::status_label( 'draft' ), 'review' => self::status_label( 'review' ) );
		if ( Bank::can_publish( $uid, $course_id ) ) {
			$st['published'] = self::status_label( 'published' );
		}
		$o .= '<form class="ec-card ec-ws-form ec-studio-narrow" data-ec-upload="' . esc_attr( 'bank/' . $course_id . '/imports' ) . '" novalidate>';
		$o .= '<p>' . esc_html__( 'Nothing is written to the bank until you confirm: the file is first validated and you see a preview of every question.', 'educore-workspace' ) . '</p>';
		$o .= '<label class="ec-ws-field" for="ec-f-file"><span class="ec-ws-label">' . esc_html__( 'File', 'educore-workspace' ) . ' <abbr title="' . esc_attr__( 'required', 'educore-workspace' ) . '">*</abbr></span><input id="ec-f-file" type="file" name="file" required aria-required="true" accept=".zip,.xlsx,.csv,.json,.xml,.gift,.txt"><span class="ec-muted">' . esc_html__( 'EduCore package, Excel, CSV, JSON, Moodle XML or GIFT — up to 10 MB.', 'educore-workspace' ) . '</span></label>';
		$o .= '<div class="ec-ws-grid">' . Studio::field_select( 'format', __( 'Format', 'educore-workspace' ), $fmt, 'auto' ) . Studio::field_select( 'mode', __( 'Questions that already exist', 'educore-workspace' ), Jobs::modes(), 'skip' ) . '</div>';
		$o .= '<div class="ec-ws-grid">' . Studio::field_select( 'status', __( 'Status of imported questions', 'educore-workspace' ), $st, '' ) . Studio::field_select( 'lang', __( 'Language (if not in the file)', 'educore-workspace' ), array( '' => '—' ) + I18n::labels(), '' ) . '</div>';
		$o .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Upload and validate', 'educore-workspace' ) . '</button></div></form>';
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Templates', 'educore-workspace' ) . '</h2><p>' . esc_html__( 'Start from a template with one example of every question type.', 'educore-workspace' ) . '</p><p class="ec-ws-actions"><a class="ec-btn" href="' . esc_url( Bank::download_url( 'template', $course_id, array( 'format' => 'xlsx' ) ) ) . '">' . esc_html__( 'Excel template', 'educore-workspace' ) . '</a> <a class="ec-btn" href="' . esc_url( Bank::download_url( 'template', $course_id, array( 'format' => 'csv' ) ) ) . '">' . esc_html__( 'CSV template', 'educore-workspace' ) . '</a></p></section>';
		$jobs = Bank::jobs( $uid, $course_id );
		if ( $jobs ) {
			$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Recent imports', 'educore-workspace' ) . '</h2><ul class="ec-ws-list">';
			foreach ( $jobs as $j ) {
				$o .= '<li><a href="' . esc_url( self::url( array( 'bank' => $course_id, 'job' => (int) $j['id'] ) ) ) . '">' . esc_html( (string) $j['filename'] ) . '</a><span class="ec-muted">' . esc_html( Center::label( (string) $j['status'] ) ) . ' · ' . esc_html( get_date_from_gmt( (string) $j['created_at'], get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ) . '</span></li>';
			}
			$o .= '</ul></section>';
		}
		return $o;
	}

	private static function job( int $uid, int $course_id, int $job_id ): string {
		$job = Bank::job( $uid, $job_id );
		if ( ! $job || (int) $job['course_id'] !== $course_id ) {
			Shell::title( __( 'Import questions', 'educore-workspace' ) );
			return Studio::notice( __( 'Import not found.', 'educore-workspace' ), 'error' );
		}
		/* translators: %s: file name */
		$title = sprintf( __( 'Import: %s', 'educore-workspace' ), (string) $job['filename'] );
		Shell::title( $title, '<span class="ec-chip">' . esc_html( Center::label( (string) $job['status'] ) ) . '</span>' );
		self::crumbs( $course_id, __( 'Import', 'educore-workspace' ), self::url( array( 'bank' => $course_id, 'x' => 'import' ) ), (string) $job['filename'] );
		$s    = in_array( $job['status'], array( 'validated', 'importing' ), true ) ? Jobs::summarise( $job_id ) : (array) $job['summary'];
		$base = 'bank/' . $course_id . '/imports/' . $job_id;
		$o    = self::tabs( $course_id, 'import' );
		$o   .= '<section class="ec-card ec-ws-section" aria-labelledby="ec-jsum"><h2 id="ec-jsum">' . esc_html__( 'Summary', 'educore-workspace' ) . '</h2><dl class="ec-ws-kv">';
		$o   .= '<dt>' . esc_html__( 'Questions in the file', 'educore-workspace' ) . '</dt><dd>' . (int) ( $s['total'] ?? 0 ) . '</dd>';
		$o   .= '<dt>' . esc_html__( 'Valid', 'educore-workspace' ) . '</dt><dd>' . (int) ( $s['valid'] ?? 0 ) . '</dd>';
		$o   .= '<dt>' . esc_html__( 'Invalid', 'educore-workspace' ) . '</dt><dd>' . (int) ( $s['invalid'] ?? 0 ) . '</dd>';
		$o   .= '<dt>' . esc_html__( 'With warnings', 'educore-workspace' ) . '</dt><dd>' . (int) ( $s['with_warnings'] ?? 0 ) . '</dd>';
		foreach ( array_merge( (array) ( $s['actions'] ?? array() ), (array) ( $s['results'] ?? array() ) ) as $k => $n ) {
			$o .= '<dt>' . esc_html( Center::label( (string) $k ) ) . '</dt><dd>' . (int) $n . '</dd>';
		}
		$o .= '</dl>';
		if ( 'validated' === $job['status'] ) {
			$n  = array_sum( array_intersect_key( (array) ( $s['actions'] ?? array() ), array_flip( array( 'create', 'update', 'new_version' ) ) ) );
			$o .= '<form class="ec-ws-inline" data-ec-api="' . esc_attr( $base . '/mode' ) . '" data-ec-method="POST">' . Studio::field_select( 'mode', __( 'Questions that already exist', 'educore-workspace' ), Jobs::modes(), (string) $job['mode'] ) . ' <button class="ec-btn" type="submit">' . esc_html__( 'Recalculate preview', 'educore-workspace' ) . '</button></form>';
			/* translators: %d: number of questions */
			$label = sprintf( _n( 'Confirm import of %d question', 'Confirm import of %d questions', (int) $n, 'educore-workspace' ), (int) $n );
			$o    .= '<p class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="button" data-ec-call="' . esc_attr( $base . '/commit' ) . '"' . ( $n ? '' : ' disabled' ) . ' data-ec-confirm="' . esc_attr__( 'Write these questions to the bank now?', 'educore-workspace' ) . '">' . esc_html( $label ) . '</button> <button class="ec-btn" type="button" data-ec-call="' . esc_attr( $base . '/cancel' ) . '">' . esc_html__( 'Cancel import', 'educore-workspace' ) . '</button></p>';
		} elseif ( 'importing' === $job['status'] ) {
			$o .= '<p class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="button" data-ec-call="' . esc_attr( $base . '/commit' ) . '">' . esc_html__( 'Resume import', 'educore-workspace' ) . '</button></p>';
		}
		$o .= '<p><a class="ec-btn ec-btn--small" href="' . esc_url( Bank::download_url( 'report', $course_id, array( 'job' => $job_id ) ) ) . '">' . esc_html__( 'Download the report (CSV)', 'educore-workspace' ) . '</a></p></section>';
		$o .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><caption class="screen-reader-text">' . esc_html__( 'Questions in the file', 'educore-workspace' ) . '</caption><thead><tr><th scope="col">' . esc_html__( 'Line', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Type', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Question', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Result', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Messages', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( Jobs::items( $job_id, 300 ) as $it ) {
			$rec  = (array) json_decode( (string) $it['record'], true );
			$msgs = (array) json_decode( (string) $it['messages'], true );
			$res  = 'valid' === $it['status'] ? Center::label( (string) $it['action'] ) : Center::label( (string) $it['status'] );
			$link = (int) $it['question_id'] && ! in_array( $it['status'], array( 'valid', 'invalid' ), true ) ? ' <a href="' . esc_url( self::url( array( 'bank' => $course_id, 'q' => (int) $it['question_id'] ) ) ) . '">#' . (int) $it['question_id'] . '</a>' : '';
			$ml   = implode( '<br>', array_map( static fn( $m ) => '<span class="' . ( 'e' === ( $m[0] ?? '' ) ? 'ec-msg-error">✗ ' : 'ec-msg-warn">⚠ ' ) . esc_html( (string) ( $m[1] ?? '' ) ) . '</span>', $msgs ) );
			$o   .= '<tr' . ( 'invalid' === $it['status'] || 'failed' === $it['status'] ? ' class="is-invalid"' : '' ) . '><td>' . (int) $it['line'] . '</td><td>' . esc_html( (string) ( $rec['type'] ?? '' ) ) . '</td><td>' . esc_html( mb_strimwidth( wp_strip_all_tags( (string) ( $rec['stem'] ?? '' ) ), 0, 120, '…' ) ) . '</td><td>' . esc_html( $res ) . $link . '</td><td>' . $ml . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
		return $o . '</tbody></table></div>';
	}

	private static function export( int $uid, int $course_id ): string {
		Shell::title( __( 'Export questions', 'educore-workspace' ) );
		self::crumbs( $course_id, __( 'Question bank', 'educore-workspace' ), self::url( array( 'bank' => $course_id ) ), __( 'Export', 'educore-workspace' ) );
		$o  = self::tabs( $course_id, 'export' );
		$o .= '<form class="ec-card ec-ws-form ec-studio-narrow" method="get" action="' . esc_url( self::url() ) . '">';
		$o .= '<input type="hidden" name="ec_bank_dl" value="export"><input type="hidden" name="course" value="' . (int) $course_id . '"><input type="hidden" name="_ecdl" value="' . esc_attr( wp_create_nonce( 'ec_bank_dl_export_' . $course_id ) ) . '">';
		$o .= Studio::field_select( 'format', __( 'Format', 'educore-workspace' ), array_map( static fn( $f ) => $f['label'], Formats::all() ), 'native' );
		$o .= '<p class="ec-muted">' . esc_html__( 'Moodle GIFT and Moodle XML cannot carry fill-in-the-blank, ordering, code and image questions; they are left out of those files.', 'educore-workspace' ) . '</p>';
		$o .= '<div class="ec-ws-grid">' . Studio::field_select( 'status', __( 'Status', 'educore-workspace' ), array( '' => __( 'All except archived', 'educore-workspace' ), 'draft' => self::status_label( 'draft' ), 'review' => self::status_label( 'review' ), 'published' => self::status_label( 'published' ) ), '' ) . Studio::field_select( 'type', __( 'Type', 'educore-workspace' ), array( '' => __( 'All types', 'educore-workspace' ) ) + Types::labels(), '' ) . '</div>';
		$o .= '<div class="ec-ws-grid">' . Studio::field_select( 'difficulty', __( 'Difficulty', 'educore-workspace' ), self::difficulties( true ), '' ) . Studio::field_select( 'lesson_id', __( 'Lesson', 'educore-workspace' ), self::lessons( $course_id, __( 'All lessons', 'educore-workspace' ) ), '' ) . '</div>';
		$o .= Studio::field_text( 'tag', __( 'Tag', 'educore-workspace' ), '' );
		$o .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Download', 'educore-workspace' ) . '</button></div></form>';
		$skipped = get_transient( 'educore_ws_bank_skipped_' . $uid );
		if ( is_array( $skipped ) && $skipped ) {
			delete_transient( 'educore_ws_bank_skipped_' . $uid );
			/* translators: %d: count */
			$o .= Studio::notice( sprintf( _n( '%d question could not be written in the last export format.', '%d questions could not be written in the last export format.', count( $skipped ), 'educore-workspace' ), count( $skipped ) ), 'warn' );
		}
		return $o;
	}

	/* ===================== Assessments ===================== */

	public static function assessments( int $uid, int $course_id ): string {
		if ( ! Builder::can( $uid, $course_id ) ) {
			Shell::title( __( 'Assessments', 'educore-workspace' ) );
			return Studio::notice( __( 'You cannot manage the assessments of this course.', 'educore-workspace' ), 'error' );
		}
		if ( '' !== self::q( 'a' ) ) {
			return self::flash() . self::builder( $uid, $course_id, 'new' === self::q( 'a' ) ? 0 : (int) self::q( 'a' ) );
		}
		$new = '<a class="ec-btn ec-btn--primary" href="' . esc_url( self::url( array( 'assess' => $course_id, 'a' => 'new' ) ) ) . '">' . esc_html__( 'New assessment', 'educore-workspace' ) . '</a>';
		Shell::title( __( 'Assessments', 'educore-workspace' ), $new );
		self::crumbs( $course_id, __( 'Assessments', 'educore-workspace' ), '' );
		$o    = self::flash() . self::tabs( $course_id, 'assessments' );
		$rows = Builder::list( $uid, $course_id );
		$o   .= '<p class="ec-ws-actions"><button class="ec-btn" type="button" data-ec-call="' . esc_attr( 'assess/' . $course_id . '/template' ) . '">' . esc_html__( 'Create a chapter examination from the template', 'educore-workspace' ) . '</button></p>';
		if ( ! $rows ) {
			return $o . '<div class="ec-ws-empty"><p>' . esc_html__( 'No assessments yet.', 'educore-workspace' ) . '</p><p>' . $new . '</p></div>';
		}
		$pub = Builder::can_publish( $uid, $course_id );
		$o  .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><thead><tr><th scope="col">' . esc_html__( 'Title', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Kind', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Availability', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Ready', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Actions', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $a ) {
			$id    = (int) $a['id'];
			$edit  = self::url( array( 'assess' => $course_id, 'a' => $id ) );
			$ready = Builder::readiness( $a );
			$base  = 'assess/' . $course_id . '/assessments/' . $id;
			$s     = $a['settings'];
			$win   = trim( ( $s['opens_at'] ? Assessments::format_local( $s['opens_at'] ) : '' ) . ( $s['closes_at'] ? ' → ' . Assessments::format_local( $s['closes_at'] ) : '' ) ) ?: __( 'Always open', 'educore-workspace' );
			$acts  = '<a class="ec-btn ec-btn--small" href="' . esc_url( $edit ) . '">' . esc_html__( 'Edit', 'educore-workspace' ) . '</a> <button class="ec-btn ec-btn--small" type="button" data-ec-call="' . esc_attr( $base . '/duplicate' ) . '">' . esc_html__( 'Duplicate', 'educore-workspace' ) . '</button> ';
			if ( $pub && 'draft' === $a['status'] ) {
				$acts .= '<button class="ec-btn ec-btn--small ec-btn--primary" type="button" data-ec-call="' . esc_attr( $base . '/status' ) . '" data-ec-body="' . esc_attr( '{"status":"published"}' ) . '"' . ( $ready['ok'] ? '' : ' disabled' ) . '>' . esc_html__( 'Publish', 'educore-workspace' ) . '</button> ';
			}
			if ( 'published' === $a['status'] ) {
				$acts .= '<button class="ec-btn ec-btn--small" type="button" data-ec-call="' . esc_attr( $base . '/status' ) . '" data-ec-body="' . esc_attr( '{"status":"draft"}' ) . '" data-ec-confirm="' . esc_attr__( 'Unpublish? Learners will no longer be able to start new attempts.', 'educore-workspace' ) . '">' . esc_html__( 'Unpublish', 'educore-workspace' ) . '</button> ';
			}
			if ( 'archived' !== $a['status'] ) {
				$acts .= '<button class="ec-btn ec-btn--small ec-btn--danger" type="button" data-ec-call="' . esc_attr( $base . '/status' ) . '" data-ec-body="' . esc_attr( '{"status":"archived"}' ) . '" data-ec-confirm="' . esc_attr__( 'Archive this assessment? Results are kept.', 'educore-workspace' ) . '">' . esc_html__( 'Archive', 'educore-workspace' ) . '</button>';
			}
			/* translators: 1: number of questions, 2: points */
			$rd = $ready['ok'] ? '<span class="ec-chip ec-chip--publish">' . esc_html( sprintf( __( '%1$d questions · %2$s pts', 'educore-workspace' ), $ready['count'], (string) ( 0 + $ready['points'] ) ) ) . '</span>' : '<span class="ec-chip ec-chip--warn">' . esc_html__( 'Not ready', 'educore-workspace' ) . '</span>';
			$o .= '<tr><td><a href="' . esc_url( $edit ) . '">' . esc_html( (string) $a['title'] ) . '</a></td><td>' . esc_html( self::kinds()[ $a['kind'] ] ?? $a['kind'] ) . '</td><td>' . esc_html( $win ) . '</td><td>' . $rd . '</td><td>' . self::chip( (string) $a['status'] ) . '</td><td class="ec-ws-actions">' . $acts . '</td></tr>';
		}
		return $o . '</tbody></table></div>';
	}

	private static function pool_row( int $course_id, array $p, array $lessons ): string {
		$sel = static function ( string $name, array $opts, string $val, string $label ) {
			$o = '<label><span>' . esc_html( $label ) . '</span><select name="' . esc_attr( $name ) . '[]">';
			foreach ( $opts as $k => $v ) {
				$o .= '<option value="' . esc_attr( (string) $k ) . '"' . selected( $val, (string) $k, false ) . '>' . esc_html( $v ) . '</option>';
			}
			return $o . '</select></label>';
		};
		$num = static fn( string $name, string $val, string $label, string $step = '1' ) => '<label><span>' . esc_html( $label ) . '</span><input type="number" min="0" step="' . esc_attr( $step ) . '" inputmode="decimal" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( $val ) . '"></label>';
		$o   = '<fieldset class="ec-bank-pool" data-ec-pool><legend>' . esc_html__( 'Question pool', 'educore-workspace' ) . '</legend><div class="ec-ws-grid">';
		$o  .= $sel( 'pool_qtype', array( '' => __( 'Any type', 'educore-workspace' ) ) + Types::labels(), (string) ( $p['qtype'] ?? '' ), __( 'Type', 'educore-workspace' ) );
		$o  .= $sel( 'pool_lesson', $lessons, (string) ( (int) ( $p['lesson_id'] ?? 0 ) ?: '' ), __( 'Lesson', 'educore-workspace' ) );
		$o  .= $sel( 'pool_difficulty', self::difficulties( true ), (string) ( $p['difficulty'] ?? '' ), __( 'Difficulty', 'educore-workspace' ) );
		$o  .= '<label><span>' . esc_html__( 'Tag', 'educore-workspace' ) . '</span><input type="text" name="pool_tag[]" value="' . esc_attr( (string) ( $p['tag'] ?? '' ) ) . '"></label>';
		$o  .= $num( 'pool_count', (string) ( (int) ( $p['question_id'] ?? 0 ) ? '' : ( $p['draw_count'] ?? '' ) ), __( 'Questions to draw', 'educore-workspace' ) );
		$o  .= $num( 'pool_points', (string) ( isset( $p['points_each'] ) && (float) $p['points_each'] > 0 ? 0 + (float) $p['points_each'] : '' ), __( 'Points each (blank = question points)', 'educore-workspace' ), '0.5' );
		$o  .= $num( 'pool_question', (string) ( (int) ( $p['question_id'] ?? 0 ) ?: '' ), __( 'Or one fixed question #', 'educore-workspace' ) );
		return $o . '</div><button type="button" class="ec-btn ec-btn--small ec-btn--danger" data-ec-pool-remove>' . esc_html__( 'Remove pool', 'educore-workspace' ) . '</button></fieldset>';
	}

	private static function builder( int $uid, int $course_id, int $id ): string {
		$a   = $id ? Builder::get( $uid, $course_id, $id ) : null;
		$sec = self::url( array( 'assess' => $course_id ) );
		if ( $id && ! $a ) {
			Shell::title( __( 'Assessments', 'educore-workspace' ) );
			return Studio::notice( __( 'Assessment not found in this course.', 'educore-workspace' ), 'error' );
		}
		$kind  = $a['kind'] ?? 'quiz';
		$s     = $a['settings'] ?? Assessments::defaults( $kind );
		$title = $a ? (string) $a['title'] : __( 'New assessment', 'educore-workspace' );
		Shell::title( $title, $a ? self::chip( (string) $a['status'] ) : '' );
		self::crumbs( $course_id, __( 'Assessments', 'educore-workspace' ), $sec, $title );
		$lessons = self::lessons( $course_id, __( 'Any lesson', 'educore-workspace' ) );
		$pub     = Builder::can_publish( $uid, $course_id );
		$o       = self::tabs( $course_id, 'assessments' );
		$o      .= '<div class="ec-bank-editor"><form class="ec-card ec-ws-form" data-ec-api="' . esc_attr( 'assess/' . $course_id . '/assessments' . ( $a ? '/' . $id : '' ) ) . '" data-ec-method="POST" data-ec-dirty novalidate><input type="hidden" name="pools_present" value="1">';
		$o      .= '<fieldset><legend>' . esc_html__( 'Basics', 'educore-workspace' ) . '</legend>' . Studio::field_text( 'title', __( 'Title', 'educore-workspace' ), $a ? (string) $a['title'] : '', true );
		$o      .= '<div class="ec-ws-grid">' . Studio::field_select( 'kind', __( 'Kind', 'educore-workspace' ), self::kinds(), $kind ) . Studio::field_select( 'lesson_id', __( 'Attached to lesson', 'educore-workspace' ), array( '' => __( 'Course level', 'educore-workspace' ) ) + array_slice( $lessons, 1, null, true ), (string) ( (int) ( $a['lesson_id'] ?? 0 ) ?: '' ) ) . '</div>';
		$o      .= Studio::field_area( 's_instructions', __( 'Instructions for learners', 'educore-workspace' ), (string) $s['instructions'], 3 ) . '</fieldset>';
		$o      .= '<fieldset><legend>' . esc_html__( 'Rules', 'educore-workspace' ) . '</legend><div class="ec-ws-grid">' . Studio::field_text( 's_duration', __( 'Time limit (minutes, 0 = none)', 'educore-workspace' ), (string) $s['duration'], false, 'number' ) . Studio::field_text( 's_attempts', __( 'Attempts allowed (0 = unlimited)', 'educore-workspace' ), (string) $s['attempts'], false, 'number' ) . Studio::field_text( 's_pass_mark', __( 'Pass mark (%)', 'educore-workspace' ), (string) ( 0 + $s['pass_mark'] ), false, 'number' ) . Studio::field_text( 's_total_mark', __( 'Scale to total mark (0 = raw points)', 'educore-workspace' ), (string) ( 0 + $s['total_mark'] ), false, 'number' ) . '</div>';
		$o      .= '<div class="ec-ws-grid"><label class="ec-ws-check"><input type="hidden" name="s_shuffle_questions" value="0"><input type="checkbox" name="s_shuffle_questions" value="1"' . checked( $s['shuffle_questions'], true, false ) . '> ' . esc_html__( 'Shuffle questions', 'educore-workspace' ) . '</label><label class="ec-ws-check"><input type="hidden" name="s_shuffle_options" value="0"><input type="checkbox" name="s_shuffle_options" value="1"' . checked( $s['shuffle_options'], true, false ) . '> ' . esc_html__( 'Shuffle answer options', 'educore-workspace' ) . '</label></div>';
		$o      .= '<div class="ec-ws-grid">' . Studio::field_select( 's_release', __( 'Results', 'educore-workspace' ), array( 'auto' => __( 'Released automatically', 'educore-workspace' ), 'manual' => __( 'Released by the teacher', 'educore-workspace' ) ), (string) $s['release'] ) . Studio::field_select( 's_feedback', __( 'Show answers and feedback', 'educore-workspace' ), array( 'none' => __( 'Never', 'educore-workspace' ), 'after_release' => __( 'After results are released', 'educore-workspace' ), 'after_attempts_exhausted' => __( 'After the last attempt', 'educore-workspace' ) ), (string) $s['feedback'] ) . '</div></fieldset>';
		/* translators: %s: timezone name */
		$o .= '<fieldset><legend>' . esc_html__( 'Schedule', 'educore-workspace' ) . '</legend><p class="ec-muted">' . esc_html( sprintf( __( 'Times are in %s.', 'educore-workspace' ), Assessments::timezone_label() ) ) . '</p><div class="ec-ws-grid">' . Studio::field_text( 's_opens_at', __( 'Opens', 'educore-workspace' ), Assessments::utc_to_local_input( (string) $s['opens_at'] ), false, 'datetime-local' ) . Studio::field_text( 's_closes_at', __( 'Closes', 'educore-workspace' ), Assessments::utc_to_local_input( (string) $s['closes_at'] ), false, 'datetime-local' ) . '</div></fieldset>';
		$o .= '<fieldset><legend>' . esc_html__( 'Questions', 'educore-workspace' ) . '</legend><p class="ec-muted">' . esc_html__( 'Each pool draws questions at random from the published bank. A different selection is drawn for every attempt.', 'educore-workspace' ) . '</p><div data-ec-pools>';
		$pools = $a ? Assessments::pools( $id ) : array( array( 'draw_count' => 10 ) );
		foreach ( $pools as $p ) {
			$o .= self::pool_row( $course_id, $p, $lessons );
		}
		$o .= '</div><template data-ec-pool-template>' . self::pool_row( $course_id, array(), $lessons ) . '</template><button type="button" class="ec-btn ec-btn--small" data-ec-pool-add>' . esc_html__( 'Add a pool', 'educore-workspace' ) . '</button></fieldset>';
		$st = array( 'draft' => self::status_label( 'draft' ) );
		if ( $pub || 'published' === ( $a['status'] ?? '' ) ) {
			$st['published'] = self::status_label( 'published' );
		}
		if ( $a ) {
			$st['archived'] = self::status_label( 'archived' );
		}
		$o .= Studio::field_select( 'status', __( 'Status', 'educore-workspace' ), $st, (string) ( $a['status'] ?? 'draft' ) );
		if ( ! $pub ) {
			$o .= '<p class="ec-muted">' . esc_html__( 'A lead instructor or academic manager publishes assessments.', 'educore-workspace' ) . '</p>';
		}
		$o .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Save assessment', 'educore-workspace' ) . '</button> <a class="ec-btn" href="' . esc_url( $sec ) . '">' . esc_html__( 'Back to assessments', 'educore-workspace' ) . '</a></div></form>';
		if ( $a ) {
			$o .= self::readiness_panel( $course_id, $a );
		}
		return $o . '</div>';
	}

	private static function readiness_panel( int $course_id, array $a ): string {
		$ready = Builder::readiness( $a );
		$o     = '<aside class="ec-card ec-ws-section ec-bank-preview" aria-labelledby="ec-aprev"><h2 id="ec-aprev">' . esc_html__( 'Readiness', 'educore-workspace' ) . '</h2>';
		if ( ! $ready['ok'] ) {
			return $o . Studio::notice( $ready['message'], 'warn' ) . '<p><a class="ec-btn ec-btn--small" href="' . esc_url( self::url( array( 'bank' => $course_id ) ) ) . '">' . esc_html__( 'Open the question bank', 'educore-workspace' ) . '</a></p></aside>';
		}
		$s = $a['settings'];
		/* translators: 1: number of questions, 2: points */
		$o .= '<p>' . esc_html( sprintf( __( 'Each attempt has %1$d questions worth %2$s points.', 'educore-workspace' ), $ready['count'], (string) ( 0 + $ready['points'] ) ) ) . '</p>';
		if ( (float) $s['total_mark'] > 0 ) {
			/* translators: %s: total mark */
			$o .= '<p class="ec-muted">' . esc_html( sprintf( __( 'Scores are scaled to %s.', 'educore-workspace' ), (string) ( 0 + $s['total_mark'] ) ) ) . '</p>';
		}
		$o .= '<h3>' . esc_html__( 'Sample draw', 'educore-workspace' ) . '</h3><ol class="ec-bank-sample">';
		foreach ( array_slice( Builder::sample( $a ), 0, 50 ) as $c ) {
			$ver = Questions::version( (int) $c['version_id'] );
			$o  .= '<li><a href="' . esc_url( self::url( array( 'bank' => $course_id, 'q' => (int) $c['qid'] ) ) ) . '">' . esc_html( mb_strimwidth( wp_strip_all_tags( (string) ( $ver['stem'] ?? '' ) ), 0, 90, '…' ) ) . '</a> <span class="ec-muted">' . esc_html( (string) ( 0 + (float) $c['points'] ) ) . '</span></li>';
		}
		return $o . '</ol><p class="ec-muted">' . esc_html__( 'Reload to see another random draw.', 'educore-workspace' ) . '</p></aside>';
	}
}
