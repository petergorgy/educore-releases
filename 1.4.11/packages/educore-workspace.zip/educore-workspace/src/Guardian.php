<?php
namespace EduCore\Workspace;

use EduCore\Core\Enrollment;
use EduCore\Core\Privacy;
use EduCore\Core\Progress;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Guardian workspace on the existing /guardian/ page: a consent link (?educore_guardian=…) still shows the consent
 * form; a signed-in guardian sees their linked learners. Every learner shown passes Privacy::guardian_has_access().
 */
final class Guardian {

	public static function register(): void {
		add_filter( 'render_block', array( self::class, 'render_block' ), 10, 2 );
	}

	public static function is_guardian( int $uid ): bool {
		$u = $uid ? get_userdata( $uid ) : null;
		return $u && in_array( 'ec_guardian', (array) $u->roles, true );
	}

	public static function render_block( $html, $block ) {
		if ( 'educore/guardian-consent' !== ( $block['blockName'] ?? '' ) || 'guardian' !== Shell::workspace() ) {
			return $html;
		}
		return self::portal( get_current_user_id() );
	}

	/** @return int[] learner ids this guardian may see */
	public static function learners( int $uid ): array {
		global $wpdb;
		$u = get_userdata( $uid );
		if ( ! $u ) {
			return array();
		}
		$ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT student_id FROM ' . Schema::table( 'guardian_links' ) . " WHERE status='verified' AND (guardian_user_id=%d OR guardian_email=%s)", $uid, $u->user_email ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		return array_values( array_filter( $ids, static fn( $sid ) => Privacy::guardian_has_access( $uid, $sid ) ) );
	}

	public static function portal( int $uid ): string {
		Shell::title( __( 'My learners', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Guardian', 'educore-workspace' ) ), array( __( 'My learners', 'educore-workspace' ) ) ) );
		$ids = self::learners( $uid );
		if ( ! $ids ) {
			return '<div class="ec-ws-empty"><p>' . esc_html__( 'No learner is linked to your account yet. The school links guardians to learners; if you expected to see someone here, contact the school.', 'educore-workspace' ) . '</p></div>';
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only selector, validated against the allowed list.
		$sel = isset( $_GET['learner'] ) ? (int) $_GET['learner'] : $ids[0];
		if ( ! in_array( $sel, $ids, true ) ) {
			$sel = $ids[0];
		}
		$o = '';
		if ( count( $ids ) > 1 ) {
			$o .= '<nav class="ec-ws-tabs" aria-label="' . esc_attr__( 'Learners', 'educore-workspace' ) . '"><ul>';
			foreach ( $ids as $sid ) {
				$s  = get_userdata( $sid );
				$o .= '<li><a href="' . esc_url( add_query_arg( 'learner', $sid ) ) . '"' . ( $sid === $sel ? ' aria-current="page"' : '' ) . '>' . esc_html( $s ? $s->display_name : '#' . $sid ) . '</a></li>';
			}
			$o .= '</ul></nav>';
		}
		$s  = get_userdata( $sel );
		$o .= '<h2 class="ec-ws-h2">' . esc_html( $s->display_name ) . '</h2><div class="ec-ws-cols">';
		// Courses and progress.
		$o .= '<section class="ec-card ec-ws-section"><h3>' . esc_html__( 'Courses and progress', 'educore-workspace' ) . '</h3>';
		$en = Enrollment::for_user( $sel );
		if ( ! $en ) {
			$o .= '<p class="ec-muted">' . esc_html__( 'Not enrolled in any course yet.', 'educore-workspace' ) . '</p>';
		} else {
			$o .= '<ul class="ec-ws-list">';
			foreach ( $en as $e ) {
				$p  = Progress::course_summary( $sel, (int) $e['course_id'] );
				/* translators: 1: completed lessons, 2: total lessons */
				$o .= '<li><span>' . esc_html( get_the_title( (int) $e['course_id'] ) ) . '<br><span class="ec-muted">' . esc_html( sprintf( __( '%1$d of %2$d lessons', 'educore-workspace' ), $p['completed'], $p['total'] ) ) . '</span></span><span class="ec-ws-meter" role="img" aria-label="' . esc_attr( $p['percent'] . '%' ) . '"><span style="width:' . (int) $p['percent'] . '%"></span></span></li>';
			}
			$o .= '</ul>';
		}
		$o .= '</section>';
		if ( class_exists( '\EduCore\TeachingHub\Assignments' ) ) {
			$now      = gmdate( 'Y-m-d H:i:s' );
			$upcoming = array();
			$feedback = array();
			foreach ( \EduCore\TeachingHub\Assignments::for_student( $sel ) as $a ) {
				if ( $a['due_at'] && $a['due_at'] >= $now && in_array( (string) $a['sub_status'], array( '', 'draft' ), true ) ) {
					$upcoming[] = $a;
				}
				if ( (int) $a['released'] && null !== $a['score'] ) {
					$feedback[] = $a;
				}
			}
			$o .= '<section class="ec-card ec-ws-section"><h3>' . esc_html__( 'Upcoming deadlines', 'educore-workspace' ) . '</h3>';
			$o .= $upcoming ? '<ul class="ec-ws-list">' . implode( '', array_map( static fn( $a ) => '<li><span>' . esc_html( $a['title'] ) . '</span><time datetime="' . esc_attr( $a['due_at'] ) . '">' . esc_html( get_date_from_gmt( $a['due_at'], get_option( 'date_format' ) ) ) . '</time></li>', array_slice( $upcoming, 0, 10 ) ) ) . '</ul>' : '<p class="ec-muted">' . esc_html__( 'Nothing due.', 'educore-workspace' ) . '</p>';
			$o .= '</section><section class="ec-card ec-ws-section"><h3>' . esc_html__( 'Released results', 'educore-workspace' ) . '</h3>';
			$o .= $feedback ? '<ul class="ec-ws-list">' . implode( '', array_map( static fn( $a ) => '<li><span>' . esc_html( $a['title'] ) . '</span><strong>' . esc_html( number_format_i18n( (float) $a['score'], 1 ) . ' / ' . number_format_i18n( (float) $a['max_score'], 1 ) ) . '</strong></li>', array_slice( array_reverse( $feedback ), 0, 10 ) ) ) . '</ul>' : '<p class="ec-muted">' . esc_html__( 'No released results yet.', 'educore-workspace' ) . '</p>';
			$o .= '</section>';
		}
		$o .= Family::guardian_section( $uid, $sel );
		if ( class_exists( '\EduCore\TeachingHub\Attendance' ) ) {
			$att   = \EduCore\TeachingHub\Attendance::student_summary( $sel, gmdate( 'Y-m-d', time() - 30 * DAY_IN_SECONDS ) );
			$total = array_sum( $att );
			$o    .= '<section class="ec-card ec-ws-section"><h3>' . esc_html__( 'Attendance (last 30 days)', 'educore-workspace' ) . '</h3>';
			if ( $total ) {
				$o    .= '<ul class="ec-ws-list">';
				$names = array( 'present' => __( 'Present', 'educore-workspace' ), 'absent' => __( 'Absent', 'educore-workspace' ), 'late' => __( 'Late', 'educore-workspace' ), 'excused' => __( 'Excused', 'educore-workspace' ) );
				foreach ( $att as $k => $n ) {
					$o .= '<li><span>' . esc_html( $names[ $k ] ?? ucfirst( (string) $k ) ) . '</span><strong>' . esc_html( number_format_i18n( $n ) ) . '</strong></li>';
				}
				$o .= '</ul>';
			} else {
				$o .= '<p class="ec-muted">' . esc_html__( 'No attendance recorded.', 'educore-workspace' ) . '</p>';
			}
			$o .= '</section>';
		}
		return $o . '</div>';
	}
}
