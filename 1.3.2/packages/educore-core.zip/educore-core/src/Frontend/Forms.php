<?php
namespace EduCore\Core\Frontend;

use EduCore\Core\Announcements;
use EduCore\Core\Audit;
use EduCore\Core\I18n;
use EduCore\Core\Pages;
use EduCore\Core\Privacy;
use EduCore\Core\Profile;
use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/** Classic form handlers (admin-post.php). Every handler: nonce + capability/ownership + rate limit. */
final class Forms {

	public static function register(): void {
		add_action( 'admin_post_educore_profile', array( self::class, 'profile' ) );
		add_action( 'admin_post_nopriv_educore_register', array( self::class, 'handle_register' ) );
		add_action( 'admin_post_educore_register', array( self::class, 'handle_register' ) );
		add_action( 'admin_post_nopriv_educore_contact', array( self::class, 'contact' ) );
		add_action( 'admin_post_educore_contact', array( self::class, 'contact' ) );
		add_action( 'admin_post_nopriv_educore_guardian', array( self::class, 'guardian' ) );
		add_action( 'admin_post_educore_guardian', array( self::class, 'guardian' ) );
		add_action( 'admin_post_educore_announce', array( self::class, 'announce' ) );
	}

	private static function back( string $msg, string $fallback = '' ): void {
		$ref = wp_validate_redirect( (string) wp_get_raw_referer(), $fallback ?: home_url( '/' ) );
		wp_safe_redirect( add_query_arg( 'ec_msg', $msg, remove_query_arg( 'ec_msg', $ref ) ) );
		exit;
	}

	private static function verify( string $action ): void {
		if ( ! isset( $_POST['_ecnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_ecnonce'] ) ), $action ) ) {
			wp_die( esc_html__( 'Your session expired. Please reload the page and try again.', 'educore-core' ), 403 );
		}
	}

	public static function profile(): void {
		self::verify( 'educore_profile' );
		$uid = get_current_user_id();
		if ( ! $uid ) {
			wp_die( '', 403 );
		}
		$in = array(
			'display_name'  => isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '',
			'mobile'        => isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : '',
			'academic_year' => isset( $_POST['academic_year'] ) ? sanitize_text_field( wp_unslash( $_POST['academic_year'] ) ) : '',
			'programme_id'  => isset( $_POST['programme_id'] ) ? absint( $_POST['programme_id'] ) : 0,
			'lang'          => isset( $_POST['lang'] ) ? sanitize_key( wp_unslash( $_POST['lang'] ) ) : 'en',
		);
		$in  = apply_filters( 'educore/profile/form_input', $in, $_POST ); // phpcs:ignore WordPress.Security.NonceVerification -- verified above.
		$res = Profile::update( $uid, $in );
		if ( is_wp_error( $res ) ) {
			self::back( 'educore_invalid_mobile' === $res->get_error_code() ? 'bad_mobile' : 'error' );
		}
		if ( \EduCore\Core\Gamification::leaderboards_on() && '18plus' === get_user_meta( $uid, 'educore_age_band', true ) ) {
			update_user_meta( $uid, 'educore_leaderboard_optin', empty( $_POST['leaderboard_optin'] ) ? 'no' : 'yes' );
		} else {
			delete_user_meta( $uid, 'educore_leaderboard_optin' );
		}
		if ( isset( $_POST['weekly_goal'] ) ) {
			update_user_meta( $uid, 'educore_weekly_goal', max( 1, min( 50, absint( $_POST['weekly_goal'] ) ) ) );
		}
		if ( ! empty( $_FILES['avatar']['name'] ) ) {
			if ( ! self::save_avatar( $uid ) ) {
				self::back( 'bad_upload' );
			}
		}
		I18n::reset();
		$ref = wp_validate_redirect( (string) wp_get_raw_referer(), Pages::url( 'profile' ) );
		wp_safe_redirect( add_query_arg( array( 'ec_msg' => 'saved', 'lang' => $in['lang'] ), remove_query_arg( array( 'ec_msg', 'lang' ), $ref ) ) );
		exit;
	}

	/** Secure image upload: whitelist MIME by content, 1 MB max, stored as a private-to-user attachment. */
	private static function save_avatar( int $uid ): bool {
		// phpcs:disable WordPress.Security.NonceVerification -- verified by caller.
		$file = $_FILES['avatar'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! is_array( $file ) || ! empty( $file['error'] ) || (int) $file['size'] > MB_IN_BYTES ) {
			return false;
		}
		$check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) );
		if ( empty( $check['type'] ) || ! @getimagesize( $file['tmp_name'] ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return false;
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		$file['name'] = 'avatar-' . $uid . '-' . wp_generate_password( 8, false ) . '.' . $check['ext'];
		$_FILES['avatar'] = $file;
		$id = media_handle_upload( 'avatar', 0, array(), array( 'test_form' => false, 'mimes' => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) ) );
		// phpcs:enable
		if ( is_wp_error( $id ) ) {
			return false;
		}
		$old = (int) get_user_meta( $uid, 'educore_avatar_id', true );
		if ( $old ) {
			wp_delete_attachment( $old, true );
		}
		update_user_meta( $uid, 'educore_avatar_id', (int) $id );
		return true;
	}

	public static function handle_register(): void {
		self::verify( 'educore_register' );
		// phpcs:disable WordPress.Security.NonceVerification -- verified above.
		if ( ! empty( $_POST['website'] ) ) { // Honeypot.
			self::back( 'error' );
		}
		if ( 'closed' === get_option( 'educore_registration', 'open' ) ) {
			self::back( 'error' );
		}
		if ( ! RateLimiter::hit( 'register' ) ) {
			self::back( 'throttled' );
		}
		$name     = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$email    = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$password = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- passwords are not sanitised.
		$band     = isset( $_POST['age_band'] ) ? sanitize_key( wp_unslash( $_POST['age_band'] ) ) : '';
		$lang     = I18n::sanitize_lang( isset( $_POST['lang'] ) ? sanitize_key( wp_unslash( $_POST['lang'] ) ) : 'en' );
		$g_email  = isset( $_POST['guardian_email'] ) ? sanitize_email( wp_unslash( $_POST['guardian_email'] ) ) : '';
		$g_name   = isset( $_POST['guardian_name'] ) ? sanitize_text_field( wp_unslash( $_POST['guardian_name'] ) ) : '';
		$redirect = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';
		$consent  = ! empty( $_POST['consent'] );
		// phpcs:enable
		if ( '' === $name || ! is_email( $email ) || ! in_array( $band, Privacy::AGE_BANDS, true ) ) {
			self::back( 'error' );
		}
		if ( ! $consent ) {
			self::back( 'consent' );
		}
		if ( strlen( $password ) < 10 ) {
			self::back( 'weak_password' );
		}
		if ( email_exists( $email ) ) {
			self::back( 'exists' );
		}
		$minor = '18plus' !== $band;
		if ( $minor && ( ! is_email( $g_email ) || strtolower( $g_email ) === strtolower( $email ) ) ) {
			self::back( 'guardian_email' );
		}
		$login = sanitize_user( strstr( $email, '@', true ), true ) ?: 'learner';
		$base  = $login;
		$i     = 1;
		while ( username_exists( $login ) ) {
			$login = $base . ( ++$i );
		}
		$uid = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_email'   => $email,
				'user_pass'    => $password,
				'display_name' => $name,
				'first_name'   => $name,
				'role'         => 'ec_student',
			)
		);
		if ( is_wp_error( $uid ) ) {
			self::back( 'error' );
		}
		update_user_meta( $uid, 'educore_age_band', $band );
		update_user_meta( $uid, 'educore_lang', $lang );
		Privacy::record_consent( $uid, 'terms_privacy', 'self' );
		if ( $minor ) {
			update_user_meta( $uid, 'educore_consent_state', 'pending_guardian' );
			Privacy::request_guardian_consent( $uid, $g_email, $g_name );
		} else {
			Privacy::record_consent( $uid, 'learning', 'self' );
			update_user_meta( $uid, 'educore_consent_state', 'granted' );
		}
		Audit::log( 'user.registered', 'user', $uid, array( 'minor' => $minor ) );
		do_action( 'educore/events/registered', $uid );
		wp_set_current_user( $uid );
		wp_set_auth_cookie( $uid, false, is_ssl() );
		$dest = $redirect ? wp_validate_redirect( $redirect, Pages::url( 'dashboard' ) ) : Pages::url( 'dashboard' );
		wp_safe_redirect( add_query_arg( array( 'ec_msg' => $minor ? 'pending' : 'registered', 'lang' => $lang ), $dest ) );
		exit;
	}

	public static function contact(): void {
		self::verify( 'educore_contact' );
		// phpcs:disable WordPress.Security.NonceVerification -- verified above.
		if ( ! empty( $_POST['website'] ) || empty( $_POST['consent'] ) ) {
			self::back( 'error' );
		}
		if ( ! RateLimiter::hit( 'contact' ) ) {
			self::back( 'throttled' );
		}
		$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
		// phpcs:enable
		if ( '' === $name || ! is_email( $email ) || '' === $subject || '' === $message ) {
			self::back( 'error' );
		}
		$to   = sanitize_email( (string) get_option( 'educore_support_email', 'support@educore.gorgy.org' ) );
		$sent = wp_mail( $to, '[EduCore support] ' . $subject, $message . "\n\n— " . $name . ' <' . $email . '>', array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );
		Audit::log( 'support.contact', 'support', 0, array( 'accepted_by_mailer' => (bool) $sent ) );
		self::back( $sent ? 'sent' : 'error' );
	}

	public static function guardian(): void {
		self::verify( 'educore_guardian' );
		// phpcs:disable WordPress.Security.NonceVerification -- verified above.
		$token    = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$approve  = isset( $_POST['decision'] ) && 'approve' === $_POST['decision'];
		$attested = ! empty( $_POST['confirm_guardian'] );
		// phpcs:enable
		if ( ! RateLimiter::hit( 'guardian' ) ) {
			self::back( 'throttled' );
		}
		if ( $approve && ! $attested ) {
			self::back( 'error' );
		}
		$res = Privacy::confirm_guardian( $token, $approve );
		wp_safe_redirect( add_query_arg( 'ec_msg', is_wp_error( $res ) ? 'error' : ( $approve ? 'consent_ok' : 'consent_no' ), Pages::url( 'guardian' ) ) );
		exit;
	}

	public static function announce(): void {
		$cid = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- verified next line.
		self::verify( 'educore_announce_' . $cid );
		if ( ! current_user_can( 'ec_edit_course', $cid ) ) {
			wp_die( '', 403 );
		}
		// phpcs:disable WordPress.Security.NonceVerification -- verified above.
		$title = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
		$body  = isset( $_POST['body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['body'] ) ) : '';
		// phpcs:enable
		$ok = Announcements::publish( $cid, $title, $body );
		self::back( $ok ? 'saved' : 'error' );
	}
}
