=== EduCore Assessments ===
Contributors: gorgyorg
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: lms, quiz, exam, question bank, assessment

Question banks, quizzes and timed examinations for EduCore.

== Description ==

Part of the EduCore LMS (https://educore.gorgy.org), an initiative of GORGY.ORG.

* Question bank with version history (questions used in an attempt are never changed — edits create a new version), review workflow, duplicate detection, CSV/JSON import and export, coverage against per-lesson targets.
* 10 question types: single and multiple choice, true/false, short answer, essay, fill in the blanks, matching, ordering, code reading, image-based.
* Practice, quiz and exam modes; question pools, randomised questions and options, server-side timer with auto-save, session recovery and automatic submission on expiry.
* Attempt policies enforced on the server (practice: MCQ 3 tries, true/false 1, essay 1 submission; quizzes/exams: configurable attempt count); availability window (opens/closes).
* Automatic grading, essay grading with rubrics and written feedback, manual or automatic result release. Answer keys and explanations never reach the browser before review is allowed.
* "Chapter 1 Examination" template (15 MCQ, 15 true/false, 5 essays, 45 minutes).
* Optional lesson completion rule: "pass the linked quiz".

Requires EduCore Core. AI-assisted marking is not included; any future AI marking must stay instructor-confirmed.

== Installation ==

1. Install and activate EduCore Core first.
2. Upload and activate this plugin.
3. Run EduCore → Setup wizard → "Run database & roles setup".

== Changelog ==

= 1.0.1 =
* Availability window (opens/closes) is entered and shown in the site timezone (e.g. Africa/Cairo, DST-aware) and still stored and enforced in UTC; REST returns ISO-8601 UTC ("…Z") so read-modify-write round trips are lossless.
* Students see "Opens …" / "Closes …" with local time and timezone on the assessment card, course list, dashboard and reminder e-mails.
* Optional partial credit for multiple-answer (correct − wrong ÷ correct, never below zero) and ordering (share in correct position) questions; default stays all-or-nothing. Available in the editor, REST and CSV/JSON import/export (column "scoring").
* Assessment attempts and practice answers count as learning activity in core's daily activity log.

= 1.0.0 =
* First release.
