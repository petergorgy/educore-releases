<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Server-side entitlement gate. Every learner-facing read goes through here. */
final class Access {

	public static function can_access_course( int $user_id, int $course_id ): bool {
		if ( ! Content::is_course( $course_id ) ) {
			return false;
		}
		if ( $user_id && ( user_can( $user_id, 'ec_edit_course', $course_id ) || user_can( $user_id, 'ec_view_course_records', $course_id ) ) ) {
			return true;
		}
		$allowed = $user_id > 0 && 'publish' === get_post_status( $course_id ) && Enrollment::is_enrolled( $user_id, $course_id );
		/**
		 * Final entitlement decision (commerce attaches here). Must stay server-side.
		 */
		return (bool) apply_filters( 'educore/access/can_access_course', $allowed, $user_id, $course_id );
	}

	public static function can_view_lesson( int $user_id, int $lesson_id ): bool {
		if ( get_post_type( $lesson_id ) !== Content::LESSON ) {
			return false;
		}
		$course_id = Content::course_of( $lesson_id );
		if ( $user_id && user_can( $user_id, 'ec_edit_course', $course_id ) ) {
			return true;
		}
		if ( 'publish' !== get_post_status( $lesson_id ) ) {
			return false;
		}
		return self::can_access_course( $user_id, $course_id );
	}

	/** Self-enrolment allowed? (open courses only; paid handled by commerce). */
	public static function can_self_enroll( int $user_id, int $course_id ): bool {
		if ( ! $user_id || ! Content::is_course( $course_id ) || 'publish' !== get_post_status( $course_id ) ) {
			return false;
		}
		if ( ! Privacy::has_required_consent( $user_id ) ) {
			return false;
		}
		$mode = get_post_meta( $course_id, '_ec_enroll_mode', true ) ?: 'open';
		return (bool) apply_filters( 'educore/access/can_self_enroll', 'open' === $mode, $user_id, $course_id, $mode );
	}

	/** Mark all personalised responses as private/non-cacheable. */
	public static function no_cache_headers(): void {
		if ( ! headers_sent() ) {
			nocache_headers();
			header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' );
			header( 'X-LiteSpeed-Cache-Control: no-cache' );
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // Honoured by most WP page-cache plugins.
		}
	}
}
