<?php
namespace EduCore\Workspace;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Enrollment;
use EduCore\Core\RateLimiter;
use EduCore\Core\Schema;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/**
 * Student Success: learner support plans (interventions) with an owner, a due date and a closed loop
 * Detect → Plan → Act → Resolve → Close. Course-scoped: only the course's teaching team (or academic managers)
 * can see or act on a plan, the learner must be enrolled, and the owner must be on the team. Every change is
 * written to the plan's timeline and to the audit log. Overdue plans surface in the owner's notifications.
 */
final class Success {
	public const STATUSES = array( 'open', 'in_progress', 'resolved', 'closed' );
	public const REASONS  = array( 'inactive', 'low_progress', 'low_scores', 'attendance', 'wellbeing', 'other' );
	public const FLOW     = array(
		'open'        => array( 'in_progress', 'resolved', 'closed' ),
		'in_progress' => array( 'resolved', 'closed' ),
		'resolved'    => array( 'closed', 'in_progress' ),
		'closed'      => array( 'in_progress' ),
	);

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	private static function t( string $n ): string {
		return Schema::table( $n );
	}

	public static function reason_labels(): array {
		return array(
			'inactive'     => __( 'Inactive', 'educore-workspace' ),
			'low_progress' => __( 'Low progress', 'educore-workspace' ),
			'low_scores'   => __( 'Low scores', 'educore-workspace' ),
			'attendance'   => __( 'Attendance', 'educore-workspace' ),
			'wellbeing'    => __( 'Wellbeing', 'educore-workspace' ),
			'other'        => __( 'Other', 'educore-workspace' ),
		);
	}

	public static function status_labels(): array {
		return array(
			'open'        => __( 'Open', 'educore-workspace' ),
			'in_progress' => __( 'In progress', 'educore-workspace' ),
			'resolved'    => __( 'Resolved', 'educore-workspace' ),
			'closed'      => __( 'Closed', 'educore-workspace' ),
		);
	}

	/* ---------- authority ---------- */

	public static function can_course( int $uid, int $course_id ): bool {
		return $uid > 0 && Content::is_course( $course_id ) && ( user_can( $uid, 'ec_manage_all_courses' ) || ( null !== Staff::role_of( $uid, $course_id ) && user_can( $uid, 'ec_view_course_records', $course_id ) ) );
	}

	/** @return int[] */
	public static function courses( int $uid ): array {
		if ( ! $uid ) {
			return array();
		}
		if ( user_can( $uid, 'ec_manage_all_courses' ) ) {
			return array_map( 'intval', get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'private' ), 'numberposts' => -1, 'fields' => 'ids' ) ) );
		}
		return array_values( array_filter( array_map( 'intval', Staff::courses_of( $uid ) ), static fn( $c ) => self::can_course( $uid, $c ) ) );
	}

	public static function can_any( int $uid ): bool {
		return $uid > 0 && ( user_can( $uid, 'ec_manage_all_courses' ) || (bool) self::courses( $uid ) );
	}

	private static function deny(): \WP_Error {
		return new \WP_Error( 'ec_success_forbidden', __( 'You cannot manage support plans for this course.', 'educore-workspace' ), array( 'status' => 403 ) );
	}

	public static function get( int $uid, int $id ): ?array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'ws_interventions' ) . ' WHERE id=%d', $id ), ARRAY_A );
		return ( $r && self::can_course( $uid, (int) $r['course_id'] ) ) ? $r : null;
	}

	public static function learner_name( int $viewer, int $learner ): string {
		$u = get_userdata( $learner );
		/* translators: %d: user id */
		return $u && user_can( $viewer, 'ec_view_student', $learner ) ? $u->display_name : sprintf( __( 'Learner #%d', 'educore-workspace' ), $learner );
	}

	public static function is_overdue( array $r ): bool {
		return in_array( $r['status'], array( 'open', 'in_progress' ), true ) && ! empty( $r['due_on'] ) && $r['due_on'] < wp_date( 'Y-m-d' );
	}

	/* ---------- actions ---------- */

	/** @return int|\WP_Error */
	public static function create( int $uid, array $in ) {
		global $wpdb;
		$course  = absint( $in['course_id'] ?? 0 );
		$learner = absint( $in['learner_id'] ?? 0 );
		$owner   = absint( $in['owner_id'] ?? 0 ) ?: $uid;
		if ( ! self::can_course( $uid, $course ) ) {
			return self::deny();
		}
		$e = Enrollment::get( $learner, $course );
		if ( ! $e || ! in_array( $e['status'], array( 'active', 'completed' ), true ) ) {
			return new \WP_Error( 'ec_success_learner', __( 'The learner is not enrolled in this course.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'learner_id' => 'invalid' ) ) );
		}
		if ( ! self::can_course( $owner, $course ) ) {
			return new \WP_Error( 'ec_success_owner', __( 'The owner must be on the course’s teaching team.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'owner_id' => 'invalid' ) ) );
		}
		$reason  = in_array( $in['reason'] ?? '', self::REASONS, true ) ? (string) $in['reason'] : 'other';
		$summary = mb_substr( sanitize_text_field( (string) ( $in['summary'] ?? '' ) ), 0, 255 );
		if ( mb_strlen( $summary ) < 5 ) {
			return new \WP_Error( 'ec_success_summary', __( 'Describe the concern in a few words (at least 5 characters).', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'summary' => 'required' ) ) );
		}
		$due = self::date( (string) ( $in['due_on'] ?? '' ) );
		if ( '' === $due || $due < wp_date( 'Y-m-d' ) ) {
			return new \WP_Error( 'ec_success_due', __( 'Set a follow-up date from today onwards.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'due_on' => 'invalid' ) ) );
		}
		$dupe = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t( 'ws_interventions' ) . " WHERE course_id=%d AND learner_id=%d AND status IN ('open','in_progress')", $course, $learner ) );
		if ( $dupe ) {
			return new \WP_Error( 'ec_success_dupe', __( 'This learner already has an open support plan in this course. Update it instead.', 'educore-workspace' ), array( 'status' => 409, 'id' => $dupe ) );
		}
		$now = Schema::now();
		$wpdb->insert( self::t( 'ws_interventions' ), array( 'course_id' => $course, 'learner_id' => $learner, 'owner_id' => $owner, 'reason' => $reason, 'summary' => $summary, 'plan' => sanitize_textarea_field( (string) ( $in['plan'] ?? '' ) ), 'status' => 'open', 'due_on' => $due, 'created_by' => $uid, 'created_at' => $now, 'updated_at' => $now ) );
		$id = (int) $wpdb->insert_id;
		self::log( $id, $uid, 'created', $summary );
		Audit::log( 'success.plan_created', 'intervention', $id, array( 'course_id' => $course, 'learner_id' => $learner, 'owner_id' => $owner, 'reason' => $reason ) );
		return $id;
	}

	/** Status change, reassignment, new due date or plan text. @return true|\WP_Error */
	public static function update( int $uid, int $id, array $in ) {
		global $wpdb;
		$r = self::get( $uid, $id );
		if ( ! $r ) {
			return self::deny();
		}
		$row = array();
		$log = array();
		if ( isset( $in['status'] ) && $in['status'] !== $r['status'] ) {
			$to = (string) $in['status'];
			if ( ! in_array( $to, self::FLOW[ $r['status'] ] ?? array(), true ) ) {
				return new \WP_Error( 'ec_success_flow', __( 'This status change is not allowed.', 'educore-workspace' ), array( 'status' => 409 ) );
			}
			$outcome = trim( sanitize_textarea_field( (string) ( $in['outcome'] ?? '' ) ) );
			if ( in_array( $to, array( 'resolved', 'closed' ), true ) && mb_strlen( $outcome ?: (string) $r['outcome'] ) < 10 ) {
				return new \WP_Error( 'ec_success_outcome', __( 'Record the outcome (at least 10 characters) before resolving or closing the plan.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'outcome' => 'required' ) ) );
			}
			if ( 'closed' === $r['status'] && ! user_can( $uid, 'ec_manage_all_courses' ) && (int) $r['owner_id'] !== $uid ) {
				return new \WP_Error( 'ec_success_reopen', __( 'Only the owner or an academic manager can reopen a closed plan.', 'educore-workspace' ), array( 'status' => 403 ) );
			}
			$row['status']    = $to;
			$row['closed_at'] = 'closed' === $to ? Schema::now() : null;
			if ( '' !== $outcome ) {
				$row['outcome'] = $outcome;
			}
			$log[] = array( 'status', $r['status'] . ' → ' . $to . ( '' !== $outcome ? ': ' . $outcome : '' ) );
		}
		if ( isset( $in['owner_id'] ) && (int) $in['owner_id'] && (int) $in['owner_id'] !== (int) $r['owner_id'] ) {
			$owner = (int) $in['owner_id'];
			if ( ! self::can_course( $owner, (int) $r['course_id'] ) ) {
				return new \WP_Error( 'ec_success_owner', __( 'The owner must be on the course’s teaching team.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'owner_id' => 'invalid' ) ) );
			}
			$row['owner_id'] = $owner;
			$log[]           = array( 'owner', ( get_userdata( $owner )->display_name ?? '#' . $owner ) );
		}
		if ( isset( $in['due_on'] ) && '' !== (string) $in['due_on'] && self::date( (string) $in['due_on'] ) !== (string) $r['due_on'] ) {
			$due = self::date( (string) $in['due_on'] );
			if ( '' === $due || $due < wp_date( 'Y-m-d' ) ) {
				return new \WP_Error( 'ec_success_due', __( 'Set a follow-up date from today onwards.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'due_on' => 'invalid' ) ) );
			}
			$row['due_on'] = $due;
			$log[]         = array( 'due', $due );
		}
		if ( isset( $in['plan'] ) && sanitize_textarea_field( (string) $in['plan'] ) !== (string) $r['plan'] ) {
			$row['plan'] = sanitize_textarea_field( (string) $in['plan'] );
			$log[]       = array( 'plan', mb_strimwidth( $row['plan'], 0, 200, '…' ) );
		}
		if ( ! $row ) {
			return true;
		}
		$row['updated_at'] = Schema::now();
		$wpdb->update( self::t( 'ws_interventions' ), $row, array( 'id' => $id ) );
		foreach ( $log as list( $kind, $body ) ) {
			self::log( $id, $uid, $kind, $body );
		}
		Audit::log( 'success.plan_updated', 'intervention', $id, array_diff_key( $row, array( 'updated_at' => 1, 'plan' => 1, 'outcome' => 1 ) ) );
		return true;
	}

	/** @return true|\WP_Error */
	public static function note( int $uid, int $id, string $body ) {
		global $wpdb;
		if ( ! self::get( $uid, $id ) ) {
			return self::deny();
		}
		$body = trim( sanitize_textarea_field( $body ) );
		if ( mb_strlen( $body ) < 3 ) {
			return new \WP_Error( 'ec_success_note', __( 'Write the note first.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'body' => 'required' ) ) );
		}
		self::log( $id, $uid, 'note', mb_substr( $body, 0, 4000 ) );
		$wpdb->update( self::t( 'ws_interventions' ), array( 'updated_at' => Schema::now() ), array( 'id' => $id ) );
		return true;
	}

	private static function log( int $id, int $uid, string $kind, string $body ): void {
		global $wpdb;
		$wpdb->insert( self::t( 'ws_intervention_notes' ), array( 'intervention_id' => $id, 'author_id' => $uid, 'kind' => $kind, 'body' => $body, 'created_at' => Schema::now() ) );
	}

	private static function date( string $v ): string {
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) && strtotime( $v ) ? $v : '';
	}

	/* ---------- queries ---------- */

	public static function search( int $uid, array $f ): array {
		global $wpdb;
		$courses = self::courses( $uid );
		if ( ! empty( $f['course_id'] ) ) {
			$courses = in_array( (int) $f['course_id'], $courses, true ) ? array( (int) $f['course_id'] ) : array();
		}
		if ( ! $courses ) {
			return array();
		}
		$where = array( 'course_id IN (' . implode( ',', array_map( 'intval', $courses ) ) . ')' );
		$args  = array();
		if ( in_array( $f['status'] ?? '', self::STATUSES, true ) ) {
			$where[] = 'status=%s';
			$args[]  = $f['status'];
		} elseif ( 'active' === ( $f['status'] ?? 'active' ) ) {
			$where[] = "status IN ('open','in_progress')";
		}
		if ( ! empty( $f['mine'] ) ) {
			$where[] = 'owner_id=%d';
			$args[]  = $uid;
		}
		if ( ! empty( $f['learner_id'] ) ) {
			$where[] = 'learner_id=%d';
			$args[]  = (int) $f['learner_id'];
		}
		$sql = 'SELECT * FROM ' . self::t( 'ws_interventions' ) . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY (due_on IS NULL), due_on ASC, id DESC LIMIT 300';
		return $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL -- integer list + placeholders.
	}

	/** KPIs over the viewer's scope. */
	public static function kpis( int $uid ): array {
		global $wpdb;
		$courses = self::courses( $uid );
		$out     = array( 'active' => 0, 'overdue' => 0, 'mine' => 0, 'resolved_30' => 0, 'median_days' => null );
		if ( ! $courses ) {
			return $out;
		}
		$in   = implode( ',', array_map( 'intval', $courses ) );
		$rows = $wpdb->get_results( 'SELECT status, owner_id, due_on, created_at, closed_at, updated_at FROM ' . self::t( 'ws_interventions' ) . " WHERE course_id IN ({$in})", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL -- integer list.
		$days = array();
		$cut  = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
		foreach ( $rows as $r ) {
			if ( in_array( $r['status'], array( 'open', 'in_progress' ), true ) ) {
				++$out['active'];
				$out['overdue'] += self::is_overdue( $r ) ? 1 : 0;
				$out['mine']    += (int) $r['owner_id'] === $uid ? 1 : 0;
			} elseif ( $r['updated_at'] >= $cut ) {
				++$out['resolved_30'];
				$days[] = ( strtotime( (string) ( $r['closed_at'] ?: $r['updated_at'] ) ) - strtotime( (string) $r['created_at'] ) ) / DAY_IN_SECONDS;
			}
		}
		if ( $days ) {
			sort( $days );
			$out['median_days'] = round( $days[ (int) floor( ( count( $days ) - 1 ) / 2 ) ], 1 );
		}
		return $out;
	}

	public static function timeline( int $id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'ws_intervention_notes' ) . ' WHERE intervention_id=%d ORDER BY id DESC', $id ), ARRAY_A ) ?: array();
	}

	/** Plans assigned to the user: [active, overdue]. */
	public static function assigned( int $uid ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT status, due_on FROM ' . self::t( 'ws_interventions' ) . " WHERE owner_id=%d AND status IN ('open','in_progress')", $uid ), ARRAY_A ) ?: array();
		return array( count( $rows ), count( array_filter( $rows, array( self::class, 'is_overdue' ) ) ) );
	}

	/* ---------- REST ---------- */

	public static function routes(): void {
		$perm = static fn() => self::can_any( get_current_user_id() );
		$id   = array( 'id' => array( 'type' => 'integer', 'required' => true, 'minimum' => 1 ) );
		register_rest_route( 'educore/v1', '/success/plans', array( 'methods' => 'POST', 'callback' => array( self::class, 'rest_create' ), 'permission_callback' => $perm ) );
		register_rest_route( 'educore/v1', '/success/plans/(?P<id>\d+)', array( 'methods' => 'POST', 'callback' => array( self::class, 'rest_update' ), 'permission_callback' => $perm, 'args' => $id ) );
		register_rest_route( 'educore/v1', '/success/plans/(?P<id>\d+)/notes', array( 'methods' => 'POST', 'callback' => array( self::class, 'rest_note' ), 'permission_callback' => $perm, 'args' => $id + array( 'body' => array( 'type' => 'string', 'required' => true ) ) ) );
	}

	private static function guard() {
		return RateLimiter::hit( 'rest_write' ) ? null : new \WP_Error( 'ec_ws_rate', __( 'Too many changes in a short time. Please wait a moment.', 'educore-workspace' ), array( 'status' => 429 ) );
	}

	public static function rest_create( \WP_REST_Request $q ) {
		$r = self::guard() ?? self::create( get_current_user_id(), $q->get_params() );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new \WP_REST_Response( array( 'ok' => true, 'id' => $r, 'url' => add_query_arg( array( 'v' => 'success', 'plan' => $r ), Pages::url( (string) ( $q['ws'] ?? 'studio' ) === 'manage' ? 'manage' : 'studio' ) ) ), 201 );
	}

	public static function rest_update( \WP_REST_Request $q ) {
		$r = self::guard() ?? self::update( get_current_user_id(), (int) $q['id'], array_intersect_key( $q->get_params(), array_flip( array( 'status', 'owner_id', 'due_on', 'plan', 'outcome' ) ) ) );
		return is_wp_error( $r ) ? $r : new \WP_REST_Response( array( 'ok' => true ) );
	}

	public static function rest_note( \WP_REST_Request $q ) {
		$r = self::guard() ?? self::note( get_current_user_id(), (int) $q['id'], (string) $q['body'] );
		return is_wp_error( $r ) ? $r : new \WP_REST_Response( array( 'ok' => true ) );
	}

	/* ---------- view ---------- */

	private static function q( string $k ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view parameters.
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
	}

	private static function chip( string $s, bool $overdue = false ): string {
		$c = array( 'open' => 'pending', 'in_progress' => 'pending', 'resolved' => 'publish', 'closed' => 'draft' )[ $s ] ?? 'draft';
		return '<span class="ec-chip ec-chip--' . $c . '">' . esc_html( self::status_labels()[ $s ] ?? $s ) . '</span>' . ( $overdue ? ' <span class="ec-chip ec-chip--warn">' . esc_html__( 'Overdue', 'educore-workspace' ) . '</span>' : '' );
	}

	public static function render( int $uid, string $ws ): string {
		$base = Pages::url( $ws );
		Shell::title( __( 'Student success', 'educore-workspace' ) );
		$home = 'manage' === $ws ? array( __( 'Management', 'educore-workspace' ), $base ) : array( __( 'Course Studio', 'educore-workspace' ), $base );
		if ( ! self::can_any( $uid ) ) {
			Shell::crumbs( array( $home, array( __( 'Student success', 'educore-workspace' ) ) ) );
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'You do not have access to this section.', 'educore-workspace' ) . '</div>';
		}
		if ( (int) self::q( 'plan' ) ) {
			return self::detail( $uid, $ws, (int) self::q( 'plan' ), $home );
		}
		if ( 'new' === self::q( 'do' ) ) {
			return self::form( $uid, $ws, $home );
		}
		Shell::crumbs( array( $home, array( __( 'Student success', 'educore-workspace' ) ) ) );
		$k  = self::kpis( $uid );
		$st = static fn( $v, $l ) => '<li class="ec-ws-stat"><span class="ec-ws-stat__v">' . esc_html( (string) $v ) . '</span><span class="ec-ws-stat__l">' . esc_html( $l ) . '</span></li>';
		/* translators: %s: number of days */
		$med = null === $k['median_days'] ? '—' : sprintf( __( '%s days', 'educore-workspace' ), number_format_i18n( (float) $k['median_days'], 1 ) );
		$o   = '<p class="ec-ws-actions"><a class="ec-btn ec-btn--primary" href="' . esc_url( add_query_arg( array( 'v' => 'success', 'do' => 'new' ), $base ) ) . '">' . esc_html__( 'New support plan', 'educore-workspace' ) . '</a></p>';
		$o  .= '<ul class="ec-ws-stats">' . $st( number_format_i18n( $k['active'] ), __( 'Active plans', 'educore-workspace' ) ) . $st( number_format_i18n( $k['overdue'] ), __( 'Overdue', 'educore-workspace' ) ) . $st( number_format_i18n( $k['mine'] ), __( 'Assigned to me', 'educore-workspace' ) ) . $st( number_format_i18n( $k['resolved_30'] ), __( 'Resolved or closed (30 days)', 'educore-workspace' ) ) . $st( $med, __( 'Median time to resolve', 'educore-workspace' ) ) . '</ul>';
		$f     = array( 'status' => self::q( 'status' ) ?: 'active', 'mine' => self::q( 'mine' ), 'course_id' => (int) self::q( 'course' ) );
		$copts = array( '' => __( 'All my courses', 'educore-workspace' ) );
		foreach ( self::courses( $uid ) as $c ) {
			$copts[ (string) $c ] = get_the_title( $c ) ?: '#' . $c;
		}
		$F  = '\EduCore\Workspace\Studio\View';
		$o .= '<form class="ec-ws-filters" method="get" action="' . esc_url( $base ) . '"><input type="hidden" name="v" value="success">' . $F::field_select( 'status', __( 'Status', 'educore-workspace' ), array( 'active' => __( 'Open and in progress', 'educore-workspace' ) ) + self::status_labels() + array( 'all' => __( 'All', 'educore-workspace' ) ), $f['status'] ) . $F::field_select( 'course', __( 'Course', 'educore-workspace' ), $copts, (string) ( $f['course_id'] ?: '' ) ) . '<label class="ec-ws-check"><input type="checkbox" name="mine" value="1"' . checked( (bool) $f['mine'], true, false ) . '> ' . esc_html__( 'Only mine', 'educore-workspace' ) . '</label><button class="ec-btn" type="submit">' . esc_html__( 'Filter', 'educore-workspace' ) . '</button></form>';
		$rows = self::search( $uid, $f );
		if ( ! $rows ) {
			return $o . '<div class="ec-ws-empty"><p>' . esc_html__( 'No support plans match.', 'educore-workspace' ) . '</p></div>';
		}
		$o .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><caption class="screen-reader-text">' . esc_html__( 'Support plans', 'educore-workspace' ) . '</caption><thead><tr><th scope="col">' . esc_html__( 'Learner', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Course', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Concern', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Owner', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Follow-up', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$o .= '<tr><td><a href="' . esc_url( add_query_arg( array( 'v' => 'success', 'plan' => (int) $r['id'] ), $base ) ) . '">' . esc_html( self::learner_name( $uid, (int) $r['learner_id'] ) ) . '</a></td><td>' . esc_html( get_the_title( (int) $r['course_id'] ) ) . '</td><td>' . esc_html( self::reason_labels()[ $r['reason'] ] ?? $r['reason'] ) . ' — ' . esc_html( $r['summary'] ) . '</td><td>' . esc_html( get_userdata( (int) $r['owner_id'] )->display_name ?? '—' ) . '</td><td>' . esc_html( $r['due_on'] ? wp_date( get_option( 'date_format' ), strtotime( $r['due_on'] . ' 12:00' ) ) : '—' ) . '</td><td>' . self::chip( $r['status'], self::is_overdue( $r ) ) . '</td></tr>';
		}
		return $o . '</tbody></table></div>';
	}

	/** Team members (possible owners) for a course. */
	private static function team( int $course ): array {
		$o = array();
		foreach ( Staff::of_course( $course ) as $s ) {
			$u = get_userdata( (int) $s['user_id'] );
			if ( $u ) {
				$o[ (string) $u->ID ] = $u->display_name;
			}
		}
		return $o;
	}

	private static function form( int $uid, string $ws, array $home ): string {
		$base = Pages::url( $ws );
		Shell::crumbs( array( $home, array( __( 'Student success', 'educore-workspace' ), add_query_arg( 'v', 'success', $base ) ), array( __( 'New support plan', 'educore-workspace' ) ) ) );
		Shell::title( __( 'New support plan', 'educore-workspace' ) );
		$course = (int) self::q( 'course' );
		$F      = '\EduCore\Workspace\Studio\View';
		$copts  = array( '' => __( 'Choose a course', 'educore-workspace' ) );
		foreach ( self::courses( $uid ) as $c ) {
			$copts[ (string) $c ] = get_the_title( $c ) ?: '#' . $c;
		}
		if ( ! $course || ! self::can_course( $uid, $course ) ) {
			return '<form class="ec-card ec-ws-form ec-studio-narrow" method="get" action="' . esc_url( $base ) . '"><input type="hidden" name="v" value="success"><input type="hidden" name="do" value="new">' . $F::field_select( 'course', __( 'Course', 'educore-workspace' ), $copts, '' ) . '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Continue', 'educore-workspace' ) . '</button></div></form>';
		}
		$learners = array( '' => __( 'Choose a learner', 'educore-workspace' ) );
		foreach ( \EduCore\Core\Enrollment::for_course( $course ) as $e ) {
			if ( in_array( $e['status'], array( 'active', 'completed' ), true ) ) {
				$learners[ (string) $e['user_id'] ] = self::learner_name( $uid, (int) $e['user_id'] );
			}
		}
		$team = self::team( $course );
		if ( ! isset( $team[ (string) $uid ] ) && user_can( $uid, 'ec_manage_all_courses' ) ) {
			$team = array( (string) $uid => wp_get_current_user()->display_name ) + $team;
		}
		$o  = '<form class="ec-card ec-ws-form ec-studio-narrow" data-ec-api="success/plans" data-ec-method="POST" novalidate><input type="hidden" name="course_id" value="' . $course . '"><input type="hidden" name="ws" value="' . esc_attr( $ws ) . '">';
		/* translators: %s: course title */
		$o .= '<p class="ec-muted">' . esc_html( sprintf( __( 'Course: %s', 'educore-workspace' ), get_the_title( $course ) ) ) . '</p>';
		$o .= $F::field_select( 'learner_id', __( 'Learner', 'educore-workspace' ), $learners, self::q( 'learner' ) );
		$o .= '<div class="ec-ws-grid">' . $F::field_select( 'reason', __( 'Reason', 'educore-workspace' ), self::reason_labels(), in_array( self::q( 'reason' ), self::REASONS, true ) ? self::q( 'reason' ) : 'other' ) . $F::field_select( 'owner_id', __( 'Owner', 'educore-workspace' ), $team, (string) $uid ) . $F::field_text( 'due_on', __( 'Follow-up by', 'educore-workspace' ), wp_date( 'Y-m-d', time() + 7 * DAY_IN_SECONDS ), true, 'date' ) . '</div>';
		$o .= $F::field_text( 'summary', __( 'Concern (short)', 'educore-workspace' ), '', true );
		$o .= $F::field_area( 'plan', __( 'Action plan', 'educore-workspace' ), '', 4, __( 'What will be done, by whom, and how success will be checked.', 'educore-workspace' ) );
		return $o . '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Create support plan', 'educore-workspace' ) . '</button></div></form>';
	}

	private static function detail( int $uid, string $ws, int $id, array $home ): string {
		$base = Pages::url( $ws );
		$r    = self::get( $uid, $id );
		Shell::crumbs( array( $home, array( __( 'Student success', 'educore-workspace' ), add_query_arg( 'v', 'success', $base ) ), array( $r ? self::learner_name( $uid, (int) $r['learner_id'] ) : '—' ) ) );
		if ( ! $r ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'Support plan not found.', 'educore-workspace' ) . '</div>';
		}
		Shell::title( self::learner_name( $uid, (int) $r['learner_id'] ), self::chip( $r['status'], self::is_overdue( $r ) ) );
		$F   = '\EduCore\Workspace\Studio\View';
		$api = 'success/plans/' . $id;
		$o   = '<div class="ec-ws-cols"><div><section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Plan', 'educore-workspace' ) . '</h2><dl class="ec-ws-kv">';
		$o  .= '<dt>' . esc_html__( 'Course', 'educore-workspace' ) . '</dt><dd>' . esc_html( get_the_title( (int) $r['course_id'] ) ) . '</dd>';
		$o  .= '<dt>' . esc_html__( 'Reason', 'educore-workspace' ) . '</dt><dd>' . esc_html( self::reason_labels()[ $r['reason'] ] ?? $r['reason'] ) . '</dd>';
		$o  .= '<dt>' . esc_html__( 'Concern', 'educore-workspace' ) . '</dt><dd>' . esc_html( $r['summary'] ) . '</dd>';
		$o  .= '<dt>' . esc_html__( 'Opened', 'educore-workspace' ) . '</dt><dd>' . esc_html( get_date_from_gmt( $r['created_at'], get_option( 'date_format' ) ) . ' · ' . ( get_userdata( (int) $r['created_by'] )->display_name ?? '' ) ) . '</dd>';
		if ( $r['outcome'] ) {
			$o .= '<dt>' . esc_html__( 'Outcome', 'educore-workspace' ) . '</dt><dd>' . esc_html( $r['outcome'] ) . '</dd>';
		}
		$o .= '</dl>';
		$next = self::FLOW[ $r['status'] ] ?? array();
		$sts  = array( $r['status'] => self::status_labels()[ $r['status'] ] ) + array_intersect_key( self::status_labels(), array_flip( $next ) );
		$team = self::team( (int) $r['course_id'] );
		if ( ! isset( $team[ (string) $r['owner_id'] ] ) ) {
			$team = array( (string) $r['owner_id'] => get_userdata( (int) $r['owner_id'] )->display_name ?? '#' . $r['owner_id'] ) + $team;
		}
		$o .= '<form class="ec-ws-form" data-ec-api="' . esc_attr( $api ) . '" data-ec-method="POST" novalidate><div class="ec-ws-grid">' . $F::field_select( 'status', __( 'Status', 'educore-workspace' ), $sts, $r['status'] ) . $F::field_select( 'owner_id', __( 'Owner', 'educore-workspace' ), $team, (string) $r['owner_id'] ) . $F::field_text( 'due_on', __( 'Follow-up by', 'educore-workspace' ), (string) $r['due_on'], false, 'date' ) . '</div>';
		$o .= $F::field_area( 'plan', __( 'Action plan', 'educore-workspace' ), (string) $r['plan'], 4 );
		$o .= $F::field_area( 'outcome', __( 'Outcome (required to resolve or close)', 'educore-workspace' ), (string) $r['outcome'], 3 );
		$o .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Save', 'educore-workspace' ) . '</button></div></form></section></div><div>';
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Timeline', 'educore-workspace' ) . '</h2><form class="ec-ws-form" data-ec-api="' . esc_attr( $api . '/notes' ) . '" data-ec-method="POST" novalidate>' . $F::field_area( 'body', __( 'Add a note (contact made, agreed actions…)', 'educore-workspace' ), '', 2 ) . '<div class="ec-ws-actions"><button class="ec-btn" type="submit">' . esc_html__( 'Add note', 'educore-workspace' ) . '</button></div></form><ol class="ec-ws-timeline">';
		$kinds = array( 'created' => __( 'Plan opened', 'educore-workspace' ), 'status' => __( 'Status', 'educore-workspace' ), 'owner' => __( 'Owner changed', 'educore-workspace' ), 'due' => __( 'Follow-up date', 'educore-workspace' ), 'plan' => __( 'Plan updated', 'educore-workspace' ), 'note' => __( 'Note', 'educore-workspace' ) );
		foreach ( self::timeline( $id ) as $n ) {
			$o .= '<li><p class="ec-muted">' . esc_html( get_date_from_gmt( $n['created_at'], get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) . ' · ' . ( get_userdata( (int) $n['author_id'] )->display_name ?? '' ) . ' · ' . ( $kinds[ $n['kind'] ] ?? $n['kind'] ) ) . '</p><p>' . esc_html( $n['body'] ) . '</p></li>';
		}
		return $o . '</ol></section></div></div>';
	}
}
