<?php
namespace EduCore\Analytics;

use EduCore\Core\Frontend\Views;

defined( 'ABSPATH' ) || exit;

/** Student-facing "My progress" analytics block: educore/my-analytics (always the current user's own data). */
final class Block {

	public static function register(): void {
		add_filter(
			'educore/blocks',
			static function ( array $blocks ) {
				$blocks['my-analytics'] = array( 'title' => __( 'EduCore: My progress analytics', 'educore-analytics' ), 'render' => array( self::class, 'render' ) );
				return $blocks;
			}
		);
		add_action( 'wp_enqueue_scripts', static fn() => wp_register_style( 'educore-analytics-front', EDUCORE_ANALYTICS_URL . 'assets/css/analytics.css', array(), EDUCORE_ANALYTICS_VERSION ) );
	}

	/** Own-data view model. $user_id is always the signed-in user at call sites. */
	public static function data( int $user_id ): array {
		$f = new Filters( array( 'from' => '1970-01-01' ) );
		$f->course_ids = array_map( 'intval', wp_list_pluck( \EduCore\Core\Enrollment::for_user( $user_id ), 'course_id' ) );
		return array(
			'courses'     => Metrics::lesson_progress( $user_id, $f ),
			'mean'        => Metrics::assessment_mean( $user_id, $f ),
			'improvement' => Metrics::score_improvement( $user_id, $f ),
			'topics'      => Metrics::topic_strengths( $user_id, $f ),
			'consistency' => Metrics::consistency( $user_id, $f ),
			'pending'     => Metrics::pending_activities( $user_id, $f ),
		);
	}

	public static function render(): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return '<p class="ec-muted">' . esc_html__( 'Log in to see your progress.', 'educore-analytics' ) . '</p>';
		}
		wp_enqueue_style( 'educore-analytics-front' );
		$d   = self::data( $uid );
		$num = static fn( $v, $suffix = '%' ) => null === $v ? '—' : number_format_i18n( (float) $v, 1 ) . $suffix;
		$out = '<div class="ec-my-analytics"><div class="ec-stats">';
		$out .= '<div class="ec-stat ec-card"><span class="ec-stat__value">' . esc_html( $num( $d['mean'] ) ) . '</span><span class="ec-stat__label">' . esc_html__( 'Average assessment score', 'educore-analytics' ) . '</span></div>';
		$imp  = null === $d['improvement'] ? '—' : ( $d['improvement'] > 0 ? '+' : '' ) . number_format_i18n( $d['improvement'], 1 );
		$out .= '<div class="ec-stat ec-card"><span class="ec-stat__value">' . esc_html( $imp ) . '</span><span class="ec-stat__label">' . esc_html__( 'Score improvement (points)', 'educore-analytics' ) . '</span></div>';
		/* translators: %d: active days */
		$out .= '<div class="ec-stat ec-card"><span class="ec-stat__value">' . esc_html( sprintf( __( '%d / 28', 'educore-analytics' ), $d['consistency']['active_days'] ) ) . '</span><span class="ec-stat__label">' . esc_html__( 'Active days (last 4 weeks)', 'educore-analytics' ) . '</span></div>';
		$pending = $d['pending']['lessons'] + (int) $d['pending']['assessments'];
		$out    .= '<div class="ec-stat ec-card"><span class="ec-stat__value">' . esc_html( number_format_i18n( $pending ) ) . '</span><span class="ec-stat__label">' . esc_html__( 'Pending activities', 'educore-analytics' ) . '</span></div></div>';
		if ( $d['courses'] ) {
			$out .= '<section class="ec-section"><h2>' . esc_html__( 'Course progress', 'educore-analytics' ) . '</h2><ul class="ec-bars">';
			foreach ( $d['courses'] as $c ) {
				$out .= '<li><span class="ec-bars__label">' . esc_html( $c['title'] ) . '</span>' . Views::progress_bar( (int) round( (float) $c['completion'] ), $c['title'] ) . '<span class="ec-bars__value">' . esc_html( $num( $c['completion'] ) ) . '</span></li>';
			}
			$out .= '</ul></section>';
		}
		if ( $d['topics'] ) {
			$labels = array( 'strength' => __( 'Strength', 'educore-analytics' ), 'developing' => __( 'Developing', 'educore-analytics' ), 'weakness' => __( 'Needs practice', 'educore-analytics' ) );
			$out   .= '<section class="ec-section"><h2>' . esc_html__( 'Strengths and areas to practise', 'educore-analytics' ) . '</h2><div class="ec-table-wrap"><table class="ec-table"><thead><tr><th scope="col">' . esc_html__( 'Topic (lesson)', 'educore-analytics' ) . '</th><th scope="col">' . esc_html__( 'Average', 'educore-analytics' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-analytics' ) . '</th></tr></thead><tbody>';
			foreach ( $d['topics'] as $t ) {
				$out .= '<tr><td>' . esc_html( $t['lesson'] ) . '</td><td>' . esc_html( $num( $t['mean'] ) ) . '</td><td><span class="ec-band ec-band--' . esc_attr( $t['band'] ) . '">' . esc_html( $labels[ $t['band'] ] ) . '</span></td></tr>';
			}
			$out .= '</tbody></table></div></section>';
		}
		return $out . '</div>';
	}
}
