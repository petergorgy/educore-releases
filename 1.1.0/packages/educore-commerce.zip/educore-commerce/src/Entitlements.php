<?php
namespace EduCore\Commerce;

use EduCore\Core\Audit;
use EduCore\Core\Enrollment;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Entitlement service: the server-side record of paid access.
 * status: active | expired | cancelled | refunded
 */
final class Entitlements {
	public const HOOK = 'educore_commerce_hourly';

	public static function register(): void {
		add_action( self::HOOK, array( self::class, 'cron' ) );
		add_action(
			'init',
			static function () {
				if ( ! wp_next_scheduled( self::HOOK ) ) {
					wp_schedule_event( time() + 300, 'hourly', self::HOOK );
				}
			}
		);
	}

	private static function t(): string {
		return Schema::table( 'entitlements' );
	}

	/**
	 * Grant (idempotent per order/product/course/user). Re-syncs the core enrollment.
	 */
	public static function grant( int $user_id, int $course_id, int $order_id, int $product_id, ?string $ends_at, string $source = 'order' ): int {
		global $wpdb;
		$t   = self::t();
		$now = Schema::now();
		$wpdb->query( $wpdb->prepare( "INSERT INTO {$t} (user_id,course_id,order_id,product_id,starts_at,ends_at,status,source,updated_at) VALUES (%d,%d,%d,%d,%s,%s,'active',%s,%s) ON DUPLICATE KEY UPDATE status=IF(status IN ('refunded','cancelled'),'active',status), ends_at=VALUES(ends_at), updated_at=VALUES(updated_at)", $user_id, $course_id, $order_id, $product_id, $now, $ends_at, $source, $now ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( null === $ends_at ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET ends_at=NULL WHERE order_id=%d AND product_id=%d AND course_id=%d AND user_id=%d", $order_id, $product_id, $course_id, $user_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE order_id=%d AND product_id=%d AND course_id=%d AND user_id=%d", $order_id, $product_id, $course_id, $user_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		self::sync_enrollment( $user_id, $course_id );
		Audit::log( 'commerce.entitlement_granted', 'course', $course_id, array( 'user_id' => $user_id, 'order_id' => $order_id, 'ends_at' => $ends_at ) );
		return $id;
	}

	/** Revoke all entitlements of an order (refunded|cancelled). */
	public static function revoke_order( int $order_id, string $status ): int {
		global $wpdb;
		$status = in_array( $status, array( 'refunded', 'cancelled' ), true ) ? $status : 'cancelled';
		$t      = self::t();
		$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT user_id, course_id FROM {$t} WHERE order_id=%d AND status='active'", $order_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status=%s, updated_at=%s WHERE order_id=%d AND status='active'", $status, Schema::now(), $order_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $rows as $r ) {
			self::sync_enrollment( (int) $r['user_id'], (int) $r['course_id'], 'suspended' );
			Audit::log( 'commerce.entitlement_' . $status, 'course', (int) $r['course_id'], array( 'user_id' => (int) $r['user_id'], 'order_id' => $order_id ) );
		}
		return count( $rows );
	}

	public static function has_active( int $user_id, int $course_id, ?int $now = null ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t() . " WHERE user_id=%d AND course_id=%d AND status='active' AND (ends_at IS NULL OR ends_at > %s) LIMIT 1", $user_id, $course_id, gmdate( 'Y-m-d H:i:s', $now ?? time() ) ) );
	}

	/** Latest end of active entitlements: null = lifetime, false = none. @return string|null|false */
	public static function coverage_end( int $user_id, int $course_id ) {
		global $wpdb;
		$rows = $wpdb->get_col( $wpdb->prepare( 'SELECT COALESCE(ends_at, \'9999-12-31 00:00:00\') FROM ' . self::t() . " WHERE user_id=%d AND course_id=%d AND status='active' AND (ends_at IS NULL OR ends_at > %s)", $user_id, $course_id, Schema::now() ) );
		if ( ! $rows ) {
			return false;
		}
		$max = max( $rows );
		return '9999-12-31 00:00:00' === $max ? null : $max;
	}

	/**
	 * Make the core enrollment reflect entitlements: covered → active with expiry = coverage end;
	 * not covered → $when_uncovered (only for enrollments created by commerce).
	 */
	public static function sync_enrollment( int $user_id, int $course_id, string $when_uncovered = 'suspended' ): void {
		$end = self::coverage_end( $user_id, $course_id );
		if ( false !== $end ) {
			Enrollment::enroll( $user_id, $course_id, 'commerce', $end );
			return;
		}
		$e = Enrollment::get( $user_id, $course_id );
		if ( $e && 'commerce' === $e['source'] && in_array( $e['status'], array( 'active' ), true ) ) {
			Enrollment::set_status( $user_id, $course_id, $when_uncovered );
		}
	}

	/** Cron: expire past-due entitlements, warn 7 days before the end. */
	public static function cron( ?int $now = null ): array {
		global $wpdb;
		$now = $now ?? time();
		$t   = self::t();
		$ts  = gmdate( 'Y-m-d H:i:s', $now );
		$due = $wpdb->get_results( $wpdb->prepare( "SELECT id, user_id, course_id FROM {$t} WHERE status='active' AND ends_at IS NOT NULL AND ends_at <= %s LIMIT 500", $ts ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $due as $r ) {
			$wpdb->update( $t, array( 'status' => 'expired', 'updated_at' => Schema::now() ), array( 'id' => (int) $r['id'] ) );
		}
		foreach ( $due as $r ) {
			if ( ! self::has_active( (int) $r['user_id'], (int) $r['course_id'], $now ) ) {
				$e = Enrollment::get( (int) $r['user_id'], (int) $r['course_id'] );
				if ( $e && 'commerce' === $e['source'] && 'active' === $e['status'] ) {
					Enrollment::set_status( (int) $r['user_id'], (int) $r['course_id'], 'expired' );
				}
			}
			Audit::log( 'commerce.entitlement_expired', 'course', (int) $r['course_id'], array( 'user_id' => (int) $r['user_id'] ) );
		}
		$soon = $wpdb->get_results( $wpdb->prepare( "SELECT id, user_id, course_id, ends_at FROM {$t} WHERE status='active' AND notified_at IS NULL AND ends_at IS NOT NULL AND ends_at > %s AND ends_at <= %s LIMIT 500", $ts, gmdate( 'Y-m-d H:i:s', $now + 7 * DAY_IN_SECONDS ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $soon as $r ) {
			$wpdb->update( $t, array( 'notified_at' => Schema::now() ), array( 'id' => (int) $r['id'] ) );
			do_action( 'educore/events/entitlement_expiring', (int) $r['user_id'], (int) $r['course_id'], $r['ends_at'] );
		}
		return array( 'expired' => count( $due ), 'warned' => count( $soon ) );
	}

	/** @return array<int,array<string,mixed>> */
	public static function for_user( int $user_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t() . ' WHERE user_id=%d ORDER BY id DESC', $user_id ), ARRAY_A ) ?: array();
	}

	public static function used_trial( int $user_id, int $course_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t() . " WHERE user_id=%d AND course_id=%d AND source='trial' LIMIT 1", $user_id, $course_id ) );
	}
}
