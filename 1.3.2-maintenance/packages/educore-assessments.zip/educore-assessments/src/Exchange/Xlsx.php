<?php
namespace EduCore\Assessments\Exchange;

defined( 'ABSPATH' ) || exit;

/** Minimal, safe XLSX reader/writer (first worksheet, inline/shared strings, numbers, booleans). */
final class Xlsx {
	private const MAX_XML = 50 * 1048576;

	public static function write( array $rows, string $sheet ): string {
		$tmp = wp_tempnam( 'educore-xlsx' );
		$zip = new \ZipArchive();
		$zip->open( $tmp, \ZipArchive::CREATE | \ZipArchive::OVERWRITE );
		$zip->addFromString( '[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>' );
		$zip->addFromString( '_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' );
		$zip->addFromString( 'xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="' . self::x( $sheet ) . '" sheetId="1" r:id="rId1"/></sheets></workbook>' );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' );
		$zip->addFromString( 'xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="3"><xf fontId="0"/><xf fontId="1" applyFont="1"/><xf fontId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf></cellXfs></styleSheet>' );
		$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetData>';
		foreach ( array_values( $rows ) as $ri => $row ) {
			$xml .= '<row r="' . ( $ri + 1 ) . '">';
			foreach ( array_values( $row ) as $ci => $val ) {
				$ref = self::col( $ci ) . ( $ri + 1 );
				$s   = 0 === $ri ? ' s="1"' : ' s="2"';
				if ( null === $val || '' === $val ) {
					continue;
				}
				// Always strings (inline): Excel never evaluates inline strings, so no formula injection, and values round-trip exactly.
				$xml .= '<c r="' . $ref . '" t="inlineStr"' . $s . '><is><t xml:space="preserve">' . self::x( (string) $val ) . '</t></is></c>';
			}
			$xml .= '</row>';
		}
		$zip->addFromString( 'xl/worksheets/sheet1.xml', $xml . '</sheetData></worksheet>' );
		$zip->close();
		$bin = (string) file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		wp_delete_file( $tmp );
		return $bin;
	}

	/** @return array<int,array<int,string>>|\WP_Error row number => cells by column index */
	public static function read( string $path ) {
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $path, \ZipArchive::RDONLY ) ) {
			return new \WP_Error( 'ec_x_xlsx', __( 'This is not a valid .xlsx file.', 'educore-assessments' ) );
		}
		$get = static function ( string $name ) use ( $zip ) {
			$st = $zip->statName( $name );
			if ( ! $st || $st['size'] > self::MAX_XML ) {
				return null;
			}
			return $zip->getFromName( $name );
		};
		$sheet = 'xl/worksheets/sheet1.xml';
		$wb    = $get( 'xl/workbook.xml' );
		$rels  = $get( 'xl/_rels/workbook.xml.rels' );
		if ( $wb && $rels ) {
			$w = self::xml( $wb );
			$r = self::xml( $rels );
			if ( $w && $r && isset( $w->sheets->sheet[0] ) ) {
				$rid = (string) $w->sheets->sheet[0]->attributes( 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' )->id;
				foreach ( $r->Relationship as $rel ) {
					if ( (string) $rel['Id'] === $rid ) {
						$target = ltrim( (string) $rel['Target'], '/' );
						$sheet  = 0 === strpos( $target, 'xl/' ) ? $target : 'xl/' . $target;
					}
				}
			}
		}
		$shared = array();
		$ss     = $get( 'xl/sharedStrings.xml' );
		if ( $ss && ( $sx = self::xml( $ss ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
			foreach ( $sx->si as $si ) {
				$shared[] = self::si_text( $si );
			}
		}
		$data = $get( $sheet );
		$zip->close();
		$sx = $data ? self::xml( $data ) : null;
		if ( ! $sx ) {
			return new \WP_Error( 'ec_x_xlsx', __( 'The first worksheet could not be read.', 'educore-assessments' ) );
		}
		$out = array();
		foreach ( $sx->sheetData->row as $row ) {
			$rn    = (int) $row['r'];
			$cells = array();
			$auto  = 0;
			foreach ( $row->c as $c ) {
				$ci = isset( $c['r'] ) ? self::col_index( (string) $c['r'] ) : $auto;
				$auto = $ci + 1;
				$t  = (string) $c['t'];
				if ( 'inlineStr' === $t ) {
					$v = self::si_text( $c->is );
				} elseif ( 's' === $t ) {
					$v = $shared[ (int) $c->v ] ?? '';
				} elseif ( 'b' === $t ) {
					$v = '1' === (string) $c->v ? 'true' : 'false';
				} else {
					$v = (string) $c->v;
					if ( is_numeric( $v ) && false !== strpos( $v, 'E' ) ) {
						$v = rtrim( rtrim( sprintf( '%.15F', (float) $v ), '0' ), '.' );
					}
				}
				$cells[ $ci ] = $v;
			}
			if ( $cells ) {
				$out[ $rn ?: count( $out ) + 1 ] = $cells;
			}
		}
		return $out;
	}

	private static function si_text( \SimpleXMLElement $si ): string {
		if ( isset( $si->t ) ) {
			return (string) $si->t;
		}
		$s = '';
		foreach ( $si->r as $run ) {
			$s .= (string) $run->t;
		}
		return $s;
	}

	/** Parse XML with DTDs refused (no entity expansion, no network). */
	public static function xml( string $s ): ?\SimpleXMLElement {
		if ( preg_match( '/<!DOCTYPE/i', $s ) ) {
			return null;
		}
		$prev = libxml_use_internal_errors( true );
		$x    = simplexml_load_string( $s, \SimpleXMLElement::class, LIBXML_NONET | LIBXML_NOCDATA | LIBXML_COMPACT );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		return $x ?: null;
	}

	public static function col( int $i ): string {
		$s = '';
		for ( $n = $i + 1; $n > 0; $n = intdiv( $n - 1, 26 ) ) {
			$s = chr( 65 + ( $n - 1 ) % 26 ) . $s;
		}
		return $s;
	}

	private static function col_index( string $ref ): int {
		$letters = preg_replace( '/[^A-Z]/', '', strtoupper( $ref ) );
		$n       = 0;
		foreach ( str_split( (string) $letters ) as $ch ) {
			$n = $n * 26 + ( ord( $ch ) - 64 );
		}
		return max( 0, $n - 1 );
	}

	private static function x( string $s ): string {
		$s = (string) preg_replace( '/[^\x{9}\x{A}\x{D}\x{20}-\x{D7FF}\x{E000}-\x{FFFD}]/u', '', $s );
		return htmlspecialchars( $s, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
	}
}
