<?php
namespace EduCore\Workspace;

use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/** `educore/v1/manage/*` — capability gate in permission_callback, object-level checks inside People. */
final class Rest {
	public const NS = 'educore/v1';

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	public static function routes(): void {
		$people = static fn() => People::can_manage( get_current_user_id() );
		$id     = array( 'id' => array( 'type' => 'integer', 'required' => true, 'minimum' => 1 ) );
		$r      = static function ( string $route, string $methods, callable $cb, callable $perm, array $args = array() ) {
			register_rest_route( self::NS, $route, array( 'methods' => $methods, 'callback' => $cb, 'permission_callback' => $perm, 'args' => $args ) );
		};
		$r( '/manage/people', 'GET', array( self::class, 'search' ), $people );
		$r( '/manage/people', 'POST', array( self::class, 'create' ), $people, array( 'email' => array( 'type' => 'string', 'required' => true ), 'roles' => array( 'type' => 'array', 'required' => true, 'items' => array( 'type' => 'string' ) ) ) );
		$r( '/manage/people/(?P<id>\d+)', 'GET', array( self::class, 'get' ), $people, $id );
		$r( '/manage/people/(?P<id>\d+)', 'POST', array( self::class, 'update' ), $people, $id );
		$r( '/manage/people/(?P<id>\d+)/status', 'POST', array( self::class, 'status' ), $people, $id + array( 'suspended' => array( 'type' => 'boolean', 'required' => true ) ) );
		$r( '/manage/people/(?P<id>\d+)/invite', 'POST', array( self::class, 'invite' ), $people, $id );
		$r( '/manage/people/(?P<id>\d+)/reset', 'POST', array( self::class, 'reset' ), $people, $id );
		$r( '/manage/people/(?P<id>\d+)/guardians', 'POST', array( self::class, 'link' ), $people, $id + array( 'guardian_id' => array( 'type' => 'integer', 'required' => true ) ) );
		$r( '/manage/guardian-links/(?P<id>\d+)', 'DELETE', array( self::class, 'unlink' ), $people, $id );
		$r( '/manage/courses/(?P<id>\d+)/team', 'POST', array( self::class, 'team' ), static fn() => current_user_can( 'ec_manage_all_courses' ), $id + array( 'user_id' => array( 'type' => 'integer', 'required' => true ), 'role' => array( 'type' => 'string', 'enum' => array( 'lead', 'instructor', 'grader', 'remove' ), 'required' => true ) ) );
		$r( '/manage/courses/(?P<id>\d+)/enroll', 'POST', array( self::class, 'enroll' ), static fn( \WP_REST_Request $q ) => current_user_can( 'ec_manage_course_enrollments', (int) $q['id'] ), $id + array( 'user_id' => array( 'type' => 'integer', 'required' => true ) ) );
	}

	private static function write_guard() {
		return RateLimiter::hit( 'rest_write' ) ? null : new \WP_Error( 'ec_ws_rate', __( 'Too many changes in a short time. Please wait a moment.', 'educore-workspace' ), array( 'status' => 429 ) );
	}

	private static function out( $result, array $extra = array(), int $status = 200 ) {
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new \WP_REST_Response( array( 'ok' => true ) + $extra, $status );
	}

	public static function search( \WP_REST_Request $q ) {
		return new \WP_REST_Response( People::search( get_current_user_id(), array( 'q' => (string) $q['q'], 'role' => (string) $q['role'], 'status' => (string) $q['status'], 'page' => (int) $q['page'] ) ) );
	}

	public static function get( \WP_REST_Request $q ) {
		$p = People::profile( get_current_user_id(), (int) $q['id'] );
		return $p ? new \WP_REST_Response( $p ) : new \WP_Error( 'ec_ws_not_found', __( 'Not found.', 'educore-workspace' ), array( 'status' => 404 ) );
	}

	public static function create( \WP_REST_Request $q ) {
		$g = self::write_guard();
		if ( $g ) {
			return $g;
		}
		$id = People::create( get_current_user_id(), $q->get_params() );
		return self::out( $id, is_wp_error( $id ) ? array() : array( 'id' => $id, 'url' => Pages::url( 'manage', array( 'v' => 'person', 'id' => $id, 'ec_msg' => 'created' ) ) ), 201 );
	}

	public static function update( \WP_REST_Request $q ) {
		$g = self::write_guard();
		if ( $g ) {
			return $g;
		}
		$in = array_intersect_key( $q->get_params(), array_flip( array( 'first', 'last', 'name', 'email', 'roles' ) ) );
		return self::out( People::update( get_current_user_id(), (int) $q['id'], $in ) );
	}

	public static function status( \WP_REST_Request $q ) {
		return self::write_guard() ?? self::out( People::set_suspended( get_current_user_id(), (int) $q['id'], (bool) $q['suspended'] ) );
	}

	public static function invite( \WP_REST_Request $q ) {
		return self::write_guard() ?? self::out( People::invite( get_current_user_id(), (int) $q['id'] ) );
	}

	public static function reset( \WP_REST_Request $q ) {
		return self::write_guard() ?? self::out( People::send_reset( get_current_user_id(), (int) $q['id'] ) );
	}

	public static function link( \WP_REST_Request $q ) {
		$r = self::write_guard() ?? People::link_guardian( get_current_user_id(), (int) $q['id'], (int) $q['guardian_id'] );
		return is_wp_error( $r ) ? $r : self::out( true, array( 'link_id' => $r ) );
	}

	public static function unlink( \WP_REST_Request $q ) {
		return self::write_guard() ?? self::out( People::unlink_guardian( get_current_user_id(), (int) $q['id'] ) );
	}

	public static function team( \WP_REST_Request $q ) {
		return self::write_guard() ?? self::out( People::assign_course( get_current_user_id(), (int) $q['id'], (int) $q['user_id'], (string) $q['role'] ) );
	}

	public static function enroll( \WP_REST_Request $q ) {
		return self::write_guard() ?? self::out( People::enroll( get_current_user_id(), (int) $q['id'], (int) $q['user_id'] ) );
	}
}
