<?php
namespace EduCore\Workspace;

use EduCore\Core\Access;
use EduCore\Core\Enrollment;

defined( 'ABSPATH' ) || exit;

/**
 * "Coming up" on My learning: one time-ordered list of what the learner has to do or watch in the next 14 days,
 * plus anything overdue in the last 7 days. Sources (each only when its package is active):
 * assessments that close (not yet attempted), class assignments due (not yet submitted), course access ending,
 * shared support-plan check-ins. Read-only; every source applies its own access rules.
 */
final class Agenda {
	public const AHEAD = 14;
	public const BEHIND = 7;

	public static function register(): void {
		add_filter( 'educore/dashboard/student_sections', array( self::class, 'section' ), 5, 3 );
	}

	/** @return array<int,array{ts:int,kind:string,title:string,meta:string,url:string,overdue:bool}> sorted by time */
	public static function items( int $uid, ?int $now = null ): array {
		$now   = $now ?? time();
		$from  = $now - self::BEHIND * DAY_IN_SECONDS;
		$to    = $now + self::AHEAD * DAY_IN_SECONDS;
		$items = array();
		$add   = static function ( int $ts, string $kind, string $title, string $meta, string $url, bool $can_be_overdue ) use ( &$items, $now, $from, $to ) {
			if ( $ts < ( $can_be_overdue ? $from : $now ) || $ts > $to ) {
				return;
			}
			$items[] = array( 'ts' => $ts, 'kind' => $kind, 'title' => $title, 'meta' => $meta, 'url' => $url, 'overdue' => $ts < $now );
		};
		$courses = array();
		foreach ( Enrollment::for_user( $uid ) as $e ) {
			$cid = (int) $e['course_id'];
			if ( 'active' !== $e['status'] ) {
				continue;
			}
			if ( Access::can_access_course( $uid, $cid ) ) {
				$courses[] = $cid;
			}
			if ( ! empty( $e['expires_at'] ) ) {
				$add( (int) strtotime( $e['expires_at'] . ' UTC' ), 'access', get_the_title( $cid ), __( 'Course access ends', 'educore-workspace' ), (string) get_permalink( $cid ), false );
			}
		}
		if ( class_exists( '\EduCore\Assessments\Assessments' ) && class_exists( '\EduCore\Assessments\Frontend' ) ) {
			foreach ( $courses as $cid ) {
				foreach ( \EduCore\Assessments\Assessments::for_course( $cid ) as $a ) {
					$closes = (string) ( $a['settings']['closes_at'] ?? '' );
					if ( 'practice' === $a['kind'] || '' === $closes ) {
						continue;
					}
					$s = \EduCore\Assessments\Frontend::summary_data( $a, $uid );
					if ( $s['used'] || ! $s['can_start'] ) {
						continue;
					}
					$add( (int) strtotime( $closes . ' UTC' ), 'assessment', (string) $a['title'], get_the_title( $cid ) . ' · ' . __( 'Assessment closes', 'educore-workspace' ), add_query_arg( 'ec_assessment', (int) $a['id'], (string) get_permalink( $cid ) ) . '#ec-assessment-' . (int) $a['id'], false );
				}
			}
		}
		if ( class_exists( '\EduCore\TeachingHub\Assignments' ) ) {
			foreach ( \EduCore\TeachingHub\Assignments::for_student( $uid ) as $a ) {
				if ( empty( $a['due_at'] ) || ! in_array( (string) $a['sub_status'], array( '', 'draft' ), true ) ) {
					continue;
				}
				$add( (int) strtotime( $a['due_at'] . ' UTC' ), 'assignment', (string) $a['title'], __( 'Assignment due', 'educore-workspace' ), add_query_arg( array( 'th_view' => 'assignment', 'id' => (int) $a['id'] ), \EduCore\Core\Pages::url( 'dashboard' ) ), true );
			}
		}
		foreach ( Family::plans( $uid ) as $p ) {
			if ( $p['due_on'] && in_array( $p['status'], array( 'open', 'in_progress' ), true ) ) {
				$add( (int) strtotime( $p['due_on'] . ' 12:00:00 ' . wp_timezone_string() ), 'support', get_the_title( (int) $p['course_id'] ), __( 'Support plan check-in', 'educore-workspace' ), '#ec-fam-h', false );
			}
		}
		usort( $items, static fn( $a, $b ) => $a['ts'] <=> $b['ts'] ?: strcmp( $a['title'], $b['title'] ) );
		return $items;
	}

	private static function when( int $ts, int $now ): string {
		$day   = wp_date( 'Y-m-d', $ts );
		$today = wp_date( 'Y-m-d', $now );
		$time  = wp_date( get_option( 'time_format' ), $ts );
		if ( $day === $today ) {
			/* translators: %s: time */
			return sprintf( __( 'Today, %s', 'educore-workspace' ), $time );
		}
		if ( wp_date( 'Y-m-d', $now + DAY_IN_SECONDS ) === $day ) {
			/* translators: %s: time */
			return sprintf( __( 'Tomorrow, %s', 'educore-workspace' ), $time );
		}
		return wp_date( 'D j M', $ts ) . ', ' . $time;
	}

	public static function section( $html, $d, $uid ) {
		if ( empty( $d['courses'] ) ) {
			return $html;
		}
		$now   = time();
		$items = self::items( (int) $uid, $now );
		$o     = '<section class="ec-card ec-ws-section ec-agenda" aria-labelledby="ec-agenda-h"><h2 id="ec-agenda-h">' . esc_html__( 'Coming up', 'educore-workspace' ) . '</h2>';
		if ( ! $items ) {
			return $html . $o . '<p class="ec-muted">' . esc_html__( 'Nothing due in the next two weeks.', 'educore-workspace' ) . '</p></section>';
		}
		$o .= '<ul class="ec-ws-list ec-agenda__list">';
		foreach ( $items as $i ) {
			$title = $i['url'] ? '<a href="' . esc_url( $i['url'] ) . '">' . esc_html( $i['title'] ) . '</a>' : esc_html( $i['title'] );
			$o    .= '<li class="ec-agenda__item' . ( $i['overdue'] ? ' is-overdue' : '' ) . '"><span>' . $title . '<br><span class="ec-muted">' . esc_html( $i['meta'] ) . '</span></span><span>' . ( $i['overdue'] ? '<span class="ec-chip ec-chip--warn">' . esc_html__( 'Overdue', 'educore-workspace' ) . '</span> ' : '' ) . '<time datetime="' . esc_attr( gmdate( 'c', $i['ts'] ) ) . '">' . esc_html( self::when( $i['ts'], $now ) ) . '</time></span></li>';
		}
		return $html . $o . '</ul></section>';
	}
}
