<?php
/**
 * Plugin Name:       EduCore Commerce
 * Plugin URI:        https://educore.gorgy.org
 * Description:       Paid courses and time-limited access plans for EduCore through WooCommerce. Server-side entitlements; no card data is stored by EduCore.
 * Version:           1.0.1
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core, woocommerce
 * Author:            GORGY.ORG
 * Author URI:        https://gorgy.org
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-commerce
 * Domain Path:       /languages
 *
 * @package EduCore\Commerce
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_COMMERCE_VERSION', '1.0.1' );
define( 'EDUCORE_COMMERCE_DB_VERSION', 1 );
define( 'EDUCORE_COMMERCE_FILE', __FILE__ );
define( 'EDUCORE_COMMERCE_DIR', plugin_dir_path( __FILE__ ) );

// Declare compatibility with WooCommerce High-Performance Order Storage and the Cart/Checkout blocks.
// EduCore reads orders only through the WC_Order API (no direct post/postmeta order queries).
add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\\Automattic\\WooCommerce\\Utilities\\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
		}
	}
);

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Commerce', '1.0.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Commerce\\', EDUCORE_COMMERCE_DIR . 'src/' );
		\EduCore\Commerce\Plugin::boot();
	}
);

add_action(
	'admin_notices',
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) && current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'EduCore Commerce requires the EduCore Core plugin. It has not been loaded.', 'educore-commerce' ) . '</p></div>';
		}
	}
);

register_deactivation_hook( __FILE__, static fn() => wp_clear_scheduled_hook( 'educore_commerce_hourly' ) );
