<?php
namespace EduCore\Assessments;

defined( 'ABSPATH' ) || exit;

/**
 * Read-only statistics for EduCore Analytics. Metric definitions:
 *  - attempts:          submitted (non-open) attempts in scope
 *  - mean_percent:      average attempt percent over graded attempts (0–100)
 *  - pass_rate:         passed ÷ graded attempts (0–100)
 *  - pending_grading:   essay responses awaiting a grade
 *  - question p-value:  mean of (final_score ÷ points) per question over graded responses (0–1);
 *                       low values = difficult questions
 */
final class ReadModel {

	private static function range( string $col, string $from, string $to ): string {
		global $wpdb;
		$sql = '';
		if ( $from ) {
			$sql .= $wpdb->prepare( " AND {$col} >= %s", $from . ' 00:00:00' ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		if ( $to ) {
			$sql .= $wpdb->prepare( " AND {$col} <= %s", $to . ' 23:59:59' ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		return $sql;
	}

	public static function course_stats( int $course_id, string $from = '', string $to = '' ): array {
		global $wpdb;
		$at  = Schema::t( 'attempts' );
		$as  = Schema::t( 'assessments' );
		$rng = self::range( 'a.submitted_at', $from, $to );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) attempts, SUM(a.state='graded') graded, AVG(CASE WHEN a.state='graded' THEN a.percent END) mean_percent, SUM(a.passed=1) passed FROM {$at} a JOIN {$as} s ON s.id=a.assessment_id WHERE s.course_id=%d AND a.state<>'open'{$rng}", $course_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$graded = (int) ( $row['graded'] ?? 0 );
		return array(
			'attempts'        => (int) ( $row['attempts'] ?? 0 ),
			'graded'          => $graded,
			'mean_percent'    => null === $row['mean_percent'] ? null : round( (float) $row['mean_percent'], 2 ),
			'pass_rate'       => $graded ? round( (int) $row['passed'] * 100 / $graded, 2 ) : null,
			'pending_grading' => self::pending_grading( $course_id ),
		);
	}

	public static function pending_grading( int $course_id = 0 ): int {
		global $wpdb;
		$rs = Schema::t( 'responses' );
		$it = Schema::t( 'attempt_items' );
		$at = Schema::t( 'attempts' );
		$as = Schema::t( 'assessments' );
		$w  = $course_id ? $wpdb->prepare( ' AND s.course_id=%d', $course_id ) : '';
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$rs} r JOIN {$it} i ON i.id=r.attempt_item_id JOIN {$at} a ON a.id=i.attempt_id JOIN {$as} s ON s.id=a.assessment_id WHERE r.needs_grading=1 AND r.final_score IS NULL{$w}" ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Per-assessment summary. */
	public static function assessment_stats( int $course_id, string $from = '', string $to = '' ): array {
		global $wpdb;
		$at  = Schema::t( 'attempts' );
		$as  = Schema::t( 'assessments' );
		$rng = self::range( 'a.submitted_at', $from, $to );
		return $wpdb->get_results( $wpdb->prepare( "SELECT s.id, s.title, s.kind, COUNT(a.id) attempts, AVG(CASE WHEN a.state='graded' THEN a.percent END) mean_percent, SUM(a.passed=1) passed, SUM(a.state='graded') graded, MIN(a.percent) min_percent, MAX(a.percent) max_percent FROM {$as} s LEFT JOIN {$at} a ON a.assessment_id=s.id AND a.state<>'open'{$rng} WHERE s.course_id=%d GROUP BY s.id ORDER BY s.id", $course_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Per-question difficulty (p-value) — difficult questions first. */
	public static function question_stats( int $course_id, int $min_responses = 1, string $from = '', string $to = '' ): array {
		global $wpdb;
		$rs  = Schema::t( 'responses' );
		$it  = Schema::t( 'attempt_items' );
		$at  = Schema::t( 'attempts' );
		$as  = Schema::t( 'assessments' );
		$v   = Schema::t( 'question_versions' );
		$q   = Schema::t( 'questions' );
		$rng = self::range( 'a.submitted_at', $from, $to );
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT q.id question_id, q.type, q.lesson_id, LEFT(v.stem, 160) stem, COUNT(*) responses, AVG(r.final_score / NULLIF(i.points,0)) p_value, SUM(r.final_score >= i.points) correct
				 FROM {$rs} r JOIN {$it} i ON i.id=r.attempt_item_id JOIN {$at} a ON a.id=i.attempt_id JOIN {$as} s ON s.id=a.assessment_id
				 JOIN {$v} v ON v.id=i.question_version_id JOIN {$q} q ON q.id=v.question_id
				 WHERE s.course_id=%d AND r.final_score IS NOT NULL{$rng}
				 GROUP BY q.id HAVING COUNT(*) >= %d ORDER BY p_value ASC, responses DESC", // phpcs:ignore WordPress.DB.PreparedSQL
				$course_id,
				$min_responses
			),
			ARRAY_A
		) ?: array();
	}

	/** One student's graded attempts in a course (for drilldowns; caller must check ec_view_student). */
	public static function student_attempts( int $user_id, int $course_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT a.id, s.title, a.attempt_no, a.state, a.percent, a.passed, a.submitted_at FROM ' . Schema::t( 'attempts' ) . ' a JOIN ' . Schema::t( 'assessments' ) . " s ON s.id=a.assessment_id WHERE a.user_id=%d AND s.course_id=%d AND a.state<>'open' ORDER BY a.submitted_at", $user_id, $course_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Per-student mean percent in a course (at-risk detection). */
	public static function student_means( int $course_id ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT a.user_id, AVG(a.percent) mean_percent, COUNT(*) attempts FROM ' . Schema::t( 'attempts' ) . ' a JOIN ' . Schema::t( 'assessments' ) . " s ON s.id=a.assessment_id WHERE s.course_id=%d AND a.state='graded' GROUP BY a.user_id", $course_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ (int) $r['user_id'] ] = array( 'mean_percent' => round( (float) $r['mean_percent'], 2 ), 'attempts' => (int) $r['attempts'] );
		}
		return $out;
	}

	/** Topic strengths: mean p-value per lesson for one student. */
	public static function student_lesson_strengths( int $user_id, int $course_id ): array {
		global $wpdb;
		$rs = Schema::t( 'responses' );
		$it = Schema::t( 'attempt_items' );
		$at = Schema::t( 'attempts' );
		$as = Schema::t( 'assessments' );
		$v  = Schema::t( 'question_versions' );
		$q  = Schema::t( 'questions' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT q.lesson_id, AVG(r.final_score / NULLIF(i.points,0)) p_value, COUNT(*) responses FROM {$rs} r JOIN {$it} i ON i.id=r.attempt_item_id JOIN {$at} a ON a.id=i.attempt_id JOIN {$as} s ON s.id=a.assessment_id JOIN {$v} v ON v.id=i.question_version_id JOIN {$q} q ON q.id=v.question_id WHERE a.user_id=%d AND s.course_id=%d AND r.final_score IS NOT NULL GROUP BY q.lesson_id", $user_id, $course_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}
}
