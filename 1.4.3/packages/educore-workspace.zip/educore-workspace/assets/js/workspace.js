/* EduCore application shell: menus, mobile navigation, REST-backed forms with partial refresh. No dependencies. */
( function () {
	'use strict';
	var cfg = window.EduCoreWS || { i18n: {} };
	var t = cfg.i18n || {};
	var body = document.body;

	// ---------- Menus (disclosure pattern) ----------
	function closeMenus( except ) {
		document.querySelectorAll( '[data-ec-menu][aria-expanded="true"]' ).forEach( function ( b ) {
			if ( b !== except ) {
				b.setAttribute( 'aria-expanded', 'false' );
				var p = document.getElementById( b.getAttribute( 'aria-controls' ) );
				if ( p ) { p.hidden = true; }
			}
		} );
	}
	document.addEventListener( 'click', function ( e ) {
		var btn = e.target.closest( '[data-ec-menu]' );
		if ( btn ) {
			var open = btn.getAttribute( 'aria-expanded' ) === 'true';
			closeMenus( btn );
			btn.setAttribute( 'aria-expanded', open ? 'false' : 'true' );
			var panel = document.getElementById( btn.getAttribute( 'aria-controls' ) );
			if ( panel ) {
				panel.hidden = open;
				if ( ! open ) { var first = panel.querySelector( 'a, button' ); if ( first ) { first.focus(); } }
			}
			return;
		}
		if ( ! e.target.closest( '.ec-app-menu__panel' ) ) { closeMenus(); }
		if ( body.classList.contains( 'ec-app--nav-open' ) && ! e.target.closest( '#ec-app-side' ) && ! e.target.closest( '[data-ec-burger]' ) ) { toggleNav( false ); }
	} );
	document.addEventListener( 'keydown', function ( e ) {
		if ( e.key === 'Escape' ) {
			var open = document.querySelector( '[data-ec-menu][aria-expanded="true"]' );
			if ( open ) { closeMenus(); open.focus(); }
			if ( body.classList.contains( 'ec-app--nav-open' ) ) { toggleNav( false ); }
		}
	} );

	// ---------- Mobile navigation ----------
	var burger = document.querySelector( '[data-ec-burger]' );
	function toggleNav( open ) {
		body.classList.toggle( 'ec-app--nav-open', open );
		if ( burger ) { burger.setAttribute( 'aria-expanded', open ? 'true' : 'false' ); }
		if ( open ) { var a = document.querySelector( '#ec-app-side a' ); if ( a ) { a.focus(); } } else if ( burger ) { burger.focus(); }
	}
	if ( burger ) {
		burger.addEventListener( 'click', function () { toggleNav( ! body.classList.contains( 'ec-app--nav-open' ) ); } );
	}

	// ---------- Theme toggle (same storage key as the EduCore theme) ----------
	document.querySelectorAll( '[data-ec-theme-toggle]' ).forEach( function ( b ) {
		var root = document.documentElement;
		var sync = function () { b.setAttribute( 'aria-pressed', root.getAttribute( 'data-theme' ) === 'dark' ? 'true' : 'false' ); };
		sync();
		if ( b.dataset.ecBound ) { return; }
		b.dataset.ecBound = '1';
		b.addEventListener( 'click', function () {
			var next = root.getAttribute( 'data-theme' ) === 'dark' ? 'light' : 'dark';
			root.setAttribute( 'data-theme', next );
			try { localStorage.setItem( 'educore-theme', next ); } catch ( err ) { /* storage unavailable */ }
			sync();
		} );
	} );

	// ---------- Toast ----------
	var toastEl = document.querySelector( '[data-ec-toast]' );
	var toastTimer;
	function toast( msg, kind ) {
		if ( ! toastEl ) { return; }
		toastEl.textContent = msg;
		toastEl.dataset.kind = kind || 'ok';
		toastEl.hidden = false;
		clearTimeout( toastTimer );
		toastTimer = setTimeout( function () { toastEl.hidden = true; }, 5000 );
	}

	// ---------- REST calls ----------
	function api( path, method, data ) {
		return fetch( cfg.rest + path.replace( /^\//, '' ), {
			method: method || 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
			body: method === 'GET' ? undefined : JSON.stringify( data || {} )
		} ).then( function ( r ) {
			return r.json().catch( function () { return {}; } ).then( function ( j ) {
				if ( ! r.ok ) { var e = new Error( ( j && j.message ) || t.error ); e.data = j; throw e; }
				return j;
			} );
		} );
	}

	function formData( form ) {
		if ( window.tinymce && window.tinymce.triggerSave ) { window.tinymce.triggerSave(); }
		var out = {};
		new FormData( form ).forEach( function ( v, k ) {
			if ( k.slice( -2 ) === '[]' ) {
				k = k.slice( 0, -2 );
				( out[ k ] = out[ k ] || [] ).push( v );
			} else { out[ k ] = v; }
		} );
		form.querySelectorAll( 'input[type="checkbox"]' ).forEach( function ( c ) {
			if ( c.name.slice( -2 ) === '[]' ) { var k = c.name.slice( 0, -2 ); out[ k ] = out[ k ] || []; }
			else if ( ! c.checked && ! ( c.name in out ) ) { out[ c.name ] = false; }
			else if ( c.checked && c.value === '1' ) { out[ c.name ] = true; }
		} );
		return out;
	}

	var main = document.querySelector( '[data-ec-main]' );
	function refresh( url ) {
		if ( ! main ) { location.reload(); return Promise.resolve(); }
		main.setAttribute( 'aria-busy', 'true' );
		var u = new URL( url || location.href );
		u.searchParams.set( 'partial', '1' );
		return fetch( u.toString(), { credentials: 'same-origin' } ).then( function ( r ) { return r.text(); } ).then( function ( html ) {
			main.innerHTML = html;
			main.removeAttribute( 'aria-busy' );
			bind( main );
		} ).catch( function () { location.reload(); } );
	}

	function busy( el, on ) {
		var b = el.tagName === 'FORM' ? el.querySelector( '[type="submit"]' ) : el;
		if ( b ) { b.setAttribute( 'aria-busy', on ? 'true' : 'false' ); b.disabled = !! on; }
	}

	function showErrors( form, err ) {
		var msg = ( err && err.message ) || t.error;
		var box = form.querySelector( '.ec-ws-form-error' );
		if ( ! box ) { box = document.createElement( 'div' ); box.className = 'ec-notice ec-notice--error ec-ws-form-error'; box.setAttribute( 'role', 'alert' ); form.prepend( box ); }
		box.textContent = msg;
		var p = err && err.data && err.data.data && err.data.data.params;
		if ( p ) { Object.keys( p ).forEach( function ( k ) { var f = form.querySelector( '[name="' + k + '"]' ); if ( f ) { f.setAttribute( 'aria-invalid', 'true' ); } } ); }
		box.setAttribute( 'tabindex', '-1' );
		box.focus();
	}

	var dirty = false;
	window.addEventListener( 'beforeunload', function ( e ) { if ( dirty ) { e.preventDefault(); e.returnValue = t.unsaved; } } );

	function bind( root ) {
		root.querySelectorAll( 'form[data-ec-api]' ).forEach( function ( form ) {
			if ( form.dataset.ecBound ) { return; }
			form.dataset.ecBound = '1';
			if ( form.hasAttribute( 'data-ec-dirty' ) ) {
				form.addEventListener( 'input', function () { dirty = true; } );
			}
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				if ( ! form.checkValidity() ) {
					form.querySelectorAll( ':invalid' ).forEach( function ( f ) { f.setAttribute( 'aria-invalid', 'true' ); } );
					var first = form.querySelector( ':invalid' ); if ( first ) { first.focus(); }
					return;
				}
				if ( ! navigator.onLine ) { toast( t.offline, 'error' ); return; }
				var data = formData( form );
				var path = form.dataset.ecApi;
				if ( form.dataset.ecApiTpl ) {
					path = form.dataset.ecApiTpl.replace( /\{(\w+)\}/g, function ( m, k ) { return encodeURIComponent( data[ k ] || '' ); } );
				}
				busy( form, true );
				api( path, form.dataset.ecMethod || 'POST', data ).then( function ( res ) {
					dirty = false;
					toast( t.saved );
					if ( res && res.url ) { location.assign( res.url ); return; }
					var after = form.dataset.ecAfter;
					if ( after === 'stay' ) { busy( form, false ); return; }
					if ( after ) { location.assign( after ); return; }
					return refresh();
				} ).catch( function ( err ) { busy( form, false ); showErrors( form, err ); toast( err.message || t.error, 'error' ); } );
			} );
			form.addEventListener( 'input', function ( e ) { e.target.removeAttribute( 'aria-invalid' ); } );
		} );
		root.querySelectorAll( '[data-ec-call]' ).forEach( function ( b ) {
			if ( b.dataset.ecBound ) { return; }
			b.dataset.ecBound = '1';
			b.addEventListener( 'click', function () {
				if ( b.dataset.ecConfirm && ! window.confirm( b.dataset.ecConfirm ) ) { return; }
				busy( b, true );
				var payload = {};
				try { payload = b.dataset.ecBody ? JSON.parse( b.dataset.ecBody ) : {}; } catch ( err ) { payload = {}; }
				api( b.dataset.ecCall, b.dataset.ecMethod || 'POST', payload ).then( function ( res ) { toast( t.saved ); if ( res && res.url ) { location.assign( res.url ); return; } if ( b.dataset.ecGoto ) { location.assign( b.dataset.ecGoto ); return; } return refresh(); } ).catch( function ( err ) { busy( b, false ); toast( err.message || t.error, 'error' ); } );
			} );
		} );
		// Show student-only fields only when the Student role is ticked.
		root.querySelectorAll( '[data-ec-show-if]' ).forEach( function ( el ) {
			var form = el.closest( 'form' );
			var role = el.getAttribute( 'data-ec-show-if' );
			var sync = function () { var c = form.querySelector( 'input[name="roles[]"][value="' + role + '"]' ); el.hidden = ! ( c && c.checked ); };
			form.addEventListener( 'change', sync );
			sync();
		} );
	}
	bind( document );
	window.EduCoreWSApp = { api: api, toast: toast, refresh: refresh, bind: bind, setDirty: function ( v ) { dirty = !! v; }, isDirty: function () { return dirty; } };
}() );
