<?php
namespace EduCore\Identity;

defined( 'ABSPATH' ) || exit;

/**
 * Minimal, standards-based OpenID Connect client: discovery, JWKS, authorization-code exchange and ID-token checks
 * (RS256 signature, issuer, audience/azp, expiry with 2 minutes' clock skew, nonce). No third-party library.
 */
final class Oidc {
	public const SKEW = 120;

	/** @return array|\WP_Error */
	public static function discovery( string $p, bool $fresh = false ) {
		$def = Providers::def( $p );
		$url = Providers::expand( (string) $def['discovery'], $p );
		$key = 'educore_id_disc_' . md5( $url );
		if ( ! $fresh ) {
			$c = get_transient( $key );
			if ( is_array( $c ) ) {
				return $c;
			}
		}
		$d = self::get_json( $url, $p );
		if ( is_wp_error( $d ) ) {
			return $d;
		}
		foreach ( array( 'issuer', 'authorization_endpoint', 'token_endpoint', 'jwks_uri' ) as $k ) {
			if ( empty( $d[ $k ] ) ) {
				return new \WP_Error( 'educore_id_discovery', sprintf( 'Discovery document has no %s.', $k ) );
			}
		}
		foreach ( array( 'authorization_endpoint', 'token_endpoint', 'jwks_uri' ) as $k ) {
			if ( ! Providers::url_allowed( (string) $d[ $k ], $p ) ) {
				return new \WP_Error( 'educore_id_discovery', sprintf( 'Discovery %s points to an unexpected host.', $k ) );
			}
		}
		set_transient( $key, $d, 12 * HOUR_IN_SECONDS );
		return $d;
	}

	/** @return array|\WP_Error keys by kid */
	public static function jwks( string $p, string $uri, bool $fresh = false ) {
		$key = 'educore_id_jwks_' . md5( $uri );
		if ( ! $fresh ) {
			$c = get_transient( $key );
			if ( is_array( $c ) ) {
				return $c;
			}
		}
		$j = self::get_json( $uri, $p );
		if ( is_wp_error( $j ) ) {
			return $j;
		}
		$out = array();
		foreach ( (array) ( $j['keys'] ?? array() ) as $k ) {
			if ( 'RSA' === ( $k['kty'] ?? '' ) && ! empty( $k['n'] ) && ! empty( $k['e'] ) && ( empty( $k['use'] ) || 'sig' === $k['use'] ) ) {
				$out[ (string) ( $k['kid'] ?? '' ) ] = array( 'n' => $k['n'], 'e' => $k['e'] );
			}
		}
		if ( ! $out ) {
			return new \WP_Error( 'educore_id_jwks', 'No usable signing keys.' );
		}
		set_transient( $key, $out, 12 * HOUR_IN_SECONDS );
		return $out;
	}

	/** @return array|\WP_Error */
	public static function get_json( string $url, string $p ) {
		if ( ! Providers::url_allowed( $url, $p ) ) {
			return new \WP_Error( 'educore_id_host', 'Request to an unexpected host was blocked.' );
		}
		$r = wp_remote_get( $url, array( 'timeout' => 10, 'redirection' => 0, 'headers' => array( 'Accept' => 'application/json' ) ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$j    = json_decode( (string) wp_remote_retrieve_body( $r ), true );
		if ( 200 !== $code || ! is_array( $j ) ) {
			return new \WP_Error( 'educore_id_http', sprintf( 'HTTP %d from provider.', $code ) );
		}
		return $j;
	}

	/** @return array|\WP_Error token response */
	public static function exchange( string $p, string $endpoint, string $code, string $verifier ) {
		if ( ! Providers::url_allowed( $endpoint, $p ) ) {
			return new \WP_Error( 'educore_id_host', 'Token endpoint host not allowed.' );
		}
		$body = array(
			'grant_type'    => 'authorization_code',
			'code'          => $code,
			'redirect_uri'  => Providers::callback_url( $p ),
			'client_id'     => (string) Providers::config( $p )['client_id'],
			'client_secret' => Providers::secret( $p ),
		);
		if ( '' !== $verifier ) {
			$body['code_verifier'] = $verifier;
		}
		$r = wp_remote_post( $endpoint, array( 'timeout' => 15, 'redirection' => 0, 'headers' => array( 'Accept' => 'application/json' ), 'body' => $body ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$j = json_decode( (string) wp_remote_retrieve_body( $r ), true );
		if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) || ! is_array( $j ) || empty( $j['id_token'] ) ) {
			return new \WP_Error( 'educore_id_token', 'Token exchange failed' . ( is_array( $j ) && ! empty( $j['error'] ) ? ': ' . sanitize_key( (string) $j['error'] ) : '' ) . '.' );
		}
		return $j;
	}

	public static function b64url_decode( string $s ): string {
		$s = strtr( $s, '-_', '+/' );
		return (string) base64_decode( $s . str_repeat( '=', ( 4 - strlen( $s ) % 4 ) % 4 ), true );
	}

	/** RSA public key (PEM) from a JWK modulus/exponent. */
	public static function jwk_to_pem( string $n, string $e ): string {
		$mod = self::b64url_decode( $n );
		$exp = self::b64url_decode( $e );
		$len = static function ( int $l ): string {
			if ( $l < 128 ) {
				return chr( $l );
			}
			$b = ltrim( pack( 'N', $l ), "\0" );
			return chr( 0x80 | strlen( $b ) ) . $b;
		};
		$int = static function ( string $x ) use ( $len ): string {
			if ( ord( $x[0] ) > 0x7f ) {
				$x = "\0" . $x;
			}
			return "\x02" . $len( strlen( $x ) ) . $x;
		};
		$seq  = $int( $mod ) . $int( $exp );
		$rsa  = "\x30" . $len( strlen( $seq ) ) . $seq;
		$bit  = "\x03" . $len( strlen( $rsa ) + 1 ) . "\0" . $rsa;
		$alg  = "\x30\x0d\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00";
		$spki = "\x30" . $len( strlen( $alg . $bit ) ) . $alg . $bit;
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $spki ), 64, "\n" ) . "-----END PUBLIC KEY-----\n";
	}

	/**
	 * Verify an ID token and return its claims.
	 *
	 * @return array|\WP_Error
	 */
	public static function verify_id_token( string $p, string $jwt, array $disc, string $nonce, ?int $now = null ) {
		$now   = $now ?? time();
		$parts = explode( '.', $jwt );
		if ( 3 !== count( $parts ) ) {
			return new \WP_Error( 'educore_id_jwt', 'Malformed ID token.' );
		}
		$head   = json_decode( self::b64url_decode( $parts[0] ), true );
		$claims = json_decode( self::b64url_decode( $parts[1] ), true );
		$sig    = self::b64url_decode( $parts[2] );
		if ( ! is_array( $head ) || ! is_array( $claims ) || 'RS256' !== ( $head['alg'] ?? '' ) ) {
			return new \WP_Error( 'educore_id_alg', 'Unsupported ID token algorithm.' );
		}
		$keys = self::jwks( $p, (string) $disc['jwks_uri'] );
		$kid  = (string) ( $head['kid'] ?? '' );
		if ( ! is_wp_error( $keys ) && ! isset( $keys[ $kid ] ) ) {
			$keys = self::jwks( $p, (string) $disc['jwks_uri'], true ); // Key rotation.
		}
		if ( is_wp_error( $keys ) ) {
			return $keys;
		}
		$k = $keys[ $kid ] ?? ( 1 === count( $keys ) && '' === $kid ? reset( $keys ) : null );
		if ( ! $k ) {
			return new \WP_Error( 'educore_id_kid', 'Unknown signing key.' );
		}
		if ( 1 !== openssl_verify( $parts[0] . '.' . $parts[1], $sig, self::jwk_to_pem( $k['n'], $k['e'] ), OPENSSL_ALGO_SHA256 ) ) {
			return new \WP_Error( 'educore_id_signature', 'ID token signature is invalid.' );
		}
		$cid = (string) Providers::config( $p )['client_id'];
		$iss = (string) $disc['issuer'];
		if ( false !== strpos( $iss, '{tenantid}' ) ) {
			$tid = (string) ( $claims['tid'] ?? '' );
			if ( ! preg_match( '/^[0-9a-f-]{36}$/', $tid ) ) {
				return new \WP_Error( 'educore_id_issuer', 'Missing tenant in ID token.' );
			}
			$iss = str_replace( '{tenantid}', $tid, $iss );
		}
		$issuers = 'google' === $p ? array( $iss, 'accounts.google.com', 'https://accounts.google.com' ) : array( $iss );
		if ( ! in_array( (string) ( $claims['iss'] ?? '' ), $issuers, true ) ) {
			return new \WP_Error( 'educore_id_issuer', 'ID token issuer does not match.' );
		}
		$aud = (array) ( $claims['aud'] ?? array() );
		if ( ! in_array( $cid, $aud, true ) || ( count( $aud ) > 1 && ( $claims['azp'] ?? '' ) !== $cid ) ) {
			return new \WP_Error( 'educore_id_audience', 'ID token was issued to a different application.' );
		}
		if ( (int) ( $claims['exp'] ?? 0 ) < $now - self::SKEW ) {
			return new \WP_Error( 'educore_id_expired', 'ID token has expired.' );
		}
		if ( isset( $claims['nbf'] ) && (int) $claims['nbf'] > $now + self::SKEW ) {
			return new \WP_Error( 'educore_id_nbf', 'ID token is not valid yet.' );
		}
		if ( isset( $claims['iat'] ) && (int) $claims['iat'] > $now + self::SKEW ) {
			return new \WP_Error( 'educore_id_iat', 'ID token was issued in the future.' );
		}
		if ( ! hash_equals( $nonce, (string) ( $claims['nonce'] ?? '' ) ) ) {
			return new \WP_Error( 'educore_id_nonce', 'ID token nonce does not match.' );
		}
		if ( empty( $claims['sub'] ) ) {
			return new \WP_Error( 'educore_id_sub', 'ID token has no subject.' );
		}
		// Microsoft: restrict to the configured audience of accounts.
		if ( 'microsoft' === $p ) {
			$t = (string) Providers::config( $p )['tenant'];
			$consumer = '9188040d-6c67-4c5b-b112-36a304b66dad' === ( $claims['tid'] ?? '' );
			if ( ( 'consumers' === $t && ! $consumer ) || ( 'organizations' === $t && $consumer ) || ( Providers::valid_tenant( $t ) && ! in_array( $t, array( 'consumers', 'organizations', 'common' ), true ) && $t !== ( $claims['tid'] ?? '' ) ) ) {
				return new \WP_Error( 'educore_id_tenant', 'This Microsoft account type is not accepted here.' );
			}
		}
		return $claims;
	}
}
