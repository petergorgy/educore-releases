<?php
namespace EduCore\Workspace;

use EduCore\Core\Branding;
use EduCore\Core\I18n;
use EduCore\Core\Pages as CorePages;
use EduCore\Core\Registry;

defined( 'ABSPATH' ) || exit;

/**
 * About EduCore (`/about/`, public) and the role-based User Guide (`/help/`). Signed-in users see the guides for
 * the roles they hold first; academic managers and administrators can open every guide (to support their staff).
 * Visitors see the learner and guardian guides only. Content is static and translatable; links point to the
 * places each task is done, so the guide never drifts from the navigation.
 */
final class Help {
	public const ROLES = array( 'learner', 'guardian', 'teacher', 'instructor', 'tutor', 'manager', 'admin' );

	public static function register(): void {
		add_shortcode( 'educore_help', array( self::class, 'render_help' ) );
		add_shortcode( 'educore_about', array( self::class, 'render_about' ) );
		add_action( 'wp_enqueue_scripts', array( self::class, 'public_assets' ), 20 );
		add_filter( 'the_content', array( self::class, 'extend_about' ), 20 );
	}

	/** The core About page keeps its mission text; the platform overview is appended below it (no page is replaced). */
	public static function extend_about( $content ) {
		static $done = false;
		$id = CorePages::id( 'about' );
		if ( $done || ! $id || ! is_page( $id ) || (int) get_the_ID() !== $id || false !== strpos( (string) $content, 'ec-about' ) ) {
			return $content;
		}
		$done = true; // Block themes may filter the content more than once (excerpts, previews).
		return $content . self::render_about();
	}

	public static function about_url(): string {
		return CorePages::url( 'about' );
	}

	/** Outside the shell (visitors, or a theme page) the guide still needs the workspace stylesheet. */
	public static function public_assets(): void {
		if ( is_page() && in_array( (int) get_queried_object_id(), array_filter( array( Pages::id( 'help' ), CorePages::id( 'about' ) ) ), true ) && ! Shell::active() ) {
			wp_enqueue_style( 'educore-ws' );
		}
	}

	private static function q( string $k ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view parameter.
		return isset( $_GET[ $k ] ) ? sanitize_key( wp_unslash( $_GET[ $k ] ) ) : '';
	}

	public static function labels(): array {
		return array(
			'learner'    => __( 'Learner', 'educore-workspace' ),
			'guardian'   => __( 'Parent or guardian', 'educore-workspace' ),
			'teacher'    => __( 'Teacher', 'educore-workspace' ),
			'instructor' => __( 'Instructor (course author)', 'educore-workspace' ),
			'tutor'      => __( 'Tutor', 'educore-workspace' ),
			'manager'    => __( 'Academic manager', 'educore-workspace' ),
			'admin'      => __( 'Administrator', 'educore-workspace' ),
		);
	}

	/** Guides relevant to a user, most specific first. @return string[] */
	public static function roles_of( int $uid ): array {
		if ( ! $uid ) {
			return array();
		}
		$r = array();
		if ( user_can( $uid, 'manage_options' ) ) {
			$r[] = 'admin';
		}
		if ( user_can( $uid, 'ec_manage_all_courses' ) ) {
			$r[] = 'manager';
		}
		if ( user_can( $uid, 'edit_ec_courses' ) && ! user_can( $uid, 'ec_manage_all_courses' ) ) {
			$r[] = 'instructor';
		}
		if ( user_can( $uid, 'ec_teach' ) ) {
			$r[] = 'teacher';
		}
		if ( user_can( $uid, 'ec_tutor_sessions' ) ) {
			$r[] = 'tutor';
		}
		if ( Guardian::is_guardian( $uid ) ) {
			$r[] = 'guardian';
		}
		if ( user_can( $uid, 'ec_learn' ) ) {
			$r[] = 'learner';
		}
		return array_values( array_unique( $r ) );
	}

	/** Which guides a viewer may open. Staff oversight roles may open all (to support colleagues). */
	public static function allowed( int $uid ): array {
		if ( $uid && ( user_can( $uid, 'manage_options' ) || user_can( $uid, 'ec_manage_all_courses' ) ) ) {
			return self::ROLES;
		}
		return array_values( array_unique( array_merge( self::roles_of( $uid ), array( 'learner', 'guardian' ) ) ) );
	}

	private static function link( string $url, string $label ): string {
		return '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
	}

	private static function hub_url( string $view = '' ): string {
		return class_exists( '\EduCore\TeachingHub\Portal' ) ? \EduCore\TeachingHub\Portal::url( $view ) : home_url( '/' );
	}

	/**
	 * Guide content: [ intro, where (url,label), sections[ title => steps[] ], tips[] ].
	 * Steps are short imperative sentences; %s placeholders receive links.
	 */
	public static function guide( string $role ): array {
		$studio = Pages::url( 'studio' );
		$manage = Pages::url( 'manage' );
		switch ( $role ) {
			case 'learner':
				return array(
					'intro'    => __( 'Follow your courses, practise, take assessments and keep track of your progress — on a phone, tablet or computer, in English, French or Arabic.', 'educore-workspace' ),
					'where'    => array( CorePages::url( 'dashboard' ), __( 'My learning', 'educore-workspace' ) ),
					'sections' => array(
						__( 'Getting started', 'educore-workspace' ) => array(
							__( 'Sign in and open My learning. Your enrolled courses and your next lesson are shown first.', 'educore-workspace' ),
							__( 'Choose your language from the language menu at the top. Arabic switches the whole interface to right-to-left.', 'educore-workspace' ),
							__( 'Complete your profile (My profile) so your teachers and certificates show the right name.', 'educore-workspace' ),
						),
						__( 'Studying a course', 'educore-workspace' ) => array(
							__( 'Open a course, then a lesson. Your place is saved automatically, so you can continue later on any device.', 'educore-workspace' ),
							__( 'Mark a lesson as complete when you finish it; some lessons complete themselves when you pass their quiz.', 'educore-workspace' ),
							__( 'Write notes on a lesson to keep what matters; only you can see them.', 'educore-workspace' ),
							__( 'Practise with the questions of a lesson: you get feedback straight away, with a limited number of tries per question, and practice does not count towards your grade.', 'educore-workspace' ),
						),
						__( 'Assessments and assignments', 'educore-workspace' ) => array(
							__( 'Before you start, read the instructions: the time limit, the number of attempts and when the assessment closes are shown on the start page.', 'educore-workspace' ),
							__( 'Your answers are saved as you go. If your connection drops, open the assessment again to continue the same attempt.', 'educore-workspace' ),
							__( 'Results appear when your teacher releases them; essay answers are marked by a teacher.', 'educore-workspace' ),
							__( 'Assignments show their due date on your dashboard; submit before the deadline and read the feedback when it is returned.', 'educore-workspace' ),
						),
						__( 'Progress and certificates', 'educore-workspace' ) => array(
							__( 'My progress shows your completion, average score, active days and what is still pending.', 'educore-workspace' ),
							__( 'When you complete a course that awards a certificate, it appears in your learning history; anyone can check it with its verification code.', 'educore-workspace' ),
						),
					),
					'tips'     => array(
						__( 'Learners under 18 need a parent or guardian’s consent before studying; the request is sent by e-mail when the account is created.', 'educore-workspace' ),
						__( 'You can ask for a copy of your data, or for its deletion, by writing to support.', 'educore-workspace' ),
					),
				);
			case 'guardian':
				return array(
					'intro'    => __( 'Give consent for your child, follow their progress and stay in touch with their teachers.', 'educore-workspace' ),
					'where'    => array( CorePages::url( 'guardian' ), __( 'My learners', 'educore-workspace' ) ),
					'sections' => array(
						__( 'Consent', 'educore-workspace' ) => array(
							__( 'When a school creates an account for a learner under 18, you receive an e-mail with a consent link. Open it, read the information and give or decline consent.', 'educore-workspace' ),
							__( 'Until consent is given, the learner cannot study. You can withdraw consent at any time by contacting support.', 'educore-workspace' ),
						),
						__( 'Following progress', 'educore-workspace' ) => array(
							__( 'Sign in and open My learners to see each linked child’s courses, progress and results.', 'educore-workspace' ),
							__( 'If you have several children, each appears separately; you only see children linked to your account.', 'educore-workspace' ),
						),
						__( 'Communication', 'educore-workspace' ) => array(
							__( 'Messages between teachers and learners under 18 are visible to the guardian, and any message can be reported.', 'educore-workspace' ),
						),
					),
					'tips'     => array(
						__( 'If a consent e-mail did not arrive, ask the school to send it again; check your spam folder first.', 'educore-workspace' ),
					),
				);
			case 'teacher':
				return array(
					'intro'    => __( 'Run your classes day to day: plan lessons, set assignments, grade, take attendance and follow your learners.', 'educore-workspace' ),
					'where'    => array( self::hub_url(), __( 'Teaching Hub', 'educore-workspace' ) ),
					'sections' => array(
						__( 'Your day in the Teaching Hub', 'educore-workspace' ) => array(
							__( 'The Overview shows what needs you today: work to grade, upcoming sessions and learners who need attention.', 'educore-workspace' ),
							__( 'Classes lists your groups; open one to see members and their progress.', 'educore-workspace' ),
							__( 'Use Quick actions (+ at the top) to create an assignment or take attendance in two clicks.', 'educore-workspace' ),
						),
						__( 'Assignments and grading', 'educore-workspace' ) => array(
							__( 'Create an assignment with instructions, a due date, the target class or learners, and an optional rubric.', 'educore-workspace' ),
							__( 'Grade from the Grading centre: assignments and essay answers from exams are in one queue, oldest first.', 'educore-workspace' ),
							__( 'Results stay private until you release them; every grade change is logged.', 'educore-workspace' ),
						),
						__( 'Attendance and planning', 'educore-workspace' ) => array(
							__( 'Take attendance per session; you can export it for your records.', 'educore-workspace' ),
							__( 'The planner keeps lesson plans per class and date, and can start from a template.', 'educore-workspace' ),
						),
						__( 'Learners at risk', 'educore-workspace' ) => array(
							__( 'The Attention center on the Overview flags learners who need follow-up, so you can act early.', 'educore-workspace' ),
						),
					),
					'tips'     => array(
						__( 'To change course content (lessons, questions, quizzes), use the Course Studio from the workspace switcher in your account menu.', 'educore-workspace' ),
					),
				);
			case 'instructor':
				return array(
					'intro'    => __( 'Build and maintain courses: structure, lessons, question banks and assessments, then submit them for review.', 'educore-workspace' ),
					'where'    => array( $studio, __( 'Course Studio', 'educore-workspace' ) ),
					'sections' => array(
						__( 'Building a course', 'educore-workspace' ) => array(
							__( 'Choose New course, give it a title and follow the steps: Basics, Classification, Objectives & enrollment, Units & lessons, Assessments, Review & publish.', 'educore-workspace' ),
							__( 'Add units and lessons in Units & lessons; reorder them with the arrow buttons or by dragging, then choose Save order.', 'educore-workspace' ),
							__( 'The lesson editor saves a draft automatically every 30 seconds; earlier versions can be restored from the history.', 'educore-workspace' ),
						),
						__( 'Question bank', 'educore-workspace' ) => array(
							__( 'Open Question banks and choose your course. Ten question types are available; the form only shows the fields each type needs.', 'educore-workspace' ),
							__( 'The learner preview shows exactly what learners will see, with the correct answer marked.', 'educore-workspace' ),
							__( 'Import many questions at once from Excel, CSV, Moodle XML, GIFT or an EduCore package: nothing is written until you confirm the preview.', 'educore-workspace' ),
							__( 'A question that learners have answered is never changed; saving creates a new version so past results stay correct.', 'educore-workspace' ),
						),
						__( 'Assessments', 'educore-workspace' ) => array(
							__( 'Create an assessment, set its rules and schedule (in the site’s time zone), then add pools that draw questions at random.', 'educore-workspace' ),
							__( 'The Readiness panel tells you whether every pool can be filled from published questions; an assessment cannot be published until it can.', 'educore-workspace' ),
						),
						__( 'Review, publication and translation', 'educore-workspace' ) => array(
							__( 'When the readiness check is complete, choose Submit for review. A publisher approves or sends it back with a note.', 'educore-workspace' ),
							__( 'From Review & publish you can create a French or Arabic copy of the whole course for translation.', 'educore-workspace' ),
							__( 'Learning analytics (Course Studio) shows completion, difficult questions and learners at risk for your courses.', 'educore-workspace' ),
						),
					),
					'tips'     => array(
						__( 'Only a lead instructor or academic manager can publish questions and assessments; other instructors submit them for review.', 'educore-workspace' ),
					),
				);
			case 'tutor':
				return array(
					'intro'    => __( 'Manage your availability and one-to-one or group tutoring sessions.', 'educore-workspace' ),
					'where'    => array( Pages::url( 'tutor' ), __( 'Tutor workspace', 'educore-workspace' ) ),
					'sections' => array(
						__( 'Sessions', 'educore-workspace' ) => array(
							__( 'Set your weekly availability and the dates you are away; learners can only book free slots.', 'educore-workspace' ),
							__( 'Open a session to see the learner, the topic and the session workspace; mark it completed or reschedule it.', 'educore-workspace' ),
						),
						__( 'Profile', 'educore-workspace' ) => array(
							__( 'Keep your tutor profile up to date (subjects, languages, short presentation); it is what learners see when they look for a tutor.', 'educore-workspace' ),
						),
					),
					'tips'     => array(
						__( 'Messages with learners under 18 are visible to their guardian.', 'educore-workspace' ),
					),
				);
			case 'manager':
				return array(
					'intro'    => __( 'Oversee people, courses, programmes, quality and results for the whole platform.', 'educore-workspace' ),
					'where'    => array( $manage, __( 'EduCore Management', 'educore-workspace' ) ),
					'sections' => array(
						__( 'People', 'educore-workspace' ) => array(
							__( 'Add a person with one or several roles; they receive an invitation to set their own password. Learners under 18 need a guardian’s consent first.', 'educore-workspace' ),
							__( 'Suspend or reactivate an account, send a password reset, and link guardians to learners from the person’s page.', 'educore-workspace' ),
							__( 'You cannot grant technical administrator rights from EduCore Management; that is reserved to technical administrators.', 'educore-workspace' ),
						),
						__( 'Courses and programmes', 'educore-workspace' ) => array(
							__( 'Courses lists every course with its team and enrollments; assign lead instructors, instructors and graders there.', 'educore-workspace' ),
							__( 'Programmes shows each programme as the institutional unit: courses, learners and completion, plus courses not linked to any programme.', 'educore-workspace' ),
							__( 'The Review queue in the Course Studio lists courses waiting for approval.', 'educore-workspace' ),
						),
						__( 'Quality and results', 'educore-workspace' ) => array(
							__( 'Learning analytics compares courses, cohorts and question quality; exports are available in CSV and Excel.', 'educore-workspace' ),
							__( 'Certificates: issue manually (enrolled learners only; a justification is required if the course is not completed), revoke with a reason, or reinstate.', 'educore-workspace' ),
							__( 'The Audit log records every sensitive action; filter it by action, for example certificate. or settings.', 'educore-workspace' ),
						),
					),
					'tips'     => array(
						__( 'Every page in EduCore Management checks your rights on the server; hiding a menu item never grants or removes access.', 'educore-workspace' ),
					),
				);
			case 'admin':
				return array(
					'intro'    => __( 'Keep the platform configured, secure, backed up and up to date.', 'educore-workspace' ),
					'where'    => array( Pages::url( 'manage', array( 'v' => 'settings' ) ), __( 'Platform settings', 'educore-workspace' ) ),
					'sections' => array(
						__( 'Everyday settings', 'educore-workspace' ) => array(
							__( 'Platform settings covers the support e-mail, default language, audit retention, registration and consent, engagement and branding. Opening registration and raising the consent version ask for an explicit confirmation.', 'educore-workspace' ),
							__( 'System status shows installed versions and health checks; resolve every WARN.', 'educore-workspace' ),
						),
						__( 'Backups and recovery', 'educore-workspace' ) => array(
							__( 'Create a backup before every change, verify it and run the restore test: the test restores into separate tables and never touches live data.', 'educore-workspace' ),
							__( 'Download and keep the offline recovery key in a safe place: without it, encrypted backups cannot be restored on another server.', 'educore-workspace' ),
						),
						__( 'Updates', 'educore-workspace' ) => array(
							__( 'Updates come only from the signed EduCore release channel; a package is installed only if its signature and checksum verify.', 'educore-workspace' ),
							__( 'Maintenance releases can install automatically; feature releases always wait for an administrator.', 'educore-workspace' ),
						),
						__( 'Security', 'educore-workspace' ) => array(
							__( 'Use a unique password and two-factor authentication for every administrator account.', 'educore-workspace' ),
							__( 'Technical tools (updates, e-mail server, backups, plugins) stay in WordPress and are available to technical administrators only.', 'educore-workspace' ),
						),
					),
					'tips'     => array(
						__( 'Never share administrator credentials in e-mail or chat; if it happens, change the password immediately.', 'educore-workspace' ),
					),
				);
		}
		return array();
	}

	/* ---------- rendering ---------- */

	public static function render_help(): string {
		$uid     = get_current_user_id();
		$allowed = self::allowed( $uid );
		$mine    = self::roles_of( $uid );
		$labels  = self::labels();
		$req     = self::q( 'role' );
		$role    = in_array( $req, $allowed, true ) ? $req : ( $mine[0] ?? 'learner' );
		Shell::title( __( 'User guide', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'User guide', 'educore-workspace' ) ) ) );
		$base = Pages::url( 'help' );
		$o    = '<div class="ec-help' . ( Shell::active() ? '' : ' ec-ws-public' ) . '">';
		if ( ! $uid ) {
			$o .= '<p class="ec-notice ec-notice--info">' . esc_html__( 'Sign in to see the guide for your role (teacher, instructor, tutor, manager or administrator).', 'educore-workspace' ) . ' ' . self::link( wp_login_url( $base ), __( 'Sign in', 'educore-workspace' ) ) . '</p>';
		}
		$o .= '<nav class="ec-ws-tabs" aria-label="' . esc_attr__( 'Guides by role', 'educore-workspace' ) . '"><ul>';
		foreach ( self::ROLES as $r ) {
			if ( ! in_array( $r, $allowed, true ) ) {
				continue;
			}
			$o .= '<li><a href="' . esc_url( add_query_arg( 'role', $r, $base ) ) . '"' . ( $r === $role ? ' aria-current="page"' : '' ) . '>' . esc_html( $labels[ $r ] ) . ( in_array( $r, $mine, true ) ? ' <span class="ec-chip ec-chip--publish">' . esc_html__( 'You', 'educore-workspace' ) . '</span>' : '' ) . '</a></li>';
		}
		$o .= '</ul></nav>';
		$g  = self::guide( $role );
		/* translators: %s: role name */
		$o .= '<article class="ec-card ec-ws-section ec-help-guide" aria-labelledby="ec-help-h"><h2 id="ec-help-h">' . esc_html( sprintf( __( 'Guide for: %s', 'educore-workspace' ), $labels[ $role ] ) ) . '</h2><p class="ec-help-intro">' . esc_html( $g['intro'] ) . '</p>';
		if ( $uid && in_array( $role, $mine, true ) ) {
			$o .= '<p><a class="ec-btn ec-btn--primary" href="' . esc_url( $g['where'][0] ) . '">' . esc_html( sprintf( /* translators: %s: workspace name */ __( 'Open %s', 'educore-workspace' ), $g['where'][1] ) ) . '</a></p>';
		} else {
			/* translators: %s: workspace name */
			$o .= '<p class="ec-muted">' . esc_html( sprintf( __( 'Where: %s', 'educore-workspace' ), $g['where'][1] ) ) . '</p>';
		}
		$o .= '<nav class="ec-help-toc" aria-label="' . esc_attr__( 'On this page', 'educore-workspace' ) . '"><ol>';
		$i  = 0;
		foreach ( array_keys( $g['sections'] ) as $title ) {
			$o .= '<li><a href="#ec-help-s' . ( ++$i ) . '">' . esc_html( $title ) . '</a></li>';
		}
		$o .= '</ol></nav>';
		$i  = 0;
		foreach ( $g['sections'] as $title => $steps ) {
			$o .= '<section aria-labelledby="ec-help-s' . ( ++$i ) . '"><h3 id="ec-help-s' . $i . '">' . esc_html( $title ) . '</h3><ol class="ec-help-steps">' . implode( '', array_map( static fn( $s ) => '<li>' . esc_html( $s ) . '</li>', $steps ) ) . '</ol></section>';
		}
		if ( $g['tips'] ) {
			$o .= '<aside class="ec-help-tips"><h3>' . esc_html__( 'Good to know', 'educore-workspace' ) . '</h3><ul>' . implode( '', array_map( static fn( $s ) => '<li>' . esc_html( $s ) . '</li>', $g['tips'] ) ) . '</ul></aside>';
		}
		$o    .= '</article>';
		$email = (string) get_option( 'educore_support_email', 'support@educore.gorgy.org' );
		/* translators: %s: support e-mail address */
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Still need help?', 'educore-workspace' ) . '</h2><p>' . sprintf( esc_html__( 'Write to %s with a short description and, if possible, a screenshot. Never send your password.', 'educore-workspace' ), '<a href="' . esc_url( 'mailto:' . $email ) . '">' . esc_html( $email ) . '</a>' ) . '</p><p>' . self::link( self::about_url(), __( 'About EduCore', 'educore-workspace' ) ) . '</p></section>';
		return $o . '</div>';
	}

	public static function render_about(): string {
		$name = Branding::name();
		$features = array(
			__( 'Courses', 'educore-workspace' )              => __( 'Structured courses with units and lessons, rich content, progress saved on every device and personal notes.', 'educore-workspace' ),
			__( 'Assessment', 'educore-workspace' )           => __( 'Ten question types, question banks with versioning, timed and scheduled assessments drawn at random, practice with instant feedback, rubric-based marking.', 'educore-workspace' ),
			__( 'Teaching', 'educore-workspace' )             => __( 'A Teaching Hub for classes, assignments, grading, attendance, lesson planning and tutoring.', 'educore-workspace' ),
			__( 'Families', 'educore-workspace' )             => __( 'Guardian consent for learners under 18, a guardian portal and safeguarded communication.', 'educore-workspace' ),
			__( 'Results', 'educore-workspace' )              => __( 'Learning analytics for teachers and managers, verifiable certificates and programme-level reporting.', 'educore-workspace' ),
			__( 'Three languages', 'educore-workspace' )      => __( 'English, French and Arabic, with a full right-to-left interface for Arabic.', 'educore-workspace' ),
		);
		$o  = '<div class="ec-help ec-about' . ( Shell::active() ? '' : ' ec-ws-public' ) . '">';
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html( sprintf( /* translators: %s: platform name */ __( '%s at a glance', 'educore-workspace' ), $name ) ) . '</h2><p class="ec-help-intro">' . esc_html__( 'EduCore is a learning management system for schools and training programmes: one place for learners to study, for teachers to teach and assess, for families to follow progress and for managers to assure quality.', 'educore-workspace' ) . '</p></section>';
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'What it offers', 'educore-workspace' ) . '</h2><dl class="ec-about-features">';
		foreach ( $features as $t => $d ) {
			$o .= '<div><dt>' . esc_html( $t ) . '</dt><dd>' . esc_html( $d ) . '</dd></div>';
		}
		$o .= '</dl></section>';
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Privacy, safety and reliability', 'educore-workspace' ) . '</h2><ul class="ec-help-steps">';
		foreach ( array(
			__( 'Learners under 18 study only after a parent or guardian has given consent; consent can be withdrawn.', 'educore-workspace' ),
			__( 'Every person can ask for a copy of their data or for its deletion.', 'educore-workspace' ),
			__( 'Access is checked on the server for every action; sensitive actions are recorded in an audit log.', 'educore-workspace' ),
			__( 'The platform is backed up with encryption and every backup is test-restored; updates are signed and verified before installation.', 'educore-workspace' ),
			__( 'The interface follows accessibility guidelines (WCAG 2.2 AA) and works with keyboards and screen readers.', 'educore-workspace' ),
		) as $s ) {
			$o .= '<li>' . esc_html( $s ) . '</li>';
		}
		$o .= '</ul></section>';
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Get started', 'educore-workspace' ) . '</h2><p class="ec-ws-actions">' . ( is_user_logged_in() ? '' : '<a class="ec-btn ec-btn--primary" href="' . esc_url( wp_login_url() ) . '">' . esc_html__( 'Sign in', 'educore-workspace' ) . '</a> ' ) . '<a class="ec-btn" href="' . esc_url( Pages::url( 'help' ) ) . '">' . esc_html__( 'User guide', 'educore-workspace' ) . '</a> <a class="ec-btn" href="' . esc_url( CorePages::url( 'courses' ) ) . '">' . esc_html__( 'Course catalogue', 'educore-workspace' ) . '</a></p>';
		$email = (string) get_option( 'educore_support_email', 'support@educore.gorgy.org' );
		/* translators: %s: support e-mail address */
		$o .= '<p>' . sprintf( esc_html__( 'Contact: %s', 'educore-workspace' ), '<a href="' . esc_url( 'mailto:' . $email ) . '">' . esc_html( $email ) . '</a>' ) . '</p>';
		if ( current_user_can( 'ec_manage_settings' ) ) {
			$v = Registry::all();
			/* translators: %s: version list */
			$o .= '<p class="ec-muted">' . esc_html( sprintf( __( 'Installed versions: %s', 'educore-workspace' ), implode( ' · ', array_map( static fn( $k, $x ) => $k . ' ' . $x, array_keys( $v ), $v ) ) ) ) . '</p>';
		}
		return $o . '</section></div>';
	}
}
