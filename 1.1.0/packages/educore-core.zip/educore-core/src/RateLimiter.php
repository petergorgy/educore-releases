<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Fixed-window DB rate limiter (works without object cache on shared hosting).
 * Also guards wp-login against password brute force.
 */
final class RateLimiter {

	/** Default policies: bucket => [max hits, window seconds]. */
	public const POLICIES = array(
		'login'        => array( 8, 900 ),
		'register'     => array( 5, 3600 ),
		'contact'      => array( 5, 3600 ),
		'attempt'      => array( 30, 60 ),
		'autosave'     => array( 120, 60 ),
		'guardian'     => array( 5, 3600 ),
		'verify'       => array( 60, 60 ),
		'rest_write'   => array( 120, 60 ),
	);

	public static function register(): void {
		add_filter( 'authenticate', array( self::class, 'guard_login' ), 30, 3 );
		add_action( 'wp_login_failed', array( self::class, 'login_failed' ) );
	}

	/** Records a hit and returns true if the caller is still within the limit. */
	public static function hit( string $bucket, string $key = '' ): bool {
		global $wpdb;
		[ $max, $window ] = self::policy( $bucket );
		$start            = (int) ( floor( time() / $window ) * $window );
		$hash             = hash( 'sha256', $bucket . '|' . ( '' === $key ? self::client_key() : $key ) );
		$table            = Schema::table( 'rate_limits' );
		$wpdb->query( $wpdb->prepare( "INSERT INTO {$table} (bucket,key_hash,window_start,hits) VALUES (%s,%s,%d,1) ON DUPLICATE KEY UPDATE hits = hits + 1", $bucket, $hash, $start ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$hits = (int) $wpdb->get_var( $wpdb->prepare( "SELECT hits FROM {$table} WHERE bucket=%s AND key_hash=%s AND window_start=%d", $bucket, $hash, $start ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		return $hits <= $max;
	}

	public static function exceeded( string $bucket, string $key = '' ): bool {
		global $wpdb;
		[ $max, $window ] = self::policy( $bucket );
		$start            = (int) ( floor( time() / $window ) * $window );
		$hash             = hash( 'sha256', $bucket . '|' . ( '' === $key ? self::client_key() : $key ) );
		$hits             = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT hits FROM ' . Schema::table( 'rate_limits' ) . ' WHERE bucket=%s AND key_hash=%s AND window_start=%d', $bucket, $hash, $start ) );
		return $hits >= $max;
	}

	/** @return array{0:int,1:int} */
	public static function policy( string $bucket ): array {
		$policies = apply_filters( 'educore/rate_limits', self::POLICIES );
		return $policies[ $bucket ] ?? array( 60, 60 );
	}

	public static function client_key(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'cli';
		return $ip;
	}

	/** @param \WP_User|\WP_Error|null $user */
	public static function guard_login( $user, $username, $password ) {
		if ( '' === (string) $username ) {
			return $user;
		}
		if ( self::exceeded( 'login' ) || self::exceeded( 'login', 'u:' . strtolower( (string) $username ) ) ) {
			Audit::log( 'security.login_throttled', 'user', 0, array( 'username_hash' => hash( 'sha256', strtolower( (string) $username ) ) ) );
			return new \WP_Error( 'educore_throttled', __( 'Too many login attempts. Please wait a few minutes and try again.', 'educore-core' ) );
		}
		return $user;
	}

	public static function login_failed( $username ): void {
		self::hit( 'login' );
		self::hit( 'login', 'u:' . strtolower( (string) $username ) );
	}

	public static function cleanup(): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . Schema::table( 'rate_limits' ) . ' WHERE window_start < %d', time() - DAY_IN_SECONDS ) );
	}
}
