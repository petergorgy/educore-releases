<?php
/**
 * Title: EduCore registration call to action
 * Slug: educore-theme/cta
 * Categories: educore-theme, call-to-action
 * Description: Invitation to create an account.
 */
?>
<!-- wp:group {"align":"wide","className":"ect-card ect-cta","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide ect-card ect-cta" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--60);padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
<?php $ect_open = educore_theme_registration_open(); ?>
<!-- wp:heading {"textAlign":"center"} --><h2 class="wp-block-heading has-text-align-center"><?php echo $ect_open ? esc_html__( 'Ready to start learning?', 'educore-theme' ) : esc_html__( 'Joining EduCore', 'educore-theme' ); ?></h2><!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color"><?php echo $ect_open ? esc_html__( 'Create your free account in a minute. Learners under 18 join with a parent or guardian’s consent.', 'educore-theme' ) : esc_html__( 'Accounts are currently created by your school or by our support team. Contact us to request access.', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"ect-btn-gold"} --><div class="wp-block-button ect-btn-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( educore_theme_url( $ect_open ? 'register' : 'contact' ) ); ?>"><?php echo $ect_open ? esc_html__( 'Create a free account', 'educore-theme' ) : esc_html__( 'Request access', 'educore-theme' ); ?></a></div><!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
