<?php
/**
 * Title: EduCore instructors introduction (owner to complete)
 * Slug: educore-theme/instructors-intro
 * Categories: educore-theme, team
 * Description: Section introducing instructors. Contains placeholder guidance only — no invented people or testimonials.
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--40)">
<!-- wp:heading {"align":"wide"} --><h2 class="wp-block-heading alignwide"><?php esc_html_e( 'Meet the instructors', 'educore-theme' ); ?></h2><!-- /wp:heading -->
<!-- wp:paragraph {"align":"wide"} --><p class="alignwide"><?php esc_html_e( 'EduCore courses are written and taught by qualified teachers. Each course page introduces its instructors.', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<?php if ( current_user_can( 'edit_theme_options' ) ) : ?>
<!-- wp:paragraph {"align":"wide","className":"ect-placeholder-note"} --><p class="alignwide ect-placeholder-note"><?php esc_html_e( 'Site owner: replace this note with real instructor profiles (name, photo, short bio) once you have their consent, or remove this section. Do not publish invented people or testimonials. This note is shown to administrators only.', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<?php endif; ?>
</div>
<!-- /wp:group -->
