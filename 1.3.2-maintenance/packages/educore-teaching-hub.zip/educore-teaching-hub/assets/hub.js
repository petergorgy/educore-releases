/* EduCore Teaching Hub — progressive enhancement only; every action works without JavaScript. */
(function () {
	'use strict';
	document.addEventListener('click', function (e) {
		var t = e.target.closest('[data-ec-th-nav]');
		if (t) {
			var nav = t.closest('.ec-th-nav');
			var open = nav.classList.toggle('is-open');
			t.setAttribute('aria-expanded', open ? 'true' : 'false');
			return;
		}
		var c = e.target.closest('[data-ec-th-confirm]');
		if (c && !window.confirm(c.getAttribute('data-ec-th-confirm'))) {
			e.preventDefault();
			return;
		}
		var all = e.target.closest('[data-ec-th-all-present]');
		if (all) {
			all.closest('form').querySelectorAll('select[name^="marks"]').forEach(function (s) {
				if (!s.value) { s.value = 'present'; }
			});
		}
	});
	/* Inline validation: mark invalid fields after the first submit attempt. */
	document.addEventListener('invalid', function (e) {
		if (e.target.closest && e.target.closest('.ec-th-form')) { e.target.classList.add('ec-th-invalid'); }
	}, true);
	document.addEventListener('input', function (e) {
		if (e.target.classList && e.target.classList.contains('ec-th-invalid') && e.target.checkValidity()) { e.target.classList.remove('ec-th-invalid'); }
	});
	/* Prevent double submission; show a busy state. */
	document.addEventListener('submit', function (e) {
		var f = e.target;
		if (!f.classList || !f.classList.contains('ec-th-form')) { return; }
		if (f.dataset.busy) { e.preventDefault(); return; }
		f.dataset.busy = '1';
		f.setAttribute('aria-busy', 'true');
		setTimeout(function () { delete f.dataset.busy; f.removeAttribute('aria-busy'); }, 8000);
	});
	/* Toasts fade after a few seconds (kept in the DOM for screen readers). */
	document.querySelectorAll('.ec-th-toast').forEach(function (n) {
		setTimeout(function () { n.style.opacity = '0.0'; n.style.transition = 'opacity .4s'; }, 4000);
	});
	/* Sortable tables (click a header). */
	document.querySelectorAll('table[data-ec-th-sortable] thead th').forEach(function (th, idx) {
		th.tabIndex = 0;
		th.setAttribute('role', 'button');
		var sort = function () {
			var tb = th.closest('table').tBodies[0];
			var dir = th.dataset.dir === 'asc' ? 'desc' : 'asc';
			th.dataset.dir = dir;
			Array.prototype.slice.call(tb.rows).sort(function (a, b) {
				var x = a.cells[idx].textContent.trim(), y = b.cells[idx].textContent.trim();
				return (dir === 'asc' ? 1 : -1) * x.localeCompare(y, document.documentElement.lang || undefined, { numeric: true });
			}).forEach(function (r) { tb.appendChild(r); });
		};
		th.addEventListener('click', sort);
		th.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); sort(); } });
	});
})();
