/* Registers EduCore dynamic blocks in the editor with a server-side preview. */
(function (wp) {
	if (!wp || !wp.blocks || !window.EduCoreBlocks) { return; }
	var el = wp.element.createElement;
	var SSR = wp.serverSideRender;
	var useBlockProps = wp.blockEditor && wp.blockEditor.useBlockProps;
	window.EduCoreBlocks.blocks.forEach(function (b) {
		if (wp.blocks.getBlockType(b.name)) {
			var existing = wp.blocks.getBlockType(b.name);
			if (existing.edit) { return; }
		}
		wp.blocks.registerBlockType(b.name, {
			apiVersion: 3,
			title: b.title,
			category: 'widgets',
			icon: 'welcome-learn-more',
			edit: function (props) {
				var bp = useBlockProps ? useBlockProps() : {};
				return el('div', bp, el(SSR, { block: b.name, attributes: props.attributes }));
			},
			save: function () { return null; }
		});
	});
})(window.wp);
