<?php
namespace EduCore\Notifications;

use EduCore\Core\Registry;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	public const WORKER    = 'educore_notifications_worker';
	public const REMINDERS = 'educore_notifications_reminders';

	public static function tables(): array {
		return array(
			'notification_jobs'  => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				event VARCHAR(40) NOT NULL,
				recipient_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				recipient_email VARCHAR(191) NOT NULL,
				channel VARCHAR(12) NOT NULL DEFAULT 'email',
				lang VARCHAR(5) NOT NULL DEFAULT 'en',
				subject VARCHAR(255) NOT NULL,
				body LONGTEXT NOT NULL,
				payload LONGTEXT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'queued',
				tries TINYINT UNSIGNED NOT NULL DEFAULT 0,
				max_tries TINYINT UNSIGNED NOT NULL DEFAULT 4,
				next_try_at DATETIME NOT NULL,
				last_error VARCHAR(500) NOT NULL DEFAULT '',
				idempotency_key VARCHAR(191) NOT NULL,
				created_at DATETIME NOT NULL,
				sent_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY idempotency_key (idempotency_key),
				KEY status_next (status,next_try_at),
				KEY recipient_id (recipient_id),
				KEY event (event)",
			'notification_prefs' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				event VARCHAR(40) NOT NULL,
				channel VARCHAR(12) NOT NULL DEFAULT 'email',
				enabled TINYINT(1) NOT NULL DEFAULT 1,
				PRIMARY KEY  (id),
				UNIQUE KEY user_event_channel (user_id,event,channel)",
		);
	}

	public static function install(): void {
		Schema::migrate( 'educore_notifications_db_version', EDUCORE_NOTIFICATIONS_DB_VERSION, self::tables() );
		add_option( 'educore_mail_from', 'support@educore.gorgy.org' );
		add_option( 'educore_mail_from_name', 'EduCore' );
		self::schedule();
	}

	public static function boot(): void {
		Registry::register( 'notifications', EDUCORE_NOTIFICATIONS_VERSION );
		Schema::migrate( 'educore_notifications_db_version', EDUCORE_NOTIFICATIONS_DB_VERSION, self::tables() );
		add_action( 'educore/install/repair', static fn() => Schema::migrate( 'educore_notifications_db_version', EDUCORE_NOTIFICATIONS_DB_VERSION, self::tables() ) );
		add_action( 'init', array( self::class, 'textdomain' ) );
		add_filter( 'cron_schedules', array( self::class, 'cron_schedules' ) );
		add_action( 'init', array( self::class, 'schedule' ) );
		add_action( self::WORKER, array( Queue::class, 'process' ) );
		add_action( self::REMINDERS, array( Events::class, 'reminders' ) );
		Mailer::register();
		Events::register();
		Prefs::register();
		add_filter( 'educore/privacy/export', array( self::class, 'export' ), 10, 2 );
		add_action( 'educore/privacy/erase', array( self::class, 'erase' ) );
		if ( is_admin() ) {
			Admin::register();
		}
	}

	public static function textdomain(): void {
		load_plugin_textdomain( 'educore-notifications', false, dirname( plugin_basename( EDUCORE_NOTIFICATIONS_FILE ) ) . '/languages' );
	}

	public static function cron_schedules( array $s ): array {
		$s['educore_5min'] = array( 'interval' => 300, 'display' => 'Every 5 minutes (EduCore)' );
		return $s;
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::WORKER ) ) {
			wp_schedule_event( time() + 60, 'educore_5min', self::WORKER );
		}
		if ( ! wp_next_scheduled( self::REMINDERS ) ) {
			wp_schedule_event( time() + 900, 'daily', self::REMINDERS );
		}
	}

	/** @param array<int,array<string,mixed>> $data */
	public static function export( array $data, $user ): array {
		global $wpdb;
		if ( ! $user ) {
			return $data;
		}
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, event, subject, status, created_at, sent_at FROM ' . Schema::table( 'notification_jobs' ) . ' WHERE recipient_id=%d OR recipient_email=%s', $user->ID, $user->user_email ), ARRAY_A );
		foreach ( $rows as $r ) {
			$items = array();
			foreach ( $r as $k => $v ) {
				$items[] = array( 'name' => $k, 'value' => (string) $v );
			}
			$data[] = array( 'group_id' => 'educore-notifications', 'group_label' => __( 'E-mail notifications', 'educore-notifications' ), 'item_id' => 'notification-' . $r['id'], 'data' => $items );
		}
		return $data;
	}

	public static function erase( $user ): void {
		global $wpdb;
		if ( ! $user ) {
			return;
		}
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . Schema::table( 'notification_jobs' ) . ' WHERE recipient_id=%d OR recipient_email=%s', $user->ID, $user->user_email ) );
		$wpdb->delete( Schema::table( 'notification_prefs' ), array( 'user_id' => $user->ID ), array( '%d' ) );
	}
}
