<?php
namespace EduCore\Analytics;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Read-only access to assessment tables (owned by educore-assessments). Every method returns
 * null when the required tables/columns are absent, so analytics degrades gracefully.
 *
 * Conventions (from the P01 schema): a "scored" attempt has state graded|released, score NOT NULL and
 * max_score > 0. A "pending grading" attempt has state submitted. A response is "correct" when
 * COALESCE(final_score, auto_score) >= attempt_items.points.
 */
final class AssessmentSource {
	/** @var array<string,bool> */
	private static array $cache = array();

	public const SCORED_STATES = "('graded','released')";

	public static function reset(): void {
		self::$cache = array();
	}

	/** @param string[] $columns */
	public static function has( string $table, array $columns = array() ): bool {
		global $wpdb;
		$key = $table . ':' . implode( ',', $columns );
		if ( isset( self::$cache[ $key ] ) ) {
			return self::$cache[ $key ];
		}
		$t = Schema::table( $table );
		// SHOW COLUMNS also works for temporary tables (unlike SHOW TABLES).
		$suppress = $wpdb->suppress_errors( true );
		$cols     = $wpdb->get_col( "SHOW COLUMNS FROM `{$t}`" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$wpdb->suppress_errors( $suppress );
		$ok = ! empty( $cols ) && ! array_diff( $columns, $cols );
		return self::$cache[ $key ] = $ok;
	}

	public static function attempts_available(): bool {
		return self::has( 'attempts', array( 'assessment_id', 'user_id', 'state', 'score', 'max_score', 'submitted_at' ) )
			&& self::has( 'assessments', array( 'id', 'course_id' ) );
	}

	public static function questions_available(): bool {
		return self::attempts_available()
			&& self::has( 'attempt_items', array( 'id', 'attempt_id', 'question_version_id', 'points' ) )
			&& self::has( 'responses', array( 'attempt_item_id', 'auto_score', 'final_score' ) )
			&& self::has( 'question_versions', array( 'id', 'question_id' ) )
			&& self::has( 'questions', array( 'id', 'lesson_id' ) );
	}

	public static function in_list( array $ids ): string {
		$ids = array_map( 'intval', $ids );
		return $ids ? implode( ',', $ids ) : '0';
	}

	/** Scored attempt rows: user_id, assessment_id, course_id, pct, submitted_at. */
	public static function scored_attempts( Filters $f, ?int $user_id = null ): ?array {
		global $wpdb;
		if ( ! self::attempts_available() ) {
			return null;
		}
		$at   = Schema::table( 'attempts' );
		$as   = Schema::table( 'assessments' );
		$in   = self::in_list( $f->courses() );
		$user = null === $user_id ? '' : $wpdb->prepare( ' AND t.user_id=%d', $user_id );
		$sql  = "SELECT t.id, t.user_id, t.assessment_id, a.course_id, (t.score / t.max_score * 100) AS pct, t.submitted_at
			FROM {$at} t JOIN {$as} a ON a.id = t.assessment_id
			WHERE a.course_id IN ({$in}) AND t.state IN " . self::SCORED_STATES . ' AND t.score IS NOT NULL AND t.max_score > 0'
			. $wpdb->prepare( ' AND t.submitted_at BETWEEN %s AND %s', $f->from_dt(), $f->to_dt() ) . $user . $f->cohort_sql( 't.user_id' ) . ' ORDER BY t.submitted_at, t.id';
		return $wpdb->get_results( $sql, ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Item-level scored responses: user_id, course_id, lesson_id, question_id, correct(0/1), pct. */
	public static function scored_items( Filters $f, ?int $user_id = null ): ?array {
		global $wpdb;
		if ( ! self::questions_available() ) {
			return null;
		}
		$at   = Schema::table( 'attempts' );
		$as   = Schema::table( 'assessments' );
		$it   = Schema::table( 'attempt_items' );
		$rs   = Schema::table( 'responses' );
		$qv   = Schema::table( 'question_versions' );
		$q    = Schema::table( 'questions' );
		$in   = self::in_list( $f->courses() );
		$user = null === $user_id ? '' : $wpdb->prepare( ' AND t.user_id=%d', $user_id );
		$sql  = "SELECT t.user_id, a.course_id, q.lesson_id, q.id AS question_id,
				(COALESCE(r.final_score, r.auto_score) >= i.points) AS correct,
				(COALESCE(r.final_score, r.auto_score) / i.points * 100) AS pct
			FROM {$it} i
			JOIN {$at} t ON t.id = i.attempt_id
			JOIN {$as} a ON a.id = t.assessment_id
			JOIN {$rs} r ON r.attempt_item_id = i.id
			JOIN {$qv} v ON v.id = i.question_version_id
			JOIN {$q} q ON q.id = v.question_id
			WHERE a.course_id IN ({$in}) AND t.state IN " . self::SCORED_STATES . ' AND i.points > 0 AND COALESCE(r.final_score, r.auto_score) IS NOT NULL'
			. $wpdb->prepare( ' AND t.submitted_at BETWEEN %s AND %s', $f->from_dt(), $f->to_dt() ) . $user . $f->cohort_sql( 't.user_id' );
		return $wpdb->get_results( $sql, ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Attempts awaiting manual grading in the given courses: rows id, course_id, submitted_at. */
	public static function pending( array $course_ids ): ?array {
		global $wpdb;
		if ( ! self::attempts_available() ) {
			return null;
		}
		$at = Schema::table( 'attempts' );
		$as = Schema::table( 'assessments' );
		$in = self::in_list( $course_ids );
		return $wpdb->get_results( "SELECT t.id, a.course_id, t.user_id, t.submitted_at FROM {$at} t JOIN {$as} a ON a.id=t.assessment_id WHERE a.course_id IN ({$in}) AND t.state='submitted' ORDER BY t.submitted_at", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Assessment ids per course (published ones when a status column exists). */
	public static function assessment_ids( array $course_ids ): ?array {
		global $wpdb;
		if ( ! self::attempts_available() ) {
			return null;
		}
		$as     = Schema::table( 'assessments' );
		$in     = self::in_list( $course_ids );
		$status = self::has( 'assessments', array( 'status' ) ) ? " AND status='publish'" : '';
		return $wpdb->get_results( "SELECT id, course_id FROM {$as} WHERE course_id IN ({$in}){$status}", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Distinct assessments the user has attempted (any state). */
	public static function attempted_assessments( int $user_id ): ?array {
		global $wpdb;
		if ( ! self::attempts_available() ) {
			return null;
		}
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT assessment_id FROM ' . Schema::table( 'attempts' ) . ' WHERE user_id=%d', $user_id ) ) );
	}
}
