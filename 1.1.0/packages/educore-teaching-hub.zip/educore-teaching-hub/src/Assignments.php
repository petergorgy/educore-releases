<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Audit;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Assignments & homework: targets (class / group / student), submissions with server-side rules,
 * grading with rubric + partial credit, auditable grade changes and explicit release.
 *
 * Learner-facing status: assigned → in_progress (draft) → submitted | late → graded (released) | returned.
 */
final class Assignments {
	public const STATUSES = array( 'draft', 'published', 'closed' );

	private static function t( string $n ): string {
		return Schema::table( $n );
	}

	/** @return int|\WP_Error */
	public static function save( array $in, int $actor, int $id = 0 ) {
		global $wpdb;
		$title = sanitize_text_field( (string) ( $in['title'] ?? '' ) );
		if ( '' === $title ) {
			return new \WP_Error( 'ec_th_title', __( 'A title is required.', 'educore-teaching-hub' ) );
		}
		$max = round( (float) ( $in['max_score'] ?? 100 ), 2 );
		if ( $max <= 0 || $max > 10000 ) {
			return new \WP_Error( 'ec_th_max', __( 'Maximum score must be between 0 and 10000.', 'educore-teaching-hub' ) );
		}
		$opens = Plugin::local_to_utc( (string) ( $in['opens_at'] ?? '' ) );
		$due   = Plugin::local_to_utc( (string) ( $in['due_at'] ?? '' ) );
		if ( $opens && $due && $due <= $opens ) {
			return new \WP_Error( 'ec_th_dates', __( 'The deadline must be after the opening date.', 'educore-teaching-hub' ) );
		}
		$rubric = self::parse_rubric( (string) ( $in['rubric'] ?? '' ) );
		if ( $rubric && abs( array_sum( wp_list_pluck( $rubric, 'points' ) ) - $max ) > 0.001 ) {
			return new \WP_Error( 'ec_th_rubric', __( 'Rubric points must add up to the maximum score.', 'educore-teaching-hub' ) );
		}
		$status = in_array( $in['status'] ?? 'draft', self::STATUSES, true ) ? $in['status'] : 'draft';
		$row    = array(
			'class_id'       => absint( $in['class_id'] ?? 0 ),
			'course_id'      => absint( $in['course_id'] ?? 0 ),
			'lesson_id'      => absint( $in['lesson_id'] ?? 0 ),
			'title'          => mb_substr( $title, 0, 190 ),
			'instructions'   => wp_kses_post( (string) ( $in['instructions'] ?? '' ) ),
			'opens_at'       => $opens,
			'due_at'         => $due,
			'max_score'      => $max,
			'rubric'         => $rubric ? wp_json_encode( $rubric ) : null,
			'allow_resubmit' => empty( $in['allow_resubmit'] ) ? 0 : 1,
			'allow_late'     => isset( $in['allow_late'] ) && ! $in['allow_late'] ? 0 : 1,
			'allow_files'    => isset( $in['allow_files'] ) && ! $in['allow_files'] ? 0 : 1,
			'status'         => $status,
			'updated_at'     => Schema::now(),
		);
		if ( $row['class_id'] && ! $row['course_id'] ) {
			$class            = Classes::get( $row['class_id'] );
			$row['course_id'] = $class ? (int) $class['course_id'] : 0;
		}
		if ( $id ) {
			$wpdb->update( self::t( 'th_assignments' ), $row, array( 'id' => $id ) );
		} else {
			$row['created_by'] = $actor;
			$row['created_at'] = $row['updated_at'];
			$wpdb->insert( self::t( 'th_assignments' ), $row );
			$id = (int) $wpdb->insert_id;
		}
		$targets = isset( $in['targets'] ) && is_array( $in['targets'] ) ? $in['targets'] : ( $row['class_id'] ? array( array( 'class', $row['class_id'] ) ) : array() );
		self::set_targets( $id, $targets );
		Audit::log( 'assignment.saved', 'assignment', $id, array( 'status' => $status ) );
		if ( 'published' === $status ) {
			do_action( 'educore/th/assignment_published', $id );
		}
		return $id;
	}

	/** "Criterion | points" per line → [{label, points}]. */
	public static function parse_rubric( string $text ): array {
		$out = array();
		foreach ( preg_split( '/\R/', $text ) as $line ) {
			if ( preg_match( '/^\s*(.+?)\s*\|\s*([0-9]+(?:\.[0-9]+)?)\s*$/u', $line, $m ) ) {
				$out[] = array( 'label' => mb_substr( sanitize_text_field( $m[1] ), 0, 120 ), 'points' => (float) $m[2] );
			}
		}
		return $out;
	}

	/** @param array<int,array{0:string,1:int}> $targets */
	public static function set_targets( int $id, array $targets ): void {
		global $wpdb;
		$wpdb->delete( self::t( 'th_assignment_targets' ), array( 'assignment_id' => $id ) );
		foreach ( $targets as $t ) {
			$type = (string) ( $t[0] ?? '' );
			$tid  = (int) ( $t[1] ?? 0 );
			if ( in_array( $type, array( 'class', 'group', 'student' ), true ) && $tid ) {
				$wpdb->query( $wpdb->prepare( 'INSERT IGNORE INTO ' . self::t( 'th_assignment_targets' ) . ' (assignment_id,target_type,target_id) VALUES (%d,%s,%d)', $id, $type, $tid ) );
			}
		}
	}

	public static function get( int $id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_assignments' ) . ' WHERE id=%d', $id ), ARRAY_A ) ?: null;
	}

	public static function rubric( array $a ): array {
		return $a['rubric'] ? (array) json_decode( $a['rubric'], true ) : array();
	}

	/** @return array<int,array<string,mixed>> */
	public static function for_classes( array $class_ids, string $status = '' ): array {
		global $wpdb;
		$class_ids = array_filter( array_map( 'intval', $class_ids ) );
		if ( ! $class_ids ) {
			return array();
		}
		$where = 'class_id IN (' . implode( ',', $class_ids ) . ')' . ( $status ? $wpdb->prepare( ' AND status=%s', $status ) : '' );
		return $wpdb->get_results( 'SELECT * FROM ' . self::t( 'th_assignments' ) . " WHERE {$where} ORDER BY COALESCE(due_at,'9999-12-31') ASC, id DESC LIMIT 500", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Is the student a target of the assignment (class member / group member / named)? */
	public static function is_target( array $a, int $student_id ): bool {
		global $wpdb;
		$tt   = self::t( 'th_assignment_targets' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT target_type, target_id FROM {$tt} WHERE assignment_id=%d", (int) $a['id'] ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $rows as $r ) {
			$tid = (int) $r['target_id'];
			if ( ( 'student' === $r['target_type'] && $tid === $student_id )
				|| ( 'class' === $r['target_type'] && Classes::is_member( $tid, $student_id ) )
				|| ( 'group' === $r['target_type'] && in_array( $student_id, Classes::group_members( $tid ), true ) ) ) {
				return true;
			}
		}
		return false;
	}

	/** Published, open assignments addressed to a student (one query per target type). @return array<int,array<string,mixed>> */
	public static function for_student( int $student_id ): array {
		global $wpdb;
		$classes = Classes::of_student( $student_id );
		$groups  = Classes::groups_of_student( $student_id );
		$or      = array( $wpdb->prepare( "(t.target_type='student' AND t.target_id=%d)", $student_id ) );
		if ( $classes ) {
			$or[] = "(t.target_type='class' AND t.target_id IN (" . implode( ',', $classes ) . '))';
		}
		if ( $groups ) {
			$or[] = "(t.target_type='group' AND t.target_id IN (" . implode( ',', $groups ) . '))';
		}
		$a   = self::t( 'th_assignments' );
		$t   = self::t( 'th_assignment_targets' );
		$s   = self::t( 'th_submissions' );
		$sql = "SELECT DISTINCT a.*, sub.status sub_status, sub.score, sub.released, sub.submitted_at, sub.is_late FROM {$a} a JOIN {$t} t ON t.assignment_id=a.id LEFT JOIN {$s} sub ON sub.assignment_id=a.id AND sub.student_id=%d WHERE a.status IN ('published','closed') AND (a.opens_at IS NULL OR a.opens_at<=%s) AND (" . implode( ' OR ', $or ) . ") ORDER BY COALESCE(a.due_at,'9999-12-31') ASC LIMIT 200";
		return $wpdb->get_results( $wpdb->prepare( $sql, $student_id, Schema::now() ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function submission( int $assignment_id, int $student_id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_submissions' ) . ' WHERE assignment_id=%d AND student_id=%d', $assignment_id, $student_id ), ARRAY_A ) ?: null;
	}

	public static function submission_by_id( int $id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_submissions' ) . ' WHERE id=%d', $id ), ARRAY_A ) ?: null;
	}

	/** Learner status label key. */
	public static function learner_status( array $a, ?array $sub ): string {
		if ( $sub && 'returned' === $sub['status'] ) {
			return 'returned';
		}
		if ( $sub && 'graded' === $sub['status'] && (int) $sub['released'] ) {
			return 'graded';
		}
		if ( $sub && in_array( $sub['status'], array( 'submitted', 'graded' ), true ) ) {
			return (int) $sub['is_late'] ? 'late' : 'submitted';
		}
		if ( $sub && 'draft' === $sub['status'] ) {
			return 'in_progress';
		}
		return ( $a['due_at'] && $a['due_at'] < Schema::now() ) ? 'missing' : 'not_started';
	}

	/**
	 * Save a draft or submit. All rules are enforced here (server side).
	 *
	 * @param array<int,array{key:string,name:string,size:int}> $new_files already validated + stored
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function submit( int $assignment_id, int $student_id, string $answer, array $new_files, bool $final ) {
		global $wpdb;
		$a = self::get( $assignment_id );
		if ( ! $a || 'published' !== $a['status'] ) {
			return new \WP_Error( 'ec_th_closed', __( 'This assignment is not open for submissions.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		if ( ! self::is_target( $a, $student_id ) ) {
			return new \WP_Error( 'ec_th_forbidden', __( 'This assignment was not given to you.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		$now = Schema::now();
		if ( $a['opens_at'] && $a['opens_at'] > $now ) {
			return new \WP_Error( 'ec_th_not_open', __( 'This assignment has not opened yet.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		$late = $a['due_at'] && $now > $a['due_at'];
		if ( $late && ! (int) $a['allow_late'] && $final ) {
			return new \WP_Error( 'ec_th_deadline', __( 'The deadline has passed and late submissions are not accepted.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		if ( $new_files && ! (int) $a['allow_files'] ) {
			return new \WP_Error( 'ec_th_nofiles', __( 'This assignment does not accept files.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		$sub = self::submission( $assignment_id, $student_id );
		if ( $sub && in_array( $sub['status'], array( 'submitted', 'graded' ), true ) && ! ( 'graded' !== $sub['status'] && (int) $a['allow_resubmit'] ) ) {
			return new \WP_Error( 'ec_th_locked', __( 'You have already submitted this assignment.', 'educore-teaching-hub' ), array( 'status' => 409 ) );
		}
		$files = $sub && $sub['files'] ? (array) json_decode( $sub['files'], true ) : array();
		$files = array_merge( $files, $new_files );
		if ( count( $files ) > (int) Settings::get( 'max_files' ) ) {
			foreach ( $new_files as $f ) {
				Files::delete( $f['key'] );
			}
			/* translators: %d: number of files */
			return new \WP_Error( 'ec_th_toomany', sprintf( __( 'You can attach at most %d files.', 'educore-teaching-hub' ), (int) Settings::get( 'max_files' ) ), array( 'status' => 400 ) );
		}
		$answer = wp_kses_post( $answer );
		if ( $final && '' === trim( wp_strip_all_tags( $answer ) ) && ! $files ) {
			return new \WP_Error( 'ec_th_empty', __( 'Write an answer or attach a file before submitting.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		$row = array(
			'status'     => $final ? 'submitted' : 'draft',
			'answer'     => $answer,
			'files'      => wp_json_encode( array_values( $files ) ),
			'updated_at' => $now,
		);
		if ( $final ) {
			$row['submitted_at'] = $now;
			$row['is_late']      = $late ? 1 : 0;
			$row['attempts']     = ( $sub ? (int) $sub['attempts'] : 0 ) + 1;
			$row['released']     = 0;
		}
		if ( $sub ) {
			$wpdb->update( self::t( 'th_submissions' ), $row, array( 'id' => (int) $sub['id'] ) );
			$sid = (int) $sub['id'];
		} else {
			$row['assignment_id'] = $assignment_id;
			$row['student_id']    = $student_id;
			$wpdb->insert( self::t( 'th_submissions' ), $row );
			$sid = (int) $wpdb->insert_id;
		}
		if ( $final ) {
			Audit::log( 'assignment.submitted', 'submission', $sid, array( 'assignment_id' => $assignment_id, 'late' => $late ) );
			do_action( 'educore/th/submitted', $sid, $assignment_id, $student_id );
		}
		return self::submission_by_id( $sid );
	}

	/**
	 * Grade (or re-grade) a submission. Rubric scores, when present, determine the total.
	 *
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function grade( int $submission_id, ?float $score, string $feedback, array $rubric_scores, int $actor, string $action = 'grade' ) {
		global $wpdb;
		$sub = self::submission_by_id( $submission_id );
		if ( ! $sub ) {
			return new \WP_Error( 'ec_th_404', __( 'Submission not found.', 'educore-teaching-hub' ), array( 'status' => 404 ) );
		}
		if ( ! Caps::can_grade_assignment( $actor, (int) $sub['assignment_id'] ) ) {
			return new \WP_Error( 'ec_th_forbidden', __( 'You cannot grade this assignment.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		if ( ! in_array( $sub['status'], array( 'submitted', 'graded', 'returned' ), true ) ) {
			return new \WP_Error( 'ec_th_state', __( 'Only submitted work can be graded.', 'educore-teaching-hub' ), array( 'status' => 409 ) );
		}
		$a      = self::get( (int) $sub['assignment_id'] );
		$rubric = self::rubric( $a );
		$clean  = array();
		if ( $rubric ) {
			foreach ( $rubric as $i => $c ) {
				$v = isset( $rubric_scores[ $i ] ) ? (float) $rubric_scores[ $i ] : 0.0;
				if ( $v < 0 || $v > (float) $c['points'] ) {
					return new \WP_Error( 'ec_th_rubric_range', __( 'Each rubric score must be between 0 and the criterion maximum.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
				}
				$clean[ $i ] = round( $v, 2 );
			}
			$score = array_sum( $clean );
		}
		if ( 'return' !== $action && ( null === $score || $score < 0 || $score > (float) $a['max_score'] ) ) {
			/* translators: %s: maximum score */
			return new \WP_Error( 'ec_th_range', sprintf( __( 'The score must be between 0 and %s.', 'educore-teaching-hub' ), $a['max_score'] ), array( 'status' => 400 ) );
		}
		$old = null === $sub['score'] ? null : (float) $sub['score'];
		$row = array(
			'feedback'      => wp_kses_post( $feedback ),
			'graded_by'     => $actor,
			'graded_at'     => Schema::now(),
			'rubric_scores' => $clean ? wp_json_encode( $clean ) : null,
			'updated_at'    => Schema::now(),
		);
		if ( 'return' === $action ) {
			$row['status']   = 'returned';
			$row['released'] = 1;
		} else {
			$row['status'] = 'graded';
			$row['score']  = round( (float) $score, 2 );
		}
		$wpdb->update( self::t( 'th_submissions' ), $row, array( 'id' => $submission_id ) );
		$wpdb->insert(
			self::t( 'th_grade_log' ),
			array( 'submission_id' => $submission_id, 'actor_id' => $actor, 'action' => null === $old ? $action : ( 'return' === $action ? 'return' : 'regrade' ), 'old_score' => $old, 'new_score' => 'return' === $action ? $old : round( (float) $score, 2 ), 'comment' => mb_substr( wp_strip_all_tags( $feedback ), 0, 500 ), 'created_at' => Schema::now() )
		);
		Audit::log( 'assignment.' . ( 'return' === $action ? 'returned' : ( null === $old ? 'graded' : 'regraded' ) ), 'submission', $submission_id, array( 'old' => $old, 'new' => $row['score'] ?? $old ) );
		if ( 'return' === $action ) {
			do_action( 'educore/th/returned', $submission_id );
		}
		return self::submission_by_id( $submission_id );
	}

	/** Release graded results (one submission or the whole assignment). Returns number released. */
	public static function release( int $assignment_id, int $actor, int $submission_id = 0 ): int {
		global $wpdb;
		if ( ! Caps::can_grade_assignment( $actor, $assignment_id ) ) {
			return 0;
		}
		$where = $wpdb->prepare( "assignment_id=%d AND status='graded' AND released=0", $assignment_id ) . ( $submission_id ? $wpdb->prepare( ' AND id=%d', $submission_id ) : '' );
		$ids   = array_map( 'intval', $wpdb->get_col( 'SELECT id FROM ' . self::t( 'th_submissions' ) . " WHERE {$where}" ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $ids as $id ) {
			$wpdb->update( self::t( 'th_submissions' ), array( 'released' => 1, 'released_at' => Schema::now() ), array( 'id' => $id ) );
			$wpdb->insert( self::t( 'th_grade_log' ), array( 'submission_id' => $id, 'actor_id' => $actor, 'action' => 'release', 'created_at' => Schema::now() ) );
			do_action( 'educore/th/released', $id );
		}
		if ( $ids ) {
			Audit::log( 'assignment.released', 'assignment', $assignment_id, array( 'count' => count( $ids ) ) );
		}
		return count( $ids );
	}

	/** Submissions of an assignment, including target students without a submission. @return array<int,array<string,mixed>> */
	public static function roster( int $assignment_id ): array {
		global $wpdb;
		$a = self::get( $assignment_id );
		if ( ! $a ) {
			return array();
		}
		$students = array();
		$targets  = $wpdb->get_results( $wpdb->prepare( 'SELECT target_type, target_id FROM ' . self::t( 'th_assignment_targets' ) . ' WHERE assignment_id=%d', $assignment_id ), ARRAY_A ) ?: array();
		foreach ( $targets as $t ) {
			$tid = (int) $t['target_id'];
			$ids = 'class' === $t['target_type'] ? Classes::members( $tid ) : ( 'group' === $t['target_type'] ? Classes::group_members( $tid ) : array( $tid ) );
			foreach ( $ids as $sid ) {
				$students[ $sid ] = true;
			}
		}
		$subs = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_submissions' ) . ' WHERE assignment_id=%d', $assignment_id ), ARRAY_A ) ?: array() as $s ) {
			$subs[ (int) $s['student_id'] ] = $s;
			$students[ (int) $s['student_id'] ] = true;
		}
		$out = array();
		cache_users( array_keys( $students ) );
		foreach ( array_keys( $students ) as $sid ) {
			$out[] = array( 'student_id' => $sid, 'name' => ( get_userdata( $sid ) ?: new \WP_User() )->display_name, 'submission' => $subs[ $sid ] ?? null, 'status' => self::learner_status( $a, $subs[ $sid ] ?? null ) );
		}
		usort( $out, static fn( $x, $y ) => strcmp( $x['name'], $y['name'] ) );
		return $out;
	}

	/** Ungraded submissions the user may grade. @return array<int,array<string,mixed>> */
	public static function grading_queue( int $user_id, int $limit = 200 ): array {
		global $wpdb;
		$a = self::t( 'th_assignments' );
		$s = self::t( 'th_submissions' );
		if ( Caps::is_manager( $user_id ) ) {
			$scope = '1=1';
		} else {
			$classes = Caps::classes_of( $user_id );
			$courses = array_values( array_filter( \EduCore\Core\Staff::courses_of( $user_id ), static fn( $c ) => user_can( $user_id, 'ec_grade_course', $c ) ) );
			$parts   = array();
			if ( $classes ) {
				$parts[] = 'a.class_id IN (' . implode( ',', $classes ) . ')';
			}
			if ( $courses ) {
				$parts[] = '(a.class_id=0 AND a.course_id IN (' . implode( ',', array_map( 'intval', $courses ) ) . '))';
			}
			if ( ! $parts ) {
				return array();
			}
			$scope = '(' . implode( ' OR ', $parts ) . ')';
		}
		return $wpdb->get_results( $wpdb->prepare( "SELECT s.id submission_id, s.student_id, s.submitted_at, s.is_late, s.attempts, a.id assignment_id, a.title, a.class_id, a.course_id, a.max_score FROM {$s} s JOIN {$a} a ON a.id=s.assignment_id WHERE s.status='submitted' AND {$scope} ORDER BY s.submitted_at ASC LIMIT %d", $limit ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** @return array<int,array<string,mixed>> */
	public static function grade_log( int $submission_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_grade_log' ) . ' WHERE submission_id=%d ORDER BY id ASC', $submission_id ), ARRAY_A ) ?: array();
	}

	/** Can the user read this submission (student owner, guardian rules elsewhere, graders)? */
	public static function can_view_submission( int $user_id, array $sub ): bool {
		return $user_id > 0 && ( (int) $sub['student_id'] === $user_id || Caps::can_grade_assignment( $user_id, (int) $sub['assignment_id'] ) );
	}
}
