/* EduCore assessment player + quick practice. The server is authoritative for time, attempts and grading. */
(function () {
	'use strict';
	var api = window.EduCoreApi, toast = window.EduCoreToast || function () {}, celebrate = window.EduCoreCelebrate || function () {};
	var T = (window.EduCoreAssess && window.EduCoreAssess.i18n) || {};
	if (!api) { return; }
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	function fmt(s) { var a = Array.prototype.slice.call(arguments, 1), i = 0; return String(s).replace(/%%|%(\d+\$)?[sd]/g, function (m, pos) { if (m === '%%') { return '%'; } return pos ? a[parseInt(pos, 10) - 1] : a[i++]; }); }
	function el(tag, attrs, html) {
		var e = document.createElement(tag);
		Object.keys(attrs || {}).forEach(function (k) { if (attrs[k] !== null && attrs[k] !== undefined) { e.setAttribute(k, attrs[k]); } });
		if (html !== undefined) { e.innerHTML = html; }
		return e;
	}
	function text(tag, attrs, t) { var e = el(tag, attrs); e.textContent = t; return e; }
	function uid(p) { return p + Math.random().toString(36).slice(2, 9); }

	/* ---------- question rendering ---------- */
	function renderQuestion(item, idx, total, ns) {
		var fs = el('fieldset', { 'class': 'ec-q ec-q--' + item.type, 'data-item': item.id, 'data-type': item.type });
		var legend = el('legend', { 'class': 'ec-q__legend' });
		legend.appendChild(text('span', { 'class': 'ec-q__num' }, total ? fmt(T.question, idx + 1, total) : ''));
		if (item.points !== undefined) { legend.appendChild(text('span', { 'class': 'ec-chip' }, fmt(T.points, item.points))); }
		fs.appendChild(legend);
		var stemHtml = item.stem || '';
		var name = ns + item.id;
		var v = item.view || {}, ans = item.answer;
		if (item.type === 'fill_blanks') {
			stemHtml = stemHtml.replace(/\[\[(\d+)\]\]/g, function (m, n) {
				return '<input type="text" class="ec-blank" data-blank="' + (parseInt(n, 10) - 1) + '" aria-label="' + fmt(T.blank, n) + '" autocomplete="off">';
			});
		}
		fs.appendChild(el('div', { 'class': 'ec-q__stem' }, stemHtml));
		var body = el('div', { 'class': 'ec-q__body' });
		if (item.type === 'image' && v.image) { body.appendChild(el('img', { src: v.image, alt: v.alt || '', 'class': 'ec-q__img', loading: 'lazy' })); }
		if (item.type === 'single' || item.type === 'image' || item.type === 'multiple') {
			(v.options || []).forEach(function (o) {
				var id = uid('o');
				var lab = el('label', { 'class': 'ec-opt', 'for': id });
				var inp = el('input', { type: item.type === 'multiple' ? 'checkbox' : 'radio', name: name, value: o.id, id: id });
				if (ans !== null && ans !== undefined && (item.type === 'multiple' ? (ans || []).indexOf(o.id) > -1 : ans === o.id)) { inp.checked = true; }
				lab.appendChild(inp); lab.appendChild(el('span', {}, o.text)); body.appendChild(lab);
			});
		} else if (item.type === 'truefalse') {
			[['true', T['true']], ['false', T['false']]].forEach(function (p) {
				var id = uid('o'); var lab = el('label', { 'class': 'ec-opt', 'for': id });
				var inp = el('input', { type: 'radio', name: name, value: p[0], id: id });
				if (ans === (p[0] === 'true')) { inp.checked = true; }
				lab.appendChild(inp); lab.appendChild(text('span', {}, p[1])); body.appendChild(lab);
			});
		} else if (item.type === 'short') {
			var s = el('input', { type: 'text', 'class': 'ec-input', name: name, 'aria-label': T.yourAnswer, autocomplete: 'off' }); s.value = ans || ''; body.appendChild(s);
		} else if (item.type === 'essay' || item.type === 'code') {
			if (item.type === 'code') {
				var pre = el('pre', { 'class': 'ec-code', dir: 'ltr', tabindex: '0' }); pre.textContent = v.code || ''; body.appendChild(pre);
				body.appendChild(text('p', { 'class': 'ec-muted' }, T.output));
			}
			var ta = el('textarea', { 'class': 'ec-input', name: name, rows: item.type === 'essay' ? 8 : 3, 'aria-label': T.yourAnswer, dir: item.type === 'code' ? 'ltr' : 'auto' }); ta.value = ans || '';
			body.appendChild(ta);
			if (item.type === 'essay') {
				var wc = el('p', { 'class': 'ec-muted ec-wc', 'aria-live': 'off' });
				var upd = function () { var n = ta.value.trim() ? ta.value.trim().split(/\s+/).length : 0; wc.textContent = fmt(T.words, n); };
				ta.addEventListener('input', upd); upd(); body.appendChild(wc);
			}
		} else if (item.type === 'matching') {
			(v.left || []).forEach(function (l) {
				var id = uid('m'); var row = el('div', { 'class': 'ec-match' });
				row.appendChild(el('label', { 'for': id }, l.text));
				var sel = el('select', { id: id, 'data-left': l.id });
				sel.appendChild(text('option', { value: '' }, T.choose));
				(v.right || []).forEach(function (r) { var o = el('option', { value: r.id }, r.text); if (ans && ans[l.id] === r.id) { o.selected = true; } sel.appendChild(o); });
				row.appendChild(sel); body.appendChild(row);
			});
		} else if (item.type === 'ordering') {
			var ol = el('ol', { 'class': 'ec-order' });
			var items = v.items || [];
			if (Array.isArray(ans) && ans.length) { var by = {}; items.forEach(function (i) { by[i.id] = i; }); items = ans.map(function (id) { return by[id]; }).filter(Boolean); }
			items.forEach(function (it) {
				var li = el('li', { 'data-id': it.id });
				li.appendChild(el('span', { 'class': 'ec-order__text' }, it.text));
				var up = text('button', { type: 'button', 'class': 'ec-btn ec-btn--sm', 'data-move': 'up' }, '↑'); up.setAttribute('aria-label', T.up);
				var dn = text('button', { type: 'button', 'class': 'ec-btn ec-btn--sm', 'data-move': 'down' }, '↓'); dn.setAttribute('aria-label', T.down);
				li.appendChild(up); li.appendChild(dn); ol.appendChild(li);
			});
			ol.addEventListener('click', function (e) {
				var b = e.target.closest('[data-move]'); if (!b) { return; }
				var li = b.closest('li');
				if (b.getAttribute('data-move') === 'up' && li.previousElementSibling) { ol.insertBefore(li, li.previousElementSibling); }
				else if (b.getAttribute('data-move') === 'down' && li.nextElementSibling) { ol.insertBefore(li.nextElementSibling, li); }
				b.focus(); fs.dispatchEvent(new Event('change', { bubbles: true }));
			});
			body.appendChild(ol);
		}
		if (item.type === 'fill_blanks' && Array.isArray(ans)) {
			fs.querySelectorAll('[data-blank]').forEach(function (b) { b.value = ans[parseInt(b.getAttribute('data-blank'), 10)] || ''; });
		}
		fs.appendChild(body);
		return fs;
	}

	function collect(fs) {
		var type = fs.getAttribute('data-type');
		switch (type) {
			case 'single': case 'image': case 'truefalse':
				var c = fs.querySelector('input:checked'); if (!c) { return null; }
				return type === 'truefalse' ? c.value === 'true' : c.value;
			case 'multiple':
				return Array.prototype.map.call(fs.querySelectorAll('input:checked'), function (i) { return i.value; });
			case 'short': case 'essay': case 'code':
				return fs.querySelector('.ec-input').value;
			case 'fill_blanks':
				var out = []; fs.querySelectorAll('[data-blank]').forEach(function (b) { out[parseInt(b.getAttribute('data-blank'), 10)] = b.value; });
				for (var i = 0; i < out.length; i++) { if (out[i] === undefined) { out[i] = ''; } }
				return out;
			case 'matching':
				var m = {}; fs.querySelectorAll('select[data-left]').forEach(function (s) { if (s.value) { m[s.getAttribute('data-left')] = s.value; } }); return m;
			case 'ordering':
				return Array.prototype.map.call(fs.querySelectorAll('.ec-order li'), function (li) { return li.getAttribute('data-id'); });
		}
		return null;
	}
	function isEmpty(v) { return v === null || v === '' || (Array.isArray(v) && !v.filter(function (x) { return x; }).length) || (typeof v === 'object' && !Array.isArray(v) && v !== null && !Object.keys(v).length); }

	function keyText(item) {
		if (item.correct !== undefined && item.correct !== '') { return String(item.correct); }
		var k = item.key || {};
		if (k.model_answer) { return k.model_answer; }
		return '';
	}

	/* ---------- attempt player ---------- */
	function Player(root) {
		this.root = root; this.player = root.querySelector('[data-ec-player]');
		this.id = root.getAttribute('data-ec-assessment'); this.dirty = false; this.timer = null; this.saveTimer = null;
	}
	Player.prototype.start = function (btn) {
		var self = this; if (btn) { btn.disabled = true; }
		this.player.innerHTML = '<div class="ec-skeleton" style="height:6rem"></div>';
		api('assessments/' + this.id + '/attempts', { method: 'POST' }).then(function (a) { if (btn) { btn.hidden = true; } self.render(a); })
			.catch(function (e) { if (btn) { btn.disabled = false; } self.player.innerHTML = ''; toast(e.message, 'error'); });
	};
	Player.prototype.review = function (attemptId) {
		var self = this;
		api('attempts/' + attemptId).then(function (a) { self.result(a); }).catch(function (e) { toast(e.message, 'error'); });
	};
	Player.prototype.render = function (a) {
		var self = this; this.attempt = a;
		if (a.state !== 'open') { return this.result(a); }
		var form = el('form', { 'class': 'ec-attempt', novalidate: 'novalidate' });
		var bar = el('div', { 'class': 'ec-attempt__bar' });
		this.status = el('span', { 'class': 'ec-muted ec-attempt__status', role: 'status' });
		bar.appendChild(this.status);
		if (a.seconds_left !== null && a.seconds_left !== undefined) {
			this.clock = el('span', { 'class': 'ec-timer', 'aria-hidden': 'true' });
			this.live = el('span', { 'class': 'screen-reader-text', 'aria-live': 'assertive' });
			var lbl = text('span', { 'class': 'screen-reader-text' }, T.timeLeft);
			bar.insertBefore(this.clock, bar.firstChild); bar.appendChild(lbl); bar.appendChild(this.live);
			this.deadline = Date.now() + a.seconds_left * 1000; this.tick();
			this.timer = setInterval(function () { self.tick(); }, 1000);
		}
		form.appendChild(bar);
		a.items.forEach(function (it, i) { form.appendChild(renderQuestion(it, i, a.items.length, 'ec' + a.id + '_')); });
		var submit = text('button', { type: 'submit', 'class': 'ec-btn ec-btn--primary' }, T.submit);
		form.appendChild(el('p', { 'class': 'ec-actions' })).appendChild(submit);
		form.addEventListener('change', function () { self.markDirty(); });
		form.addEventListener('input', function () { self.markDirty(); });
		form.addEventListener('submit', function (e) { e.preventDefault(); self.submit(false); });
		this.form = form; this.player.innerHTML = ''; this.player.appendChild(form);
		this.saveTimer = setInterval(function () { if (self.dirty) { self.save(); } }, 15000);
		window.addEventListener('beforeunload', function (e) { if (self.dirty) { self.save(); e.preventDefault(); } });
		var first = form.querySelector('input,select,textarea,button'); if (first) { first.focus({ preventScroll: true }); }
	};
	Player.prototype.tick = function () {
		var left = Math.max(0, Math.round((this.deadline - Date.now()) / 1000));
		var m = Math.floor(left / 60), s = left % 60;
		this.clock.textContent = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
		this.clock.classList.toggle('is-low', left <= 300);
		if (left === 300) { this.live.textContent = T.fiveMin; }
		if (left === 60) { this.live.textContent = T.oneMin; }
		if (left === 0 && !this.ended) { this.ended = true; this.live.textContent = T.timeUp; this.submit(true); }
	};
	Player.prototype.answers = function () {
		var out = {};
		this.form.querySelectorAll('fieldset[data-item]').forEach(function (fs) { out[fs.getAttribute('data-item')] = collect(fs); });
		return out;
	};
	Player.prototype.markDirty = function () {
		var self = this; this.dirty = true; this.status.textContent = T.saving;
		clearTimeout(this.debounce); this.debounce = setTimeout(function () { self.save(); }, 1500);
	};
	Player.prototype.save = function () {
		var self = this; if (!this.form || this.ended) { return Promise.resolve(); }
		this.dirty = false;
		return api('attempts/' + this.attempt.id + '/answers', { method: 'POST', body: { answers: this.answers() } })
			.then(function (r) { self.status.textContent = T.saved; if (r.seconds_left !== null && r.seconds_left !== undefined && self.clock) { self.deadline = Date.now() + r.seconds_left * 1000; } })
			.catch(function (e) {
				if (e.data && e.data.code === 'educore_time_up') { self.ended = true; return self.review(self.attempt.id); }
				self.dirty = true; self.status.textContent = T.offline;
			});
	};
	Player.prototype.submit = function (auto) {
		var self = this, answers = this.answers();
		if (!auto) {
			var empty = Object.keys(answers).filter(function (k) { return isEmpty(answers[k]); }).length;
			if (!window.confirm((empty ? fmt(T.unanswered, empty) + '\n' : '') + T.confirm)) { return; }
		}
		this.ended = true; clearInterval(this.timer); clearInterval(this.saveTimer); this.dirty = false;
		api('attempts/' + this.attempt.id + '/submit', { method: 'POST', body: { answers: answers } })
			.then(function (a) { self.result(a); })
			.catch(function (e) { self.ended = false; toast(e.message, 'error'); });
	};
	Player.prototype.result = function (a) {
		clearInterval(this.timer); clearInterval(this.saveTimer);
		var box = el('div', { 'class': 'ec-result', tabindex: '-1' });
		box.appendChild(text('p', { 'class': 'ec-result__title' }, T.submitted));
		if (a.released && a.result) {
			var r = a.result;
			box.appendChild(text('p', { 'class': 'ec-result__score' }, fmt(T.score, r.mark, r.mark_of, r.percent)));
			box.appendChild(text('p', { 'class': 'ec-result__verdict ' + (r.passed ? 'is-pass' : 'is-fail') }, r.passed ? T.passed : T.notPassed));
			if (r.passed) { celebrate(box); }
			var list = el('ol', { 'class': 'ec-review' });
			a.items.forEach(function (it) {
				var li = el('li', { 'class': 'ec-review__item' });
				li.appendChild(el('div', { 'class': 'ec-q__stem' }, it.stem));
				if (it.score !== undefined && it.score !== null) { li.appendChild(text('p', { 'class': 'ec-chip' }, it.score + ' / ' + it.points)); }
				if (it.feedback) { li.appendChild(text('p', { 'class': 'ec-feedback' }, T.feedback + ': ' + it.feedback)); }
				if (it.rubric && it.rubric.length) {
					var rl = el('ul', { 'class': 'ec-rubric-review', 'aria-label': T.criteria || 'Marking criteria' });
					it.rubric.forEach(function (c) { rl.appendChild(text('li', {}, c.label + ': ' + (c.score === null ? '–' : c.score) + ' / ' + c.points)); });
					li.appendChild(rl);
				}
				if (a.review) {
					var k = keyText(it); if (k) { li.appendChild(el('p', { 'class': 'ec-key' }, '<strong></strong> ')); li.lastChild.firstChild.textContent = T.answer + ': '; li.lastChild.appendChild(document.createTextNode(k)); }
					if (it.explanation) { li.appendChild(el('div', { 'class': 'ec-explain' }, it.explanation)); }
				}
				list.appendChild(li);
			});
			box.appendChild(list);
		} else {
			box.appendChild(text('p', { 'class': 'ec-muted' }, T.awaiting));
		}
		this.player.innerHTML = ''; this.player.appendChild(box); box.focus({ preventScroll: reduce });
		if (!reduce) { box.classList.add('is-in'); }
	};

	document.addEventListener('click', function (e) {
		var s = e.target.closest('[data-ec-start]');
		if (s) { new Player(s.closest('[data-ec-assessment]')).start(s); return; }
		var rv = e.target.closest('[data-ec-review]');
		if (rv) { new Player(rv.closest('[data-ec-assessment]')).review(rv.getAttribute('data-ec-review')); }
	});

	/* ---------- quick practice ---------- */
	function showReveal(card, rev, type) {
		var old = card.querySelector('.ec-reveal-box'); if (old) { old.remove(); }
		var box = el('div', { 'class': 'ec-reveal-box' });
		var k = rev.model_answer || rev.correct;
		if (k) { var p = el('p'); p.appendChild(text('strong', {}, (type === 'essay' ? T.modelAnswer : T.answer) + ': ')); p.appendChild(document.createTextNode(k)); box.appendChild(p); }
		if (rev.explanation) { box.appendChild(el('div', { 'class': 'ec-explain' }, rev.explanation)); }
		card.appendChild(box);
	}
	document.querySelectorAll('[data-ec-practice]').forEach(function (root) {
		var items = [];
		try { items = JSON.parse(root.getAttribute('data-ec-practice')) || []; } catch (err) { items = []; }
		items.forEach(function (it) {
			var card = el('div', { 'class': 'ec-practice__item' });
			var fs = renderQuestion({ id: it.id, type: it.type, stem: it.stem, view: it.view, answer: null }, 0, 0, 'p');
			card.appendChild(fs);
			var fb = el('p', { 'class': 'ec-practice__fb', 'aria-live': 'polite' });
			var btn = text('button', { type: 'button', 'class': 'ec-btn' }, T.check);
			var left = text('span', { 'class': 'ec-muted' }, fmt(T.triesLeft, it.tries_left));
			var row = el('p', { 'class': 'ec-actions' }); row.appendChild(btn); row.appendChild(left);
			card.appendChild(row); card.appendChild(fb);
			if (it.solved || !it.tries_left) { btn.disabled = true; }
			if (it.reveal) { showReveal(card, it.reveal, it.type); }
			btn.addEventListener('click', function () {
				var ans = collect(fs); if (isEmpty(ans)) { fs.querySelector('input,textarea,select') && fs.querySelector('input,textarea,select').focus(); return; }
				btn.disabled = true;
				api('practice/' + it.id, { method: 'POST', body: { answer: ans } }).then(function (r) {
					fb.className = 'ec-practice__fb ' + (r.correct ? 'is-correct' : (r.manual ? 'is-manual' : 'is-wrong'));
					fb.textContent = r.manual ? T.manualNote : (r.correct ? T.correct : (r.partial ? T.partial : T.incorrect));
					left.textContent = fmt(T.triesLeft, r.tries_left);
					if (r.correct) { celebrate(card); }
					if (!reduce) { fb.classList.add('is-anim'); }
					if (r.reveal) { showReveal(card, r.reveal, it.type); }
					btn.disabled = !!(r.correct || r.tries_left < 1 || r.reveal);
				}).catch(function (e2) { btn.disabled = false; toast(e2.message, 'error'); });
			});
			root.appendChild(card);
		});
	});
})();
