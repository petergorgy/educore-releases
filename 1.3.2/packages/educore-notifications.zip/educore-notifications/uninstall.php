<?php
/** Removes notification data only when the EduCore "delete all data" preference was confirmed. */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
if ( 'yes' !== get_option( 'educore_uninstall_delete_data' ) ) {
	return;
}
global $wpdb;
foreach ( array( 'notification_jobs', 'notification_prefs' ) as $t ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'ec_' . $t ); // phpcs:ignore WordPress.DB.PreparedSQL
}
foreach ( array( 'educore_notifications_db_version', 'educore_mail_from', 'educore_mail_from_name', 'educore_smtp_host', 'educore_smtp_port', 'educore_smtp_encryption', 'educore_smtp_user', 'educore_smtp_pass' ) as $o ) {
	delete_option( $o );
}
