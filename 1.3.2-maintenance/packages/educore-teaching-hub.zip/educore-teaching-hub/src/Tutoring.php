<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Audit;
use EduCore\Core\Privacy as CorePrivacy;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Private tutoring: profiles (admin-approved before public listing), weekly availability,
 * unavailable dates, conflict-free booking, session lifecycle and guardian authorisation for minors.
 *
 * Overlap prevention: every session holds one row per slot (slot_minutes grid) in th_slot_locks whose
 * PRIMARY KEY (tutor_id, slot_start) makes a double booking impossible. Locks are written with ONE
 * multi-row INSERT — InnoDB applies it atomically (all rows or none) — before a request exists.
 *
 * Lifecycle: requested → confirmed → completed | no_show; requested → declined; requested|confirmed → cancelled;
 * confirmed → (rescheduled) confirmed.
 */
final class Tutoring {
	public const PROFILE_STATUSES = array( 'draft', 'pending', 'approved', 'rejected', 'suspended' );
	public const ACTIVE           = array( 'requested', 'confirmed' );

	private static function t( string $n ): string {
		return Schema::table( $n );
	}

	public static function register(): void {
		add_action( 'template_redirect', array( self::class, 'guardian_endpoint' ), 5 );
	}

	/* ---------- Profiles ---------- */

	public static function profile( int $user_id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_tutor_profiles' ) . ' WHERE user_id=%d', $user_id ), ARRAY_A ) ?: null;
	}

	/** Tutor edits own profile. Material changes to an approved profile send it back to review. */
	public static function save_profile( int $user_id, array $in, bool $submit_for_review ): array {
		global $wpdb;
		$cur  = self::profile( $user_id );
		$row  = array(
			'headline'        => mb_substr( sanitize_text_field( (string) ( $in['headline'] ?? '' ) ), 0, 190 ),
			'bio'             => sanitize_textarea_field( (string) ( $in['bio'] ?? '' ) ),
			'subjects'        => mb_substr( sanitize_text_field( (string) ( $in['subjects'] ?? '' ) ), 0, 255 ),
			'languages'       => implode( ',', array_intersect( array_map( 'sanitize_key', (array) ( $in['languages'] ?? array() ) ), array( 'en', 'fr', 'ar' ) ) ),
			'experience'      => mb_substr( sanitize_text_field( (string) ( $in['experience'] ?? '' ) ), 0, 255 ),
			'qualifications'  => sanitize_textarea_field( (string) ( $in['qualifications'] ?? '' ) ),
			'formats'         => implode( ',', array_intersect( array_map( 'sanitize_key', (array) ( $in['formats'] ?? array( 'online' ) ) ), array( 'online', 'in_person' ) ) ) ?: 'online',
			'session_minutes' => max( 15, min( 240, absint( $in['session_minutes'] ?? 60 ) ) ),
			'notice_hours'    => max( 0, min( 336, absint( $in['notice_hours'] ?? 24 ) ) ),
			'capacity'        => max( 1, min( 20, absint( $in['capacity'] ?? 1 ) ) ),
			'is_public'       => empty( $in['is_public'] ) ? 0 : 1,
			'updated_at'      => Schema::now(),
		);
		$row['session_minutes'] = (int) ( ceil( $row['session_minutes'] / (int) Settings::get( 'slot_minutes' ) ) * (int) Settings::get( 'slot_minutes' ) );
		$material               = $cur && ( $cur['bio'] !== $row['bio'] || $cur['qualifications'] !== $row['qualifications'] || $cur['headline'] !== $row['headline'] || $cur['subjects'] !== $row['subjects'] );
		if ( ! $cur ) {
			$row['status'] = $submit_for_review ? 'pending' : 'draft';
		} elseif ( $submit_for_review || ( 'approved' === $cur['status'] && $material ) ) {
			$row['status'] = 'suspended' === $cur['status'] ? 'suspended' : 'pending';
		}
		if ( $cur ) {
			$wpdb->update( self::t( 'th_tutor_profiles' ), $row, array( 'user_id' => $user_id ) );
		} else {
			$row['user_id'] = $user_id;
			$wpdb->insert( self::t( 'th_tutor_profiles' ), $row );
		}
		Audit::log( 'tutor.profile_saved', 'user', $user_id, array( 'status' => $row['status'] ?? $cur['status'] ) );
		return self::profile( $user_id );
	}

	/** Admin review. */
	public static function review( int $user_id, string $decision, int $actor, string $note = '' ): bool {
		global $wpdb;
		if ( ! in_array( $decision, array( 'approved', 'rejected', 'suspended' ), true ) || ! self::profile( $user_id ) || ! user_can( $actor, 'ec_approve_tutors' ) ) {
			return false;
		}
		$wpdb->update( self::t( 'th_tutor_profiles' ), array( 'status' => $decision, 'reviewed_by' => $actor, 'reviewed_at' => Schema::now(), 'review_note' => mb_substr( sanitize_text_field( $note ), 0, 255 ) ), array( 'user_id' => $user_id ) );
		Audit::log( 'tutor.' . $decision, 'user', $user_id, array( 'note' => $note ) );
		do_action( 'educore/th/tutor_reviewed', $user_id, $decision );
		return true;
	}

	/** Approved tutors (public listing only when also is_public). @return array<int,array<string,mixed>> */
	public static function directory( bool $public_only = true ): array {
		global $wpdb;
		$where = "p.status='approved'" . ( $public_only ? ' AND p.is_public=1' : '' );
		$rows  = $wpdb->get_results( 'SELECT p.*, u.display_name FROM ' . self::t( 'th_tutor_profiles' ) . ' p JOIN ' . $wpdb->users . " u ON u.ID=p.user_id WHERE {$where} ORDER BY u.display_name LIMIT 200", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		return array_values( array_filter( $rows, static fn( $r ) => user_can( (int) $r['user_id'], 'ec_tutor_sessions' ) ) );
	}

	public static function bookable( int $tutor_id ): bool {
		$p = self::profile( $tutor_id );
		return $p && 'approved' === $p['status'] && user_can( $tutor_id, 'ec_tutor_sessions' );
	}

	/* ---------- Availability ---------- */

	/** Replace weekly windows. $windows: [[weekday 0-6, 'HH:MM', 'HH:MM'], ...] in site local time. @return true|\WP_Error */
	public static function set_availability( int $tutor_id, array $windows ) {
		global $wpdb;
		$clean = array();
		foreach ( $windows as $w ) {
			$d = (int) ( $w[0] ?? -1 );
			$s = (string) ( $w[1] ?? '' );
			$e = (string) ( $w[2] ?? '' );
			if ( $d < 0 || $d > 6 || ! preg_match( '/^\d{2}:\d{2}$/', $s ) || ! preg_match( '/^\d{2}:\d{2}$/', $e ) || $e <= $s ) {
				return new \WP_Error( 'ec_th_window', __( 'Each availability window needs a day, a start time and a later end time.', 'educore-teaching-hub' ) );
			}
			foreach ( $clean as $c ) {
				if ( $c[0] === $d && $s < $c[2] && $e > $c[1] ) {
					return new \WP_Error( 'ec_th_overlap', __( 'Availability windows on the same day must not overlap.', 'educore-teaching-hub' ) );
				}
			}
			$clean[] = array( $d, $s, $e );
		}
		$wpdb->delete( self::t( 'th_availability' ), array( 'tutor_id' => $tutor_id ) );
		foreach ( $clean as $c ) {
			$wpdb->insert( self::t( 'th_availability' ), array( 'tutor_id' => $tutor_id, 'weekday' => $c[0], 'start_time' => $c[1] . ':00', 'end_time' => $c[2] . ':00' ) );
		}
		Audit::log( 'tutor.availability', 'user', $tutor_id, array( 'windows' => count( $clean ) ) );
		return true;
	}

	/** @return array<int,array{0:int,1:string,2:string}> */
	public static function availability( int $tutor_id ): array {
		global $wpdb;
		return array_map(
			static fn( $r ) => array( (int) $r['weekday'], substr( $r['start_time'], 0, 5 ), substr( $r['end_time'], 0, 5 ) ),
			$wpdb->get_results( $wpdb->prepare( 'SELECT weekday, start_time, end_time FROM ' . self::t( 'th_availability' ) . ' WHERE tutor_id=%d ORDER BY weekday, start_time', $tutor_id ), ARRAY_A ) ?: array()
		);
	}

	/** @param string[] $days Y-m-d */
	public static function set_unavailable( int $tutor_id, array $days ): void {
		global $wpdb;
		$wpdb->delete( self::t( 'th_unavailable' ), array( 'tutor_id' => $tutor_id ) );
		foreach ( array_unique( $days ) as $d ) {
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) {
				$wpdb->insert( self::t( 'th_unavailable' ), array( 'tutor_id' => $tutor_id, 'day' => $d ) );
			}
		}
	}

	/** @return string[] */
	public static function unavailable( int $tutor_id ): array {
		global $wpdb;
		return $wpdb->get_col( $wpdb->prepare( 'SELECT day FROM ' . self::t( 'th_unavailable' ) . ' WHERE tutor_id=%d AND day>=%s ORDER BY day', $tutor_id, wp_date( 'Y-m-d' ) ) );
	}

	/** Is [start,end) (UTC) inside one availability window on an available local day? */
	public static function within_availability( int $tutor_id, string $start_utc, string $end_utc ): bool {
		$tz = wp_timezone();
		$s  = ( new \DateTimeImmutable( $start_utc, new \DateTimeZone( 'UTC' ) ) )->setTimezone( $tz );
		$e  = ( new \DateTimeImmutable( $end_utc, new \DateTimeZone( 'UTC' ) ) )->setTimezone( $tz );
		if ( $s->format( 'Y-m-d' ) !== $e->format( 'Y-m-d' ) && '00:00' !== $e->format( 'H:i' ) ) {
			return false;
		}
		if ( in_array( $s->format( 'Y-m-d' ), self::unavailable( $tutor_id ), true ) ) {
			return false;
		}
		$day = (int) $s->format( 'w' );
		$hs  = $s->format( 'H:i' );
		$he  = '00:00' === $e->format( 'H:i' ) ? '24:00' : $e->format( 'H:i' );
		foreach ( self::availability( $tutor_id ) as $w ) {
			if ( $w[0] === $day && $hs >= $w[1] && $he <= ( '00:00' === $w[2] ? '24:00' : $w[2] ) ) {
				return true;
			}
		}
		return false;
	}

	/** Slot grid starts (UTC) covering [start,end). */
	public static function slots( string $start_utc, string $end_utc ): array {
		$step = (int) Settings::get( 'slot_minutes' ) * 60;
		$out  = array();
		for ( $t = strtotime( $start_utc . ' UTC' ); $t < strtotime( $end_utc . ' UTC' ); $t += $step ) {
			$out[] = gmdate( 'Y-m-d H:i:s', $t );
		}
		return $out;
	}

	/** Free bookable starts (UTC) for the next $days days, honouring notice, windows, locks. @return string[] */
	public static function free_starts( int $tutor_id, int $days = 14 ): array {
		global $wpdb;
		$p = self::profile( $tutor_id );
		if ( ! $p || ! self::bookable( $tutor_id ) ) {
			return array();
		}
		$len    = (int) $p['session_minutes'];
		$step   = (int) Settings::get( 'slot_minutes' );
		$tz     = wp_timezone();
		$min    = time() + (int) $p['notice_hours'] * HOUR_IN_SECONDS;
		$locked = array_flip( $wpdb->get_col( $wpdb->prepare( 'SELECT slot_start FROM ' . self::t( 'th_slot_locks' ) . ' WHERE tutor_id=%d AND slot_start>=%s', $tutor_id, gmdate( 'Y-m-d H:i:s' ) ) ) );
		$off    = array_flip( self::unavailable( $tutor_id ) );
		$wins   = self::availability( $tutor_id );
		$out    = array();
		$today  = new \DateTimeImmutable( 'today', $tz );
		for ( $i = 0; $i < min( $days, (int) Settings::get( 'max_booking_days' ) ); $i++ ) {
			$d = $today->modify( "+{$i} day" );
			if ( isset( $off[ $d->format( 'Y-m-d' ) ] ) ) {
				continue;
			}
			foreach ( $wins as $w ) {
				if ( (int) $d->format( 'w' ) !== $w[0] ) {
					continue;
				}
				$ws = new \DateTimeImmutable( $d->format( 'Y-m-d' ) . ' ' . $w[1], $tz );
				$we = new \DateTimeImmutable( $d->format( 'Y-m-d' ) . ' ' . $w[2], $tz );
				for ( $s = $ws; $s->modify( "+{$len} minutes" ) <= $we; $s = $s->modify( "+{$step} minutes" ) ) {
					if ( $s->getTimestamp() < $min ) {
						continue;
					}
					$su   = $s->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
					$eu   = $s->modify( "+{$len} minutes" )->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
					$free = true;
					foreach ( self::slots( $su, $eu ) as $sl ) {
						if ( isset( $locked[ $sl ] ) ) {
							$free = false;
							break;
						}
					}
					if ( $free ) {
						$out[] = $su;
					}
				}
			}
		}
		sort( $out );
		return array_values( array_unique( $out ) );
	}

	/* ---------- Locks ---------- */

	/** Atomic: all slot rows inserted by a single statement or none. */
	private static function lock( int $tutor_id, int $session_id, string $start, string $end ): bool {
		global $wpdb;
		$vals = array();
		foreach ( self::slots( $start, $end ) as $sl ) {
			$vals[] = $wpdb->prepare( '(%d,%s,%d)', $tutor_id, $sl, $session_id );
		}
		if ( ! $vals ) {
			return false;
		}
		$suppress = $wpdb->suppress_errors( true );
		$ok       = $wpdb->query( 'INSERT INTO ' . self::t( 'th_slot_locks' ) . ' (tutor_id,slot_start,session_id) VALUES ' . implode( ',', $vals ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$wpdb->suppress_errors( $suppress );
		return false !== $ok && $ok > 0;
	}

	private static function unlock( int $session_id ): void {
		global $wpdb;
		$wpdb->delete( self::t( 'th_slot_locks' ), array( 'session_id' => $session_id ) );
	}

	/* ---------- Sessions ---------- */

	public static function get( int $id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_sessions' ) . ' WHERE id=%d', $id ), ARRAY_A ) ?: null;
	}

	/** @return int[] students taking part (individual student or group members). */
	public static function participants( int $session_id ): array {
		$s = self::get( $session_id );
		if ( ! $s ) {
			return array();
		}
		return (int) $s['group_id'] ? Classes::group_members( (int) $s['group_id'] ) : array_filter( array( (int) $s['student_id'] ) );
	}

	public static function can_view( int $user_id, array $s ): bool {
		if ( ! $user_id ) {
			return false;
		}
		if ( (int) $s['tutor_id'] === $user_id || Caps::is_manager( $user_id ) || in_array( $user_id, self::participants( (int) $s['id'] ), true ) ) {
			return true;
		}
		foreach ( self::participants( (int) $s['id'] ) as $sid ) {
			if ( CorePrivacy::guardian_has_access( $user_id, $sid ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Student requests a session at a free start (UTC).
	 *
	 * @return int|\WP_Error session id
	 */
	public static function request( int $student_id, int $tutor_id, string $start_utc, array $in ) {
		global $wpdb;
		$student = get_userdata( $student_id );
		if ( ! $student || ! in_array( 'ec_student', (array) $student->roles, true ) ) {
			return new \WP_Error( 'ec_th_student', __( 'Only student accounts can request tutoring.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		if ( ! CorePrivacy::has_required_consent( $student_id ) ) {
			return new \WP_Error( 'ec_th_consent', __( 'Your account needs consent before you can book tutoring.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		if ( $student_id === $tutor_id || ! self::bookable( $tutor_id ) ) {
			return new \WP_Error( 'ec_th_tutor', __( 'This tutor is not available for booking.', 'educore-teaching-hub' ), array( 'status' => 404 ) );
		}
		$p     = self::profile( $tutor_id );
		$start = gmdate( 'Y-m-d H:i:s', strtotime( $start_utc . ' UTC' ) );
		$end   = gmdate( 'Y-m-d H:i:s', strtotime( $start . ' UTC' ) + (int) $p['session_minutes'] * 60 );
		$step  = (int) Settings::get( 'slot_minutes' ) * 60;
		if ( strtotime( $start . ' UTC' ) % $step ) {
			return new \WP_Error( 'ec_th_grid', __( 'Please choose one of the offered start times.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		if ( strtotime( $start . ' UTC' ) < time() + (int) $p['notice_hours'] * HOUR_IN_SECONDS ) {
			/* translators: %d: hours */
			return new \WP_Error( 'ec_th_notice', sprintf( __( 'This tutor needs at least %d hours’ notice.', 'educore-teaching-hub' ), (int) $p['notice_hours'] ), array( 'status' => 400 ) );
		}
		if ( strtotime( $start . ' UTC' ) > time() + (int) Settings::get( 'max_booking_days' ) * DAY_IN_SECONDS ) {
			return new \WP_Error( 'ec_th_far', __( 'That date is too far ahead.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		if ( ! self::within_availability( $tutor_id, $start, $end ) ) {
			return new \WP_Error( 'ec_th_unavailable', __( 'The tutor is not available at that time.', 'educore-teaching-hub' ), array( 'status' => 409 ) );
		}
		$want   = (string) ( $in['format'] ?? '' );
		$format = in_array( $want, explode( ',', $p['formats'] ), true ) ? $want : explode( ',', $p['formats'] )[0];
		$minor  = CorePrivacy::is_minor( $student_id ) && 'on' === Settings::get( 'minor_tutoring_guardian' );
		if ( $minor && ! self::guardian_emails( $student_id ) ) {
			return new \WP_Error( 'ec_th_guardian', __( 'A verified parent or guardian is required before booking tutoring.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		$now = Schema::now();
		$wpdb->insert(
			self::t( 'th_sessions' ),
			array(
				'tutor_id'     => $tutor_id,
				'student_id'   => $student_id,
				'subject'      => mb_substr( sanitize_text_field( (string) ( $in['subject'] ?? '' ) ), 0, 190 ),
				'starts_at'    => $start,
				'ends_at'      => $end,
				'format'       => $format,
				'status'       => 'requested',
				'guardian_ok'  => $minor ? 0 : 1,
				'objectives'   => sanitize_textarea_field( (string) ( $in['objectives'] ?? '' ) ),
				'requested_by' => $student_id,
				'created_at'   => $now,
				'updated_at'   => $now,
			)
		);
		$id = (int) $wpdb->insert_id;
		if ( ! self::lock( $tutor_id, $id, $start, $end ) ) {
			$wpdb->delete( self::t( 'th_sessions' ), array( 'id' => $id ) );
			return new \WP_Error( 'ec_th_taken', __( 'Sorry — that time was just booked. Please choose another time.', 'educore-teaching-hub' ), array( 'status' => 409 ) );
		}
		Audit::log( 'tutoring.requested', 'session', $id, array( 'tutor_id' => $tutor_id, 'minor' => $minor ) );
		if ( $minor ) {
			self::send_guardian_requests( $id );
		}
		do_action( 'educore/th/session_requested', $id );
		return $id;
	}

	/**
	 * Tutor creates a session directly: group session (own tutoring group) or one-to-one with a student they
	 * already tutor; optional weekly recurrence. Returns created ids (skips conflicting occurrences).
	 *
	 * @return int[]|\WP_Error
	 */
	public static function create_by_tutor( int $tutor_id, array $in ) {
		global $wpdb;
		if ( ! user_can( $tutor_id, 'ec_tutor_sessions' ) || ! self::bookable( $tutor_id ) ) {
			return new \WP_Error( 'ec_th_tutor', __( 'Your tutor profile must be approved first.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		$group   = absint( $in['group_id'] ?? 0 );
		$student = absint( $in['student_id'] ?? 0 );
		if ( $group ) {
			$g = Classes::group( $group );
			if ( ! $g || 'tutoring' !== $g['group_type'] || (int) $g['owner_id'] !== $tutor_id ) {
				return new \WP_Error( 'ec_th_group', __( 'Choose one of your tutoring groups.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
			}
			$student = 0;
		} elseif ( ! $student || ! Caps::teaches_student( $tutor_id, $student ) ) {
			return new \WP_Error( 'ec_th_scope', __( 'You can schedule directly only with students you already tutor. New students send a request.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		$start = Plugin::local_to_utc( (string) ( $in['start'] ?? '' ) );
		$mins  = max( 15, min( 240, absint( $in['minutes'] ?? 60 ) ) );
		if ( ! $start || strtotime( $start . ' UTC' ) < time() ) {
			return new \WP_Error( 'ec_th_time', __( 'Choose a future start time.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		$step = (int) Settings::get( 'slot_minutes' ) * 60;
		if ( strtotime( $start . ' UTC' ) % $step || ( $mins * 60 ) % $step ) {
			/* translators: %d: minutes */
			return new \WP_Error( 'ec_th_grid', sprintf( __( 'Start times and durations must be multiples of %d minutes.', 'educore-teaching-hub' ), $step / 60 ), array( 'status' => 400 ) );
		}
		$weeks  = max( 1, min( 26, absint( $in['repeat_weeks'] ?? 1 ) ) );
		$url    = self::clean_meeting_url( (string) ( $in['meeting_url'] ?? '' ) );
		if ( is_wp_error( $url ) ) {
			return $url;
		}
		$ids    = array();
		$series = 0;
		for ( $w = 0; $w < $weeks; $w++ ) {
			$s   = gmdate( 'Y-m-d H:i:s', strtotime( $start . ' UTC' ) + $w * WEEK_IN_SECONDS );
			$e   = gmdate( 'Y-m-d H:i:s', strtotime( $s . ' UTC' ) + $mins * 60 );
			$now = Schema::now();
			$wpdb->insert( self::t( 'th_sessions' ), array( 'tutor_id' => $tutor_id, 'student_id' => $student, 'group_id' => $group, 'subject' => mb_substr( sanitize_text_field( (string) ( $in['subject'] ?? '' ) ), 0, 190 ), 'starts_at' => $s, 'ends_at' => $e, 'format' => 'in_person' === ( $in['format'] ?? '' ) ? 'in_person' : 'online', 'status' => 'confirmed', 'guardian_ok' => 1, 'objectives' => sanitize_textarea_field( (string) ( $in['objectives'] ?? '' ) ), 'meeting_url' => $url, 'location' => mb_substr( sanitize_text_field( (string) ( $in['location'] ?? '' ) ), 0, 190 ), 'series_id' => $series, 'requested_by' => $tutor_id, 'created_at' => $now, 'updated_at' => $now ) );
			$id = (int) $wpdb->insert_id;
			if ( ! self::lock( $tutor_id, $id, $s, $e ) ) {
				$wpdb->delete( self::t( 'th_sessions' ), array( 'id' => $id ) );
				continue;
			}
			if ( ! $series ) {
				$series = $id;
				$wpdb->update( self::t( 'th_sessions' ), array( 'series_id' => $id ), array( 'id' => $id ) );
			}
			$ids[] = $id;
			Audit::log( 'tutoring.scheduled', 'session', $id, array( 'group_id' => $group, 'student_id' => $student ) );
			do_action( 'educore/th/session_confirmed', $id );
		}
		return $ids ?: new \WP_Error( 'ec_th_taken', __( 'All requested times conflict with existing sessions.', 'educore-teaching-hub' ), array( 'status' => 409 ) );
	}

	/** Only links to approved conferencing hosts over HTTPS (no unsecured public rooms). @return string|\WP_Error */
	public static function clean_meeting_url( string $url ) {
		$url = trim( $url );
		if ( '' === $url ) {
			return '';
		}
		$parts = wp_parse_url( $url );
		$host  = strtolower( (string) ( $parts['host'] ?? '' ) );
		$ok    = false;
		foreach ( array_filter( explode( ',', (string) Settings::get( 'meeting_hosts' ) ) ) as $allowed ) {
			if ( $host === $allowed || str_ends_with( $host, '.' . $allowed ) ) {
				$ok = true;
			}
		}
		if ( 'https' !== ( $parts['scheme'] ?? '' ) || ! $ok ) {
			return new \WP_Error( 'ec_th_meeting', __( 'Meeting links must be HTTPS links on an approved conferencing service.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		return esc_url_raw( $url );
	}

	/**
	 * Status transition with rules per actor.
	 *
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function transition( int $session_id, string $to, int $actor, array $in = array() ) {
		global $wpdb;
		$s = self::get( $session_id );
		if ( ! $s ) {
			return new \WP_Error( 'ec_th_404', __( 'Session not found.', 'educore-teaching-hub' ), array( 'status' => 404 ) );
		}
		$is_tutor   = (int) $s['tutor_id'] === $actor || Caps::is_manager( $actor );
		$is_student = (int) $s['student_id'] === $actor && $actor > 0;
		$from       = $s['status'];
		$started    = strtotime( $s['starts_at'] . ' UTC' ) <= time();
		$allowed    = array(
			'confirmed' => $is_tutor && 'requested' === $from,
			'declined'  => $is_tutor && 'requested' === $from,
			'cancelled' => ( $is_tutor || $is_student ) && in_array( $from, self::ACTIVE, true ) && ! $started,
			'completed' => $is_tutor && 'confirmed' === $from && $started,
			'no_show'   => $is_tutor && 'confirmed' === $from && $started,
		);
		if ( empty( $allowed[ $to ] ) ) {
			return new \WP_Error( 'ec_th_transition', __( 'This change is not allowed for this session.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		if ( 'confirmed' === $to && ! (int) $s['guardian_ok'] ) {
			return new \WP_Error( 'ec_th_guardian_pending', __( 'Waiting for the parent or guardian to authorise this session.', 'educore-teaching-hub' ), array( 'status' => 409 ) );
		}
		$row = array( 'status' => $to, 'updated_at' => Schema::now(), 'status_note' => mb_substr( sanitize_text_field( (string) ( $in['note'] ?? '' ) ), 0, 255 ) );
		if ( 'confirmed' === $to ) {
			$url = self::clean_meeting_url( (string) ( $in['meeting_url'] ?? '' ) );
			if ( is_wp_error( $url ) ) {
				return $url;
			}
			$row['meeting_url'] = $url;
			$row['location']    = mb_substr( sanitize_text_field( (string) ( $in['location'] ?? '' ) ), 0, 190 );
		}
		$wpdb->update( self::t( 'th_sessions' ), $row, array( 'id' => $session_id ) );
		if ( in_array( $to, array( 'declined', 'cancelled' ), true ) ) {
			self::unlock( $session_id );
		}
		if ( in_array( $to, array( 'completed', 'no_show' ), true ) && ! (int) $s['group_id'] && (int) $s['student_id'] ) {
			Attendance::record( 'session', $session_id, Plugin::local( $s['starts_at'], 'Y-m-d' ), array( (int) $s['student_id'] => 'completed' === $to ? 'present' : 'absent' ), $actor );
		}
		Caps::flush();
		Audit::log( 'tutoring.' . $to, 'session', $session_id, array( 'from' => $from, 'by' => $actor ) );
		do_action( 'educore/th/session_' . $to, $session_id, $actor );
		return self::get( $session_id );
	}

	/** Move a confirmed/requested session; new slots are locked before old ones are released. @return array<string,mixed>|\WP_Error */
	public static function reschedule( int $session_id, string $new_start_utc, int $actor ) {
		global $wpdb;
		$s = self::get( $session_id );
		if ( ! $s || ! ( (int) $s['tutor_id'] === $actor || Caps::is_manager( $actor ) ) || ! in_array( $s['status'], self::ACTIVE, true ) ) {
			return new \WP_Error( 'ec_th_transition', __( 'This session cannot be rescheduled.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		$len   = strtotime( $s['ends_at'] . ' UTC' ) - strtotime( $s['starts_at'] . ' UTC' );
		$start = gmdate( 'Y-m-d H:i:s', strtotime( $new_start_utc . ' UTC' ) );
		$end   = gmdate( 'Y-m-d H:i:s', strtotime( $start . ' UTC' ) + $len );
		if ( strtotime( $start . ' UTC' ) < time() || strtotime( $start . ' UTC' ) % ( (int) Settings::get( 'slot_minutes' ) * 60 ) ) {
			return new \WP_Error( 'ec_th_time', __( 'Choose a future start time on the booking grid.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		// Lock only the new slots this session does not already hold (one atomic INSERT), then release the rest.
		$own  = $wpdb->get_col( $wpdb->prepare( 'SELECT slot_start FROM ' . self::t( 'th_slot_locks' ) . ' WHERE session_id=%d', $session_id ) );
		$want = self::slots( $start, $end );
		$add  = array_values( array_diff( $want, $own ) );
		if ( $add ) {
			$vals = array();
			foreach ( $add as $sl ) {
				$vals[] = $wpdb->prepare( '(%d,%s,%d)', (int) $s['tutor_id'], $sl, $session_id );
			}
			$suppress = $wpdb->suppress_errors( true );
			$ok       = $wpdb->query( 'INSERT INTO ' . self::t( 'th_slot_locks' ) . ' (tutor_id,slot_start,session_id) VALUES ' . implode( ',', $vals ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->suppress_errors( $suppress );
			if ( false === $ok || ! $ok ) {
				return new \WP_Error( 'ec_th_taken', __( 'The new time conflicts with another session.', 'educore-teaching-hub' ), array( 'status' => 409 ) );
			}
		}
		foreach ( array_diff( $own, $want ) as $sl ) {
			$wpdb->delete( self::t( 'th_slot_locks' ), array( 'tutor_id' => (int) $s['tutor_id'], 'slot_start' => $sl, 'session_id' => $session_id ) );
		}
		$wpdb->update( self::t( 'th_sessions' ), array( 'starts_at' => $start, 'ends_at' => $end, 'status_note' => 'rescheduled', 'updated_at' => Schema::now() ), array( 'id' => $session_id ) );
		Audit::log( 'tutoring.rescheduled', 'session', $session_id, array( 'from' => $s['starts_at'], 'to' => $start ) );
		do_action( 'educore/th/session_rescheduled', $session_id );
		return self::get( $session_id );
	}

	/** Tutor workspace notes: objectives, notes, homework, feedback, follow-up. */
	public static function update_workspace( int $session_id, array $in, int $actor ): bool {
		global $wpdb;
		$s = self::get( $session_id );
		if ( ! $s || ! ( (int) $s['tutor_id'] === $actor || Caps::is_manager( $actor ) ) ) {
			return false;
		}
		$row = array( 'updated_at' => Schema::now() );
		foreach ( array( 'objectives', 'notes', 'homework', 'feedback', 'follow_up' ) as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$row[ $f ] = sanitize_textarea_field( (string) $in[ $f ] );
			}
		}
		$wpdb->update( self::t( 'th_sessions' ), $row, array( 'id' => $session_id ) );
		Audit::log( 'tutoring.workspace', 'session', $session_id );
		if ( ! empty( $in['feedback'] ) || ! empty( $in['homework'] ) ) {
			do_action( 'educore/th/session_feedback', $session_id );
		}
		return true;
	}

	/** @return array<int,array<string,mixed>> */
	public static function for_tutor( int $tutor_id, string $when = 'upcoming', int $limit = 100 ): array {
		global $wpdb;
		$cond = 'upcoming' === $when ? $wpdb->prepare( "status IN ('requested','confirmed') AND ends_at>=%s ORDER BY starts_at ASC", Schema::now() ) : $wpdb->prepare( "(status NOT IN ('requested','confirmed') OR ends_at<%s) ORDER BY starts_at DESC", Schema::now() );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_sessions' ) . " WHERE tutor_id=%d AND {$cond} LIMIT %d", $tutor_id, $limit ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** @return array<int,array<string,mixed>> */
	public static function for_student( int $student_id, int $limit = 50 ): array {
		global $wpdb;
		$groups = Classes::groups_of_student( $student_id );
		$or     = $wpdb->prepare( 'student_id=%d', $student_id ) . ( $groups ? ' OR group_id IN (' . implode( ',', $groups ) . ')' : '' );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_sessions' ) . " WHERE ({$or}) ORDER BY starts_at DESC LIMIT %d", $limit ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/* ---------- Guardian authorisation for minors ---------- */

	/** @return string[] verified guardian e-mails */
	public static function guardian_emails( int $student_id ): array {
		global $wpdb;
		return $wpdb->get_col( $wpdb->prepare( 'SELECT guardian_email FROM ' . Schema::table( 'guardian_links' ) . " WHERE student_id=%d AND status='verified'", $student_id ) );
	}

	public static function guardian_token( int $session_id, int $student_id ): string {
		return hash_hmac( 'sha256', 'th-session|' . $session_id . '|' . $student_id, wp_salt( 'auth' ) );
	}

	public static function guardian_url( int $session_id ): string {
		$s = self::get( $session_id );
		return add_query_arg( array( 'ec_th_session' => $session_id, 't' => self::guardian_token( $session_id, (int) $s['student_id'] ) ), home_url( '/' ) );
	}

	private static function send_guardian_requests( int $session_id ): void {
		$s = self::get( $session_id );
		foreach ( self::guardian_emails( (int) $s['student_id'] ) as $email ) {
			do_action( 'educore/th/guardian_session_request', $session_id, $email, self::guardian_url( $session_id ) );
		}
	}

	/** Guardian decision: GET shows a confirmation form (no state change); POST with the token applies it. */
	public static function guardian_endpoint(): void {
		// phpcs:disable WordPress.Security.NonceVerification -- the HMAC token is the authorisation and CSRF secret for the (anonymous) guardian.
		if ( empty( $_REQUEST['ec_th_session'] ) || empty( $_REQUEST['t'] ) ) {
			return;
		}
		$id    = absint( $_REQUEST['ec_th_session'] );
		$token = sanitize_text_field( wp_unslash( $_REQUEST['t'] ) );
		$s     = self::get( $id );
		\EduCore\Core\Access::no_cache_headers();
		if ( ! $s || ! hash_equals( self::guardian_token( $id, (int) $s['student_id'] ), $token ) ) {
			wp_die( esc_html__( 'This link is not valid.', 'educore-teaching-hub' ), '', array( 'response' => 403 ) );
		}
		$student = get_userdata( (int) $s['student_id'] );
		$tutor   = get_userdata( (int) $s['tutor_id'] );
		if ( Plugin::is_post() && isset( $_POST['decision'] ) && 'requested' === $s['status'] && ! (int) $s['guardian_ok'] ) {
			$approve = 'approve' === sanitize_key( wp_unslash( $_POST['decision'] ) );
			global $wpdb;
			if ( $approve ) {
				$wpdb->update( self::t( 'th_sessions' ), array( 'guardian_ok' => 1, 'updated_at' => Schema::now() ), array( 'id' => $id ) );
			} else {
				$wpdb->update( self::t( 'th_sessions' ), array( 'status' => 'declined', 'status_note' => 'guardian_declined', 'updated_at' => Schema::now() ), array( 'id' => $id ) );
				self::unlock( $id );
			}
			Audit::log( 'tutoring.guardian_' . ( $approve ? 'approved' : 'declined' ), 'session', $id );
			do_action( 'educore/th/guardian_decided', $id, $approve );
			wp_die( esc_html( $approve ? __( 'Thank you. The session is authorised; the tutor can now confirm it.', 'educore-teaching-hub' ) : __( 'Thank you. The request has been declined.', 'educore-teaching-hub' ) ), esc_html__( 'Tutoring request', 'educore-teaching-hub' ), array( 'response' => 200 ) );
		}
		$done = 'requested' !== $s['status'] || (int) $s['guardian_ok'];
		$html = '<h1>' . esc_html__( 'Tutoring request', 'educore-teaching-hub' ) . '</h1><p>' . esc_html(
			sprintf(
				/* translators: 1: student, 2: tutor, 3: date/time, 4: format */
				__( '%1$s asked for a tutoring session with %2$s on %3$s (%4$s).', 'educore-teaching-hub' ),
				$student ? $student->display_name : '',
				$tutor ? $tutor->display_name : '',
				Plugin::local( $s['starts_at'] ),
				'in_person' === $s['format'] ? __( 'in person', 'educore-teaching-hub' ) : __( 'online', 'educore-teaching-hub' )
			)
		) . '</p>';
		if ( $done ) {
			$html .= '<p>' . esc_html__( 'A decision has already been recorded for this request.', 'educore-teaching-hub' ) . '</p>';
		} else {
			$html .= '<form method="post"><input type="hidden" name="ec_th_session" value="' . esc_attr( (string) $id ) . '"><input type="hidden" name="t" value="' . esc_attr( $token ) . '"><p><button name="decision" value="approve">' . esc_html__( 'Authorise', 'educore-teaching-hub' ) . '</button> <button name="decision" value="decline">' . esc_html__( 'Decline', 'educore-teaching-hub' ) . '</button></p></form>';
		}
		wp_die( $html, esc_html__( 'Tutoring request', 'educore-teaching-hub' ), array( 'response' => 200 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts.
		// phpcs:enable
	}
}
