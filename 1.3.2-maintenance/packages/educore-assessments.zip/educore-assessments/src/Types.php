<?php
namespace EduCore\Assessments;

use EduCore\Core\Search;

defined( 'ABSPATH' ) || exit;

/**
 * Question types: authoring normalisation, student-safe views and grading.
 *
 * payload (public) / answer_key (server-only) shapes:
 *   single, image  payload {options:[{id,text}], image_id?}      key {correct:"b"}
 *   multiple       payload {options:[{id,text}]}                 key {correct:["a","c"]}           all-or-nothing; optional key.scoring "partial": max(0,(right−wrong)/correct)
 *   truefalse      payload {}                                    key {correct:true}
 *   short          payload {}                                    key {accepted:["…"]}               case/space/diacritic-insensitive
 *   essay          payload {min_words?}                          key {model_answer:"…"}            manual grading
 *   fill_blanks    payload {blanks:n} (stem contains [[1]]…)     key {blanks:[["a","alt"],["b"]]}   partial credit per blank
 *   matching       payload {left:[{id,text}], right:[{id,text}]} key {pairs:{"l1":"r2"}}            partial credit per pair
 *   ordering       payload {items:[{id,text}]}                   key {order:["i1","i2"]}           all-or-nothing; optional key.scoring "partial": share in correct position
 *   code           payload {code, language}                      key {expected:["output"]}         code reading; output compared, never executed
 */
final class Types {
	/** Types that support an optional partial-credit scoring mode (stored in the answer key). */
	public const PARTIAL_TYPES = array( 'multiple', 'ordering' );

	public static function scoring_of( array $row ): string {
		return 'partial' === ( $row['scoring'] ?? '' ) ? 'partial' : 'all_or_nothing';
	}

	/** Add the scoring mode to a key only when partial, so existing versions stay byte-identical. */
	private static function with_scoring( array $key, array $row ): array {
		if ( 'partial' === self::scoring_of( $row ) ) {
			$key['scoring'] = 'partial';
		}
		return $key;
	}

	public const ALL = array( 'single', 'multiple', 'truefalse', 'short', 'essay', 'fill_blanks', 'matching', 'ordering', 'code', 'image' );

	public static function labels(): array {
		return array(
			'single'      => __( 'Multiple choice (one answer)', 'educore-assessments' ),
			'multiple'    => __( 'Multiple choice (several answers)', 'educore-assessments' ),
			'truefalse'   => __( 'True / False', 'educore-assessments' ),
			'short'       => __( 'Short answer', 'educore-assessments' ),
			'essay'       => __( 'Essay', 'educore-assessments' ),
			'fill_blanks' => __( 'Fill in the blanks', 'educore-assessments' ),
			'matching'    => __( 'Matching', 'educore-assessments' ),
			'ordering'    => __( 'Ordering', 'educore-assessments' ),
			'code'        => __( 'Code reading', 'educore-assessments' ),
			'image'       => __( 'Image-based choice', 'educore-assessments' ),
		);
	}

	public static function is_manual( string $type ): bool {
		return 'essay' === $type;
	}

	/** Practice tries allowed (D-05). */
	public static function practice_limit( string $type ): int {
		$map = array( 'truefalse' => 1, 'essay' => 1 );
		return (int) apply_filters( 'educore/assessments/practice_limit', $map[ $type ] ?? 3, $type );
	}

	/** MCQ family for blueprint coverage. */
	public static function family( string $type ): string {
		if ( in_array( $type, array( 'single', 'multiple', 'image' ), true ) ) {
			return 'mcq';
		}
		return in_array( $type, array( 'truefalse', 'essay' ), true ) ? $type : 'other';
	}

	private static function lines( $v ): array {
		if ( is_array( $v ) ) {
			return array_values( array_filter( array_map( static fn( $x ) => trim( (string) $x ), $v ), 'strlen' ) );
		}
		return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $v ) ), 'strlen' ) );
	}

	private static function option_list( array $texts, string $prefix = '' ): array {
		$out = array();
		foreach ( array_values( $texts ) as $i => $t ) {
			$out[] = array( 'id' => $prefix . ( $prefix ? ( $i + 1 ) : chr( 97 + $i ) ), 'text' => wp_kses_post( $t ) );
		}
		return $out;
	}

	private static function indexes( string $v ): array {
		return array_values( array_filter( array_map( 'intval', preg_split( '/[\s,;]+/', $v ) ) ) );
	}

	/**
	 * Convert an authoring row (admin form / CSV) into payload + key.
	 * Row fields: type, options (lines), correct, model_answer, code, image_id, language.
	 *
	 * @return array{payload:array,key:array}|\WP_Error
	 */
	public static function from_authoring( array $row ) {
		$type    = (string) ( $row['type'] ?? '' );
		$options = self::lines( $row['options'] ?? '' );
		$correct = trim( (string) ( $row['correct'] ?? '' ) );
		$err     = static fn( $m ) => new \WP_Error( 'educore_invalid_question', $m, array( 'status' => 400 ) );
		switch ( $type ) {
			case 'single':
			case 'image':
				$opts = self::option_list( $options );
				$idx  = (int) $correct;
				if ( count( $opts ) < 2 || $idx < 1 || $idx > count( $opts ) ) {
					return $err( __( 'Provide at least two options and the number of the correct option.', 'educore-assessments' ) );
				}
				$payload = array( 'options' => $opts );
				if ( 'image' === $type ) {
					$payload['image_id'] = absint( $row['image_id'] ?? 0 );
					if ( ! $payload['image_id'] ) {
						return $err( __( 'Image questions need an image (media library ID).', 'educore-assessments' ) );
					}
				}
				return array( 'payload' => $payload, 'key' => array( 'correct' => $opts[ $idx - 1 ]['id'] ) );
			case 'multiple':
				$opts = self::option_list( $options );
				$idx  = array_unique( self::indexes( $correct ) );
				if ( count( $opts ) < 2 || ! $idx || max( $idx ) > count( $opts ) ) {
					return $err( __( 'Provide options and the numbers of all correct options (e.g. 1,3).', 'educore-assessments' ) );
				}
				$ids = array_map( static fn( $i ) => $opts[ $i - 1 ]['id'], $idx );
				sort( $ids );
				return array( 'payload' => array( 'options' => $opts ), 'key' => self::with_scoring( array( 'correct' => $ids ), $row ) );
			case 'truefalse':
				$v = strtolower( $correct );
				if ( ! in_array( $v, array( 'true', 'false', '1', '0', 't', 'f', 'yes', 'no' ), true ) ) {
					return $err( __( 'The correct answer must be true or false.', 'educore-assessments' ) );
				}
				return array( 'payload' => array(), 'key' => array( 'correct' => in_array( $v, array( 'true', '1', 't', 'yes' ), true ) ) );
			case 'short':
				$acc = self::lines( $correct );
				return $acc ? array( 'payload' => array(), 'key' => array( 'accepted' => $acc ) ) : $err( __( 'List at least one accepted answer (one per line).', 'educore-assessments' ) );
			case 'essay':
				return array( 'payload' => array( 'min_words' => absint( $row['min_words'] ?? 0 ) ), 'key' => array( 'model_answer' => wp_kses_post( (string) ( $row['model_answer'] ?? '' ) ) ) );
			case 'fill_blanks':
				preg_match_all( '/\[\[(\d+)\]\]/', (string) ( $row['stem'] ?? '' ), $m );
				$n      = $m[1] ? max( array_map( 'intval', $m[1] ) ) : 0;
				$blanks = array();
				foreach ( self::lines( $correct ) as $line ) {
					if ( preg_match( '/^(\d+)\s*[:=]\s*(.+)$/u', $line, $mm ) ) {
						$blanks[ (int) $mm[1] - 1 ] = array_values( array_filter( array_map( 'trim', explode( '|', $mm[2] ) ), 'strlen' ) );
					}
				}
				if ( ! $n || count( $blanks ) !== $n ) {
					return $err( __( 'Mark blanks in the question as [[1]], [[2]]… and give one line per blank: "1: answer|alternative".', 'educore-assessments' ) );
				}
				ksort( $blanks );
				return array( 'payload' => array( 'blanks' => $n ), 'key' => array( 'blanks' => array_values( $blanks ) ) );
			case 'matching':
				$left  = array();
				$right = array();
				$pairs = array();
				foreach ( $options as $i => $line ) {
					$parts = array_map( 'trim', explode( '|', $line, 2 ) );
					// "left | right" is a pair; " | right" (empty left) is an extra distractor answer.
					if ( 2 !== count( $parts ) || '' === $parts[1] ) {
						return $err( __( 'Write each pair on its own line as "left | right".', 'educore-assessments' ) );
					}
					$text = wp_kses_post( $parts[1] );
					$rid  = array_search( $text, array_column( $right, 'text', 'id' ), true );
					if ( false === $rid ) {
						$rid     = 'r' . ( $i + 1 );
						$right[] = array( 'id' => $rid, 'text' => $text );
					}
					if ( '' !== $parts[0] ) {
						$left[]                     = array( 'id' => 'l' . ( $i + 1 ), 'text' => wp_kses_post( $parts[0] ) );
						$pairs[ 'l' . ( $i + 1 ) ] = $rid;
					}
				}
				return count( $left ) >= 2 ? array( 'payload' => array( 'left' => $left, 'right' => $right ), 'key' => array( 'pairs' => $pairs ) ) : $err( __( 'Provide at least two pairs.', 'educore-assessments' ) );
			case 'ordering':
				$items = self::option_list( $options, 'i' );
				return count( $items ) >= 2 ? array( 'payload' => array( 'items' => $items ), 'key' => self::with_scoring( array( 'order' => wp_list_pluck( $items, 'id' ) ), $row ) ) : $err( __( 'List at least two items in the correct order.', 'educore-assessments' ) );
			case 'code':
				$code = (string) ( $row['code'] ?? '' );
				$exp  = self::lines( $correct );
				if ( '' === trim( $code ) || ! $exp ) {
					return $err( __( 'Provide the code snippet and the expected output.', 'educore-assessments' ) );
				}
				return array( 'payload' => array( 'code' => $code, 'language' => sanitize_key( $row['language'] ?? 'python' ) ?: 'python' ), 'key' => array( 'expected' => $exp ) );
		}
		return $err( __( 'Unknown question type.', 'educore-assessments' ) );
	}

	/** Inverse of from_authoring (for edit forms and CSV export). */
	public static function to_authoring( string $type, array $payload, array $key ): array {
		$row = array( 'options' => '', 'correct' => '', 'model_answer' => '', 'code' => '', 'image_id' => '', 'language' => '', 'scoring' => in_array( $type, self::PARTIAL_TYPES, true ) ? self::scoring_of( $key ) : '' );
		switch ( $type ) {
			case 'single':
			case 'image':
			case 'multiple':
				$ids            = wp_list_pluck( $payload['options'] ?? array(), 'id' );
				$row['options'] = implode( "\n", wp_list_pluck( $payload['options'] ?? array(), 'text' ) );
				$correct        = (array) ( $key['correct'] ?? array() );
				$row['correct'] = implode( ',', array_map( static fn( $c ) => (string) ( array_search( $c, $ids, true ) + 1 ), $correct ) );
				$row['image_id'] = (string) ( $payload['image_id'] ?? '' );
				break;
			case 'truefalse':
				$row['correct'] = ! empty( $key['correct'] ) ? 'true' : 'false';
				break;
			case 'short':
				$row['correct'] = implode( "\n", (array) ( $key['accepted'] ?? array() ) );
				break;
			case 'essay':
				$row['model_answer'] = (string) ( $key['model_answer'] ?? '' );
				break;
			case 'fill_blanks':
				$lines = array();
				foreach ( (array) ( $key['blanks'] ?? array() ) as $i => $alts ) {
					$lines[] = ( $i + 1 ) . ': ' . implode( '|', (array) $alts );
				}
				$row['correct'] = implode( "\n", $lines );
				break;
			case 'matching':
				$right = array();
				foreach ( $payload['right'] ?? array() as $r ) {
					$right[ $r['id'] ] = $r['text'];
				}
				$lines = array();
				$used  = array();
				foreach ( $payload['left'] ?? array() as $l ) {
					$rid     = $key['pairs'][ $l['id'] ] ?? '';
					$used[]  = $rid;
					$lines[] = $l['text'] . ' | ' . ( $right[ $rid ] ?? '' );
				}
				foreach ( array_diff( array_keys( $right ), $used ) as $extra ) {
					$lines[] = ' | ' . $right[ $extra ]; // Distractor.
				}
				$row['options'] = implode( "\n", $lines );
				break;
			case 'ordering':
				$texts = array();
				foreach ( $payload['items'] ?? array() as $it ) {
					$texts[ $it['id'] ] = $it['text'];
				}
				$row['options'] = implode( "\n", array_map( static fn( $id ) => $texts[ $id ] ?? '', (array) ( $key['order'] ?? array() ) ) );
				break;
			case 'code':
				$row['code']     = (string) ( $payload['code'] ?? '' );
				$row['language'] = (string) ( $payload['language'] ?? '' );
				$row['correct']  = implode( "\n", (array) ( $key['expected'] ?? array() ) );
				break;
		}
		return $row;
	}

	/** Deterministic seeded ordering helper. */
	public static function seeded_sort( array $ids, string $seed ): array {
		usort( $ids, static fn( $a, $b ) => strcmp( md5( $seed . '|' . $a ), md5( $seed . '|' . $b ) ) );
		return $ids;
	}

	/**
	 * Student-safe view. Never includes the answer key.
	 *
	 * @param array|null $order option/item order frozen for an attempt (ids), or null.
	 */
	public static function public_view( string $type, array $payload, ?array $order = null, string $seed = '' ): array {
		$view = array();
		switch ( $type ) {
			case 'single':
			case 'image':
			case 'multiple':
				$opts = $payload['options'] ?? array();
				if ( $order ) {
					$by = array();
					foreach ( $opts as $o ) {
						$by[ $o['id'] ] = $o;
					}
					$opts = array_values( array_filter( array_map( static fn( $id ) => $by[ $id ] ?? null, $order ) ) );
				}
				$view['options'] = $opts;
				if ( 'image' === $type ) {
					$view['image'] = (string) wp_get_attachment_image_url( (int) ( $payload['image_id'] ?? 0 ), 'large' );
					$alt           = (string) get_post_meta( (int) ( $payload['image_id'] ?? 0 ), '_wp_attachment_image_alt', true );
					$view['alt']   = $alt;
				}
				break;
			case 'essay':
				$view['min_words'] = (int) ( $payload['min_words'] ?? 0 );
				break;
			case 'fill_blanks':
				$view['blanks'] = (int) ( $payload['blanks'] ?? 0 );
				break;
			case 'matching':
				$view['left']  = $payload['left'] ?? array();
				$right         = $payload['right'] ?? array();
				$ids           = self::seeded_sort( wp_list_pluck( $right, 'id' ), $seed ?: 'm' );
				$by            = array();
				foreach ( $right as $r ) {
					$by[ $r['id'] ] = $r;
				}
				$view['right'] = array_map( static fn( $id ) => $by[ $id ], $ids );
				break;
			case 'ordering':
				$items = $payload['items'] ?? array();
				$ids   = self::seeded_sort( wp_list_pluck( $items, 'id' ), $seed ?: 'o' );
				if ( wp_list_pluck( $items, 'id' ) === $ids && count( $ids ) > 1 ) {
					$ids = array_reverse( $ids ); // Never present the solved order.
				}
				$by = array();
				foreach ( $items as $it ) {
					$by[ $it['id'] ] = $it;
				}
				$view['items'] = array_map( static fn( $id ) => $by[ $id ], $ids );
				break;
			case 'code':
				$view['code']     = (string) ( $payload['code'] ?? '' );
				$view['language'] = (string) ( $payload['language'] ?? '' );
				break;
		}
		return $view;
	}

	public static function norm( string $s ): string {
		return Search::normalize( $s );
	}

	private static function norm_code( string $s ): string {
		$lines = array_map( static fn( $l ) => preg_replace( '/\s+/', ' ', trim( $l ) ), preg_split( '/\r\n|\r|\n/', trim( $s ) ) );
		return implode( "\n", array_filter( $lines, 'strlen' ) );
	}

	/**
	 * Fraction of points earned (0..1), or null when manual grading is needed / no answer for manual.
	 *
	 * @param mixed $answer
	 */
	public static function grade( string $type, array $key, $answer ): ?float {
		switch ( $type ) {
			case 'single':
			case 'image':
				return is_scalar( $answer ) && (string) $answer === (string) ( $key['correct'] ?? '' ) ? 1.0 : 0.0;
			case 'multiple':
				$a = array_map( 'strval', (array) $answer );
				$c = array_map( 'strval', (array) ( $key['correct'] ?? array() ) );
				$a = array_values( array_unique( $a ) );
				sort( $a );
				sort( $c );
				if ( 'partial' === ( $key['scoring'] ?? '' ) ) {
					// Partial: (correct selected − wrong selected) / total correct, never below 0.
					if ( ! $c ) {
						return 0.0;
					}
					$right = count( array_intersect( $a, $c ) );
					$wrong = count( array_diff( $a, $c ) );
					return max( 0.0, ( $right - $wrong ) / count( $c ) );
				}
				return $a === $c ? 1.0 : 0.0;
			case 'truefalse':
				if ( null === $answer || '' === $answer ) {
					return 0.0;
				}
				$bool = is_bool( $answer ) ? $answer : in_array( strtolower( (string) $answer ), array( 'true', '1' ), true );
				return $bool === (bool) ( $key['correct'] ?? false ) ? 1.0 : 0.0;
			case 'short':
				$given = self::norm( (string) ( is_scalar( $answer ) ? $answer : '' ) );
				if ( '' === $given ) {
					return 0.0;
				}
				foreach ( (array) ( $key['accepted'] ?? array() ) as $acc ) {
					if ( self::norm( (string) $acc ) === $given ) {
						return 1.0;
					}
				}
				return 0.0;
			case 'essay':
				return null;
			case 'fill_blanks':
				$blanks = (array) ( $key['blanks'] ?? array() );
				if ( ! $blanks ) {
					return 0.0;
				}
				$ans = array_values( (array) $answer );
				$ok  = 0;
				foreach ( $blanks as $i => $alts ) {
					$g = self::norm( (string) ( $ans[ $i ] ?? '' ) );
					if ( '' !== $g && in_array( $g, array_map( array( self::class, 'norm' ), (array) $alts ), true ) ) {
						++$ok;
					}
				}
				return $ok / count( $blanks );
			case 'matching':
				$pairs = (array) ( $key['pairs'] ?? array() );
				if ( ! $pairs ) {
					return 0.0;
				}
				$ans = (array) $answer;
				$ok  = 0;
				foreach ( $pairs as $l => $r ) {
					if ( isset( $ans[ $l ] ) && (string) $ans[ $l ] === (string) $r ) {
						++$ok;
					}
				}
				return $ok / count( $pairs );
			case 'ordering':
				$given = array_map( 'strval', array_values( (array) $answer ) );
				$order = array_map( 'strval', array_values( (array) ( $key['order'] ?? array() ) ) );
				if ( 'partial' === ( $key['scoring'] ?? '' ) ) {
					// Partial: share of items placed in their correct absolute position.
					if ( ! $order ) {
						return 0.0;
					}
					$ok = 0;
					foreach ( $order as $i => $id ) {
						if ( ( $given[ $i ] ?? null ) === $id ) {
							++$ok;
						}
					}
					return $ok / count( $order );
				}
				return $given === $order ? 1.0 : 0.0;
			case 'code':
				$g = self::norm_code( (string) ( is_scalar( $answer ) ? $answer : '' ) );
				if ( '' === $g ) {
					return 0.0;
				}
				foreach ( (array) ( $key['expected'] ?? array() ) as $e ) {
					if ( self::norm_code( (string) $e ) === $g ) {
						return 1.0;
					}
				}
				return 0.0;
		}
		return 0.0;
	}

	/** Sanitise a student answer to a bounded JSON-able structure. */
	public static function sanitize_answer( string $type, $answer ) {
		switch ( $type ) {
			case 'multiple':
			case 'ordering':
			case 'fill_blanks':
				return array_slice( array_map( static fn( $v ) => sanitize_text_field( (string) $v ), array_values( (array) $answer ) ), 0, 100 );
			case 'matching':
				$out = array();
				foreach ( array_slice( (array) $answer, 0, 100, true ) as $k => $v ) {
					$out[ sanitize_key( (string) $k ) ] = sanitize_key( (string) $v );
				}
				return $out;
			case 'truefalse':
				if ( is_bool( $answer ) ) {
					return $answer;
				}
				return in_array( (string) $answer, array( 'true', 'false' ), true ) ? 'true' === (string) $answer : null;
			case 'essay':
			case 'code':
				return mb_substr( sanitize_textarea_field( (string) ( is_scalar( $answer ) ? $answer : '' ) ), 0, 20000 );
			default:
				return mb_substr( sanitize_text_field( (string) ( is_scalar( $answer ) ? $answer : '' ) ), 0, 1000 );
		}
	}
}
