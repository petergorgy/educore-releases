<?php
namespace EduCore\Certificates;

use EduCore\Core\I18n;

defined( 'ABSPATH' ) || exit;

/** Certificate templates (CPT ec_cert_template) with placeholder bodies and styling meta. */
final class Templates {
	public const PLACEHOLDERS = array( '{student_name}', '{course_title}', '{issue_date}', '{certificate_id}', '{verify_url}' );

	/** @return array<string,array{title:string,heading:string,body:string,sig_name:string,sig_title:string}> */
	public static function defaults(): array {
		return array(
			'en' => array( 'title' => 'Default certificate (English)', 'heading' => 'Certificate of Completion', 'body' => "This certifies that\n{student_name}\nhas successfully completed the course\n{course_title}\non {issue_date}.", 'sig_name' => 'EduCore', 'sig_title' => 'Academic Director' ),
			'fr' => array( 'title' => 'Attestation par défaut (français)', 'heading' => 'Attestation de réussite', 'body' => "Nous certifions que\n{student_name}\na suivi avec succès le cours\n{course_title}\nle {issue_date}.", 'sig_name' => 'EduCore', 'sig_title' => 'Direction pédagogique' ),
			'ar' => array( 'title' => 'الشهادة الافتراضية (العربية)', 'heading' => 'شهادة إتمام', 'body' => "نشهد بأن\n{student_name}\nقد أتمّ بنجاح مقرر\n{course_title}\nبتاريخ {issue_date}.", 'sig_name' => 'EduCore', 'sig_title' => 'المدير الأكاديمي' ),
		);
	}

	/** Create the three default templates once. Idempotent. */
	public static function ensure_defaults(): array {
		$ids = (array) get_option( 'educore_cert_default_templates', array() );
		foreach ( self::defaults() as $lang => $d ) {
			if ( ! empty( $ids[ $lang ] ) && get_post( (int) $ids[ $lang ] ) ) {
				continue;
			}
			$id = (int) wp_insert_post( array( 'post_type' => Plugin::TEMPLATE, 'post_status' => 'publish', 'post_title' => $d['title'] ) );
			update_post_meta( $id, '_ec_cert_heading', $d['heading'] );
			update_post_meta( $id, '_ec_cert_body', $d['body'] );
			update_post_meta( $id, '_ec_cert_orientation', 'L' );
			update_post_meta( $id, '_ec_cert_accent', '#0b7f7a' );
			update_post_meta( $id, '_ec_cert_sig_name', $d['sig_name'] );
			update_post_meta( $id, '_ec_cert_sig_title', $d['sig_title'] );
			update_post_meta( $id, '_ec_cert_lang', $lang );
			$ids[ $lang ] = $id;
		}
		update_option( 'educore_cert_default_templates', $ids, false );
		return $ids;
	}

	/** Course template (meta _ec_cert_template) or the default in the learner's language. */
	public static function for_course( int $course_id, int $user_id ): int {
		$tpl = (int) get_post_meta( $course_id, '_ec_cert_template', true );
		if ( $tpl && get_post_type( $tpl ) === Plugin::TEMPLATE && 'publish' === get_post_status( $tpl ) ) {
			return $tpl;
		}
		$ids  = self::ensure_defaults();
		$lang = I18n::sanitize_lang( get_user_meta( $user_id, 'educore_lang', true ) ?: 'en' );
		return (int) ( $ids[ $lang ] ?? $ids['en'] );
	}

	/** @return array{heading:string,body:string,orientation:string,accent:string,sig_name:string,sig_title:string,lang:string} */
	public static function get( int $template_id ): array {
		$m = static fn( $k, $d = '' ) => (string) ( get_post_meta( $template_id, $k, true ) ?: $d );
		$accent = $m( '_ec_cert_accent', '#0b7f7a' );
		return array(
			'heading'     => $m( '_ec_cert_heading', 'Certificate of Completion' ),
			'body'        => $m( '_ec_cert_body', self::defaults()['en']['body'] ),
			'orientation' => 'P' === $m( '_ec_cert_orientation', 'L' ) ? 'P' : 'L',
			'accent'      => preg_match( '/^#[0-9a-fA-F]{6}$/', $accent ) ? $accent : '#0b7f7a',
			'sig_name'    => $m( '_ec_cert_sig_name' ),
			'sig_title'   => $m( '_ec_cert_sig_title' ),
			'lang'        => I18n::sanitize_lang( $m( '_ec_cert_lang', 'en' ) ),
		);
	}

	public static function fill( string $text, array $vars ): string {
		return str_replace( self::PLACEHOLDERS, array( $vars['student_name'], $vars['course_title'], $vars['issue_date'], $vars['certificate_id'], $vars['verify_url'] ), $text );
	}
}
