<?php
namespace EduCore\Assessments\Exchange;

defined( 'ABSPATH' ) || exit;

/**
 * Import and export EduCore question banks.
 */
final class Cli {

	/**
	 * Export a course question bank.
	 *
	 * <course>
	 * : Course ID.
	 *
	 * --file=<path>
	 * : Output file.
	 *
	 * [--format=<format>]
	 * : native, xlsx, csv, json, moodlexml, gift. Default: native.
	 *
	 * [--status=<status>]
	 * : Only this status.
	 *
	 * @param array $args
	 * @param array $assoc
	 */
	public function export( $args, $assoc ): void {
		$format = $assoc['format'] ?? 'native';
		if ( ! isset( Formats::all()[ $format ] ) ) {
			\WP_CLI::error( 'Unknown format.' );
		}
		$x = Exporter::export( (int) $args[0], $format, array( 'status' => $assoc['status'] ?? '' ) );
		file_put_contents( $assoc['file'], $x['bytes'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		foreach ( $x['skipped'] as $s ) {
			\WP_CLI::warning( 'Not exported: ' . $s );
		}
		\WP_CLI::success( sprintf( 'Exported %d questions (%d skipped) to %s', $x['count'] - count( $x['skipped'] ), count( $x['skipped'] ), $assoc['file'] ) );
	}

	/**
	 * Import a file into a course question bank (validates first; --dry-run stops after the preview).
	 *
	 * <course>
	 * : Course ID.
	 *
	 * <file>
	 * : Input file.
	 *
	 * [--format=<format>]
	 * : Default: detect.
	 *
	 * [--mode=<mode>]
	 * : skip (default), update or duplicate.
	 *
	 * [--status=<status>]
	 * : Force draft, review or published.
	 *
	 * [--lang=<lang>]
	 * : Language when the file does not say.
	 *
	 * [--dry-run]
	 * : Validate and preview only.
	 *
	 * @param array $args
	 * @param array $assoc
	 */
	public function import( $args, $assoc ): void {
		if ( ! get_current_user_id() ) {
			\WP_CLI::error( 'Run with --user=<administrator or instructor> so permissions and authorship are recorded.' );
		}
		$job = Jobs::create( (int) $args[0], $args[1], basename( $args[1] ), $assoc['format'] ?? 'auto', $assoc );
		if ( is_wp_error( $job ) ) {
			\WP_CLI::error( $job->get_error_message() );
		}
		$this->print_job( $job );
		if ( ! empty( $assoc['dry-run'] ) ) {
			Jobs::cancel( $job );
			\WP_CLI::success( "Dry run: nothing imported (job {$job} cancelled)." );
			return;
		}
		$r = Jobs::commit( $job );
		if ( is_wp_error( $r ) ) {
			\WP_CLI::error( $r->get_error_message() );
		}
		\WP_CLI::success( "Job {$job}: " . wp_json_encode( $r['results'] ) . ( $r['invalid'] ? " — {$r['invalid']} invalid rows not imported" : '' ) );
	}

	private function print_job( int $job ): void {
		$rows = array();
		foreach ( Jobs::items( $job ) as $it ) {
			$m      = (array) json_decode( (string) $it['messages'], true );
			$rows[] = array( 'line' => $it['line'], 'status' => $it['status'], 'action' => $it['action'], 'external_id' => $it['external_id'], 'messages' => implode( ' | ', array_map( static fn( $x ) => ( 'e' === $x[0] ? 'ERROR ' : 'warn ' ) . $x[1], $m ) ) );
		}
		\WP_CLI\Utils\format_items( 'table', $rows, array( 'line', 'status', 'action', 'external_id', 'messages' ) );
	}
}
