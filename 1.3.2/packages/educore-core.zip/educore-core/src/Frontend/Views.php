<?php
namespace EduCore\Core\Frontend;

use EduCore\Core\Access;
use EduCore\Core\Announcements;
use EduCore\Core\Catalog;
use EduCore\Core\Content;
use EduCore\Core\Curriculum;
use EduCore\Core\Dashboard;
use EduCore\Core\Enrollment;
use EduCore\Core\I18n;
use EduCore\Core\Pages;
use EduCore\Core\Privacy;
use EduCore\Core\Profile;
use EduCore\Core\Progress;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/** Server-rendered views. All output is escaped at the point of output. */
final class Views {

	/* ---------- small helpers ---------- */

	public static function progress_bar( int $percent, string $label = '' ): string {
		$percent = max( 0, min( 100, $percent ) );
		return sprintf(
			'<div class="ec-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="%1$d" aria-label="%2$s"><span class="ec-progress__bar" style="--ec-p:%1$d%%"></span></div>',
			$percent,
			esc_attr( $label ?: __( 'Progress', 'educore-core' ) )
		);
	}

	public static function notice( string $text, string $type = 'info' ): string {
		return '<div class="ec-notice ec-notice--' . esc_attr( $type ) . '" role="' . ( 'error' === $type ? 'alert' : 'status' ) . '">' . esc_html( $text ) . '</div>';
	}

	public static function flash(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only message code.
		$code = isset( $_GET['ec_msg'] ) ? sanitize_key( wp_unslash( $_GET['ec_msg'] ) ) : '';
		$map  = array(
			'saved'          => array( __( 'Your changes were saved.', 'educore-core' ), 'success' ),
			'registered'     => array( __( 'Welcome! Your account is ready.', 'educore-core' ), 'success' ),
			'pending'        => array( __( 'Your account was created. We e-mailed your parent or guardian — you can start learning as soon as they confirm.', 'educore-core' ), 'info' ),
			'sent'           => array( __( 'Thank you — your message was sent to our support team.', 'educore-core' ), 'success' ),
			'consent_ok'     => array( __( 'Thank you. Your consent has been recorded.', 'educore-core' ), 'success' ),
			'consent_no'     => array( __( 'Your decision has been recorded. The account will not be able to start learning.', 'educore-core' ), 'info' ),
			'error'          => array( __( 'Something went wrong. Please check the form and try again.', 'educore-core' ), 'error' ),
			'throttled'      => array( __( 'Too many attempts. Please wait a little and try again.', 'educore-core' ), 'error' ),
			'exists'         => array( __( 'An account with this e-mail already exists. Please log in.', 'educore-core' ), 'error' ),
			'bad_mobile'     => array( __( 'Please enter a valid Egyptian mobile number, e.g. 01012345678.', 'educore-core' ), 'error' ),
			'guardian_email' => array( __( 'Learners under 18 must provide a valid parent or guardian e-mail address (different from their own).', 'educore-core' ), 'error' ),
			'weak_password'  => array( __( 'Please choose a password of at least 10 characters.', 'educore-core' ), 'error' ),
			'consent'        => array( __( 'Please accept the Terms of Service and Privacy Policy to continue.', 'educore-core' ), 'error' ),
			'bad_upload'     => array( __( 'Profile pictures must be JPG, PNG or WebP images under 1 MB.', 'educore-core' ), 'error' ),
		);
		return isset( $map[ $code ] ) ? self::notice( $map[ $code ][0], $map[ $code ][1] ) : '';
	}

	private static function login_prompt( string $why ): string {
		$here = esc_url( home_url( add_query_arg( array() ) ) );
		return '<div class="ec-card ec-gate">' .
			'<p>' . esc_html( $why ) . '</p>' .
			'<p class="ec-actions"><a class="ec-btn ec-btn--primary" href="' . esc_url( wp_login_url( $here ) ) . '">' . esc_html__( 'Log in', 'educore-core' ) . '</a> ' .
			( Pages::registration_open()
				? '<a class="ec-btn" href="' . esc_url( add_query_arg( 'redirect_to', rawurlencode( $here ), Pages::url( 'register' ) ) ) . '">' . esc_html__( 'Create an account', 'educore-core' ) . '</a>'
				: '<a class="ec-btn" href="' . esc_url( Pages::url( 'contact' ) ) . '">' . esc_html__( 'Request access', 'educore-core' ) . '</a>' ) . '</p></div>';
	}

	private static function chip( string $text ): string {
		return '' === $text ? '' : '<span class="ec-chip">' . esc_html( $text ) . '</span>';
	}

	public static function difficulty_label( string $d ): string {
		$map = array( 'beginner' => __( 'Beginner', 'educore-core' ), 'intermediate' => __( 'Intermediate', 'educore-core' ), 'advanced' => __( 'Advanced', 'educore-core' ) );
		return $map[ $d ] ?? '';
	}

	/* ---------- gating ---------- */

	public static function gate( int $course_id ): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return self::login_prompt( __( 'Log in to open this lesson.', 'educore-core' ) );
		}
		if ( ! Privacy::has_required_consent( $uid ) ) {
			return self::notice( __( 'Your account is waiting for guardian consent. Lessons unlock as soon as your parent or guardian confirms.', 'educore-core' ), 'info' );
		}
		$enrollment = Enrollment::get( $uid, $course_id );
		if ( $enrollment && in_array( $enrollment['status'], array( 'expired', 'suspended' ), true ) ) {
			return self::notice( __( 'Your access to this course has ended. Contact support or renew your access to continue.', 'educore-core' ), 'info' );
		}
		return '<div class="ec-card ec-gate"><p>' . esc_html__( 'This lesson is part of a course you are not enrolled in yet.', 'educore-core' ) . '</p>' . self::enroll_button( $course_id ) . '</div>';
	}

	public static function enroll_button( int $course_id ): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return '<a class="ec-btn ec-btn--primary" href="' . esc_url( wp_login_url( get_permalink( $course_id ) ) ) . '">' . esc_html__( 'Log in to enroll', 'educore-core' ) . '</a>';
		}
		if ( Access::can_access_course( $uid, $course_id ) ) {
			$s    = Progress::course_summary( $uid, $course_id );
			$url  = $s['next_lesson'] ? get_permalink( $s['next_lesson'] ) : get_permalink( $course_id );
			$text = $s['completed'] ? __( 'Continue learning', 'educore-core' ) : __( 'Start learning', 'educore-core' );
			return '<a class="ec-btn ec-btn--primary" href="' . esc_url( $url ) . '">' . esc_html( $text ) . '</a>';
		}
		/** Commerce replaces this for paid courses. */
		$custom = apply_filters( 'educore/course/enroll_cta', '', $course_id, $uid );
		if ( '' !== $custom ) {
			return $custom;
		}
		if ( Access::can_self_enroll( $uid, $course_id ) ) {
			return '<button type="button" class="ec-btn ec-btn--primary" data-ec-action="enroll" data-course="' . esc_attr( (string) $course_id ) . '">' . esc_html__( 'Enroll for free', 'educore-core' ) . '</button>';
		}
		return '<p class="ec-muted">' . esc_html__( 'Enrollment is managed by your school or instructor.', 'educore-core' ) . '</p>';
	}

	/* ---------- catalogue ---------- */

	public static function course_card( array $c ): string {
		$img = $c['image'] ? '<img src="' . esc_url( $c['image'] ) . '" alt="" loading="lazy" decoding="async">' : '<span class="ec-card__placeholder" aria-hidden="true"></span>';
		$out  = '<article class="ec-course-card ec-reveal">';
		$out .= '<a class="ec-course-card__media" href="' . esc_url( $c['url'] ) . '" tabindex="-1" aria-hidden="true">' . $img . '</a>';
		$out .= '<div class="ec-course-card__body">';
		$labels = I18n::labels();
		$out   .= '<p class="ec-course-card__eyebrow">' . esc_html( $c['subject'] ?: $c['programme'] ) . ( ! empty( $c['lang'] ) && I18n::DEFAULT !== $c['lang'] ? ' <span class="ec-chip" lang="' . esc_attr( $c['lang'] ) . '">' . esc_html( $labels[ $c['lang'] ] ?? '' ) . '</span>' : '' ) . '</p>';
		$out .= '<h3 class="ec-course-card__title"><a href="' . esc_url( $c['url'] ) . '">' . esc_html( $c['title'] ) . '</a></h3>';
		$out .= '<p class="ec-course-card__excerpt">' . esc_html( wp_trim_words( $c['excerpt'], 22 ) ) . '</p>';
		/* translators: %d: number of lessons */
		$out .= '<p class="ec-chips">' . self::chip( self::difficulty_label( $c['difficulty'] ) ) . self::chip( sprintf( _n( '%d lesson', '%d lessons', $c['lesson_count'], 'educore-core' ), $c['lesson_count'] ) ) . ( $c['hours'] ? self::chip( sprintf( /* translators: %d hours */ _n( '%d hour', '%d hours', $c['hours'], 'educore-core' ), $c['hours'] ) ) : '' ) . '</p>';
		$price = $c['price_label'] ?: ( 'paid' === $c['enroll_mode'] ? '' : __( 'Free', 'educore-core' ) );
		$out  .= '<p class="ec-course-card__footer"><span class="ec-price">' . esc_html( $price ) . '</span>';
		if ( ! empty( $c['instructors'][0]['name'] ) ) {
			$out .= '<span class="ec-muted">' . esc_html( $c['instructors'][0]['name'] ) . '</span>';
		}
		$out .= '</p></div></article>';
		return $out;
	}

	public static function catalog( array $attrs = array() ): string {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filter form.
		$p = array(
			'q'          => isset( $_GET['ec_q'] ) ? sanitize_text_field( wp_unslash( $_GET['ec_q'] ) ) : '',
			'subject'    => isset( $_GET['ec_subject'] ) ? absint( $_GET['ec_subject'] ) : 0,
			'difficulty' => isset( $_GET['ec_level'] ) ? sanitize_key( wp_unslash( $_GET['ec_level'] ) ) : '',
			'price'      => isset( $_GET['ec_price'] ) ? sanitize_key( wp_unslash( $_GET['ec_price'] ) ) : '',
			'lang'       => isset( $_GET['ec_lang'] ) ? sanitize_key( wp_unslash( $_GET['ec_lang'] ) ) : '',
			'instructor' => isset( $_GET['ec_instructor'] ) ? absint( $_GET['ec_instructor'] ) : 0,
			'page'       => isset( $_GET['ec_page'] ) ? max( 1, absint( $_GET['ec_page'] ) ) : 1,
			'per_page'   => (int) ( $attrs['perPage'] ?? 12 ),
		);
		$mine = isset( $_GET['ec_mine'] ) && is_user_logged_in();
		// phpcs:enable
		$res = Catalog::search( $p );

		$out  = '<div class="ec-catalog">';
		$out .= '<form class="ec-filters" method="get" role="search" aria-label="' . esc_attr__( 'Filter courses', 'educore-core' ) . '">';
		$out .= '<label class="ec-field ec-field--grow"><span>' . esc_html__( 'Search', 'educore-core' ) . '</span><input type="search" name="ec_q" value="' . esc_attr( $p['q'] ) . '" placeholder="' . esc_attr__( 'Search courses…', 'educore-core' ) . '"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Subject', 'educore-core' ) . '</span><select name="ec_subject"><option value="0">' . esc_html__( 'All subjects', 'educore-core' ) . '</option>';
		foreach ( Curriculum::subjects() as $s ) {
			$out .= '<option value="' . esc_attr( $s['id'] ) . '"' . selected( $p['subject'], (int) $s['id'], false ) . '>' . esc_html( $s['name'] ) . '</option>';
		}
		$out .= '</select></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Level', 'educore-core' ) . '</span><select name="ec_level"><option value="">' . esc_html__( 'Any level', 'educore-core' ) . '</option>';
		foreach ( array( 'beginner', 'intermediate', 'advanced' ) as $d ) {
			$out .= '<option value="' . esc_attr( $d ) . '"' . selected( $p['difficulty'], $d, false ) . '>' . esc_html( self::difficulty_label( $d ) ) . '</option>';
		}
		$out .= '</select></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Price', 'educore-core' ) . '</span><select name="ec_price"><option value="">' . esc_html__( 'Any', 'educore-core' ) . '</option><option value="free"' . selected( $p['price'], 'free', false ) . '>' . esc_html__( 'Free', 'educore-core' ) . '</option><option value="paid"' . selected( $p['price'], 'paid', false ) . '>' . esc_html__( 'Paid', 'educore-core' ) . '</option></select></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Course language', 'educore-core' ) . '</span><select name="ec_lang"><option value="">' . esc_html__( 'Any', 'educore-core' ) . '</option>';
		foreach ( I18n::labels() as $code => $label ) {
			$out .= '<option value="' . esc_attr( $code ) . '" lang="' . esc_attr( $code ) . '"' . selected( $p['lang'], $code, false ) . '>' . esc_html( $label ) . '</option>';
		}
		$out .= '</select></label>';
		if ( is_user_logged_in() ) {
			$out .= '<label class="ec-check"><input type="checkbox" name="ec_mine" value="1"' . checked( $mine, true, false ) . '> ' . esc_html__( 'My courses only', 'educore-core' ) . '</label>';
		}
		$out .= '<button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Apply', 'educore-core' ) . '</button></form>';

		$posts = $res['posts'];
		if ( $mine ) {
			$uid   = get_current_user_id();
			$posts = array_values( array_filter( $posts, static fn( $post ) => Enrollment::is_enrolled( $uid, $post->ID, false ) ) );
		}
		/* translators: %d: number of courses */
		$out .= '<p class="ec-muted" aria-live="polite">' . esc_html( sprintf( _n( '%d course found', '%d courses found', $mine ? count( $posts ) : $res['total'], 'educore-core' ), $mine ? count( $posts ) : $res['total'] ) ) . '</p>';
		if ( empty( $posts ) ) {
			$out .= '<div class="ec-empty">' . esc_html__( 'No courses match your filters yet.', 'educore-core' ) . '</div>';
		} else {
			$out .= '<div class="ec-grid">';
			foreach ( $posts as $post ) {
				$out .= self::course_card( Catalog::card( $post ) );
			}
			$out .= '</div>';
		}
		if ( $res['pages'] > 1 && ! $mine ) {
			$out .= '<nav class="ec-pagination" aria-label="' . esc_attr__( 'Pages', 'educore-core' ) . '">';
			for ( $i = 1; $i <= $res['pages']; $i++ ) {
				$out .= $i === $p['page']
					? '<span aria-current="page" class="ec-page is-current">' . esc_html( (string) $i ) . '</span>'
					: '<a class="ec-page" href="' . esc_url( add_query_arg( 'ec_page', $i ) ) . '">' . esc_html( (string) $i ) . '</a>';
			}
			$out .= '</nav>';
		}
		return $out . '</div>';
	}

	public static function featured( array $attrs = array() ): string {
		$res = Catalog::search( array( 'per_page' => (int) ( $attrs['count'] ?? 3 ) ) );
		if ( empty( $res['posts'] ) ) {
			return '<div class="ec-empty">' . esc_html__( 'Courses will appear here once they are published.', 'educore-core' ) . '</div>';
		}
		$out = '<div class="ec-grid">';
		foreach ( $res['posts'] as $post ) {
			$out .= self::course_card( Catalog::card( $post ) );
		}
		return $out . '</div>';
	}

	public static function subjects(): string {
		$subjects = Curriculum::subjects();
		if ( empty( $subjects ) ) {
			return '';
		}
		$out = '<ul class="ec-subjects">';
		foreach ( $subjects as $s ) {
			$out .= '<li><a class="ec-subject ec-reveal" href="' . esc_url( add_query_arg( 'ec_subject', (int) $s['id'], Pages::url( 'courses' ) ) ) . '">' . esc_html( $s['name'] ) . '</a></li>';
		}
		return $out . '</ul>';
	}

	/* ---------- course details ---------- */

	public static function course_block(): string {
		$id = (int) get_queried_object_id();
		if ( ! Content::is_course( $id ) ) {
			return '';
		}
		return Gate::guarded( static fn() => self::course_details( $id, apply_filters( 'the_content', get_post_field( 'post_content', $id ) ) ) );
	}

	public static function course_details( int $course_id, string $description ): string {
		$d   = Catalog::details( $course_id );
		$uid = get_current_user_id();
		$out = '<div class="ec-course">';
		$out .= '<header class="ec-course__hero"><div class="ec-course__intro">';
		$out .= '<p class="ec-course-card__eyebrow">' . esc_html( trim( $d['programme'] . ( $d['subject'] ? ' · ' . $d['subject'] : '' ), ' ·' ) ) . '</p>';
		$out .= '<p class="ec-lead">' . esc_html( $d['excerpt'] ) . '</p>';
		/* translators: %d: number of lessons */
		$out .= '<p class="ec-chips">' . self::chip( self::difficulty_label( $d['difficulty'] ) ) . self::chip( $d['grade_level'] ) . self::chip( sprintf( _n( '%d lesson', '%d lessons', $d['lesson_count'], 'educore-core' ), $d['lesson_count'] ) );
		if ( $d['hours'] ) {
			/* translators: %d: hours */
			$out .= self::chip( sprintf( _n( '%d hour', '%d hours', $d['hours'], 'educore-core' ), $d['hours'] ) );
		} elseif ( $d['total_minutes'] ) {
			/* translators: %d: minutes */
			$out .= self::chip( sprintf( __( '%d min', 'educore-core' ), $d['total_minutes'] ) );
		}
		$out .= '</p></div><div class="ec-course__cta ec-card">';
		if ( $d['price_label'] ) {
			$out .= '<p class="ec-price ec-price--lg">' . esc_html( $d['price_label'] ) . '</p>';
		}
		if ( $uid && Access::can_access_course( $uid, $course_id ) ) {
			$s    = Progress::course_summary( $uid, $course_id );
			/* translators: 1: completed, 2: total */
			$out .= '<p>' . esc_html( sprintf( __( '%1$d of %2$d lessons completed', 'educore-core' ), $s['completed'], $s['total'] ) ) . '</p>' . self::progress_bar( $s['percent'] );
		}
		$out .= self::enroll_button( $course_id ) . '</div></header>';

		if ( $d['objectives'] ) {
			$out .= '<section class="ec-section"><h2>' . esc_html__( 'What you will learn', 'educore-core' ) . '</h2><ul class="ec-checklist">';
			foreach ( $d['objectives'] as $o ) {
				$out .= '<li>' . esc_html( $o ) . '</li>';
			}
			$out .= '</ul></section>';
		}
		if ( trim( wp_strip_all_tags( $description ) ) ) {
			$out .= '<section class="ec-section ec-prose">' . $description . '</section>'; // Already filtered post content.
		}
		$out .= '<section class="ec-section"><h2>' . esc_html__( 'Syllabus', 'educore-core' ) . '</h2>';
		if ( empty( $d['outline'] ) ) {
			$out .= '<p class="ec-muted">' . esc_html__( 'The syllabus will be published soon.', 'educore-core' ) . '</p>';
		}
		$completed = $uid ? Progress::completed_ids( $uid, $course_id ) : array();
		$can       = $uid && Access::can_access_course( $uid, $course_id );
		foreach ( $d['outline'] as $i => $unit ) {
			$out .= '<details class="ec-unit"' . ( 0 === $i ? ' open' : '' ) . '><summary><span class="ec-unit__title">' . esc_html( $unit['title'] ) . '</span>';
			/* translators: %d: number of lessons */
			$out .= '<span class="ec-muted">' . esc_html( sprintf( _n( '%d lesson', '%d lessons', count( $unit['lessons'] ), 'educore-core' ), count( $unit['lessons'] ) ) ) . '</span></summary><ol class="ec-lessons">';
			foreach ( $unit['lessons'] as $l ) {
				$done  = in_array( $l['id'], $completed, true );
				$title = esc_html( $l['title'] );
				$out  .= '<li class="' . ( $done ? 'is-done' : '' ) . '">' . ( $can ? '<a href="' . esc_url( get_permalink( $l['id'] ) ) . '">' . $title . '</a>' : '<span>' . $title . '</span>' );
				$out  .= $l['minutes'] ? ' <span class="ec-muted">' . esc_html( sprintf( /* translators: %d minutes */ __( '%d min', 'educore-core' ), $l['minutes'] ) ) . '</span>' : '';
				$out  .= $done ? ' <span class="ec-badge-done">' . esc_html__( 'Completed', 'educore-core' ) . '</span>' : '';
				$out  .= '</li>';
			}
			$out .= '</ol></details>';
		}
		$out .= '</section>';
		if ( $d['prerequisites'] ) {
			$out .= '<section class="ec-section"><h2>' . esc_html__( 'Prerequisites', 'educore-core' ) . '</h2><p>' . nl2br( esc_html( $d['prerequisites'] ) ) . '</p></section>';
		}
		if ( $d['assessment_reqs'] ) {
			$out .= '<section class="ec-section"><h2>' . esc_html__( 'Assessment requirements', 'educore-core' ) . '</h2><p>' . nl2br( esc_html( $d['assessment_reqs'] ) ) . '</p></section>';
		}
		if ( $d['instructors'] ) {
			$out .= '<section class="ec-section"><h2>' . esc_html__( 'Instructors', 'educore-core' ) . '</h2><div class="ec-instructors">';
			foreach ( $d['instructors'] as $ins ) {
				$out .= '<div class="ec-instructor ec-card">' . get_avatar( $ins['id'], 56, '', '', array( 'loading' => 'lazy' ) ) . '<div><strong>' . esc_html( $ins['name'] ) . '</strong><p class="ec-muted">' . esc_html( wp_trim_words( $ins['bio'], 30 ) ) . '</p></div></div>';
			}
			$out .= '</div></section>';
		}
		$out .= apply_filters( 'educore/course/after_details', '', $course_id );
		return $out . '</div>';
	}

	/* ---------- lesson reader ---------- */

	public static function lesson_block(): string {
		$id = (int) get_queried_object_id();
		if ( get_post_type( $id ) !== Content::LESSON ) {
			return '';
		}
		if ( ! Access::can_view_lesson( get_current_user_id(), $id ) ) {
			return self::gate( Content::course_of( $id ) );
		}
		return Gate::guarded( static fn() => self::lesson_reader( $id, apply_filters( 'the_content', get_post_field( 'post_content', $id ) ) ) );
	}

	public static function lesson_reader( int $lesson_id, string $content ): string {
		$uid       = get_current_user_id();
		$course_id = Content::course_of( $lesson_id );
		$unit_id   = (int) get_post_meta( $lesson_id, '_ec_unit_id', true );
		$rule      = Progress::rule( $lesson_id );
		if ( $uid ) {
			Progress::touch( $uid, $lesson_id );
		}
		$summary   = $uid ? Progress::course_summary( $uid, $course_id ) : array( 'percent' => 0, 'completed' => 0, 'total' => 0 );
		$completed = $uid ? Progress::completed_ids( $uid, $course_id ) : array();
		$nb        = Content::neighbours( $lesson_id );
		$done      = in_array( $lesson_id, $completed, true );

		$out  = '<div class="ec-reader" data-lesson="' . esc_attr( (string) $lesson_id ) . '" data-rule="' . esc_attr( $rule ) . '">';
		$out .= '<div class="ec-reading-progress" aria-hidden="true"><span></span></div>';
		$out .= '<button type="button" class="ec-btn ec-reader__toggle" aria-expanded="false" aria-controls="ec-outline">' . esc_html__( 'Course contents', 'educore-core' ) . '</button>';
		$out .= '<aside class="ec-reader__sidebar" id="ec-outline" aria-label="' . esc_attr__( 'Course contents', 'educore-core' ) . '">';
		$out .= '<p class="ec-reader__course"><a href="' . esc_url( get_permalink( $course_id ) ) . '">' . esc_html( get_the_title( $course_id ) ) . '</a></p>';
		/* translators: %d: percent */
		$out .= self::progress_bar( $summary['percent'], sprintf( __( 'Course progress %d%%', 'educore-core' ), $summary['percent'] ) );
		$out .= '<nav><ol class="ec-outline">';
		foreach ( Content::outline( $course_id ) as $row ) {
			$out .= '<li class="ec-outline__unit"><span>' . esc_html( get_the_title( $row['unit'] ) ) . '</span><ol>';
			foreach ( $row['lessons'] as $l ) {
				$cls  = array();
				$cls[] = in_array( $l->ID, $completed, true ) ? 'is-done' : '';
				$cls[] = $l->ID === $lesson_id ? 'is-current' : '';
				$out  .= '<li class="' . esc_attr( trim( implode( ' ', $cls ) ) ) . '"><a href="' . esc_url( get_permalink( $l ) ) . '"' . ( $l->ID === $lesson_id ? ' aria-current="page"' : '' ) . '>' . esc_html( get_the_title( $l ) ) . '</a></li>';
			}
			$out .= '</ol></li>';
		}
		$out .= '</ol></nav></aside>';

		$out .= '<article class="ec-reader__main">';
		$out .= '<header class="ec-reader__header"><p class="ec-breadcrumb"><a href="' . esc_url( get_permalink( $course_id ) ) . '">' . esc_html( get_the_title( $course_id ) ) . '</a>' . ( $unit_id ? ' <span aria-hidden="true">›</span> ' . esc_html( get_the_title( $unit_id ) ) : '' ) . '</p>';
		$out .= '<h1 class="ec-reader__title">' . esc_html( get_the_title( $lesson_id ) ) . '</h1>';
		$minutes = (int) get_post_meta( $lesson_id, '_ec_minutes', true );
		$out .= '<p class="ec-chips">' . ( $minutes ? self::chip( sprintf( /* translators: %d minutes */ __( '%d min', 'educore-core' ), $minutes ) ) : '' );
		if ( $uid ) {
			$out .= ' <button type="button" class="ec-btn ec-btn--ghost" data-ec-action="bookmark">' . esc_html__( 'Bookmark', 'educore-core' ) . '</button>';
		}
		$out .= '</p></header>';

		$objectives = array_filter( array_map( 'trim', explode( "\n", (string) get_post_meta( $lesson_id, '_ec_objectives', true ) ) ) );
		if ( $objectives ) {
			$out .= '<section class="ec-callout"><h2>' . esc_html__( 'Learning objectives', 'educore-core' ) . '</h2><ul class="ec-checklist">';
			foreach ( $objectives as $o ) {
				$out .= '<li>' . esc_html( $o ) . '</li>';
			}
			$out .= '</ul></section>';
		}
		$out .= '<div class="ec-prose ec-lesson-content">' . $content . '</div>';

		$files = get_attached_media( '', $lesson_id );
		$files = array_filter( $files, static fn( $f ) => ! wp_attachment_is_image( $f->ID ) );
		if ( $files ) {
			$out .= '<section class="ec-section"><h2>' . esc_html__( 'Resources', 'educore-core' ) . '</h2><ul class="ec-resources">';
			foreach ( $files as $f ) {
				$out .= '<li><a href="' . esc_url( wp_get_attachment_url( $f->ID ) ) . '" download>' . esc_html( get_the_title( $f ) ) . '</a></li>';
			}
			$out .= '</ul></section>';
		}
		$summary_text = (string) get_post_meta( $lesson_id, '_ec_summary', true );
		if ( $summary_text ) {
			$out .= '<section class="ec-callout ec-callout--summary"><h2>' . esc_html__( 'Summary', 'educore-core' ) . '</h2><p>' . nl2br( esc_html( $summary_text ) ) . '</p></section>';
		}
		$out .= apply_filters( 'educore/lesson/after_content', '', $lesson_id, $uid );

		if ( $uid ) {
			$out .= '<div class="ec-complete" aria-live="polite">';
			if ( $done ) {
				$out .= '<p class="ec-badge-done ec-badge-done--lg">' . esc_html__( 'Lesson completed', 'educore-core' ) . '</p>';
			} elseif ( 'manual' === $rule ) {
				$out .= '<button type="button" class="ec-btn ec-btn--primary" data-ec-action="complete">' . esc_html__( 'Mark as complete', 'educore-core' ) . '</button>';
			} elseif ( 'time' === $rule ) {
				$out .= '<p class="ec-muted">' . esc_html__( 'This lesson completes automatically after enough active reading time.', 'educore-core' ) . '</p>';
			} else {
				$out .= '<p class="ec-muted">' . esc_html( (string) apply_filters( 'educore/lesson/rule_hint', __( 'This lesson completes automatically when its requirement is met.', 'educore-core' ), $rule, $lesson_id ) ) . '</p>';
			}
			$out .= '</div>';
			$out .= '<section class="ec-notes" aria-labelledby="ec-notes-h"><h2 id="ec-notes-h">' . esc_html__( 'My notes', 'educore-core' ) . '</h2>';
			$out .= '<form class="ec-notes__form" data-ec-form="note"><label class="screen-reader-text" for="ec-note-body">' . esc_html__( 'New note', 'educore-core' ) . '</label><textarea id="ec-note-body" name="body" rows="3" maxlength="5000" placeholder="' . esc_attr__( 'Write a private note…', 'educore-core' ) . '"></textarea><button class="ec-btn" type="submit">' . esc_html__( 'Save note', 'educore-core' ) . '</button></form><ul class="ec-notes__list" data-ec-notes></ul></section>';
		}
		$out .= '<nav class="ec-pager" aria-label="' . esc_attr__( 'Lesson navigation', 'educore-core' ) . '">';
		$out .= $nb['prev'] ? '<a class="ec-btn" rel="prev" href="' . esc_url( get_permalink( $nb['prev'] ) ) . '"><span class="ec-arrow" aria-hidden="true">←</span> ' . esc_html( get_the_title( $nb['prev'] ) ) . '</a>' : '<span></span>';
		$out .= $nb['next'] ? '<a class="ec-btn ec-btn--primary" rel="next" href="' . esc_url( get_permalink( $nb['next'] ) ) . '">' . esc_html( get_the_title( $nb['next'] ) ) . ' <span class="ec-arrow" aria-hidden="true">→</span></a>' : '';
		$out .= '</nav></article></div>';
		return $out;
	}

	/* ---------- student portal ---------- */

	public static function dashboard(): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return self::login_prompt( __( 'Log in to see your learning dashboard.', 'educore-core' ) );
		}
		$d   = Dashboard::student( $uid );
		$out = '<div class="ec-dashboard">' . self::flash();
		/* translators: %s: name */
		$out .= '<header class="ec-dashboard__head"><h2>' . esc_html( sprintf( __( 'Welcome back, %s', 'educore-core' ), $d['user']['name'] ) ) . '</h2>';
		if ( ! $d['consent'] ) {
			$out .= self::notice( __( 'Your account is waiting for guardian consent. You can browse courses, and learning unlocks once your parent or guardian confirms.', 'educore-core' ), 'info' );
		}
		$out .= '</header><div class="ec-stats">';
		$out .= '<div class="ec-stat ec-card"><span class="ec-stat__value">' . esc_html( (string) $d['overall']['percent'] ) . '%</span><span class="ec-stat__label">' . esc_html__( 'Overall progress', 'educore-core' ) . '</span>' . self::progress_bar( $d['overall']['percent'] ) . '</div>';
		$out .= '<div class="ec-stat ec-card"><span class="ec-stat__value">' . esc_html( (string) count( $d['courses'] ) ) . '</span><span class="ec-stat__label">' . esc_html__( 'Enrolled courses', 'educore-core' ) . '</span></div>';
		/* translators: 1: done, 2: target */
		$out .= '<div class="ec-stat ec-card"><span class="ec-stat__value">' . esc_html( sprintf( __( '%1$d / %2$d', 'educore-core' ), $d['goal']['done'], $d['goal']['target'] ) ) . '</span><span class="ec-stat__label">' . esc_html__( 'Lessons this week (goal)', 'educore-core' ) . '</span>' . self::progress_bar( (int) min( 100, $d['goal']['done'] * 100 / max( 1, $d['goal']['target'] ) ) ) . '</div>';
		if ( $d['xp'] ) {
			$out .= '<div class="ec-stat ec-card"><span class="ec-stat__value">' . esc_html( number_format_i18n( $d['xp'] ) ) . '</span><span class="ec-stat__label">' . esc_html__( 'Experience points', 'educore-core' ) . '</span></div>';
		}
		$out .= '</div>';

		if ( ! empty( $d['recommended'] ) ) {
			$first = $d['recommended'][0];
			$out  .= '<section class="ec-continue ec-card"><p class="ec-course-card__eyebrow">' . esc_html__( 'Continue learning', 'educore-core' ) . '</p><h3>' . esc_html( $first['title'] ) . '</h3><p class="ec-muted">' . esc_html( $first['course'] ) . '</p><a class="ec-btn ec-btn--primary" href="' . esc_url( $first['url'] ) . '">' . esc_html__( 'Resume', 'educore-core' ) . '</a></section>';
		}

		$out .= '<section class="ec-section"><h2>' . esc_html__( 'My courses', 'educore-core' ) . '</h2>';
		if ( empty( $d['courses'] ) ) {
			$out .= '<div class="ec-empty">' . esc_html__( 'You are not enrolled in any course yet.', 'educore-core' ) . ' <a href="' . esc_url( Pages::url( 'courses' ) ) . '">' . esc_html__( 'Browse courses', 'educore-core' ) . '</a></div>';
		} else {
			$out .= '<div class="ec-grid ec-grid--courses">';
			foreach ( $d['courses'] as $c ) {
				$out .= '<article class="ec-card ec-my-course"><h3><a href="' . esc_url( $c['url'] ) . '">' . esc_html( $c['title'] ) . '</a></h3>';
				/* translators: 1: completed, 2: total */
				$out .= '<p class="ec-muted">' . esc_html( sprintf( __( '%1$d of %2$d lessons', 'educore-core' ), $c['progress']['completed'], $c['progress']['total'] ) ) . '</p>' . self::progress_bar( $c['progress']['percent'] );
				if ( 'completed' === $c['status'] ) {
					$out .= '<p class="ec-badge-done">' . esc_html__( 'Course completed', 'educore-core' ) . '</p>';
				} elseif ( ! $c['accessible'] ) {
					$out .= '<p class="ec-muted">' . esc_html__( 'Access ended', 'educore-core' ) . '</p>';
				} else {
					$out .= '<a class="ec-btn" href="' . esc_url( $c['continue'] ) . '">' . esc_html__( 'Continue', 'educore-core' ) . '</a>';
				}
				$out .= '</article>';
			}
			$out .= '</div>';
		}
		$out .= '</section>';

		$sections = array(
			'upcoming'      => __( 'Upcoming assessments', 'educore-core' ),
			'pending'       => __( 'Pending work', 'educore-core' ),
			'results'       => __( 'Recent results', 'educore-core' ),
			'announcements' => __( 'Announcements', 'educore-core' ),
			'certificates'  => __( 'Certificates', 'educore-core' ),
		);
		$out .= '<div class="ec-columns">';
		foreach ( $sections as $key => $label ) {
			if ( empty( $d[ $key ] ) ) {
				continue;
			}
			$out .= '<section class="ec-card ec-list-card"><h2>' . esc_html( $label ) . '</h2><ul>';
			foreach ( $d[ $key ] as $item ) {
				$title = isset( $item['url'] ) && $item['url'] ? '<a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['title'] ) . '</a>' : esc_html( $item['title'] );
				$out  .= '<li>' . $title . ( ! empty( $item['meta'] ) ? ' <span class="ec-muted">' . esc_html( $item['meta'] ) . '</span>' : '' ) . '</li>';
			}
			$out .= '</ul></section>';
		}
		if ( $d['achievements'] ) {
			$out .= '<section class="ec-card ec-list-card"><h2>' . esc_html__( 'Achievements', 'educore-core' ) . '</h2><ul class="ec-badges">';
			foreach ( $d['achievements'] as $a ) {
				$out .= '<li class="ec-badge' . ( $a['earned'] ? ' is-earned' : '' ) . '"><span aria-hidden="true">' . ( $a['earned'] ? '★' : '☆' ) . '</span> ' . esc_html( $a['label'] ) . ( $a['earned'] ? '' : ' <span class="screen-reader-text">' . esc_html__( '(not yet earned)', 'educore-core' ) . '</span>' ) . '</li>';
			}
			$out .= '</ul></section>';
		}
		$out .= '</div>';
		$out .= '<p class="ec-actions"><a class="ec-btn ec-btn--ghost" href="' . esc_url( Pages::url( 'history' ) ) . '">' . esc_html__( 'Learning history', 'educore-core' ) . '</a> <a class="ec-btn ec-btn--ghost" href="' . esc_url( Pages::url( 'profile' ) ) . '">' . esc_html__( 'My profile', 'educore-core' ) . '</a></p>';
		/** Packages append dashboard sections (escaped HTML) — e.g. Teaching Hub: classes, assignments, tutoring. */
		$out .= (string) apply_filters( 'educore/dashboard/student_sections', '', $d, $uid );
		return $out . '</div>';
	}

	public static function history(): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return self::login_prompt( __( 'Log in to see your learning history.', 'educore-core' ) );
		}
		$h   = Dashboard::history( $uid );
		$out = '<div class="ec-history">';
		if ( $h['weekly'] ) {
			$max  = max( array_map( static fn( $w ) => (int) $w['n'], $h['weekly'] ) );
			$out .= '<section class="ec-section"><h2>' . esc_html__( 'Lessons completed per week', 'educore-core' ) . '</h2><ul class="ec-bars" role="list">';
			foreach ( $h['weekly'] as $w ) {
				$out .= '<li><span class="ec-bars__label">' . esc_html( date_i18n( get_option( 'date_format' ), strtotime( $w['week_start'] ) ) ) . '</span><span class="ec-bars__bar" style="--ec-p:' . esc_attr( (string) (int) ( $w['n'] * 100 / max( 1, $max ) ) ) . '%"></span><span class="ec-bars__value">' . esc_html( (string) (int) $w['n'] ) . '</span></li>';
			}
			$out .= '</ul></section>';
		}
		$tables = array(
			'completed_lessons' => array( __( 'Completed lessons', 'educore-core' ), array( 'lesson' => __( 'Lesson', 'educore-core' ), 'course' => __( 'Course', 'educore-core' ), 'completed_at' => __( 'Completed', 'educore-core' ), 'active_minutes' => __( 'Approx. active minutes', 'educore-core' ) ) ),
			'attempts'          => array( __( 'Assessment attempts', 'educore-core' ), array( 'assessment' => __( 'Assessment', 'educore-core' ), 'attempt' => __( 'Attempt', 'educore-core' ), 'score' => __( 'Score', 'educore-core' ), 'status' => __( 'Status', 'educore-core' ), 'date' => __( 'Date', 'educore-core' ) ) ),
			'enrollments'       => array( __( 'Enrollment history', 'educore-core' ), array( 'course' => __( 'Course', 'educore-core' ), 'status' => __( 'Status', 'educore-core' ), 'since' => __( 'Since', 'educore-core' ), 'completed_at' => __( 'Completed', 'educore-core' ) ) ),
			'certificates'      => array( __( 'Certificates', 'educore-core' ), array( 'course' => __( 'Course', 'educore-core' ), 'issued' => __( 'Issued', 'educore-core' ), 'link' => __( 'Certificate', 'educore-core' ) ) ),
		);
		foreach ( $tables as $key => [ $title, $cols ] ) {
			$out .= '<section class="ec-section"><h2>' . esc_html( $title ) . '</h2>';
			if ( empty( $h[ $key ] ) ) {
				$out .= '<p class="ec-muted">' . esc_html__( 'Nothing here yet.', 'educore-core' ) . '</p></section>';
				continue;
			}
			$out .= '<div class="ec-table-wrap"><table class="ec-table"><thead><tr>';
			foreach ( $cols as $label ) {
				$out .= '<th scope="col">' . esc_html( $label ) . '</th>';
			}
			$out .= '</tr></thead><tbody>';
			foreach ( $h[ $key ] as $row ) {
				$out .= '<tr>';
				foreach ( array_keys( $cols ) as $col ) {
					$val = $row[ $col ] ?? '';
					if ( 'link' === $col && $val ) {
						$out .= '<td><a href="' . esc_url( $val ) . '">' . esc_html__( 'View', 'educore-core' ) . '</a></td>';
					} elseif ( in_array( $col, array( 'completed_at', 'since', 'date', 'issued' ), true ) && $val ) {
						$out .= '<td>' . esc_html( date_i18n( get_option( 'date_format' ), strtotime( $val . ' UTC' ) ) ) . '</td>';
					} else {
						$out .= '<td>' . esc_html( (string) $val ) . '</td>';
					}
				}
				$out .= '</tr>';
			}
			$out .= '</tbody></table></div></section>';
		}
		return $out . '</div>';
	}

	public static function profile(): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return self::login_prompt( __( 'Log in to manage your profile.', 'educore-core' ) );
		}
		$p   = Profile::get( $uid );
		$out = '<div class="ec-profile">' . self::flash();
		$out .= '<form class="ec-form ec-card" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		$out .= '<input type="hidden" name="action" value="educore_profile">' . wp_nonce_field( 'educore_profile', '_ecnonce', true, false );
		$out .= '<div class="ec-profile__avatar"><img src="' . esc_url( $p['avatar'] ) . '" alt="" width="96" height="96"><label class="ec-field"><span>' . esc_html__( 'Profile picture (optional)', 'educore-core' ) . '</span><input type="file" name="avatar" accept="image/jpeg,image/png,image/webp"></label></div>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Full name', 'educore-core' ) . '</span><input name="display_name" required maxlength="120" autocomplete="name" value="' . esc_attr( $p['display_name'] ) . '"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'E-mail', 'educore-core' ) . '</span><input type="email" value="' . esc_attr( $p['email'] ) . '" readonly aria-describedby="ec-email-help"><small id="ec-email-help" class="ec-muted">' . esc_html__( 'To change your e-mail, contact support.', 'educore-core' ) . '</small></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Mobile number (optional)', 'educore-core' ) . '</span><input type="tel" name="mobile" inputmode="tel" autocomplete="tel" pattern="[0-9+ ]{11,16}" value="' . esc_attr( $p['mobile'] ) . '" placeholder="01012345678"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Academic year (optional)', 'educore-core' ) . '</span><input name="academic_year" maxlength="60" value="' . esc_attr( $p['academic_year'] ) . '"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Educational programme (optional)', 'educore-core' ) . '</span><select name="programme_id"><option value="0">—</option>';
		foreach ( Curriculum::programmes() as $prog ) {
			$out .= '<option value="' . esc_attr( $prog['id'] ) . '"' . selected( $p['programme_id'], (int) $prog['id'], false ) . '>' . esc_html( $prog['name'] ) . '</option>';
		}
		$out .= '</select></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Preferred language', 'educore-core' ) . '</span><select name="lang">';
		foreach ( I18n::labels() as $code => $label ) {
			$out .= '<option value="' . esc_attr( $code ) . '" lang="' . esc_attr( $code ) . '"' . selected( $p['lang'], $code, false ) . '>' . esc_html( $label ) . '</option>';
		}
		$out .= '</select></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Weekly goal (lessons)', 'educore-core' ) . '</span><input type="number" min="1" max="50" name="weekly_goal" value="' . esc_attr( (string) ( (int) get_user_meta( $uid, 'educore_weekly_goal', true ) ?: 3 ) ) . '"></label>';
		if ( \EduCore\Core\Gamification::leaderboards_on() && '18plus' === get_user_meta( $uid, 'educore_age_band', true ) ) {
			$out .= '<label class="ec-check"><input type="checkbox" name="leaderboard_optin" value="1"' . checked( 'yes', get_user_meta( $uid, 'educore_leaderboard_optin', true ), false ) . '> ' . esc_html__( 'Show my first name and XP on leaderboards', 'educore-core' ) . '</label>';
		}
		$out .= apply_filters( 'educore/profile/form_fields', '', $uid );
		$out .= '<button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Save profile', 'educore-core' ) . '</button></form></div>';
		return $out;
	}

	public static function register(): string {
		if ( is_user_logged_in() ) {
			return self::notice( __( 'You are already signed in.', 'educore-core' ), 'info' ) . '<p><a class="ec-btn ec-btn--primary" href="' . esc_url( Pages::url( 'dashboard' ) ) . '">' . esc_html__( 'Go to my learning', 'educore-core' ) . '</a></p>';
		}
		if ( 'closed' === get_option( 'educore_registration', 'open' ) ) {
			return self::notice( __( 'Self-registration is currently closed. Please contact your school or our support team.', 'educore-core' ), 'info' );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$redirect = isset( $_GET['redirect_to'] ) ? esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ) : '';
		$out  = '<div class="ec-register">' . self::flash();
		$out .= '<form class="ec-form ec-card" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" novalidate>';
		$out .= '<input type="hidden" name="action" value="educore_register">' . wp_nonce_field( 'educore_register', '_ecnonce', true, false ) . '<input type="hidden" name="redirect_to" value="' . esc_attr( $redirect ) . '">';
		$out .= '<div class="ec-hp" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Full name', 'educore-core' ) . '</span><input name="name" required maxlength="120" autocomplete="name"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'E-mail', 'educore-core' ) . '</span><input type="email" name="email" required autocomplete="email"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Password (at least 10 characters)', 'educore-core' ) . '</span><input type="password" name="password" required minlength="10" autocomplete="new-password"></label>';
		$out .= '<fieldset class="ec-field"><legend>' . esc_html__( 'Your age', 'educore-core' ) . '</legend>';
		foreach ( array( 'under15' => __( 'Under 15', 'educore-core' ), '15to17' => __( '15 to 17', 'educore-core' ), '18plus' => __( '18 or older', 'educore-core' ) ) as $v => $l ) {
			$out .= '<label class="ec-check"><input type="radio" name="age_band" value="' . esc_attr( $v ) . '" required data-ec-minor="' . ( '18plus' === $v ? '0' : '1' ) . '"> ' . esc_html( $l ) . '</label>';
		}
		$out .= '</fieldset>';
		$out .= '<div class="ec-guardian" data-ec-guardian hidden><p class="ec-muted">' . esc_html__( 'Because you are under 18, your parent or guardian must confirm before you can start learning. We will e-mail them a confirmation link.', 'educore-core' ) . '</p>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Parent or guardian name', 'educore-core' ) . '</span><input name="guardian_name" maxlength="120"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Parent or guardian e-mail', 'educore-core' ) . '</span><input type="email" name="guardian_email"></label></div>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Preferred language', 'educore-core' ) . '</span><select name="lang">';
		foreach ( I18n::labels() as $code => $label ) {
			$out .= '<option value="' . esc_attr( $code ) . '" lang="' . esc_attr( $code ) . '"' . selected( I18n::current(), $code, false ) . '>' . esc_html( $label ) . '</option>';
		}
		$out .= '</select></label>';
		$terms   = '<a href="' . esc_url( Pages::url( 'terms' ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Terms of Service', 'educore-core' ) . '</a>';
		$privacy = '<a href="' . esc_url( Pages::url( 'privacy' ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Privacy Policy', 'educore-core' ) . '</a>';
		/* translators: 1: terms link, 2: privacy link */
		$out .= '<label class="ec-check"><input type="checkbox" name="consent" value="1" required> ' . sprintf( esc_html__( 'I accept the %1$s and the %2$s.', 'educore-core' ), $terms, $privacy ) . '</label>';
		$out .= '<button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Create account', 'educore-core' ) . '</button>';
		$out .= '<p class="ec-muted">' . esc_html__( 'Already have an account?', 'educore-core' ) . ' <a href="' . esc_url( wp_login_url( $redirect ?: Pages::url( 'dashboard' ) ) ) . '">' . esc_html__( 'Log in', 'educore-core' ) . '</a></p>';
		return $out . '</form></div>';
	}

	public static function guardian(): string {
		$out = self::flash();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- token is the credential.
		$token = isset( $_GET['educore_guardian'] ) ? sanitize_text_field( wp_unslash( $_GET['educore_guardian'] ) ) : '';
		if ( '' === $token ) {
			return $out ?: self::notice( __( 'Open this page from the link in the consent e-mail.', 'educore-core' ), 'info' );
		}
		$link = Privacy::find_guardian_link( $token );
		if ( ! $link ) {
			return self::notice( __( 'This consent link is invalid or has expired. Ask the learner to request a new one from their profile.', 'educore-core' ), 'error' );
		}
		$student = get_userdata( (int) $link['student_id'] );
		$o  = '<div class="ec-card ec-guardian-consent">';
		/* translators: %s: learner name */
		$o .= '<h2>' . esc_html( sprintf( __( 'Consent for %s', 'educore-core' ), $student ? $student->display_name : '' ) ) . '</h2>';
		$o .= '<p>' . esc_html__( 'EduCore is an online learning platform. To let the learner use it, we will process: their name and e-mail address, learning progress, assessment answers and grades, and certificates. We never sell personal data and do not show learners under 18 on public leaderboards. You can withdraw consent at any time by contacting support, and you can ask for a copy or deletion of the data.', 'educore-core' ) . '</p>';
		$o .= '<p><a href="' . esc_url( Pages::url( 'privacy' ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Read the Privacy Policy', 'educore-core' ) . '</a></p>';
		$o .= '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="ec-actions">';
		$o .= '<input type="hidden" name="action" value="educore_guardian"><input type="hidden" name="token" value="' . esc_attr( $token ) . '">' . wp_nonce_field( 'educore_guardian', '_ecnonce', true, false );
		$o .= '<label class="ec-check"><input type="checkbox" name="confirm_guardian" value="1" required> ' . esc_html__( 'I am the parent or legal guardian of this learner.', 'educore-core' ) . '</label>';
		$o .= '<button class="ec-btn ec-btn--primary" name="decision" value="approve" type="submit">' . esc_html__( 'I give my consent', 'educore-core' ) . '</button> ';
		$o .= '<button class="ec-btn" name="decision" value="decline" type="submit" formnovalidate>' . esc_html__( 'I do not consent', 'educore-core' ) . '</button></form></div>';
		return $out . $o;
	}

	public static function contact(): string {
		$email = sanitize_email( (string) get_option( 'educore_support_email', 'support@educore.gorgy.org' ) );
		$out   = '<div class="ec-contact">' . self::flash();
		/* translators: %s: email link */
		$out .= '<p>' . sprintf( esc_html__( 'Write to us at %s or use the form below. We reply within two working days.', 'educore-core' ), '<a href="mailto:' . esc_attr( antispambot( $email ) ) . '">' . esc_html( antispambot( $email ) ) . '</a>' ) . '</p>';
		$out .= '<form class="ec-form ec-card" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		$out .= '<input type="hidden" name="action" value="educore_contact">' . wp_nonce_field( 'educore_contact', '_ecnonce', true, false );
		$out .= '<div class="ec-hp" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div>';
		$u    = wp_get_current_user();
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Your name', 'educore-core' ) . '</span><input name="name" required maxlength="120" value="' . esc_attr( $u->exists() ? $u->display_name : '' ) . '"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Your e-mail', 'educore-core' ) . '</span><input type="email" name="email" required value="' . esc_attr( $u->exists() ? $u->user_email : '' ) . '"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Subject', 'educore-core' ) . '</span><input name="subject" required maxlength="150"></label>';
		$out .= '<label class="ec-field"><span>' . esc_html__( 'Message', 'educore-core' ) . '</span><textarea name="message" rows="6" required maxlength="5000"></textarea></label>';
		$out .= '<label class="ec-check"><input type="checkbox" name="consent" value="1" required> ' . esc_html__( 'I agree that EduCore uses my name and e-mail only to answer this message.', 'educore-core' ) . '</label>';
		$out .= '<button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Send message', 'educore-core' ) . '</button></form>';
		$faqs = array(
			__( 'How do I enroll in a course?', 'educore-core' )            => __( 'Open the course page and press “Enroll”. Some courses are assigned by your school or require purchase.', 'educore-core' ),
			__( 'Why can’t I start learning yet?', 'educore-core' )         => __( 'Learners under 18 need their parent or guardian to confirm the e-mail we sent them.', 'educore-core' ),
			__( 'Can I change the language?', 'educore-core' )              => __( 'Yes — use the language switcher in the header or your profile (English, Français, العربية).', 'educore-core' ),
			__( 'How do I get a copy of my data?', 'educore-core' )         => __( 'Write to support and we will send you an export of your learning records.', 'educore-core' ),
		);
		$out .= '<section class="ec-section"><h2>' . esc_html__( 'Frequently asked questions', 'educore-core' ) . '</h2>';
		foreach ( $faqs as $q => $a ) {
			$out .= '<details class="ec-faq"><summary>' . esc_html( $q ) . '</summary><p>' . esc_html( $a ) . '</p></details>';
		}
		return $out . '</section></div>';
	}

	public static function language_switcher(): string {
		$cur = I18n::current();
		$out = '<nav class="ec-lang" aria-label="' . esc_attr__( 'Language', 'educore-core' ) . '"><ul>';
		foreach ( I18n::labels() as $code => $label ) {
			$out .= '<li><a lang="' . esc_attr( $code ) . '" hreflang="' . esc_attr( $code ) . '" href="' . I18n::switch_url( $code ) . '"' . ( $cur === $code ? ' aria-current="true"' : '' ) . '>' . esc_html( $label ) . '</a></li>';
		}
		return $out . '</ul></nav>';
	}

	public static function user_menu(): string {
		if ( ! is_user_logged_in() ) {
			return '<nav class="ec-usermenu" aria-label="' . esc_attr__( 'Account', 'educore-core' ) . '"><a class="ec-btn ec-btn--ghost" href="' . esc_url( wp_login_url( Pages::url( 'dashboard' ) ) ) . '">' . esc_html__( 'Log in', 'educore-core' ) . '</a>' . ( Pages::registration_open() ? ' <a class="ec-btn ec-btn--primary" href="' . esc_url( Pages::url( 'register' ) ) . '">' . esc_html__( 'Sign up', 'educore-core' ) . '</a>' : '' ) . '</nav>';
		}
		$out = '<nav class="ec-usermenu" aria-label="' . esc_attr__( 'Account', 'educore-core' ) . '"><a class="ec-btn ec-btn--ghost" href="' . esc_url( Pages::url( 'dashboard' ) ) . '">' . esc_html__( 'My learning', 'educore-core' ) . '</a>';
		if ( current_user_can( 'ec_access_workspace' ) ) {
			$out .= ' <a class="ec-btn ec-btn--ghost" href="' . esc_url( Pages::url( 'workspace' ) ) . '">' . esc_html__( 'Workspace', 'educore-core' ) . '</a>';
		}
		return $out . ' <a class="ec-btn ec-btn--ghost" href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">' . esc_html__( 'Log out', 'educore-core' ) . '</a></nav>';
	}

	public static function leaderboard( array $attrs = array() ): string {
		if ( ! \EduCore\Core\Gamification::leaderboards_on() ) {
			return '';
		}
		$rows = \EduCore\Core\Gamification::leaderboard( (int) ( $attrs['courseId'] ?? 0 ) );
		$out  = '<section class="ec-card ec-leaderboard"><h2>' . esc_html__( 'Leaderboard', 'educore-core' ) . '</h2>';
		if ( ! $rows ) {
			$out .= '<p class="ec-muted">' . esc_html__( 'No one has joined the leaderboard yet.', 'educore-core' ) . '</p>';
		} else {
			$out .= '<ol class="ec-leaderboard__list">';
			$me   = get_current_user_id();
			foreach ( $rows as $r ) {
				/* translators: %s: experience points */
				$out .= '<li' . ( $r['user_id'] === $me ? ' class="is-me" aria-current="true"' : '' ) . '><span>' . esc_html( $r['name'] ) . '</span> <span class="ec-muted">' . esc_html( sprintf( __( '%s XP', 'educore-core' ), number_format_i18n( $r['xp'] ) ) ) . '</span></li>';
			}
			$out .= '</ol>';
		}
		$out .= '<p class="ec-muted">' . esc_html__( 'Only adult learners who chose to appear here are listed. You can join or leave in your profile.', 'educore-core' ) . '</p>';
		return $out . '</section>';
	}

	/* ---------- instructor workspace ---------- */

	public static function workspace(): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return self::login_prompt( __( 'Log in to open the instructor workspace.', 'educore-core' ) );
		}
		if ( ! current_user_can( 'ec_access_workspace' ) ) {
			return self::notice( __( 'The workspace is available to instructors, graders and academic managers.', 'educore-core' ), 'error' );
		}
		$courses = current_user_can( 'ec_manage_all_courses' )
			? get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'future' ), 'posts_per_page' => 200, 'fields' => 'ids' ) )
			: Staff::courses_of( $uid );
		$out  = '<div class="ec-workspace">' . self::flash();
		$out .= '<nav class="ec-actions" aria-label="' . esc_attr__( 'Workspace tools', 'educore-core' ) . '">';
		if ( current_user_can( 'edit_ec_courses' ) ) {
			$out .= '<a class="ec-btn ec-btn--primary" href="' . esc_url( admin_url( 'post-new.php?post_type=' . Content::COURSE ) ) . '">' . esc_html__( 'New course', 'educore-core' ) . '</a> ';
		}
		$out .= apply_filters( 'educore/workspace/tools', '', $uid ) . '</nav>';
		$out .= apply_filters( 'educore/workspace/before_courses', '', $uid );
		$out .= '<section class="ec-section"><h2>' . esc_html__( 'My courses', 'educore-core' ) . '</h2>';
		if ( empty( $courses ) ) {
			$out .= '<div class="ec-empty">' . esc_html__( 'No courses are assigned to you yet.', 'educore-core' ) . '</div>';
		}
		foreach ( $courses as $cid ) {
			$cid      = (int) $cid;
			$can_see  = current_user_can( 'ec_view_course_records', $cid );
			$count    = $can_see ? Enrollment::count_for_course( $cid ) : 0;
			$students = $can_see ? Enrollment::for_course( $cid, 50 ) : array();
			$out     .= '<details class="ec-card ec-ws-course"><summary><strong>' . esc_html( get_the_title( $cid ) ) . '</strong> <span class="ec-chip">' . esc_html( get_post_status_object( get_post_status( $cid ) )->label ?? '' ) . '</span>';
			/* translators: %d: student count */
			$out .= ' <span class="ec-muted">' . esc_html( sprintf( _n( '%d student', '%d students', $count, 'educore-core' ), $count ) ) . '</span></summary>';
			$out .= '<p class="ec-actions">';
			if ( current_user_can( 'edit_post', $cid ) ) {
				$out .= '<a class="ec-btn" href="' . esc_url( get_edit_post_link( $cid ) ) . '">' . esc_html__( 'Edit course', 'educore-core' ) . '</a> ';
				$out .= '<a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-curriculum&course=' . $cid ) ) . '">' . esc_html__( 'Curriculum editor', 'educore-core' ) . '</a> ';
			}
			$out .= '<a class="ec-btn" href="' . esc_url( get_permalink( $cid ) ) . '">' . esc_html__( 'View', 'educore-core' ) . '</a> ' . apply_filters( 'educore/workspace/course_actions', '', $cid, $uid ) . '</p>';
			if ( current_user_can( 'ec_edit_course', $cid ) ) {
				$out .= '<form class="ec-form ec-inline-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="educore_announce"><input type="hidden" name="course_id" value="' . esc_attr( (string) $cid ) . '">' . wp_nonce_field( 'educore_announce_' . $cid, '_ecnonce', true, false );
				$out .= '<label class="ec-field ec-field--grow"><span>' . esc_html__( 'Post an announcement to enrolled students', 'educore-core' ) . '</span><input name="title" required maxlength="150" placeholder="' . esc_attr__( 'Title', 'educore-core' ) . '"></label><label class="ec-field ec-field--grow"><span class="screen-reader-text">' . esc_html__( 'Message', 'educore-core' ) . '</span><textarea name="body" rows="2" required maxlength="3000" placeholder="' . esc_attr__( 'Message', 'educore-core' ) . '"></textarea></label><button class="ec-btn" type="submit">' . esc_html__( 'Publish', 'educore-core' ) . '</button></form>';
			}
			if ( $students ) {
				$bulk  = \EduCore\Core\Progress::bulk_course_summary( $cid, array_map( static fn( $e ) => (int) $e['user_id'], $students ) );
				update_meta_cache( 'user', array_map( static fn( $e ) => (int) $e['user_id'], $students ) );
				cache_users( array_map( static fn( $e ) => (int) $e['user_id'], $students ) );
				$out .= '<div class="ec-table-wrap"><table class="ec-table"><thead><tr><th scope="col">' . esc_html__( 'Student', 'educore-core' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-core' ) . '</th><th scope="col">' . esc_html__( 'Progress', 'educore-core' ) . '</th></tr></thead><tbody>';
				foreach ( $students as $e ) {
					$u = get_userdata( (int) $e['user_id'] );
					if ( ! $u ) {
						continue;
					}
					$s    = $bulk[ (int) $u->ID ] ?? array( 'percent' => 0 );
					$out .= '<tr><td>' . esc_html( $u->display_name ) . '</td><td>' . esc_html( $e['status'] ) . '</td><td>' . esc_html( $s['percent'] . '%' ) . self::progress_bar( $s['percent'] ) . '</td></tr>';
				}
				$out .= '</tbody></table></div>';
				if ( $count > count( $students ) ) {
					/* translators: %d: number of students shown */
					$out .= '<p class="ec-muted">' . esc_html( sprintf( __( 'Showing the first %d students. Use Analytics or Enrollments for the full list.', 'educore-core' ), count( $students ) ) ) . '</p>';
				}
			}
			$out .= '</details>';
		}
		$out .= '</section>' . apply_filters( 'educore/workspace/after_courses', '', $uid );
		return $out . '</div>';
	}
}
