<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Access;
use EduCore\Core\Privacy as CorePrivacy;

defined( 'ABSPATH' ) || exit;

/**
 * Learner-facing integration: dashboard sections (classes, teachers, assignments, tutoring, attendance,
 * conversations), assignment submission, tutoring requests, tutor directory block, file downloads.
 * Also the learner-safe projections used by REST (no unreleased grades, no tutor/staff private notes).
 */
final class Student {

	public static function register(): void {
		add_filter( 'educore/dashboard/student_sections', array( self::class, 'sections' ), 10, 3 );
		add_action( 'template_redirect', array( self::class, 'handle' ), 9 );
		add_action( 'template_redirect', array( self::class, 'download' ), 8 );
		add_action( 'init', array( self::class, 'blocks' ) );
		add_filter( 'educore/workspace/tools', array( self::class, 'workspace_link' ) );
	}

	public static function blocks(): void {
		register_block_type( 'educore/teaching-hub', array( 'api_version' => 3, 'title' => __( 'EduCore: Teaching Hub', 'educore-teaching-hub' ), 'category' => 'widgets', 'render_callback' => array( Portal::class, 'render' ) ) );
		register_block_type( 'educore/tutors', array( 'api_version' => 3, 'title' => __( 'EduCore: Tutor directory', 'educore-teaching-hub' ), 'category' => 'widgets', 'render_callback' => array( self::class, 'directory' ) ) );
		wp_register_style( 'educore-th', EDUCORE_TH_URL . 'assets/hub.css', array(), EDUCORE_TH_VERSION );
		wp_register_script( 'educore-th', EDUCORE_TH_URL . 'assets/hub.js', array(), EDUCORE_TH_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
	}

	/** @param mixed $tools */
	public static function workspace_link( $tools ) {
		if ( is_string( $tools ) && ( current_user_can( 'ec_teach' ) || current_user_can( 'ec_tutor_sessions' ) ) ) {
			$tools .= '<a class="ec-btn" href="' . esc_url( Portal::url() ) . '">' . esc_html__( 'Open the Teaching Hub', 'educore-teaching-hub' ) . '</a>';
		}
		return $tools;
	}

	/* ---------- Learner-safe projections ---------- */

	public static function public_assignment( array $a ): array {
		return array(
			'id'           => (int) $a['id'],
			'title'        => $a['title'],
			'instructions' => $a['instructions'],
			'opens_at'     => $a['opens_at'],
			'due_at'       => $a['due_at'],
			'max_score'    => (float) $a['max_score'],
			'rubric'       => Assignments::rubric( $a ),
			'allow_files'  => (bool) $a['allow_files'],
			'allow_late'   => (bool) $a['allow_late'],
			'allow_resubmit' => (bool) $a['allow_resubmit'],
		);
	}

	public static function public_submission( ?array $s ): ?array {
		if ( ! $s ) {
			return null;
		}
		$released = (int) $s['released'];
		return array(
			'id'           => (int) $s['id'],
			'status'       => 'graded' === $s['status'] && ! $released ? 'submitted' : $s['status'],
			'answer'       => $s['answer'],
			'files'        => array_map( static fn( $f ) => array( 'name' => $f['name'], 'size' => $f['size'] ), (array) json_decode( (string) $s['files'], true ) ),
			'submitted_at' => $s['submitted_at'],
			'is_late'      => (bool) $s['is_late'],
			'score'        => $released && 'graded' === $s['status'] ? (float) $s['score'] : null,
			'rubric_scores'=> $released ? json_decode( (string) $s['rubric_scores'], true ) : null,
			// Criteria actually used when graded (immutable snapshot); null for pre-1.1.1 grades.
			'rubric_graded'=> $released && ! empty( $s['rubric_snapshot'] ) ? json_decode( (string) $s['rubric_snapshot'], true ) : null,
			'feedback'     => $released ? $s['feedback'] : null,
		);
	}

	public static function public_session( array $s ): array {
		$tutor = get_userdata( (int) $s['tutor_id'] );
		$show  = 'confirmed' === $s['status'];
		return array(
			'id'          => (int) $s['id'],
			'tutor'       => $tutor ? $tutor->display_name : '',
			'subject'     => $s['subject'],
			'starts_at'   => $s['starts_at'],
			'ends_at'     => $s['ends_at'],
			'format'      => $s['format'],
			'status'      => $s['status'],
			'awaiting_guardian' => 'requested' === $s['status'] && ! (int) $s['guardian_ok'],
			'meeting_url' => $show ? $s['meeting_url'] : '',
			'location'    => $show ? $s['location'] : '',
			'objectives'  => $s['objectives'],
			'homework'    => $s['homework'],
			'feedback'    => $s['feedback'],
		);
	}

	/** Public tutor card — never e-mail, phone or address. */
	public static function public_tutor( array $p ): array {
		return array(
			'id'         => (int) $p['user_id'],
			'name'       => $p['display_name'] ?? ( get_userdata( (int) $p['user_id'] ) ?: new \WP_User() )->display_name,
			'headline'   => $p['headline'],
			'bio'        => $p['bio'],
			'subjects'   => $p['subjects'],
			'languages'  => array_filter( explode( ',', (string) $p['languages'] ) ),
			'formats'    => array_filter( explode( ',', (string) $p['formats'] ) ),
			'experience' => $p['experience'],
			'minutes'    => (int) $p['session_minutes'],
		);
	}

	/* ---------- Dashboard sections ---------- */

	private static function msg(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$code = isset( $_GET['ec_th_msg'] ) ? sanitize_key( wp_unslash( $_GET['ec_th_msg'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$err  = isset( $_GET['ec_th_err'] ) ? sanitize_text_field( wp_unslash( $_GET['ec_th_err'] ) ) : '';
		$map  = array(
			'saved'     => __( 'Saved.', 'educore-teaching-hub' ),
			'submitted' => __( 'Your work was submitted.', 'educore-teaching-hub' ),
			'requested' => __( 'Your request was sent to the tutor.', 'educore-teaching-hub' ),
			'cancelled' => __( 'The session was cancelled.', 'educore-teaching-hub' ),
			'posted'    => __( 'Your message was posted.', 'educore-teaching-hub' ),
			'reported'  => __( 'Thank you. Your concern was sent to the safeguarding team.', 'educore-teaching-hub' ),
		);
		$out = isset( $map[ $code ] ) ? '<div class="ec-notice ec-notice--success" role="status">' . esc_html( $map[ $code ] ) . '</div>' : '';
		return $out . ( '' !== $err ? '<div class="ec-notice ec-notice--error" role="alert">' . esc_html( $err ) . '</div>' : '' );
	}

	public static function sections( string $html, array $data, int $uid ): string {
		wp_enqueue_style( 'educore-th' );
		wp_enqueue_script( 'educore-th' );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only view routing.
		$view = isset( $_GET['th_view'] ) ? sanitize_key( wp_unslash( $_GET['th_view'] ) ) : '';
		$id   = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		// phpcs:enable
		$out = '<section class="ec-th-learner" aria-labelledby="ec-th-learner-h"><h2 id="ec-th-learner-h" class="screen-reader-text">' . esc_html__( 'Classes, assignments and tutoring', 'educore-teaching-hub' ) . '</h2>' . self::msg();
		if ( 'assignment' === $view && $id ) {
			return $html . $out . self::assignment_view( $uid, $id ) . '</section>';
		}
		if ( 'thread' === $view && $id ) {
			return $html . $out . self::thread_view( $uid, $id ) . '</section>';
		}
		if ( 'book' === $view && $id ) {
			return $html . $out . self::book_view( $uid, $id ) . '</section>';
		}
		$out .= self::classes_card( $uid ) . self::assignments_card( $uid ) . self::sessions_card( $uid ) . self::attendance_card( $uid ) . self::threads_card( $uid );
		return $html . $out . '</section>';
	}

	private static function url( array $args = array() ): string {
		return add_query_arg( $args, \EduCore\Core\Pages::url( 'dashboard' ) );
	}

	private static function classes_card( int $uid ): string {
		$classes = Classes::of_student( $uid );
		if ( ! $classes ) {
			return '';
		}
		$out = '<div class="ec-card ec-th-card"><h3>' . esc_html__( 'My classes & teachers', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-list">';
		foreach ( $classes as $cid ) {
			$c        = Classes::get( $cid );
			$teachers = array_filter( array_map( static fn( $s ) => ( get_userdata( $s['user_id'] ) ?: null )?->display_name, Classes::staff( $cid ) ) );
			$out     .= '<li><strong>' . esc_html( $c['name'] ) . '</strong>' . ( $c['academic_year'] ? ' <span class="ec-chip">' . esc_html( $c['academic_year'] ) . '</span>' : '' ) . '<br><span class="ec-muted">' . esc_html( implode( ', ', $teachers ) ) . '</span>';
			if ( $c['schedule'] ) {
				$out .= '<br><span class="ec-muted">' . esc_html( $c['schedule'] ) . '</span>';
			}
			$out .= '</li>';
		}
		return $out . '</ul></div>';
	}

	public static function status_label( string $st ): string {
		$map = array(
			'not_started' => __( 'Not started', 'educore-teaching-hub' ),
			'in_progress' => __( 'In progress', 'educore-teaching-hub' ),
			'submitted'   => __( 'Submitted', 'educore-teaching-hub' ),
			'late'        => __( 'Submitted late', 'educore-teaching-hub' ),
			'graded'      => __( 'Graded', 'educore-teaching-hub' ),
			'returned'    => __( 'Returned for revision', 'educore-teaching-hub' ),
			'missing'     => __( 'Missing', 'educore-teaching-hub' ),
			'requested'   => __( 'Requested', 'educore-teaching-hub' ),
			'confirmed'   => __( 'Confirmed', 'educore-teaching-hub' ),
			'completed'   => __( 'Completed', 'educore-teaching-hub' ),
			'cancelled'   => __( 'Cancelled', 'educore-teaching-hub' ),
			'declined'    => __( 'Declined', 'educore-teaching-hub' ),
			'no_show'     => __( 'No-show', 'educore-teaching-hub' ),
			'present'     => __( 'Present', 'educore-teaching-hub' ),
			'absent'      => __( 'Absent', 'educore-teaching-hub' ),
			'excused'     => __( 'Excused', 'educore-teaching-hub' ),
			'draft'       => __( 'Draft', 'educore-teaching-hub' ),
			'published'   => __( 'Published', 'educore-teaching-hub' ),
			'closed'      => __( 'Closed', 'educore-teaching-hub' ),
			'planned'     => __( 'Planned', 'educore-teaching-hub' ),
			'delivered'   => __( 'Delivered', 'educore-teaching-hub' ),
		);
		return $map[ $st ] ?? $st;
	}

	public static function chip( string $st ): string {
		return '<span class="ec-chip ec-th-st ec-th-st--' . esc_attr( $st ) . '">' . esc_html( self::status_label( $st ) ) . '</span>';
	}

	private static function assignments_card( int $uid ): string {
		$rows = Assignments::for_student( $uid );
		if ( ! $rows ) {
			return '';
		}
		$out = '<div class="ec-card ec-th-card"><h3>' . esc_html__( 'My assignments', 'educore-teaching-hub' ) . '</h3><table class="ec-th-table"><thead><tr><th>' . esc_html__( 'Assignment', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Deadline', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Status', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Result', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $a ) {
			$sub  = $a['sub_status'] ? array( 'status' => $a['sub_status'], 'released' => $a['released'], 'is_late' => $a['is_late'] ) : null;
			$st   = Assignments::learner_status( $a, $sub );
			$res  = 'graded' === $st ? esc_html( number_format_i18n( (float) $a['score'], 1 ) . ' / ' . number_format_i18n( (float) $a['max_score'], 0 ) ) : '—';
			$out .= '<tr><td><a href="' . esc_url( self::url( array( 'th_view' => 'assignment', 'id' => $a['id'] ) ) ) . '">' . esc_html( $a['title'] ) . '</a></td><td>' . esc_html( Plugin::local( $a['due_at'] ) ) . '</td><td>' . self::chip( $st ) . '</td><td>' . $res . '</td></tr>';
		}
		return $out . '</tbody></table></div>';
	}

	private static function sessions_card( int $uid ): string {
		$rows = Tutoring::for_student( $uid, 20 );
		$out  = '<div class="ec-card ec-th-card"><h3>' . esc_html__( 'My tutoring sessions', 'educore-teaching-hub' ) . '</h3>';
		if ( ! $rows ) {
			$out .= '<p class="ec-muted">' . esc_html__( 'No tutoring sessions yet.', 'educore-teaching-hub' ) . '</p>';
		} else {
			$out .= '<ul class="ec-th-list">';
			foreach ( $rows as $s ) {
				$p    = self::public_session( $s );
				$out .= '<li><strong>' . esc_html( $p['subject'] ?: __( 'Tutoring session', 'educore-teaching-hub' ) ) . '</strong> — ' . esc_html( $p['tutor'] ) . ' · ' . esc_html( Plugin::local( $p['starts_at'] ) ) . ' ' . self::chip( $p['status'] );
				if ( $p['awaiting_guardian'] ) {
					$out .= ' <span class="ec-chip">' . esc_html__( 'Waiting for guardian approval', 'educore-teaching-hub' ) . '</span>';
				}
				if ( $p['meeting_url'] ) {
					$out .= ' <a class="ec-btn ec-btn--ghost" rel="noopener" target="_blank" href="' . esc_url( $p['meeting_url'] ) . '">' . esc_html__( 'Join', 'educore-teaching-hub' ) . '</a>';
				}
				if ( $p['homework'] ) {
					$out .= '<br><span class="ec-muted">' . esc_html__( 'Homework:', 'educore-teaching-hub' ) . ' ' . esc_html( $p['homework'] ) . '</span>';
				}
				if ( in_array( $p['status'], Tutoring::ACTIVE, true ) && (int) $s['student_id'] === $uid && strtotime( $s['starts_at'] . ' UTC' ) > time() ) {
					$out .= self::form( 'cancel_session', array( 'session_id' => $s['id'] ), '<button class="ec-btn ec-btn--ghost">' . esc_html__( 'Cancel', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' );
				}
				$out .= '</li>';
			}
			$out .= '</ul>';
		}
		return $out . '<p><a class="ec-btn" href="' . esc_url( Pages::url( 'tutors' ) ) . '">' . esc_html__( 'Find a tutor', 'educore-teaching-hub' ) . '</a></p></div>';
	}

	private static function attendance_card( int $uid ): string {
		$sum = Attendance::student_summary( $uid, wp_date( 'Y-m-d', time() - 30 * DAY_IN_SECONDS ) );
		if ( ! array_sum( $sum ) ) {
			return '';
		}
		$out = '<div class="ec-card ec-th-card"><h3>' . esc_html__( 'Attendance (last 30 days)', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-stats">';
		foreach ( $sum as $st => $n ) {
			$out .= '<li><span class="ec-th-stat__n">' . esc_html( number_format_i18n( $n ) ) . '</span> ' . esc_html( self::status_label( $st ) ) . '</li>';
		}
		return $out . '</ul></div>';
	}

	private static function threads_card( int $uid ): string {
		$threads = Comms::threads_for( $uid, 10 );
		$classes = Classes::of_student( $uid );
		$out     = '<div class="ec-card ec-th-card"><h3>' . esc_html__( 'Questions & announcements', 'educore-teaching-hub' ) . '</h3>';
		if ( $threads ) {
			$out .= '<ul class="ec-th-list">';
			foreach ( $threads as $t ) {
				$out .= '<li><a href="' . esc_url( self::url( array( 'th_view' => 'thread', 'id' => $t['id'] ) ) ) . '">' . esc_html( $t['subject'] ) . '</a> <span class="ec-muted">' . esc_html( Plugin::local( $t['last_post_at'] ) ) . '</span></li>';
			}
			$out .= '</ul>';
		}
		if ( $classes ) {
			$opts = '';
			foreach ( $classes as $cid ) {
				$opts .= '<option value="' . esc_attr( (string) $cid ) . '">' . esc_html( Classes::get( $cid )['name'] ) . '</option>';
			}
			$out .= '<details class="ec-th-details"><summary>' . esc_html__( 'Ask your teacher a question', 'educore-teaching-hub' ) . '</summary>' . self::form(
				'ask',
				array(),
				'<p><label>' . esc_html__( 'Class', 'educore-teaching-hub' ) . ' <select name="class_id" required>' . $opts . '</select></label></p><p><label>' . esc_html__( 'Subject', 'educore-teaching-hub' ) . ' <input name="subject" required maxlength="190"></label></p><p><label>' . esc_html__( 'Your question', 'educore-teaching-hub' ) . ' <textarea name="body" rows="4" required></textarea></label></p><p class="ec-muted">' . esc_html__( 'Your teacher will reply here. Conversations are kept on EduCore and may be reviewed for safety.', 'educore-teaching-hub' ) . '</p><p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Send', 'educore-teaching-hub' ) . '</button></p>'
			) . '</details>';
		}
		return $out . '</div>';
	}

	public static function form( string $action, array $hidden, string $inner, string $class = '', bool $files = false ): string {
		$h = '<form method="post" class="ec-th-form ' . esc_attr( $class ) . '"' . ( $files ? ' enctype="multipart/form-data"' : '' ) . '>' . wp_nonce_field( 'ec_th_' . $action, '_ecthnonce', true, false ) . '<input type="hidden" name="ec_th_action" value="' . esc_attr( $action ) . '">';
		foreach ( $hidden as $k => $v ) {
			$h .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( (string) $v ) . '">';
		}
		return $h . $inner . '</form>';
	}

	private static function files_list( array $files, array $link_args ): string {
		if ( ! $files ) {
			return '';
		}
		$out = '<ul class="ec-th-files">';
		foreach ( $files as $i => $f ) {
			$out .= '<li><a href="' . esc_url( wp_nonce_url( add_query_arg( array_merge( $link_args, array( 'ec_th_file' => $i ) ), home_url( '/' ) ), 'ec_th_file' ) ) . '">' . esc_html( $f['name'] ) . '</a> <span class="ec-muted">' . esc_html( size_format( (int) $f['size'] ) ) . '</span></li>';
		}
		return $out . '</ul>';
	}

	private static function assignment_view( int $uid, int $id ): string {
		$a = Assignments::get( $id );
		if ( ! $a || 'draft' === $a['status'] || ! Assignments::is_target( $a, $uid ) ) {
			return '<div class="ec-notice ec-notice--error">' . esc_html__( 'Assignment not found.', 'educore-teaching-hub' ) . '</div>';
		}
		$sub = Assignments::submission( $id, $uid );
		$pub = self::public_submission( $sub );
		$st  = Assignments::learner_status( $a, $sub );
		$out = '<p><a href="' . esc_url( self::url() ) . '">← ' . esc_html__( 'Back to my learning', 'educore-teaching-hub' ) . '</a></p><article class="ec-card ec-th-card"><h3>' . esc_html( $a['title'] ) . ' ' . self::chip( $st ) . '</h3>';
		$out .= '<p class="ec-muted">' . esc_html__( 'Deadline', 'educore-teaching-hub' ) . ': ' . esc_html( Plugin::local( $a['due_at'] ) ) . ' · ' . esc_html__( 'Maximum score', 'educore-teaching-hub' ) . ': ' . esc_html( number_format_i18n( (float) $a['max_score'] ) ) . '</p>';
		$out .= '<div class="ec-th-instructions">' . wp_kses_post( wpautop( (string) $a['instructions'] ) ) . '</div>';
		$out .= self::files_list( (array) json_decode( (string) $a['attachments'], true ), array( 'asg' => $id ) );
		$rubric = $pub && null !== $pub['rubric_scores'] ? Assignments::rubric_for( $a, $sub ) : Assignments::rubric( $a );
		if ( $rubric ) {
			$out .= '<h4>' . esc_html__( 'Marking criteria', 'educore-teaching-hub' ) . '</h4><ul>';
			foreach ( $rubric as $i => $c ) {
				$got  = $pub && is_array( $pub['rubric_scores'] ) && isset( $pub['rubric_scores'][ $i ] ) ? number_format_i18n( (float) $pub['rubric_scores'][ $i ], 1 ) . ' / ' : '';
				$out .= '<li>' . esc_html( $c['label'] ) . ' — ' . esc_html( $got . number_format_i18n( (float) $c['points'], 1 ) ) . '</li>';
			}
			$out .= '</ul>';
		}
		if ( $pub && null !== $pub['score'] ) {
			$out .= '<div class="ec-th-result"><strong>' . esc_html__( 'Your result', 'educore-teaching-hub' ) . ':</strong> ' . esc_html( number_format_i18n( $pub['score'], 1 ) . ' / ' . number_format_i18n( (float) $a['max_score'], 0 ) ) . '</div>';
		}
		if ( $pub && $pub['feedback'] ) {
			$out .= '<div class="ec-th-feedback"><strong>' . esc_html__( 'Teacher feedback', 'educore-teaching-hub' ) . '</strong>' . wp_kses_post( wpautop( (string) $pub['feedback'] ) ) . '</div>';
		}
		$locked = $sub && in_array( $sub['status'], array( 'submitted', 'graded' ), true ) && ! ( 'graded' !== $sub['status'] && (int) $a['allow_resubmit'] );
		$late   = $a['due_at'] && \EduCore\Core\Schema::now() > $a['due_at'];
		if ( $sub && $sub['files'] ) {
			$out .= '<h4>' . esc_html__( 'Your files', 'educore-teaching-hub' ) . '</h4>' . self::files_list( (array) json_decode( (string) $sub['files'], true ), array( 'sub' => (int) $sub['id'] ) );
		}
		if ( 'published' !== $a['status'] || $locked || ( $late && ! (int) $a['allow_late'] ) ) {
			if ( $sub && $sub['answer'] ) {
				$out .= '<h4>' . esc_html__( 'Your answer', 'educore-teaching-hub' ) . '</h4><div class="ec-th-answer">' . wp_kses_post( wpautop( (string) $sub['answer'] ) ) . '</div>';
			}
			return $out . '</article>';
		}
		$inner  = '<p><label for="ec-th-answer">' . esc_html__( 'Your answer', 'educore-teaching-hub' ) . '</label><textarea id="ec-th-answer" name="answer" rows="8">' . esc_textarea( (string) ( $sub['answer'] ?? '' ) ) . '</textarea></p>';
		if ( (int) $a['allow_files'] ) {
			$inner .= '<p><label>' . esc_html__( 'Attach files', 'educore-teaching-hub' ) . ' <input type="file" name="files[]" multiple accept="' . esc_attr( '.' . implode( ',.', Files::allowed() ) ) . '"></label><br><span class="ec-muted">' . esc_html( sprintf( /* translators: 1: types, 2: MB, 3: count */ __( 'Allowed: %1$s · up to %2$d MB each · at most %3$d files.', 'educore-teaching-hub' ), implode( ', ', Files::allowed() ), (int) Settings::get( 'max_file_mb' ), (int) Settings::get( 'max_files' ) ) ) . '</span></p>';
		}
		if ( $late ) {
			$inner .= '<p class="ec-notice ec-notice--info">' . esc_html__( 'The deadline has passed. Your work will be marked as late.', 'educore-teaching-hub' ) . '</p>';
		}
		$inner .= '<p><button class="ec-btn" name="final" value="0">' . esc_html__( 'Save draft', 'educore-teaching-hub' ) . '</button> <button class="ec-btn ec-btn--primary" name="final" value="1" data-ec-th-confirm="' . esc_attr__( 'Submit your work now?', 'educore-teaching-hub' ) . '">' . esc_html__( 'Submit', 'educore-teaching-hub' ) . '</button></p>';
		return $out . self::form( 'submit', array( 'assignment_id' => $id ), $inner, '', true ) . '</article>';
	}

	private static function thread_view( int $uid, int $id ): string {
		$t = Comms::thread( $id );
		if ( ! $t || 'none' === Comms::access( $uid, $t ) ) {
			return '<div class="ec-notice ec-notice--error">' . esc_html__( 'Conversation not found.', 'educore-teaching-hub' ) . '</div>';
		}
		return '<p><a href="' . esc_url( self::url() ) . '">← ' . esc_html__( 'Back to my learning', 'educore-teaching-hub' ) . '</a></p>' . Portal::thread_html( $uid, $t );
	}

	private static function book_view( int $uid, int $tutor_id ): string {
		$p = Tutoring::profile( $tutor_id );
		if ( ! $p || ! Tutoring::bookable( $tutor_id ) ) {
			return '<div class="ec-notice ec-notice--error">' . esc_html__( 'This tutor is not available for booking.', 'educore-teaching-hub' ) . '</div>';
		}
		$card  = self::public_tutor( array_merge( $p, array( 'display_name' => get_userdata( $tutor_id )->display_name ) ) );
		$out   = '<p><a href="' . esc_url( Pages::url( 'tutors' ) ) . '">← ' . esc_html__( 'All tutors', 'educore-teaching-hub' ) . '</a></p><div class="ec-card ec-th-card"><h3>' . esc_html( sprintf( /* translators: %s: tutor */ __( 'Request a session with %s', 'educore-teaching-hub' ), $card['name'] ) ) . '</h3>';
		if ( CorePrivacy::is_minor( $uid ) && 'on' === Settings::get( 'minor_tutoring_guardian' ) ) {
			$out .= '<p class="ec-notice ec-notice--info">' . esc_html__( 'Because you are under 18, your parent or guardian will be asked to authorise the session before the tutor can confirm it.', 'educore-teaching-hub' ) . '</p>';
		}
		$starts = Tutoring::free_starts( $tutor_id, 14 );
		if ( ! $starts ) {
			return $out . '<p class="ec-muted">' . esc_html__( 'No free times in the next two weeks. Please check again later.', 'educore-teaching-hub' ) . '</p></div>';
		}
		$opts = '';
		$last = '';
		foreach ( $starts as $s ) {
			$day = Plugin::local( $s, get_option( 'date_format' ) );
			if ( $day !== $last ) {
				$opts .= ( $last ? '</optgroup>' : '' ) . '<optgroup label="' . esc_attr( $day ) . '">';
				$last  = $day;
			}
			$opts .= '<option value="' . esc_attr( $s ) . '">' . esc_html( Plugin::local( $s, get_option( 'time_format' ) ) ) . '</option>';
		}
		$opts  .= '</optgroup>';
		$formats = '';
		foreach ( $card['formats'] as $f ) {
			$formats .= '<option value="' . esc_attr( $f ) . '">' . esc_html( 'in_person' === $f ? __( 'In person', 'educore-teaching-hub' ) : __( 'Online', 'educore-teaching-hub' ) ) . '</option>';
		}
		/* translators: %d: minutes */
		$inner = '<p><label>' . esc_html__( 'Time', 'educore-teaching-hub' ) . ' <select name="start_utc" required>' . $opts . '</select></label> <span class="ec-muted">' . esc_html( sprintf( __( '%d minutes', 'educore-teaching-hub' ), $card['minutes'] ) ) . ' · ' . esc_html( wp_timezone_string() ) . '</span></p><p><label>' . esc_html__( 'Format', 'educore-teaching-hub' ) . ' <select name="format">' . $formats . '</select></label></p><p><label>' . esc_html__( 'Subject', 'educore-teaching-hub' ) . ' <input name="subject" maxlength="190" required></label></p><p><label>' . esc_html__( 'What would you like to work on?', 'educore-teaching-hub' ) . ' <textarea name="objectives" rows="3"></textarea></label></p><p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Send request', 'educore-teaching-hub' ) . '</button></p>';
		return $out . self::form( 'request_session', array( 'tutor_id' => $tutor_id ), $inner ) . '</div>';
	}

	/** Tutor directory block (approved + public profiles). */
	public static function directory(): string {
		wp_enqueue_style( 'educore-th' );
		$tutors = Tutoring::directory( true );
		$out    = '<div class="ec-th-directory">';
		if ( ! $tutors ) {
			return $out . '<p class="ec-muted">' . esc_html__( 'No tutors are listed yet.', 'educore-teaching-hub' ) . '</p></div>';
		}
		$langs = array( 'en' => 'English', 'fr' => 'Français', 'ar' => 'العربية' );
		foreach ( $tutors as $row ) {
			$t    = self::public_tutor( $row );
			$out .= '<article class="ec-card ec-th-tutor"><h3>' . esc_html( $t['name'] ) . '</h3>' . ( $t['headline'] ? '<p><strong>' . esc_html( $t['headline'] ) . '</strong></p>' : '' ) . '<p>' . esc_html( $t['subjects'] ) . '</p><p class="ec-muted">' . esc_html( implode( ' · ', array_map( static fn( $l ) => $langs[ $l ] ?? $l, $t['languages'] ) ) ) . '</p>' . ( $t['bio'] ? '<p>' . esc_html( wp_trim_words( $t['bio'], 40 ) ) . '</p>' : '' );
			$out .= is_user_logged_in()
				? '<p><a class="ec-btn ec-btn--primary" href="' . esc_url( self::url( array( 'th_view' => 'book', 'id' => $t['id'] ) ) ) . '">' . esc_html__( 'Request a session', 'educore-teaching-hub' ) . '</a></p>'
				: '<p><a class="ec-btn" href="' . esc_url( wp_login_url( self::url( array( 'th_view' => 'book', 'id' => $t['id'] ) ) ) ) . '">' . esc_html__( 'Log in to request a session', 'educore-teaching-hub' ) . '</a></p>';
			$out .= '</article>';
		}
		return $out . '</div>';
	}

	/* ---------- POST handler (PRG) ---------- */

	private static function back( string $msg = '', string $err = '', array $args = array() ): void {
		$ref = wp_validate_redirect( (string) wp_get_raw_referer(), self::url() );
		$ref = remove_query_arg( array( 'ec_th_msg', 'ec_th_err' ), $ref );
		wp_safe_redirect( add_query_arg( array_merge( $args, array_filter( array( 'ec_th_msg' => $msg, 'ec_th_err' => $err ) ) ), $ref ) );
		exit;
	}

	public static function handle(): void {
		if ( ! Plugin::is_post() || empty( $_POST['ec_th_action'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- routing check; nonce verified below.
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['ec_th_action'] ) );
		if ( ! in_array( $action, array( 'submit', 'request_session', 'cancel_session', 'ask', 'reply', 'report' ), true ) ) {
			return; // Staff actions are handled by Portal.
		}
		if ( ! is_user_logged_in() || ! isset( $_POST['_ecthnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_ecthnonce'] ) ), 'ec_th_' . $action ) ) {
			wp_die( esc_html__( 'Your session expired. Please reload the page and try again.', 'educore-teaching-hub' ), '', array( 'response' => 403 ) );
		}
		$uid = get_current_user_id();
		$p   = static fn( string $k ) => isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitised by each service.
		switch ( $action ) {
			case 'submit':
				$aid   = absint( $p( 'assignment_id' ) );
				$a     = Assignments::get( $aid );
				$files = array();
				if ( $a && Assignments::is_target( $a, $uid ) && (int) $a['allow_files'] ) {
					foreach ( Files::from_request( 'files' ) as $f ) {
						$st = Files::store( $f );
						if ( is_wp_error( $st ) ) {
							foreach ( $files as $done ) {
								Files::delete( $done['key'] );
							}
							self::back( '', $st->get_error_message() );
						}
						$files[] = $st;
					}
				}
				$res = Assignments::submit( $aid, $uid, (string) $p( 'answer' ), $files, '1' === $p( 'final' ) );
				if ( is_wp_error( $res ) ) {
					foreach ( $files as $done ) {
						Files::delete( $done['key'] );
					}
					self::back( '', $res->get_error_message() );
				}
				self::back( '1' === $p( 'final' ) ? 'submitted' : 'saved' );
				break;
			case 'request_session':
				$res = Tutoring::request( $uid, absint( $p( 'tutor_id' ) ), (string) $p( 'start_utc' ), array( 'format' => sanitize_key( (string) $p( 'format' ) ), 'subject' => (string) $p( 'subject' ), 'objectives' => (string) $p( 'objectives' ) ) );
				if ( is_wp_error( $res ) ) {
					self::back( '', $res->get_error_message() );
				}
				wp_safe_redirect( add_query_arg( 'ec_th_msg', 'requested', self::url() ) );
				exit;
			case 'cancel_session':
				$res = Tutoring::transition( absint( $p( 'session_id' ) ), 'cancelled', $uid, array( 'note' => 'by_student' ) );
				self::back( is_wp_error( $res ) ? '' : 'cancelled', is_wp_error( $res ) ? $res->get_error_message() : '' );
				break;
			case 'ask':
				$res = Comms::start( $uid, 'class', absint( $p( 'class_id' ) ), (string) $p( 'subject' ), (string) $p( 'body' ) );
				if ( is_wp_error( $res ) ) {
					self::back( '', $res->get_error_message() );
				}
				self::back( 'posted', '', array( 'th_view' => 'thread', 'id' => $res ) );
				break;
			case 'reply':
				$res = Comms::reply( $uid, absint( $p( 'thread_id' ) ), (string) $p( 'body' ) );
				self::back( is_wp_error( $res ) ? '' : 'posted', is_wp_error( $res ) ? $res->get_error_message() : '' );
				break;
			case 'report':
				$res = Comms::report( $uid, absint( $p( 'thread_id' ) ), absint( $p( 'message_id' ) ), (string) $p( 'reason' ) );
				self::back( is_wp_error( $res ) ? '' : 'reported', is_wp_error( $res ) ? $res->get_error_message() : '' );
				break;
		}
	}

	/** Authenticated file download: ?ec_th_file=<index>&sub=<submission> | &asg=<assignment>. */
	public static function download(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- nonce checked below.
		if ( ! isset( $_GET['ec_th_file'] ) ) {
			return;
		}
		if ( ! is_user_logged_in() || ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'ec_th_file' ) ) {
			status_header( 403 );
			exit;
		}
		$uid   = get_current_user_id();
		$index = absint( $_GET['ec_th_file'] );
		$files = array();
		if ( ! empty( $_GET['sub'] ) ) {
			$sub = Assignments::submission_by_id( absint( $_GET['sub'] ) );
			if ( $sub && Assignments::can_view_submission( $uid, $sub ) ) {
				$files = (array) json_decode( (string) $sub['files'], true );
			}
		} elseif ( ! empty( $_GET['asg'] ) ) {
			$a = Assignments::get( absint( $_GET['asg'] ) );
			if ( $a && ( Caps::can_grade_assignment( $uid, (int) $a['id'] ) || ( 'draft' !== $a['status'] && Assignments::is_target( $a, $uid ) ) ) ) {
				$files = (array) json_decode( (string) $a['attachments'], true );
			}
		}
		// phpcs:enable
		if ( ! isset( $files[ $index ]['key'] ) ) {
			status_header( 404 );
			exit;
		}
		Access::no_cache_headers();
		\EduCore\Core\Audit::log( 'file.downloaded', 'file', 0, array( 'key' => substr( $files[ $index ]['key'], 0, 8 ) ) );
		Files::serve( $files[ $index ]['key'], $files[ $index ]['name'] );
	}
}
