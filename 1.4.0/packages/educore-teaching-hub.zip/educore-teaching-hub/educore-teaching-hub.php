<?php
/**
 * Plugin Name:       EduCore Teaching & Tutoring Hub
 * Plugin URI:        https://educore.gorgy.org
 * Description:       Teachers, instructors and tutors: classes, groups, lesson planning, assignments, attendance, grading center, private tutoring with safe booking, safeguarded communication and teaching analytics.
 * Version:           1.2.0
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core
 * EduCore Requires Core: 1.1.0
 * Author:            GORGY.ORG
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-teaching-hub
 * Domain Path:       /languages
 *
 * @package EduCore\TeachingHub
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_TH_VERSION', '1.2.0' );
define( 'EDUCORE_TH_DB_VERSION', 2 );
define( 'EDUCORE_TH_FILE', __FILE__ );
define( 'EDUCORE_TH_DIR', plugin_dir_path( __FILE__ ) );
define( 'EDUCORE_TH_URL', plugin_dir_url( __FILE__ ) );

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Teaching & Tutoring Hub', '1.1.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\TeachingHub\\', EDUCORE_TH_DIR . 'src/' );
		\EduCore\TeachingHub\Plugin::boot();
	}
);

add_action(
	'admin_notices',
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) && current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'EduCore Teaching & Tutoring Hub requires the EduCore Core plugin (1.1.0 or newer). It has not been loaded.', 'educore-teaching-hub' ) . '</p></div>';
		}
	}
);

register_activation_hook(
	__FILE__,
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) || version_compare( EDUCORE_CORE_VERSION, '1.1.0', '<' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die( esc_html__( 'Please install and activate EduCore Core 1.1.0 or newer first.', 'educore-teaching-hub' ), '', array( 'back_link' => true ) );
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\TeachingHub\\', EDUCORE_TH_DIR . 'src/' );
		\EduCore\TeachingHub\Plugin::install();
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		wp_clear_scheduled_hook( 'educore_th_daily' );
	}
);
