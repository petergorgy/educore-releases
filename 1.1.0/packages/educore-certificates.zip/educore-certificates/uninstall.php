<?php
/** Removes certificates only when the EduCore "delete all data" preference was confirmed. */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
if ( 'yes' !== get_option( 'educore_uninstall_delete_data' ) ) {
	return;
}
global $wpdb;
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'ec_certificates' ); // phpcs:ignore WordPress.DB.PreparedSQL
foreach ( get_posts( array( 'post_type' => 'ec_cert_template', 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids' ) ) as $id ) {
	wp_delete_post( $id, true );
}
$up  = wp_upload_dir( null, false );
$dir = trailingslashit( $up['basedir'] ) . 'educore-certificates';
if ( is_dir( $dir ) ) {
	foreach ( (array) glob( $dir . '/{,.}[!.,!..]*', GLOB_BRACE ) as $f ) {
		is_file( $f ) && unlink( $f ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
}
foreach ( array( 'educore_certificates_db_version', 'educore_cert_default_templates', 'educore_cert_verify_page' ) as $o ) {
	delete_option( $o );
}
