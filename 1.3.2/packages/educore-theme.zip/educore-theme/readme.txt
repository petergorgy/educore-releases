=== EduCore ===
Contributors: gorgyorg
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The EduCore block theme: a calm, accessible learning interface in English, French and Arabic.

== Description ==

Presentation layer for the EduCore LMS (https://educore.gorgy.org). All learning features come from the EduCore plugins; the theme contains no business logic.

* Design tokens in theme.json (navy, teal, cream, gold), fluid type, self-hosted IBM Plex Sans and IBM Plex Sans Arabic.
* Templates for home, course catalogue, course, lesson reader, pages, search and 404.
* Light and dark mode, right-to-left layout for Arabic, reduced-motion support, WCAG 2.2 AA colour contrast.

== Copyright ==

EduCore theme, (C) 2026 GORGY.ORG, GPLv2 or later.
IBM Plex Sans and IBM Plex Sans Arabic: SIL Open Font License 1.1 (see assets/fonts).

== Changelog ==
= 1.1.0 =
* Legal links are shown as "in preparation" until the owner publishes the page (no more 404s, drafts never presented as approved) (D-01).
* Registration calls to action follow EduCore → Settings; closed registration shows "Request access" (D-02).


= 1.0.0 =
* First release.
