<?php
namespace EduCore\Workspace;

defined( 'ABSPATH' ) || exit;

/** Tutor workspace (/tutor/): the Teaching Hub's tutoring views under the tutor's own address and navigation. */
final class Tutor {
	public const KEYS = array( 'overview', 'tutoring', 'calendar', 'analytics', 'messages' );

	public static function register(): void {
		add_shortcode( 'educore_tutor_workspace', array( self::class, 'render' ) );
		add_filter( 'educore/th/base_url', array( self::class, 'base_url' ) );
		add_filter( 'educore/th/nav', array( self::class, 'nav' ), 10, 2 );
	}

	private static function on_tutor_page(): bool {
		return did_action( 'wp' ) && 'tutor' === Shell::resolve();
	}

	public static function base_url( $url ) {
		return self::on_tutor_page() ? Pages::url( 'tutor' ) : $url;
	}

	public static function nav( array $nav, int $uid ): array {
		return self::on_tutor_page() ? array_intersect_key( $nav, array_flip( self::KEYS ) ) : $nav;
	}

	public static function render(): string {
		if ( ! class_exists( '\EduCore\TeachingHub\Portal' ) ) {
			return '<div class="ec-notice ec-notice--info">' . esc_html__( 'The tutor workspace needs the EduCore Teaching & Tutoring Hub.', 'educore-workspace' ) . '</div>';
		}
		return \EduCore\TeachingHub\Portal::render();
	}
}
