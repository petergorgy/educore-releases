<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Default pages created by the setup wizard (never with demo data). */
final class Pages {
	public const OPTION = 'educore_pages';

	public static function register(): void {
		add_filter( 'the_title', array( self::class, 'translate_title' ), 10, 2 );
	}

	/**
	 * Default pages are stored with English titles; show the interface-language title instead
	 * while the stored title is still the default one (an owner-edited title is left untouched).
	 */
	public static function translate_title( $title, $post_id = 0 ) {
		if ( is_admin() || ! $post_id || 'page' !== get_post_type( $post_id ) ) {
			return $title;
		}
		$key = array_search( (int) $post_id, array_map( 'intval', (array) get_option( self::OPTION, array() ) ), true );
		if ( false === $key || I18n::DEFAULT === I18n::current() ) {
			return $title;
		}
		$defs = self::definitions();
		return isset( $defs[ $key ] ) && in_array( html_entity_decode( wp_strip_all_tags( (string) $title ), ENT_QUOTES ), self::english_titles(), true ) ? $defs[ $key ]['title'] : $title;
	}

	/** English default titles (independent of the current locale). */
	private static function english_titles(): array {
		return array( 'My learning', 'Learning history', 'My profile', 'Create your account', 'Guardian consent', 'Instructor workspace', 'About EduCore', 'Contact & support', 'Privacy Policy', 'Terms of Service', 'Cookie information', 'Subscription policy' );
	}

	/** @return array<string,array{title:string,content:string}> */
	public static function definitions(): array {
		$legal_note = '<!-- wp:paragraph {"className":"ec-legal-draft"} --><p class="ec-legal-draft">' . esc_html__( 'DRAFT — this text must be reviewed by the site owner and legal counsel before publication.', 'educore-core' ) . '</p><!-- /wp:paragraph -->';
		return array(
			'dashboard'     => array( 'title' => __( 'My learning', 'educore-core' ), 'content' => '<!-- wp:educore/student-dashboard /-->' ),
			'history'       => array( 'title' => __( 'Learning history', 'educore-core' ), 'content' => '<!-- wp:educore/learning-history /-->' ),
			'profile'       => array( 'title' => __( 'My profile', 'educore-core' ), 'content' => '<!-- wp:educore/profile /-->' ),
			'register'      => array( 'title' => __( 'Create your account', 'educore-core' ), 'content' => '<!-- wp:educore/register /-->' ),
			'guardian'      => array( 'title' => __( 'Guardian consent', 'educore-core' ), 'content' => '<!-- wp:educore/guardian-consent /-->' ),
			'workspace'     => array( 'title' => __( 'Instructor workspace', 'educore-core' ), 'content' => '<!-- wp:educore/instructor-workspace /-->' ),
			'about'         => array( 'title' => __( 'About EduCore', 'educore-core' ), 'content' => '<!-- wp:pattern {"slug":"educore/about"} /-->' ),
			'contact'       => array( 'title' => __( 'Contact & support', 'educore-core' ), 'content' => '<!-- wp:educore/contact-form /-->' ),
			'privacy'       => array( 'title' => __( 'Privacy Policy', 'educore-core' ), 'content' => $legal_note . '<!-- wp:pattern {"slug":"educore/legal-privacy"} /-->' ),
			'terms'         => array( 'title' => __( 'Terms of Service', 'educore-core' ), 'content' => $legal_note . '<!-- wp:pattern {"slug":"educore/legal-terms"} /-->' ),
			'cookies'       => array( 'title' => __( 'Cookie information', 'educore-core' ), 'content' => $legal_note . '<!-- wp:pattern {"slug":"educore/legal-cookies"} /-->' ),
			'subscriptions' => array( 'title' => __( 'Subscription policy', 'educore-core' ), 'content' => $legal_note . '<!-- wp:pattern {"slug":"educore/legal-subscriptions"} /-->' ),
		);
	}

	/** Idempotent: creates only missing pages. Legal pages are created as drafts. @return array<string,int> */
	public static function create_missing(): array {
		$pages = (array) get_option( self::OPTION, array() );
		foreach ( self::definitions() as $key => $def ) {
			if ( ! empty( $pages[ $key ] ) && get_post( (int) $pages[ $key ] ) ) {
				continue;
			}
			$draft          = in_array( $key, array( 'privacy', 'terms', 'cookies', 'subscriptions' ), true );
			$pages[ $key ] = (int) wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => $draft ? 'draft' : 'publish',
					'post_title'   => $def['title'],
					'post_name'    => $key,
					'post_content' => $def['content'],
				)
			);
		}
		update_option( self::OPTION, $pages, false );
		if ( ! empty( $pages['privacy'] ) ) {
			update_option( 'wp_page_for_privacy_policy', (int) $pages['privacy'] );
		}
		return $pages;
	}

	public static function id( string $key ): int {
		$pages = (array) get_option( self::OPTION, array() );
		return (int) ( $pages[ $key ] ?? 0 );
	}

	/** True when the EduCore page for $key exists and is published (legal drafts stay unlinked). */
	public static function is_published( string $key ): bool {
		$id = self::id( $key );
		return $id > 0 && 'publish' === get_post_status( $id );
	}

	/** Self-registration policy (EduCore → Settings). Calls to action must follow it. */
	public static function registration_open(): bool {
		return 'closed' !== get_option( 'educore_registration', 'open' );
	}

	public static function url( string $key ): string {
		$id = 'courses' === $key ? 0 : self::id( $key );
		if ( $id && 'publish' === get_post_status( $id ) ) {
			return (string) get_permalink( $id );
		}
		// The course archive (/courses/) is the catalogue; the EduCore theme renders it with the catalogue block.
		return 'courses' === $key ? (string) get_post_type_archive_link( Content::COURSE ) : home_url( '/' . $key . '/' );
	}
}
