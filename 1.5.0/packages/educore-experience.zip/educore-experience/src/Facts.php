<?php
namespace EduCore\Experience;

use EduCore\Core\Pages as CorePages;

defined( 'ABSPATH' ) || exit;

/**
 * Verified, role-specific facts for the welcome card. Every item is computed from EduCore records the person is
 * allowed to see; nothing is estimated or invented. A source that is unavailable simply contributes nothing.
 *
 * Each fact: array{text:string, url:string, kind:string}
 */
final class Facts {

	public static function collect( int $uid, string $lens ): array {
		$facts = array();
		switch ( $lens ) {
			case 'student':
				$facts = self::student( $uid );
				break;
			case 'teacher':
			case 'instructor':
				$facts = self::teacher( $uid );
				break;
			case 'tutor':
				$facts = self::tutor( $uid );
				break;
			case 'guardian':
				$facts = self::guardian( $uid );
				break;
			case 'manager':
			case 'admin':
				$facts = self::manager( $uid, 'admin' === $lens );
				break;
		}
		return (array) apply_filters( 'educore/experience/facts', $facts, $uid, $lens );
	}

	public static function student( int $uid ): array {
		$out = array();
		if ( ! class_exists( '\EduCore\Core\Dashboard' ) ) {
			return $out;
		}
		$d     = self::dashboard( $uid );
		$ready = count( (array) $d['recommended'] );
		if ( $ready ) {
			/* translators: %s: number of lessons */
			$out[] = array( 'kind' => 'lessons', 'text' => sprintf( _n( '%s lesson is ready to continue.', '%s lessons are ready to continue.', $ready, 'educore-experience' ), number_format_i18n( $ready ) ), 'url' => CorePages::url( 'dashboard' ) . '#ec-xp-suggestions' );
		}
		$due = 0;
		if ( class_exists( '\EduCore\Workspace\Agenda' ) ) {
			foreach ( self::agenda( $uid ) as $it ) {
				if ( in_array( $it['kind'], array( 'assessment', 'assignment' ), true ) && ( $it['overdue'] || $it['ts'] <= time() + 7 * DAY_IN_SECONDS ) ) {
					++$due;
				}
			}
		}
		if ( $due ) {
			/* translators: %s: number of items */
			$out[] = array( 'kind' => 'due', 'text' => sprintf( _n( '%s assessment or assignment is due within a week.', '%s assessments or assignments are due within a week.', $due, 'educore-experience' ), number_format_i18n( $due ) ), 'url' => CorePages::url( 'dashboard' ) . '#ec-agenda-h' );
		}
		$p = Prefs::get( $uid );
		if ( ! $p['goals_paused'] && ! empty( $d['goal'] ) ) {
			$left = max( 0, (int) $d['goal']['target'] - (int) $d['goal']['done'] );
			$out[] = $left
				/* translators: %s: number of lessons */
				? array( 'kind' => 'goal', 'text' => sprintf( _n( '%s more lesson reaches your weekly goal.', '%s more lessons reach your weekly goal.', $left, 'educore-experience' ), number_format_i18n( $left ) ), 'url' => Plugin::url( 'preferences' ) . '#ec-xp-s-goals' )
				: array( 'kind' => 'goal', 'text' => __( 'You reached your weekly lesson goal. Well done!', 'educore-experience' ), 'url' => '' );
		}
		return $out;
	}

	public static function teacher( int $uid ): array {
		$out = array();
		if ( class_exists( '\EduCore\TeachingHub\Portal' ) && method_exists( '\EduCore\TeachingHub\Portal', 'grading_items' ) && user_can( $uid, 'ec_teach' ) ) {
			$n = count( (array) \EduCore\TeachingHub\Portal::grading_items( $uid ) );
			$out[] = $n
				/* translators: %s: number of submissions */
				? array( 'kind' => 'grading', 'text' => sprintf( _n( '%s submission is waiting for your review.', '%s submissions are waiting for your review.', $n, 'educore-experience' ), number_format_i18n( $n ) ), 'url' => \EduCore\TeachingHub\Portal::url( 'grading' ) )
				: array( 'kind' => 'grading', 'text' => __( 'Nothing is waiting to be graded.', 'educore-experience' ), 'url' => '' );
		}
		if ( class_exists( '\EduCore\Workspace\Studio\Courses' ) && user_can( $uid, 'publish_ec_courses' ) && method_exists( '\EduCore\Workspace\Studio\Courses', 'review_queue' ) ) {
			$q = count( (array) \EduCore\Workspace\Studio\Courses::review_queue( $uid ) );
			if ( $q ) {
				/* translators: %s: number of courses */
				$out[] = array( 'kind' => 'review', 'text' => sprintf( _n( '%s course is waiting for review.', '%s courses are waiting for review.', $q, 'educore-experience' ), number_format_i18n( $q ) ), 'url' => \EduCore\Workspace\Pages::url( 'studio', array( 'v' => 'review' ) ) );
			}
		}
		return $out;
	}

	public static function tutor( int $uid ): array {
		$out = array();
		if ( ! class_exists( '\EduCore\TeachingHub\Tutoring' ) || ! method_exists( '\EduCore\TeachingHub\Tutoring', 'for_tutor' ) ) {
			return $out;
		}
		$up        = (array) \EduCore\TeachingHub\Tutoring::for_tutor( $uid, 'upcoming', 50 );
		$requested = array_filter( $up, static fn( $s ) => 'requested' === ( $s['status'] ?? '' ) );
		$confirmed = array_values( array_filter( $up, static fn( $s ) => 'confirmed' === ( $s['status'] ?? '' ) ) );
		$base      = class_exists( '\EduCore\Workspace\Pages' ) ? \EduCore\Workspace\Pages::url( 'tutor' ) : '';
		if ( $confirmed ) {
			$ts  = (int) strtotime( $confirmed[0]['starts_at'] . ' UTC' );
			$out[] = array(
				'kind' => 'session',
				/* translators: %s: date and time of the session */
				'text' => sprintf( __( 'Your next tutoring session is on %s.', 'educore-experience' ), self::when( $ts, Clock::tz_for( $uid ) ) ),
				'url'  => $base,
			);
		} else {
			$out[] = array( 'kind' => 'session', 'text' => __( 'You have no upcoming tutoring sessions.', 'educore-experience' ), 'url' => '' );
		}
		if ( $requested ) {
			$n = count( $requested );
			/* translators: %s: number of requests */
			$out[] = array( 'kind' => 'requests', 'text' => sprintf( _n( '%s booking request needs your answer.', '%s booking requests need your answer.', $n, 'educore-experience' ), number_format_i18n( $n ) ), 'url' => $base );
		}
		return $out;
	}

	public static function guardian( int $uid ): array {
		$out = array();
		if ( ! class_exists( '\EduCore\Workspace\Guardian' ) ) {
			return $out;
		}
		$kids = (array) \EduCore\Workspace\Guardian::learners( $uid );
		$n    = count( $kids );
		if ( ! $n ) {
			$out[] = array( 'kind' => 'children', 'text' => __( 'No learner is linked to your account yet. The school links learners after confirming your relationship.', 'educore-experience' ), 'url' => '' );
			return $out;
		}
		$text = 1 === $n
			? __( 'Here is the latest progress for your linked learner.', 'educore-experience' )
			/* translators: %s: number of learners (2 or more) */
			: sprintf( _n( 'Here is the latest progress for your %s linked learner.', 'Here is the latest progress for your %s linked learners.', $n, 'educore-experience' ), number_format_i18n( $n ) );
		$out[] = array( 'kind' => 'children', 'text' => $text, 'url' => CorePages::url( 'guardian' ) );
		return $out;
	}

	public static function manager( int $uid, bool $admin ): array {
		$out     = array();
		$courses = wp_count_posts( 'ec_course' );
		$pending = (int) ( $courses->pending ?? 0 );
		if ( $pending && class_exists( '\EduCore\Workspace\Pages' ) ) {
			/* translators: %s: number of courses */
			$out[] = array( 'kind' => 'review', 'text' => sprintf( _n( '%s course is awaiting review.', '%s courses are awaiting review.', $pending, 'educore-experience' ), number_format_i18n( $pending ) ), 'url' => \EduCore\Workspace\Pages::url( 'manage', array( 'v' => 'courses', 'status' => 'pending' ) ) );
		}
		if ( $admin && class_exists( '\EduCore\Core\Installer' ) && method_exists( '\EduCore\Core\Installer', 'environment_checks' ) ) {
			$cached = get_transient( 'educore_xp_health' );
			if ( ! is_array( $cached ) ) {
				$cached = array( 'warn' => 0, 'fail' => 0 );
				foreach ( (array) \EduCore\Core\Installer::environment_checks() as $c ) {
					$st = strtolower( (string) ( $c['status'] ?? $c['state'] ?? '' ) );
					if ( in_array( $st, array( 'warn', 'fail' ), true ) ) {
						++$cached[ $st ];
					}
				}
				set_transient( 'educore_xp_health', $cached, 10 * MINUTE_IN_SECONDS );
			}
			$url   = class_exists( '\EduCore\Workspace\Pages' ) ? \EduCore\Workspace\Pages::url( 'manage', array( 'v' => 'system' ) ) : '';
			$out[] = $cached['fail']
				/* translators: %s: number of checks */
				? array( 'kind' => 'health', 'text' => sprintf( _n( '%s platform check is failing.', '%s platform checks are failing.', $cached['fail'], 'educore-experience' ), number_format_i18n( $cached['fail'] ) ), 'url' => $url )
				: ( $cached['warn']
					/* translators: %s: number of checks */
					? array( 'kind' => 'health', 'text' => sprintf( _n( 'Platform health: no failures, %s warning to review.', 'Platform health: no failures, %s warnings to review.', $cached['warn'], 'educore-experience' ), number_format_i18n( $cached['warn'] ) ), 'url' => $url )
					: array( 'kind' => 'health', 'text' => __( 'All platform checks pass.', 'educore-experience' ), 'url' => $url ) );
		}
		return $out;
	}

	/** Request-level cache of the "Coming up" items. */
	public static function agenda( int $uid ): array {
		static $c = array();
		if ( ! isset( $c[ $uid ] ) ) {
			$c[ $uid ] = class_exists( '\EduCore\Workspace\Agenda' ) ? (array) \EduCore\Workspace\Agenda::items( $uid ) : array();
		}
		return $c[ $uid ];
	}

	/** Request-level cache of the student dashboard model. */
	public static function dashboard( int $uid ): array {
		static $c = array();
		if ( ! isset( $c[ $uid ] ) ) {
			$c[ $uid ] = \EduCore\Core\Dashboard::student( $uid );
		}
		return $c[ $uid ];
	}

	public static function when( int $ts, string $tz ): string {
		return Clock::format( $ts, $tz, true );
	}
}
