<?php
namespace EduCore\Core\Rest;

use EduCore\Core\Access;
use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Enrollment;
use EduCore\Core\I18n;
use EduCore\Core\Privacy;
use EduCore\Core\Profile;
use EduCore\Core\Progress;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Endpoints for the signed-in learner, always scoped to the current user. */
final class LearnerController {

	public static function routes(): void {
		$lesson = array( 'id' => Routes::id_arg() );
		register_rest_route( Routes::NS, '/courses/(?P<id>\d+)/enroll', array( 'methods' => 'POST', 'callback' => array( self::class, 'enroll' ), 'permission_callback' => array( Routes::class, 'logged_in' ), 'args' => array( 'id' => Routes::id_arg() ) ) );
		register_rest_route( Routes::NS, '/me/dashboard', array( 'methods' => 'GET', 'callback' => array( self::class, 'dashboard' ), 'permission_callback' => array( Routes::class, 'logged_in' ) ) );
		register_rest_route( Routes::NS, '/me/history', array( 'methods' => 'GET', 'callback' => array( self::class, 'history' ), 'permission_callback' => array( Routes::class, 'logged_in' ) ) );
		register_rest_route(
			Routes::NS,
			'/me/profile',
			array(
				array( 'methods' => 'GET', 'callback' => array( self::class, 'get_profile' ), 'permission_callback' => array( Routes::class, 'logged_in' ) ),
				array( 'methods' => 'POST', 'callback' => array( self::class, 'update_profile' ), 'permission_callback' => array( Routes::class, 'logged_in' ) ),
			)
		);
		register_rest_route( Routes::NS, '/lessons/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => array( self::class, 'get_lesson' ), 'permission_callback' => array( self::class, 'can_view_lesson' ), 'args' => $lesson ) );
		register_rest_route( Routes::NS, '/lessons/(?P<id>\d+)/complete', array( 'methods' => 'POST', 'callback' => array( self::class, 'complete' ), 'permission_callback' => array( self::class, 'can_view_lesson' ), 'args' => $lesson ) );
		register_rest_route(
			Routes::NS,
			'/lessons/(?P<id>\d+)/heartbeat',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'heartbeat' ),
				'permission_callback' => array( self::class, 'can_view_lesson' ),
				'args'                => array_merge( $lesson, array( 'seconds' => array( 'type' => 'integer', 'default' => 30, 'minimum' => 0, 'maximum' => 600 ) ) ),
			)
		);
		register_rest_route(
			Routes::NS,
			'/lessons/(?P<id>\d+)/notes',
			array(
				array( 'methods' => 'GET', 'callback' => array( self::class, 'notes' ), 'permission_callback' => array( self::class, 'can_view_lesson' ), 'args' => $lesson ),
				array(
					'methods'             => 'POST',
					'callback'            => array( self::class, 'add_note' ),
					'permission_callback' => array( self::class, 'can_view_lesson' ),
					'args'                => array_merge(
						$lesson,
						array(
							'type' => array( 'type' => 'string', 'enum' => array( 'note', 'bookmark' ), 'default' => 'note' ),
							'body' => array( 'type' => 'string', 'default' => '', 'maxLength' => 5000 ),
						)
					),
				),
			)
		);
		register_rest_route( Routes::NS, '/notes/(?P<id>\d+)', array( 'methods' => 'DELETE', 'callback' => array( self::class, 'delete_note' ), 'permission_callback' => array( Routes::class, 'logged_in' ), 'args' => array( 'id' => Routes::id_arg() ) ) );
	}

	public static function can_view_lesson( \WP_REST_Request $r ): bool {
		return is_user_logged_in() && Access::can_view_lesson( get_current_user_id(), (int) $r['id'] );
	}

	public static function enroll( \WP_REST_Request $r ) {
		$err = Routes::throttle( 'rest_write' );
		if ( $err ) {
			return $err;
		}
		$uid = get_current_user_id();
		$cid = (int) $r['id'];
		if ( ! Privacy::has_required_consent( $uid ) ) {
			return Routes::error( 'educore_consent_required', __( 'Your account is waiting for guardian consent.', 'educore-core' ), 403 );
		}
		if ( ! Access::can_self_enroll( $uid, $cid ) ) {
			return Routes::error( 'educore_enroll_closed', __( 'Enrollment for this course is not open.', 'educore-core' ), 403 );
		}
		$id = Enrollment::enroll( $uid, $cid, 'self' );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		return new \WP_REST_Response( array( 'enrolled' => true, 'course_url' => get_permalink( $cid ) ), 201 );
	}

	public static function dashboard(): \WP_REST_Response {
		return new \WP_REST_Response( \EduCore\Core\Dashboard::student( get_current_user_id() ) );
	}

	public static function history(): \WP_REST_Response {
		return new \WP_REST_Response( \EduCore\Core\Dashboard::history( get_current_user_id() ) );
	}

	public static function get_profile(): \WP_REST_Response {
		return new \WP_REST_Response( Profile::get( get_current_user_id() ) );
	}

	public static function update_profile( \WP_REST_Request $r ) {
		$err = Routes::throttle( 'rest_write' );
		if ( $err ) {
			return $err;
		}
		$res = Profile::update( get_current_user_id(), (array) $r->get_json_params() + (array) $r->get_body_params() );
		return is_wp_error( $res ) ? $res : new \WP_REST_Response( Profile::get( get_current_user_id() ) );
	}

	public static function get_lesson( \WP_REST_Request $r ): \WP_REST_Response {
		$id   = (int) $r['id'];
		$post = get_post( $id );
		Progress::touch( get_current_user_id(), $id );
		$nb = Content::neighbours( $id );
		return new \WP_REST_Response(
			array(
				'id'         => $id,
				'title'      => get_the_title( $post ),
				'content'    => apply_filters( 'the_content', $post->post_content ),
				'objectives' => (string) get_post_meta( $id, '_ec_objectives', true ),
				'minutes'    => (int) get_post_meta( $id, '_ec_minutes', true ),
				'rule'       => Progress::rule( $id ),
				'completed'  => Progress::is_complete( get_current_user_id(), $id ),
				'prev'       => $nb['prev'],
				'next'       => $nb['next'],
				'course_id'  => Content::course_of( $id ),
			)
		);
	}

	public static function complete( \WP_REST_Request $r ) {
		$res = Progress::complete( get_current_user_id(), (int) $r['id'], 'manual' );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$cid = Content::course_of( (int) $r['id'] );
		return new \WP_REST_Response( array( 'completed' => true, 'course' => Progress::course_summary( get_current_user_id(), $cid ) ) );
	}

	public static function heartbeat( \WP_REST_Request $r ) {
		$err = Routes::throttle( 'autosave' );
		if ( $err ) {
			return $err;
		}
		$total = Progress::heartbeat( get_current_user_id(), (int) $r['id'], (int) $r['seconds'] );
		return new \WP_REST_Response( array( 'active_seconds' => $total, 'completed' => Progress::is_complete( get_current_user_id(), (int) $r['id'] ) ) );
	}

	public static function notes( \WP_REST_Request $r ): \WP_REST_Response {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, type, body, created_at FROM ' . Schema::table( 'notes' ) . ' WHERE user_id=%d AND lesson_id=%d ORDER BY id DESC', get_current_user_id(), (int) $r['id'] ), ARRAY_A );
		return new \WP_REST_Response( $rows ?: array() );
	}

	public static function add_note( \WP_REST_Request $r ) {
		global $wpdb;
		$err = Routes::throttle( 'rest_write' );
		if ( $err ) {
			return $err;
		}
		$type = 'bookmark' === $r['type'] ? 'bookmark' : 'note';
		if ( 'bookmark' === $type ) {
			$wpdb->delete( Schema::table( 'notes' ), array( 'user_id' => get_current_user_id(), 'lesson_id' => (int) $r['id'], 'type' => 'bookmark' ) );
		}
		$wpdb->insert( Schema::table( 'notes' ), array( 'user_id' => get_current_user_id(), 'lesson_id' => (int) $r['id'], 'type' => $type, 'body' => sanitize_textarea_field( (string) $r['body'] ), 'created_at' => Schema::now() ) );
		return new \WP_REST_Response( array( 'id' => (int) $wpdb->insert_id ), 201 );
	}

	public static function delete_note( \WP_REST_Request $r ) {
		global $wpdb;
		// Ownership enforced in the WHERE clause (no IDOR).
		$n = $wpdb->delete( Schema::table( 'notes' ), array( 'id' => (int) $r['id'], 'user_id' => get_current_user_id() ), array( '%d', '%d' ) );
		return $n ? new \WP_REST_Response( array( 'deleted' => true ) ) : Routes::error( 'educore_not_found', __( 'Note not found.', 'educore-core' ), 404 );
	}
}
