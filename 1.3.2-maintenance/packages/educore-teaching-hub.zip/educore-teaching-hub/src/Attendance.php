<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Audit;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Attendance for class meetings (context=class, date) and tutoring sessions (context=session). */
final class Attendance {
	public const STATUSES = array( 'present', 'absent', 'late', 'excused' );

	private static function t(): string {
		return Schema::table( 'th_attendance' );
	}

	/**
	 * Record marks. $marks: student_id => status ('' = not recorded → existing mark removed).
	 * Changes are audited with old → new values.
	 *
	 * @return int|\WP_Error number of changed marks
	 */
	public static function record( string $context, int $context_id, string $day, array $marks, int $actor, array $notes = array() ) {
		global $wpdb;
		if ( ! in_array( $context, array( 'class', 'session' ), true ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $day ) ) {
			return new \WP_Error( 'ec_th_att', __( 'Invalid attendance context or date.', 'educore-teaching-hub' ) );
		}
		if ( $day > wp_date( 'Y-m-d' ) ) {
			return new \WP_Error( 'ec_th_future', __( 'Attendance cannot be recorded for a future date.', 'educore-teaching-hub' ) );
		}
		$allowed = 'class' === $context ? Classes::members( $context_id ) : Tutoring::participants( $context_id );
		$changed = 0;
		$current = self::for_context( $context, $context_id, $day );
		foreach ( $marks as $sid => $status ) {
			$sid    = (int) $sid;
			$status = (string) $status;
			if ( ! in_array( $sid, $allowed, true ) ) {
				continue; // Out of scope students are ignored, never written.
			}
			$old = $current[ $sid ]['status'] ?? '';
			if ( '' === $status ) {
				if ( '' !== $old ) {
					$wpdb->delete( self::t(), array( 'context_type' => $context, 'context_id' => $context_id, 'occurs_on' => $day, 'student_id' => $sid ) );
					Audit::log( 'attendance.cleared', $context, $context_id, array( 'student_id' => $sid, 'day' => $day, 'old' => $old ) );
					++$changed;
				}
				continue;
			}
			if ( ! in_array( $status, self::STATUSES, true ) || $status === $old && ( $notes[ $sid ] ?? '' ) === ( $current[ $sid ]['note'] ?? '' ) ) {
				continue;
			}
			$wpdb->query( $wpdb->prepare( 'INSERT INTO ' . self::t() . ' (context_type,context_id,occurs_on,student_id,status,note,recorded_by,recorded_at) VALUES (%s,%d,%s,%d,%s,%s,%d,%s) ON DUPLICATE KEY UPDATE status=VALUES(status), note=VALUES(note), recorded_by=VALUES(recorded_by), recorded_at=VALUES(recorded_at)', $context, $context_id, $day, $sid, $status, mb_substr( sanitize_text_field( (string) ( $notes[ $sid ] ?? '' ) ), 0, 255 ), $actor, Schema::now() ) );
			Audit::log( 'attendance.' . ( '' === $old ? 'recorded' : 'changed' ), $context, $context_id, array( 'student_id' => $sid, 'day' => $day, 'old' => $old, 'new' => $status ) );
			++$changed;
		}
		return $changed;
	}

	/** @return array<int,array{status:string,note:string}> */
	public static function for_context( string $context, int $context_id, string $day ): array {
		global $wpdb;
		$out = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT student_id, status, note FROM ' . self::t() . ' WHERE context_type=%s AND context_id=%d AND occurs_on=%s', $context, $context_id, $day ), ARRAY_A ) ?: array() as $r ) {
			$out[ (int) $r['student_id'] ] = array( 'status' => $r['status'], 'note' => $r['note'] );
		}
		return $out;
	}

	/** Per-status counts for one student (optionally since a date). @return array<string,int> */
	public static function student_summary( int $student_id, string $since = '' ): array {
		global $wpdb;
		$where = $wpdb->prepare( 'student_id=%d', $student_id ) . ( $since ? $wpdb->prepare( ' AND occurs_on>=%s', $since ) : '' );
		$out   = array_fill_keys( self::STATUSES, 0 );
		foreach ( $wpdb->get_results( 'SELECT status, COUNT(*) n FROM ' . self::t() . " WHERE {$where} GROUP BY status", ARRAY_A ) ?: array() as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$out[ $r['status'] ] = (int) $r['n'];
		}
		return $out;
	}

	/** Class summary per student over a date range: student_id => counts. */
	public static function class_summary( int $class_id, string $from, string $to ): array {
		global $wpdb;
		$out = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT student_id, status, COUNT(*) n FROM ' . self::t() . " WHERE context_type='class' AND context_id=%d AND occurs_on BETWEEN %s AND %s GROUP BY student_id, status", $class_id, $from, $to ), ARRAY_A ) ?: array() as $r ) {
			$out[ (int) $r['student_id'] ][ $r['status'] ] = (int) $r['n'];
		}
		return $out;
	}

	/** Attendance rate (present+late over recorded) for a set of class ids since a date; null = no data. */
	public static function rate( array $class_ids, string $since ): ?float {
		global $wpdb;
		$class_ids = array_filter( array_map( 'intval', $class_ids ) );
		if ( ! $class_ids ) {
			return null;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT SUM(status IN ('present','late')) ok, COUNT(*) n FROM " . self::t() . " WHERE context_type='class' AND context_id IN (" . implode( ',', $class_ids ) . ') AND occurs_on>=%s', $since ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		return ( $row && (int) $row['n'] ) ? round( 100 * (int) $row['ok'] / (int) $row['n'], 1 ) : null;
	}

	/** CSV rows for a class over a range (date, student, status, note). */
	public static function export_rows( int $class_id, string $from, string $to ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT a.occurs_on, u.display_name, a.status, a.note FROM ' . self::t() . ' a JOIN ' . $wpdb->users . " u ON u.ID=a.student_id WHERE a.context_type='class' AND a.context_id=%d AND a.occurs_on BETWEEN %s AND %s ORDER BY a.occurs_on, u.display_name", $class_id, $from, $to ), ARRAY_N ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		array_unshift( $rows, array( __( 'Date', 'educore-teaching-hub' ), __( 'Student', 'educore-teaching-hub' ), __( 'Status', 'educore-teaching-hub' ), __( 'Note', 'educore-teaching-hub' ) ) );
		return $rows;
	}
}
