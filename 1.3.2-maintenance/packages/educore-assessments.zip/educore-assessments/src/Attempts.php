<?php
namespace EduCore\Assessments;

use EduCore\Core\Access;
use EduCore\Core\Audit;
use EduCore\Core\Privacy;
use EduCore\Core\Progress;
use EduCore\Core\Schema as CoreSchema;

defined( 'ABSPATH' ) || exit;

/**
 * Server-authoritative attempt engine.
 *   open → submitted (essay items await grading) → graded → (released flag)
 * Deadlines are computed on the server; answers are refused after deadline + grace.
 */
final class Attempts {
	public const GRACE = 30;

	public static function get( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::t( 'attempts' ) . ' WHERE id=%d', $id ), ARRAY_A );
		return $row ?: null;
	}

	public static function for_user( int $assessment_id, int $user_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::t( 'attempts' ) . ' WHERE assessment_id=%d AND user_id=%d ORDER BY attempt_no', $assessment_id, $user_id ), ARRAY_A ) ?: array();
	}

	public static function open_attempt( int $assessment_id, int $user_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::t( 'attempts' ) . " WHERE assessment_id=%d AND user_id=%d AND state='open'", $assessment_id, $user_id ), ARRAY_A );
		return $row ?: null;
	}

	public static function used( int $assessment_id, int $user_id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Schema::t( 'attempts' ) . ' WHERE assessment_id=%d AND user_id=%d', $assessment_id, $user_id ) );
	}

	public static function remaining( array $a, int $user_id ): ?int {
		$max = (int) $a['settings']['attempts'];
		return $max ? max( 0, $max - self::used( (int) $a['id'], $user_id ) ) : null;
	}

	public static function past_grace( array $attempt ): bool {
		return ! empty( $attempt['deadline_at'] ) && strtotime( $attempt['deadline_at'] . ' UTC' ) + self::GRACE < time();
	}

	/** Can this learner take the assessment right now (ignoring an already-open attempt)? */
	public static function can_take( array $a, int $user_id ) {
		if ( 'published' !== $a['status'] ) {
			return new \WP_Error( 'educore_unavailable', __( 'This assessment is not available.', 'educore-assessments' ), array( 'status' => 404 ) );
		}
		if ( ! Access::can_access_course( $user_id, (int) $a['course_id'] ) ) {
			return new \WP_Error( 'educore_forbidden', __( 'You are not enrolled in this course.', 'educore-assessments' ), array( 'status' => 403 ) );
		}
		if ( ! Privacy::has_required_consent( $user_id ) ) {
			return new \WP_Error( 'educore_consent_required', __( 'Your account is waiting for guardian consent.', 'educore-assessments' ), array( 'status' => 403 ) );
		}
		if ( ! Assessments::is_open_window( $a ) ) {
			return new \WP_Error( 'educore_closed', __( 'This assessment is not open at the moment.', 'educore-assessments' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * Start a new attempt or resume the open one (session recovery).
	 *
	 * @return int|\WP_Error attempt id
	 */
	public static function start( int $assessment_id, int $user_id ) {
		global $wpdb;
		$a = Assessments::get( $assessment_id );
		if ( ! $a ) {
			return new \WP_Error( 'educore_not_found', __( 'Assessment not found.', 'educore-assessments' ), array( 'status' => 404 ) );
		}
		$ok = self::can_take( $a, $user_id );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$open = self::open_attempt( $assessment_id, $user_id );
		if ( $open ) {
			if ( self::past_grace( $open ) ) {
				self::submit( (int) $open['id'], true );
			} else {
				return (int) $open['id'];
			}
		}
		$remaining = self::remaining( $a, $user_id );
		if ( null !== $remaining && $remaining < 1 ) {
			return new \WP_Error( 'educore_no_attempts', __( 'You have used all attempts for this assessment.', 'educore-assessments' ), array( 'status' => 403 ) );
		}
		$seed     = bin2hex( random_bytes( 16 ) );
		$selected = self::select_questions( $a, $seed );
		if ( is_wp_error( $selected ) ) {
			return $selected;
		}
		$now      = time();
		$deadline = null;
		if ( (int) $a['settings']['duration'] > 0 ) {
			$deadline = $now + 60 * (int) $a['settings']['duration'];
		}
		if ( $a['settings']['closes_at'] ) {
			$close    = strtotime( $a['settings']['closes_at'] . ' UTC' );
			$deadline = null === $deadline ? $close : min( $deadline, $close );
		}
		$at = Schema::t( 'attempts' );
		self::tx( 'begin' );
		$no = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(MAX(attempt_no),0)+1 FROM {$at} WHERE assessment_id=%d AND user_id=%d FOR UPDATE", $assessment_id, $user_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$suppress = $wpdb->suppress_errors( true );
		$inserted = $wpdb->insert(
			$at,
			array(
				'assessment_id' => $assessment_id,
				'user_id'       => $user_id,
				'attempt_no'    => $no,
				'state'         => 'open',
				'seed'          => $seed,
				'started_at'    => gmdate( 'Y-m-d H:i:s', $now ),
				'deadline_at'   => $deadline ? gmdate( 'Y-m-d H:i:s', $deadline ) : null,
				'max_score'     => array_sum( array_column( $selected, 'points' ) ),
				'open_lock'     => 1,
			)
		);
		$wpdb->suppress_errors( $suppress );
		if ( ! $inserted ) {
			self::tx( 'rollback' );
			// A concurrent start won the race: the unique (assessment,user,open_lock) key rejected this one.
			$open = self::open_attempt( $assessment_id, $user_id );
			return $open ? (int) $open['id'] : new \WP_Error( 'educore_conflict', __( 'Could not start the attempt. Please try again.', 'educore-assessments' ), array( 'status' => 409 ) );
		}
		$attempt_id = (int) $wpdb->insert_id;
		$it         = Schema::t( 'attempt_items' );
		foreach ( $selected as $pos => $item ) {
			$wpdb->insert( $it, array( 'attempt_id' => $attempt_id, 'position' => $pos + 1, 'question_version_id' => $item['version_id'], 'points' => $item['points'], 'option_order' => $item['order'] ? wp_json_encode( $item['order'] ) : null ) );
		}
		$vids = implode( ',', array_map( 'intval', array_column( $selected, 'version_id' ) ) );
		$wpdb->query( 'UPDATE ' . Schema::t( 'question_versions' ) . " SET used=1 WHERE id IN ($vids)" ); // phpcs:ignore WordPress.DB.PreparedSQL -- integers only.
		self::tx( 'commit' );
		Audit::log( 'attempt.started', 'assessment', $assessment_id, array( 'attempt_id' => $attempt_id ) );
		return $attempt_id;
	}

	/**
	 * Draw questions from pools with a seeded order (reproducible for audits).
	 *
	 * @return array<int,array{version_id:int,points:float,order:?array}>|\WP_Error
	 */
	public static function select_questions( array $a, string $seed ) {
		global $wpdb;
		$q      = Schema::t( 'questions' );
		$v      = Schema::t( 'question_versions' );
		$tg     = Schema::t( 'question_tags' );
		$chosen = array();
		$used   = array( 0 );
		$pools  = Assessments::pools( (int) $a['id'] );
		if ( ! $pools ) {
			return new \WP_Error( 'educore_empty', __( 'This assessment has no questions yet.', 'educore-assessments' ), array( 'status' => 409 ) );
		}
		foreach ( $pools as $p ) {
			$where  = array( 'q.course_id=%d', "q.status='published'", "q.usage_scope IN ('any','assessment')" );
			$params = array( (int) $a['course_id'] );
			if ( (int) $p['question_id'] ) {
				$where[]  = 'q.id=%d';
				$params[] = (int) $p['question_id'];
			}
			foreach ( array( 'qtype' => 'q.type', 'difficulty' => 'q.difficulty' ) as $k => $col ) {
				if ( '' !== $p[ $k ] ) {
					$where[]  = "$col=%s";
					$params[] = $p[ $k ];
				}
			}
			if ( (int) $p['lesson_id'] ) {
				$where[]  = 'q.lesson_id=%d';
				$params[] = (int) $p['lesson_id'];
			}
			if ( '' !== $p['tag'] ) {
				$where[]  = "EXISTS (SELECT 1 FROM {$tg} t WHERE t.question_id=q.id AND t.tag=%s)";
				$params[] = $p['tag'];
			}
			$where[] = 'q.id NOT IN (' . implode( ',', array_map( 'intval', $used ) ) . ')';
			$rows    = $wpdb->get_results( $wpdb->prepare( "SELECT q.id, q.type, q.current_version_id vid, v.points FROM {$q} q JOIN {$v} v ON v.id=q.current_version_id WHERE " . implode( ' AND ', $where ) . ' ORDER BY q.id', $params ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
			$need    = (int) $p['draw_count'];
			if ( count( $rows ) < $need ) {
				return new \WP_Error( 'educore_pool_short', __( 'Not enough published questions to build this assessment. Ask your instructor to complete the question bank.', 'educore-assessments' ), array( 'status' => 409 ) );
			}
			$by = array();
			foreach ( $rows as $r ) {
				$by[ $r['id'] ] = $r;
			}
			$ids = Types::seeded_sort( array_keys( $by ), $seed . '|pool' . $p['id'] );
			foreach ( array_slice( $ids, 0, $need ) as $qid ) {
				$r        = $by[ $qid ];
				$used[]   = (int) $qid;
				$chosen[] = array( 'qid' => (int) $qid, 'type' => $r['type'], 'version_id' => (int) $r['vid'], 'points' => (float) $p['points_each'] > 0 ? (float) $p['points_each'] : (float) $r['points'] );
			}
		}
		if ( $a['settings']['shuffle_questions'] ) {
			$keys   = Types::seeded_sort( array_keys( $chosen ), $seed . '|order' );
			$chosen = array_map( static fn( $k ) => $chosen[ $k ], $keys );
		}
		foreach ( $chosen as &$c ) {
			$c['order'] = null;
			if ( $a['settings']['shuffle_options'] && in_array( $c['type'], array( 'single', 'multiple', 'image' ), true ) ) {
				$ver        = Questions::version( $c['version_id'] );
				$c['order'] = Types::seeded_sort( wp_list_pluck( $ver['payload']['options'] ?? array(), 'id' ), $seed . '|opt' . $c['qid'] );
			}
		}
		unset( $c );
		return array_values( $chosen );
	}

	public static function items( int $attempt_id ): array {
		global $wpdb;
		$it = Schema::t( 'attempt_items' );
		$rs = Schema::t( 'responses' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT i.*, r.id response_id, r.answer, r.auto_score, r.final_score, r.needs_grading, r.feedback, r.rubric_scores, r.rubric_snapshot FROM {$it} i LEFT JOIN {$rs} r ON r.attempt_item_id=i.id WHERE i.attempt_id=%d ORDER BY i.position", $attempt_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/**
	 * Save answers (autosave). $answers: item_id => answer.
	 *
	 * @return true|\WP_Error
	 */
	public static function save( int $attempt_id, int $user_id, array $answers ) {
		global $wpdb;
		$at = self::get( $attempt_id );
		if ( ! $at || (int) $at['user_id'] !== $user_id ) {
			return new \WP_Error( 'educore_not_found', __( 'Attempt not found.', 'educore-assessments' ), array( 'status' => 404 ) );
		}
		if ( 'open' !== $at['state'] ) {
			return new \WP_Error( 'educore_closed', __( 'This attempt has already been submitted.', 'educore-assessments' ), array( 'status' => 409 ) );
		}
		if ( self::past_grace( $at ) ) {
			self::submit( $attempt_id, true );
			return new \WP_Error( 'educore_time_up', __( 'Time is up. Your attempt was submitted automatically.', 'educore-assessments' ), array( 'status' => 409 ) );
		}
		$items = array();
		foreach ( self::items( $attempt_id ) as $i ) {
			$items[ (int) $i['id'] ] = $i;
		}
		$rs = Schema::t( 'responses' );
		foreach ( array_slice( $answers, 0, 200, true ) as $item_id => $answer ) {
			$item_id = (int) $item_id;
			if ( ! isset( $items[ $item_id ] ) ) {
				continue; // Never write to items of other attempts.
			}
			$ver   = Questions::version( (int) $items[ $item_id ]['question_version_id'] );
			$clean = Types::sanitize_answer( self::type_of( $ver ), $answer );
			$wpdb->query( $wpdb->prepare( "INSERT INTO {$rs} (attempt_item_id, answer, saved_at) VALUES (%d,%s,%s) ON DUPLICATE KEY UPDATE answer=VALUES(answer), saved_at=VALUES(saved_at)", $item_id, wp_json_encode( $clean ), CoreSchema::now() ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		return true;
	}

	private static array $types = array();

	/**
	 * Transaction helper. Inside the WordPress test harness (which wraps each test in a transaction)
	 * savepoints are used so test isolation is preserved; in production a real transaction is used.
	 */
	private static function tx( string $op ): void {
		global $wpdb;
		$nested = (bool) apply_filters( 'educore/assessments/nested_transactions', class_exists( 'WP_UnitTestCase', false ) );
		$sql    = $nested
			? array( 'begin' => 'SAVEPOINT ec_attempt', 'commit' => 'RELEASE SAVEPOINT ec_attempt', 'rollback' => 'ROLLBACK TO SAVEPOINT ec_attempt' )
			: array( 'begin' => 'START TRANSACTION', 'commit' => 'COMMIT', 'rollback' => 'ROLLBACK' );
		$wpdb->query( $sql[ $op ] ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function type_of( array $version ): string {
		global $wpdb;
		$qid = (int) $version['question_id'];
		if ( ! isset( self::$types[ $qid ] ) ) {
			self::$types[ $qid ] = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT type FROM ' . Schema::t( 'questions' ) . ' WHERE id=%d', $qid ) );
		}
		return self::$types[ $qid ];
	}

	/**
	 * Submit and auto-grade. Essays are flagged for manual grading.
	 *
	 * @return true|\WP_Error
	 */
	public static function submit( int $attempt_id, bool $expired = false ) {
		global $wpdb;
		$at = self::get( $attempt_id );
		if ( ! $at || 'open' !== $at['state'] ) {
			return new \WP_Error( 'educore_closed', __( 'This attempt has already been submitted.', 'educore-assessments' ), array( 'status' => 409 ) );
		}
		$rs     = Schema::t( 'responses' );
		$manual = 0;
		foreach ( self::items( $attempt_id ) as $i ) {
			$ver    = Questions::version( (int) $i['question_version_id'] );
			$type   = self::type_of( $ver );
			$answer = null === $i['answer'] ? null : json_decode( (string) $i['answer'], true );
			$frac   = Types::grade( $type, $ver['answer_key'], $answer );
			$needs  = null === $frac && null !== $answer && '' !== $answer ? 1 : 0;
			$score  = null === $frac ? ( $needs ? null : 0.0 ) : round( $frac * (float) $i['points'], 2 );
			$manual += $needs;
			$num = null === $score ? 'NULL' : "'" . number_format( (float) $score, 2, '.', '' ) . "'";
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$rs} (attempt_item_id, answer, saved_at, auto_score, final_score, needs_grading) VALUES (%d,%s,%s,{$num},{$num},%d)
					 ON DUPLICATE KEY UPDATE auto_score=VALUES(auto_score), final_score=VALUES(final_score), needs_grading=VALUES(needs_grading)", // phpcs:ignore WordPress.DB.PreparedSQL -- $num is a formatted number or NULL.
					(int) $i['id'],
					null === $i['answer'] ? 'null' : $i['answer'],
					CoreSchema::now(),
					$needs
				)
			);
		}
		$wpdb->update(
			Schema::t( 'attempts' ),
			array( 'state' => $manual ? 'submitted' : 'graded', 'submitted_at' => CoreSchema::now(), 'expired' => $expired ? 1 : 0, 'open_lock' => null ),
			array( 'id' => $attempt_id, 'state' => 'open' )
		);
		self::recompute( $attempt_id );
		Audit::log( $expired ? 'attempt.expired' : 'attempt.submitted', 'assessment', (int) $at['assessment_id'], array( 'attempt_id' => $attempt_id ) );
		do_action( 'educore/events/attempt_submitted', $attempt_id, (int) $at['user_id'] );
		self::maybe_auto_release( $attempt_id );
		return true;
	}

	/** Recalculate totals from responses; mark graded when no manual items remain. */
	public static function recompute( int $attempt_id ): void {
		global $wpdb;
		$at = self::get( $attempt_id );
		$a  = $at ? Assessments::get( (int) $at['assessment_id'] ) : null;
		if ( ! $at || ! $a || 'open' === $at['state'] ) {
			return;
		}
		$score   = 0.0;
		$max     = 0.0;
		$pending = 0;
		foreach ( self::items( $attempt_id ) as $i ) {
			$max += (float) $i['points'];
			if ( (int) $i['needs_grading'] && null === $i['final_score'] ) {
				++$pending;
			}
			$score += (float) $i['final_score'];
		}
		$percent = $max > 0 ? round( $score * 100 / $max, 2 ) : 0.0;
		$wpdb->update(
			Schema::t( 'attempts' ),
			array(
				'score'     => round( $score, 2 ),
				'max_score' => $max,
				'percent'   => $percent,
				'passed'    => $pending ? null : ( $percent >= (float) $a['settings']['pass_mark'] ? 1 : 0 ),
				'state'     => $pending ? 'submitted' : 'graded',
			),
			array( 'id' => $attempt_id )
		);
	}

	public static function maybe_auto_release( int $attempt_id ): void {
		$at = self::get( $attempt_id );
		$a  = $at ? Assessments::get( (int) $at['assessment_id'] ) : null;
		if ( $at && $a && 'graded' === $at['state'] && 'auto' === $a['settings']['release'] && ! (int) $at['released'] ) {
			self::release( $attempt_id );
		}
	}

	/** @return true|\WP_Error */
	public static function release( int $attempt_id ) {
		global $wpdb;
		$at = self::get( $attempt_id );
		if ( ! $at || 'graded' !== $at['state'] ) {
			return new \WP_Error( 'educore_not_ready', __( 'Only fully graded attempts can be released.', 'educore-assessments' ), array( 'status' => 409 ) );
		}
		if ( (int) $at['released'] ) {
			return true;
		}
		$wpdb->update( Schema::t( 'attempts' ), array( 'released' => 1, 'released_at' => CoreSchema::now() ), array( 'id' => $attempt_id ) );
		Audit::log( 'attempt.released', 'assessment', (int) $at['assessment_id'], array( 'attempt_id' => $attempt_id ) );
		do_action( 'educore/events/grade_released', $attempt_id, (int) $at['user_id'] );
		if ( (int) $at['passed'] ) {
			foreach ( Assessments::linked_lessons( (int) $at['assessment_id'] ) as $lesson_id ) {
				if ( 'assessment' === Progress::rule( (int) $lesson_id ) ) {
					Progress::complete( (int) $at['user_id'], (int) $lesson_id, 'assessment' );
				}
			}
		}
		return true;
	}

	/** Cron + on-access expiry of overdue open attempts. */
	public static function expire_due( int $limit = 50 ): int {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . Schema::t( 'attempts' ) . " WHERE state='open' AND deadline_at IS NOT NULL AND deadline_at < %s LIMIT %d", gmdate( 'Y-m-d H:i:s', time() - self::GRACE ), $limit ) );
		foreach ( $ids as $id ) {
			self::submit( (int) $id, true );
		}
		return count( $ids );
	}

	/** May the learner see correct answers and explanations for this attempt? */
	public static function review_allowed( array $at, array $a ): bool {
		if ( ! (int) $at['released'] ) {
			return false;
		}
		switch ( $a['settings']['feedback'] ) {
			case 'after_release':
				return true;
			case 'after_attempts_exhausted':
				$rem = self::remaining( $a, (int) $at['user_id'] );
				return null !== $rem && 0 === $rem && ! self::open_attempt( (int) $a['id'], (int) $at['user_id'] );
		}
		return false;
	}

	/** Student-facing representation. Answer keys only appear when review is allowed. */
	public static function student_view( int $attempt_id ): array {
		$at = self::get( $attempt_id );
		$a  = Assessments::get( (int) $at['assessment_id'] );
		if ( 'open' === $at['state'] && self::past_grace( $at ) ) {
			self::submit( $attempt_id, true );
			$at = self::get( $attempt_id );
		}
		$review = self::review_allowed( $at, $a );
		$items  = array();
		foreach ( self::items( $attempt_id ) as $i ) {
			$ver  = Questions::version( (int) $i['question_version_id'] );
			$type = self::type_of( $ver );
			$item = array(
				'id'       => (int) $i['id'],
				'position' => (int) $i['position'],
				'type'     => $type,
				'stem'     => $ver['stem'],
				'points'   => (float) $i['points'],
				'view'     => Types::public_view( $type, $ver['payload'], $i['option_order'] ? (array) json_decode( (string) $i['option_order'], true ) : null, $at['seed'] . '|' . $i['id'] ),
				'answer'   => null === $i['answer'] ? null : json_decode( (string) $i['answer'], true ),
			);
			if ( (int) $at['released'] ) {
				$item['score']    = null === $i['final_score'] ? null : (float) $i['final_score'];
				$item['feedback'] = (string) $i['feedback'];
				$item['rubric']   = Grading::rubric_review( $i, (int) $ver['question_id'] );
			}
			if ( $review ) {
				$item['correct']     = Types::to_authoring( $type, $ver['payload'], $ver['answer_key'] )['correct'] ?: '';
				$item['key']         = $ver['answer_key'];
				$item['explanation'] = (string) $ver['explanation'];
			}
			$items[] = $item;
		}
		$out = array(
			'id'           => (int) $at['id'],
			'assessment'   => array( 'id' => (int) $a['id'], 'title' => $a['title'], 'kind' => $a['kind'] ),
			'attempt_no'   => (int) $at['attempt_no'],
			'state'        => $at['state'],
			'expired'      => (bool) $at['expired'],
			'seconds_left' => 'open' === $at['state'] && $at['deadline_at'] ? max( 0, strtotime( $at['deadline_at'] . ' UTC' ) - time() ) : null,
			'released'     => (bool) $at['released'],
			'review'       => $review,
			'items'        => $items,
		);
		if ( (int) $at['released'] ) {
			$out['result'] = self::result( $at, $a );
		}
		return $out;
	}

	public static function result( array $at, array $a ): array {
		$scale = (float) $a['settings']['total_mark'];
		return array(
			'score'     => (float) $at['score'],
			'max'       => (float) $at['max_score'],
			'percent'   => (float) $at['percent'],
			'passed'    => (bool) $at['passed'],
			'mark'      => $scale > 0 ? round( (float) $at['percent'] * $scale / 100, 2 ) : (float) $at['score'],
			'mark_of'   => $scale > 0 ? $scale : (float) $at['max_score'],
			'pass_mark' => (float) $a['settings']['pass_mark'],
		);
	}

	/** Has the learner a released, passed attempt? (completion rule) */
	public static function has_passed( int $assessment_id, int $user_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Schema::t( 'attempts' ) . ' WHERE assessment_id=%d AND user_id=%d AND released=1 AND passed=1 LIMIT 1', $assessment_id, $user_id ) );
	}
}
