<?php
namespace EduCore\Workspace;

use EduCore\Core\Audit;
use EduCore\Core\Branding;
use EduCore\Core\I18n;
use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/**
 * Platform settings in EduCore Management (`/manage/?v=settings`). Covers the everyday settings of the wp-admin
 * page with the same sanitisation. Technical and destructive settings stay in WordPress for technical
 * administrators: the release channel, package installation, SMTP credentials and the uninstall preference are
 * shown read-only. Two changes with policy impact need an explicit confirmation: opening self-registration, and
 * a new consent text version (which affects consent evidence).
 */
final class Settings {
	public const CAP      = 'ec_manage_settings';
	public const SECTIONS = array( 'general', 'access', 'engagement', 'branding' );

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	public static function can( int $uid ): bool {
		return $uid > 0 && user_can( $uid, self::CAP );
	}

	public static function routes(): void {
		register_rest_route(
			'educore/v1',
			'/manage/settings/(?P<section>[a-z]+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'rest_save' ),
				'permission_callback' => static fn() => self::can( get_current_user_id() ),
				'args'                => array( 'section' => array( 'type' => 'string', 'required' => true, 'enum' => self::SECTIONS ) ),
			)
		);
	}

	public static function rest_save( \WP_REST_Request $r ) {
		if ( ! RateLimiter::hit( 'rest_write' ) ) {
			return new \WP_Error( 'ec_ws_rate', __( 'Too many changes in a short time. Please wait a moment.', 'educore-workspace' ), array( 'status' => 429 ) );
		}
		$res = self::save( get_current_user_id(), (string) $r['section'], $r->get_params() );
		return is_wp_error( $res ) ? $res : new \WP_REST_Response( array( 'ok' => true, 'changed' => $res ) );
	}

	/** Current values, with the same defaults as the wp-admin page. */
	public static function values(): array {
		$o = static fn( $k, $d ) => get_option( $k, $d );
		return array(
			'educore_support_email'              => (string) $o( 'educore_support_email', 'support@educore.gorgy.org' ),
			'educore_default_lang'               => (string) $o( 'educore_default_lang', 'en' ),
			'educore_audit_retention_days'       => (int) $o( 'educore_audit_retention_days', 730 ),
			'educore_registration'               => (string) $o( 'educore_registration', 'open' ),
			'educore_consent_version'            => (string) $o( 'educore_consent_version', '1.0' ),
			'educore_admin_created_is_consented' => (bool) $o( 'educore_admin_created_is_consented', true ),
			'educore_gamification'               => (string) $o( 'educore_gamification', 'on' ),
			'educore_leaderboards'               => (string) $o( 'educore_leaderboards', 'off' ),
			'educore_brand'                      => array_merge( Branding::defaults(), (array) get_option( Branding::OPTION, array() ) ),
		);
	}

	private static function bool( $v ): bool {
		return in_array( $v, array( true, 1, '1', 'on', 'yes', 'true' ), true );
	}

	private static function invalid( string $field, string $msg ): \WP_Error {
		return new \WP_Error( 'ec_settings_invalid', $msg, array( 'status' => 400, 'params' => array( $field => 'invalid' ) ) );
	}

	/**
	 * Validate and store one section.
	 *
	 * @return string[]|\WP_Error changed option keys
	 */
	public static function save( int $uid, string $section, array $in ) {
		if ( ! self::can( $uid ) ) {
			return new \WP_Error( 'ec_settings_forbidden', __( 'You cannot change platform settings.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$cur  = self::values();
		$next = array();
		switch ( $section ) {
			case 'general':
				$email = sanitize_email( (string) ( $in['educore_support_email'] ?? '' ) );
				if ( ! is_email( $email ) ) {
					return self::invalid( 'educore_support_email', __( 'Enter a valid support e-mail address.', 'educore-workspace' ) );
				}
				$days = (string) ( $in['educore_audit_retention_days'] ?? '' );
				if ( ! preg_match( '/^\d{1,5}$/', $days ) || ( (int) $days > 0 && (int) $days < 90 ) ) {
					return self::invalid( 'educore_audit_retention_days', __( 'Audit retention must be 0 (keep forever) or at least 90 days.', 'educore-workspace' ) );
				}
				$next = array(
					'educore_support_email'        => $email,
					'educore_default_lang'         => I18n::sanitize_lang( (string) ( $in['educore_default_lang'] ?? '' ) ),
					'educore_audit_retention_days' => (int) $days,
				);
				break;
			case 'access':
				$reg = 'open' === ( $in['educore_registration'] ?? '' ) ? 'open' : 'closed';
				if ( 'open' === $reg && 'open' !== $cur['educore_registration'] && ! self::bool( $in['confirm_open'] ?? '' ) ) {
					return self::invalid( 'confirm_open', __( 'Opening self-registration lets anyone create an account. Tick the confirmation to proceed.', 'educore-workspace' ) );
				}
				$ver = trim( (string) ( $in['educore_consent_version'] ?? '' ) );
				if ( ! preg_match( '/^\d{1,3}(\.\d{1,3}){0,2}$/', $ver ) ) {
					return self::invalid( 'educore_consent_version', __( 'Use a version number such as 1.1 or 2.0.', 'educore-workspace' ) );
				}
				if ( version_compare( $ver, $cur['educore_consent_version'], '<' ) ) {
					return self::invalid( 'educore_consent_version', __( 'The consent version can only go up; earlier consent evidence refers to the current version.', 'educore-workspace' ) );
				}
				if ( $ver !== $cur['educore_consent_version'] && ! self::bool( $in['confirm_consent'] ?? '' ) ) {
					return self::invalid( 'confirm_consent', __( 'A new consent version is recorded with every new consent. Publish the updated policy first, then tick the confirmation.', 'educore-workspace' ) );
				}
				$next = array(
					'educore_registration'               => $reg,
					'educore_consent_version'            => $ver,
					'educore_admin_created_is_consented' => self::bool( $in['educore_admin_created_is_consented'] ?? false ),
				);
				break;
			case 'engagement':
				$next = array(
					'educore_gamification' => 'off' === ( $in['educore_gamification'] ?? '' ) ? 'off' : 'on',
					'educore_leaderboards' => 'on' === ( $in['educore_leaderboards'] ?? '' ) ? 'on' : 'off',
				);
				break;
			case 'branding':
				$brand = array();
				foreach ( array( 'name', 'tagline', 'initiative' ) as $k ) {
					$brand[ $k ] = (string) ( $in[ 'brand_' . $k ] ?? '' );
				}
				foreach ( Branding::SLOTS as $k ) {
					$id = absint( $in[ 'brand_' . $k ] ?? 0 );
					if ( $id && ! wp_attachment_is_image( $id ) ) {
						return self::invalid( 'brand_' . $k, __( 'Choose an image from the media library.', 'educore-workspace' ) );
					}
					$brand[ $k ] = $id;
				}
				$before = $cur['educore_brand'];
				Branding::save( $brand ); // Same sanitiser and audit event as wp-admin.
				$after   = array_merge( Branding::defaults(), (array) get_option( Branding::OPTION, array() ) );
				$changed = array_keys( array_diff_assoc( array_map( 'strval', $after ), array_map( 'strval', $before ) ) );
				return array_map( static fn( $k ) => 'educore_brand.' . $k, $changed );
			default:
				return new \WP_Error( 'ec_settings_section', __( 'Unknown settings section.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		$changed = array();
		$detail  = array();
		foreach ( $next as $k => $v ) {
			if ( $cur[ $k ] !== $v ) {
				update_option( $k, $v );
				$changed[]    = $k;
				$detail[ $k ] = array( 'from' => $cur[ $k ], 'to' => $v );
			}
		}
		if ( $changed ) {
			Audit::log( 'settings.updated', 'settings', 0, array( 'via' => 'workspace', 'section' => $section, 'changes' => $detail ) );
			/** Fires after platform settings change in EduCore Management. */
			do_action( 'educore/workspace/settings_saved', $section, $changed );
		}
		return $changed;
	}

	/** Read-only technical status (no secrets, no full URLs). */
	public static function technical(): array {
		$st  = (array) get_option( 'educore_update_status', array() );
		$url = (string) get_option( 'educore_update_manifest_url', '' );
		$rel = preg_match( '#/releases/([^/]+)/manifest\.json$#', $url, $m ) ? $m[1] : '';
		$out = array(
			'channel'     => $url ? ( wp_parse_url( $url, PHP_URL_HOST ) . ( $rel ? ' · ' . $rel : '' ) ) : '',
			'check_state' => (string) ( $st['state'] ?? '' ),
			'check_msg'   => (string) ( $st['message'] ?? '' ),
			'checked_at'  => (string) ( $st['checked_at'] ?? '' ),
			'auto_update' => 'on' === get_option( 'educore_auto_update', 'off' ),
			'uninstall'   => 'yes' === get_option( 'educore_uninstall_delete_data' ),
			'smtp'        => '' !== (string) get_option( 'educore_smtp_host', '' ),
			'mail_failed' => null,
		);
		if ( class_exists( '\EduCore\Notifications\Queue' ) && method_exists( '\EduCore\Notifications\Queue', 'counts' ) ) {
			$c                  = (array) \EduCore\Notifications\Queue::counts( 7 );
			$out['mail_failed'] = (int) ( $c['failed'] ?? 0 );
		}
		return $out;
	}
}
