<?php
/**
 * Plugin Name:       EduCore Core
 * Plugin URI:        https://educore.gorgy.org
 * Description:       EduCore learning management core: curriculum, courses, lessons, enrollment, progress, roles, privacy, audit and REST API.
 * Version:           1.2.0
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Author:            GORGY.ORG
 * Author URI:        https://gorgy.org
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-core
 * Domain Path:       /languages
 *
 * @package EduCore\Core
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'EDUCORE_CORE_VERSION' ) ) {
	return;
}

define( 'EDUCORE_CORE_VERSION', '1.2.0' );
define( 'EDUCORE_CORE_DB_VERSION', 2 );
define( 'EDUCORE_CORE_FILE', __FILE__ );
define( 'EDUCORE_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'EDUCORE_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once EDUCORE_CORE_DIR . 'src/Autoloader.php';
\EduCore\Core\Autoloader::register( 'EduCore\\Core\\', EDUCORE_CORE_DIR . 'src/' );

register_activation_hook( __FILE__, array( \EduCore\Core\Installer::class, 'activate' ) );
register_deactivation_hook( __FILE__, array( \EduCore\Core\Installer::class, 'deactivate' ) );

add_action( 'plugins_loaded', array( \EduCore\Core\Plugin::class, 'boot' ), 5 );
