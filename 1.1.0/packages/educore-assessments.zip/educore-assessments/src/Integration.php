<?php
namespace EduCore\Assessments;

use EduCore\Core\Access;
use EduCore\Core\Enrollment;

defined( 'ABSPATH' ) || exit;

/** Hooks into EduCore Core: completion rule, dashboards, workspace, privacy, cron. */
final class Integration {

	public static function register(): void {
		add_filter( 'educore/progress/completion_rules', static fn( $r ) => array_merge( (array) $r, array( 'assessment' ) ) );
		add_filter( 'educore/progress/rule_labels', static fn( $l ) => $l + array( 'assessment' => __( 'Pass the linked quiz/exam', 'educore-assessments' ) ) );
		add_filter( 'educore/progress/check_rule', array( self::class, 'check_rule' ), 10, 4 );
		add_filter( 'educore/lesson/rule_hint', array( self::class, 'rule_hint' ), 10, 3 );
		// Core's daily activity log resolves the course of assessment events through this filter.
		add_filter( 'educore/activity/course_of', array( self::class, 'activity_course_of' ), 10, 3 );
		add_action( 'educore/admin/lesson_meta_box', array( self::class, 'lesson_meta_box' ) );
		add_action( 'educore/admin/save_content_meta', array( self::class, 'save_lesson_meta' ), 10, 2 );
		add_filter( 'educore/dashboard/student', array( self::class, 'dashboard' ), 10, 2 );
		add_filter( 'educore/dashboard/history', array( self::class, 'history' ), 10, 2 );
		add_filter( 'educore/workspace/tools', array( self::class, 'workspace_tools' ), 10, 2 );
		add_filter( 'educore/workspace/before_courses', array( self::class, 'workspace_queue' ), 10, 2 );
		add_filter( 'educore/workspace/course_actions', array( self::class, 'course_actions' ), 10, 3 );
		add_filter( 'educore/privacy/export', array( self::class, 'export' ), 10, 2 );
		add_action( 'educore/privacy/erase', array( self::class, 'erase' ) );
		add_filter( 'educore/admin/overview_tiles', array( self::class, 'tiles' ) );
		add_filter( 'educore/notifications/attempt_context', array( self::class, 'attempt_context' ), 10, 2 );
		add_filter( 'educore/notifications/reminders', array( self::class, 'reminders' ) );
		add_action( 'educore_assessments_expire', array( Attempts::class, 'expire_due' ) );
		add_action( 'educore/install/repair', array( Schema::class, 'repair' ) );
		add_action(
			'init',
			static function () {
				if ( ! wp_next_scheduled( 'educore_assessments_expire' ) ) {
					wp_schedule_event( time() + 120, 'educore_five_minutes', 'educore_assessments_expire' );
				}
			}
		);
	}

	public static function check_rule( $ok, $rule, $user_id, $lesson_id ) {
		if ( 'assessment' !== $rule ) {
			return $ok;
		}
		$aid = (int) get_post_meta( (int) $lesson_id, '_ec_assessment_id', true );
		return $aid && Attempts::has_passed( $aid, (int) $user_id );
	}

	public static function rule_hint( $hint, $rule, $lesson_id ) {
		return 'assessment' === $rule ? __( 'This lesson completes when you pass its quiz.', 'educore-assessments' ) : $hint;
	}

	public static function lesson_meta_box( \WP_Post $post ): void {
		$course = (int) get_post_meta( $post->ID, '_ec_course_id', true );
		$cur    = (int) get_post_meta( $post->ID, '_ec_assessment_id', true );
		echo '<p><label><strong>' . esc_html__( 'Linked quiz (for the "Pass the linked quiz" rule, also shown under the lesson)', 'educore-assessments' ) . '</strong><br><select name="_ec_assessment_id"><option value="0">—</option>';
		foreach ( $course ? Assessments::for_course( $course, array( 'draft', 'published' ) ) : array() as $a ) {
			echo '<option value="' . esc_attr( (string) $a['id'] ) . '"' . selected( $cur, (int) $a['id'], false ) . '>' . esc_html( $a['title'] . ' (' . $a['status'] . ')' ) . '</option>';
		}
		echo '</select></label></p>';
	}

	/** Core has already verified the nonce and edit_post capability before this action fires. */
	public static function save_lesson_meta( int $post_id, \WP_Post $post ): void {
		if ( 'ec_lesson' !== $post->post_type || ! isset( $_POST['_ec_assessment_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$aid = absint( $_POST['_ec_assessment_id'] ); // phpcs:ignore WordPress.Security.NonceVerification
		$a   = $aid ? Assessments::get( $aid ) : null;
		if ( $aid && ( ! $a || (int) $a['course_id'] !== (int) get_post_meta( $post_id, '_ec_course_id', true ) ) ) {
			return;
		}
		update_post_meta( $post_id, '_ec_assessment_id', $aid );
	}

	public static function dashboard( array $d, int $uid ): array {
		foreach ( $d['courses'] as $c ) {
			if ( ! $c['accessible'] ) {
				continue;
			}
			foreach ( Assessments::for_course( (int) $c['course_id'] ) as $a ) {
				if ( 'practice' === $a['kind'] ) {
					continue;
				}
				$url  = add_query_arg( 'ec_assessment', (int) $a['id'], get_permalink( (int) $c['course_id'] ) ) . '#ec-assessment-' . (int) $a['id'];
				$s    = Frontend::summary_data( $a, $uid );
				if ( $s['open_attempt'] ) {
					$d['pending'][] = array( 'title' => $a['title'], 'meta' => __( 'In progress — resume', 'educore-assessments' ), 'url' => $url );
				} elseif ( $s['pending'] ) {
					$d['pending'][] = array( 'title' => $a['title'], 'meta' => __( 'Awaiting grading', 'educore-assessments' ), 'url' => $url );
				} elseif ( ! $s['used'] && $s['can_start'] ) {
					$d['upcoming'][] = array( 'title' => $a['title'], 'meta' => $a['settings']['closes_at'] ? sprintf( /* translators: %s: local date, time and timezone */ __( 'Closes %s', 'educore-assessments' ), Assessments::format_local( $a['settings']['closes_at'] ) ) : $c['title'], 'url' => $url );
				}
			}
		}
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT a.*, s.title, s.course_id FROM ' . Schema::t( 'attempts' ) . ' a JOIN ' . Schema::t( 'assessments' ) . ' s ON s.id=a.assessment_id WHERE a.user_id=%d AND a.released=1 ORDER BY a.released_at DESC LIMIT 5', $uid ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $rows as $r ) {
			$d['results'][] = array( 'title' => $r['title'], 'meta' => number_format_i18n( (float) $r['percent'], 1 ) . '% · ' . ( (int) $r['passed'] ? __( 'Passed', 'educore-assessments' ) : __( 'Not passed yet', 'educore-assessments' ) ), 'url' => add_query_arg( 'ec_assessment', (int) $r['assessment_id'], get_permalink( (int) $r['course_id'] ) ) . '#ec-assessment-' . (int) $r['assessment_id'] );
		}
		return $d;
	}

	public static function history( array $h, int $uid ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT a.*, s.title FROM ' . Schema::t( 'attempts' ) . ' a JOIN ' . Schema::t( 'assessments' ) . ' s ON s.id=a.assessment_id WHERE a.user_id=%d ORDER BY a.started_at DESC LIMIT 200', $uid ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$map  = array( 'open' => __( 'In progress', 'educore-assessments' ), 'submitted' => __( 'Awaiting grading', 'educore-assessments' ), 'graded' => __( 'Graded', 'educore-assessments' ) );
		foreach ( $rows as $r ) {
			$h['attempts'][] = array(
				'assessment' => $r['title'],
				'attempt'    => (int) $r['attempt_no'],
				'score'      => (int) $r['released'] ? number_format_i18n( (float) $r['percent'], 1 ) . '%' : '—',
				'status'     => (int) $r['released'] ? ( (int) $r['passed'] ? __( 'Passed', 'educore-assessments' ) : __( 'Not passed', 'educore-assessments' ) ) : ( $map[ $r['state'] ] ?? $r['state'] ),
				'date'       => $r['submitted_at'] ?: $r['started_at'],
			);
		}
		return $h;
	}

	public static function workspace_tools( string $html, int $uid ): string {
		if ( user_can( $uid, 'ec_manage_question_bank' ) ) {
			$html .= '<a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-questions' ) ) . '">' . esc_html__( 'Question bank', 'educore-assessments' ) . '</a> ';
		}
		if ( user_can( $uid, 'ec_manage_assessments' ) ) {
			$html .= '<a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-assess' ) ) . '">' . esc_html__( 'Assessments', 'educore-assessments' ) . '</a> ';
		}
		if ( user_can( $uid, 'ec_grade_submissions' ) ) {
			$html .= '<a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-grading' ) ) . '">' . esc_html__( 'Grading', 'educore-assessments' ) . '</a> ';
		}
		return $html;
	}

	public static function workspace_queue( string $html, int $uid ): string {
		if ( ! user_can( $uid, 'ec_grade_submissions' ) ) {
			return $html;
		}
		$n = count( Grading::queue( $uid, 0, 500 ) );
		/* translators: %d: count */
		return $html . '<div class="ec-card ec-ws-queue"><strong>' . esc_html( sprintf( _n( '%d answer awaiting grading', '%d answers awaiting grading', $n, 'educore-assessments' ), $n ) ) . '</strong> ' . ( $n ? '<a class="ec-btn ec-btn--primary" href="' . esc_url( admin_url( 'admin.php?page=educore-grading' ) ) . '">' . esc_html__( 'Open grading queue', 'educore-assessments' ) . '</a>' : '' ) . '</div>';
	}

	public static function course_actions( string $html, int $course_id, int $uid ): string {
		if ( user_can( $uid, 'ec_edit_course', $course_id ) ) {
			$html .= '<a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-questions&course=' . $course_id ) ) . '">' . esc_html__( 'Questions', 'educore-assessments' ) . '</a> ';
		}
		return $html;
	}

	public static function export( array $data, $user ): array {
		global $wpdb;
		if ( ! $user ) {
			return $data;
		}
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT a.id, s.title, a.attempt_no, a.state, a.started_at, a.submitted_at, a.score, a.max_score, a.percent, a.passed, a.released FROM ' . Schema::t( 'attempts' ) . ' a JOIN ' . Schema::t( 'assessments' ) . ' s ON s.id=a.assessment_id WHERE a.user_id=%d', $user->ID ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $rows as $r ) {
			$items = array();
			foreach ( $r as $k => $v ) {
				$items[] = array( 'name' => $k, 'value' => (string) $v );
			}
			foreach ( Attempts::items( (int) $r['id'] ) as $i ) {
				$items[] = array( 'name' => 'answer_' . $i['position'], 'value' => (string) $i['answer'] . ( null !== $i['final_score'] ? ' [' . $i['final_score'] . '] ' . $i['feedback'] : '' ) );
			}
			$data[] = array( 'group_id' => 'educore-attempts', 'group_label' => __( 'Assessment attempts', 'educore-assessments' ), 'item_id' => 'attempt-' . $r['id'], 'data' => $items );
		}
		return $data;
	}

	public static function erase( $user ): void {
		global $wpdb;
		$at  = Schema::t( 'attempts' );
		$it  = Schema::t( 'attempt_items' );
		$rs  = Schema::t( 'responses' );
		$ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$at} WHERE user_id=%d", $user->ID ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( $ids ) {
			$in = implode( ',', $ids );
			$wpdb->query( "DELETE r FROM {$rs} r JOIN {$it} i ON i.id=r.attempt_item_id WHERE i.attempt_id IN ($in)" ); // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->query( "DELETE FROM {$it} WHERE attempt_id IN ($in)" ); // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->query( "DELETE FROM {$at} WHERE id IN ($in)" ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		$wpdb->delete( Schema::t( 'practice_tries' ), array( 'user_id' => $user->ID ) );
	}

	public static function student_url( array $a ): string {
		return add_query_arg( 'ec_assessment', (int) $a['id'], (string) get_permalink( (int) $a['course_id'] ) ) . '#ec-assessment-' . (int) $a['id'];
	}

	/** Context for EduCore Notifications (attempt_submitted / grade_released e-mails). */
	public static function attempt_context( $ctx, $attempt_id ): array {
		$at = Attempts::get( (int) $attempt_id );
		$a  = $at ? Assessments::get( (int) $at['assessment_id'] ) : null;
		if ( ! $a ) {
			return (array) $ctx;
		}
		$pending = false;
		foreach ( Attempts::items( (int) $attempt_id ) as $i ) {
			if ( (int) $i['needs_grading'] && null === $i['final_score'] ) {
				$pending = true;
				break;
			}
		}
		return array_merge(
			(array) $ctx,
			array(
				'title'         => (string) $a['title'],
				'course_id'     => (int) $a['course_id'],
				'needs_grading' => $pending,
				'url'           => self::student_url( $a ),
				'grading_url'   => admin_url( 'admin.php?page=educore-grading' ),
			)
		);
	}

	/** Course for core's activity log: attempts via their assessment, practice via the question. */
	public static function activity_course_of( $course, $kind, $id ): int {
		global $wpdb;
		if ( (int) $course ) {
			return (int) $course;
		}
		if ( 'attempt' === $kind ) {
			return Grading::course_of_attempt( (int) $id );
		}
		if ( 'question' === $kind ) {
			return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT course_id FROM ' . Schema::t( 'questions' ) . ' WHERE id=%d', (int) $id ) );
		}
		return (int) $course;
	}

	/**
	 * Daily reminders: published quizzes/exams whose availability window (closes_at, UTC) ends
	 * within the next 48 hours, for active enrolled learners who have not submitted and still
	 * have attempts left. Flat items: user_id, key, title, due, url.
	 */
	public static function reminders( $items ): array {
		global $wpdb;
		$items = (array) $items;
		$now   = time();
		$rows  = $wpdb->get_results( 'SELECT * FROM ' . Schema::t( 'assessments' ) . " WHERE status='published' AND kind IN ('quiz','exam')", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $rows as $row ) {
			$a     = Assessments::get( (int) $row['id'] );
			$close = $a['settings']['closes_at'] ? strtotime( $a['settings']['closes_at'] . ' UTC' ) : 0;
			if ( ! $close || $close <= $now || $close > $now + 2 * DAY_IN_SECONDS || 'publish' !== get_post_status( (int) $a['course_id'] ) ) {
				continue;
			}
			foreach ( Enrollment::for_course( (int) $a['course_id'], 5000 ) as $e ) {
				$uid = (int) $e['user_id'];
				if ( 'active' !== $e['status'] || ! Enrollment::is_enrolled( $uid, (int) $a['course_id'] ) ) {
					continue;
				}
				$done = array_filter( Attempts::for_user( (int) $a['id'], $uid ), static fn( $x ) => 'open' !== $x['state'] );
				$rem  = Attempts::remaining( $a, $uid );
				if ( $done || ( null !== $rem && $rem < 1 ) ) {
					continue;
				}
				$items[] = array(
					'user_id' => $uid,
					'key'     => 'exam:' . (int) $a['id'] . ':' . $uid,
					/* translators: 1: assessment title, 2: local closing date, time and timezone */
					'title'   => sprintf( __( '%1$s (closes %2$s)', 'educore-assessments' ), (string) $a['title'], Assessments::format_local( $a['settings']['closes_at'] ) ),
					'due'     => gmdate( 'Y-m-d H:i:s', $close ),
					'url'     => self::student_url( $a ),
				);
			}
		}
		return $items;
	}

	public static function tiles( array $tiles ): array {
		$tiles[ __( 'Pending grading', 'educore-assessments' ) ] = number_format_i18n( ReadModel::pending_grading() );
		return $tiles;
	}
}
