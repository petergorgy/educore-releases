<?php
namespace EduCore\Recovery;

defined( 'ABSPATH' ) || exit;

final class Settings {
	public const OPTION = 'educore_rc_settings';

	public static function defaults(): array {
		return array(
			'daily'          => 'on',   // Academic data (database) backup every day.
			'weekly'         => 'on',   // Full backup (database + files) every week.
			'keep_daily'     => 7,
			'keep_weekly'    => 4,
			'keep_predeploy' => 5,
			'keep_manual'    => 10,
			'predeploy'      => 'on',   // Backup before EduCore packages are installed/updated.
			'max_file_mb'    => 0,      // 0 = no per-file limit for full backups.
		);
	}

	public static function all(): array {
		return array_merge( self::defaults(), (array) get_option( self::OPTION, array() ) );
	}

	/** @return mixed */
	public static function get( string $k ) {
		return self::all()[ $k ] ?? null;
	}

	public static function save( array $in ): void {
		$out = self::all();
		foreach ( self::defaults() as $k => $d ) {
			if ( is_int( $d ) ) {
				$out[ $k ] = max( 0, min( 365, absint( $in[ $k ] ?? $d ) ) );
			} else {
				$out[ $k ] = ( isset( $in[ $k ] ) && 'on' === $in[ $k ] ) ? 'on' : 'off';
			}
		}
		$out['keep_daily']  = max( 1, $out['keep_daily'] );
		$out['keep_weekly'] = max( 1, $out['keep_weekly'] );
		update_option( self::OPTION, $out, false );
	}

	/** Encryption key (32 bytes) from wp-config — never stored in the database or in backups. */
	public static function key(): ?string {
		if ( ! defined( 'EDUCORE_BACKUP_KEY' ) || ! function_exists( 'sodium_crypto_secretstream_xchacha20poly1305_init_push' ) ) {
			return null;
		}
		$k = base64_decode( (string) EDUCORE_BACKUP_KEY, true );
		return ( false !== $k && SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_KEYBYTES === strlen( $k ) ) ? $k : null;
	}

	/** Secret token for the reliable cron URL (stored hashed). */
	public static function cron_token( bool $regenerate = false ): string {
		$plain = '';
		if ( $regenerate || ! get_option( 'educore_rc_cron_hash' ) ) {
			$plain = bin2hex( random_bytes( 16 ) );
			update_option( 'educore_rc_cron_hash', hash( 'sha256', $plain ), false );
		}
		return $plain;
	}
}
