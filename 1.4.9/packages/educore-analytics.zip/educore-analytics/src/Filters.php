<?php
namespace EduCore\Analytics;

use EduCore\Core\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Normalised report filters. Dates are inclusive UTC calendar days.
 * course_ids === null means "every course the viewer may see" (resolved by Scope).
 */
final class Filters {
	public string $from;
	public string $to;
	/** @var int[]|null */
	public ?array $course_ids = null;
	public int $programme_id  = 0;
	public string $academic_year = '';
	public int $now;

	public function __construct( array $in = array() ) {
		$this->now  = isset( $in['now'] ) ? (int) $in['now'] : time();
		$to         = isset( $in['to'] ) && self::valid_date( (string) $in['to'] ) ? (string) $in['to'] : gmdate( 'Y-m-d', $this->now );
		$from       = isset( $in['from'] ) && self::valid_date( (string) $in['from'] ) ? (string) $in['from'] : gmdate( 'Y-m-d', strtotime( $to . ' -29 days' ) );
		if ( $from > $to ) {
			[ $from, $to ] = array( $to, $from );
		}
		$this->from = $from;
		$this->to   = $to;
		if ( isset( $in['course_ids'] ) && null !== $in['course_ids'] ) {
			$this->course_ids = array_values( array_filter( array_map( 'absint', (array) $in['course_ids'] ) ) );
		} elseif ( ! empty( $in['course'] ) ) {
			$this->course_ids = array( absint( $in['course'] ) );
		}
		$this->programme_id  = isset( $in['programme'] ) ? absint( $in['programme'] ) : 0;
		$this->academic_year = isset( $in['year'] ) ? sanitize_text_field( (string) $in['year'] ) : '';
	}

	public static function valid_date( string $d ): bool {
		return (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) && false !== strtotime( $d );
	}

	public function from_dt(): string {
		return $this->from . ' 00:00:00';
	}

	public function to_dt(): string {
		return $this->to . ' 23:59:59';
	}

	/** @return int[] courses (all published+draft courses when unrestricted) */
	public function courses(): array {
		if ( null !== $this->course_ids ) {
			return $this->course_ids;
		}
		return array_map( 'intval', get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ), 'posts_per_page' => -1, 'fields' => 'ids' ) ) );
	}

	public function has_cohort(): bool {
		return $this->programme_id > 0 || '' !== $this->academic_year;
	}

	/** SQL fragment restricting a user-id column to the cohort ('' when no cohort filter). */
	public function cohort_sql( string $column ): string {
		global $wpdb;
		$sql = '';
		if ( $this->programme_id ) {
			$sql .= $wpdb->prepare( " AND {$column} IN (SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key='educore_programme_id' AND meta_value=%s)", (string) $this->programme_id ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		if ( '' !== $this->academic_year ) {
			$sql .= $wpdb->prepare( " AND {$column} IN (SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key='educore_academic_year' AND meta_value=%s)", $this->academic_year ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		return $sql;
	}

	public function to_query_args(): array {
		return array_filter(
			array(
				'from'      => $this->from,
				'to'        => $this->to,
				'course'    => ( null !== $this->course_ids && 1 === count( $this->course_ids ) ) ? $this->course_ids[0] : null,
				'programme' => $this->programme_id ?: null,
				'year'      => $this->academic_year ?: null,
			)
		);
	}
}
