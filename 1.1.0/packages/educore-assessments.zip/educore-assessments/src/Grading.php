<?php
namespace EduCore\Assessments;

use EduCore\Core\Audit;
use EduCore\Core\Schema as CoreSchema;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/**
 * Manual (rubric) grading of essays and release of results.
 * AI-assisted marking is NOT implemented; if added later it must only suggest scores that an
 * instructor confirms here before a grade becomes final.
 */
final class Grading {

	public static function rubric( int $question_id ): array {
		global $wpdb;
		$c = $wpdb->get_var( $wpdb->prepare( 'SELECT criteria FROM ' . Schema::t( 'rubrics' ) . ' WHERE question_id=%d ORDER BY id DESC LIMIT 1', $question_id ) );
		return $c ? (array) json_decode( (string) $c, true ) : array();
	}

	/** $criteria: [ ['label'=>..,'points'=>..], ... ] */
	public static function set_rubric( int $question_id, array $criteria ): void {
		global $wpdb;
		$clean = array();
		foreach ( $criteria as $c ) {
			$label = sanitize_text_field( (string) ( $c['label'] ?? '' ) );
			if ( '' !== $label ) {
				$clean[] = array( 'label' => $label, 'points' => max( 0, (float) ( $c['points'] ?? 0 ) ) );
			}
		}
		$t = Schema::t( 'rubrics' );
		$wpdb->delete( $t, array( 'question_id' => $question_id ) );
		if ( $clean ) {
			$wpdb->insert( $t, array( 'question_id' => $question_id, 'criteria' => wp_json_encode( $clean ) ) );
		}
	}

	/** Course id owning a response (for object-level permission checks). */
	public static function course_of_response( int $response_id ): int {
		global $wpdb;
		$rs = Schema::t( 'responses' );
		$it = Schema::t( 'attempt_items' );
		$at = Schema::t( 'attempts' );
		$as = Schema::t( 'assessments' );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT s.course_id FROM {$rs} r JOIN {$it} i ON i.id=r.attempt_item_id JOIN {$at} a ON a.id=i.attempt_id JOIN {$as} s ON s.id=a.assessment_id WHERE r.id=%d", $response_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function course_of_attempt( int $attempt_id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT s.course_id FROM ' . Schema::t( 'attempts' ) . ' a JOIN ' . Schema::t( 'assessments' ) . ' s ON s.id=a.assessment_id WHERE a.id=%d', $attempt_id ) );
	}

	/** @return true|\WP_Error */
	public static function grade( int $response_id, float $score, string $feedback = '', array $rubric_scores = array() ) {
		global $wpdb;
		$rs  = Schema::t( 'responses' );
		$it  = Schema::t( 'attempt_items' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT r.*, i.points, i.attempt_id FROM {$rs} r JOIN {$it} i ON i.id=r.attempt_item_id WHERE r.id=%d", $response_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( ! $row ) {
			return new \WP_Error( 'educore_not_found', __( 'Response not found.', 'educore-assessments' ), array( 'status' => 404 ) );
		}
		$at = Attempts::get( (int) $row['attempt_id'] );
		if ( ! $at || 'open' === $at['state'] ) {
			return new \WP_Error( 'educore_not_ready', __( 'The attempt has not been submitted yet.', 'educore-assessments' ), array( 'status' => 409 ) );
		}
		if ( $score < 0 || $score > (float) $row['points'] ) {
			/* translators: %s: max points */
			return new \WP_Error( 'educore_invalid', sprintf( __( 'Score must be between 0 and %s.', 'educore-assessments' ), $row['points'] ), array( 'status' => 400 ) );
		}
		$wpdb->update(
			$rs,
			array(
				'final_score'   => round( $score, 2 ),
				'graded_by'     => get_current_user_id(),
				'graded_at'     => CoreSchema::now(),
				'feedback'      => sanitize_textarea_field( $feedback ),
				'rubric_scores' => wp_json_encode( array_map( 'floatval', $rubric_scores ) ),
			),
			array( 'id' => $response_id )
		);
		Audit::log( 'grade.recorded', 'attempt', (int) $row['attempt_id'], array( 'response_id' => $response_id, 'score' => $score ) );
		Attempts::recompute( (int) $row['attempt_id'] );
		Attempts::maybe_auto_release( (int) $row['attempt_id'] );
		return true;
	}

	/** Pending essay responses the user may grade. */
	public static function queue( int $user_id, int $course_id = 0, int $limit = 100 ): array {
		global $wpdb;
		$courses = user_can( $user_id, 'ec_manage_all_courses' ) ? null : array_values( array_filter( Staff::courses_of( $user_id ), static fn( $c ) => user_can( $user_id, 'ec_grade_course', $c ) ) );
		if ( is_array( $courses ) && ! $courses ) {
			return array();
		}
		$rs     = Schema::t( 'responses' );
		$it     = Schema::t( 'attempt_items' );
		$at     = Schema::t( 'attempts' );
		$as     = Schema::t( 'assessments' );
		$where  = 'r.needs_grading=1 AND r.final_score IS NULL';
		$where .= null === $courses ? '' : ' AND s.course_id IN (' . implode( ',', array_map( 'intval', $courses ) ) . ')';
		$where .= $course_id ? $wpdb->prepare( ' AND s.course_id=%d', $course_id ) : '';
		return $wpdb->get_results( $wpdb->prepare( "SELECT r.id response_id, r.answer, i.points, i.question_version_id, a.id attempt_id, a.user_id, a.submitted_at, s.id assessment_id, s.title, s.course_id FROM {$rs} r JOIN {$it} i ON i.id=r.attempt_item_id JOIN {$at} a ON a.id=i.attempt_id JOIN {$as} s ON s.id=a.assessment_id WHERE {$where} ORDER BY a.submitted_at ASC LIMIT %d", $limit ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Release all graded, unreleased attempts of an assessment. */
	public static function release_assessment( int $assessment_id ): int {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . Schema::t( 'attempts' ) . " WHERE assessment_id=%d AND state='graded' AND released=0", $assessment_id ) );
		foreach ( $ids as $id ) {
			Attempts::release( (int) $id );
		}
		return count( $ids );
	}
}
