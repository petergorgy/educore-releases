<?php
namespace EduCore\Identity;

defined( 'ABSPATH' ) || exit;

/**
 * Provider definitions and configuration. Endpoints follow each provider's current documentation (checked 2026-11-03):
 *  - Google: OpenID Connect discovery, scopes "openid email profile", PKCE.
 *  - Microsoft identity platform v2.0: OIDC per tenant (consumers / organizations / common / a tenant ID), PKCE.
 *    The e-mail claim is not guaranteed verified and can change, so it is never used to match accounts.
 *  - LinkedIn: "Sign In with LinkedIn using OpenID Connect", scopes "openid profile email"; e-mail claims are optional.
 *  - Facebook Login: manually built flow (Graph API, version configurable), token inspected with debug_token and the
 *    profile read with appsecret_proof. Facebook e-mail may be absent and is never used to match accounts.
 *
 * Secrets: a constant in wp-config.php (EDUCORE_SSO_GOOGLE_SECRET, …) wins; otherwise the secret is stored encrypted
 * (libsodium secretbox, key derived from the site's secret keys). Secrets are never sent to the browser or logged.
 */
final class Providers {
	public const OPTION = 'educore_id_providers';
	public const KEYS   = array( 'google', 'microsoft', 'linkedin', 'facebook' );

	public static function definitions(): array {
		$d = array(
			'google'    => array( 'label' => 'Google', 'type' => 'oidc', 'discovery' => 'https://accounts.google.com/.well-known/openid-configuration', 'scope' => 'openid email profile', 'pkce' => true, 'trust_email' => true, 'hosts' => array( 'accounts.google.com', 'oauth2.googleapis.com', 'www.googleapis.com', 'openidconnect.googleapis.com' ), 'console' => 'https://console.cloud.google.com/apis/credentials' ),
			'microsoft' => array( 'label' => 'Microsoft', 'type' => 'oidc', 'discovery' => 'https://login.microsoftonline.com/{tenant}/v2.0/.well-known/openid-configuration', 'scope' => 'openid email profile', 'pkce' => true, 'trust_email' => false, 'hosts' => array( 'login.microsoftonline.com' ), 'console' => 'https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade' ),
			'linkedin'  => array( 'label' => 'LinkedIn', 'type' => 'oidc', 'discovery' => 'https://www.linkedin.com/oauth/.well-known/openid-configuration', 'scope' => 'openid profile email', 'pkce' => false, 'trust_email' => true, 'hosts' => array( 'www.linkedin.com', 'api.linkedin.com' ), 'console' => 'https://www.linkedin.com/developers/apps' ),
			'facebook'  => array( 'label' => 'Facebook', 'type' => 'facebook', 'authorize' => 'https://www.facebook.com/{graph}/dialog/oauth', 'token' => 'https://graph.facebook.com/{graph}/oauth/access_token', 'debug' => 'https://graph.facebook.com/debug_token', 'me' => 'https://graph.facebook.com/{graph}/me', 'scope' => 'public_profile,email', 'pkce' => false, 'trust_email' => false, 'hosts' => array( 'www.facebook.com', 'graph.facebook.com' ), 'console' => 'https://developers.facebook.com/apps/' ),
		);
		/** Staging/test hook only (a local mock provider). Inert unless EDUCORE_IDENTITY_TESTING is defined. */
		return self::testing() ? (array) apply_filters( 'educore/identity/definitions', $d ) : $d;
	}

	/** True only on test installations (the staging mock provider defines the constant). Never defined in production. */
	public static function testing(): bool {
		return defined( 'EDUCORE_IDENTITY_TESTING' ) && EDUCORE_IDENTITY_TESTING;
	}

	public static function def( string $p ): ?array {
		return self::definitions()[ $p ] ?? null;
	}

	public static function all_config(): array {
		$raw = get_option( self::OPTION, array() );
		return is_array( $raw ) ? $raw : array();
	}

	public static function config( string $p ): array {
		return array_merge(
			array( 'enabled' => false, 'client_id' => '', 'secret' => '', 'tenant' => 'consumers', 'graph' => 'v25.0', 'health' => array( 'ok' => false, 'at' => '', 'message' => '' ) ),
			(array) ( self::all_config()[ $p ] ?? array() )
		);
	}

	public static function save_config( string $p, array $c ): void {
		$all       = self::all_config();
		$all[ $p ] = $c;
		update_option( self::OPTION, $all, false );
	}

	public static function constant( string $p ): string {
		$name = 'EDUCORE_SSO_' . strtoupper( $p ) . '_SECRET';
		return defined( $name ) ? (string) constant( $name ) : '';
	}

	public static function secret( string $p ): string {
		$c = self::constant( $p );
		if ( '' !== $c ) {
			return $c;
		}
		$enc = (string) self::config( $p )['secret'];
		return '' === $enc ? '' : self::decrypt( $enc );
	}

	public static function has_secret( string $p ): bool {
		return '' !== self::secret( $p );
	}

	private static function key(): string {
		return hash( 'sha256', wp_salt( 'secure_auth' ) . '|educore-identity|' . ( defined( 'EDUCORE_SSO_KEY' ) ? EDUCORE_SSO_KEY : '' ), true );
	}

	public static function encrypt( string $plain ): string {
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		return 'v1:' . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, self::key() ) );
	}

	public static function decrypt( string $enc ): string {
		if ( 0 !== strpos( $enc, 'v1:' ) ) {
			return '';
		}
		$raw = base64_decode( substr( $enc, 3 ), true );
		if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
			return '';
		}
		$out = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), self::key() );
		return false === $out ? '' : $out;
	}

	public static function configured( string $p ): bool {
		$c = self::config( $p );
		return '' !== trim( (string) $c['client_id'] ) && self::has_secret( $p );
	}

	/** Shown to people only when enabled, configured and the last configuration test passed. */
	public static function available( string $p ): bool {
		$c = self::config( $p );
		return ! empty( $c['enabled'] ) && self::configured( $p ) && ! empty( $c['health']['ok'] );
	}

	/** @return string[] */
	public static function available_list(): array {
		return array_values( array_filter( self::KEYS, array( self::class, 'available' ) ) );
	}

	public static function label( string $p ): string {
		return (string) ( self::def( $p )['label'] ?? $p );
	}

	public static function callback_url( string $p ): string {
		return rest_url( 'educore/v1/identity/callback/' . $p );
	}

	/** Resolved endpoint template for a provider (tenant / Graph version substituted). */
	public static function expand( string $url, string $p ): string {
		$c = self::config( $p );
		return strtr( $url, array( '{tenant}' => rawurlencode( (string) $c['tenant'] ), '{graph}' => rawurlencode( (string) $c['graph'] ) ) );
	}

	/** Remote calls only to the provider's own HTTPS hosts (or hosts a test filter added). */
	public static function url_allowed( string $url, string $p ): bool {
		$parts = wp_parse_url( $url );
		$def   = self::def( $p );
		if ( ! $def || empty( $parts['host'] ) ) {
			return false;
		}
		$test = self::testing() ? (array) apply_filters( 'educore/identity/test_hosts', array() ) : array();
		if ( in_array( $parts['host'], $test, true ) ) {
			return true;
		}
		return 'https' === ( $parts['scheme'] ?? '' ) && in_array( strtolower( $parts['host'] ), $def['hosts'], true );
	}

	public static function valid_tenant( string $t ): bool {
		return in_array( $t, array( 'consumers', 'organizations', 'common' ), true ) || (bool) preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $t );
	}
}
