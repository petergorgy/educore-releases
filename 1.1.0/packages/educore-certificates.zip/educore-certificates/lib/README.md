# Bundled third-party libraries

Loaded only when a certificate PDF is generated (`lib/autoload.php`), and only if no other plugin has already loaded `\Mpdf\Mpdf`.

| Library | Version | License | Source |
|---|---|---|---|
| mpdf/mpdf (src, data) | 8.2.5 | GPL-2.0-only | https://github.com/mpdf/mpdf |
| mpdf/psr-http-message-shim | 2.0.1 | MIT | https://github.com/mpdf/psr-http-message-shim |
| mpdf/psr-log-aware-trait | 3.0.0 | MIT | https://github.com/mpdf/psr-log-aware-trait |
| myclabs/deep-copy | 1.13.4 | MIT | https://github.com/myclabs/DeepCopy |
| psr/http-message | 2.0 | MIT | https://github.com/php-fig/http-message |
| psr/log | 3.0.2 | MIT | https://github.com/php-fig/log |
| setasign/fpdi | 2.6.3 | MIT | https://github.com/Setasign/FPDI |

Fonts kept (all others removed to reduce size): DejaVu Sans Regular/Bold (Bitstream Vera / DejaVu license, see DejaVuinfo.txt) and XB Riyaz Regular/Bold (Arabic, OpenType shaping; see "XW Zar Font Info.txt"). ICC profiles were removed (PDF/A output is not used).

`paragonie/random_compat` is not bundled: it is a no-op polyfill on PHP 7+.

| mpdf/qrcode | 1.2.1 | LGPL-2.1-or-later | `qrcode/` — QR code on certificates (added in 1.0.1) |
