<?php
namespace EduCore\Notifications;

defined( 'ABSPATH' ) || exit;

/**
 * wp_mail transport with optional authenticated SMTP. The SMTP password is stored encrypted
 * (libsodium, key derived from the site's auth salt), never displayed and never logged.
 */
final class Mailer {
	private static ?array $current = null;
	private static string $error   = '';

	public static function register(): void {
		add_action( 'phpmailer_init', array( self::class, 'configure' ), 20 );
		add_action( 'wp_mail_failed', array( self::class, 'capture_error' ) );
	}

	/** @return true|string true when the mail server accepted the message, else an error string. */
	public static function send( array $job ) {
		self::$current = $job;
		self::$error   = '';
		$from          = sanitize_email( (string) get_option( 'educore_mail_from', 'support@educore.gorgy.org' ) );
		$name          = (string) get_option( 'educore_mail_from_name', 'EduCore' );
		$headers       = array( 'Content-Type: text/html; charset=UTF-8', 'From: ' . $name . ' <' . $from . '>', 'Reply-To: ' . sanitize_email( (string) get_option( 'educore_support_email', $from ) ) );
		try {
			$ok = wp_mail( $job['recipient_email'], $job['subject'], $job['body'], $headers );
		} catch ( \Throwable $e ) {
			$ok          = false;
			self::$error = $e->getMessage();
		}
		self::$current = null;
		if ( true === $ok ) {
			return true;
		}
		return self::scrub( self::$error ?: 'wp_mail returned false' );
	}

	/** @param \PHPMailer\PHPMailer\PHPMailer $mailer */
	public static function configure( $mailer ): void {
		if ( null === self::$current ) {
			return;
		}
		$payload = json_decode( (string) self::$current['payload'], true );
		if ( ! empty( $payload['text'] ) ) {
			$mailer->AltBody = (string) $payload['text']; // phpcs:ignore WordPress.NamingConventions.ValidVariableName
		}
		$host = (string) get_option( 'educore_smtp_host', '' );
		if ( '' === $host ) {
			return;
		}
		$mailer->isSMTP();
		$mailer->Host       = $host; // phpcs:ignore WordPress.NamingConventions.ValidVariableName
		$mailer->Port       = (int) get_option( 'educore_smtp_port', 587 ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName
		$enc                = (string) get_option( 'educore_smtp_encryption', 'tls' );
		$mailer->SMTPSecure = in_array( $enc, array( 'tls', 'ssl' ), true ) ? $enc : ''; // phpcs:ignore WordPress.NamingConventions.ValidVariableName
		$user               = (string) get_option( 'educore_smtp_user', '' );
		if ( '' !== $user ) {
			$mailer->SMTPAuth = true; // phpcs:ignore WordPress.NamingConventions.ValidVariableName
			$mailer->Username = $user; // phpcs:ignore WordPress.NamingConventions.ValidVariableName
			$mailer->Password = self::password(); // phpcs:ignore WordPress.NamingConventions.ValidVariableName
		}
		$mailer->Timeout = 15; // phpcs:ignore WordPress.NamingConventions.ValidVariableName
	}

	public static function capture_error( \WP_Error $error ): void {
		self::$error = $error->get_error_message();
	}

	/** Remove the SMTP password from any error text. */
	public static function scrub( string $msg ): string {
		$pw = self::password();
		return '' === $pw ? $msg : str_replace( $pw, '[redacted]', $msg );
	}

	private static function key(): string {
		return sodium_crypto_generichash( wp_salt( 'auth' ) . '|educore-smtp', '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES );
	}

	public static function set_password( string $plain ): void {
		if ( '' === $plain ) {
			delete_option( 'educore_smtp_pass' );
			return;
		}
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		update_option( 'educore_smtp_pass', base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, self::key() ) ), false ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}

	public static function password(): string {
		$raw = base64_decode( (string) get_option( 'educore_smtp_pass', '' ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( ! $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
			return '';
		}
		$plain = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), self::key() );
		return false === $plain ? '' : $plain;
	}
}
