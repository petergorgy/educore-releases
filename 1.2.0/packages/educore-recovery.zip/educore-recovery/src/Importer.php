<?php
namespace EduCore\Recovery;

use EduCore\Core\Audit;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Registers a backup file produced on another installation (disaster recovery onto a rebuilt site). */
final class Importer {

	/** @return int|\WP_Error */
	public static function import( string $src ) {
		global $wpdb;
		if ( ! is_file( $src ) || ! is_readable( $src ) ) {
			return new \WP_Error( 'ec_rc_import', __( 'File not found.', 'educore-recovery' ) );
		}
		$fh    = fopen( $src, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$magic = (string) fread( $fh, 6 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$enc     = "ECBK1\n" === $magic;
		$zippath = $src;
		$tmp     = null;
		if ( $enc ) {
			$key = Settings::key();
			if ( ! $key ) {
				return new \WP_Error( 'ec_rc_key', __( 'This backup is encrypted and EDUCORE_BACKUP_KEY is not configured.', 'educore-recovery' ) );
			}
			$tmp = Store::tmp( '.zip' );
			$r   = Store::decrypt( $src, $tmp, $key );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$zippath = $tmp;
		}
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $zippath, \ZipArchive::RDONLY ) ) {
			$tmp && wp_delete_file( $tmp );
			return new \WP_Error( 'ec_rc_zip', __( 'Not a readable EduCore backup archive.', 'educore-recovery' ) );
		}
		$m = json_decode( (string) $zip->getFromName( 'manifest.json' ), true );
		$zip->close();
		$tmp && wp_delete_file( $tmp );
		if ( ! is_array( $m ) || empty( $m['backup_id'] ) || ! preg_match( '/^\d{8}T\d{6}-[a-f0-9]{4}$/', (string) $m['backup_id'] ) || ! isset( Backup::kinds()[ $m['kind'] ?? '' ] ) ) {
			return new \WP_Error( 'ec_rc_manifest', __( 'The archive has no valid EduCore manifest.', 'educore-recovery' ) );
		}
		if ( Backup::by_uid( $m['backup_id'] ) ) {
			return new \WP_Error( 'ec_rc_exists', __( 'This backup is already registered here.', 'educore-recovery' ) );
		}
		$name = "educore-{$m['kind']}-{$m['backup_id']}.zip" . ( $enc ? '.enc' : '' );
		$dest = Store::dir() . '/' . $name;
		if ( ! copy( $src, $dest ) ) {
			return new \WP_Error( 'ec_rc_copy', __( 'Could not copy the file into backup storage.', 'educore-recovery' ) );
		}
		$summary = $m;
		$summary['file_count'] = count( (array) ( $m['entries'] ?? array() ) ) - 1;
		unset( $summary['entries'] );
		$wpdb->insert(
			Backup::table(),
			array(
				'uid'            => $m['backup_id'],
				'kind'           => $m['kind'],
				'trigger_source' => 'imported',
				'status'         => 'complete',
				'file'           => $name,
				'size'           => filesize( $dest ),
				'sha256'         => hash_file( 'sha256', $dest ),
				'encrypted'      => $enc ? 1 : 0,
				'manifest'       => wp_json_encode( $summary ),
				'message'        => sprintf( /* translators: %s: site */ __( 'Imported; originally from %s.', 'educore-recovery' ), (string) ( $m['site']['home'] ?? '?' ) ),
				'created_by'     => get_current_user_id(),
				'created_at'     => gmdate( 'Y-m-d H:i:s', strtotime( (string) $m['created_at'] ) ),
				'finished_at'    => Schema::now(),
			)
		);
		$id = (int) $wpdb->insert_id;
		Audit::log( 'backup.imported', 'backup', $id, array( 'uid' => $m['backup_id'] ) );
		return $id;
	}
}
