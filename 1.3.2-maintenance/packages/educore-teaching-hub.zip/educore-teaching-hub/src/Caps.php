<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Teaching responsibilities are capabilities, not separate identities: one WordPress user can be
 * instructor + teacher + tutor at once (multiple roles on the same account).
 *
 * Primitive caps: ec_teach, ec_tutor_sessions, ec_manage_teaching, ec_approve_tutors, ec_review_reports.
 * Meta caps (pass an object id): ec_teach_class, ec_manage_class, ec_grade_assignment,
 * ec_manage_session, ec_view_hub_student. Core's ec_view_student is extended to class/tutoring scope.
 */
final class Caps {
	public const PRIMITIVE = array( 'ec_teach', 'ec_tutor_sessions', 'ec_manage_teaching', 'ec_approve_tutors', 'ec_review_reports' );
	public const CLASS_ROLES = array( 'lead', 'teacher', 'assistant' );

	/** @var array<string,mixed> */
	private static array $cache = array();

	public static function install(): void {
		add_role( 'ec_teacher', 'Teacher', array( 'read' => true, 'upload_files' => true, 'ec_teach' => true, 'ec_access_workspace' => true ) );
		add_role( 'ec_tutor', 'Tutor', array( 'read' => true, 'upload_files' => true, 'ec_tutor_sessions' => true, 'ec_access_workspace' => true ) );
		foreach ( array( 'ec_teacher' => array( 'ec_teach', 'ec_access_workspace' ), 'ec_tutor' => array( 'ec_tutor_sessions', 'ec_access_workspace' ), 'ec_instructor' => array( 'ec_teach' ) ) as $role => $caps ) {
			$r = get_role( $role );
			foreach ( $caps as $c ) {
				$r && $r->add_cap( $c );
			}
		}
		foreach ( array( 'administrator', 'ec_academic_manager' ) as $role ) {
			$r = get_role( $role );
			foreach ( self::PRIMITIVE as $c ) {
				$r && $r->add_cap( $c );
			}
		}
		update_option( 'educore_th_caps_version', EDUCORE_TH_VERSION, false );
	}

	public static function uninstall(): void {
		foreach ( wp_roles()->role_objects as $role ) {
			foreach ( self::PRIMITIVE as $c ) {
				$role->remove_cap( $c );
			}
		}
		remove_role( 'ec_teacher' );
		remove_role( 'ec_tutor' );
	}

	public static function register(): void {
		add_filter( 'map_meta_cap', array( self::class, 'map_meta_cap' ), 20, 4 );
	}

	public static function flush(): void {
		self::$cache = array();
		Classes::flush();
	}

	public static function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array {
		$id = isset( $args[0] ) ? (int) $args[0] : 0;
		switch ( $cap ) {
			case 'ec_teach_class':
				return self::is_manager( $user_id ) || self::class_role( $user_id, $id ) ? array( 'read' ) : array( 'do_not_allow' );
			case 'ec_manage_class':
				return self::is_manager( $user_id ) || 'lead' === self::class_role( $user_id, $id ) ? array( 'read' ) : array( 'do_not_allow' );
			case 'ec_grade_assignment':
				return self::can_grade_assignment( $user_id, $id ) ? array( 'read' ) : array( 'do_not_allow' );
			case 'ec_manage_session':
				return self::is_manager( $user_id ) || self::session_tutor( $id ) === $user_id && $user_id > 0 ? array( 'read' ) : array( 'do_not_allow' );
			case 'ec_view_hub_student':
				return self::can_view_student( $user_id, $id ) ? array( 'read' ) : array( 'do_not_allow' );
			case 'ec_view_student':
				// Extend core scope: class teachers and tutors with a confirmed relationship.
				if ( $user_id && $id && in_array( 'do_not_allow', $caps, true ) && self::teaches_student( $user_id, $id ) ) {
					return array( 'read' );
				}
				return $caps;
		}
		return $caps;
	}

	public static function is_manager( int $user_id ): bool {
		return $user_id > 0 && user_can( $user_id, 'ec_manage_teaching' );
	}

	/** Staff role of a user in a class (null = none). Requires ec_teach (role can be revoked centrally). */
	public static function class_role( int $user_id, int $class_id ): ?string {
		if ( ! $user_id || ! $class_id ) {
			return null;
		}
		$key = "cr{$user_id}_{$class_id}";
		if ( ! array_key_exists( $key, self::$cache ) ) {
			global $wpdb;
			$role                = $wpdb->get_var( $wpdb->prepare( 'SELECT staff_role FROM ' . Schema::table( 'th_class_staff' ) . ' WHERE user_id=%d AND class_id=%d', $user_id, $class_id ) );
			self::$cache[ $key ] = ( $role && user_can( $user_id, 'ec_teach' ) ) ? (string) $role : null;
		}
		return self::$cache[ $key ];
	}

	/** @return int[] class ids the user teaches (all active classes for managers). */
	public static function classes_of( int $user_id ): array {
		global $wpdb;
		$key = "co{$user_id}";
		if ( ! array_key_exists( $key, self::$cache ) ) {
			if ( self::is_manager( $user_id ) ) {
				$ids = $wpdb->get_col( 'SELECT id FROM ' . Schema::table( 'th_classes' ) . " WHERE status='active' ORDER BY name" ); // phpcs:ignore WordPress.DB.PreparedSQL
			} elseif ( user_can( $user_id, 'ec_teach' ) ) {
				$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT c.id FROM ' . Schema::table( 'th_classes' ) . ' c JOIN ' . Schema::table( 'th_class_staff' ) . " s ON s.class_id=c.id WHERE s.user_id=%d AND c.status='active' ORDER BY c.name", $user_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			} else {
				$ids = array();
			}
			self::$cache[ $key ] = array_map( 'intval', $ids );
			Classes::prime( self::$cache[ $key ] );
		}
		return self::$cache[ $key ];
	}

	public static function teaches_student( int $user_id, int $student_id ): bool {
		global $wpdb;
		if ( ! $user_id || ! $student_id ) {
			return false;
		}
		$key = "ts{$user_id}_{$student_id}";
		if ( ! array_key_exists( $key, self::$cache ) ) {
			$ok = false;
			if ( user_can( $user_id, 'ec_teach' ) ) {
				$ok = (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM ' . Schema::table( 'th_class_members' ) . ' m JOIN ' . Schema::table( 'th_class_staff' ) . " s ON s.class_id=m.class_id WHERE s.user_id=%d AND m.student_id=%d AND m.status='active' LIMIT 1", $user_id, $student_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			}
			if ( ! $ok && user_can( $user_id, 'ec_tutor_sessions' ) ) {
				$ok = (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM ' . Schema::table( 'th_sessions' ) . " WHERE tutor_id=%d AND student_id=%d AND status IN ('confirmed','completed','no_show') LIMIT 1", $user_id, $student_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			}
			self::$cache[ $key ] = $ok;
		}
		return self::$cache[ $key ];
	}

	public static function can_view_student( int $user_id, int $student_id ): bool {
		if ( ! $user_id || ! $student_id ) {
			return false;
		}
		if ( $user_id === $student_id || self::is_manager( $user_id ) || self::teaches_student( $user_id, $student_id ) ) {
			return true;
		}
		return user_can( $user_id, 'ec_view_student', $student_id );
	}

	public static function can_grade_assignment( int $user_id, int $assignment_id ): bool {
		if ( ! $user_id || ! $assignment_id ) {
			return false;
		}
		if ( self::is_manager( $user_id ) ) {
			return true;
		}
		$a = Assignments::get( $assignment_id );
		if ( ! $a ) {
			return false;
		}
		if ( (int) $a['class_id'] && self::class_role( $user_id, (int) $a['class_id'] ) ) {
			return true;
		}
		return (int) $a['course_id'] > 0 && user_can( $user_id, 'ec_grade_course', (int) $a['course_id'] );
	}

	public static function session_tutor( int $session_id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT tutor_id FROM ' . Schema::table( 'th_sessions' ) . ' WHERE id=%d', $session_id ) );
	}

	/** Responsibilities a user holds (drives the role-aware portal navigation). @return string[] */
	public static function responsibilities( int $user_id ): array {
		$out = array();
		if ( user_can( $user_id, 'ec_teach' ) ) {
			$out[] = 'teacher';
		}
		if ( user_can( $user_id, 'ec_edit_assigned_courses' ) || user_can( $user_id, 'ec_manage_all_courses' ) ) {
			$out[] = 'instructor';
		}
		if ( user_can( $user_id, 'ec_tutor_sessions' ) ) {
			$out[] = 'tutor';
		}
		if ( self::is_manager( $user_id ) ) {
			$out[] = 'manager';
		}
		return $out;
	}

	/** Grant/revoke teacher & tutor responsibilities on one account (admin only; audited by caller). */
	public static function set_responsibility( int $user_id, string $what, bool $on ): bool {
		$map  = array( 'teacher' => 'ec_teacher', 'tutor' => 'ec_tutor', 'instructor' => 'ec_instructor' );
		$user = get_userdata( $user_id );
		if ( ! $user || ! isset( $map[ $what ] ) ) {
			return false;
		}
		if ( $on ) {
			$user->add_role( $map[ $what ] );
		} else {
			$user->remove_role( $map[ $what ] );
		}
		self::flush();
		return true;
	}
}
