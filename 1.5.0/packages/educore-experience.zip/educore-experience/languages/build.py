#!/usr/bin/env python3
"""Builds fr_FR and ar .po files for educore-experience from translations.tsv (msgid <TAB> fr <TAB> ar; plural forms
separated by ||), then checks placeholders and reports any string in the .pot without a translation.
Run `wp i18n make-pot` first when strings change.
Usage: python3 languages/build.py && wp i18n make-mo languages && wp i18n make-php languages"""
import os, re, sys
here = os.path.dirname(os.path.abspath(__file__))
pot = open(os.path.join(here, 'educore-experience.pot'), encoding='utf-8').read()
ents = [(a, b) for a, b in re.findall(r'(?:msgctxt "[^"]*"\n)?msgid "((?:[^"\\]|\\.)*)"\n(?:msgid_plural "((?:[^"\\]|\\.)*)"\n)?', pot) if a]
rows = {}
for line in open(os.path.join(here, 'translations.tsv'), encoding='utf-8'):
    if not line.strip():
        continue
    k, fr, ar = line.rstrip('\n').split('\t')
    rows[k] = (fr, ar)
ph = re.compile(r'%(?:\d\$)?s|\{name\}')
errors = []
locales = (('fr_FR', 0, 'nplurals=2; plural=(n > 1);'), ('ar', 1, 'nplurals=6; plural=(n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5);'))
for loc, col, plural in locales:
    out = ['msgid ""', 'msgstr ""', '"Content-Type: text/plain; charset=UTF-8\\n"', '"Language: %s\\n"' % loc, '"Plural-Forms: %s\\n"' % plural, '"X-Domain: educore-experience\\n"', '']
    for i, (msgid, plural_id) in enumerate(ents):
        if msgid not in rows:
            continue
        forms = rows[msgid][col].split('||')
        want = sorted(ph.findall(msgid.replace('\\"', '"')))
        if plural_id:
            n = 2 if loc == 'fr_FR' else 6
            if len(forms) != n:
                errors.append(f'{loc} #{i}: {len(forms)} plural forms, need {n}')
            for k, f in enumerate(forms):
                got = sorted(ph.findall(f))
                want_pl = sorted(ph.findall(plural_id))
                if got not in (want, want_pl) and not (loc == 'ar' and k < 3 and got == []):
                    errors.append(f'{loc} #{i} form {k}: placeholders {got} != {want}')
            out += ['msgid "%s"' % msgid, 'msgid_plural "%s"' % plural_id] + ['msgstr[%d] "%s"' % (k, f.replace('"', '\\"')) for k, f in enumerate(forms)] + ['']
        else:
            got = sorted(ph.findall(forms[0]))
            if got != want:
                errors.append(f'{loc} #{i}: placeholders {got} != {want} ({msgid[:40]})')
            out += ['msgid "%s"' % msgid, 'msgstr "%s"' % forms[0].replace('"', '\\"'), '']
    open(os.path.join(here, f'educore-experience-{loc}.po'), 'w', encoding='utf-8').write('\n'.join(out))
SKIP = {'EduCore Experience', 'https://educore.gorgy.org', 'GORGY.ORG'}
missing = [m for m, _ in ents if m not in rows and m not in SKIP and not m.startswith('The EduCore Personal Experience Engine') and not m.startswith('EduCore Experience needs')]
if missing:
    errors.append(f'untranslated indexes: {missing}')
if errors:
    print('\n'.join(errors)); sys.exit(1)
print(f'{len(rows)} strings x 2 locales, placeholders OK')
