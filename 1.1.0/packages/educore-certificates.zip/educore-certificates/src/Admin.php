<?php
namespace EduCore\Certificates;

use EduCore\Core\Content;
use EduCore\Core\I18n;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

final class Admin {

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 20 );
		add_action( 'admin_init', array( self::class, 'handle' ) );
		add_action( 'add_meta_boxes', array( self::class, 'meta_boxes' ) );
		add_action( 'save_post_' . Plugin::TEMPLATE, array( self::class, 'save_template' ) );
		add_action( 'educore/admin/save_content_meta', array( self::class, 'save_course' ), 10, 2 );
		add_filter( 'educore/admin/overview_tiles', array( self::class, 'tiles' ) );
	}

	public static function menu(): void {
		add_submenu_page( 'educore', __( 'Certificates', 'educore-certificates' ), __( 'Certificates', 'educore-certificates' ), 'ec_manage_certificates', 'educore-certificates', array( self::class, 'page' ) );
	}

	public static function tiles( array $tiles ): array {
		global $wpdb;
		$tiles[ __( 'Certificates issued', 'educore-certificates' ) ] = number_format_i18n( (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Schema::table( 'certificates' ) . ' WHERE revoked_at IS NULL' ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		return $tiles;
	}

	private static function form( string $action ): string {
		return '<form method="post" style="display:inline">' . wp_nonce_field( 'educore_cert_' . $action, '_ecnonce', true, false ) . '<input type="hidden" name="educore_cert_action" value="' . esc_attr( $action ) . '">';
	}

	public static function page(): void {
		global $wpdb;
		if ( ! current_user_can( 'ec_manage_certificates' ) ) {
			wp_die( '', 403 );
		}
		echo '<div class="wrap ec-admin"><h1>' . esc_html__( 'Certificates', 'educore-certificates' ) . '</h1>';
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ec_err'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['ec_err'] ) ) ) . '</p></div>';
		} elseif ( isset( $_GET['ec_done'] ) ) {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Done.', 'educore-certificates' ) . '</p></div>';
		}
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable
		echo '<h2>' . esc_html__( 'Issue manually', 'educore-certificates' ) . '</h2>' . self::form( 'issue' ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<input type="email" name="email" required placeholder="' . esc_attr__( 'Learner e-mail', 'educore-certificates' ) . '"> <select name="course_id" required><option value="">' . esc_html__( 'Course', 'educore-certificates' ) . '</option>';
		foreach ( get_posts( array( 'post_type' => Content::COURSE, 'post_status' => 'publish', 'posts_per_page' => 500 ) ) as $c ) {
			echo '<option value="' . esc_attr( (string) $c->ID ) . '">' . esc_html( $c->post_title ) . '</option>';
		}
		echo '</select> <button class="button button-primary">' . esc_html__( 'Issue', 'educore-certificates' ) . '</button></form>';
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'certificates' ) . ' ORDER BY id DESC LIMIT 50 OFFSET %d', ( $paged - 1 ) * 50 ), ARRAY_A );
		echo '<h2>' . esc_html__( 'Issued certificates', 'educore-certificates' ) . '</h2><table class="widefat striped"><thead><tr><th>' . esc_html__( 'ID', 'educore-certificates' ) . '</th><th>' . esc_html__( 'Learner', 'educore-certificates' ) . '</th><th>' . esc_html__( 'Course', 'educore-certificates' ) . '</th><th>' . esc_html__( 'Issued (UTC)', 'educore-certificates' ) . '</th><th>' . esc_html__( 'Status', 'educore-certificates' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><td><code>' . esc_html( $r['uid'] ) . '</code></td><td>' . esc_html( $r['student_name'] ) . '</td><td>' . esc_html( $r['course_title'] ) . '</td><td>' . esc_html( $r['issued_at'] ) . '</td><td>' . esc_html( $r['revoked_at'] ? __( 'Revoked', 'educore-certificates' ) . ': ' . $r['revoke_reason'] : __( 'Valid', 'educore-certificates' ) ) . '</td><td>';
			echo '<a class="button button-small" href="' . esc_url( Download::url( $r['uid'] ) ) . '">PDF</a> <a class="button button-small" href="' . esc_url( Verify::url( $r['uid'] ) ) . '">' . esc_html__( 'Verify page', 'educore-certificates' ) . '</a> ';
			if ( $r['revoked_at'] ) {
				echo self::form( 'reinstate' ) . '<input type="hidden" name="id" value="' . esc_attr( $r['id'] ) . '"><button class="button button-small">' . esc_html__( 'Reinstate', 'educore-certificates' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
			} else {
				echo self::form( 'revoke' ) . '<input type="hidden" name="id" value="' . esc_attr( $r['id'] ) . '"><input name="reason" required minlength="3" placeholder="' . esc_attr__( 'Reason', 'educore-certificates' ) . '"> <button class="button button-small">' . esc_html__( 'Revoke', 'educore-certificates' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo ' ' . self::form( 'regenerate' ) . '<input type="hidden" name="id" value="' . esc_attr( $r['id'] ) . '"><button class="button button-small">' . esc_html__( 'Regenerate PDF', 'educore-certificates' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</td></tr>';
		}
		echo '</tbody></table><p><a class="button" href="' . esc_url( add_query_arg( 'paged', $paged + 1 ) ) . '">' . esc_html__( 'Older', 'educore-certificates' ) . '</a> <a class="button" href="' . esc_url( admin_url( 'edit.php?post_type=' . Plugin::TEMPLATE ) ) . '">' . esc_html__( 'Manage templates', 'educore-certificates' ) . '</a></p></div>';
	}

	public static function handle(): void {
		if ( empty( $_POST['educore_cert_action'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['educore_cert_action'] ) );
		check_admin_referer( 'educore_cert_' . $action, '_ecnonce' );
		if ( ! current_user_can( 'ec_manage_certificates' ) ) {
			wp_die( '', 403 );
		}
		$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$err = '';
		switch ( $action ) {
			case 'issue':
				$u   = get_user_by( 'email', isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '' );
				$res = $u ? Certificates::issue( (int) $u->ID, isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0 ) : new \WP_Error( 'x', __( 'No account uses this e-mail address.', 'educore-certificates' ) );
				$err = is_wp_error( $res ) ? $res->get_error_message() : '';
				break;
			case 'revoke':
				$err = Certificates::revoke( $id, isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : '' ) ? '' : __( 'A reason is required.', 'educore-certificates' );
				break;
			case 'reinstate':
				Certificates::reinstate( $id );
				break;
			case 'regenerate':
				try {
					Pdf::generate( $id );
				} catch ( \Throwable $e ) {
					$err = __( 'PDF generation failed. Check the server error log.', 'educore-certificates' );
				}
				break;
		}
		$ref = remove_query_arg( array( 'ec_err', 'ec_done' ), wp_get_referer() ?: admin_url( 'admin.php?page=educore-certificates' ) );
		wp_safe_redirect( $err ? add_query_arg( 'ec_err', rawurlencode( $err ), $ref ) : add_query_arg( 'ec_done', 1, $ref ) );
		exit;
	}

	public static function meta_boxes(): void {
		add_meta_box( 'ec_cert_template', __( 'Certificate design', 'educore-certificates' ), array( self::class, 'template_box' ), Plugin::TEMPLATE, 'normal' );
		add_meta_box( 'ec_course_cert', __( 'Certificate', 'educore-certificates' ), array( self::class, 'course_box' ), Content::COURSE, 'side' );
	}

	public static function template_box( \WP_Post $post ): void {
		wp_nonce_field( 'educore_cert_tpl_' . $post->ID, '_ec_cert_nonce' );
		$t = Templates::get( $post->ID );
		echo '<p><label><strong>' . esc_html__( 'Heading', 'educore-certificates' ) . '</strong><br><input class="widefat" name="_ec_cert_heading" value="' . esc_attr( $t['heading'] ) . '"></label></p>';
		echo '<p><label><strong>' . esc_html__( 'Body (one line per row)', 'educore-certificates' ) . '</strong><br><textarea class="widefat" rows="6" name="_ec_cert_body">' . esc_textarea( $t['body'] ) . '</textarea></label><br><span class="description">' . esc_html__( 'Placeholders:', 'educore-certificates' ) . ' <code>' . esc_html( implode( ' ', Templates::PLACEHOLDERS ) ) . '</code></span></p>';
		echo '<p><label>' . esc_html__( 'Language / direction', 'educore-certificates' ) . ' <select name="_ec_cert_lang">';
		foreach ( I18n::labels() as $c => $l ) {
			echo '<option value="' . esc_attr( $c ) . '"' . selected( $t['lang'], $c, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></label> <label>' . esc_html__( 'Orientation', 'educore-certificates' ) . ' <select name="_ec_cert_orientation"><option value="L"' . selected( $t['orientation'], 'L', false ) . '>' . esc_html__( 'Landscape', 'educore-certificates' ) . '</option><option value="P"' . selected( $t['orientation'], 'P', false ) . '>' . esc_html__( 'Portrait', 'educore-certificates' ) . '</option></select></label> <label>' . esc_html__( 'Accent colour', 'educore-certificates' ) . ' <input type="color" name="_ec_cert_accent" value="' . esc_attr( $t['accent'] ) . '"></label></p>';
		echo '<p><label>' . esc_html__( 'Signature name', 'educore-certificates' ) . ' <input name="_ec_cert_sig_name" value="' . esc_attr( $t['sig_name'] ) . '"></label> <label>' . esc_html__( 'Signature title', 'educore-certificates' ) . ' <input name="_ec_cert_sig_title" value="' . esc_attr( $t['sig_title'] ) . '"></label></p>';
	}

	public static function save_template( int $post_id ): void {
		if ( ! isset( $_POST['_ec_cert_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_ec_cert_nonce'] ) ), 'educore_cert_tpl_' . $post_id ) || ! current_user_can( 'ec_manage_certificates' ) ) {
			return;
		}
		$map = array( '_ec_cert_heading' => 'sanitize_text_field', '_ec_cert_body' => 'sanitize_textarea_field', '_ec_cert_lang' => array( I18n::class, 'sanitize_lang' ), '_ec_cert_orientation' => static fn( $v ) => 'P' === $v ? 'P' : 'L', '_ec_cert_accent' => 'sanitize_hex_color', '_ec_cert_sig_name' => 'sanitize_text_field', '_ec_cert_sig_title' => 'sanitize_text_field' );
		foreach ( $map as $k => $fn ) {
			if ( isset( $_POST[ $k ] ) ) {
				update_post_meta( $post_id, $k, call_user_func( $fn, wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			}
		}
	}

	public static function course_box( \WP_Post $post ): void {
		if ( ! current_user_can( 'ec_manage_certificates' ) ) {
			echo '<p class="description">' . esc_html__( 'Managed by certificate administrators.', 'educore-certificates' ) . '</p>';
			return;
		}
		$cur = (int) get_post_meta( $post->ID, '_ec_cert_template', true );
		echo '<p><label><input type="checkbox" name="_ec_cert_enabled" value="1"' . checked( 'no' !== get_post_meta( $post->ID, '_ec_cert_enabled', true ), true, false ) . '> ' . esc_html__( 'Issue a certificate on completion', 'educore-certificates' ) . '</label></p><input type="hidden" name="_ec_cert_box" value="1">';
		echo '<p><select name="_ec_cert_template" class="widefat"><option value="0">' . esc_html__( 'Default (learner language)', 'educore-certificates' ) . '</option>';
		foreach ( get_posts( array( 'post_type' => Plugin::TEMPLATE, 'post_status' => 'publish', 'posts_per_page' => 100 ) ) as $t ) {
			echo '<option value="' . esc_attr( (string) $t->ID ) . '"' . selected( $cur, $t->ID, false ) . '>' . esc_html( $t->post_title ) . '</option>';
		}
		echo '</select></p>';
	}

	/** Runs inside core's nonce/capability-checked meta save. */
	public static function save_course( int $post_id, \WP_Post $post ): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified by core MetaBoxes::save.
		if ( Content::COURSE !== $post->post_type || empty( $_POST['_ec_cert_box'] ) || ! current_user_can( 'ec_manage_certificates' ) ) {
			return;
		}
		update_post_meta( $post_id, '_ec_cert_enabled', empty( $_POST['_ec_cert_enabled'] ) ? 'no' : 'yes' );
		update_post_meta( $post_id, '_ec_cert_template', isset( $_POST['_ec_cert_template'] ) ? absint( $_POST['_ec_cert_template'] ) : 0 );
		// phpcs:enable
	}
}
