<?php
namespace EduCore\Experience;

use EduCore\Core\Access;
use EduCore\Core\Content;
use EduCore\Core\Progress;

defined( 'ABSPATH' ) || exit;

/**
 * Explained learning suggestions. Every suggestion carries the reason it was made, and is derived from
 * real records: the lesson the learner last opened, the next lesson of each course, assessments that are
 * about to close, results that were released, and the learner's own weekly goal.
 *
 * Teachers can add or reorder suggestions for their learners through the `educore/experience/recommendations`
 * filter (for example from a pinned-lesson feature); EduCore does not invent suggestions on their behalf.
 *
 * Each item: array{kind:string,title:string,context:string,reason:string,url:string}
 */
final class Recommend {
	public const MAX = 4;

	public static function for_student( int $uid ): array {
		$items = array();
		$seen  = array();
		$push  = static function ( array $it ) use ( &$items, &$seen ) {
			$k = strtok( $it['url'], '#' );
			if ( '' === $it['url'] || isset( $seen[ $k ] ) ) {
				return;
			}
			$seen[ $k ] = true;
			$items[]    = $it;
		};

		// 1. Pick up where you left off: last opened lesson that is not complete and still accessible.
		$last = Resume::last( $uid );
		if ( $last && ! Progress::is_complete( $uid, $last['lesson'] ) && Access::can_view_lesson( $uid, $last['lesson'] ) ) {
			$pos  = Resume::position( $uid, $last['lesson'] );
			$push(
				array(
					'kind'    => 'resume',
					'title'   => get_the_title( $last['lesson'] ),
					'context' => get_the_title( $last['course'] ),
					'reason'  => $pos >= 0.05
						/* translators: 1: date, 2: percentage read */
						? sprintf( __( 'You opened this on %1$s and read about %2$s of it.', 'educore-experience' ), Clock::format( $last['at'], Clock::tz_for( $uid ) ), number_format_i18n( (int) round( $pos * 100 ) ) . '%' )
						/* translators: %s: date */
						: sprintf( __( 'You opened this on %s and haven’t finished it yet.', 'educore-experience' ), Clock::format( $last['at'], Clock::tz_for( $uid ) ) ),
					'url'     => add_query_arg( 'ec_resume', '1', (string) get_permalink( $last['lesson'] ) ),
				)
			);
		}

		// 2. Assessments closing within 7 days that the learner can still start.
		if ( class_exists( '\EduCore\Workspace\Agenda' ) ) {
			foreach ( Facts::agenda( $uid ) as $it ) {
				if ( 'assessment' !== $it['kind'] || $it['ts'] > time() + 7 * DAY_IN_SECONDS ) {
					continue;
				}
				$days = max( 0, (int) ceil( ( $it['ts'] - time() ) / DAY_IN_SECONDS ) );
				$push(
					array(
						'kind'    => 'assessment',
						'title'   => $it['title'],
						'context' => $it['meta'],
						'reason'  => 0 === $days
							? __( 'Closes today. Prepare and take it while it is open.', 'educore-experience' )
							/* translators: %s: number of days */
							: sprintf( _n( 'Closes in %s day. Prepare and take it while it is open.', 'Closes in %s days. Prepare and take it while it is open.', $days, 'educore-experience' ), number_format_i18n( $days ) ),
						'url'     => $it['url'],
					)
				);
			}
		}

		$d = Facts::dashboard( $uid );

		// 3. Released results: revisit the teacher's feedback.
		foreach ( array_slice( (array) ( $d['results'] ?? array() ), 0, 2 ) as $r ) {
			if ( empty( $r['url'] ) ) {
				continue;
			}
			$push( array( 'kind' => 'feedback', 'title' => (string) $r['title'], 'context' => (string) ( $r['meta'] ?? '' ), 'reason' => __( 'A result was released. Reading the feedback helps with the next step.', 'educore-experience' ), 'url' => (string) $r['url'] ) );
		}

		// 4. Next lesson of each course in order.
		foreach ( (array) ( $d['recommended'] ?? array() ) as $n ) {
			/* translators: %s: course title */
			$push( array( 'kind' => 'next', 'title' => (string) $n['title'], 'context' => (string) $n['course'], 'reason' => sprintf( __( 'The next lesson in %s.', 'educore-experience' ), (string) $n['course'] ), 'url' => (string) $n['url'] ) );
		}

		$items = (array) apply_filters( 'educore/experience/recommendations', $items, $uid );
		return array_slice( $items, 0, self::MAX );
	}

	/** Lessons left to reach the weekly goal, or null when goals are paused. */
	public static function goal_gap( int $uid ): ?int {
		$p = Prefs::get( $uid );
		if ( $p['goals_paused'] ) {
			return null;
		}
		$g = Facts::dashboard( $uid )['goal'] ?? null;
		return $g ? max( 0, (int) $g['target'] - (int) $g['done'] ) : null;
	}

	/** Practice questions answered this week (Monday 00:00 in the learner's zone), or null when unavailable. */
	public static function practice_done( int $uid ): ?int {
		global $wpdb;
		if ( ! class_exists( '\EduCore\Assessments\Schema' ) ) {
			return null;
		}
		$tz     = new \DateTimeZone( Clock::tz_for( $uid ) );
		$monday = ( new \DateTimeImmutable( 'monday this week', $tz ) )->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . \EduCore\Assessments\Schema::t( 'practice_tries' ) . ' WHERE user_id=%d AND updated_at >= %s', $uid, $monday ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function course_of_lesson( int $lesson_id ): int {
		return (int) Content::course_of( $lesson_id );
	}
}
