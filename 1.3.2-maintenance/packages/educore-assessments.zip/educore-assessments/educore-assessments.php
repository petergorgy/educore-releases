<?php
/**
 * Plugin Name:       EduCore Assessments
 * Plugin URI:        https://educore.gorgy.org
 * Description:       Question banks, quizzes and examinations, server-side attempts, automatic and rubric grading, practice and results for EduCore.
 * Version:           1.3.2
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core
 * EduCore Requires Core: 1.1.0
 * Author:            GORGY.ORG
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-assessments
 * Domain Path:       /languages
 *
 * @package EduCore\Assessments
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'EDUCORE_ASSESSMENTS_VERSION' ) ) {
	return;
}

define( 'EDUCORE_ASSESSMENTS_VERSION', '1.3.2' );
define( 'EDUCORE_ASSESSMENTS_DB_VERSION', 3 );
define( 'EDUCORE_ASSESSMENTS_FILE', __FILE__ );
define( 'EDUCORE_ASSESSMENTS_DIR', plugin_dir_path( __FILE__ ) );
define( 'EDUCORE_ASSESSMENTS_URL', plugin_dir_url( __FILE__ ) );

add_filter(
	'cron_schedules',
	static function ( $s ) {
		$s['educore_five_minutes'] = array( 'interval' => 300, 'display' => 'Every 5 minutes (EduCore)' );
		return $s;
	}
);

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Assessments', '1.0.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Assessments\\', EDUCORE_ASSESSMENTS_DIR . 'src/' );
		\EduCore\Assessments\Plugin::boot();
	}
);

add_action(
	'plugins_loaded',
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) ) {
			add_action(
				'admin_notices',
				static function () {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'EduCore Assessments requires the EduCore Core plugin. It has not been loaded.', 'educore-assessments' ) . '</p></div>';
				}
			);
		}
	},
	20
);

register_activation_hook(
	__FILE__,
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die( esc_html__( 'Please activate EduCore Core first.', 'educore-assessments' ), '', array( 'back_link' => true ) );
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Assessments\\', EDUCORE_ASSESSMENTS_DIR . 'src/' );
		\EduCore\Assessments\Schema::install();
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		wp_clear_scheduled_hook( 'educore_assessments_expire' );
	}
);
