<?php
namespace EduCore\Assessments;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Schema as CoreSchema;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/**
 * Question bank repository. Versions are immutable once used by an attempt: an edit then creates
 * a new version, so past attempts keep the exact question (and key) the learner saw.
 */
final class Questions {
	public const STATUSES   = array( 'draft', 'review', 'published', 'archived' );
	public const USAGES     = array( 'any', 'practice', 'assessment' );
	public const DIFFICULTY = array( 'easy', 'medium', 'hard' );

	public static function default_bank( int $course_id ): int {
		global $wpdb;
		$t  = Schema::t( 'question_banks' );
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE course_id=%d ORDER BY id LIMIT 1", $course_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( ! $id ) {
			$wpdb->insert( $t, array( 'course_id' => $course_id, 'title' => get_the_title( $course_id ), 'owner_id' => get_current_user_id(), 'created_at' => CoreSchema::now() ) );
			$id = (int) $wpdb->insert_id;
		}
		return $id;
	}

	public static function dedupe_hash( string $type, string $stem, array $payload ): string {
		$opts = '';
		foreach ( array( 'options', 'left', 'right', 'items' ) as $k ) {
			if ( ! empty( $payload[ $k ] ) ) {
				$opts .= '|' . implode( '|', array_map( static fn( $o ) => Types::norm( (string) $o['text'] ), $payload[ $k ] ) );
			}
		}
		if ( ! empty( $payload['code'] ) ) {
			$opts .= '|' . md5( (string) $payload['code'] );
		}
		return hash( 'sha256', $type . '|' . Types::norm( $stem ) . $opts );
	}

	/** Normalised stable identifier used to match questions across imports/exports (max 64 chars). */
	public static function external_id( string $id ): string {
		return mb_substr( trim( (string) preg_replace( '/[^\p{L}\p{N}._:\-]+/u', '-', $id ), '-' ), 0, 64 );
	}

	public static function by_external_id( int $course_id, string $external_id ): int {
		global $wpdb;
		if ( '' === $external_id ) {
			return 0;
		}
		$t = Schema::t( 'questions' );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE course_id=%d AND external_id=%s AND status<>'archived' ORDER BY id LIMIT 1", $course_id, $external_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** @return int[] ids of other questions in the same course with the same content hash */
	public static function duplicates( int $course_id, string $hash, int $exclude = 0 ): array {
		global $wpdb;
		$t = Schema::t( 'questions' );
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t} WHERE course_id=%d AND dedupe_hash=%s AND id<>%d AND status<>'archived'", $course_id, $hash, $exclude ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/**
	 * Create or update a question. $data: course_id, lesson_id, type, stem, payload, key, explanation,
	 * points, difficulty, usage, lang, tags (array|string), status.
	 *
	 * @return int|\WP_Error question id
	 */
	public static function save( array $data, int $question_id = 0 ) {
		global $wpdb;
		$type = (string) ( $data['type'] ?? '' );
		if ( ! in_array( $type, Types::ALL, true ) ) {
			return new \WP_Error( 'educore_invalid_question', __( 'Unknown question type.', 'educore-assessments' ), array( 'status' => 400 ) );
		}
		$stem = wp_kses_post( (string) ( $data['stem'] ?? '' ) );
		if ( '' === trim( wp_strip_all_tags( $stem ) ) && 'image' !== $type ) {
			return new \WP_Error( 'educore_invalid_question', __( 'The question text is required.', 'educore-assessments' ), array( 'status' => 400 ) );
		}
		$existing = $question_id ? self::get( $question_id ) : null;
		if ( $question_id && ! $existing ) {
			return new \WP_Error( 'educore_not_found', __( 'Question not found.', 'educore-assessments' ), array( 'status' => 404 ) );
		}
		$course_id = $existing ? (int) $existing['course_id'] : absint( $data['course_id'] ?? 0 );
		if ( ! Content::is_course( $course_id ) ) {
			return new \WP_Error( 'educore_invalid_question', __( 'Choose a valid course.', 'educore-assessments' ), array( 'status' => 400 ) );
		}
		$lesson_id = absint( $data['lesson_id'] ?? ( $existing['lesson_id'] ?? 0 ) );
		if ( $lesson_id && Content::course_of( $lesson_id ) !== $course_id ) {
			return new \WP_Error( 'educore_invalid_question', __( 'The lesson does not belong to this course.', 'educore-assessments' ), array( 'status' => 400 ) );
		}
		$payload = (array) ( $data['payload'] ?? array() );
		$key     = (array) ( $data['key'] ?? array() );
		$now     = CoreSchema::now();
		$status  = in_array( $data['status'] ?? '', self::STATUSES, true ) ? $data['status'] : ( $existing['status'] ?? 'draft' );
		$row     = array(
			'lesson_id'   => $lesson_id,
			'type'        => $type,
			'status'      => $status,
			'usage_scope' => in_array( $data['usage'] ?? '', self::USAGES, true ) ? $data['usage'] : ( $existing['usage_scope'] ?? 'any' ),
			'difficulty'  => in_array( $data['difficulty'] ?? '', self::DIFFICULTY, true ) ? $data['difficulty'] : ( $existing['difficulty'] ?? 'medium' ),
			'dedupe_hash' => self::dedupe_hash( $type, $stem, $payload ),
			'updated_at'  => $now,
		);
		if ( array_key_exists( 'external_id', $data ) ) {
			$row['external_id'] = self::external_id( (string) $data['external_id'] );
		}
		$version = array(
			'lang'        => \EduCore\Core\I18n::sanitize_lang( $data['lang'] ?? 'en' ),
			'stem'        => $stem,
			'payload'     => wp_json_encode( $payload ),
			'answer_key'  => wp_json_encode( $key ),
			'explanation' => wp_kses_post( (string) ( $data['explanation'] ?? '' ) ),
			'points'      => max( 0, (float) ( $data['points'] ?? 1 ) ),
		);
		$qt = Schema::t( 'questions' );
		$vt = Schema::t( 'question_versions' );
		if ( ! $existing ) {
			$wpdb->insert( $qt, array_merge( $row, array( 'bank_id' => self::default_bank( $course_id ), 'course_id' => $course_id, 'created_by' => get_current_user_id(), 'created_at' => $now ) ) );
			$question_id = (int) $wpdb->insert_id;
			$wpdb->insert( $vt, array_merge( $version, array( 'question_id' => $question_id, 'version_no' => 1, 'created_by' => get_current_user_id(), 'created_at' => $now ) ) );
			$row['current_version_id'] = (int) $wpdb->insert_id;
			Audit::log( 'question.created', 'question', $question_id, array( 'course_id' => $course_id ) );
		} else {
			$cur = self::version( (int) $existing['current_version_id'] );
			if ( $cur && ! $cur['used'] && $existing['type'] === $type ) {
				$wpdb->update( $vt, $version, array( 'id' => (int) $cur['id'] ) );
				$row['current_version_id'] = (int) $cur['id'];
			} else {
				$next = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(version_no) FROM {$vt} WHERE question_id=%d", $question_id ) ) + 1; // phpcs:ignore WordPress.DB.PreparedSQL
				$wpdb->insert( $vt, array_merge( $version, array( 'question_id' => $question_id, 'version_no' => $next, 'created_by' => get_current_user_id(), 'created_at' => $now ) ) );
				$row['current_version_id'] = (int) $wpdb->insert_id;
			}
			Audit::log( 'question.updated', 'question', $question_id, array( 'version_id' => $row['current_version_id'] ) );
		}
		$wpdb->update( $qt, $row, array( 'id' => $question_id ) );
		if ( array_key_exists( 'tags', $data ) ) {
			self::set_tags( $question_id, $data['tags'] );
		}
		return $question_id;
	}

	public static function set_tags( int $question_id, $tags ): void {
		global $wpdb;
		$t    = Schema::t( 'question_tags' );
		$list = is_array( $tags ) ? $tags : explode( ',', (string) $tags );
		$wpdb->delete( $t, array( 'question_id' => $question_id ) );
		foreach ( array_unique( array_filter( array_map( static fn( $x ) => substr( sanitize_title( $x ), 0, 60 ), $list ) ) ) as $tag ) {
			$wpdb->insert( $t, array( 'question_id' => $question_id, 'tag' => $tag ) );
		}
	}

	public static function tags( int $question_id ): array {
		global $wpdb;
		return $wpdb->get_col( $wpdb->prepare( 'SELECT tag FROM ' . Schema::t( 'question_tags' ) . ' WHERE question_id=%d ORDER BY tag', $question_id ) );
	}

	public static function get( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::t( 'questions' ) . ' WHERE id=%d', $id ), ARRAY_A );
		return $row ?: null;
	}

	public static function version( int $version_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::t( 'question_versions' ) . ' WHERE id=%d', $version_id ), ARRAY_A );
		if ( ! $row ) {
			return null;
		}
		$row['payload']    = (array) json_decode( (string) $row['payload'], true );
		$row['answer_key'] = (array) json_decode( (string) $row['answer_key'], true );
		$row['used']       = (int) $row['used'];
		return $row;
	}

	/** Full question incl. current version (staff use only — contains the key). */
	public static function full( int $id ): ?array {
		$q = self::get( $id );
		if ( ! $q ) {
			return null;
		}
		$v = self::version( (int) $q['current_version_id'] );
		return array_merge( $q, array( 'version' => $v, 'tags' => self::tags( $id ) ) );
	}

	/** @return array<int,array<string,mixed>> history of versions (newest first) */
	public static function history( int $id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT id, version_no, lang, used, created_by, created_at FROM ' . Schema::t( 'question_versions' ) . ' WHERE question_id=%d ORDER BY version_no DESC', $id ), ARRAY_A ) ?: array();
	}

	public static function set_status( int $id, string $status ) {
		global $wpdb;
		$q = self::get( $id );
		if ( ! $q || ! in_array( $status, self::STATUSES, true ) ) {
			return new \WP_Error( 'educore_invalid', __( 'Invalid question or status.', 'educore-assessments' ), array( 'status' => 400 ) );
		}
		if ( 'published' === $status && ! self::can_publish( get_current_user_id(), (int) $q['course_id'] ) ) {
			return new \WP_Error( 'educore_forbidden', __( 'Only a lead instructor or academic manager can publish questions.', 'educore-assessments' ), array( 'status' => 403 ) );
		}
		$wpdb->update( Schema::t( 'questions' ), array( 'status' => $status, 'updated_at' => CoreSchema::now() ), array( 'id' => $id ) );
		Audit::log( 'question.' . $status, 'question', $id );
		return true;
	}

	public static function can_publish( int $user_id, int $course_id ): bool {
		return user_can( $user_id, 'ec_manage_all_courses' ) || user_can( $user_id, 'ec_publish_courses' ) || Staff::has_role( $user_id, $course_id, array( 'lead' ) );
	}

	/**
	 * @return array{rows:array<int,array<string,mixed>>,total:int}
	 */
	public static function search( array $f ): array {
		global $wpdb;
		$q      = Schema::t( 'questions' );
		$v      = Schema::t( 'question_versions' );
		$where  = array( '1=1' );
		$params = array();
		if ( isset( $f['course_ids'] ) ) {
			$ids = array_map( 'intval', (array) $f['course_ids'] ) ?: array( 0 );
			$where[] = 'q.course_id IN (' . implode( ',', $ids ) . ')';
		}
		foreach ( array( 'course_id' => 'q.course_id', 'lesson_id' => 'q.lesson_id' ) as $k => $col ) {
			if ( ! empty( $f[ $k ] ) ) {
				$where[]  = "$col = %d";
				$params[] = (int) $f[ $k ];
			}
		}
		foreach ( array( 'type' => 'q.type', 'status' => 'q.status', 'difficulty' => 'q.difficulty' ) as $k => $col ) {
			if ( ! empty( $f[ $k ] ) ) {
				$where[]  = "$col = %s";
				$params[] = (string) $f[ $k ];
			}
		}
		if ( ! empty( $f['search'] ) ) {
			$where[]  = 'v.stem LIKE %s';
			$params[] = '%' . $wpdb->esc_like( (string) $f['search'] ) . '%';
		}
		$limit  = min( 200, max( 1, (int) ( $f['per_page'] ?? 50 ) ) );
		$offset = max( 0, ( (int) ( $f['page'] ?? 1 ) - 1 ) * $limit );
		$base   = "FROM {$q} q JOIN {$v} v ON v.id = q.current_version_id WHERE " . implode( ' AND ', $where );
		$total  = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) $base", $params ) ) : $wpdb->get_var( "SELECT COUNT(*) $base" ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$sql    = "SELECT q.*, v.stem, v.points, v.lang, v.version_no $base ORDER BY q.id DESC LIMIT %d OFFSET %d";
		$rows   = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $params, array( $limit, $offset ) ) ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		return array( 'rows' => $rows, 'total' => $total );
	}

	/** Blueprint coverage per lesson: published questions per family vs target (50/50/50). */
	public static function coverage( int $course_id ): array {
		global $wpdb;
		$target = (array) apply_filters( 'educore/assessments/blueprint', array( 'mcq' => 50, 'truefalse' => 50, 'essay' => 50 ) );
		$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT lesson_id, type, COUNT(*) n FROM ' . Schema::t( 'questions' ) . " WHERE course_id=%d AND status='published' GROUP BY lesson_id, type", $course_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$counts = array();
		foreach ( $rows as $r ) {
			$fam = Types::family( $r['type'] );
			if ( 'other' === $fam ) {
				continue;
			}
			$counts[ (int) $r['lesson_id'] ][ $fam ] = ( $counts[ (int) $r['lesson_id'] ][ $fam ] ?? 0 ) + (int) $r['n'];
		}
		$out = array();
		foreach ( Content::outline( $course_id, array( 'publish', 'draft', 'pending', 'future' ) ) as $row ) {
			foreach ( $row['lessons'] as $l ) {
				$line = array( 'lesson_id' => $l->ID, 'title' => $l->post_title );
				foreach ( $target as $fam => $t ) {
					$line[ $fam ] = array( 'have' => $counts[ $l->ID ][ $fam ] ?? 0, 'target' => (int) $t );
				}
				$out[] = $line;
			}
		}
		return $out;
	}
}
