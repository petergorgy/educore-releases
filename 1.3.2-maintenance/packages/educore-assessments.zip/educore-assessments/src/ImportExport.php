<?php
namespace EduCore\Assessments;

use EduCore\Core\Audit;

defined( 'ABSPATH' ) || exit;

/**
 * Bulk question import/export.
 *
 * CSV (UTF-8, header row required) columns:
 *   type, lesson_id, difficulty, points, usage, lang, tags, status, stem, options, correct,
 *   explanation, model_answer, code, language, image_id, scoring
 * "scoring" (optional, multiple/ordering only): all_or_nothing (default) | partial.
 * Multi-line cells (options, correct) use line breaks inside a quoted cell — see Types::from_authoring()
 * for the meaning of "options" and "correct" per type. Imported questions default to "draft";
 * "published" is only kept when the importer may publish, otherwise it becomes "review".
 *
 * JSON: array of objects { type, lesson_id, difficulty, points, usage, lang, tags[], status, stem,
 *   payload{}, key{}, explanation } — the exact internal structure (lossless round-trip).
 */
final class ImportExport {
	public const CSV_COLUMNS = array( 'type', 'lesson_id', 'difficulty', 'points', 'usage', 'lang', 'tags', 'status', 'stem', 'options', 'correct', 'explanation', 'model_answer', 'code', 'language', 'image_id', 'scoring' );

	/**
	 * Legacy one-step import (REST + quick form). Since 1.3.1 every row goes through the same validator as the
	 * Import & Export Center (key structure, safe HTML, publish rights, lesson ownership).
	 *
	 * @return array{imported:int,duplicates:int,errors:array<int,string>}
	 */
	public static function import_rows( int $course_id, array $rows, bool $structured ): array {
		$res = array( 'imported' => 0, 'duplicates' => 0, 'errors' => array() );
		foreach ( array_slice( $rows, 0, 2000 ) as $n => $row ) {
			$line = $n + ( $structured ? 1 : 2 );
			if ( ! is_array( $row ) ) {
				$res['errors'][ $line ] = sprintf( 'Row %d: %s', $line, __( 'Not a question object.', 'educore-assessments' ) );
				continue;
			}
			if ( $structured ) {
				$key = (array) ( $row['key'] ?? array() );
				if ( 'partial' === ( $row['scoring'] ?? '' ) ) {
					$key['scoring'] = 'partial';
				}
				$rec = array_merge( $row, array( 'key' => $key ) );
			} else {
				$t = Exchange\Tabular::row_to_record( $row );
				if ( null !== $t['error'] || null === $t['record'] ) {
					if ( null !== $t['error'] ) {
						$res['errors'][ $line ] = sprintf( 'Row %d: %s', $line, $t['error'] );
					}
					continue;
				}
				$rec = $t['record'];
			}
			$v = Exchange\Validator::check( $rec, $course_id );
			if ( $v['errors'] ) {
				$res['errors'][ $line ] = sprintf( 'Row %d: %s', $line, implode( ' ', $v['errors'] ) );
				continue;
			}
			$r = $v['record'];
			if ( Questions::duplicates( $course_id, Exchange\Record::dedupe_hash( $r ) ) ) {
				++$res['duplicates'];
				continue;
			}
			$id = Questions::save(
				array(
					'course_id'   => $course_id,
					'lesson_id'   => $r['lesson_id'],
					'type'        => $r['type'],
					'stem'        => $r['stem'],
					'payload'     => $r['payload'],
					'key'         => $r['key'],
					'explanation' => $r['explanation'],
					'points'      => $r['points'],
					'difficulty'  => $r['difficulty'],
					'usage'       => $r['usage'],
					'lang'        => $r['lang'],
					'tags'        => $r['tags'],
					'status'      => $r['status'],
				)
			);
			if ( is_wp_error( $id ) ) {
				$res['errors'][ $line ] = sprintf( 'Row %d: %s', $line, $id->get_error_message() );
			} else {
				++$res['imported'];
			}
		}
		Audit::log( 'questions.imported', 'course', $course_id, array( 'imported' => $res['imported'], 'duplicates' => $res['duplicates'], 'errors' => count( $res['errors'] ), 'channel' => 'legacy' ) );
		return $res;
	}

	public static function parse_csv( string $csv ): array {
		$csv = preg_replace( '/^\xEF\xBB\xBF/', '', $csv );
		$fh  = fopen( 'php://temp', 'r+' );
		fwrite( $fh, $csv );
		rewind( $fh );
		$head = fgetcsv( $fh, 0, ',', '"', '\\' );
		$rows = array();
		if ( ! $head ) {
			return array();
		}
		$head = array_map( static fn( $h ) => sanitize_key( trim( (string) $h ) ), $head );
		while ( ( $r = fgetcsv( $fh, 0, ',', '"', '\\' ) ) !== false ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
			if ( array( null ) === $r ) {
				continue;
			}
			$rows[] = array_combine( $head, array_pad( array_slice( $r, 0, count( $head ) ), count( $head ), '' ) );
		}
		fclose( $fh );
		return $rows;
	}

	/** @return array<int,array<string,mixed>> */
	public static function export_structured( int $course_id ): array {
		$out  = array();
		$page = 1;
		do {
			$batch = Questions::search( array( 'course_id' => $course_id, 'per_page' => 200, 'page' => $page ) );
			foreach ( $batch['rows'] as $r ) {
				if ( 'archived' === $r['status'] ) {
					continue;
				}
				$full  = Questions::full( (int) $r['id'] );
				$out[] = array(
					'type'        => $full['type'],
					'lesson_id'   => (int) $full['lesson_id'],
					'difficulty'  => $full['difficulty'],
					'points'      => (float) $full['version']['points'],
					'usage'       => $full['usage_scope'],
					'lang'        => $full['version']['lang'],
					'tags'        => $full['tags'],
					'status'      => $full['status'],
					'stem'        => $full['version']['stem'],
					'payload'     => $full['version']['payload'],
					'key'         => $full['version']['answer_key'],
					'scoring'     => in_array( $full['type'], Types::PARTIAL_TYPES, true ) ? Types::scoring_of( (array) $full['version']['answer_key'] ) : '',
					'explanation' => (string) $full['version']['explanation'],
				);
			}
			++$page;
		} while ( count( $batch['rows'] ) === 200 );
		return array_reverse( $out );
	}

	public static function export_csv( int $course_id ): string {
		$fh = fopen( 'php://temp', 'r+' );
		fputcsv( $fh, self::CSV_COLUMNS, ',', '"', '\\' );
		foreach ( self::export_structured( $course_id ) as $q ) {
			$a = Types::to_authoring( $q['type'], $q['payload'], $q['key'] );
			fputcsv(
				$fh,
				array( $q['type'], $q['lesson_id'], $q['difficulty'], $q['points'], $q['usage'], $q['lang'], implode( ',', $q['tags'] ), $q['status'], $q['stem'], $a['options'], $a['correct'], $q['explanation'], $a['model_answer'], $a['code'], $a['language'], $a['image_id'], $a['scoring'] ),
				',',
				'"',
				'\\'
			);
		}
		rewind( $fh );
		$csv = stream_get_contents( $fh );
		fclose( $fh );
		return "\xEF\xBB\xBF" . $csv;
	}
}
