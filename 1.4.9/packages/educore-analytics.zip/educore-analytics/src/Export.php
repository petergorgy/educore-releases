<?php
namespace EduCore\Analytics;

defined( 'ABSPATH' ) || exit;

/** Report datasets and CSV/XLSX serialisation. Permission is checked by callers via Scope::can_export(). */
final class Export {
	public const TYPES = array( 'course_students', 'lesson_completion', 'difficult_questions', 'at_risk', 'participation' );

	/** Neutralise spreadsheet formula injection. */
	public static function safe_cell( string $v ): string {
		return ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) ? "'" . $v : $v;
	}

	/** @return array<int,array<int,mixed>>|\WP_Error first row is the header */
	public static function rows( string $type, Filters $f, int $viewer ) {
		$course = ( null !== $f->course_ids && 1 === count( $f->course_ids ) ) ? $f->course_ids[0] : 0;
		if ( ! in_array( $type, self::TYPES, true ) ) {
			return new \WP_Error( 'educore_bad_report', __( 'Unknown report.', 'educore-analytics' ), array( 'status' => 400 ) );
		}
		if ( 'participation' !== $type && ! $course ) {
			return new \WP_Error( 'educore_course_required', __( 'Choose a course for this report.', 'educore-analytics' ), array( 'status' => 400 ) );
		}
		if ( ! Scope::can_export( $viewer, $course ?: null ) ) {
			return new \WP_Error( 'educore_forbidden', __( 'You cannot export this report.', 'educore-analytics' ), array( 'status' => 403 ) );
		}
		$show_names = static fn( int $uid ) => user_can( $viewer, 'ec_view_student', $uid );
		switch ( $type ) {
			case 'course_students':
				$rows   = array( array( __( 'Learner ID', 'educore-analytics' ), __( 'Learner', 'educore-analytics' ), __( 'Completion %', 'educore-analytics' ), __( 'Assessment mean %', 'educore-analytics' ), __( 'Active days (28)', 'educore-analytics' ) ) );
				$cf     = clone $f;
				foreach ( Metrics::enrolled_users( $course, $f ) as $u ) {
					$user   = get_userdata( $u );
					$rows[] = array( $u, $user && $show_names( $u ) ? $user->display_name : '', Metrics::course_completion( $u, $course ), Metrics::assessment_mean( $u, $cf ), Metrics::consistency( $u, $cf )['active_days'] );
				}
				return $rows;
			case 'lesson_completion':
				$rows = array( array( __( 'Lesson', 'educore-analytics' ), __( 'Completed', 'educore-analytics' ), __( 'Enrolled', 'educore-analytics' ), __( 'Rate %', 'educore-analytics' ) ) );
				foreach ( Metrics::lesson_completion_rates( $course, $f ) as $r ) {
					$rows[] = array( $r['lesson'], $r['completed'], $r['enrolled'], $r['rate'] );
				}
				return $rows;
			case 'difficult_questions':
				$rows = array( array( __( 'Question ID', 'educore-analytics' ), __( 'Lesson', 'educore-analytics' ), __( 'Responses', 'educore-analytics' ), __( 'Correct', 'educore-analytics' ), 'p' ) );
				foreach ( (array) Metrics::difficult_questions( $f ) as $q ) {
					$rows[] = array( $q['question_id'], $q['lesson_id'] ? get_the_title( $q['lesson_id'] ) : '', $q['responses'], $q['correct'], $q['p'] );
				}
				return $rows;
			case 'at_risk':
				$rows = array( array( __( 'Learner ID', 'educore-analytics' ), __( 'Learner', 'educore-analytics' ), __( 'Completion %', 'educore-analytics' ), __( 'Assessment mean %', 'educore-analytics' ), __( 'Last active (UTC)', 'educore-analytics' ), __( 'Reasons', 'educore-analytics' ) ) );
				foreach ( Metrics::at_risk( $course, $f ) as $r ) {
					$user   = get_userdata( $r['user_id'] );
					$rows[] = array( $r['user_id'], $user && $show_names( $r['user_id'] ) ? $user->display_name : '', $r['completion'], $r['mean'], (string) $r['last_active'], implode( ', ', $r['reasons'] ) );
				}
				return $rows;
			case 'participation':
				$rows = array( array( __( 'Course', 'educore-analytics' ), __( 'Enrolled', 'educore-analytics' ), __( 'Active in range', 'educore-analytics' ), __( 'Participation %', 'educore-analytics' ), __( 'Completions in range', 'educore-analytics' ) ) );
				foreach ( Metrics::participation( $f ) as $r ) {
					$rows[] = array( $r['course'], $r['enrolled'], $r['active'], $r['participation'], $r['completions'] );
				}
				return $rows;
		}
		return array();
	}

	public static function csv( array $rows ): string {
		$fh = fopen( 'php://temp', 'w+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $fh, "\xEF\xBB\xBF" ); // UTF-8 BOM so Excel shows Arabic/French correctly. phpcs:ignore WordPress.WP.AlternativeFunctions
		foreach ( $rows as $row ) {
			fputcsv( $fh, array_map( static fn( $v ) => is_string( $v ) ? self::safe_cell( $v ) : ( null === $v ? '' : $v ), (array) $row ), ',', '"', '\\' );
		}
		rewind( $fh );
		$out = (string) stream_get_contents( $fh );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $out;
	}

	/** admin-post handler: streams the file. */
	public static function download(): void {
		if ( ! isset( $_GET['_ecnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_ecnonce'] ) ), 'educore_analytics_export' ) ) {
			wp_die( esc_html__( 'Your session expired. Please reload and try again.', 'educore-analytics' ), 403 );
		}
		$type   = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '';
		$format = isset( $_GET['format'] ) && 'xlsx' === $_GET['format'] ? 'xlsx' : 'csv';
		$f      = new Filters( array_map( static fn( $v ) => sanitize_text_field( wp_unslash( $v ) ), array_intersect_key( $_GET, array_flip( array( 'from', 'to', 'course', 'programme', 'year' ) ) ) ) );
		$rows   = self::rows( $type, $f, get_current_user_id() );
		if ( is_wp_error( $rows ) ) {
			wp_die( esc_html( $rows->get_error_message() ), (int) ( $rows->get_error_data()['status'] ?? 400 ) );
		}
		\EduCore\Core\Audit::log( 'analytics.export', 'report', 0, array( 'type' => $type, 'format' => $format, 'course' => $f->course_ids ) );
		$name = 'educore-' . $type . '-' . gmdate( 'Ymd-His' ) . '.' . $format;
		nocache_headers();
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		if ( 'xlsx' === $format ) {
			header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
			echo Xlsx::build( $rows, $type ); // phpcs:ignore WordPress.Security.EscapeOutput -- binary file.
		} else {
			header( 'Content-Type: text/csv; charset=utf-8' );
			echo self::csv( $rows ); // phpcs:ignore WordPress.Security.EscapeOutput -- CSV file, injection-neutralised.
		}
		exit;
	}

	public static function url( string $type, string $format, Filters $f ): string {
		return wp_nonce_url( add_query_arg( array_merge( array( 'action' => 'educore_analytics_export', 'type' => $type, 'format' => $format ), $f->to_query_args() ), admin_url( 'admin-post.php' ) ), 'educore_analytics_export', '_ecnonce' );
	}
}
