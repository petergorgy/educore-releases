<?php
/**
 * EduCore Analytics uninstall. Data is KEPT unless the administrator explicitly opted in
 * (EduCore → Settings → Uninstall behaviour, two confirmations).
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( 'yes' !== get_option( 'educore_uninstall_delete_data' ) ) {
	return;
}
global $wpdb;
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'ec_analytics_daily' ); // phpcs:ignore WordPress.DB.PreparedSQL
delete_option( 'educore_analytics_db_version' );
