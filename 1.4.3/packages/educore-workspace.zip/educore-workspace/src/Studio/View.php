<?php
namespace EduCore\Workspace\Studio;

use EduCore\Core\Content;
use EduCore\Core\Curriculum;
use EduCore\Core\I18n;
use EduCore\Core\Staff;
use EduCore\Workspace\Pages;
use EduCore\Workspace\Shell;

defined( 'ABSPATH' ) || exit;

/** Course Studio (`/studio/`): course builder wizard, structure, lesson editor, review queue, academic structure. */
final class View {
	public const STEPS = array( 'basics', 'classification', 'objectives', 'structure', 'assessments', 'review' );

	public static function register(): void {
		add_shortcode( 'educore_studio', array( self::class, 'render' ) );
		add_filter( 'get_edit_post_link', array( self::class, 'edit_link' ), 10, 2 );
		add_filter( 'educore/th/course_edit_url', static fn( $url, $cid ) => self::url( array( 'course' => (int) $cid, 'step' => 'structure' ) ), 10, 2 );
	}

	public static function url( array $args = array() ): string {
		return Pages::url( 'studio', $args );
	}

	/** Front-end "Edit" links for courses and lessons open the Studio (wp-admin keeps its own links). */
	public static function edit_link( $link, $post_id ) {
		if ( is_admin() || ! $post_id ) {
			return $link;
		}
		$type = get_post_type( $post_id );
		if ( Content::COURSE === $type ) {
			return self::url( array( 'course' => (int) $post_id ) );
		}
		if ( Content::LESSON === $type ) {
			return self::url( array( 'lesson' => (int) $post_id ) );
		}
		return $link;
	}

	private static function q( string $k ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view parameters.
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
	}

	public static function notice( string $msg, string $kind = 'info' ): string {
		return '<div class="ec-notice ec-notice--' . esc_attr( $kind ) . '" role="' . ( 'error' === $kind ? 'alert' : 'status' ) . '">' . esc_html( $msg ) . '</div>';
	}

	public static function status_label( string $s ): string {
		return array(
			'draft'   => __( 'Draft', 'educore-workspace' ),
			'pending' => __( 'Awaiting review', 'educore-workspace' ),
			'publish' => __( 'Published', 'educore-workspace' ),
			'future'  => __( 'Scheduled', 'educore-workspace' ),
			'private' => __( 'Private', 'educore-workspace' ),
			'trash'   => __( 'In trash', 'educore-workspace' ),
		)[ $s ] ?? $s;
	}

	private static function chip( string $s ): string {
		return '<span class="ec-chip ec-chip--' . esc_attr( $s ) . '">' . esc_html( self::status_label( $s ) ) . '</span>';
	}

	public static function render(): string {
		$uid = get_current_user_id();
		if ( ! Courses::can_author( $uid ) ) {
			Shell::title( __( 'Course Studio', 'educore-workspace' ) );
			return self::notice( __( 'The Course Studio is for instructors and academic managers.', 'educore-workspace' ) );
		}
		$msg = array(
			'created'   => __( 'Course created. Continue with the steps below.', 'educore-workspace' ),
			'copied'    => __( 'A copy was created as a draft.', 'educore-workspace' ),
			'submitted' => __( 'Submitted for review. A publisher will review it.', 'educore-workspace' ),
			'published' => __( 'Published.', 'educore-workspace' ),
			'scheduled' => __( 'Scheduled for publication.', 'educore-workspace' ),
			'returned'  => __( 'Sent back to the authors with your note.', 'educore-workspace' ),
		)[ sanitize_key( self::q( 'ec_msg' ) ) ] ?? '';
		$flash = $msg ? self::notice( $msg, 'success' ) : '';
		if ( (int) self::q( 'bank' ) ) {
			return \EduCore\Workspace\Assess\View::bank( $uid, (int) self::q( 'bank' ) );
		}
		if ( (int) self::q( 'assess' ) ) {
			return \EduCore\Workspace\Assess\View::assessments( $uid, (int) self::q( 'assess' ) );
		}
		if ( (int) self::q( 'lesson' ) ) {
			return $flash . self::lesson( $uid, (int) self::q( 'lesson' ) );
		}
		if ( (int) self::q( 'course' ) ) {
			return $flash . self::course( $uid, (int) self::q( 'course' ) );
		}
		switch ( sanitize_key( self::q( 'v' ) ) ) {
			case 'new':
				return self::create_form();
			case 'review':
				return $flash . self::review_queue( $uid );
			case 'academic':
				return $flash . self::academic( $uid );
			case 'bank':
				return \EduCore\Workspace\Assess\View::picker( $uid, 'bank' );
			case 'assessments':
				return \EduCore\Workspace\Assess\View::picker( $uid, 'assessments' );
		}
		return $flash . self::list( $uid );
	}

	/* ---------- Course list ---------- */

	private static function list( int $uid ): string {
		Shell::title( __( 'My courses', 'educore-workspace' ), '<a class="ec-btn ec-btn--primary" href="' . esc_url( self::url( array( 'v' => 'new' ) ) ) . '">' . esc_html__( 'New course', 'educore-workspace' ) . '</a>' );
		Shell::crumbs( array( array( __( 'Course Studio', 'educore-workspace' ), self::url() ), array( __( 'My courses', 'educore-workspace' ) ) ) );
		$status  = sanitize_key( self::q( 'status' ) );
		$courses = Courses::mine( $uid, $status );
		$o       = '<nav class="ec-ws-tabs" aria-label="' . esc_attr__( 'Filter by status', 'educore-workspace' ) . '"><ul>';
		foreach ( array( '' => __( 'All', 'educore-workspace' ), 'draft' => __( 'Drafts', 'educore-workspace' ), 'pending' => __( 'Awaiting review', 'educore-workspace' ), 'future' => __( 'Scheduled', 'educore-workspace' ), 'publish' => __( 'Published', 'educore-workspace' ) ) as $k => $l ) {
			$o .= '<li><a href="' . esc_url( self::url( $k ? array( 'status' => $k ) : array() ) ) . '"' . ( $k === $status ? ' aria-current="page"' : '' ) . '>' . esc_html( $l ) . '</a></li>';
		}
		$o .= '</ul></nav>';
		if ( ! $courses ) {
			return $o . '<div class="ec-ws-empty"><p>' . esc_html__( 'No courses yet.', 'educore-workspace' ) . '</p><p><a class="ec-btn ec-btn--primary" href="' . esc_url( self::url( array( 'v' => 'new' ) ) ) . '">' . esc_html__( 'Create your first course', 'educore-workspace' ) . '</a></p></div>';
		}
		$o .= '<ul class="ec-studio-cards">';
		foreach ( $courses as $c ) {
			$units   = Content::units( $c->ID, Courses::EDITABLE );
			$lessons = 0;
			foreach ( $units as $u ) {
				$lessons += count( Content::lessons_of_unit( $u->ID, Courses::EDITABLE ) );
			}
			$thumb = get_the_post_thumbnail( $c->ID, 'medium', array( 'class' => 'ec-studio-card__img', 'alt' => '' ) );
			/* translators: 1: units, 2: lessons */
			$counts = sprintf( __( '%1$d units · %2$d lessons', 'educore-workspace' ), count( $units ), $lessons );
			$o     .= '<li class="ec-card ec-studio-card">' . ( $thumb ?: '<span class="ec-studio-card__img ec-studio-card__img--empty" aria-hidden="true"></span>' ) . '<div class="ec-studio-card__body"><h2 class="ec-studio-card__title"><a href="' . esc_url( self::url( array( 'course' => $c->ID ) ) ) . '">' . esc_html( get_the_title( $c ) ) . '</a></h2><p class="ec-muted">' . self::chip( $c->post_status ) . ' ' . esc_html( $counts ) . '</p>';
			$o     .= '<p class="ec-ws-actions"><a class="ec-btn ec-btn--small" href="' . esc_url( self::url( array( 'course' => $c->ID ) ) ) . '">' . esc_html__( 'Edit', 'educore-workspace' ) . '</a> <a class="ec-btn ec-btn--small" href="' . esc_url( get_preview_post_link( $c ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Preview', 'educore-workspace' ) . '</a> <button class="ec-btn ec-btn--small" type="button" data-ec-call="studio/courses/' . (int) $c->ID . '/duplicate" data-ec-method="POST" data-ec-confirm="' . esc_attr__( 'Make a draft copy of this course, with all units and lessons?', 'educore-workspace' ) . '">' . esc_html__( 'Duplicate', 'educore-workspace' ) . '</button></p></div></li>';
		}
		return $o . '</ul>';
	}

	private static function create_form(): string {
		Shell::title( __( 'New course', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Course Studio', 'educore-workspace' ), self::url() ), array( __( 'New course', 'educore-workspace' ) ) ) );
		$o  = '<form class="ec-card ec-ws-form ec-studio-narrow" data-ec-api="studio/courses" data-ec-method="POST" novalidate>';
		$o .= self::field_text( 'title', __( 'Course title', 'educore-workspace' ), '', true );
		$o .= self::field_area( 'excerpt', __( 'Short description', 'educore-workspace' ), '', 3, __( 'One or two sentences shown in the catalogue.', 'educore-workspace' ) );
		$o .= self::field_select( 'lang', __( 'Language of instruction', 'educore-workspace' ), I18n::labels(), I18n::current() );
		$o .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Create and continue', 'educore-workspace' ) . '</button> <a class="ec-btn" href="' . esc_url( self::url() ) . '">' . esc_html__( 'Cancel', 'educore-workspace' ) . '</a></div></form>';
		return $o;
	}

	/* ---------- Course builder ---------- */

	private static function stepper( int $course_id, string $cur ): string {
		$labels = array(
			'basics'         => __( 'Basics', 'educore-workspace' ),
			'classification' => __( 'Classification', 'educore-workspace' ),
			'objectives'     => __( 'Objectives & enrollment', 'educore-workspace' ),
			'structure'      => __( 'Units & lessons', 'educore-workspace' ),
			'assessments'    => __( 'Assessments', 'educore-workspace' ),
			'review'         => __( 'Review & publish', 'educore-workspace' ),
		);
		$o = '<nav class="ec-studio-steps" aria-label="' . esc_attr__( 'Course steps', 'educore-workspace' ) . '"><ol>';
		$i = 0;
		foreach ( $labels as $k => $l ) {
			++$i;
			$o .= '<li><a href="' . esc_url( self::url( array( 'course' => $course_id, 'step' => $k ) ) ) . '"' . ( $k === $cur ? ' aria-current="step"' : '' ) . '><span class="ec-studio-steps__n" aria-hidden="true">' . (int) $i . '</span><span>' . esc_html( $l ) . '</span></a></li>';
		}
		return $o . '</ol></nav>';
	}

	private static function next_url( int $course_id, string $step ): string {
		$i = array_search( $step, self::STEPS, true );
		return self::url( array( 'course' => $course_id, 'step' => self::STEPS[ min( count( self::STEPS ) - 1, (int) $i + 1 ) ] ) );
	}

	private static function course( int $uid, int $id ): string {
		if ( ! Content::is_course( $id ) || ! Courses::can_edit( $uid, $id ) ) {
			// Publishers can open courses waiting for review even when not on the team.
			if ( ! ( Content::is_course( $id ) && Courses::can_publish( $uid ) ) ) {
				Shell::title( __( 'Course Studio', 'educore-workspace' ) );
				return self::notice( __( 'You cannot edit this course.', 'educore-workspace' ), 'error' );
			}
		}
		$c    = get_post( $id );
		$step = in_array( self::q( 'step' ), self::STEPS, true ) ? self::q( 'step' ) : 'basics';
		Shell::title( get_the_title( $c ), self::chip( $c->post_status ) . ' <a class="ec-btn" href="' . esc_url( get_preview_post_link( $c ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Preview', 'educore-workspace' ) . '</a>' );
		Shell::crumbs( array( array( __( 'Course Studio', 'educore-workspace' ), self::url() ), array( get_the_title( $c ) ) ) );
		$note = json_decode( (string) get_post_meta( $id, '_ec_review_note', true ), true );
		$o    = '';
		if ( is_array( $note ) ) {
			$who = get_userdata( (int) $note['by'] );
			/* translators: 1: reviewer, 2: note */
			$o .= '<div class="ec-notice ec-notice--info" role="status"><strong>' . esc_html__( 'Changes requested', 'educore-workspace' ) . '</strong> — ' . esc_html( sprintf( __( '%1$s: %2$s', 'educore-workspace' ), $who ? $who->display_name : '', $note['note'] ) ) . '</div>';
		}
		$o .= self::stepper( $id, $step ) . '<div class="ec-studio-step">' . self::{'step_' . $step}( $uid, $c ) . '</div>';
		return $o;
	}

	private static function step_form( \WP_Post $c, string $step, string $inner, bool $editable ): string {
		return '<form class="ec-card ec-ws-form" data-ec-api="studio/courses/' . (int) $c->ID . '" data-ec-method="POST" data-ec-dirty data-ec-after="' . esc_attr( self::next_url( $c->ID, $step ) ) . '" novalidate><fieldset class="ec-ws-plain"' . disabled( ! $editable, true, false ) . '>' . $inner . '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Save and continue', 'educore-workspace' ) . '</button></div></fieldset></form>';
	}

	private static function step_basics( int $uid, \WP_Post $c ): string {
		wp_enqueue_media( array( 'post' => $c->ID ) );
		$cover = (int) get_post_thumbnail_id( $c->ID );
		$i     = self::field_text( 'title', __( 'Course title', 'educore-workspace' ), $c->post_title, true );
		$i    .= self::field_area( 'excerpt', __( 'Short description', 'educore-workspace' ), $c->post_excerpt, 3, __( 'One or two sentences shown in the catalogue.', 'educore-workspace' ) );
		$i    .= '<div class="ec-ws-field"><span class="ec-ws-label">' . esc_html__( 'Cover image', 'educore-workspace' ) . '</span><div class="ec-studio-cover" data-ec-media data-ec-media-title="' . esc_attr__( 'Choose a cover image', 'educore-workspace' ) . '"><input type="hidden" name="cover_id" value="' . (int) $cover . '"><span class="ec-studio-cover__preview">' . ( $cover ? wp_get_attachment_image( $cover, 'medium', false, array( 'alt' => '' ) ) : '' ) . '</span><button class="ec-btn" type="button" data-ec-media-pick>' . esc_html__( 'Choose image', 'educore-workspace' ) . '</button> <button class="ec-btn" type="button" data-ec-media-clear' . ( $cover ? '' : ' hidden' ) . '>' . esc_html__( 'Remove', 'educore-workspace' ) . '</button></div></div>';
		$i    .= '<div class="ec-ws-field"><span class="ec-ws-label" id="ec-course-desc-l">' . esc_html__( 'Full description', 'educore-workspace' ) . '</span>' . self::editor( 'content', 'ec-course-desc', $c->post_content, 10 ) . '</div>';
		$i    .= '<div class="ec-ws-grid">' . self::field_select( 'lang', __( 'Language of instruction', 'educore-workspace' ), I18n::labels(), (string) get_post_meta( $c->ID, '_ec_lang', true ) ) . self::field_select( 'difficulty', __( 'Level', 'educore-workspace' ), array( 'beginner' => __( 'Beginner', 'educore-workspace' ), 'intermediate' => __( 'Intermediate', 'educore-workspace' ), 'advanced' => __( 'Advanced', 'educore-workspace' ) ), (string) get_post_meta( $c->ID, '_ec_difficulty', true ) ) . '</div>';
		return self::step_form( $c, 'basics', $i, Courses::can_edit( $uid, $c->ID ) );
	}

	private static function step_classification( int $uid, \WP_Post $c ): string {
		$map   = Curriculum::mappings_for_course( $c->ID )[0] ?? array();
		$progs = array( '' => __( 'Not linked to a programme', 'educore-workspace' ) );
		foreach ( Curriculum::programmes() as $p ) {
			$progs[ (string) $p['id'] ] = $p['name'];
		}
		$sel     = (int) ( $map['programme_id'] ?? 0 );
		$periods = array( '' => '—' );
		$subj    = array( '' => '—' );
		foreach ( Curriculum::programmes() as $p ) {
			foreach ( Curriculum::periods( (int) $p['id'] ) as $per ) {
				$periods[ (string) $per['id'] ] = $p['name'] . ' › ' . $per['label'];
			}
			foreach ( Curriculum::subjects( (int) $p['id'] ) as $s ) {
				$subj[ (string) $s['id'] ] = $p['name'] . ' › ' . $s['name'];
			}
		}
		$i  = '<div class="ec-ws-grid">' . self::field_select( 'programme_id', __( 'Programme', 'educore-workspace' ), $progs, (string) $sel ) . self::field_select( 'period_id', __( 'Academic year / semester', 'educore-workspace' ), $periods, (string) ( $map['period_id'] ?? '' ) ) . self::field_select( 'subject_id', __( 'Subject', 'educore-workspace' ), $subj, (string) ( $map['subject_id'] ?? '' ) ) . '</div>';
		$i .= '<div class="ec-ws-grid">' . self::field_text( 'grade_level', __( 'Grade level', 'educore-workspace' ), (string) get_post_meta( $c->ID, '_ec_grade_level', true ) ) . self::field_text( 'duration_hours', __( 'Estimated duration (hours)', 'educore-workspace' ), (string) get_post_meta( $c->ID, '_ec_duration_hours', true ), false, 'number' ) . '</div>';
		if ( current_user_can( 'ec_manage_programmes' ) ) {
			$i .= '<p class="ec-muted"><a href="' . esc_url( self::url( array( 'v' => 'academic' ) ) ) . '">' . esc_html__( 'Manage programmes, years and subjects', 'educore-workspace' ) . '</a></p>';
		}
		return self::step_form( $c, 'classification', $i, Courses::can_edit( $uid, $c->ID ) );
	}

	private static function step_objectives( int $uid, \WP_Post $c ): string {
		$i  = self::field_area( 'objectives', __( 'Learning objectives (one per line)', 'educore-workspace' ), (string) get_post_meta( $c->ID, '_ec_objectives', true ), 5 );
		$i .= self::field_area( 'prerequisites', __( 'Prerequisites', 'educore-workspace' ), (string) get_post_meta( $c->ID, '_ec_prerequisites', true ), 3 );
		$i .= self::field_area( 'assessment_req', __( 'How learners are assessed', 'educore-workspace' ), (string) get_post_meta( $c->ID, '_ec_assessment_req', true ), 3 );
		$modes = array( 'open' => __( 'Open: learners enroll themselves', 'educore-workspace' ), 'closed' => __( 'Closed: staff enroll learners', 'educore-workspace' ) );
		if ( defined( 'EDUCORE_COMMERCE_VERSION' ) ) {
			$modes['paid'] = __( 'Paid', 'educore-workspace' );
		}
		$i .= self::field_select( 'enroll_mode', __( 'Enrollment', 'educore-workspace' ), $modes, (string) get_post_meta( $c->ID, '_ec_enroll_mode', true ) );
		return self::step_form( $c, 'objectives', $i, Courses::can_edit( $uid, $c->ID ) );
	}

	private static function step_structure( int $uid, \WP_Post $c ): string {
		$edit = Courses::can_edit( $uid, $c->ID );
		$out  = Content::outline( $c->ID, Courses::EDITABLE );
		$o    = '<section class="ec-card ec-ws-section"><div class="ec-studio-structure-head"><h2>' . esc_html__( 'Units and lessons', 'educore-workspace' ) . '</h2>';
		if ( $edit ) {
			$o .= '<p class="ec-muted" id="ec-dnd-help">' . esc_html__( 'Drag items to reorder, or use the move buttons. Lessons can move between units. Changes to the order are saved with “Save order”.', 'educore-workspace' ) . '</p>';
		}
		$o .= '</div>';
		if ( ! $out ) {
			$o .= '<p class="ec-muted">' . esc_html__( 'No units yet. Add the first unit below.', 'educore-workspace' ) . '</p>';
		}
		$o .= '<ol class="ec-studio-outline" data-ec-outline="' . (int) $c->ID . '" aria-describedby="ec-dnd-help">';
		foreach ( $out as $row ) {
			$u  = $row['unit'];
			$o .= '<li class="ec-studio-unit" data-unit="' . (int) $u->ID . '"' . ( $edit ? ' draggable="true"' : '' ) . '><div class="ec-studio-row"><span class="ec-studio-grip" aria-hidden="true">⋮⋮</span><strong class="ec-studio-row__title">' . esc_html( get_the_title( $u ) ) . '</strong> ' . self::chip( $u->post_status );
			if ( $edit ) {
				$o .= self::row_tools( $u->ID, __( 'unit', 'educore-workspace' ), get_the_title( $u ) );
			}
			$o .= '</div><ol class="ec-studio-lessons">';
			foreach ( $row['lessons'] as $l ) {
				$o .= '<li class="ec-studio-lesson" data-lesson="' . (int) $l->ID . '"' . ( $edit ? ' draggable="true"' : '' ) . '><div class="ec-studio-row"><span class="ec-studio-grip" aria-hidden="true">⋮⋮</span><a class="ec-studio-row__title" href="' . esc_url( self::url( array( 'lesson' => $l->ID ) ) ) . '">' . esc_html( get_the_title( $l ) ) . '</a> ' . self::chip( $l->post_status );
				if ( $edit ) {
					$o .= self::row_tools( $l->ID, __( 'lesson', 'educore-workspace' ), get_the_title( $l ) );
				}
				$o .= '</div></li>';
			}
			$o .= '</ol>';
			if ( $edit ) {
				$o .= '<form class="ec-ws-inline ec-studio-add" data-ec-api="studio/units/' . (int) $u->ID . '/lessons" data-ec-method="POST"><label><span>' . esc_html__( 'New lesson', 'educore-workspace' ) . '</span><input type="text" name="title" required></label><button class="ec-btn ec-btn--small" type="submit">' . esc_html__( 'Add lesson', 'educore-workspace' ) . '</button></form>';
			}
			$o .= '</li>';
		}
		$o .= '</ol>';
		if ( $edit ) {
			$o .= '<div class="ec-ws-actions"><button class="ec-btn" type="button" data-ec-save-order hidden>' . esc_html__( 'Save order', 'educore-workspace' ) . '</button></div>';
			$o .= '<form class="ec-ws-inline" data-ec-api="studio/courses/' . (int) $c->ID . '/units" data-ec-method="POST"><label><span>' . esc_html__( 'New unit', 'educore-workspace' ) . '</span><input type="text" name="title" required></label><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Add unit', 'educore-workspace' ) . '</button></form>';
		}
		$o .= '</section><p class="ec-ws-actions"><a class="ec-btn ec-btn--primary" href="' . esc_url( self::next_url( $c->ID, 'structure' ) ) . '">' . esc_html__( 'Continue', 'educore-workspace' ) . '</a></p>';
		return $o;
	}

	private static function row_tools( int $id, string $kind, string $title ): string {
		/* translators: 1: item kind (unit/lesson), 2: title */
		$lbl = static fn( string $verb ) => sprintf( '%1$s %2$s “%3$s”', $verb, $kind, $title );
		return '<span class="ec-studio-tools">'
			. '<button type="button" class="ec-btn ec-btn--icon" data-ec-move="-1" aria-label="' . esc_attr( $lbl( __( 'Move up', 'educore-workspace' ) ) ) . '">↑</button>'
			. '<button type="button" class="ec-btn ec-btn--icon" data-ec-move="1" aria-label="' . esc_attr( $lbl( __( 'Move down', 'educore-workspace' ) ) ) . '">↓</button>'
			. '<button type="button" class="ec-btn ec-btn--icon" data-ec-rename="' . (int) $id . '" data-ec-current="' . esc_attr( $title ) . '" aria-label="' . esc_attr( $lbl( __( 'Rename', 'educore-workspace' ) ) ) . '">✎</button>'
			. '<button type="button" class="ec-btn ec-btn--icon ec-btn--danger" data-ec-call="studio/items/' . (int) $id . '" data-ec-method="DELETE" data-ec-confirm="' . esc_attr__( 'Move this item to the trash? It can be restored by an administrator.', 'educore-workspace' ) . '" aria-label="' . esc_attr( $lbl( __( 'Move to trash', 'educore-workspace' ) ) ) . '">🗑</button>'
			. '</span>';
	}

	private static function step_assessments( int $uid, \WP_Post $c ): string {
		$o = '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Assessments in this course', 'educore-workspace' ) . '</h2>';
		if ( ! \EduCore\Workspace\Assess\Builder::available() ) {
			$o .= '<p class="ec-muted">' . esc_html__( 'The assessments package is not active.', 'educore-workspace' ) . '</p>';
		} else {
			$rows = \EduCore\Assessments\Assessments::for_course( $c->ID, \EduCore\Assessments\Assessments::STATUSES );
			$o   .= $rows ? '<ul class="ec-ws-list">' . implode( '', array_map( static fn( $a ) => '<li><span>' . esc_html( $a['title'] ) . ' <span class="ec-muted">(' . esc_html( $a['kind'] ) . ')</span></span>' . \EduCore\Workspace\Assess\View::status_chip( (string) $a['status'] ) . '</li>', $rows ) ) . '</ul>' : '<p class="ec-muted">' . esc_html__( 'No assessments yet.', 'educore-workspace' ) . '</p>';
			$links = '';
			if ( \EduCore\Workspace\Assess\Bank::can( $uid, $c->ID ) ) {
				$links .= '<a class="ec-btn" href="' . esc_url( self::url( array( 'bank' => $c->ID ) ) ) . '">' . esc_html__( 'Question bank', 'educore-workspace' ) . '</a> ';
			}
			if ( \EduCore\Workspace\Assess\Builder::can( $uid, $c->ID ) ) {
				$links .= '<a class="ec-btn" href="' . esc_url( self::url( array( 'assess' => $c->ID ) ) ) . '">' . esc_html__( 'Manage assessments', 'educore-workspace' ) . '</a> <a class="ec-btn" href="' . esc_url( self::url( array( 'assess' => $c->ID, 'a' => 'new' ) ) ) . '">' . esc_html__( 'New assessment', 'educore-workspace' ) . '</a>';
			}
			$o .= $links ? '<p class="ec-ws-actions">' . $links . '</p>' : '<p class="ec-muted">' . esc_html__( 'Assessments for this course are managed by the academic team.', 'educore-workspace' ) . '</p>';
		}
		return $o . '</section><p class="ec-ws-actions"><a class="ec-btn ec-btn--primary" href="' . esc_url( self::next_url( $c->ID, 'assessments' ) ) . '">' . esc_html__( 'Continue', 'educore-workspace' ) . '</a></p>';
	}

	private static function step_review( int $uid, \WP_Post $c ): string {
		$problems = Courses::checklist( $c->ID );
		$o        = '<div class="ec-ws-cols"><div><section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Readiness check', 'educore-workspace' ) . '</h2>';
		$o       .= $problems ? '<ul class="ec-studio-check">' . implode( '', array_map( static fn( $p ) => '<li class="is-todo">' . esc_html( $p ) . '</li>', $problems ) ) . '</ul>' : '<p class="ec-studio-ok">' . esc_html__( 'Everything needed for publication is in place.', 'educore-workspace' ) . '</p>';
		$o       .= '</section><section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Publication', 'educore-workspace' ) . '</h2>';
		if ( Courses::can_publish( $uid ) ) {
			$o .= '<form class="ec-ws-form" data-ec-api="studio/courses/' . (int) $c->ID . '/publish" data-ec-method="POST" data-ec-after="' . esc_attr( self::url( array( 'course' => $c->ID, 'step' => 'review', 'ec_msg' => 'published' ) ) ) . '"><label><span>' . esc_html__( 'Publish on (optional, leave empty to publish now)', 'educore-workspace' ) . '</span><input type="datetime-local" name="when"></label><div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit"' . disabled( (bool) $problems, true, false ) . '>' . esc_html__( 'Approve and publish', 'educore-workspace' ) . '</button></div></form>';
			if ( 'pending' === $c->post_status || get_post_meta( $c->ID, '_ec_review_requested', true ) ) {
				$o .= '<form class="ec-ws-form ec-studio-reject" data-ec-api="studio/courses/' . (int) $c->ID . '/reject" data-ec-method="POST" data-ec-after="' . esc_attr( self::url( array( 'v' => 'review', 'ec_msg' => 'returned' ) ) ) . '">' . self::field_area( 'note', __( 'Request changes (note to the authors)', 'educore-workspace' ), '', 3 ) . '<div class="ec-ws-actions"><button class="ec-btn" type="submit">' . esc_html__( 'Send back for changes', 'educore-workspace' ) . '</button></div></form>';
			}
		} elseif ( 'pending' === $c->post_status ) {
			$o .= '<p>' . esc_html__( 'This course is waiting for a publisher’s review. You can keep improving it in the meantime.', 'educore-workspace' ) . '</p>';
		} else {
			$o .= '<p class="ec-muted">' . esc_html__( 'Instructors submit courses for review; a publisher approves and publishes them.', 'educore-workspace' ) . '</p>';
			$o .= '<button class="ec-btn ec-btn--primary" type="button" data-ec-call="studio/courses/' . (int) $c->ID . '/submit" data-ec-method="POST" data-ec-goto="' . esc_attr( self::url( array( 'course' => $c->ID, 'step' => 'review', 'ec_msg' => 'submitted' ) ) ) . '"' . disabled( (bool) $problems, true, false ) . '>' . esc_html__( 'Submit for review', 'educore-workspace' ) . '</button>';
		}
		$o .= '</section></div><div>' . self::history( $c->ID ) . '</div></div>';
		return $o;
	}

	private static function history( int $post_id ): string {
		$revs = Courses::revisions( $post_id );
		$o    = '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Version history', 'educore-workspace' ) . '</h2>';
		if ( ! $revs ) {
			return $o . '<p class="ec-muted">' . esc_html__( 'No earlier versions yet.', 'educore-workspace' ) . '</p></section>';
		}
		$o .= '<ul class="ec-ws-list">';
		foreach ( $revs as $r ) {
			$o .= '<li><span>' . esc_html( get_date_from_gmt( $r['date'], 'Y-m-d H:i' ) ) . ' <span class="ec-muted">' . esc_html( $r['author'] ) . '</span></span><button class="ec-btn ec-btn--small" type="button" data-ec-call="studio/revisions/' . (int) $r['id'] . '/restore" data-ec-method="POST" data-ec-confirm="' . esc_attr__( 'Restore this version? The current text is kept in the history.', 'educore-workspace' ) . '">' . esc_html__( 'Restore', 'educore-workspace' ) . '</button></li>';
		}
		return $o . '</ul></section>';
	}

	/* ---------- Lesson editor ---------- */

	private static function lesson( int $uid, int $id ): string {
		if ( Content::LESSON !== get_post_type( $id ) || ! Courses::can_edit( $uid, $id ) ) {
			Shell::title( __( 'Lesson', 'educore-workspace' ) );
			return self::notice( __( 'You cannot edit this lesson.', 'educore-workspace' ), 'error' );
		}
		wp_enqueue_media( array( 'post' => $id ) );
		$l      = get_post( $id );
		$course = Content::course_of( $id );
		Shell::title( get_the_title( $l ), self::chip( $l->post_status ) . ' <a class="ec-btn" href="' . esc_url( get_preview_post_link( $l ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Preview', 'educore-workspace' ) . '</a>' );
		Shell::crumbs( array( array( __( 'Course Studio', 'educore-workspace' ), self::url() ), array( get_the_title( $course ), self::url( array( 'course' => $course, 'step' => 'structure' ) ) ), array( get_the_title( $l ) ) ) );
		$o  = '';
		$as = Courses::autosave_of( $id );
		if ( $as && (int) $as['at'] > strtotime( $l->post_modified_gmt . ' UTC' ) ) {
			$o .= '<div class="ec-notice ec-notice--info" role="status" data-ec-autosave-notice>' . esc_html__( 'There is an automatically saved version that is newer than the saved lesson.', 'educore-workspace' ) . ' <button class="ec-btn ec-btn--small" type="button" data-ec-restore-autosave>' . esc_html__( 'Restore it', 'educore-workspace' ) . '</button><script type="application/json" data-ec-autosave-data>' . wp_json_encode( array( 'title' => $as['title'], 'content' => $as['content'] ), JSON_HEX_TAG | JSON_HEX_AMP ) . '</script></div>';
		}
		$units = array();
		foreach ( Content::units( $course, Courses::EDITABLE ) as $u ) {
			$units[ (string) $u->ID ] = get_the_title( $u );
		}
		$rules = array( 'manual' => __( 'Learner marks it complete', 'educore-workspace' ), 'view' => __( 'Complete when opened', 'educore-workspace' ), 'time' => __( 'Complete after a minimum time', 'educore-workspace' ) );
		foreach ( (array) apply_filters( 'educore/progress/completion_rules', Content::COMPLETION_RULES ) as $r ) {
			if ( ! isset( $rules[ $r ] ) ) {
				$rules[ $r ] = ucfirst( str_replace( '_', ' ', (string) $r ) );
			}
		}
		$o .= '<form class="ec-ws-form ec-studio-lesson-form" data-ec-api="studio/lessons/' . (int) $id . '" data-ec-method="POST" data-ec-dirty data-ec-after="stay" data-ec-autosave="studio/lessons/' . (int) $id . '/autosave" novalidate><div class="ec-ws-cols"><div class="ec-card">';
		$o .= self::field_text( 'title', __( 'Lesson title', 'educore-workspace' ), $l->post_title, true );
		$o .= '<div class="ec-ws-field"><span class="ec-ws-label" id="ec-lesson-body-l">' . esc_html__( 'Lesson content', 'educore-workspace' ) . '</span><p class="ec-muted">' . esc_html__( 'Text, images, video, audio, PDFs and presentations: use “Add media” to upload or choose files; paste a YouTube or Vimeo link on its own line to embed a video.', 'educore-workspace' ) . '</p>' . self::editor( 'content', 'ec-lesson-body', $l->post_content, 22 ) . '</div>';
		$o .= '<p class="ec-muted" data-ec-autosave-status aria-live="polite"></p></div><div>';
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Lesson settings', 'educore-workspace' ) . '</h2>' . self::field_select( 'unit_id', __( 'Unit', 'educore-workspace' ), $units, (string) get_post_meta( $id, '_ec_unit_id', true ) ) . self::field_text( 'minutes', __( 'Estimated minutes', 'educore-workspace' ), (string) get_post_meta( $id, '_ec_minutes', true ), false, 'number' ) . self::field_select( 'completion_rule', __( 'Completion', 'educore-workspace' ), $rules, (string) get_post_meta( $id, '_ec_completion_rule', true ) ) . self::field_text( 'completion_secs', __( 'Minimum time (seconds, for timed completion)', 'educore-workspace' ), (string) get_post_meta( $id, '_ec_completion_secs', true ), false, 'number' ) . self::field_area( 'objectives', __( 'Objectives', 'educore-workspace' ), (string) get_post_meta( $id, '_ec_objectives', true ), 3 ) . self::field_area( 'summary', __( 'Summary', 'educore-workspace' ), (string) get_post_meta( $id, '_ec_summary', true ), 3 ) . '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Save lesson', 'educore-workspace' ) . '</button></div></section>';
		$o .= '</div></div></form>' . self::history( $id );
		return $o;
	}

	/* ---------- Review queue ---------- */

	private static function review_queue( int $uid ): string {
		Shell::title( __( 'Review queue', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Course Studio', 'educore-workspace' ), self::url() ), array( __( 'Review queue', 'educore-workspace' ) ) ) );
		if ( ! Courses::can_publish( $uid ) ) {
			return self::notice( __( 'Only publishers review courses.', 'educore-workspace' ), 'error' );
		}
		$q    = Courses::review_queue( $uid );
		$live = get_posts( array( 'post_type' => Content::COURSE, 'post_status' => 'publish', 'meta_key' => '_ec_review_requested', 'numberposts' => 100 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$all  = array_merge( $q, $live );
		if ( ! $all ) {
			return '<div class="ec-ws-empty"><p>' . esc_html__( 'Nothing is waiting for review.', 'educore-workspace' ) . '</p></div>';
		}
		$o = '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><thead><tr><th scope="col">' . esc_html__( 'Course', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Submitted by', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Last change', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-workspace' ) . '</th></tr></thead><tbody>';
		foreach ( $all as $c ) {
			$team = array_map( static fn( $r ) => get_userdata( (int) $r['user_id'] )->display_name ?? '', Staff::of_course( $c->ID ) );
			$o   .= '<tr><th scope="row"><a href="' . esc_url( self::url( array( 'course' => $c->ID, 'step' => 'review' ) ) ) . '">' . esc_html( get_the_title( $c ) ) . '</a></th><td>' . esc_html( implode( ', ', array_filter( $team ) ) ) . '</td><td>' . esc_html( get_date_from_gmt( $c->post_modified_gmt, 'Y-m-d H:i' ) ) . '</td><td>' . self::chip( $c->post_status ) . ( 'publish' === $c->post_status ? ' <span class="ec-chip">' . esc_html__( 'Changes to review', 'educore-workspace' ) . '</span>' : '' ) . '</td></tr>';
		}
		return $o . '</tbody></table></div>';
	}

	/* ---------- Academic structure ---------- */

	private static function academic( int $uid ): string {
		Shell::title( __( 'Academic structure', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Course Studio', 'educore-workspace' ), self::url() ), array( __( 'Academic structure', 'educore-workspace' ) ) ) );
		if ( ! user_can( $uid, 'ec_manage_programmes' ) ) {
			return self::notice( __( 'Only academic managers change programmes.', 'educore-workspace' ), 'error' );
		}
		$o = '';
		foreach ( Curriculum::programmes() as $p ) {
			$pid = (int) $p['id'];
			$o  .= '<section class="ec-card ec-ws-section"><h2>' . esc_html( $p['name'] ) . ' <code>' . esc_html( $p['code'] ) . '</code></h2><div class="ec-ws-cols"><div><h3>' . esc_html__( 'Years and semesters', 'educore-workspace' ) . '</h3><ul class="ec-ws-list">';
			foreach ( Curriculum::periods( $pid ) as $per ) {
				$o .= '<li><span>' . esc_html( $per['label'] ) . '</span><span class="ec-chip">' . esc_html( $per['type'] ) . '</span></li>';
			}
			$o .= '</ul><form class="ec-ws-inline" data-ec-api="studio/programmes/' . $pid . '/periods" data-ec-method="POST"><label><span>' . esc_html__( 'Label', 'educore-workspace' ) . '</span><input type="text" name="label" required></label>' . self::field_select( 'type', __( 'Type', 'educore-workspace' ), array( 'year' => __( 'Academic year', 'educore-workspace' ), 'semester' => __( 'Semester', 'educore-workspace' ), 'term' => __( 'Term', 'educore-workspace' ) ), 'year' ) . '<button class="ec-btn" type="submit">' . esc_html__( 'Add', 'educore-workspace' ) . '</button></form></div><div><h3>' . esc_html__( 'Subjects', 'educore-workspace' ) . '</h3><ul class="ec-ws-list">';
			foreach ( Curriculum::subjects( $pid ) as $s ) {
				$o .= '<li><span>' . esc_html( $s['name'] ) . '</span><code>' . esc_html( $s['code'] ) . '</code></li>';
			}
			$o .= '</ul><form class="ec-ws-inline" data-ec-api="studio/programmes/' . $pid . '/subjects" data-ec-method="POST"><label><span>' . esc_html__( 'Code', 'educore-workspace' ) . '</span><input type="text" name="code" required></label><label><span>' . esc_html__( 'Name', 'educore-workspace' ) . '</span><input type="text" name="name" required></label><button class="ec-btn" type="submit">' . esc_html__( 'Add', 'educore-workspace' ) . '</button></form></div></div></section>';
		}
		$o .= '<form class="ec-card ec-ws-form" data-ec-api="studio/programmes" data-ec-method="POST"><h2>' . esc_html__( 'New programme', 'educore-workspace' ) . '</h2><div class="ec-ws-grid">' . self::field_text( 'code', __( 'Code', 'educore-workspace' ), '', true ) . self::field_text( 'name', __( 'Name', 'educore-workspace' ), '', true ) . self::field_select( 'lang', __( 'Language', 'educore-workspace' ), I18n::labels(), I18n::current() ) . '</div><div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Add programme', 'educore-workspace' ) . '</button></div></form>';
		return $o;
	}

	/* ---------- Field helpers ---------- */

	public static function field_text( string $name, string $label, string $value = '', bool $required = false, string $type = 'text' ): string {
		$id = 'ec-f-' . $name;
		return '<label class="ec-ws-field" for="' . esc_attr( $id ) . '"><span class="ec-ws-label">' . esc_html( $label ) . ( $required ? ' <abbr title="' . esc_attr__( 'required', 'educore-workspace' ) . '">*</abbr>' : '' ) . '</span><input id="' . esc_attr( $id ) . '" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . ( $required ? ' required aria-required="true"' : '' ) . ( 'number' === $type ? ' min="0" inputmode="numeric"' : '' ) . '></label>';
	}

	public static function field_area( string $name, string $label, string $value = '', int $rows = 4, string $help = '' ): string {
		$id = 'ec-f-' . $name;
		return '<label class="ec-ws-field" for="' . esc_attr( $id ) . '"><span class="ec-ws-label">' . esc_html( $label ) . '</span>' . ( $help ? '<span class="ec-muted" id="' . esc_attr( $id ) . '-h">' . esc_html( $help ) . '</span>' : '' ) . '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="' . (int) $rows . '"' . ( $help ? ' aria-describedby="' . esc_attr( $id ) . '-h"' : '' ) . '>' . esc_textarea( $value ) . '</textarea></label>';
	}

	public static function field_select( string $name, string $label, array $options, string $value ): string {
		$id = 'ec-f-' . $name;
		$o  = '<label class="ec-ws-field" for="' . esc_attr( $id ) . '"><span class="ec-ws-label">' . esc_html( $label ) . '</span><select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
		foreach ( $options as $k => $v ) {
			$o .= '<option value="' . esc_attr( (string) $k ) . '"' . selected( $value, (string) $k, false ) . '>' . esc_html( $v ) . '</option>';
		}
		return $o . '</select></label>';
	}

	/** WordPress's classic editor (TinyMCE + media library) on the front end. */
	private static function editor( string $name, string $id, string $content, int $rows ): string {
		ob_start();
		wp_editor(
			$content,
			$id,
			array(
				'textarea_name' => $name,
				'textarea_rows' => $rows,
				'media_buttons' => current_user_can( 'upload_files' ),
				'teeny'         => false,
				'tinymce'       => array( 'toolbar1' => 'formatselect,bold,italic,underline,strikethrough,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,hr,removeformat,undo,redo', 'toolbar2' => '' ),
				'quicktags'     => true,
			)
		);
		return (string) ob_get_clean();
	}
}
