<?php
namespace EduCore\Recovery;

defined( 'ABSPATH' ) || exit;

final class Settings {
	public const OPTION = 'educore_rc_settings';

	public static function defaults(): array {
		return array(
			'daily'          => 'on',   // Academic data (database) backup every day.
			'weekly'         => 'on',   // Full backup (database + files) every week.
			'keep_daily'     => 7,
			'keep_weekly'    => 4,
			'keep_predeploy' => 5,
			'keep_manual'    => 10,
			'predeploy'      => 'on',   // Backup before EduCore packages are installed/updated.
			'max_file_mb'    => 0,      // 0 = no per-file limit for full backups.
		);
	}

	public static function all(): array {
		return array_merge( self::defaults(), (array) get_option( self::OPTION, array() ) );
	}

	/** @return mixed */
	public static function get( string $k ) {
		return self::all()[ $k ] ?? null;
	}

	public static function save( array $in ): void {
		$out = self::all();
		foreach ( self::defaults() as $k => $d ) {
			if ( is_int( $d ) ) {
				$out[ $k ] = max( 0, min( 365, absint( $in[ $k ] ?? $d ) ) );
			} else {
				$out[ $k ] = ( isset( $in[ $k ] ) && 'on' === $in[ $k ] ) ? 'on' : 'off';
			}
		}
		$out['keep_daily']  = max( 1, $out['keep_daily'] );
		$out['keep_weekly'] = max( 1, $out['keep_weekly'] );
		update_option( self::OPTION, $out, false );
	}

	public const KEY_DIR_OPTION = 'educore_rc_key_dir';

	/**
	 * Encryption key (32 bytes). Sources, in order: EDUCORE_BACKUP_KEY in wp-config.php, or a key file kept
	 * OUTSIDE the web root in its own directory (separate from the archives). Never stored in the database
	 * and never written into a backup.
	 */
	public static function key(): ?string {
		if ( ! function_exists( 'sodium_crypto_secretstream_xchacha20poly1305_init_push' ) ) {
			return null;
		}
		$raw = null;
		if ( defined( 'EDUCORE_BACKUP_KEY' ) ) {
			$raw = (string) EDUCORE_BACKUP_KEY;
		} elseif ( ( $f = self::key_file() ) && is_readable( $f ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
			$raw = trim( (string) file_get_contents( $f ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		$k = null === $raw ? false : base64_decode( $raw, true );
		return ( false !== $k && SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_KEYBYTES === strlen( $k ) ) ? $k : null;
	}

	public static function key_source(): string {
		if ( defined( 'EDUCORE_BACKUP_KEY' ) ) {
			return self::key() ? 'wp-config' : 'invalid';
		}
		return self::key() ? 'key-file' : 'none';
	}

	/** Public, non-secret identifier of a key (shown in the UI and stored in archive headers). */
	public static function key_id( ?string $key = null ): string {
		$key = $key ?? self::key();
		return $key ? substr( hash( 'sha256', 'educore-backup-key-id|' . $key ), 0, 16 ) : '';
	}

	public static function key_file(): string {
		$d = (string) get_option( self::KEY_DIR_OPTION, '' );
		return $d ? $d . '/backup.key' : '';
	}

	/**
	 * Create a key file outside the web root (refused if only in-web-root locations are writable).
	 *
	 * @return true|\WP_Error
	 */
	public static function generate_key_file() {
		if ( self::key() ) {
			return new \WP_Error( 'ec_rc_key_exists', __( 'An encryption key is already configured.', 'educore-recovery' ) );
		}
		$parent = dirname( untrailingslashit( ABSPATH ) );
		$dir    = $parent . '/educore-keys-' . bin2hex( random_bytes( 6 ) );
		if ( ! wp_is_writable( $parent ) || ! @mkdir( $dir, 0700 ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
			return new \WP_Error( 'ec_rc_key_dir', __( 'No writable location outside the web root. Add EDUCORE_BACKUP_KEY to wp-config.php instead.', 'educore-recovery' ) );
		}
		file_put_contents( $dir . '/.htaccess', "Require all denied\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$f   = $dir . '/backup.key';
		$old = umask( 0077 );
		file_put_contents( $f, base64_encode( random_bytes( SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_KEYBYTES ) ) . "\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		umask( $old );
		@chmod( $f, 0600 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		update_option( self::KEY_DIR_OPTION, $dir, false );
		delete_option( 'educore_rc_key_downloaded' );
		return true;
	}

	/** Base64 key text for the owner's offline copy (only via the authenticated download). */
	public static function key_export(): string {
		$k = self::key();
		return $k ? base64_encode( $k ) : '';
	}

	/** Secret token for the reliable cron URL (stored hashed). */
	public static function cron_token( bool $regenerate = false ): string {
		$plain = '';
		if ( $regenerate || ! get_option( 'educore_rc_cron_hash' ) ) {
			$plain = bin2hex( random_bytes( 16 ) );
			update_option( 'educore_rc_cron_hash', hash( 'sha256', $plain ), false );
		}
		return $plain;
	}
}
