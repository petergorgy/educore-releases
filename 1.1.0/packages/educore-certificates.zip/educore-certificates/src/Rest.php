<?php
namespace EduCore\Certificates;

use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

final class Rest {

	public static function routes( string $ns ): void {
		register_rest_route(
			$ns,
			'/certificates/verify/(?P<uid>[A-Za-z0-9-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'verify' ),
				'permission_callback' => '__return_true', // Public verification; returns no contact data; rate limited.
			)
		);
		register_rest_route(
			$ns,
			'/me/certificates',
			array(
				'methods'             => 'GET',
				'callback'            => static fn() => new \WP_REST_Response(
					array_map(
						static fn( $c ) => array_merge( Certificates::public_view( $c ), array( 'download_url' => Download::url( $c['uid'] ), 'verify_url' => Verify::url( $c['uid'] ) ) ),
						Certificates::for_user( get_current_user_id() )
					)
				),
				'permission_callback' => 'is_user_logged_in',
			)
		);
		register_rest_route(
			$ns,
			'/certificates',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'issue' ),
				'permission_callback' => static fn() => current_user_can( 'ec_manage_certificates' ),
				'args'                => array(
					'user_id'   => array( 'type' => 'integer', 'required' => true, 'minimum' => 1 ),
					'course_id' => array( 'type' => 'integer', 'required' => true, 'minimum' => 1 ),
				),
			)
		);
		register_rest_route(
			$ns,
			'/certificates/(?P<id>\d+)/revoke',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'revoke' ),
				'permission_callback' => static fn() => current_user_can( 'ec_manage_certificates' ),
				'args'                => array( 'reason' => array( 'type' => 'string', 'required' => true, 'minLength' => 3 ) ),
			)
		);
	}

	public static function verify( \WP_REST_Request $r ) {
		if ( ! RateLimiter::hit( 'verify' ) ) {
			return new \WP_Error( 'educore_throttled', __( 'Too many requests.', 'educore-certificates' ), array( 'status' => 429 ) );
		}
		$c = Certificates::by_uid( strtolower( (string) $r['uid'] ) );
		if ( ! $c ) {
			return new \WP_Error( 'educore_not_found', __( 'No certificate exists with this ID.', 'educore-certificates' ), array( 'status' => 404 ) );
		}
		return new \WP_REST_Response( Certificates::public_view( $c ) );
	}

	public static function issue( \WP_REST_Request $r ) {
		$id = Certificates::issue( (int) $r['user_id'], (int) $r['course_id'] );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$c = Certificates::get( $id );
		return new \WP_REST_Response( array( 'id' => $id, 'certificate_id' => $c['uid'] ), 201 );
	}

	public static function revoke( \WP_REST_Request $r ) {
		return Certificates::revoke( (int) $r['id'], (string) $r['reason'] )
			? new \WP_REST_Response( array( 'revoked' => true ) )
			: new \WP_Error( 'educore_not_found', __( 'Certificate not found or already revoked.', 'educore-certificates' ), array( 'status' => 404 ) );
	}
}
