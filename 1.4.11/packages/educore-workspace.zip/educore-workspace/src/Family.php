<?php
namespace EduCore\Workspace;

use EduCore\Core\Audit;
use EduCore\Core\Privacy;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Support plans shared with the learner and guardians (opt-in per plan by the teaching team).
 * Visible: course, concern, action plan, follow-up date, status, owner, outcome. Never: timeline notes, reason code.
 * Learner: "Your support plans" on My learning. Guardian: section on the guardian portal (verified link only).
 * Weekly e-mail digest to verified guardians of plans changed since the last digest.
 */
final class Family {
	public const CRON = 'educore_ws_family_digest';
	public const LAST = 'educore_ws_family_digest_last';

	public static function register(): void {
		add_filter( 'educore/dashboard/student_sections', array( self::class, 'learner_section' ), 15, 3 );
		add_action( self::CRON, array( self::class, 'digest' ) );
		add_action(
			'init',
			static function () {
				if ( ! wp_next_scheduled( self::CRON ) ) {
					wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', self::CRON );
				}
			},
			30
		);
	}

	/** Shared plans of a learner: active ones plus those resolved/closed in the last 30 days. */
	public static function plans( int $learner_id ): array {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT id, course_id, owner_id, summary, plan, status, due_on, outcome, updated_at FROM ' . Schema::table( 'ws_interventions' ) . " WHERE learner_id=%d AND shared=1 AND ( status IN ('open','in_progress') OR updated_at >= %s ) ORDER BY FIELD(status,'open','in_progress','resolved','closed'), due_on ASC", $learner_id, $since ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	private static function card( array $p ): string {
		$st  = Success::status_labels()[ $p['status'] ] ?? $p['status'];
		$own = get_userdata( (int) $p['owner_id'] );
		$o   = '<li><div><p><strong>' . esc_html( get_the_title( (int) $p['course_id'] ) ) . '</strong> <span class="ec-chip">' . esc_html( $st ) . '</span></p>';
		$o  .= '<p>' . esc_html( $p['summary'] ) . '</p>';
		if ( $p['plan'] ) {
			$o .= '<p class="ec-muted">' . nl2br( esc_html( $p['plan'] ) ) . '</p>';
		}
		$meta = array();
		if ( $own ) {
			/* translators: %s: staff member name */
			$meta[] = sprintf( __( 'Contact: %s', 'educore-workspace' ), $own->display_name );
		}
		if ( $p['due_on'] && in_array( $p['status'], array( 'open', 'in_progress' ), true ) ) {
			/* translators: %s: date */
			$meta[] = sprintf( __( 'Next check: %s', 'educore-workspace' ), mysql2date( get_option( 'date_format' ), $p['due_on'] ) );
		}
		if ( $p['outcome'] && in_array( $p['status'], array( 'resolved', 'closed' ), true ) ) {
			/* translators: %s: outcome text */
			$meta[] = sprintf( __( 'Outcome: %s', 'educore-workspace' ), $p['outcome'] );
		}
		return $o . ( $meta ? '<p class="ec-muted">' . esc_html( implode( ' · ', $meta ) ) . '</p>' : '' ) . '</div></li>';
	}

	public static function learner_section( $html, $d, $uid ) {
		$plans = self::plans( (int) $uid );
		if ( ! $plans ) {
			return $html;
		}
		return $html . '<section class="ec-card ec-ws-section ec-family" aria-labelledby="ec-fam-h"><h2 id="ec-fam-h">' . esc_html__( 'Your support plans', 'educore-workspace' ) . '</h2><p class="ec-muted">' . esc_html__( 'Your teachers set up these plans to help you. Talk to the contact named on each plan if you have questions.', 'educore-workspace' ) . '</p><ul class="ec-ws-list ec-ws-list--stack">' . implode( '', array_map( array( self::class, 'card' ), $plans ) ) . '</ul></section>';
	}

	/** Guardian portal section for one learner; caller has already checked the guardian link. */
	public static function guardian_section( int $guardian_id, int $learner_id ): string {
		if ( ! Privacy::guardian_has_access( $guardian_id, $learner_id ) ) {
			return '';
		}
		$plans = self::plans( $learner_id );
		$o     = '<section class="ec-card ec-ws-section"><h3>' . esc_html__( 'Support plans', 'educore-workspace' ) . '</h3>';
		if ( ! $plans ) {
			return $o . '<p class="ec-muted">' . esc_html__( 'No support plan has been shared with you.', 'educore-workspace' ) . '</p></section>';
		}
		return $o . '<ul class="ec-ws-list ec-ws-list--stack">' . implode( '', array_map( array( self::class, 'card' ), $plans ) ) . '</ul></section>';
	}

	/** @return string[] verified guardian e-mail addresses of a learner */
	public static function guardian_emails( int $learner_id ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT guardian_email, guardian_user_id FROM ' . Schema::table( 'guardian_links' ) . " WHERE student_id=%d AND status='verified'", $learner_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		$out  = array();
		foreach ( $rows as $r ) {
			$u     = (int) $r['guardian_user_id'] ? get_userdata( (int) $r['guardian_user_id'] ) : null;
			$email = $u ? $u->user_email : (string) $r['guardian_email'];
			if ( is_email( $email ) ) {
				$out[ strtolower( $email ) ] = $email;
			}
		}
		return array_values( $out );
	}

	/**
	 * Weekly digest: for each learner with a shared plan changed since the last run, one e-mail per verified guardian.
	 *
	 * @return array{learners:int,emails:int}
	 */
	public static function digest( ?int $now = null ): array {
		global $wpdb;
		$now   = $now ?? time();
		$since = (string) get_option( self::LAST, gmdate( 'Y-m-d H:i:s', $now - 7 * DAY_IN_SECONDS ) );
		$until = gmdate( 'Y-m-d H:i:s', $now );
		$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'ws_interventions' ) . ' WHERE shared=1 AND updated_at > %s AND updated_at <= %s ORDER BY learner_id, id', $since, $until ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		$by    = array();
		foreach ( $rows as $r ) {
			$by[ (int) $r['learner_id'] ][] = $r;
		}
		$sent = 0;
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		foreach ( $by as $learner => $plans ) {
			$to = self::guardian_emails( $learner );
			$u  = get_userdata( $learner );
			if ( ! $to || ! $u ) {
				continue;
			}
			/* translators: 1: site name, 2: learner name */
			$subject = sprintf( __( '[%1$s] Weekly update: support plans for %2$s', 'educore-workspace' ), $site, $u->display_name );
			/* translators: %s: learner name */
			$lines = array( __( 'Hello,', 'educore-workspace' ), '', sprintf( __( 'The school updated the following support plans for %s this week:', 'educore-workspace' ), $u->display_name ), '' );
			foreach ( $plans as $p ) {
				$lines[] = '• ' . get_the_title( (int) $p['course_id'] ) . ' — ' . ( Success::status_labels()[ $p['status'] ] ?? $p['status'] );
				$lines[] = '  ' . $p['summary'];
				if ( $p['outcome'] && in_array( $p['status'], array( 'resolved', 'closed' ), true ) ) {
					/* translators: %s: outcome */
					$lines[] = '  ' . sprintf( __( 'Outcome: %s', 'educore-workspace' ), $p['outcome'] );
				} elseif ( $p['due_on'] ) {
					/* translators: %s: date */
					$lines[] = '  ' . sprintf( __( 'Next check: %s', 'educore-workspace' ), mysql2date( get_option( 'date_format' ), $p['due_on'] ) );
				}
				$lines[] = '';
			}
			/* translators: %s: URL of the guardian page */
			$lines[] = sprintf( __( 'See the details on your guardian page: %s', 'educore-workspace' ), \EduCore\Core\Pages::url( 'guardian' ) );
			$lines[] = __( 'You receive this because the school shared these plans with the learner’s guardians. Contact the school to stop sharing.', 'educore-workspace' );
			foreach ( $to as $email ) {
				if ( wp_mail( $email, $subject, implode( "\n", $lines ) ) ) {
					++$sent;
				}
			}
		}
		update_option( self::LAST, $until, false );
		if ( $by ) {
			Audit::log( 'success.family_digest', 'system', 0, array( 'learners' => count( $by ), 'emails' => $sent ) );
		}
		return array( 'learners' => count( $by ), 'emails' => $sent );
	}
}
