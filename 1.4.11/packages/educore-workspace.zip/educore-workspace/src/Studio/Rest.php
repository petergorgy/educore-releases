<?php
namespace EduCore\Workspace\Studio;

use EduCore\Core\Content;
use EduCore\Core\Curriculum;
use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/** `educore/v1/studio/*`. Permission callbacks gate by capability; Courses re-checks every object. */
final class Rest {
	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	public static function routes(): void {
		$author = static fn() => Courses::can_author( get_current_user_id() );
		$pub    = static fn() => Courses::can_publish( get_current_user_id() );
		$prog   = static fn() => current_user_can( 'ec_manage_programmes' );
		$id     = array( 'id' => array( 'type' => 'integer', 'required' => true, 'minimum' => 1 ) );
		$r      = static function ( string $route, string $m, callable $cb, callable $perm, array $args = array() ) {
			register_rest_route( 'educore/v1', $route, array( 'methods' => $m, 'callback' => $cb, 'permission_callback' => $perm, 'args' => $args ) );
		};
		$r( '/studio/courses', 'POST', array( self::class, 'create' ), $author, array( 'title' => array( 'type' => 'string', 'required' => true ) ) );
		$r( '/studio/courses/(?P<id>\d+)', 'POST', array( self::class, 'save' ), $author, $id );
		$r( '/studio/courses/(?P<id>\d+)/units', 'POST', array( self::class, 'unit' ), $author, $id + array( 'title' => array( 'type' => 'string', 'required' => true ) ) );
		$r( '/studio/courses/(?P<id>\d+)/outline', 'POST', array( self::class, 'outline' ), $author, $id + array( 'outline' => array( 'type' => 'array', 'required' => true ) ) );
		$r( '/studio/courses/(?P<id>\d+)/duplicate', 'POST', array( self::class, 'duplicate' ), $author, $id );
		$r( '/studio/courses/(?P<id>\d+)/translate', 'POST', array( self::class, 'translate' ), $author, $id + array( 'lang' => array( 'type' => 'string', 'required' => true ) ) );
		$r( '/studio/courses/(?P<id>\d+)/submit', 'POST', array( self::class, 'submit' ), $author, $id );
		$r( '/studio/courses/(?P<id>\d+)/publish', 'POST', array( self::class, 'publish' ), $pub, $id + array( 'when' => array( 'type' => 'string', 'default' => '' ) ) );
		$r( '/studio/courses/(?P<id>\d+)/reject', 'POST', array( self::class, 'reject' ), $pub, $id + array( 'note' => array( 'type' => 'string', 'required' => true ) ) );
		$r( '/studio/units/(?P<id>\d+)/lessons', 'POST', array( self::class, 'lesson_new' ), $author, $id + array( 'title' => array( 'type' => 'string', 'required' => true ) ) );
		$r( '/studio/items/(?P<id>\d+)', 'POST', array( self::class, 'rename' ), $author, $id + array( 'title' => array( 'type' => 'string', 'required' => true ) ) );
		$r( '/studio/items/(?P<id>\d+)', 'DELETE', array( self::class, 'trash' ), $author, $id );
		$r( '/studio/lessons/(?P<id>\d+)', 'POST', array( self::class, 'lesson' ), $author, $id );
		$r( '/studio/lessons/(?P<id>\d+)/autosave', 'POST', array( self::class, 'autosave' ), $author, $id );
		$r( '/studio/revisions/(?P<id>\d+)/restore', 'POST', array( self::class, 'restore' ), $author, $id );
		$r( '/studio/programmes', 'POST', array( self::class, 'programme' ), $prog, array( 'code' => array( 'type' => 'string', 'required' => true ), 'name' => array( 'type' => 'string', 'required' => true ) ) );
		$r( '/studio/programmes/(?P<id>\d+)/periods', 'POST', array( self::class, 'period' ), $prog, $id + array( 'label' => array( 'type' => 'string', 'required' => true ) ) );
		$r( '/studio/programmes/(?P<id>\d+)/subjects', 'POST', array( self::class, 'subject' ), $prog, $id + array( 'code' => array( 'type' => 'string', 'required' => true ), 'name' => array( 'type' => 'string', 'required' => true ) ) );
	}

	private static function guard() {
		return RateLimiter::hit( 'rest_write' ) ? null : new \WP_Error( 'ec_ws_rate', __( 'Too many changes in a short time. Please wait a moment.', 'educore-workspace' ), array( 'status' => 429 ) );
	}

	private static function out( $r, array $extra = array(), int $status = 200 ) {
		return is_wp_error( $r ) ? $r : new \WP_REST_Response( array( 'ok' => true ) + $extra, $status );
	}

	private static function uid(): int {
		return get_current_user_id();
	}

	public static function create( \WP_REST_Request $q ) {
		$r = self::guard() ?? Courses::create( self::uid(), $q->get_params() );
		return is_wp_error( $r ) ? $r : self::out( true, array( 'id' => $r, 'url' => View::url( array( 'course' => $r, 'step' => 'basics', 'ec_msg' => 'created' ) ) ), 201 );
	}

	public static function save( \WP_REST_Request $q ) {
		$in = array_intersect_key( $q->get_params(), array_flip( array( 'title', 'excerpt', 'content', 'difficulty', 'grade_level', 'duration_hours', 'objectives', 'prerequisites', 'assessment_req', 'enroll_mode', 'lang', 'cover_id', 'programme_id', 'period_id', 'subject_id' ) ) );
		return self::guard() ?? self::out( Courses::save( self::uid(), (int) $q['id'], $in ) );
	}

	/** Same rule as core's admin-post handler: ec_edit_course on the source + edit_ec_courses. */
	public static function translate( \WP_REST_Request $q ) {
		$cid = (int) $q['id'];
		if ( ! Content::is_course( $cid ) || ! current_user_can( 'ec_edit_course', $cid ) || ! current_user_can( 'edit_ec_courses' ) ) {
			return new \WP_Error( 'ec_studio_forbidden', __( 'You cannot change this course.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$r = self::guard() ?? \EduCore\Core\Translations::create_course_translation( $cid, (string) $q['lang'], self::uid() );
		if ( is_wp_error( $r ) ) {
			return new \WP_Error( $r->get_error_code(), $r->get_error_message(), array( 'status' => 409 ) );
		}
		if ( ! current_user_can( 'ec_manage_all_courses' ) && ! \EduCore\Core\Staff::role_of( self::uid(), (int) $r ) ) {
			\EduCore\Core\Staff::assign( (int) $r, self::uid(), \EduCore\Core\Staff::role_of( self::uid(), $cid ) ?: 'lead' ); // Safety net: core normally staffs the creator on the copy.
		}
		return self::out( true, array( 'id' => (int) $r, 'url' => View::url( array( 'course' => (int) $r, 'ec_msg' => 'copied' ) ) ), 201 );
	}

	public static function unit( \WP_REST_Request $q ) {
		$r = self::guard() ?? Courses::add_unit( self::uid(), (int) $q['id'], (string) $q['title'] );
		return is_wp_error( $r ) ? $r : self::out( true, array( 'id' => $r ), 201 );
	}

	public static function lesson_new( \WP_REST_Request $q ) {
		$r = self::guard() ?? Courses::add_lesson( self::uid(), (int) $q['id'], (string) $q['title'] );
		return is_wp_error( $r ) ? $r : self::out( true, array( 'id' => $r ), 201 );
	}

	public static function outline( \WP_REST_Request $q ) {
		return self::guard() ?? self::out( Courses::reorder( self::uid(), (int) $q['id'], (array) $q['outline'] ) );
	}

	public static function rename( \WP_REST_Request $q ) {
		return self::guard() ?? self::out( Courses::rename( self::uid(), (int) $q['id'], (string) $q['title'] ) );
	}

	public static function trash( \WP_REST_Request $q ) {
		return self::guard() ?? self::out( Courses::trash( self::uid(), (int) $q['id'] ) );
	}

	public static function duplicate( \WP_REST_Request $q ) {
		$r = self::guard() ?? Courses::duplicate( self::uid(), (int) $q['id'] );
		return is_wp_error( $r ) ? $r : self::out( true, array( 'id' => $r, 'url' => View::url( array( 'course' => $r, 'ec_msg' => 'copied' ) ) ), 201 );
	}

	public static function submit( \WP_REST_Request $q ) {
		return self::guard() ?? self::out( Courses::submit( self::uid(), (int) $q['id'] ) );
	}

	public static function publish( \WP_REST_Request $q ) {
		$when = trim( (string) $q['when'] );
		$gmt  = '';
		if ( '' !== $when ) {
			$local = \DateTime::createFromFormat( 'Y-m-d\TH:i', $when, wp_timezone() );
			if ( ! $local ) {
				return new \WP_Error( 'ec_studio_date', __( 'Enter a valid date and time.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'when' => 'invalid' ) ) );
			}
			$gmt = $local->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		}
		$r = self::guard() ?? Courses::publish( self::uid(), (int) $q['id'], $gmt );
		return is_wp_error( $r ) ? $r : self::out( true, array( 'url' => View::url( array( 'course' => (int) $q['id'], 'step' => 'review', 'ec_msg' => $gmt ? 'scheduled' : 'published' ) ) ) );
	}

	public static function reject( \WP_REST_Request $q ) {
		return self::guard() ?? self::out( Courses::reject( self::uid(), (int) $q['id'], (string) $q['note'] ) );
	}

	public static function lesson( \WP_REST_Request $q ) {
		$in = array_intersect_key( $q->get_params(), array_flip( array( 'title', 'content', 'minutes', 'objectives', 'summary', 'completion_rule', 'completion_secs', 'lang', 'unit_id' ) ) );
		return self::guard() ?? self::out( Courses::save_lesson( self::uid(), (int) $q['id'], $in ) );
	}

	public static function autosave( \WP_REST_Request $q ) {
		return self::out( Courses::autosave( self::uid(), (int) $q['id'], $q->get_params() ) );
	}

	public static function restore( \WP_REST_Request $q ) {
		return self::guard() ?? self::out( Courses::restore_revision( self::uid(), (int) $q['id'] ) );
	}

	public static function programme( \WP_REST_Request $q ) {
		$r = self::guard() ?? Curriculum::create_programme( (string) $q['code'], (string) $q['name'], 'EG', (string) ( $q['lang'] ?? 'en' ) );
		return is_wp_error( $r ) ? $r : self::out( true, array( 'id' => $r ), 201 );
	}

	public static function period( \WP_REST_Request $q ) {
		$r = self::guard() ?? Curriculum::add_period( (int) $q['id'], (string) ( $q['type'] ?? 'year' ), sanitize_text_field( (string) $q['label'] ) );
		return is_wp_error( $r ) ? $r : self::out( true, array( 'id' => $r ), 201 );
	}

	public static function subject( \WP_REST_Request $q ) {
		$r = self::guard() ?? Curriculum::add_subject( (int) $q['id'], sanitize_key( (string) $q['code'] ), sanitize_text_field( (string) $q['name'] ) );
		return is_wp_error( $r ) ? $r : self::out( true, array( 'id' => $r ), 201 );
	}
}
