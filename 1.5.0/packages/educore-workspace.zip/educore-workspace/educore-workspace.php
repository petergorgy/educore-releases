<?php
/**
 * Plugin Name:       EduCore Workspace
 * Plugin URI:        https://educore.gorgy.org
 * Description:       The EduCore application shell and frontend administration: EduCore Management, people and profiles, guardian and tutor workspaces, role-aware navigation. WordPress stays the engine; everyday users never need wp-admin.
 * Version:           1.9.0
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core
 * EduCore Requires Core: 1.2.0
 * Author:            GORGY.ORG
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-workspace
 * Domain Path:       /languages
 *
 * @package EduCore\Workspace
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_WS_VERSION', '1.9.0' );
define( 'EDUCORE_WS_FILE', __FILE__ );
define( 'EDUCORE_WS_DIR', plugin_dir_path( __FILE__ ) );
define( 'EDUCORE_WS_URL', plugin_dir_url( __FILE__ ) );

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Workspace', '1.2.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Workspace\\', EDUCORE_WS_DIR . 'src/' );
		\EduCore\Workspace\Plugin::boot();
	}
);

register_activation_hook(
	__FILE__,
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) || version_compare( EDUCORE_CORE_VERSION, '1.2.0', '<' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die( esc_html__( 'EduCore Workspace needs EduCore Core 1.2.0 or newer.', 'educore-workspace' ), '', array( 'back_link' => true ) );
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Workspace\\', EDUCORE_WS_DIR . 'src/' );
		\EduCore\Workspace\Plugin::install();
	}
);
