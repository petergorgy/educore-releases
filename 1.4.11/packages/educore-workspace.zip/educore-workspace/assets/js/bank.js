/* EduCore Question Bank & Assessment Builder: type-dependent fields, pool rows, validated file upload.
   Event delegation, so it keeps working after partial refreshes. Server-side checks are authoritative. */
( function () {
	'use strict';
	var app = window.EduCoreWSApp;
	var cfg = window.EduCoreWS || {};
	var t = cfg.i18n || {};
	if ( ! app ) { return; }

	// ---------- Question editor: show only the fields the selected type uses ----------
	function syncTypes( form ) {
		var sel = form.querySelector( 'select[name="type"]' );
		if ( ! sel ) { return; }
		form.querySelectorAll( '[data-ec-types]' ).forEach( function ( box ) {
			var on = box.getAttribute( 'data-ec-types' ).split( ',' ).indexOf( sel.value ) !== -1;
			box.hidden = ! on;
			box.querySelectorAll( 'input, select, textarea, button' ).forEach( function ( f ) { f.disabled = ! on; } );
		} );
	}
	function initForms( root ) {
		root.querySelectorAll( 'form[data-ec-bank-form]' ).forEach( syncTypes );
		root.querySelectorAll( '[data-ec-pools]' ).forEach( renumber );
	}
	document.addEventListener( 'change', function ( e ) {
		if ( e.target.matches( 'form[data-ec-bank-form] select[name="type"]' ) ) { syncTypes( e.target.form ); }
	} );

	// ---------- Assessment pools ----------
	function renumber( wrap ) {
		wrap.querySelectorAll( '[data-ec-pool] legend' ).forEach( function ( l, i ) {
			l.textContent = ( t.pool || 'Question pool' ) + ' ' + ( i + 1 );
		} );
	}
	document.addEventListener( 'click', function ( e ) {
		var add = e.target.closest( '[data-ec-pool-add]' );
		var rm = e.target.closest( '[data-ec-pool-remove]' );
		if ( add ) {
			var fs = add.closest( 'fieldset' );
			var wrap = fs.querySelector( '[data-ec-pools]' );
			var tpl = fs.querySelector( 'template[data-ec-pool-template]' );
			if ( wrap.children.length >= 30 ) { app.toast( t.poolMax || 'Maximum 30 pools.', 'error' ); return; }
			wrap.appendChild( tpl.content.cloneNode( true ) );
			renumber( wrap );
			app.setDirty( true );
			var last = wrap.lastElementChild && wrap.lastElementChild.querySelector( 'select, input' );
			if ( last ) { last.focus(); }
		}
		if ( rm ) {
			var w = rm.closest( '[data-ec-pools]' );
			rm.closest( '[data-ec-pool]' ).remove();
			renumber( w );
			app.setDirty( true );
			var next = w.closest( 'fieldset' ).querySelector( '[data-ec-pool-add]' );
			if ( next ) { next.focus(); }
		}
	} );

	// ---------- Import upload (multipart; validated again on the server) ----------
	document.addEventListener( 'submit', function ( e ) {
		var form = e.target.closest( 'form[data-ec-upload]' );
		if ( ! form ) { return; }
		e.preventDefault();
		var file = form.querySelector( 'input[type="file"]' );
		var box = form.querySelector( '.ec-ws-form-error' );
		function fail( msg ) {
			if ( ! box ) { box = document.createElement( 'div' ); box.className = 'ec-notice ec-notice--error ec-ws-form-error'; box.setAttribute( 'role', 'alert' ); box.tabIndex = -1; form.prepend( box ); }
			box.textContent = msg; box.focus();
			if ( btn ) { btn.disabled = false; btn.removeAttribute( 'aria-busy' ); }
		}
		var btn = form.querySelector( '[type="submit"]' );
		if ( ! file.files.length ) { file.setAttribute( 'aria-invalid', 'true' ); fail( t.chooseFile || 'Choose a file.' ); return; }
		if ( file.files[ 0 ].size > 10 * 1024 * 1024 ) { file.setAttribute( 'aria-invalid', 'true' ); fail( t.tooLarge || 'The file is larger than 10 MB.' ); return; }
		file.removeAttribute( 'aria-invalid' );
		btn.disabled = true; btn.setAttribute( 'aria-busy', 'true' );
		fetch( cfg.rest + form.getAttribute( 'data-ec-upload' ), {
			method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': cfg.nonce }, body: new FormData( form )
		} ).then( function ( r ) {
			return r.json().catch( function () { return {}; } ).then( function ( j ) {
				if ( ! r.ok ) { throw new Error( ( j && j.message ) || t.error ); }
				return j;
			} );
		} ).then( function ( j ) { location.assign( j.url ); } ).catch( function ( err ) { fail( err.message || t.error ); } );
	} );

	initForms( document );
	// Re-sync after partial refreshes (workspace.js replaces the main region).
	var main = document.querySelector( '[data-ec-main]' );
	if ( main && window.MutationObserver ) {
		new MutationObserver( function () { initForms( main ); } ).observe( main, { childList: true } );
	}
}() );
