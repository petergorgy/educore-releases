<?php
namespace EduCore\Assessments\Exchange;

defined( 'ABSPATH' ) || exit;

/**
 * Moodle XML question format.
 * Supported: multichoice (single/multiple, fractions), truefalse, shortanswer, numerical (exact → short),
 * essay (graderinfo → model answer), matching; category → tag; tags; defaultgrade → points;
 * generalfeedback → explanation; idnumber/name → external id.
 * Not supported (reported per item): cloze/multianswer, ddwtos, gapselect, calculated*, random, description.
 */
final class MoodleXml {

	private static function text( \SimpleXMLElement $node ): string {
		$fmt = (string) ( $node['format'] ?? 'html' );
		$t   = (string) $node->text;
		if ( str_contains( $t, '@@PLUGINFILE@@' ) ) {
			$t = (string) preg_replace( '#<img[^>]+@@PLUGINFILE@@[^>]*>#i', '', $t );
		}
		return in_array( $fmt, array( 'html', 'markdown' ), true ) ? $t : nl2br( esc_html( $t ), false );
	}

	/** @return array<int,array{record:?array,error:?string,warnings:string[]}>|\WP_Error keyed by question number */
	public static function read( string $raw ) {
		$x = Xlsx::xml( (string) preg_replace( '/^\xEF\xBB\xBF/', '', $raw ) );
		if ( ! $x || 'quiz' !== $x->getName() ) {
			return new \WP_Error( 'ec_x_xml', __( 'This is not a Moodle XML question file (<quiz> root expected; DOCTYPE is not allowed).', 'educore-assessments' ) );
		}
		$out = array();
		$cat = '';
		$n   = 0;
		foreach ( $x->question as $q ) {
			$type = (string) $q['type'];
			if ( 'category' === $type ) {
				$cat = trim( (string) $q->category->text );
				continue;
			}
			++$n;
			$out[ $n ] = self::question( $q, $type, $cat );
		}
		return $out;
	}

	/** @return array{record:?array,error:?string,warnings:string[]} */
	private static function question( \SimpleXMLElement $q, string $type, string $cat ): array {
		$warn = array();
		$tags = array();
		if ( '' !== $cat ) {
			$tags[] = 'cat-' . sanitize_title( (string) preg_replace( '#^\$\w+\$/?#', '', $cat ) );
		}
		foreach ( $q->tags->tag ?? array() as $tg ) {
			$tags[] = (string) $tg->text;
		}
		$stem = isset( $q->questiontext ) ? self::text( $q->questiontext ) : '';
		if ( str_contains( (string) $q->questiontext->text, '@@PLUGINFILE@@' ) ) {
			$warn[] = __( 'Embedded files (images) in the question text were not imported.', 'educore-assessments' );
		}
		$rec = array(
			'external_id' => '' !== trim( (string) $q->idnumber ) ? (string) $q->idnumber : (string) $q->name->text,
			'stem'        => $stem,
			'explanation' => isset( $q->generalfeedback ) ? self::text( $q->generalfeedback ) : '',
			'points'      => isset( $q->defaultgrade ) ? (float) $q->defaultgrade : 1,
			'tags'        => $tags,
		);
		$answers = array();
		foreach ( $q->answer ?? array() as $a ) {
			$answers[] = array( 'fraction' => (float) $a['fraction'], 'text' => trim( self::text( $a ) ), 'plain' => trim( html_entity_decode( wp_strip_all_tags( (string) $a->text ), ENT_QUOTES, 'UTF-8' ) ), 'feedback' => '' !== trim( (string) ( $a->feedback->text ?? '' ) ) );
		}
		if ( array_filter( $answers, static fn( $a ) => $a['feedback'] ) ) {
			$warn[] = __( 'Answer feedback is not stored.', 'educore-assessments' );
		}
		switch ( $type ) {
			case 'multichoice':
				$opts    = array();
				$correct = array();
				$partial = false;
				foreach ( $answers as $i => $a ) {
					$id     = chr( 97 + $i );
					$opts[] = array( 'id' => $id, 'text' => wp_kses_post( (string) preg_replace( '#^<p>(.*)</p>$#s', '$1', $a['text'] ) ) );
					if ( $a['fraction'] > 0 ) {
						$correct[] = $id;
						if ( $a['fraction'] < 100 ) {
							$partial = true;
						}
					}
				}
				// Negative fractions on wrong answers = penalised guessing → EduCore all-or-nothing; otherwise partial credit.
				$partial = $partial && ! array_filter( $answers, static fn( $a ) => $a['fraction'] < 0 );
				$single  = in_array( strtolower( trim( (string) $q->single ) ), array( 'true', '1' ), true );
				if ( $single && 1 === count( $correct ) && ! $partial ) {
					return array( 'record' => $rec + array( 'type' => 'single', 'payload' => array( 'options' => $opts ), 'key' => array( 'correct' => $correct[0] ) ), 'error' => null, 'warnings' => $warn );
				}
				if ( $single ) {
					$warn[] = __( 'Single-answer question with several (partly) correct answers imported as multiple answer.', 'educore-assessments' );
				}
				$key = array( 'correct' => $correct );
				if ( $partial ) {
					$key['scoring'] = 'partial';
				}
				return array( 'record' => $rec + array( 'type' => 'multiple', 'payload' => array( 'options' => $opts ), 'key' => $key ), 'error' => null, 'warnings' => $warn );
			case 'truefalse':
				$true = false;
				foreach ( $answers as $a ) {
					if ( 100.0 === $a['fraction'] ) {
						$true = in_array( strtolower( $a['plain'] ), array( 'true', 'vrai', 'صح', 'صحيح' ), true );
					}
				}
				return array( 'record' => $rec + array( 'type' => 'truefalse', 'payload' => array(), 'key' => array( 'correct' => $true ) ), 'error' => null, 'warnings' => $warn );
			case 'shortanswer':
			case 'numerical':
				$acc = array_values( array_map( static fn( $a ) => $a['plain'], array_filter( $answers, static fn( $a ) => $a['fraction'] >= 100 && '*' !== $a['plain'] ) ) );
				if ( count( $acc ) < count( array_filter( $answers, static fn( $a ) => $a['fraction'] > 0 ) ) ) {
					$warn[] = __( 'Partially correct answers are not supported; only fully correct answers are kept.', 'educore-assessments' );
				}
				if ( 'numerical' === $type ) {
					$warn[] = __( 'Numerical question imported as short answer (exact value).', 'educore-assessments' );
				}
				return array( 'record' => $rec + array( 'type' => 'short', 'payload' => array(), 'key' => array( 'accepted' => $acc ) ), 'error' => $acc ? null : __( 'No fully correct answer.', 'educore-assessments' ), 'warnings' => $warn );
			case 'essay':
				return array( 'record' => $rec + array( 'type' => 'essay', 'payload' => array( 'min_words' => absint( $q->minwordlimit ?? 0 ) ), 'key' => array( 'model_answer' => isset( $q->graderinfo ) ? self::text( $q->graderinfo ) : '' ) ), 'error' => null, 'warnings' => $warn );
			case 'matching':
				$left  = array();
				$right = array();
				$pairs = array();
				$i     = 0;
				foreach ( $q->subquestion as $sq ) {
					++$i;
					$r       = trim( (string) $sq->answer->text );
					$right[] = array( 'id' => 'r' . $i, 'text' => esc_html( $r ) );
					$l       = trim( (string) preg_replace( '#^<p>(.*)</p>$#s', '$1', self::text( $sq ) ) );
					if ( '' !== $l ) {
						$left[]             = array( 'id' => 'l' . $i, 'text' => wp_kses_post( $l ) );
						$pairs[ 'l' . $i ] = 'r' . $i;
					}
				}
				return array( 'record' => $rec + array( 'type' => 'matching', 'payload' => array( 'left' => $left, 'right' => $right ), 'key' => array( 'pairs' => $pairs ) ), 'error' => null, 'warnings' => $warn );
		}
		/* translators: %s: Moodle question type */
		return array( 'record' => $rec + array( 'type' => $type ), 'error' => sprintf( __( 'Moodle question type "%s" is not supported.', 'educore-assessments' ), $type ), 'warnings' => array() );
	}

	private static function cdata( string $s ): string {
		return '<![CDATA[' . str_replace( ']]>', ']]]]><![CDATA[>', $s ) . ']]>';
	}

	private static function textnode( string $tag, string $html, string $fmt = 'html' ): string {
		return "<{$tag} format=\"{$fmt}\"><text>" . self::cdata( $html ) . "</text></{$tag}>";
	}

	public static function write( array $records, array &$skipped ): string {
		$x = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<quiz>\n";
		foreach ( $records as $r ) {
			$t    = $r['type'];
			$map  = array( 'single' => 'multichoice', 'multiple' => 'multichoice', 'truefalse' => 'truefalse', 'short' => 'shortanswer', 'essay' => 'essay', 'matching' => 'matching' );
			if ( ! isset( $map[ $t ] ) ) {
				/* translators: %s: question type */
				$skipped[] = $r['external_id'] . ': ' . sprintf( __( '%s questions cannot be represented in Moodle XML', 'educore-assessments' ), $t );
				continue;
			}
			$q  = '  <question type="' . $map[ $t ] . '">' . "\n";
			$q .= '    <name><text>' . esc_html( $r['external_id'] ) . "</text></name>\n";
			$q .= '    ' . self::textnode( 'questiontext', (string) $r['stem'] ) . "\n";
			$q .= '    ' . self::textnode( 'generalfeedback', (string) $r['explanation'] ) . "\n";
			$q .= '    <defaultgrade>' . (float) $r['points'] . "</defaultgrade>\n    <penalty>0</penalty>\n    <hidden>0</hidden>\n";
			$q .= '    <idnumber>' . esc_html( $r['external_id'] ) . "</idnumber>\n";
			switch ( $t ) {
				case 'single':
				case 'multiple':
					$correct = (array) $r['key']['correct'];
					$n       = count( $correct );
					$partial = 'partial' === ( $r['key']['scoring'] ?? '' );
					$q      .= '    <single>' . ( 'single' === $t ? 'true' : 'false' ) . "</single>\n    <shuffleanswers>true</shuffleanswers>\n    <answernumbering>abc</answernumbering>\n";
					foreach ( $r['payload']['options'] as $o ) {
						$ok = in_array( $o['id'], $correct, true );
						$f  = 'single' === $t ? ( $ok ? 100 : 0 ) : ( $ok ? round( 100 / $n, 5 ) : ( $partial ? 0 : round( -100 / max( 1, count( $r['payload']['options'] ) - $n ), 5 ) ) );
						$q .= '    <answer fraction="' . $f . '" format="html"><text>' . self::cdata( (string) $o['text'] ) . "</text></answer>\n";
					}
					break;
				case 'truefalse':
					$tv = ! empty( $r['key']['correct'] );
					$q .= '    <answer fraction="' . ( $tv ? 100 : 0 ) . "\" format=\"moodle_auto_format\"><text>true</text></answer>\n";
					$q .= '    <answer fraction="' . ( $tv ? 0 : 100 ) . "\" format=\"moodle_auto_format\"><text>false</text></answer>\n";
					break;
				case 'short':
					$q .= "    <usecase>0</usecase>\n";
					foreach ( (array) $r['key']['accepted'] as $a ) {
						$q .= '    <answer fraction="100" format="moodle_auto_format"><text>' . self::cdata( (string) $a ) . "</text></answer>\n";
					}
					break;
				case 'essay':
					$q .= "    <responseformat>editor</responseformat>\n    <responserequired>1</responserequired>\n    <responsefieldlines>15</responsefieldlines>\n";
					$q .= '    <minwordlimit>' . (int) ( $r['payload']['min_words'] ?? 0 ) . "</minwordlimit>\n";
					$q .= '    ' . self::textnode( 'graderinfo', (string) ( $r['key']['model_answer'] ?? '' ) ) . "\n";
					break;
				case 'matching':
					$right = array();
					foreach ( $r['payload']['right'] as $o ) {
						$right[ $o['id'] ] = html_entity_decode( wp_strip_all_tags( (string) $o['text'] ), ENT_QUOTES, 'UTF-8' );
					}
					$q .= "    <shuffleanswers>true</shuffleanswers>\n";
					$used = array();
					foreach ( $r['payload']['left'] as $l ) {
						$rid    = $r['key']['pairs'][ $l['id'] ] ?? '';
						$used[] = $rid;
						$q     .= '    <subquestion format="html"><text>' . self::cdata( (string) $l['text'] ) . '</text><answer><text>' . self::cdata( $right[ $rid ] ?? '' ) . "</text></answer></subquestion>\n";
					}
					foreach ( array_diff( array_keys( $right ), $used ) as $extra ) {
						$q .= '    <subquestion format="html"><text></text><answer><text>' . self::cdata( $right[ $extra ] ) . "</text></answer></subquestion>\n";
					}
					break;
			}
			if ( $r['tags'] ) {
				$q .= "    <tags>\n";
				foreach ( $r['tags'] as $tg ) {
					$q .= '      <tag><text>' . esc_html( $tg ) . "</text></tag>\n";
				}
				$q .= "    </tags>\n";
			}
			$x .= $q . "  </question>\n";
		}
		return $x . "</quiz>\n";
	}
}
