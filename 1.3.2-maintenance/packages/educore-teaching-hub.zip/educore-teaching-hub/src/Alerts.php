<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Academic Attention Center. Rule-based, configurable (Settings alert_*), explainable: every flag carries the
 * numbers that triggered it. No inferred judgements about ability or personal characteristics.
 */
final class Alerts {

	/** Rule keys → human label. */
	public static function labels(): array {
		return array(
			'missing'   => __( 'Missing assignments', 'educore-teaching-hub' ),
			'low_score' => __( 'Low assignment scores', 'educore-teaching-hub' ),
			'declining' => __( 'Declining scores', 'educore-teaching-hub' ),
			'failed'    => __( 'Repeated failed assessments', 'educore-teaching-hub' ),
			'inactive'  => __( 'No recent learning activity', 'educore-teaching-hub' ),
			'absences'  => __( 'Repeated absences', 'educore-teaching-hub' ),
		);
	}

	/**
	 * Flags for students of the given classes. Batched: a fixed number of queries per call.
	 *
	 * @param int[] $class_ids
	 * @return array<int,array{student_id:int,name:string,class_id:int,rule:string,detail:string,severity:int}>
	 */
	public static function for_classes( array $class_ids ): array {
		global $wpdb;
		$class_ids = array_filter( array_map( 'intval', $class_ids ) );
		if ( ! $class_ids ) {
			return array();
		}
		$cfg  = Settings::all();
		$in   = implode( ',', $class_ids );
		$mem  = $wpdb->get_results( 'SELECT m.class_id, m.student_id, m.joined_at, u.display_name FROM ' . Schema::table( 'th_class_members' ) . ' m JOIN ' . $wpdb->users . " u ON u.ID=m.student_id WHERE m.status='active' AND m.class_id IN ({$in})", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( ! $mem ) {
			return array();
		}
		$students = array_values( array_unique( array_map( 'intval', wp_list_pluck( $mem, 'student_id' ) ) ) );
		$sin      = implode( ',', $students );
		$now      = Schema::now();
		$out      = array();
		$flag     = static function ( array $m, string $rule, string $detail, int $sev ) use ( &$out ) {
			$out[] = array( 'student_id' => (int) $m['student_id'], 'name' => $m['display_name'], 'class_id' => (int) $m['class_id'], 'rule' => $rule, 'detail' => $detail, 'severity' => $sev );
		};

		// Missing: published class assignments past due with no submission.
		$a       = Schema::table( 'th_assignments' );
		$s       = Schema::table( 'th_submissions' );
		$missing = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT a.class_id, m.student_id, COUNT(*) n FROM {$a} a JOIN " . Schema::table( 'th_class_members' ) . " m ON m.class_id=a.class_id AND m.status='active' LEFT JOIN {$s} s ON s.assignment_id=a.id AND s.student_id=m.student_id AND s.status IN ('submitted','graded','returned') WHERE a.class_id IN ({$in}) AND a.status IN ('published','closed') AND a.due_at < %s AND a.due_at >= m.joined_at AND s.id IS NULL GROUP BY a.class_id, m.student_id", $now ), ARRAY_A ) ?: array() as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$missing[ $r['class_id'] . ':' . $r['student_id'] ] = (int) $r['n'];
		}
		// Scores: released graded submissions, ordered (for mean + trend).
		$scores = array();
		foreach ( $wpdb->get_results( "SELECT s.student_id, a.class_id, s.score, a.max_score FROM {$s} s JOIN {$a} a ON a.id=s.assignment_id WHERE a.class_id IN ({$in}) AND s.status='graded' AND s.released=1 ORDER BY s.graded_at ASC", ARRAY_A ) ?: array() as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$scores[ $r['class_id'] . ':' . $r['student_id'] ][] = 100 * (float) $r['score'] / max( 0.01, (float) $r['max_score'] );
		}
		// Absences in the last 30 days.
		$abs = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT context_id class_id, student_id, COUNT(*) n FROM ' . Schema::table( 'th_attendance' ) . " WHERE context_type='class' AND context_id IN ({$in}) AND status='absent' AND occurs_on >= %s GROUP BY context_id, student_id", wp_date( 'Y-m-d', time() - 30 * DAY_IN_SECONDS ) ), ARRAY_A ) ?: array() as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$abs[ $r['class_id'] . ':' . $r['student_id'] ] = (int) $r['n'];
		}
		// Last learning activity (core daily activity log).
		$last = array();
		foreach ( $wpdb->get_results( 'SELECT user_id, MAX(day) d FROM ' . Schema::table( 'activity' ) . " WHERE user_id IN ({$sin}) GROUP BY user_id", ARRAY_A ) ?: array() as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$last[ (int) $r['user_id'] ] = $r['d'];
		}
		// Failed assessment attempts (if Assessments is active).
		$failed = array();
		if ( class_exists( '\EduCore\Assessments\Schema' ) ) {
			foreach ( $wpdb->get_results( 'SELECT user_id, COUNT(*) n FROM ' . \EduCore\Assessments\Schema::t( 'attempts' ) . " WHERE user_id IN ({$sin}) AND state='graded' AND passed=0 GROUP BY user_id", ARRAY_A ) ?: array() as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
				$failed[ (int) $r['user_id'] ] = (int) $r['n'];
			}
		}

		$inactive_cut = wp_date( 'Y-m-d', time() - (int) $cfg['alert_inactive_days'] * DAY_IN_SECONDS );
		$seen_failed  = array();
		foreach ( $mem as $m ) {
			$k = $m['class_id'] . ':' . $m['student_id'];
			if ( ( $missing[ $k ] ?? 0 ) >= max( 1, (int) $cfg['alert_missing'] ) ) {
				/* translators: %d: count */
				$flag( $m, 'missing', sprintf( _n( '%d assignment past its deadline without a submission.', '%d assignments past their deadline without a submission.', $missing[ $k ], 'educore-teaching-hub' ), $missing[ $k ] ), 3 );
			}
			$sc = $scores[ $k ] ?? array();
			if ( count( $sc ) >= 2 ) {
				$mean = array_sum( $sc ) / count( $sc );
				if ( $mean < (float) $cfg['alert_low_score_pct'] ) {
					/* translators: 1: percent, 2: count, 3: threshold */
					$flag( $m, 'low_score', sprintf( __( 'Average %1$s%% over %2$d graded assignments (threshold %3$d%%).', 'educore-teaching-hub' ), number_format_i18n( $mean, 0 ), count( $sc ), (int) $cfg['alert_low_score_pct'] ), 2 );
				}
			}
			if ( count( $sc ) >= 4 ) {
				$half   = intdiv( count( $sc ), 2 );
				$before = array_sum( array_slice( $sc, 0, $half ) ) / $half;
				$after  = array_sum( array_slice( $sc, -$half ) ) / $half;
				if ( $before - $after >= (float) $cfg['alert_decline_pct'] ) {
					/* translators: 1: earlier average, 2: recent average */
					$flag( $m, 'declining', sprintf( __( 'Recent average %2$s%% vs earlier %1$s%%.', 'educore-teaching-hub' ), number_format_i18n( $before, 0 ), number_format_i18n( $after, 0 ) ), 2 );
				}
			}
			if ( ( $abs[ $k ] ?? 0 ) >= max( 1, (int) $cfg['alert_absences'] ) ) {
				/* translators: %d: count */
				$flag( $m, 'absences', sprintf( __( '%d absences in the last 30 days.', 'educore-teaching-hub' ), $abs[ $k ] ), 2 );
			}
			$sid       = (int) $m['student_id'];
			$joined    = substr( (string) $m['joined_at'], 0, 10 );
			$last_day  = $last[ $sid ] ?? null;
			if ( (int) $cfg['alert_inactive_days'] && $joined < $inactive_cut && ( ! $last_day || $last_day < $inactive_cut ) ) {
				$flag( $m, 'inactive', $last_day ? sprintf( /* translators: %s: date */ __( 'Last learning activity on %s.', 'educore-teaching-hub' ), $last_day ) : __( 'No learning activity recorded yet.', 'educore-teaching-hub' ), 1 );
			}
			if ( ! isset( $seen_failed[ $sid ] ) && ( $failed[ $sid ] ?? 0 ) >= max( 1, (int) $cfg['alert_failed_assessments'] ) ) {
				$seen_failed[ $sid ] = true;
				/* translators: %d: count */
				$flag( $m, 'failed', sprintf( _n( '%d failed assessment attempt.', '%d failed assessment attempts.', $failed[ $sid ], 'educore-teaching-hub' ), $failed[ $sid ] ), 3 );
			}
		}
		usort( $out, static fn( $x, $y ) => $y['severity'] <=> $x['severity'] ?: strcmp( $x['name'], $y['name'] ) );
		return $out;
	}

	/** Daily cron: store a per-teacher count so the portal badge is cheap; notify on new high-severity flags. */
	public static function daily(): void {
		global $wpdb;
		$teachers = array_map( 'intval', $wpdb->get_col( 'SELECT DISTINCT user_id FROM ' . Schema::table( 'th_class_staff' ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $teachers as $uid ) {
			$flags = self::for_classes( Caps::classes_of( $uid ) );
			update_user_meta( $uid, 'educore_th_attention', array( 'count' => count( $flags ), 'high' => count( array_filter( $flags, static fn( $f ) => $f['severity'] >= 3 ) ), 'at' => time() ) );
			do_action( 'educore/th/attention_digest', $uid, $flags );
		}
	}
}
