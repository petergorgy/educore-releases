<?php
/**
 * Title: EduCore — built for everyone in the school
 * Slug: educore-theme/roles
 * Categories: educore-theme, features
 * Description: Four role cards (learners, families, teachers, school leaders) with what each can do.
 */
$ect_roles = array(
	array(
		'learner',
		__( 'Learners', 'educore-theme' ),
		array(
			__( 'A dashboard with progress, a weekly goal and “Continue learning”', 'educore-theme' ),
			__( 'Short lessons with notes, bookmarks and practice', 'educore-theme' ),
			__( 'Timed quizzes with instant results and certificates', 'educore-theme' ),
		),
	),
	array(
		'family',
		__( 'Parents and guardians', 'educore-theme' ),
		array(
			__( 'Progress, deadlines and released results for each child', 'educore-theme' ),
			__( 'Attendance and the support the school has agreed', 'educore-theme' ),
			__( 'A weekly e-mail summary when something changes', 'educore-theme' ),
		),
	),
	array(
		'teacher',
		__( 'Teachers and instructors', 'educore-theme' ),
		array(
			__( 'Build courses step by step and reuse a question bank', 'educore-theme' ),
			__( 'Grade in one queue, give feedback, take attendance', 'educore-theme' ),
			__( 'Spot learners at risk early and start a support plan', 'educore-theme' ),
		),
	),
	array(
		'school',
		__( 'School leaders', 'educore-theme' ),
		array(
			__( 'Programmes, classes and people in one place', 'educore-theme' ),
			__( 'Enrol a whole class from a spreadsheet, checked first', 'educore-theme' ),
			__( 'Learning analytics, an audit trail and verified backups', 'educore-theme' ),
		),
	),
);
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50"}}},"className":"ect-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group ect-section" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--50)">
<!-- wp:paragraph {"align":"wide","className":"ect-eyebrow ect-eyebrow--dark"} --><p class="alignwide ect-eyebrow ect-eyebrow--dark"><?php esc_html_e( 'One platform', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:heading {"align":"wide","className":"ect-section__title"} --><h2 class="wp-block-heading alignwide ect-section__title"><?php esc_html_e( 'Built for everyone in your school', 'educore-theme' ); ?></h2><!-- /wp:heading -->
<!-- wp:paragraph {"align":"wide","className":"ect-section__lead","textColor":"muted"} --><p class="alignwide ect-section__lead has-muted-color has-text-color"><?php esc_html_e( 'Each person signs in to a workspace made for what they do — and sees only what they should.', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:html -->
<div class="ect-roles alignwide">
<?php foreach ( $ect_roles as $ect_r ) : ?>
<article class="ect-role ect-card ect-reveal">
<span class="ect-role__icon"><?php echo educore_theme_icon( $ect_r[0] ); // phpcs:ignore ?></span>
<h3><?php echo esc_html( $ect_r[1] ); ?></h3>
<ul>
<?php foreach ( $ect_r[2] as $ect_line ) : ?>
<li><?php echo esc_html( $ect_line ); ?></li>
<?php endforeach; ?>
</ul>
</article>
<?php endforeach; ?>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
