<?php
/**
 * Title: EduCore hero
 * Slug: educore-theme/hero
 * Categories: educore-theme, banner
 * Description: Home page hero: tagline, calls to action and the two-minute product tour.
 */
$ect_tour = educore_theme_tour();
$ect_open = educore_theme_registration_open();
?>
<!-- wp:group {"align":"full","className":"ect-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"gradient":"hero","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull ect-hero has-hero-gradient-background has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"verticalAlignment":"center","align":"wide","className":"ect-hero__grid"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center ect-hero__grid">
<!-- wp:column {"verticalAlignment":"center","width":"46%","className":"ect-hero__copy"} -->
<div class="wp-block-column is-vertically-aligned-center ect-hero__copy" style="flex-basis:46%">
<!-- wp:paragraph {"className":"ect-eyebrow"} --><p class="ect-eyebrow"><?php esc_html_e( 'EduCore learning platform', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"ect-tagline ect-fade-in"} --><h1 class="wp-block-heading ect-tagline ect-fade-in"><?php esc_html_e( 'Learn. Practice. Understand. Grow.', 'educore-theme' ); ?></h1><!-- /wp:heading -->
<!-- wp:paragraph {"className":"ect-hero__lead","fontSize":"large"} --><p class="ect-hero__lead has-large-font-size"><?php esc_html_e( 'One platform for learners, families and teachers: structured courses, interactive lessons and fair assessments — in English, French and Arabic.', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:buttons {"className":"ect-hero__actions"} -->
<div class="wp-block-buttons ect-hero__actions">
<!-- wp:button {"className":"ect-btn-gold"} --><div class="wp-block-button ect-btn-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( educore_theme_url( 'courses' ) ); ?>"><?php esc_html_e( 'Browse courses', 'educore-theme' ); ?></a></div><!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( educore_theme_url( $ect_open ? 'register' : 'contact' ) ); ?>"><?php echo $ect_open ? esc_html__( 'Create a free account', 'educore-theme' ) : esc_html__( 'Request access', 'educore-theme' ); ?></a></div><!-- /wp:button -->
</div>
<!-- /wp:buttons -->
<!-- wp:html -->
<ul class="ect-hero__chips" aria-label="<?php esc_attr_e( 'At a glance', 'educore-theme' ); ?>">
<li><?php echo educore_theme_icon( 'check' ); // phpcs:ignore ?><span lang="en">English</span> · <span lang="fr">Français</span> · <span lang="ar">العربية</span></li>
<li><?php echo educore_theme_icon( 'check' ); // phpcs:ignore ?><?php esc_html_e( 'Works on phone, tablet and computer', 'educore-theme' ); ?></li>
<li><?php echo educore_theme_icon( 'check' ); // phpcs:ignore ?><?php esc_html_e( 'Progress saved on every device', 'educore-theme' ); ?></li>
</ul>
<!-- /wp:html -->
</div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"54%","className":"ect-hero__media"} -->
<div class="wp-block-column is-vertically-aligned-center ect-hero__media" style="flex-basis:54%">
<?php if ( $ect_tour ) : ?>
<!-- wp:html -->
<figure class="ect-video" id="tour" data-ect-video>
<div class="ect-video__frame">
<video controls playsinline preload="none" poster="<?php echo esc_url( $ect_tour['poster'] ); ?>" aria-label="<?php esc_attr_e( 'EduCore product tour, about two minutes, with background music and on-screen captions', 'educore-theme' ); ?>">
<source src="<?php echo esc_url( $ect_tour['src'] ); ?>" type="video/mp4">
<a href="<?php echo esc_url( $ect_tour['src'] ); ?>"><?php esc_html_e( 'Download the product tour (MP4)', 'educore-theme' ); ?></a>
</video>
<button type="button" class="ect-video__play" hidden><span class="ect-video__pill"><span class="ect-video__icon"><?php echo educore_theme_icon( 'play' ); // phpcs:ignore ?></span><span class="ect-video__label"><?php esc_html_e( 'Watch the 2-minute tour', 'educore-theme' ); ?></span></span></button>
</div>
<figcaption class="ect-video__caption"><?php esc_html_e( 'See a learner, a parent, teachers and the school team at work — recorded on a demonstration copy of EduCore.', 'educore-theme' ); ?></figcaption>
</figure>
<!-- /wp:html -->
<?php endif; ?>
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
