<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	private static bool $booted = false;

	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		Registry::register( 'core', EDUCORE_CORE_VERSION );
		self::maybe_upgrade();

		I18n::register();
		Roles::register();
		Content::register();
		Announcements::register();
		Translations::register();
		Updater::register();
		Hardening::register();
		Privacy::register();
		RateLimiter::register();
		Pages::register();
		Cron::register();
		Rest\Routes::register();
		Frontend\Blocks::register();
		Frontend\Gate::register();
		Frontend\Assets::register();
		Frontend\Forms::register();

		if ( is_admin() ) {
			Admin\Menu::register();
			Admin\MetaBoxes::register();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'educore', Cli::class );
		}
		// Assessment activity counts as learning activity (no class dependency: course resolved via filter).
		add_action(
			'educore/events/attempt_submitted',
			static fn( $attempt_id, $user_id ) => Progress::log_activity( (int) $user_id, (int) apply_filters( 'educore/activity/course_of', 0, 'attempt', (int) $attempt_id ) ),
			5,
			2
		);
		add_action(
			'educore/events/practice_answered',
			static fn( $user_id, $question_id ) => Progress::log_activity( (int) $user_id, (int) apply_filters( 'educore/activity/course_of', 0, 'question', (int) $question_id ) ),
			5,
			2
		);
		/** All EduCore packages hook here to start; core services are ready. */
		do_action( 'educore/core/loaded', EDUCORE_CORE_VERSION );
	}

	public static function maybe_upgrade(): void {
		Schema::migrate( 'educore_core_db_version', EDUCORE_CORE_DB_VERSION, Schema::core_tables() );
		if ( get_option( 'educore_core_roles_version' ) !== EDUCORE_CORE_VERSION ) {
			Roles::install();
			update_option( 'educore_core_roles_version', EDUCORE_CORE_VERSION, false );
		}
	}

	/**
	 * Dependency guard used by every optional EduCore package.
	 * Returns true when core is loaded at >= $min_version; otherwise shows an admin notice.
	 */
	public static function requirement_met( string $package_name, string $min_version ): bool {
		if ( version_compare( EDUCORE_CORE_VERSION, $min_version, '>=' ) ) {
			return true;
		}
		add_action(
			'admin_notices',
			static function () use ( $package_name, $min_version ) {
				/* translators: 1: package, 2: version */
				printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html( sprintf( __( '%1$s requires EduCore Core %2$s or newer. It has not been loaded.', 'educore-core' ), $package_name, $min_version ) ) );
			}
		);
		return false;
	}
}
