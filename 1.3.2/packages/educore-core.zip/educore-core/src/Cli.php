<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * WP-CLI: wp educore <command>
 */
final class Cli {

	/** Environment and schema checks. */
	public function doctor(): void {
		$fail = false;
		foreach ( Installer::environment_checks() as $c ) {
			\WP_CLI::log( sprintf( '[%s] %s — %s', strtoupper( $c['status'] ), $c['label'], $c['message'] ) );
			$fail = $fail || 'fail' === $c['status'];
		}
		\WP_CLI::log( 'Packages: ' . wp_json_encode( Registry::all() ) );
		$fail ? \WP_CLI::error( 'Environment check failed.' ) : \WP_CLI::success( 'Environment OK.' );
	}

	/**
	 * Create the initial curriculum structure (drafts, placeholder titles).
	 *
	 * @subcommand seed-structure
	 */
	public function seed_structure(): void {
		$r = Curriculum::seed_initial_structure();
		\WP_CLI::success( ( $r['created'] ? 'Created' : 'Already present' ) . ': programme #' . $r['programme_id'] . ', course #' . $r['course_id'] );
	}

	/** Create default pages. */
	public function pages(): void {
		\WP_CLI::success( 'Pages: ' . wp_json_encode( Pages::create_missing() ) );
	}

	/**
	 * Create clearly-labelled SAMPLE data for local/staging only.
	 *
	 * ## OPTIONS
	 * [--students=<n>]
	 * : Number of sample students. Default 5.
	 *
	 * @subcommand sample-data
	 */
	public function sample_data( $args, $assoc ): void {
		if ( 'production' === wp_get_environment_type() ) {
			\WP_CLI::error( 'Refusing to create sample data: WP_ENVIRONMENT_TYPE is production.' );
		}
		$n      = max( 1, (int) ( $assoc['students'] ?? 5 ) );
		$course = (int) wp_insert_post( array( 'post_type' => Content::COURSE, 'post_status' => 'publish', 'post_title' => '[SAMPLE] Introduction to Programming', 'post_excerpt' => 'Sample course for staging tests.', 'post_content' => '<!-- wp:paragraph --><p>Sample course description.</p><!-- /wp:paragraph -->' ) );
		update_post_meta( $course, '_ec_objectives', "Explain what a program is\nWrite a first program" );
		update_post_meta( $course, '_ec_enroll_mode', 'open' );
		$lessons = array();
		for ( $u = 1; $u <= 2; $u++ ) {
			$unit = (int) wp_insert_post( array( 'post_type' => Content::UNIT, 'post_status' => 'publish', 'post_title' => "[SAMPLE] Unit $u", 'menu_order' => $u ) );
			update_post_meta( $unit, '_ec_course_id', $course );
			for ( $l = 1; $l <= 2; $l++ ) {
				$lid = (int) wp_insert_post( array( 'post_type' => Content::LESSON, 'post_status' => 'publish', 'post_title' => "[SAMPLE] Lesson $u.$l", 'menu_order' => $l, 'post_content' => '<!-- wp:paragraph --><p>Sample lesson body ' . $u . '.' . $l . '.</p><!-- /wp:paragraph -->' ) );
				update_post_meta( $lid, '_ec_unit_id', $unit );
				update_post_meta( $lid, '_ec_course_id', $course );
				update_post_meta( $lid, '_ec_minutes', 10 );
				$lessons[] = $lid;
				Search::index_post( get_post( $lid ) );
			}
		}
		Search::index_post( get_post( $course ) );
		$instructor = wp_insert_user( array( 'user_login' => 'sample_instructor', 'user_email' => 'sample.instructor@example.invalid', 'user_pass' => wp_generate_password(), 'role' => 'ec_instructor', 'display_name' => '[SAMPLE] Instructor' ) );
		if ( ! is_wp_error( $instructor ) ) {
			Staff::assign( $course, $instructor, 'lead' );
		}
		for ( $i = 1; $i <= $n; $i++ ) {
			$uid = wp_insert_user( array( 'user_login' => "sample_student_$i", 'user_email' => "sample.student$i@example.invalid", 'user_pass' => wp_generate_password(), 'role' => 'ec_student', 'display_name' => "[SAMPLE] Student $i" ) );
			if ( is_wp_error( $uid ) ) {
				continue;
			}
			update_user_meta( $uid, 'educore_consent_state', 'granted' );
			Enrollment::enroll( $uid, $course, 'admin' );
		}
		do_action( 'educore/cli/sample_data', $course, $lessons );
		\WP_CLI::success( "Sample course #$course with " . count( $lessons ) . " lessons and $n students created (all labelled [SAMPLE])." );
	}
}
