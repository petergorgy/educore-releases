<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Central EduCore identity: names, colours and logo assets in one place. Every surface (login, theme
 * header/footer, e-mails, certificates, admin, favicons, PWA manifest, social previews) reads from here,
 * so a future logo change is an upload in EduCore → Settings → Branding, not a code change.
 */
final class Branding {
	public const OPTION = 'educore_brand';
	public const COLORS = array(
		'navy'  => '#102A43',
		'dark'  => '#0B1E31',
		'cyan'  => '#43D4DA',
		'teal'  => '#126B80',
		'cream' => '#F6F3E9',
		'gold'  => '#EBC16D',
		'white' => '#FFFFFF',
	);
	/** Logo slots that can be overridden with a media-library image (attachment id). */
	public const SLOTS = array( 'logo', 'logo_dark', 'mark', 'mark_dark' );

	public static function register(): void {
		add_action( 'wp_head', array( self::class, 'head' ), 2 );
		add_action( 'login_head', array( self::class, 'icons' ), 2 );
		add_action( 'admin_head', array( self::class, 'icons' ), 2 );
		add_action( 'init', array( self::class, 'manifest' ), 2 );
	}

	public static function defaults(): array {
		return array(
			'name'       => 'EduCore',
			'tagline'    => '',
			'initiative' => '',
			'logo'       => 0,
			'logo_dark'  => 0,
			'mark'       => 0,
			'mark_dark'  => 0,
		);
	}

	public static function get( string $key ) {
		$o = array_merge( self::defaults(), (array) get_option( self::OPTION, array() ) );
		return $o[ $key ] ?? null;
	}

	public static function name(): string {
		return (string) ( self::get( 'name' ) ?: 'EduCore' );
	}

	/** Translatable defaults; an owner-entered text replaces them in every language. */
	public static function tagline(): string {
		return (string) ( self::get( 'tagline' ) ?: __( 'Learn. Understand. Grow.', 'educore-core' ) );
	}

	public static function initiative(): string {
		return (string) ( self::get( 'initiative' ) ?: __( 'A GORGY.ORG Educational Initiative', 'educore-core' ) );
	}

	public static function asset( string $file ): string {
		return plugins_url( 'assets/brand/' . $file, EDUCORE_CORE_FILE );
	}

	public static function asset_path( string $file ): string {
		return EDUCORE_CORE_DIR . 'assets/brand/' . $file;
	}

	/** URL of a logo slot: the owner's uploaded image if set, else the official asset. */
	public static function url( string $slot ): string {
		$id = (int) self::get( $slot );
		if ( $id && ( $u = wp_get_attachment_url( $id ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
			return $u;
		}
		$map = array(
			'logo'      => 'educore-logo-horizontal.svg',
			'logo_dark' => 'educore-logo-horizontal-dark.svg',
			'mark'      => 'educore-mark.svg',
			'mark_dark' => 'educore-mark-dark.svg',
		);
		return self::asset( $map[ $slot ] ?? 'educore-logo-horizontal.svg' );
	}

	/**
	 * Logo markup. $variant: 'auto' (light + dark image, CSS picks), 'light', 'dark'.
	 * Decorative inside a link that already names the site → alt is the brand name once.
	 */
	public static function logo_html( string $variant = 'auto', string $class = 'ec-logo', int $height = 40 ): string {
		$alt  = esc_attr( self::name() );
		$img  = static fn( $src, $extra ) => '<img src="' . esc_url( $src ) . '" alt="' . $extra . '" height="' . $height . '" class="' . esc_attr( $class ) . '" decoding="async">';
		if ( 'light' === $variant ) {
			return $img( self::url( 'logo' ), $alt );
		}
		if ( 'dark' === $variant ) {
			return $img( self::url( 'logo_dark' ), $alt );
		}
		return '<span class="' . esc_attr( $class ) . '-wrap">' . str_replace( 'class="' . $class . '"', 'class="' . $class . ' ' . $class . '--light"', $img( self::url( 'logo' ), $alt ) )
			. str_replace( 'class="' . $class . '"', 'class="' . $class . ' ' . $class . '--dark"', $img( self::url( 'logo_dark' ), '' ) ) . '</span>';
	}

	/** Favicons and app icons (skipped when the owner set a WordPress Site Icon). */
	public static function icons(): void {
		if ( has_site_icon() ) {
			return;
		}
		echo '<link rel="icon" href="' . esc_url( self::asset( 'favicon.ico' ) ) . '" sizes="48x48">' . "\n";
		echo '<link rel="icon" href="' . esc_url( self::asset( 'favicon.svg' ) ) . '" type="image/svg+xml">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( self::asset( 'apple-touch-icon.png' ) ) . '">' . "\n";
	}

	public static function head(): void {
		self::icons();
		echo '<link rel="manifest" href="' . esc_url( add_query_arg( 'educore_manifest', '1', home_url( '/' ) ) ) . '">' . "\n";
		echo '<meta name="theme-color" content="' . esc_attr( self::COLORS['navy'] ) . '">' . "\n";
		if ( self::seo_plugin_active() ) {
			return; // An SEO plugin owns social metadata.
		}
		$title = wp_get_document_title();
		$desc  = is_singular() ? wp_strip_all_tags( (string) get_the_excerpt() ) : '';
		$desc  = '' !== trim( $desc ) ? $desc : self::tagline() . ' — ' . self::initiative();
		$url   = is_singular() ? get_permalink() : home_url( add_query_arg( array() ) );
		$tags  = array(
			'og:type'        => is_singular() ? 'article' : 'website',
			'og:site_name'   => self::name(),
			'og:title'       => $title,
			'og:description' => wp_trim_words( $desc, 40 ),
			'og:url'         => $url,
			'og:image'       => self::asset( 'educore-og-image.png' ),
			'og:image:width' => '1200',
			'og:image:height' => '630',
			'og:image:alt'   => self::name() . ' — ' . self::tagline(),
			'og:locale'      => I18n::LANGS[ I18n::current() ] ?? 'en_US',
		);
		foreach ( $tags as $p => $v ) {
			echo '<meta property="' . esc_attr( $p ) . '" content="' . esc_attr( (string) $v ) . '">' . "\n";
		}
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	}

	private static function seo_plugin_active(): bool {
		return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
	}

	/** Web app manifest (installable icon, name, colours). */
	public static function manifest(): void {
		if ( ! isset( $_GET['educore_manifest'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public, read-only.
			return;
		}
		$m = array(
			'name'             => self::name() . ' — ' . self::tagline(),
			'short_name'       => self::name(),
			'start_url'        => home_url( '/' ),
			'scope'            => home_url( '/' ),
			'display'          => 'standalone',
			'background_color' => self::COLORS['cream'],
			'theme_color'      => self::COLORS['navy'],
			'lang'             => I18n::current(),
			'dir'              => I18n::is_rtl() ? 'rtl' : 'ltr',
			'icons'            => array(
				array( 'src' => self::asset( 'icon-192.png' ), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable' ),
				array( 'src' => self::asset( 'icon-512.png' ), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable' ),
				array( 'src' => self::asset( 'favicon.svg' ), 'sizes' => 'any', 'type' => 'image/svg+xml' ),
			),
		);
		nocache_headers();
		header( 'Content-Type: application/manifest+json; charset=utf-8' );
		echo wp_json_encode( $m, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/** Admin menu icon (monochrome mark; WordPress tints it to the admin colour scheme). */
	public static function menu_icon(): string {
		$svg = (string) file_get_contents( self::asset_path( 'educore-mark-white.svg' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$svg = str_replace( array( '#FFF', '#fff' ), 'black', $svg );
		return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}

	/** Settings section (EduCore → Settings). */
	public static function settings_rows(): string {
		$o   = array_merge( self::defaults(), (array) get_option( self::OPTION, array() ) );
		$out = '<tr><th colspan="2"><h2 id="branding">' . esc_html__( 'Branding', 'educore-core' ) . '</h2><p class="description">' . esc_html__( 'Leave a field empty to use the official EduCore identity. Uploaded logos replace the official files everywhere (header, login, e-mails, certificates).', 'educore-core' ) . '</p></th></tr>';
		$out .= '<tr><th><label for="ec-brand-name">' . esc_html__( 'Platform name', 'educore-core' ) . '</label></th><td><input id="ec-brand-name" class="regular-text" name="educore_brand[name]" value="' . esc_attr( (string) $o['name'] ) . '"></td></tr>';
		$out .= '<tr><th><label for="ec-brand-tag">' . esc_html__( 'Tagline', 'educore-core' ) . '</label></th><td><input id="ec-brand-tag" class="regular-text" name="educore_brand[tagline]" placeholder="' . esc_attr__( 'Learn. Understand. Grow.', 'educore-core' ) . '" value="' . esc_attr( (string) $o['tagline'] ) . '"></td></tr>';
		$out .= '<tr><th><label for="ec-brand-ini">' . esc_html__( 'Initiative line', 'educore-core' ) . '</label></th><td><input id="ec-brand-ini" class="regular-text" name="educore_brand[initiative]" placeholder="' . esc_attr__( 'A GORGY.ORG Educational Initiative', 'educore-core' ) . '" value="' . esc_attr( (string) $o['initiative'] ) . '"></td></tr>';
		$labels = array( 'logo' => __( 'Logo for light backgrounds (media ID)', 'educore-core' ), 'logo_dark' => __( 'Logo for dark backgrounds (media ID)', 'educore-core' ), 'mark' => __( 'Icon (media ID)', 'educore-core' ), 'mark_dark' => __( 'Icon for dark backgrounds (media ID)', 'educore-core' ) );
		foreach ( $labels as $slot => $label ) {
			$out .= '<tr><th><label for="ec-brand-' . esc_attr( $slot ) . '">' . esc_html( $label ) . '</label></th><td><input id="ec-brand-' . esc_attr( $slot ) . '" type="number" min="0" class="small-text" name="educore_brand[' . esc_attr( $slot ) . ']" value="' . esc_attr( (string) (int) $o[ $slot ] ) . '"> <img src="' . esc_url( self::url( $slot ) ) . '" alt="" style="height:28px;vertical-align:middle;background:' . ( false !== strpos( $slot, 'dark' ) ? self::COLORS['navy'] : '#fff' ) . ';padding:4px;border-radius:4px"></td></tr>';
		}
		return $out;
	}

	public static function save( array $in ): void {
		$out = self::defaults();
		foreach ( array( 'name', 'tagline', 'initiative' ) as $k ) {
			$out[ $k ] = mb_substr( sanitize_text_field( (string) ( $in[ $k ] ?? '' ) ), 0, 120 );
		}
		foreach ( self::SLOTS as $k ) {
			$id        = absint( $in[ $k ] ?? 0 );
			$out[ $k ] = ( $id && wp_attachment_is_image( $id ) ) ? $id : 0;
		}
		$out['name'] = '' === $out['name'] ? 'EduCore' : $out['name'];
		update_option( self::OPTION, $out, false );
		Audit::log( 'settings.branding_saved', 'settings', 0 );
	}
}
