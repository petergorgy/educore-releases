/* EduCore core front-end — progressive enhancement; every action is also validated server-side. */
(function () {
	'use strict';
	var cfg = window.EduCore || {};
	var t = cfg.i18n || {};
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	function api(path, opts) {
		opts = opts || {};
		var headers = { 'Content-Type': 'application/json' };
		if (cfg.nonce) { headers['X-WP-Nonce'] = cfg.nonce; }
		return fetch(cfg.rest + path, {
			method: opts.method || 'GET',
			credentials: 'same-origin',
			headers: headers,
			body: opts.body ? JSON.stringify(opts.body) : undefined
		}).then(function (r) {
			return r.json().catch(function () { return {}; }).then(function (data) {
				if (!r.ok) { var e = new Error((data && data.message) || t.error); e.data = data; throw e; }
				return data;
			});
		});
	}
	window.EduCoreApi = api;

	function toast(msg, type) {
		var el = document.createElement('div');
		el.className = 'ec-toast ec-toast--' + (type || 'info');
		el.setAttribute('role', type === 'error' ? 'alert' : 'status');
		el.textContent = msg;
		document.body.appendChild(el);
		setTimeout(function () { el.classList.add('is-out'); }, 2600);
		setTimeout(function () { el.remove(); }, 3200);
	}
	window.EduCoreToast = toast;

	function celebrate(target) {
		if (reduce || !target) { return; }
		var burst = document.createElement('span');
		burst.className = 'ec-celebrate';
		burst.setAttribute('aria-hidden', 'true');
		for (var i = 0; i < 12; i++) { var s = document.createElement('i'); s.style.setProperty('--i', i); burst.appendChild(s); }
		target.appendChild(burst);
		setTimeout(function () { burst.remove(); }, 1200);
	}
	window.EduCoreCelebrate = celebrate;

	var reader = document.querySelector('.ec-reader');
	var lessonId = reader ? reader.getAttribute('data-lesson') : null;

	document.addEventListener('click', function (ev) {
		var btn = ev.target.closest('[data-ec-action]');
		if (!btn) { return; }
		var action = btn.getAttribute('data-ec-action');
		if (action === 'enroll') {
			btn.disabled = true;
			api('courses/' + btn.getAttribute('data-course') + '/enroll', { method: 'POST' })
				.then(function (d) { toast(t.enrolled, 'success'); setTimeout(function () { window.location.href = d.course_url; }, 600); })
				.catch(function (e) { btn.disabled = false; toast(e.message, 'error'); });
		} else if (action === 'complete' && lessonId) {
			btn.disabled = true;
			api('lessons/' + lessonId + '/complete', { method: 'POST' })
				.then(function () {
					var wrap = btn.parentNode;
					wrap.innerHTML = '<p class="ec-badge-done ec-badge-done--lg">' + t.completed + '</p>';
					celebrate(wrap);
					var cur = document.querySelector('.ec-outline .is-current');
					if (cur) { cur.classList.add('is-done'); }
				})
				.catch(function (e) { btn.disabled = false; toast(e.message, 'error'); });
		} else if (action === 'bookmark' && lessonId) {
			api('lessons/' + lessonId + '/notes', { method: 'POST', body: { type: 'bookmark', body: '' } })
				.then(function () { btn.setAttribute('aria-pressed', 'true'); toast(t.bookmarked, 'success'); loadNotes(); })
				.catch(function (e) { toast(e.message, 'error'); });
		} else if (action === 'delete-note') {
			api('notes/' + btn.getAttribute('data-id'), { method: 'DELETE' })
				.then(function () { toast(t.deleted); loadNotes(); })
				.catch(function (e) { toast(e.message, 'error'); });
		}
	});

	/* Notes */
	var list = document.querySelector('[data-ec-notes]');
	function loadNotes() {
		if (!list || !lessonId) { return; }
		api('lessons/' + lessonId + '/notes').then(function (rows) {
			list.innerHTML = '';
			var notes = rows.filter(function (r) { return r.type === 'note'; });
			if (rows.some(function (r) { return r.type === 'bookmark'; })) {
				var b = document.querySelector('[data-ec-action="bookmark"]');
				if (b) { b.setAttribute('aria-pressed', 'true'); }
			}
			if (!notes.length) { var li = document.createElement('li'); li.className = 'ec-muted'; li.textContent = t.noNotes; list.appendChild(li); return; }
			notes.forEach(function (n) {
				var li = document.createElement('li');
				var p = document.createElement('p'); p.textContent = n.body;
				var del = document.createElement('button');
				del.type = 'button'; del.className = 'ec-btn ec-btn--ghost ec-btn--sm';
				del.setAttribute('data-ec-action', 'delete-note'); del.setAttribute('data-id', n.id); del.textContent = t.delete;
				li.appendChild(p); li.appendChild(del); list.appendChild(li);
			});
		}).catch(function () {});
	}
	var noteForm = document.querySelector('[data-ec-form="note"]');
	if (noteForm) {
		noteForm.addEventListener('submit', function (ev) {
			ev.preventDefault();
			var body = noteForm.querySelector('textarea').value.trim();
			if (!body) { return; }
			api('lessons/' + lessonId + '/notes', { method: 'POST', body: { type: 'note', body: body } })
				.then(function () { noteForm.reset(); toast(t.saved, 'success'); loadNotes(); })
				.catch(function (e) { toast(e.message, 'error'); });
		});
		loadNotes();
	}

	/* Active-time heartbeat: only counts while the tab is visible and the learner interacted recently. */
	if (reader && cfg.nonce) {
		var last = Date.now(), active = 0, tick = 30;
		['scroll', 'keydown', 'pointermove', 'touchstart'].forEach(function (e) {
			window.addEventListener(e, function () { last = Date.now(); }, { passive: true });
		});
		setInterval(function () {
			if (document.visibilityState === 'visible' && Date.now() - last < 120000) { active += 5; }
		}, 5000);
		setInterval(function () {
			if (active <= 0) { return; }
			var send = active; active = 0;
			api('lessons/' + lessonId + '/heartbeat', { method: 'POST', body: { seconds: send } })
				.then(function (d) { if (d.completed && !document.querySelector('.ec-badge-done--lg')) { var w = document.querySelector('.ec-complete'); if (w) { w.innerHTML = '<p class="ec-badge-done ec-badge-done--lg">' + t.completed + '</p>'; celebrate(w); } } })
				.catch(function () {});
		}, tick * 1000);
	}

	/* Reading progress bar */
	var rp = document.querySelector('.ec-reading-progress span');
	var content = document.querySelector('.ec-reader__main');
	if (rp && content) {
		var update = function () {
			var r = content.getBoundingClientRect();
			var total = r.height - window.innerHeight;
			var pct = total > 0 ? Math.min(100, Math.max(0, (-r.top / total) * 100)) : 100;
			rp.style.width = pct + '%';
		};
		window.addEventListener('scroll', update, { passive: true });
		update();
	}

	/* Mobile outline toggle */
	var toggle = document.querySelector('.ec-reader__toggle');
	if (toggle) {
		toggle.addEventListener('click', function () {
			var open = toggle.getAttribute('aria-expanded') === 'true';
			toggle.setAttribute('aria-expanded', open ? 'false' : 'true');
			document.getElementById('ec-outline').classList.toggle('is-open', !open);
		});
	}

	/* Registration: show guardian fields for minors */
	var guardian = document.querySelector('[data-ec-guardian]');
	if (guardian) {
		document.querySelectorAll('input[name="age_band"]').forEach(function (r) {
			r.addEventListener('change', function () {
				var minor = r.getAttribute('data-ec-minor') === '1';
				guardian.hidden = !minor;
				guardian.querySelector('input[type="email"]').required = minor;
			});
		});
	}

	/* Scroll-reveal (skipped with reduced motion) */
	var items = document.querySelectorAll('.ec-reveal');
	if (!reduce && 'IntersectionObserver' in window && items.length) {
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-visible'); io.unobserve(e.target); } });
		}, { rootMargin: '0px 0px -40px 0px' });
		items.forEach(function (el) { el.classList.add('is-hidden'); io.observe(el); });
	}
})();
