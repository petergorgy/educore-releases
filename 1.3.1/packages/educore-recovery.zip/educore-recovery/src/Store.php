<?php
namespace EduCore\Recovery;

defined( 'ABSPATH' ) || exit;

/**
 * Backup storage. Prefers a directory OUTSIDE the web root (next to the WordPress folder); otherwise a
 * random-named folder under uploads with deny-all rules. Files are never served by URL — only streamed
 * to authorised administrators.
 */
final class Store {

	public static function dir(): string {
		$saved = (string) get_option( 'educore_rc_dir', '' );
		if ( $saved && is_dir( $saved ) && wp_is_writable( $saved ) ) {
			return $saved;
		}
		$suffix = substr( bin2hex( random_bytes( 8 ) ), 0, 12 );
		$candidates = array( dirname( untrailingslashit( ABSPATH ) ) . '/educore-backups-' . $suffix );
		$up         = wp_upload_dir( null, false );
		$candidates[] = trailingslashit( $up['basedir'] ) . 'educore-backups-' . $suffix;
		foreach ( $candidates as $dir ) {
			if ( ( is_dir( $dir ) || @wp_mkdir_p( $dir ) ) && wp_is_writable( $dir ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors -- open_basedir may forbid the parent.
				self::guard( $dir );
				update_option( 'educore_rc_dir', $dir, false );
				return $dir;
			}
		}
		return '';
	}

	public static function outside_webroot(): bool {
		$d = self::dir();
		return '' !== $d && 0 !== strpos( wp_normalize_path( $d ), wp_normalize_path( ABSPATH ) );
	}

	private static function guard( string $dir ): void {
		$files = array(
			'.htaccess'  => "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n",
			'index.php'  => "<?php\n// Silence is golden.\n",
			'web.config' => "<?xml version=\"1.0\"?><configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
		);
		foreach ( $files as $f => $c ) {
			if ( ! file_exists( "$dir/$f" ) ) {
				file_put_contents( "$dir/$f", $c ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
		}
	}

	/** Absolute path for a stored backup file name (rejects anything but our generated names). */
	public static function path( string $file ): ?string {
		if ( ! preg_match( '/^educore-[a-z]+-\d{8}T\d{6}-[a-f0-9]{4}\.zip(\.enc)?$/', $file ) ) {
			return null;
		}
		$p = self::dir() . '/' . $file;
		return is_file( $p ) ? $p : null;
	}

	public static function tmp( string $suffix ): string {
		return self::dir() . '/tmp-' . bin2hex( random_bytes( 6 ) ) . $suffix;
	}

	public static function header_key_id( string $file ): string {
		$r = @fopen( $file, 'rb' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		if ( ! $r ) {
			return '';
		}
		$h = (string) fread( $r, 22 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return 0 === strpos( $h, "ECBK2\n" ) ? substr( $h, 6, 16 ) : '';
	}

	/**
	 * Encrypt archives that were written before encryption was enabled. Each archive is verified, encrypted,
	 * verified again, and only then is the plaintext removed. Returns [converted, failed, messages].
	 */
	public static function encrypt_existing(): array {
		global $wpdb;
		$key = Settings::key();
		$out = array( 0, 0, array() );
		if ( ! $key ) {
			$out[2][] = __( 'No encryption key is configured.', 'educore-recovery' );
			return $out;
		}
		$t = Backup::table();
		foreach ( $wpdb->get_results( "SELECT * FROM {$t} WHERE status='complete' AND encrypted=0" ) as $b ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$plain = $b->file ? self::path( $b->file ) : null;
			if ( ! $plain || ! Verifier::verify( (int) $b->id )['ok'] ) {
				++$out[1];
				$out[2][] = $b->uid . ': ' . __( 'not verified; left unchanged', 'educore-recovery' );
				continue;
			}
			$enc = $plain . '.enc';
			self::encrypt( $plain, $enc, $key );
			$old = array( 'file' => $b->file, 'size' => $b->size, 'sha256' => $b->sha256, 'encrypted' => 0 );
			Backup::update( (int) $b->id, array( 'file' => basename( $enc ), 'size' => filesize( $enc ), 'sha256' => hash_file( 'sha256', $enc ), 'encrypted' => 1 ) );
			if ( Verifier::verify( (int) $b->id )['ok'] ) {
				wp_delete_file( $plain );
				++$out[0];
			} else {
				Backup::update( (int) $b->id, $old );
				wp_delete_file( $enc );
				Verifier::verify( (int) $b->id );
				++$out[1];
				$out[2][] = $b->uid . ': ' . __( 'encrypted copy failed verification; plaintext kept', 'educore-recovery' );
			}
		}
		\EduCore\Core\Audit::log( 'backup.encrypted_existing', 'backup', 0, array( 'converted' => $out[0], 'failed' => $out[1] ) );
		return $out;
	}

	public static function unencrypted_count(): int {
		global $wpdb;
		$t = Backup::table();
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status='complete' AND encrypted=0" ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/* ---------- encryption (libsodium secretstream, chunked) ---------- */

	public static function encrypt( string $in, string $out, string $key ): void {
		[ $state, $header ] = sodium_crypto_secretstream_xchacha20poly1305_init_push( $key );
		$r = fopen( $in, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$w = fopen( $out, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		// Format 2: magic, 16-hex key id (identifies which key is needed; not secret), stream header.
		fwrite( $w, "ECBK2\n" . Settings::key_id( $key ) . $header ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		while ( ! feof( $r ) ) {
			$chunk = (string) fread( $r, 1048576 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$tag   = feof( $r ) ? SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL : SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_MESSAGE;
			$enc   = sodium_crypto_secretstream_xchacha20poly1305_push( $state, $chunk, '', $tag );
			fwrite( $w, pack( 'N', strlen( $enc ) ) . $enc ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $w ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/** @return true|\WP_Error */
	public static function decrypt( string $in, string $out, string $key ) {
		$r     = fopen( $in, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$magic = fread( $r, 6 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( "ECBK2\n" === $magic ) {
			$kid = (string) fread( $r, 16 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( ! hash_equals( $kid, Settings::key_id( $key ) ) ) {
				fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				/* translators: 1: key id in the file, 2: configured key id */
				return new \WP_Error( 'ec_rc_wrong_key', sprintf( __( 'This backup was encrypted with key %1$s; the configured key is %2$s.', 'educore-recovery' ), $kid, Settings::key_id( $key ) ) );
			}
		} elseif ( "ECBK1\n" !== $magic ) {
			fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return new \WP_Error( 'ec_rc_format', __( 'Not an EduCore encrypted backup.', 'educore-recovery' ) );
		}
		$state = sodium_crypto_secretstream_xchacha20poly1305_init_pull( (string) fread( $r, SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_HEADERBYTES ), $key ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$w     = fopen( $out, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$final = false;
		while ( ! feof( $r ) ) {
			$len = fread( $r, 4 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( 4 !== strlen( (string) $len ) ) {
				break;
			}
			$res = sodium_crypto_secretstream_xchacha20poly1305_pull( $state, (string) fread( $r, unpack( 'N', $len )[1] ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( false === $res ) {
				fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				fclose( $w ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				wp_delete_file( $out );
				return new \WP_Error( 'ec_rc_tamper', __( 'The encrypted backup is damaged or was modified (authentication failed).', 'educore-recovery' ) );
			}
			fwrite( $w, $res[0] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$final = SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL === $res[1];
		}
		fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $w ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $final ) {
			wp_delete_file( $out );
			return new \WP_Error( 'ec_rc_truncated', __( 'The encrypted backup is incomplete (truncated).', 'educore-recovery' ) );
		}
		return true;
	}
}
