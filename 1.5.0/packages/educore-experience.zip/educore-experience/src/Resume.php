<?php
namespace EduCore\Experience;

use EduCore\Core\Access;
use EduCore\Core\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Resume where you left off: last opened lesson and reading position per lesson (account-bound, server-side).
 * Assessments are not touched here: attempts keep their own secure server-side autosave and resume rules.
 */
final class Resume {
	public const LAST      = 'educore_xp_last';
	public const POSITIONS = 'educore_xp_positions';
	public const KEEP      = 30;

	public static function register(): void {
		add_action( 'template_redirect', array( self::class, 'track' ), 20 );
	}

	public static function track(): void {
		$uid = get_current_user_id();
		if ( ! $uid || ! is_singular( 'ec_lesson' ) ) {
			return;
		}
		$lid = (int) get_queried_object_id();
		if ( ! Access::can_view_lesson( $uid, $lid ) ) {
			return;
		}
		update_user_meta( $uid, self::LAST, array( 'lesson' => $lid, 'course' => (int) Content::course_of( $lid ), 'at' => time() ) );
	}

	/** @return array{lesson:int,course:int,at:int}|null */
	public static function last( int $uid ): ?array {
		$l = get_user_meta( $uid, self::LAST, true );
		if ( ! is_array( $l ) || empty( $l['lesson'] ) || 'publish' !== get_post_status( (int) $l['lesson'] ) ) {
			return null;
		}
		return array( 'lesson' => (int) $l['lesson'], 'course' => (int) $l['course'], 'at' => (int) $l['at'] );
	}

	public static function position( int $uid, int $lesson_id ): float {
		$all = get_user_meta( $uid, self::POSITIONS, true );
		return is_array( $all ) && isset( $all[ $lesson_id ] ) ? (float) $all[ $lesson_id ] : 0.0;
	}

	public static function rest_save( \WP_REST_Request $r ) {
		$uid = get_current_user_id();
		$lid = (int) $r['lesson'];
		$pos = (float) $r['position'];
		if ( $pos < 0 || $pos > 1 ) {
			return new \WP_Error( 'educore_xp_position', __( 'Invalid reading position.', 'educore-experience' ), array( 'status' => 400 ) );
		}
		if ( 'ec_lesson' !== get_post_type( $lid ) || ! Access::can_view_lesson( $uid, $lid ) ) {
			return new \WP_Error( 'educore_forbidden', __( 'You cannot view this lesson.', 'educore-experience' ), array( 'status' => 403 ) );
		}
		if ( ! \EduCore\Core\RateLimiter::hit( 'xp_resume', (string) $uid ) ) {
			return new \WP_Error( 'educore_rate_limited', __( 'Too many requests.', 'educore-experience' ), array( 'status' => 429 ) );
		}
		$all         = get_user_meta( $uid, self::POSITIONS, true );
		$all         = is_array( $all ) ? $all : array();
		unset( $all[ $lid ] );
		$all[ $lid ] = round( $pos, 3 );
		if ( count( $all ) > self::KEEP ) {
			$all = array_slice( $all, -self::KEEP, null, true );
		}
		update_user_meta( $uid, self::POSITIONS, $all );
		return rest_ensure_response( array( 'saved' => true ) );
	}
}
