<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Audit;
use EduCore\Core\Privacy as CorePrivacy;
use EduCore\Core\Schema;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/**
 * Safeguarded, context-bound communication. There is NO free 1:1 messaging:
 *  - every thread belongs to a class, an assignment or a tutoring session;
 *  - class-wide threads (student_id = 0) are announcements: staff post, members read;
 *  - student threads are visible to the student, the context staff, the student's verified guardians
 *    (minors, when guardian visibility is on) and safeguarding reviewers;
 *  - staff may open a thread with a minor only when the setting allows it; otherwise they reply;
 *  - messages are never deleted by participants; reviewers can hide them (kept for investigation);
 *  - any participant can report a message or thread; reviewer access is audited.
 */
final class Comms {
	public const CONTEXTS = array( 'class', 'assignment', 'session' );

	private static function t( string $n ): string {
		return Schema::table( $n );
	}

	/** Staff user ids for a context. @return int[] */
	public static function context_staff( string $type, int $id ): array {
		switch ( $type ) {
			case 'class':
				return wp_list_pluck( Classes::staff( $id ), 'user_id' );
			case 'assignment':
				$a = Assignments::get( $id );
				if ( ! $a ) {
					return array();
				}
				$ids = (int) $a['class_id'] ? wp_list_pluck( Classes::staff( (int) $a['class_id'] ), 'user_id' ) : array();
				if ( (int) $a['course_id'] ) {
					$ids = array_merge( $ids, wp_list_pluck( Staff::of_course( (int) $a['course_id'] ), 'user_id' ) );
				}
				return array_values( array_unique( array_map( 'intval', $ids ) ) );
			case 'session':
				$s = Tutoring::get( $id );
				return $s ? array( (int) $s['tutor_id'] ) : array();
		}
		return array();
	}

	/** Students who belong to a context. @return int[] */
	public static function context_students( string $type, int $id ): array {
		switch ( $type ) {
			case 'class':
				return Classes::members( $id );
			case 'assignment':
				return wp_list_pluck( Assignments::roster( $id ), 'student_id' );
			case 'session':
				return Tutoring::participants( $id );
		}
		return array();
	}

	public static function is_reviewer( int $user_id ): bool {
		return $user_id > 0 && user_can( $user_id, 'ec_review_reports' );
	}

	public static function thread( int $id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_threads' ) . ' WHERE id=%d', $id ), ARRAY_A ) ?: null;
	}

	/** 'none' | 'read' | 'post' */
	public static function access( int $user_id, array $thread ): string {
		if ( ! $user_id ) {
			return 'none';
		}
		$type    = $thread['context_type'];
		$cid     = (int) $thread['context_id'];
		$student = (int) $thread['student_id'];
		$staff   = in_array( $user_id, self::context_staff( $type, $cid ), true ) || Caps::is_manager( $user_id );
		if ( $staff ) {
			return 'open' === $thread['status'] ? 'post' : 'read';
		}
		if ( $student ) {
			if ( $student === $user_id ) {
				return 'open' === $thread['status'] ? 'post' : 'read';
			}
			if ( 'on' === Settings::get( 'guardian_visibility' ) && CorePrivacy::guardian_has_access( $user_id, $student ) ) {
				return 'read';
			}
		} elseif ( in_array( $user_id, self::context_students( $type, $cid ), true ) ) {
			return 'read'; // Announcements: members read only.
		}
		return self::is_reviewer( $user_id ) ? 'read' : 'none';
	}

	/** @return int|\WP_Error */
	public static function start( int $author, string $type, int $context_id, string $subject, string $body, int $student_id = 0 ) {
		global $wpdb;
		if ( ! in_array( $type, self::CONTEXTS, true ) ) {
			return new \WP_Error( 'ec_th_ctx', __( 'Unknown conversation context.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		$staff    = in_array( $author, self::context_staff( $type, $context_id ), true ) || Caps::is_manager( $author );
		$students = self::context_students( $type, $context_id );
		if ( ! $staff ) {
			// A student may open only their own thread in a context they belong to.
			if ( ! in_array( $author, $students, true ) ) {
				return new \WP_Error( 'ec_th_forbidden', __( 'You cannot start a conversation here.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
			}
			$student_id = $author;
		} elseif ( $student_id ) {
			if ( ! in_array( $student_id, $students, true ) ) {
				return new \WP_Error( 'ec_th_scope', __( 'That student is not part of this class or session.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
			}
			if ( CorePrivacy::is_minor( $student_id ) && 'on' !== Settings::get( 'staff_start_minor_thread' ) ) {
				return new \WP_Error( 'ec_th_safeguarding', __( 'Staff cannot open individual conversations with learners under 18. Post to the class or reply to the learner’s question.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
			}
		}
		$subject = mb_substr( sanitize_text_field( $subject ), 0, 190 );
		$body    = sanitize_textarea_field( $body );
		if ( '' === $subject || '' === trim( $body ) ) {
			return new \WP_Error( 'ec_th_empty', __( 'Write a subject and a message.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		$now = Schema::now();
		$wpdb->insert( self::t( 'th_threads' ), array( 'context_type' => $type, 'context_id' => $context_id, 'student_id' => $student_id, 'subject' => $subject, 'status' => 'open', 'created_by' => $author, 'created_at' => $now, 'last_post_at' => $now ) );
		$tid = (int) $wpdb->insert_id;
		$wpdb->insert( self::t( 'th_messages' ), array( 'thread_id' => $tid, 'author_id' => $author, 'body' => $body, 'created_at' => $now ) );
		Audit::log( 'comms.thread_started', 'thread', $tid, array( 'context' => $type, 'context_id' => $context_id, 'student_id' => $student_id ) );
		do_action( 'educore/th/message_posted', $tid, (int) $wpdb->insert_id, $author );
		return $tid;
	}

	/** @return int|\WP_Error */
	public static function reply( int $author, int $thread_id, string $body ) {
		global $wpdb;
		$t = self::thread( $thread_id );
		if ( ! $t || 'post' !== self::access( $author, $t ) ) {
			return new \WP_Error( 'ec_th_forbidden', __( 'You cannot reply to this conversation.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		if ( ! (int) $t['student_id'] && ! in_array( $author, self::context_staff( $t['context_type'], (int) $t['context_id'] ), true ) && ! Caps::is_manager( $author ) ) {
			return new \WP_Error( 'ec_th_forbidden', __( 'Only staff post announcements.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		$body = sanitize_textarea_field( $body );
		if ( '' === trim( $body ) ) {
			return new \WP_Error( 'ec_th_empty', __( 'Write a message.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		$now = Schema::now();
		$wpdb->insert( self::t( 'th_messages' ), array( 'thread_id' => $thread_id, 'author_id' => $author, 'body' => $body, 'created_at' => $now ) );
		$mid = (int) $wpdb->insert_id;
		$wpdb->update( self::t( 'th_threads' ), array( 'last_post_at' => $now ), array( 'id' => $thread_id ) );
		do_action( 'educore/th/message_posted', $thread_id, $mid, $author );
		return $mid;
	}

	/** @return array<int,array<string,mixed>> Messages visible to the viewer (hidden ones only for reviewers). */
	public static function messages( int $thread_id, int $viewer ): array {
		global $wpdb;
		$t = self::thread( $thread_id );
		if ( ! $t || 'none' === self::access( $viewer, $t ) ) {
			return array();
		}
		$is_participant = in_array( $viewer, array_merge( self::context_staff( $t['context_type'], (int) $t['context_id'] ), array( (int) $t['student_id'] ) ), true );
		if ( self::is_reviewer( $viewer ) && ! $is_participant ) {
			Audit::log( 'safeguarding.thread_viewed', 'thread', $thread_id, array( 'viewer' => $viewer ) );
		}
		$where = self::is_reviewer( $viewer ) ? '' : ' AND hidden=0';
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_messages' ) . " WHERE thread_id=%d{$where} ORDER BY id ASC", $thread_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Threads visible to a user (participant/guardian/staff), newest first. @return array<int,array<string,mixed>> */
	public static function threads_for( int $user_id, int $limit = 50 ): array {
		global $wpdb;
		$tt  = self::t( 'th_threads' );
		$or  = array( $wpdb->prepare( 'student_id=%d', $user_id ) );
		$cls = array_unique( array_merge( Caps::classes_of( $user_id ), Classes::of_student( $user_id ) ) );
		if ( $cls ) {
			$or[] = "(context_type='class' AND context_id IN (" . implode( ',', $cls ) . '))';
		}
		$sessions = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . self::t( 'th_sessions' ) . ' WHERE tutor_id=%d LIMIT 500', $user_id ) ) );
		if ( $sessions ) {
			$or[] = "(context_type='session' AND context_id IN (" . implode( ',', $sessions ) . '))';
		}
		$assign = $cls ? array_map( 'intval', $wpdb->get_col( 'SELECT id FROM ' . self::t( 'th_assignments' ) . ' WHERE class_id IN (' . implode( ',', $cls ) . ') LIMIT 1000' ) ) : array(); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( $assign ) {
			$or[] = "(context_type='assignment' AND context_id IN (" . implode( ',', $assign ) . '))';
		}
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$tt} WHERE (" . implode( ' OR ', $or ) . ') ORDER BY last_post_at DESC LIMIT %d', $limit ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		return array_values( array_filter( $rows, static fn( $t ) => 'none' !== self::access( $user_id, $t ) ) );
	}

	/** Threads of a minor visible to a guardian. @return array<int,array<string,mixed>> */
	public static function threads_for_guardian( int $guardian_id, int $student_id ): array {
		global $wpdb;
		if ( 'on' !== Settings::get( 'guardian_visibility' ) || ! CorePrivacy::guardian_has_access( $guardian_id, $student_id ) ) {
			return array();
		}
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_threads' ) . ' WHERE student_id=%d ORDER BY last_post_at DESC LIMIT 100', $student_id ), ARRAY_A ) ?: array();
	}

	/* ---------- Concern reports ---------- */

	/** @return int|\WP_Error */
	public static function report( int $reporter, int $thread_id, int $message_id, string $reason ) {
		global $wpdb;
		$t = self::thread( $thread_id );
		if ( ! $t || 'none' === self::access( $reporter, $t ) ) {
			return new \WP_Error( 'ec_th_forbidden', __( 'You cannot report this conversation.', 'educore-teaching-hub' ), array( 'status' => 403 ) );
		}
		if ( $message_id && ! $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM ' . self::t( 'th_messages' ) . ' WHERE id=%d AND thread_id=%d', $message_id, $thread_id ) ) ) {
			$message_id = 0;
		}
		$reason = sanitize_textarea_field( $reason );
		if ( '' === trim( $reason ) ) {
			return new \WP_Error( 'ec_th_reason', __( 'Please describe your concern.', 'educore-teaching-hub' ), array( 'status' => 400 ) );
		}
		$now = Schema::now();
		$wpdb->insert( self::t( 'th_reports' ), array( 'reporter_id' => $reporter, 'thread_id' => $thread_id, 'message_id' => $message_id, 'reason' => $reason, 'status' => 'open', 'created_at' => $now, 'updated_at' => $now ) );
		$rid = (int) $wpdb->insert_id;
		Audit::log( 'safeguarding.reported', 'report', $rid, array( 'thread_id' => $thread_id, 'message_id' => $message_id ) );
		do_action( 'educore/th/concern_reported', $rid );
		return $rid;
	}

	/** Reviewer actions: hide/unhide message, close/reopen thread, set report status. */
	public static function review( int $report_id, int $actor, string $status, string $resolution = '', int $hide_message = -1, string $thread_status = '' ): bool {
		global $wpdb;
		if ( ! self::is_reviewer( $actor ) || ! in_array( $status, array( 'open', 'reviewing', 'closed' ), true ) ) {
			return false;
		}
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_reports' ) . ' WHERE id=%d', $report_id ), ARRAY_A );
		if ( ! $r ) {
			return false;
		}
		$wpdb->update( self::t( 'th_reports' ), array( 'status' => $status, 'handled_by' => $actor, 'resolution' => sanitize_textarea_field( $resolution ), 'updated_at' => Schema::now() ), array( 'id' => $report_id ) );
		if ( $hide_message >= 0 && (int) $r['message_id'] ) {
			$wpdb->update( self::t( 'th_messages' ), array( 'hidden' => $hide_message ? 1 : 0 ), array( 'id' => (int) $r['message_id'] ) );
		}
		if ( in_array( $thread_status, array( 'open', 'closed' ), true ) ) {
			$wpdb->update( self::t( 'th_threads' ), array( 'status' => $thread_status ), array( 'id' => (int) $r['thread_id'] ) );
		}
		Audit::log( 'safeguarding.reviewed', 'report', $report_id, array( 'status' => $status, 'hide' => $hide_message, 'thread' => $thread_status ) );
		return true;
	}

	/** @return array<int,array<string,mixed>> */
	public static function reports( string $status = '' ): array {
		global $wpdb;
		$where = $status ? $wpdb->prepare( 'WHERE status=%s', $status ) : '';
		return $wpdb->get_results( 'SELECT * FROM ' . self::t( 'th_reports' ) . " {$where} ORDER BY status='closed', id DESC LIMIT 200", ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}
}
