<?php
/**
 * Title: EduCore — courses and subjects
 * Slug: educore-theme/courses
 * Categories: educore-theme, query
 * Description: Featured courses (only when courses are published) and the subject list.
 */
$ect_counts    = wp_count_posts( 'ec_course' );
$ect_published = isset( $ect_counts->publish ) ? (int) $ect_counts->publish : 0;
$ect_subjects  = class_exists( '\\EduCore\\Core\\Frontend\\Views' ) ? \EduCore\Core\Frontend\Views::subjects() : '';
if ( 0 === $ect_published && '' === $ect_subjects ) {
	return;
}
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}}},"className":"ect-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group ect-section" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--40)">
<?php if ( $ect_published > 0 ) : ?>
<!-- wp:paragraph {"align":"wide","className":"ect-eyebrow ect-eyebrow--dark"} --><p class="alignwide ect-eyebrow ect-eyebrow--dark"><?php esc_html_e( 'Courses', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:heading {"align":"wide","className":"ect-section__title"} --><h2 class="wp-block-heading alignwide ect-section__title"><?php esc_html_e( 'Featured courses', 'educore-theme' ); ?></h2><!-- /wp:heading -->
<!-- wp:educore/featured-courses {"count":3,"align":"wide"} /-->
<!-- wp:paragraph {"align":"wide","className":"ect-more"} --><p class="alignwide ect-more"><?php echo do_shortcode( '[educore_a courses all-courses arrow]' ); // phpcs:ignore -- shortcode returns escaped markup. ?></p><!-- /wp:paragraph -->
<?php endif; ?>
<?php if ( '' !== $ect_subjects ) : ?>
<!-- wp:heading {"align":"wide","className":"ect-section__title<?php echo $ect_published ? ' ect-section__title--sub' : ''; ?>"} --><h2 class="wp-block-heading alignwide ect-section__title<?php echo $ect_published ? ' ect-section__title--sub' : ''; ?>"><?php esc_html_e( 'Explore by subject', 'educore-theme' ); ?></h2><!-- /wp:heading -->
<!-- wp:html -->
<?php echo $ect_subjects; // phpcs:ignore -- rendered and escaped by EduCore Core. ?>
<!-- /wp:html -->
<?php endif; ?>
</div>
<!-- /wp:group -->
