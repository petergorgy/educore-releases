<?php
namespace EduCore\Workspace;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Curriculum;
use EduCore\Core\Schema;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/**
 * Programme overview (decision 2026-11-02, option A: the programme is the institutional unit). Read-only, aggregate
 * figures only — no learner names. `/manage/?v=programmes` and `/manage/?v=programme&id=…`. Structure is still
 * edited in the Studio (Academic structure); nothing here writes academic data.
 */
final class Programmes {

	public static function can( int $uid ): bool {
		return $uid > 0 && ( user_can( $uid, 'ec_manage_all_courses' ) || user_can( $uid, 'ec_manage_programmes' ) );
	}

	public static function register(): void {
		add_action( 'template_redirect', array( self::class, 'maybe_export' ), 5 );
	}

	private static function q( string $k ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view parameters.
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
	}

	private static function pct( int $part, int $whole ): string {
		return $whole ? number_format_i18n( $part * 100 / $whole, 1 ) . '%' : '—';
	}

	/** @return array<int,array{course_id:int,period_id:int,subject_id:int}> */
	private static function mappings( int $programme_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT course_id, period_id, subject_id FROM ' . Schema::table( 'curriculum_map' ) . ' WHERE programme_id=%d', $programme_id ), ARRAY_A ) ?: array();
	}

	/** Enrollment counts per course: [course_id => [active, completed, other]]. */
	private static function enrolment_counts( array $course_ids ): array {
		global $wpdb;
		$ids = array_values( array_filter( array_map( 'intval', $course_ids ) ) );
		if ( ! $ids ) {
			return array();
		}
		$rows = $wpdb->get_results( 'SELECT course_id, status, COUNT(*) n FROM ' . Schema::table( 'enrollments' ) . ' WHERE course_id IN (' . implode( ',', $ids ) . ') GROUP BY course_id, status', ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL -- integer list.
		$out  = array();
		foreach ( $rows as $r ) {
			$k                                = in_array( $r['status'], array( 'active', 'completed' ), true ) ? $r['status'] : 'other';
			$out[ (int) $r['course_id'] ][ $k ] = ( $out[ (int) $r['course_id'] ][ $k ] ?? 0 ) + (int) $r['n'];
		}
		return $out;
	}

	private static function distinct_learners( array $course_ids ): int {
		global $wpdb;
		$ids = array_values( array_filter( array_map( 'intval', $course_ids ) ) );
		return $ids ? (int) $wpdb->get_var( 'SELECT COUNT(DISTINCT user_id) FROM ' . Schema::table( 'enrollments' ) . ' WHERE status IN (\'active\',\'completed\') AND course_id IN (' . implode( ',', $ids ) . ')' ) : 0; // phpcs:ignore WordPress.DB.PreparedSQL -- integer list.
	}

	private static function profile_learners( int $programme_id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key='educore_programme_id' AND meta_value=%s", (string) $programme_id ) );
	}

	/** One summary row per programme. */
	public static function summary(): array {
		$out = array();
		foreach ( Curriculum::programmes() as $p ) {
			$pid     = (int) $p['id'];
			$courses = array_values( array_unique( array_map( static fn( $m ) => (int) $m['course_id'], self::mappings( $pid ) ) ) );
			$courses = array_values( array_filter( $courses, static fn( $c ) => Content::is_course( $c ) && 'trash' !== get_post_status( $c ) ) );
			$pub     = count( array_filter( $courses, static fn( $c ) => 'publish' === get_post_status( $c ) ) );
			$counts  = self::enrolment_counts( $courses );
			$active  = array_sum( array_map( static fn( $c ) => $c['active'] ?? 0, $counts ) );
			$done    = array_sum( array_map( static fn( $c ) => $c['completed'] ?? 0, $counts ) );
			$out[]   = array(
				'id'          => $pid,
				'code'        => (string) $p['code'],
				'name'        => (string) $p['name'],
				'country'     => (string) $p['country'],
				'status'      => (string) $p['status'],
				'periods'     => count( Curriculum::periods( $pid ) ),
				'subjects'    => count( Curriculum::subjects( $pid ) ),
				'courses'     => count( $courses ),
				'published'   => $pub,
				'learners'    => self::distinct_learners( $courses ),
				'profile'     => self::profile_learners( $pid ),
				'active'      => $active,
				'completed'   => $done,
				'course_ids'  => $courses,
			);
		}
		return $out;
	}

	/** Published courses not mapped to any programme (governance gap). @return \WP_Post[] */
	public static function unmapped(): array {
		global $wpdb;
		$mapped = array_map( 'intval', $wpdb->get_col( 'SELECT DISTINCT course_id FROM ' . Schema::table( 'curriculum_map' ) ) ?: array() ); // phpcs:ignore WordPress.DB.PreparedSQL
		return get_posts( array( 'post_type' => Content::COURSE, 'post_status' => 'publish', 'numberposts' => 200, 'post__not_in' => $mapped ?: array( 0 ), 'orderby' => 'title', 'order' => 'ASC' ) );
	}

	/* ---------- views ---------- */

	public static function view_list( int $uid ): string {
		Shell::title( __( 'Programmes', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), Pages::url( 'manage' ) ), array( __( 'Programmes', 'educore-workspace' ) ) ) );
		if ( ! self::can( $uid ) ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'You do not have access to this section.', 'educore-workspace' ) . '</div>';
		}
		$rows = self::summary();
		$o    = '<p class="ec-muted">' . esc_html__( 'Each programme is the institutional unit: its courses, learners and results at a glance. Figures are aggregates; open a course for detail.', 'educore-workspace' ) . '</p>';
		$act  = array();
		if ( user_can( $uid, 'ec_manage_programmes' ) ) {
			$act[] = '<a class="ec-btn" href="' . esc_url( Pages::url( 'studio', array( 'v' => 'academic' ) ) ) . '">' . esc_html__( 'Edit academic structure', 'educore-workspace' ) . '</a>';
		}
		if ( user_can( $uid, 'ec_export_reports' ) && $rows ) {
			$act[] = '<a class="ec-btn" href="' . esc_url( self::export_url() ) . '">' . esc_html__( 'Export summary (CSV)', 'educore-workspace' ) . '</a>';
		}
		$o .= $act ? '<p class="ec-ws-actions">' . implode( ' ', $act ) . '</p>' : '';
		if ( ! $rows ) {
			$o .= '<div class="ec-ws-empty"><p>' . esc_html__( 'No programmes yet.', 'educore-workspace' ) . '</p></div>';
		} else {
			$o .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><caption class="screen-reader-text">' . esc_html__( 'Programmes', 'educore-workspace' ) . '</caption><thead><tr><th scope="col">' . esc_html__( 'Programme', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Structure', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Courses (published)', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Learners', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Completion rate', 'educore-workspace' ) . '</th></tr></thead><tbody>';
			foreach ( $rows as $r ) {
				/* translators: 1: periods, 2: subjects */
				$struct = sprintf( __( '%1$d periods · %2$d subjects', 'educore-workspace' ), $r['periods'], $r['subjects'] );
				$o     .= '<tr><td><a href="' . esc_url( Pages::url( 'manage', array( 'v' => 'programme', 'id' => $r['id'] ) ) ) . '">' . esc_html( $r['name'] ) . '</a><br><code class="ec-muted">' . esc_html( $r['code'] ) . '</code>' . ( 'active' !== $r['status'] ? ' <span class="ec-chip ec-chip--warn">' . esc_html( $r['status'] ) . '</span>' : '' ) . '</td><td>' . esc_html( $struct ) . '</td><td>' . (int) $r['courses'] . ' (' . (int) $r['published'] . ')</td><td>' . esc_html( number_format_i18n( $r['learners'] ) ) . '</td><td>' . esc_html( self::pct( $r['completed'], $r['active'] + $r['completed'] ) ) . '</td></tr>';
			}
			$o .= '</tbody></table></div>';
		}
		$un = self::unmapped();
		if ( $un ) {
			/* translators: %d: number of courses */
			$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html( sprintf( _n( '%d published course is not linked to a programme', '%d published courses are not linked to a programme', count( $un ), 'educore-workspace' ), count( $un ) ) ) . '</h2><p class="ec-muted">' . esc_html__( 'These courses are missing from programme reporting. Link them in the course builder (Classification step).', 'educore-workspace' ) . '</p><ul class="ec-ws-list">';
			foreach ( $un as $c ) {
				$o .= '<li><span>' . esc_html( get_the_title( $c ) ?: '#' . $c->ID ) . '</span><a href="' . esc_url( Pages::url( 'studio', array( 'course' => $c->ID, 'step' => 'classification' ) ) ) . '">' . esc_html__( 'Classify', 'educore-workspace' ) . '</a></li>';
			}
			$o .= '</ul></section>';
		}
		return $o;
	}

	public static function view_detail( int $uid ): string {
		$id = (int) self::q( 'id' );
		$p  = null;
		foreach ( self::can( $uid ) ? self::summary() : array() as $r ) {
			if ( $r['id'] === $id ) {
				$p = $r;
			}
		}
		Shell::title( $p ? $p['name'] : __( 'Programme', 'educore-workspace' ) );
		Shell::crumbs( array( array( __( 'Management', 'educore-workspace' ), Pages::url( 'manage' ) ), array( __( 'Programmes', 'educore-workspace' ), Pages::url( 'manage', array( 'v' => 'programmes' ) ) ), array( $p ? $p['name'] : '—' ) ) );
		if ( ! self::can( $uid ) ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'You do not have access to this section.', 'educore-workspace' ) . '</div>';
		}
		if ( ! $p ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'Programme not found.', 'educore-workspace' ) . '</div>';
		}
		$stat = static fn( $v, $l ) => '<li class="ec-ws-stat"><span class="ec-ws-stat__v">' . esc_html( (string) $v ) . '</span><span class="ec-ws-stat__l">' . esc_html( $l ) . '</span></li>';
		$o    = '<ul class="ec-ws-stats">' . $stat( number_format_i18n( $p['courses'] ), __( 'Courses', 'educore-workspace' ) ) . $stat( number_format_i18n( $p['learners'] ), __( 'Enrolled learners', 'educore-workspace' ) ) . $stat( number_format_i18n( $p['active'] ), __( 'Active enrollments', 'educore-workspace' ) ) . $stat( self::pct( $p['completed'], $p['active'] + $p['completed'] ), __( 'Completion rate', 'educore-workspace' ) ) . $stat( number_format_i18n( $p['profile'] ), __( 'Learners with this programme in their profile', 'educore-workspace' ) ) . '</ul>';
		$links = array();
		if ( Insights::can( $uid ) && \EduCore\Analytics\Scope::is_global( $uid ) ) {
			$links[] = '<a class="ec-btn" href="' . esc_url( Pages::url( 'manage', array( 'v' => 'analytics', 'programme' => $id ) ) ) . '">' . esc_html__( 'Learning analytics for this programme', 'educore-workspace' ) . '</a>';
		}
		if ( user_can( $uid, 'ec_manage_programmes' ) ) {
			$links[] = '<a class="ec-btn" href="' . esc_url( Pages::url( 'studio', array( 'v' => 'academic' ) ) ) . '">' . esc_html__( 'Edit academic structure', 'educore-workspace' ) . '</a>';
		}
		$o .= $links ? '<p class="ec-ws-actions">' . implode( ' ', $links ) . '</p>' : '';

		$periods  = array_column( Curriculum::periods( $id ), 'label', 'id' );
		$subjects = array_column( Curriculum::subjects( $id ), 'name', 'id' );
		$maps     = self::mappings( $id );
		$counts   = self::enrolment_counts( $p['course_ids'] );
		$by_c     = array();
		foreach ( $maps as $m ) {
			$by_c[ (int) $m['course_id'] ][] = $m;
		}
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Courses', 'educore-workspace' ) . '</h2>';
		if ( ! $p['course_ids'] ) {
			$o .= '<p class="ec-muted">' . esc_html__( 'No course is linked to this programme yet.', 'educore-workspace' ) . '</p>';
		} else {
			$o .= '<div class="ec-ws-table-wrap"><table class="ec-ws-table"><caption class="screen-reader-text">' . esc_html__( 'Courses', 'educore-workspace' ) . '</caption><thead><tr><th scope="col">' . esc_html__( 'Course', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Period / subject', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Lead', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Active', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Completed', 'educore-workspace' ) . '</th><th scope="col">' . esc_html__( 'Completion rate', 'educore-workspace' ) . '</th></tr></thead><tbody>';
			foreach ( $p['course_ids'] as $cid ) {
				$where = implode( '; ', array_map( static fn( $m ) => trim( ( $periods[ $m['period_id'] ] ?? '' ) . ( (int) $m['subject_id'] ? ' · ' . ( $subjects[ $m['subject_id'] ] ?? '' ) : '' ), ' ·' ), $by_c[ $cid ] ?? array() ) );
				$leads = array_map( static fn( $r ) => get_userdata( (int) $r['user_id'] )->display_name ?? '', array_filter( Staff::of_course( $cid ), static fn( $r ) => 'lead' === $r['staff_role'] ) );
				$a     = (int) ( $counts[ $cid ]['active'] ?? 0 );
				$d     = (int) ( $counts[ $cid ]['completed'] ?? 0 );
				$st    = get_post_status( $cid );
				$o    .= '<tr><td><a href="' . esc_url( Pages::url( 'manage', array( 'v' => 'course', 'id' => $cid ) ) ) . '">' . esc_html( get_the_title( $cid ) ?: '#' . $cid ) . '</a>' . ( 'publish' !== $st ? ' <span class="ec-chip ec-chip--' . esc_attr( (string) $st ) . '">' . esc_html( \EduCore\Workspace\Studio\View::status_label( (string) $st ) ) . '</span>' : '' ) . '</td><td>' . esc_html( $where ?: '—' ) . '</td><td>' . esc_html( implode( ', ', array_filter( $leads ) ) ?: '—' ) . '</td><td>' . $a . '</td><td>' . $d . '</td><td>' . esc_html( self::pct( $d, $a + $d ) ) . '</td></tr>';
			}
			$o .= '</tbody></table></div>';
		}
		$o .= '</section>';

		// Structure: periods with their courses, so gaps are visible.
		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Academic structure', 'educore-workspace' ) . '</h2>';
		if ( ! $periods ) {
			$o .= '<p class="ec-muted">' . esc_html__( 'No academic years or semesters defined.', 'educore-workspace' ) . '</p>';
		} else {
			$o .= '<ul class="ec-ws-list">';
			foreach ( $periods as $pid => $label ) {
				$n  = count( array_filter( $maps, static fn( $m ) => (int) $m['period_id'] === (int) $pid ) );
				/* translators: %d: number of courses */
				$o .= '<li><span>' . esc_html( $label ) . '</span>' . ( $n ? '<span class="ec-muted">' . esc_html( sprintf( _n( '%d course', '%d courses', $n, 'educore-workspace' ), $n ) ) . '</span>' : '<span class="ec-chip ec-chip--warn">' . esc_html__( 'No course', 'educore-workspace' ) . '</span>' ) . '</li>';
			}
			$o .= '</ul>';
		}
		if ( $subjects ) {
			$o .= '<h3>' . esc_html__( 'Subjects', 'educore-workspace' ) . '</h3><ul class="ec-ws-list">';
			foreach ( $subjects as $sid => $name ) {
				$n  = count( array_filter( $maps, static fn( $m ) => (int) $m['subject_id'] === (int) $sid ) );
				/* translators: %d: number of courses */
				$o .= '<li><span>' . esc_html( $name ) . '</span>' . ( $n ? '<span class="ec-muted">' . esc_html( sprintf( _n( '%d course', '%d courses', $n, 'educore-workspace' ), $n ) ) . '</span>' : '<span class="ec-chip ec-chip--warn">' . esc_html__( 'No course', 'educore-workspace' ) . '</span>' ) . '</li>';
			}
			$o .= '</ul>';
		}
		return $o . '</section>';
	}

	/* ---------- export ---------- */

	/** Neutralise spreadsheet formulas (CSV injection). */
	public static function safe_cell( $v ): string {
		$v = (string) $v;
		return ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) ? "'" . $v : $v;
	}

	public static function export_url(): string {
		return add_query_arg( array( 'ec_programmes_csv' => 1, '_ecdl' => wp_create_nonce( 'ec_programmes_csv' ) ), Pages::url( 'manage' ) );
	}

	public static function rows(): array {
		$rows = array( array( 'code', 'programme', 'status', 'periods', 'subjects', 'courses', 'published_courses', 'enrolled_learners', 'active_enrollments', 'completed_enrollments', 'completion_rate_pct' ) );
		foreach ( self::summary() as $r ) {
			$tot    = $r['active'] + $r['completed'];
			$rows[] = array( $r['code'], $r['name'], $r['status'], $r['periods'], $r['subjects'], $r['courses'], $r['published'], $r['learners'], $r['active'], $r['completed'], $tot ? round( $r['completed'] * 100 / $tot, 1 ) : '' );
		}
		return $rows;
	}

	public static function maybe_export(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- verified below.
		if ( empty( $_GET['ec_programmes_csv'] ) ) {
			return;
		}
		$nonce = isset( $_GET['_ecdl'] ) ? sanitize_text_field( wp_unslash( $_GET['_ecdl'] ) ) : '';
		// phpcs:enable
		$uid = get_current_user_id();
		if ( ! wp_verify_nonce( $nonce, 'ec_programmes_csv' ) || ! self::can( $uid ) || ! user_can( $uid, 'ec_export_reports' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to download this file.', 'educore-workspace' ), '', array( 'response' => 403 ) );
		}
		$safe = array( self::class, 'safe_cell' );
		$fh   = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $fh, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- UTF-8 BOM for Excel.
		foreach ( self::rows() as $r ) {
			fputcsv( $fh, array_map( $safe, $r ), ',', '"', '' );
		}
		rewind( $fh );
		$csv = (string) stream_get_contents( $fh );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		Audit::log( 'programmes.exported', 'report', 0, array( 'rows' => substr_count( $csv, "\n" ) - 1 ) );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="educore-programmes-' . gmdate( 'Ymd-His' ) . '.csv"' );
		header( 'X-Content-Type-Options: nosniff' );
		echo $csv; // phpcs:ignore WordPress.Security.EscapeOutput -- CSV file, injection-neutralised.
		exit;
	}
}
