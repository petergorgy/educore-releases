<?php
namespace EduCore\Experience;

defined( 'ABSPATH' ) || exit;

/** City list for the sunrise/sunset appearance: a privacy-friendly alternative to device location. */
final class Cities {
	/** key => [name, lat, lng, IANA zone] */
	private const LIST = array(
		'cairo'          => array( 'Cairo', 30.04, 31.24, 'Africa/Cairo' ),
		'alexandria'     => array( 'Alexandria', 31.20, 29.92, 'Africa/Cairo' ),
		'giza'           => array( 'Giza', 30.01, 31.21, 'Africa/Cairo' ),
		'port-said'      => array( 'Port Said', 31.26, 32.30, 'Africa/Cairo' ),
		'ismailia'       => array( 'Ismailia', 30.60, 32.27, 'Africa/Cairo' ),
		'mansoura'       => array( 'Mansoura', 31.04, 31.38, 'Africa/Cairo' ),
		'tanta'          => array( 'Tanta', 30.79, 31.00, 'Africa/Cairo' ),
		'minya'          => array( 'Minya', 28.11, 30.75, 'Africa/Cairo' ),
		'assiut'         => array( 'Assiut', 27.18, 31.18, 'Africa/Cairo' ),
		'luxor'          => array( 'Luxor', 25.69, 32.64, 'Africa/Cairo' ),
		'aswan'          => array( 'Aswan', 24.09, 32.90, 'Africa/Cairo' ),
		'hurghada'       => array( 'Hurghada', 27.26, 33.81, 'Africa/Cairo' ),
		'riyadh'         => array( 'Riyadh', 24.71, 46.68, 'Asia/Riyadh' ),
		'jeddah'         => array( 'Jeddah', 21.49, 39.19, 'Asia/Riyadh' ),
		'dubai'          => array( 'Dubai', 25.20, 55.27, 'Asia/Dubai' ),
		'doha'           => array( 'Doha', 25.29, 51.53, 'Asia/Qatar' ),
		'kuwait'         => array( 'Kuwait City', 29.38, 47.99, 'Asia/Kuwait' ),
		'amman'          => array( 'Amman', 31.95, 35.93, 'Asia/Amman' ),
		'beirut'         => array( 'Beirut', 33.89, 35.50, 'Asia/Beirut' ),
		'casablanca'     => array( 'Casablanca', 33.57, -7.59, 'Africa/Casablanca' ),
		'tunis'          => array( 'Tunis', 36.81, 10.18, 'Africa/Tunis' ),
		'algiers'        => array( 'Algiers', 36.75, 3.06, 'Africa/Algiers' ),
		'khartoum'       => array( 'Khartoum', 15.50, 32.56, 'Africa/Khartoum' ),
		'paris'          => array( 'Paris', 48.86, 2.35, 'Europe/Paris' ),
		'lyon'           => array( 'Lyon', 45.76, 4.84, 'Europe/Paris' ),
		'brussels'       => array( 'Brussels', 50.85, 4.35, 'Europe/Brussels' ),
		'geneva'         => array( 'Geneva', 46.20, 6.14, 'Europe/Zurich' ),
		'montreal'       => array( 'Montréal', 45.50, -73.57, 'America/Toronto' ),
		'london'         => array( 'London', 51.51, -0.13, 'Europe/London' ),
		'rome'           => array( 'Rome', 41.90, 12.50, 'Europe/Rome' ),
		'berlin'         => array( 'Berlin', 52.52, 13.40, 'Europe/Berlin' ),
		'athens'         => array( 'Athens', 37.98, 23.73, 'Europe/Athens' ),
		'istanbul'       => array( 'Istanbul', 41.01, 28.98, 'Europe/Istanbul' ),
		'nairobi'        => array( 'Nairobi', -1.29, 36.82, 'Africa/Nairobi' ),
		'lagos'          => array( 'Lagos', 6.52, 3.38, 'Africa/Lagos' ),
		'johannesburg'   => array( 'Johannesburg', -26.20, 28.05, 'Africa/Johannesburg' ),
		'new-york'       => array( 'New York', 40.71, -74.01, 'America/New_York' ),
		'toronto'        => array( 'Toronto', 43.65, -79.38, 'America/Toronto' ),
		'los-angeles'    => array( 'Los Angeles', 34.05, -118.24, 'America/Los_Angeles' ),
		'sydney'         => array( 'Sydney', -33.87, 151.21, 'Australia/Sydney' ),
		'mumbai'         => array( 'Mumbai', 19.08, 72.88, 'Asia/Kolkata' ),
		'singapore'      => array( 'Singapore', 1.35, 103.82, 'Asia/Singapore' ),
		'tokyo'          => array( 'Tokyo', 35.68, 139.69, 'Asia/Tokyo' ),
		'reykjavik'      => array( 'Reykjavík', 64.15, -21.94, 'Atlantic/Reykjavik' ),
		'tromso'         => array( 'Tromsø', 69.65, 18.96, 'Europe/Oslo' ),
	);

	/** @return array{key:string,name:string,lat:float,lng:float,tz:string}|null */
	public static function get( string $key ): ?array {
		$c = self::LIST[ $key ] ?? null;
		return $c ? array( 'key' => $key, 'name' => $c[0], 'lat' => (float) $c[1], 'lng' => (float) $c[2], 'tz' => $c[3] ) : null;
	}

	public static function all(): array {
		$out = array();
		foreach ( array_keys( self::LIST ) as $k ) {
			$out[] = self::get( $k );
		}
		return $out;
	}
}
