<?php
namespace EduCore\Recovery;

use EduCore\Core\Audit;
use EduCore\Core\Registry;

defined( 'ABSPATH' ) || exit;

/**
 * Guarded restore: validate → compatibility → impact preview → typed confirmation → safety snapshot →
 * maintenance mode → load into staging tables → verify staging → atomic swap → post-verification.
 * Live tables are replaced only after the staged copy has been proven identical to the backup.
 */
final class Restore {
	public const STAGE = 'ecrs_';
	public const OLD   = 'ecold_';
	/** Target-environment options that are kept across a restore (so a restore into an isolated copy stays isolated). */
	public const KEEP_OPTIONS = array( 'siteurl', 'home', 'educore_rc_dir', 'educore_rc_cron_hash', Settings::OPTION, 'educore_rc_db_version', Settings::KEY_DIR_OPTION, 'educore_rc_key_downloaded', 'educore_rc_last_tick_cli', 'educore_rc_last_tick_http' );

	public static function confirmation_phrase( object $b ): string {
		return 'RESTORE ' . $b->uid;
	}

	/** Components in the backup that are NEWER than installed code (restoring them would be unsafe). */
	public static function compatibility( array $manifest ): array {
		$issues    = array();
		$installed = Registry::all();
		foreach ( (array) ( $manifest['versions']['components'] ?? array() ) as $pkg => $ver ) {
			if ( isset( $installed[ $pkg ] ) && version_compare( (string) $ver, (string) $installed[ $pkg ], '>' ) ) {
				/* translators: 1: component, 2: backup version, 3: installed version */
				$issues[] = sprintf( __( '%1$s in the backup is %2$s but %3$s is installed. Update the code first.', 'educore-recovery' ), $pkg, $ver, $installed[ $pkg ] );
			}
		}
		if ( (int) ( $manifest['format'] ?? 0 ) > Backup::FORMAT ) {
			$issues[] = __( 'The backup was created by a newer version of the Backup & Recovery Center.', 'educore-recovery' );
		}
		return $issues;
	}

	/** Impact preview: per-table current vs backup rows, recovery-point age, validation and compatibility. */
	public static function preview( int $id ): array {
		global $wpdb;
		$b = Backup::get( $id );
		if ( ! $b || 'complete' !== $b->status ) {
			return array( 'ok' => false, 'errors' => array( __( 'Backup not found or not complete.', 'educore-recovery' ) ) );
		}
		$v = Verifier::verify( $id );
		if ( ! $v['ok'] ) {
			return array( 'ok' => false, 'errors' => $v['errors'] );
		}
		$h = Backup::open( $b );
		if ( is_wp_error( $h ) ) {
			return array( 'ok' => false, 'errors' => array( $h->get_error_message() ) );
		}
		$man = $h['manifest'];
		$h['cleanup']();
		$rows = array();
		foreach ( (array) $man['tables'] as $rel => $exp ) {
			$t       = $wpdb->prefix . substr( $rel, strlen( Dumper::PH ) );
			$exists  = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) );
			$current = $exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$t}`" ) : null; // phpcs:ignore WordPress.DB.PreparedSQL
			$rows[ substr( $rel, strlen( Dumper::PH ) ) ] = array( 'current' => $current, 'backup' => (int) $exp['rows'] );
		}
		$compat = self::compatibility( $man );
		return array(
			'ok'           => ! $compat,
			'errors'       => $compat,
			'backup'       => $b,
			'age_hours'    => round( ( time() - strtotime( $man['created_at'] ) ) / 3600, 1 ),
			'created_at'   => $man['created_at'],
			'tables'       => $rows,
			'has_uploads'  => in_array( 'uploads', (array) ( $man['scope']['files'] ?? array() ), true ),
			'phrase'       => self::confirmation_phrase( $b ),
			'versions'     => $man['versions'],
		);
	}

	/**
	 * Execute a restore. $args: confirm (string, must equal the phrase), uploads (bool), snapshot (bool, default true).
	 *
	 * @return array{ok:bool,errors:string[],safety?:int,report?:array}
	 */
	public static function run( int $id, array $args ): array {
		global $wpdb;
		$p = self::preview( $id );
		if ( ! $p['ok'] ) {
			return array( 'ok' => false, 'errors' => $p['errors'] );
		}
		$b = $p['backup'];
		if ( ( $args['confirm'] ?? '' ) !== $p['phrase'] ) {
			return array( 'ok' => false, 'errors' => array( __( 'The confirmation phrase does not match. Nothing was changed.', 'educore-recovery' ) ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		$started = microtime( true );
		$safety  = 0;
		if ( $args['snapshot'] ?? true ) {
			$safety = Backup::create( 'full' === $b->kind ? 'full' : 'academic', 'pre_restore' );
			if ( ! is_wp_error( $safety ) && ! Verifier::verify( $safety )['ok'] ) {
				$safety = new \WP_Error( 'ec_rc_safety', 'verification failed' );
			}
			if ( is_wp_error( $safety ) ) {
				return array( 'ok' => false, 'errors' => array( __( 'Safety snapshot failed; restore aborted. Nothing was changed.', 'educore-recovery' ) . ' ' . $safety->get_error_message() ) );
			}
		}
		$h = Backup::open( $b );
		if ( is_wp_error( $h ) ) {
			return array( 'ok' => false, 'errors' => array( $h->get_error_message() ) );
		}
		$man  = $h['manifest'];
		$sql  = Backup::extract_sql( $h['zip'] );
		$rels = array_keys( (array) $man['tables'] );
		$stage = $wpdb->prefix . self::STAGE;
		RestoreTest::drop( $stage, $rels );
		$loaded = Dumper::load( $sql, $stage, $rels );
		wp_delete_file( $sql );
		$errors = array();
		if ( is_wp_error( $loaded ) ) {
			$errors[] = $loaded->get_error_message();
		} else {
			foreach ( $man['tables'] as $rel => $exp ) {
				$got = Dumper::fingerprint( $stage . substr( $rel, strlen( Dumper::PH ) ) );
				if ( $got['rows'] !== (int) $exp['rows'] || ! hash_equals( (string) $exp['sha256'], $got['sha256'] ) ) {
					$errors[] = sprintf( /* translators: %s: table */ __( 'Staged data differs for table %s', 'educore-recovery' ), $rel );
				}
			}
		}
		if ( $errors ) {
			RestoreTest::drop( $stage, $rels );
			$h['cleanup']();
			Audit::log( 'backup.restore_aborted', 'backup', (int) $b->id, array( 'uid' => $b->uid, 'errors' => $errors ) );
			return array( 'ok' => false, 'errors' => array_merge( array( __( 'Restore aborted before any live data was touched.', 'educore-recovery' ) ), $errors ), 'safety' => (int) $safety );
		}

		// Values kept from the target environment.
		$keep = array();
		foreach ( self::KEEP_OPTIONS as $o ) {
			$keep[ $o ] = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $o ) );
		}
		$active = (array) get_option( 'active_plugins', array() );

		self::maintenance( true );
		// Atomic swap: one RENAME statement moves every live table aside and every staged table in.
		$old   = $wpdb->prefix . self::OLD;
		$pairs = array();
		$drop_old = array();
		foreach ( $rels as $rel ) {
			$name = substr( $rel, strlen( Dumper::PH ) );
			$live = $wpdb->prefix . $name;
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $live ) ) ) ) {
				$wpdb->query( "DROP TABLE IF EXISTS `{$old}{$name}`" ); // phpcs:ignore WordPress.DB.PreparedSQL
				$pairs[]    = "`{$live}` TO `{$old}{$name}`";
				$drop_old[] = $old . $name;
			}
			$pairs[] = "`{$stage}{$name}` TO `{$live}`";
		}
		if ( false === $wpdb->query( 'RENAME TABLE ' . implode( ', ', $pairs ) ) ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$err = $wpdb->last_error;
			RestoreTest::drop( $stage, $rels );
			self::maintenance( false );
			$h['cleanup']();
			Audit::log( 'backup.restore_aborted', 'backup', (int) $b->id, array( 'uid' => $b->uid, 'error' => $err ) );
			return array( 'ok' => false, 'errors' => array( __( 'The table swap failed and was rolled back by the database. Live data is unchanged.', 'educore-recovery' ), $err ), 'safety' => (int) $safety );
		}

		// Post-verification of the now-live tables, before anything else writes to them.
		$report = array();
		foreach ( $man['tables'] as $rel => $exp ) {
			$name = substr( $rel, strlen( Dumper::PH ) );
			$got  = Dumper::fingerprint( $wpdb->prefix . $name );
			$report[ $name ] = array( 'rows' => $got['rows'], 'match' => $got['rows'] === (int) $exp['rows'] && hash_equals( (string) $exp['sha256'], $got['sha256'] ) );
		}
		// The audit trail is append-only: events recorded after the recovery point are carried over, not lost.
		$audit_carried = 0;
		if ( in_array( $old . 'ec_audit_events', $drop_old, true ) ) {
			$live_audit    = $wpdb->prefix . 'ec_audit_events';
			$cols          = 'actor_id, action, object_type, object_id, ip_hash, context, created_at';
			$audit_carried = (int) $wpdb->query( $wpdb->prepare( "INSERT INTO `{$live_audit}` ({$cols}) SELECT {$cols} FROM `{$old}ec_audit_events` WHERE created_at >= %s ORDER BY id", gmdate( 'Y-m-d H:i:s', strtotime( (string) $man['created_at'] ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL -- identifiers built from the site prefix.
		}
		foreach ( $drop_old as $t ) {
			$wpdb->query( "DROP TABLE IF EXISTS `{$t}`" ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		foreach ( $keep as $o => $val ) {
			if ( null !== $val ) {
				$wpdb->replace( $wpdb->options, array( 'option_name' => $o, 'option_value' => $val, 'autoload' => in_array( $o, array( 'siteurl', 'home' ), true ) ? 'on' : 'off' ) );
			}
		}
		wp_cache_flush();
		$plugins = (array) get_option( 'active_plugins', array() );
		foreach ( array( 'educore-core/educore-core.php', plugin_basename( EDUCORE_RC_FILE ) ) as $must ) {
			if ( in_array( $must, $active, true ) && ! in_array( $must, $plugins, true ) ) {
				$plugins[] = $must;
			}
		}
		update_option( 'active_plugins', array_values( array_unique( $plugins ) ) );

		$files = 0;
		if ( ! empty( $args['uploads'] ) && $p['has_uploads'] ) {
			$files = self::restore_uploads( $h['zip'], (array) $man['entries'] );
		}
		$h['cleanup']();
		// Bring an older schema up to the installed code (migrations are additive and idempotent).
		do_action( 'educore/install/repair' );
		self::maintenance( false );

		$ok = ! in_array( false, array_column( $report, 'match' ), true );
		$summary = array( 'tables' => count( $report ), 'rows' => array_sum( array_column( $report, 'rows' ) ), 'files' => $files, 'audit_events_carried' => $audit_carried, 'seconds' => round( microtime( true ) - $started, 2 ), 'verified' => $ok );
		Audit::log( 'backup.restored', 'backup', (int) $b->id, array( 'uid' => $b->uid, 'safety_snapshot' => (int) $safety ) + $summary );
		update_option( 'educore_rc_last_restore', array( 'uid' => $b->uid, 'at' => gmdate( 'c' ) ) + $summary, false );
		return array( 'ok' => $ok, 'errors' => $ok ? array() : array( __( 'Post-restore verification found differences.', 'educore-recovery' ) ), 'safety' => (int) $safety, 'report' => $summary );
	}

	private static function restore_uploads( \ZipArchive $zip, array $entries ): int {
		$base = wp_normalize_path( wp_upload_dir( null, false )['basedir'] );
		$n    = 0;
		foreach ( $entries as $name => $meta ) {
			if ( 0 !== strpos( $name, 'files/uploads/' ) ) {
				continue;
			}
			$rel = substr( $name, strlen( 'files/uploads/' ) );
			if ( '' === $rel || false !== strpos( $rel, '..' ) || 0 === strpos( $rel, '/' ) ) {
				continue;
			}
			$dest = $base . '/' . $rel;
			wp_mkdir_p( dirname( $dest ) );
			$in = $zip->getStream( $name );
			$w  = fopen( $dest, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( $in && $w ) {
				stream_copy_to_stream( $in, $w );
				++$n;
			}
			$w && fclose( $w ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$in && fclose( $in ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		return $n;
	}

	private static function maintenance( bool $on ): void {
		$f = ABSPATH . '.maintenance';
		if ( $on ) {
			file_put_contents( $f, '<?php $upgrading = ' . time() . ';' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		} elseif ( file_exists( $f ) ) {
			wp_delete_file( $f );
		}
	}
}
