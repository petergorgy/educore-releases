/* EduCore sign-in: accessible errors, submit feedback, no double submission. Progressive enhancement only. */
( function () {
	'use strict';
	var t = window.educoreAuth || {};
	var main = document.getElementById( 'login' );
	if ( main && ! main.getAttribute( 'role' ) ) {
		main.setAttribute( 'role', 'main' );
	}
	var err = document.getElementById( 'login_error' );
	if ( err ) {
		err.setAttribute( 'role', 'alert' );
		err.setAttribute( 'tabindex', '-1' );
		err.classList.add( 'ec-shake' );
		// The message is deliberately generic, so both credentials are flagged and described by it.
		document.querySelectorAll( '#loginform #user_login, #loginform #user_pass, #lostpasswordform #user_login' ).forEach( function ( f ) {
			f.setAttribute( 'aria-invalid', 'true' );
			f.setAttribute( 'aria-describedby', ( ( f.getAttribute( 'aria-describedby' ) || '' ) + ' login_error' ).trim() );
		} );
	}
	// Informational notices are polite; errors (#login_error, .notice-error) keep role=alert.
	document.querySelectorAll( '#login .message, #login .notice' ).forEach( function ( m ) {
		if ( m !== err && ! m.classList.contains( 'notice-error' ) ) {
			m.setAttribute( 'role', 'status' );
		}
	} );
	var labels = { loginform: t.signingIn, lostpasswordform: t.sending, resetpassform: t.saving };
	Object.keys( labels ).forEach( function ( id ) {
		var form = document.getElementById( id );
		if ( ! form ) {
			return;
		}
		form.addEventListener( 'submit', function ( e ) {
			if ( form.dataset.ecBusy ) {
				e.preventDefault();
				return;
			}
			form.dataset.ecBusy = '1';
			form.setAttribute( 'aria-busy', 'true' );
			var btn = form.querySelector( '[type="submit"].button-primary' );
			if ( btn && labels[ id ] ) {
				btn.classList.add( 'is-loading' );
				btn.value = labels[ id ];
			}
			// Re-enable if the browser stays on the page (e.g. validation, back button).
			window.setTimeout( function () {
				delete form.dataset.ecBusy;
				form.removeAttribute( 'aria-busy' );
			}, 8000 );
		} );
	} );
}() );
