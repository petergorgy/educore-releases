<?php
namespace EduCore\TeachingHub;

defined( 'ABSPATH' ) || exit;

/** Teaching Hub settings (one option, validated on save). */
final class Settings {
	public const OPTION = 'educore_th_settings';

	public static function defaults(): array {
		return array(
			'file_types'             => 'pdf,docx,pptx,xlsx,odt,txt,png,jpg,jpeg',
			'max_file_mb'            => 10,
			'max_files'              => 3,
			'meeting_hosts'          => 'meet.google.com,zoom.us,teams.microsoft.com,teams.live.com',
			'guardian_visibility'    => 'on',
			'staff_start_minor_thread' => 'off',
			'minor_tutoring_guardian'=> 'on',
			'slot_minutes'           => 15,
			'max_booking_days'       => 60,
			'alert_missing'          => 2,
			'alert_low_score_pct'    => 50,
			'alert_inactive_days'    => 14,
			'alert_absences'         => 3,
			'alert_failed_assessments' => 2,
			'alert_decline_pct'      => 20,
		);
	}

	public static function all(): array {
		return array_merge( self::defaults(), (array) get_option( self::OPTION, array() ) );
	}

	/** @return mixed */
	public static function get( string $key ) {
		$all = self::all();
		return $all[ $key ] ?? null;
	}

	/** Sanitize a submitted settings array against the defaults' types. */
	public static function sanitize( array $in ): array {
		$out = self::all();
		foreach ( self::defaults() as $k => $default ) {
			if ( ! array_key_exists( $k, $in ) ) {
				continue;
			}
			if ( is_int( $default ) ) {
				$out[ $k ] = max( 0, min( 1000, absint( $in[ $k ] ) ) );
			} elseif ( in_array( $default, array( 'on', 'off' ), true ) ) {
				$out[ $k ] = 'on' === $in[ $k ] ? 'on' : 'off';
			} else {
				$out[ $k ] = implode( ',', array_filter( array_map( static fn( $v ) => preg_replace( '/[^a-z0-9.\-]/', '', strtolower( trim( $v ) ) ), explode( ',', (string) $in[ $k ] ) ) ) );
			}
		}
		$out['slot_minutes'] = in_array( (int) $out['slot_minutes'], array( 5, 10, 15, 30 ), true ) ? (int) $out['slot_minutes'] : 15;
		$out['max_file_mb']  = max( 1, min( 50, (int) $out['max_file_mb'] ) );
		return $out;
	}

	public static function save( array $in ): void {
		update_option( self::OPTION, self::sanitize( $in ), false );
	}
}
