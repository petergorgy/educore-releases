<?php
/**
 * Plugin Name:       EduCore Backup & Recovery
 * Plugin URI:        https://educore.gorgy.org
 * Description:       Verified backups of EduCore (database snapshot + files) with checksummed manifests, optional encryption, non-destructive restore tests, a guarded restore wizard, schedules and retention.
 * Version:           1.2.0
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core
 * EduCore Requires Core: 1.1.0
 * Author:            GORGY.ORG
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-recovery
 * Domain Path:       /languages
 *
 * @package EduCore\Recovery
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_RC_VERSION', '1.2.0' );
define( 'EDUCORE_RC_DB_VERSION', 1 );
define( 'EDUCORE_RC_FILE', __FILE__ );
define( 'EDUCORE_RC_DIR', plugin_dir_path( __FILE__ ) );

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Backup & Recovery', '1.1.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Recovery\\', EDUCORE_RC_DIR . 'src/' );
		\EduCore\Recovery\Plugin::boot();
	}
);

register_activation_hook(
	__FILE__,
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die( esc_html__( 'Please activate EduCore Core first.', 'educore-recovery' ), '', array( 'back_link' => true ) );
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Recovery\\', EDUCORE_RC_DIR . 'src/' );
		\EduCore\Recovery\Plugin::install();
	}
);

register_deactivation_hook( __FILE__, static fn() => wp_clear_scheduled_hook( 'educore_rc_tick' ) );
