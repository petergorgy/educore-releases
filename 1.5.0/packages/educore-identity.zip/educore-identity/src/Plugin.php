<?php
namespace EduCore\Identity;

use EduCore\Core\Registry;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	public const DB_VERSION = 1;

	public static function boot(): void {
		Registry::register( 'identity', EDUCORE_ID_VERSION );
		add_action( 'init', static fn() => load_plugin_textdomain( 'educore-identity', false, dirname( plugin_basename( EDUCORE_ID_FILE ) ) . '/languages' ), 1 );
		if ( (int) get_option( 'educore_id_db', 0 ) < self::DB_VERSION ) {
			add_action( 'init', array( self::class, 'install' ), 20 );
		}
		add_action( 'educore/install/repair', array( self::class, 'install' ) );
		add_filter( 'educore/rate_limits', array( self::class, 'rate_limits' ) );
		Flow::register();
		LoginUi::register();
		Admin::register();
		Connected::register();
		Privacy::register();
	}

	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = Links::table();
		dbDelta(
			"CREATE TABLE {$t} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				provider VARCHAR(20) NOT NULL,
				subject VARCHAR(191) NOT NULL,
				email VARCHAR(191) NOT NULL DEFAULT '',
				email_verified TINYINT(1) NOT NULL DEFAULT 0,
				display_name VARCHAR(191) NOT NULL DEFAULT '',
				created_at DATETIME NOT NULL,
				last_login_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY provider_subject (provider, subject),
				KEY user_id (user_id)
			) " . $wpdb->get_charset_collate() . ';'
		);
		update_option( 'educore_id_db', self::DB_VERSION, false );
		update_option( 'educore_id_version', EDUCORE_ID_VERSION, false );
	}

	public static function rate_limits( $p ) {
		$p                  = (array) $p;
		$p['sso_start']     = array( 30, 600 );
		$p['sso_callback']  = array( 30, 600 );
		$p['sso_link']      = array( 10, 3600 );
		return $p;
	}
}
