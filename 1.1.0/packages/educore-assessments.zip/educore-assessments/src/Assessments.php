<?php
namespace EduCore\Assessments;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Schema as CoreSchema;

defined( 'ABSPATH' ) || exit;

/** Assessment definitions (practice / quiz / exam) and question pools. */
final class Assessments {
	public const KINDS    = array( 'practice', 'quiz', 'exam' );
	public const STATUSES = array( 'draft', 'published', 'archived' );
	public const FEEDBACK = array( 'none', 'after_release', 'after_attempts_exhausted' );

	public static function defaults( string $kind = 'quiz' ): array {
		return array(
			'duration'          => 'exam' === $kind ? 45 : 0,
			'attempts'          => 'exam' === $kind ? 1 : 3,
			'shuffle_questions' => true,
			'shuffle_options'   => true,
			'feedback'          => 'exam' === $kind ? 'after_attempts_exhausted' : 'after_release',
			'release'           => 'exam' === $kind ? 'manual' : 'auto',
			'pass_mark'         => 50,
			'total_mark'        => 0,
			'opens_at'          => '',
			'closes_at'         => '',
			'instructions'      => '',
		);
	}

	public static function sanitize_settings( array $in, string $kind ): array {
		$s = array_merge( self::defaults( $kind ), array_intersect_key( $in, self::defaults( $kind ) ) );
		return array(
			'duration'          => max( 0, min( 600, (int) $s['duration'] ) ),
			'attempts'          => max( 0, min( 100, (int) $s['attempts'] ) ),
			'shuffle_questions' => (bool) $s['shuffle_questions'],
			'shuffle_options'   => (bool) $s['shuffle_options'],
			'feedback'          => in_array( $s['feedback'], self::FEEDBACK, true ) ? $s['feedback'] : 'after_release',
			'release'           => 'manual' === $s['release'] ? 'manual' : 'auto',
			'pass_mark'         => max( 0, min( 100, (float) $s['pass_mark'] ) ),
			'total_mark'        => max( 0, (float) $s['total_mark'] ),
			'opens_at'          => self::date( (string) $s['opens_at'] ),
			'closes_at'         => self::date( (string) $s['closes_at'] ),
			'instructions'      => sanitize_textarea_field( (string) $s['instructions'] ),
		);
	}

	private static function date( string $v ): string {
		if ( '' === trim( $v ) ) {
			return '';
		}
		$ts = strtotime( $v . ( preg_match( '/Z|[+-]\d\d:?\d\d$/', $v ) ? '' : ' UTC' ) );
		return $ts ? gmdate( 'Y-m-d H:i:s', $ts ) : '';
	}

	/**
	 * Convert an availability input to the stored UTC format (Y-m-d H:i:s).
	 * ISO-8601 with an offset/Z is honoured as given; a naive value (admin form,
	 * "2026-11-02 10:00" or "2026-11-02T10:00") is interpreted in the SITE timezone
	 * (wp_timezone(), DST-aware, e.g. Africa/Cairo). Invalid input yields ''.
	 */
	public static function local_to_utc( string $v ): string {
		$v = trim( $v );
		if ( '' === $v ) {
			return '';
		}
		try {
			$has_offset = (bool) preg_match( '/(Z|[+-]\d\d:?\d\d)$/i', $v );
			$dt         = $has_offset ? new \DateTimeImmutable( $v ) : new \DateTimeImmutable( $v, wp_timezone() );
		} catch ( \Exception $e ) {
			return '';
		}
		return $dt->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
	}

	/** Stored UTC value → value for an <input type="datetime-local"> in the site timezone. */
	public static function utc_to_local_input( string $utc ): string {
		if ( '' === $utc ) {
			return '';
		}
		$ts = strtotime( $utc . ' UTC' );
		return $ts ? wp_date( 'Y-m-d\TH:i', $ts ) : '';
	}

	/** Stored UTC value → human date/time in the site timezone with its abbreviation, e.g. "31 Oct 2026, 21:00 EET". */
	public static function format_local( string $utc ): string {
		if ( '' === $utc ) {
			return '';
		}
		$ts = strtotime( $utc . ' UTC' );
		if ( ! $ts ) {
			return '';
		}
		$abbr = wp_date( 'T', $ts );
		// Zones without a letter abbreviation (e.g. "+03") fall back to a UTC offset label.
		if ( ! preg_match( '/[A-Za-z]/', $abbr ) ) {
			$abbr = 'UTC' . wp_date( 'P', $ts );
		}
		return wp_date( get_option( 'date_format' ) . ', ' . get_option( 'time_format' ), $ts ) . ' ' . $abbr;
	}

	/** Stored UTC value → ISO-8601 UTC ("2026-11-02T08:00:00Z") for lossless API round trips. */
	public static function to_iso( string $utc ): string {
		return '' === $utc ? '' : str_replace( ' ', 'T', $utc ) . 'Z';
	}

	/** Assessment row with its availability window in ISO-8601 UTC (REST output). */
	public static function for_api( array $a ): array {
		foreach ( array( 'opens_at', 'closes_at' ) as $k ) {
			$a['settings'][ $k ] = self::to_iso( (string) ( $a['settings'][ $k ] ?? '' ) );
		}
		$a['settings']['timezone'] = self::timezone_label();
		return $a;
	}

	/** Site timezone label for form headings, e.g. "Africa/Cairo". */
	public static function timezone_label(): string {
		return wp_timezone_string();
	}

	/** @return int|\WP_Error */
	public static function save( array $data, int $id = 0 ) {
		global $wpdb;
		$existing  = $id ? self::get( $id ) : null;
		$course_id = $existing ? (int) $existing['course_id'] : absint( $data['course_id'] ?? 0 );
		if ( ! Content::is_course( $course_id ) ) {
			return new \WP_Error( 'educore_invalid', __( 'Choose a valid course.', 'educore-assessments' ), array( 'status' => 400 ) );
		}
		$kind  = in_array( $data['kind'] ?? '', self::KINDS, true ) ? $data['kind'] : ( $existing['kind'] ?? 'quiz' );
		$title = sanitize_text_field( (string) ( $data['title'] ?? ( $existing['title'] ?? '' ) ) );
		if ( '' === $title ) {
			return new \WP_Error( 'educore_invalid', __( 'A title is required.', 'educore-assessments' ), array( 'status' => 400 ) );
		}
		$lesson = absint( $data['lesson_id'] ?? ( $existing['lesson_id'] ?? 0 ) );
		if ( $lesson && Content::course_of( $lesson ) !== $course_id ) {
			return new \WP_Error( 'educore_invalid', __( 'The lesson does not belong to this course.', 'educore-assessments' ), array( 'status' => 400 ) );
		}
		$incoming = (array) ( $data['settings'] ?? array() );
		// Availability window is entered in the site timezone (or ISO-8601 with offset) and stored in UTC.
		foreach ( array( 'opens_at', 'closes_at' ) as $k ) {
			if ( array_key_exists( $k, $incoming ) ) {
				$incoming[ $k ] = self::local_to_utc( (string) $incoming[ $k ] );
			}
		}
		$settings = self::sanitize_settings( array_merge( $existing['settings'] ?? array(), $incoming ), $kind );
		$row      = array(
			'lesson_id'  => $lesson,
			'title'      => $title,
			'kind'       => $kind,
			'status'     => in_array( $data['status'] ?? '', self::STATUSES, true ) ? $data['status'] : ( $existing['status'] ?? 'draft' ),
			'settings'   => wp_json_encode( $settings ),
			'updated_at' => CoreSchema::now(),
		);
		$t = Schema::t( 'assessments' );
		if ( $existing ) {
			$wpdb->update( $t, $row, array( 'id' => $id ) );
		} else {
			$wpdb->insert( $t, array_merge( $row, array( 'course_id' => $course_id, 'created_by' => get_current_user_id(), 'created_at' => CoreSchema::now() ) ) );
			$id = (int) $wpdb->insert_id;
		}
		if ( isset( $data['pools'] ) && is_array( $data['pools'] ) ) {
			self::set_pools( $id, $data['pools'] );
		}
		Audit::log( $existing ? 'assessment.updated' : 'assessment.created', 'assessment', $id, array( 'course_id' => $course_id ) );
		return $id;
	}

	public static function set_pools( int $assessment_id, array $pools ): void {
		global $wpdb;
		$t = Schema::t( 'assessment_pools' );
		$wpdb->delete( $t, array( 'assessment_id' => $assessment_id ) );
		foreach ( array_values( $pools ) as $i => $p ) {
			$count = absint( $p['draw_count'] ?? 0 );
			$qid   = absint( $p['question_id'] ?? 0 );
			if ( ! $count && ! $qid ) {
				continue;
			}
			$wpdb->insert(
				$t,
				array(
					'assessment_id' => $assessment_id,
					'position'      => $i,
					'question_id'   => $qid,
					'qtype'         => in_array( $p['qtype'] ?? '', Types::ALL, true ) ? $p['qtype'] : '',
					'lesson_id'     => absint( $p['lesson_id'] ?? 0 ),
					'tag'           => substr( sanitize_title( (string) ( $p['tag'] ?? '' ) ), 0, 60 ),
					'difficulty'    => in_array( $p['difficulty'] ?? '', Questions::DIFFICULTY, true ) ? $p['difficulty'] : '',
					'draw_count'    => $qid ? 1 : $count,
					'points_each'   => max( 0, (float) ( $p['points_each'] ?? 0 ) ),
				)
			);
		}
	}

	public static function pools( int $assessment_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::t( 'assessment_pools' ) . ' WHERE assessment_id=%d ORDER BY position, id', $assessment_id ), ARRAY_A ) ?: array();
	}

	public static function get( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::t( 'assessments' ) . ' WHERE id=%d', $id ), ARRAY_A );
		if ( ! $row ) {
			return null;
		}
		$row['settings'] = self::sanitize_settings( (array) json_decode( (string) $row['settings'], true ), $row['kind'] );
		return $row;
	}

	/** @return array<int,array<string,mixed>> */
	public static function for_course( int $course_id, array $statuses = array( 'published' ) ): array {
		global $wpdb;
		$in   = implode( ',', array_map( static fn( $s ) => "'" . esc_sql( $s ) . "'", $statuses ) );
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::t( 'assessments' ) . " WHERE course_id=%d AND status IN ($in) ORDER BY id", $course_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		return array_map(
			static function ( $r ) {
				$r['settings'] = self::sanitize_settings( (array) json_decode( (string) $r['settings'], true ), $r['kind'] );
				return $r;
			},
			$rows
		);
	}

	public static function max_points( int $assessment_id ): float {
		$total = 0.0;
		foreach ( self::pools( $assessment_id ) as $p ) {
			$total += (float) $p['points_each'] * (int) $p['draw_count'];
		}
		return $total;
	}

	public static function is_open_window( array $a ): bool {
		$now = time();
		if ( $a['settings']['opens_at'] && strtotime( $a['settings']['opens_at'] . ' UTC' ) > $now ) {
			return false;
		}
		return ! ( $a['settings']['closes_at'] && strtotime( $a['settings']['closes_at'] . ' UTC' ) < $now );
	}

	/**
	 * Specification template: Chapter 1 Examination — 15 MCQ + 15 True/False + 5 essay, 45 minutes.
	 * Created as a draft; the total mark is configurable (points: MCQ 1, T/F 1, essay 4 = 50 raw).
	 */
	public static function chapter_one_template( int $course_id, int $lesson_id = 0 ) {
		return self::save(
			array(
				'course_id' => $course_id,
				'title'     => __( 'Chapter 1 Examination', 'educore-assessments' ),
				'kind'      => 'exam',
				'status'    => 'draft',
				'settings'  => array( 'duration' => 45, 'attempts' => 1, 'release' => 'manual', 'feedback' => 'after_attempts_exhausted' ),
				'pools'     => array(
					array( 'qtype' => 'single', 'lesson_id' => $lesson_id, 'draw_count' => 15, 'points_each' => 1 ),
					array( 'qtype' => 'truefalse', 'lesson_id' => $lesson_id, 'draw_count' => 15, 'points_each' => 1 ),
					array( 'qtype' => 'essay', 'lesson_id' => $lesson_id, 'draw_count' => 5, 'points_each' => 4 ),
				),
			)
		);
	}

	/** Lessons whose completion rule is linked to this assessment. */
	public static function linked_lessons( int $assessment_id ): array {
		return get_posts(
			array(
				'post_type'      => Content::LESSON,
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 50,
				'meta_key'       => '_ec_assessment_id', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $assessment_id, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
	}
}
