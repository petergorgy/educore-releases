<?php
/**
 * EduCore theme — presentation only. No database access, no REST routes, no business logic.
 *
 * @package EduCoreTheme
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_THEME_VERSION', '1.2.0' );

add_action(
	'after_setup_theme',
	static function () {
		load_theme_textdomain( 'educore-theme', get_template_directory() . '/languages' );
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'editor-styles' );
		add_editor_style( 'style.css' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'post-thumbnails' );
	}
);

add_action(
	'wp_enqueue_scripts',
	static function () {
		wp_enqueue_style( 'educore-theme', get_stylesheet_uri(), array(), EDUCORE_THEME_VERSION );
		wp_enqueue_script( 'educore-theme', get_template_directory_uri() . '/assets/js/theme.js', array(), EDUCORE_THEME_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script(
			'educore-theme',
			'EduCoreTheme',
			array(
				'toDark'  => __( 'Switch to dark mode', 'educore-theme' ),
				'toLight' => __( 'Switch to light mode', 'educore-theme' ),
			)
		);
	}
);

/**
 * Apply the saved/system colour scheme before first paint (avoids a flash of the wrong theme).
 */
add_action(
	'wp_head',
	static function () {
		echo "<script>(function(){var t=null;try{t=localStorage.getItem('educore-theme');}catch(e){}if(t!=='dark'&&t!=='light'){t=(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches)?'dark':'light';}document.documentElement.setAttribute('data-theme',t);})();</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- static inline script.
	},
	1
);

/** Skip link for keyboard users. */
add_action(
	'wp_body_open',
	static function () {
		echo '<a class="ect-skip-link" href="#ect-main">' . esc_html__( 'Skip to content', 'educore-theme' ) . '</a>';
	}
);

/** Theme-provided strings used inside block templates (translatable via [educore_t] shortcode). */
function educore_theme_strings(): array {
	return array(
		'courses'       => __( 'Courses', 'educore-theme' ),
		'my-learning'   => __( 'My learning', 'educore-theme' ),
		'about'         => __( 'About', 'educore-theme' ),
		'contact'       => __( 'Contact', 'educore-theme' ),
		'menu'          => __( 'Menu', 'educore-theme' ),
		'tagline'       => class_exists( '\\EduCore\\Core\\Branding' ) ? \EduCore\Core\Branding::tagline() : __( 'Learn. Understand. Grow.', 'educore-theme' ),
		'hero-lead'     => __( 'Structured courses, interactive lessons and fair assessments — in English, French and Arabic.', 'educore-theme' ),
		'browse'        => __( 'Browse courses', 'educore-theme' ),
		'start'         => __( 'Create a free account', 'educore-theme' ),
		'featured'      => __( 'Featured courses', 'educore-theme' ),
		'subjects'      => __( 'Explore by subject', 'educore-theme' ),
		'why'           => __( 'Why learn with EduCore', 'educore-theme' ),
		'b1-t'          => __( 'Clear, short lessons', 'educore-theme' ),
		'b1-d'          => __( 'Every lesson states its objectives and ends with a summary, so you always know what you learned.', 'educore-theme' ),
		'b2-t'          => __( 'Practice with feedback', 'educore-theme' ),
		'b2-d'          => __( 'Quizzes and exams give instant feedback and explanations, so mistakes become learning.', 'educore-theme' ),
		'b3-t'          => __( 'See your progress', 'educore-theme' ),
		'b3-d'          => __( 'Track completed lessons, scores and weekly goals on your personal dashboard.', 'educore-theme' ),
		'b4-t'          => __( 'Your language', 'educore-theme' ),
		'b4-d'          => __( 'Use EduCore in English, Français or العربية — switch at any time.', 'educore-theme' ),
		'instructors'   => __( 'Meet the instructors', 'educore-theme' ),
		'cta-title'     => __( 'Ready to start learning?', 'educore-theme' ),
		'cta-lead'      => __( 'Create your free account in a minute. Learners under 18 join with a parent or guardian’s consent.', 'educore-theme' ),
		'learn'         => __( 'Learn', 'educore-theme' ),
		'help'          => __( 'Help', 'educore-theme' ),
		'legal'         => __( 'Legal', 'educore-theme' ),
		'privacy'       => __( 'Privacy Policy', 'educore-theme' ),
		'terms'         => __( 'Terms of Service', 'educore-theme' ),
		'cookies'       => __( 'Cookie information', 'educore-theme' ),
		'subscriptions' => __( 'Subscription policy', 'educore-theme' ),
		'support'       => __( 'Support', 'educore-theme' ),
		'initiative'    => __( 'An initiative of', 'educore-theme' ),
		'notfound'      => __( 'Page not found', 'educore-theme' ),
		'notfound-lead' => __( 'The page you are looking for does not exist or has moved.', 'educore-theme' ),
		'home'          => __( 'Back to home', 'educore-theme' ),
		'search'        => __( 'Search results', 'educore-theme' ),
		'all-courses'   => __( 'All courses', 'educore-theme' ),
		'catalogue-lead'=> __( 'Find a course by subject, level or keyword.', 'educore-theme' ),
		'nothing'       => __( 'Nothing found.', 'educore-theme' ),
		'dark'          => __( 'Toggle dark mode', 'educore-theme' ),
		'rights'        => __( 'All rights reserved.', 'educore-theme' ),
		'in-prep'       => __( 'in preparation', 'educore-theme' ),
		'request'       => __( 'Request access', 'educore-theme' ),
		'closed-title'  => __( 'Joining EduCore', 'educore-theme' ),
		'closed-lead'   => __( 'Accounts are currently created by your school or by our support team. Contact us to request access.', 'educore-theme' ),
	);
}

/**
 * [educore_t key="..."] prints a translated theme string; [educore_link to="courses|dashboard|..."]
 * prints a URL for an EduCore page (falls back to /<key>/ when core is inactive).
 */
add_shortcode(
	'educore_t',
	static function ( $atts ) {
		$key = sanitize_key( $atts['key'] ?? '' );
		$s   = educore_theme_strings();
		return esc_html( $s[ $key ] ?? '' );
	}
);

/** Self-registration open? (follows EduCore → Settings; open when core is inactive). */
function educore_theme_registration_open(): bool {
	if ( class_exists( '\EduCore\Core\Pages' ) && method_exists( '\EduCore\Core\Pages', 'registration_open' ) ) {
		return \EduCore\Core\Pages::registration_open();
	}
	return 'closed' !== get_option( 'educore_registration', 'open' );
}

/** Legal pages are linked only once the owner has published them (drafts must never look approved). */
function educore_theme_page_published( string $key ): bool {
	if ( class_exists( '\EduCore\Core\Pages' ) && method_exists( '\EduCore\Core\Pages', 'is_published' ) ) {
		return \EduCore\Core\Pages::is_published( $key );
	}
	return true;
}

function educore_theme_url( string $key ): string {
	if ( class_exists( '\EduCore\Core\Pages' ) ) {
		return \EduCore\Core\Pages::url( $key );
	}
	return 'courses' === $key ? home_url( '/courses/' ) : home_url( '/' . $key . '/' );
}

add_shortcode(
	'educore_link',
	static function ( $atts ) {
		return esc_url( educore_theme_url( sanitize_key( $atts['to'] ?? '' ) ) );
	}
);

add_shortcode(
	'educore_support_email',
	static function () {
		$email = sanitize_email( (string) get_option( 'educore_support_email', 'support@educore.gorgy.org' ) );
		return '<a href="mailto:' . esc_attr( antispambot( $email ) ) . '">' . esc_html( antispambot( $email ) ) . '</a>';
	}
);

add_shortcode( 'educore_year', static fn() => esc_html( wp_date( 'Y' ) ) );

/** Official logo from the central EduCore branding configuration. [educore_brand_logo variant=light|dark|auto] */
add_shortcode(
	'educore_brand_logo',
	static function ( $atts ) {
		$a = shortcode_atts( array( 'variant' => 'auto', 'class' => '' ), $atts );
		if ( ! class_exists( '\\EduCore\\Core\\Branding' ) ) {
			return '<p class="' . esc_attr( $a['class'] ) . '" style="font-size:1.4rem;font-weight:800">EduCore</p>';
		}
		return '<p class="' . esc_attr( $a['class'] ) . '"><a href="' . esc_url( home_url( '/' ) ) . '">' . \EduCore\Core\Branding::logo_html( in_array( $a['variant'], array( 'light', 'dark', 'auto' ), true ) ? $a['variant'] : 'auto', 'ect-logo', 40 ) . '</a></p>';
	}
);

/**
 * Header markup (rendered via shortcode inside the header template part so links resolve to the
 * real EduCore pages and labels are translatable). Menu uses <details> → works without JavaScript.
 */
add_shortcode(
	'educore_header',
	static function ( $atts ) {
		$s       = educore_theme_strings();
		$minimal = ! empty( $atts['minimal'] );
		$links   = array(
			'courses'   => $s['courses'],
			'dashboard' => $s['my-learning'],
			'about'     => $s['about'],
			'contact'   => $s['contact'],
		);
		$out  = '<div class="ect-header__inner alignwide">';
		$out .= class_exists( '\\EduCore\\Core\\Branding' )
			? '<a class="ect-brand" href="' . esc_url( home_url( '/' ) ) . '" rel="home">' . \EduCore\Core\Branding::logo_html( 'auto', 'ect-logo', 36 ) . '</a>'
			: '<a class="ect-brand" href="' . esc_url( home_url( '/' ) ) . '" rel="home"><span class="ect-brand__mark" aria-hidden="true">E</span><span>EduCore</span></a>';
		if ( ! $minimal ) {
			$items = '';
			foreach ( $links as $key => $label ) {
				$items .= '<li><a href="' . esc_url( educore_theme_url( $key ) ) . '">' . esc_html( $label ) . '</a></li>';
			}
			$account = is_user_logged_in()
				? '<li><a href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">' . esc_html__( 'Log out', 'educore-theme' ) . '</a></li>'
				: '<li><a href="' . esc_url( wp_login_url() ) . '">' . esc_html__( 'Log in', 'educore-theme' ) . '</a></li>' . ( educore_theme_registration_open() ? '<li><a href="' . esc_url( educore_theme_url( 'register' ) ) . '">' . esc_html__( 'Sign up', 'educore-theme' ) . '</a></li>' : '' );
			$out .= '<nav class="ect-nav" aria-label="' . esc_attr__( 'Main', 'educore-theme' ) . '">';
			$out .= '<ul class="ect-menu__list ect-nav-desktop">' . $items . '</ul>';
			$out .= '<details class="ect-menu ect-nav-mobile"><summary>' . esc_html( $s['menu'] ) . '</summary><ul class="ect-menu__list">' . $items . $account . '</ul></details>';
			$out .= '</nav>';
		}
		$out .= '<div class="ect-header__tools">';
		if ( function_exists( 'do_blocks' ) ) {
			$out .= do_blocks( '<!-- wp:educore/language-switcher /-->' );
			if ( ! $minimal ) {
				$out .= do_blocks( '<!-- wp:educore/user-menu /-->' );
			}
		}
		$out .= '<button type="button" class="ect-theme-toggle" data-ect-theme-toggle aria-label="' . esc_attr( $s['dark'] ) . '" aria-pressed="false"><span class="ect-icon-light" aria-hidden="true">☾</span><span class="ect-icon-dark" aria-hidden="true">☀</span></button>';
		return $out . '</div></div>';
	}
);

/** Graceful degradation: the theme renders without EduCore Core, but tells administrators. */
add_action(
	'admin_notices',
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) && current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'The EduCore theme works best with the EduCore Core plugin. Activate it to enable courses, lessons and dashboards.', 'educore-theme' ) . '</p></div>';
		}
	}
);

/** Register theme patterns category. Patterns themselves live in /patterns (auto-registered). */
add_action(
	'init',
	static function () {
		register_block_pattern_category( 'educore-theme', array( 'label' => __( 'EduCore theme', 'educore-theme' ) ) );
	}
);

/** [educore_a courses all-courses arrow] (positional, quote-free so texturize cannot mangle it) → full translated anchor to an EduCore page. */
add_shortcode(
	'educore_a',
	static function ( $atts ) {
		$atts = (array) $atts;
		$atts = array(
			'to'     => $atts['to'] ?? ( $atts[0] ?? '' ),
			'key'    => $atts['key'] ?? ( $atts[1] ?? '' ),
			'suffix' => ( isset( $atts[2] ) && 'arrow' === $atts[2] ) ? ' →' : ( $atts['suffix'] ?? '' ),
		);
		$s    = educore_theme_strings();
		$to   = sanitize_key( $atts['to'] );
		if ( in_array( $to, array( 'privacy', 'terms', 'cookies', 'subscriptions' ), true ) && ! educore_theme_page_published( $to ) ) {
			return '<span class="ect-link-pending">' . esc_html( ( $s[ sanitize_key( $atts['key'] ) ] ?? '' ) . ' — ' . $s['in-prep'] ) . '</span>';
		}
		if ( 'register' === $to && ! educore_theme_registration_open() ) {
			return '<a href="' . esc_url( educore_theme_url( 'contact' ) ) . '">' . esc_html( $s['request'] ) . '</a>';
		}
		$url  = 'home' === $to ? home_url( '/' ) : educore_theme_url( $to );
		return '<a href="' . esc_url( $url ) . '">' . esc_html( ( $s[ sanitize_key( $atts['key'] ) ] ?? '' ) . $atts['suffix'] ) . '</a>';
	}
);
