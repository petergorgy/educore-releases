<?php
/**
 * Title: EduCore hero
 * Slug: educore-theme/hero
 * Categories: educore-theme, banner
 * Description: Home page hero with tagline and calls to action.
 */
?>
<!-- wp:group {"align":"full","className":"ect-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"gradient":"hero","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull ect-hero has-hero-gradient-background has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:paragraph {"className":"ect-eyebrow"} --><p class="ect-eyebrow"><?php esc_html_e( 'EduCore learning platform', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"ect-tagline ect-fade-in"} --><h1 class="wp-block-heading ect-tagline ect-fade-in"><?php esc_html_e( 'Learn. Practice. Understand. Grow.', 'educore-theme' ); ?></h1><!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"large"} --><p class="has-large-font-size"><?php esc_html_e( 'Structured courses, interactive lessons and fair assessments — in English, French and Arabic.', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( educore_theme_url( 'courses' ) ); ?>"><?php esc_html_e( 'Browse courses', 'educore-theme' ); ?></a></div><!-- /wp:button -->
<?php if ( educore_theme_registration_open() ) : ?>
<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( educore_theme_url( 'register' ) ); ?>"><?php esc_html_e( 'Create a free account', 'educore-theme' ); ?></a></div><!-- /wp:button -->
<?php else : ?>
<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( educore_theme_url( 'contact' ) ); ?>"><?php esc_html_e( 'Request access', 'educore-theme' ); ?></a></div><!-- /wp:button -->
<?php endif; ?>
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
