=== EduCore Commerce ===
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Requires Plugins: educore-core, woocommerce
Stable tag: 1.0.1
License: GPL-2.0-or-later

Paid courses and time-limited access plans for EduCore, sold through WooCommerce.

== How it works ==
* Set a course's Enrollment option to "Paid".
* Create a WooCommerce product (virtual) and, in its "EduCore access" tab, choose the course(s) it unlocks and the access length in days (0 = lifetime; 30 = monthly plan; 365 = annual plan).
* When an order becomes Processing or Completed and is paid, the customer receives an entitlement and an EduCore enrollment (source "commerce") that expires with the entitlement.
* Refunded, Cancelled or Failed orders revoke the order's entitlements; the enrollment is suspended unless another active entitlement covers the course.
* An hourly job expires past-due entitlements (enrollment → expired) and fires `educore/events/entitlement_expiring` once, 7 days before the end.
* Access to paid course content is checked server-side on every request (`educore/access/can_access_course`). Enrollments created manually by staff (source admin/import) act as a manual grant, e.g. for scholarships.
* Guest orders grant nothing (an order note explains why). Require accounts at checkout in WooCommerce settings.

== Discounts and trials ==
* Discounts and promotional codes: use WooCommerce coupons.
* Trials: create a zero-price product with "Trial length (days)". Each learner can use one trial per course. The trial is offered as a secondary "Start a free N-day trial" button next to the paid "Buy access" button (1.0.1); it is never shown as the course price.

== Renewals and subscriptions ==
* Without a subscription plugin, renewal = buying the access product again (the latest end date wins).
* WooCommerce Subscriptions (separately licensed): a bridge is included (src/Subscriptions.php). STATUS: NOT TESTED — the plugin was not available in the development environment.

== Payments and privacy ==
* Compatible with WooCommerce High-Performance Order Storage (HPOS) and the Cart/Checkout blocks (declared since 1.0.1; rehearsed on staging with HPOS on).
* Personal-data export includes the learner's course access periods (1.0.1). Erasure keeps access records with their orders as accounting evidence; WooCommerce's retention settings govern orders.
* EduCore never receives, stores or logs card data. Payment gateways and their credentials are configured only in WooCommerce. No credentials are hard-coded.
* Gateway choice (e.g. Paymob, Fawry) is pending decision D-04.

== Without WooCommerce ==
If WooCommerce is inactive, administrators see a notice, paid courses show "Not available", and all free courses and existing access keep working.

== Changelog ==
= 1.0.1 =
* Visitors see the price and a "Log in to buy access" button on paid courses (needs EduCore Core 1.2.1).
* Zero-price trial products are no longer picked as the course price; the trial is a separate button and disappears once used.
* Declared HPOS and Cart/Checkout blocks compatibility.
* Course access periods added to the WordPress personal-data export.
= 1.0.0 =
* First release.
