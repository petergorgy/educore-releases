<?php
namespace EduCore\Workspace;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Workspace-owned tables (1.7.0): learner interventions and course feedback. Learner data → privacy hooks below. */
final class Data {
	public const DB_VERSION = 1;

	public static function tables(): array {
		return array(
			'ws_interventions'      => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				course_id BIGINT UNSIGNED NOT NULL,
				learner_id BIGINT UNSIGNED NOT NULL,
				owner_id BIGINT UNSIGNED NOT NULL,
				reason VARCHAR(40) NOT NULL,
				summary VARCHAR(255) NOT NULL,
				plan TEXT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'open',
				due_on DATE NULL,
				outcome TEXT NULL,
				created_by BIGINT UNSIGNED NOT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				closed_at DATETIME NULL,
				PRIMARY KEY  (id),
				KEY course_status (course_id,status),
				KEY owner_status (owner_id,status),
				KEY learner_id (learner_id)",
			'ws_intervention_notes' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				intervention_id BIGINT UNSIGNED NOT NULL,
				author_id BIGINT UNSIGNED NOT NULL,
				kind VARCHAR(20) NOT NULL DEFAULT 'note',
				body TEXT NOT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY intervention_id (intervention_id)",
			'ws_feedback'           => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				course_id BIGINT UNSIGNED NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				rating TINYINT UNSIGNED NOT NULL,
				comment TEXT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'visible',
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY course_user (course_id,user_id),
				KEY course_status (course_id,status)",
		);
	}

	public static function migrate(): void {
		Schema::migrate( 'educore_ws_db_version', self::DB_VERSION, self::tables() );
	}

	public static function register(): void {
		self::migrate();
		add_action( 'educore/install/repair', array( self::class, 'migrate' ) );
		add_filter( 'wp_privacy_personal_data_exporters', array( self::class, 'exporters' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( self::class, 'erasers' ) );
	}

	public static function exporters( array $e ): array {
		$e['educore-workspace'] = array( 'exporter_friendly_name' => __( 'EduCore support plans and course feedback', 'educore-workspace' ), 'callback' => array( self::class, 'export' ) );
		return $e;
	}

	public static function erasers( array $e ): array {
		$e['educore-workspace'] = array( 'eraser_friendly_name' => __( 'EduCore support plans and course feedback', 'educore-workspace' ), 'callback' => array( self::class, 'erase' ) );
		return $e;
	}

	public static function export( string $email, int $page = 1 ): array {
		global $wpdb;
		$u     = get_user_by( 'email', $email );
		$items = array();
		if ( $u ) {
			foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'ws_interventions' ) . ' WHERE learner_id=%d', $u->ID ), ARRAY_A ) ?: array() as $r ) {
				$items[] = array( 'group_id' => 'educore-support', 'group_label' => __( 'Support plans', 'educore-workspace' ), 'item_id' => 'intervention-' . $r['id'], 'data' => array( array( 'name' => __( 'Course', 'educore-workspace' ), 'value' => get_the_title( (int) $r['course_id'] ) ), array( 'name' => __( 'Summary', 'educore-workspace' ), 'value' => $r['summary'] ), array( 'name' => __( 'Plan', 'educore-workspace' ), 'value' => (string) $r['plan'] ), array( 'name' => __( 'Status', 'educore-workspace' ), 'value' => $r['status'] ), array( 'name' => __( 'Outcome', 'educore-workspace' ), 'value' => (string) $r['outcome'] ) ) );
			}
			foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'ws_feedback' ) . ' WHERE user_id=%d', $u->ID ), ARRAY_A ) ?: array() as $r ) {
				$items[] = array( 'group_id' => 'educore-feedback', 'group_label' => __( 'Course feedback', 'educore-workspace' ), 'item_id' => 'feedback-' . $r['id'], 'data' => array( array( 'name' => __( 'Course', 'educore-workspace' ), 'value' => get_the_title( (int) $r['course_id'] ) ), array( 'name' => __( 'Rating', 'educore-workspace' ), 'value' => (string) $r['rating'] ), array( 'name' => __( 'Comment', 'educore-workspace' ), 'value' => (string) $r['comment'] ) ) );
			}
		}
		return array( 'data' => $items, 'done' => true );
	}

	public static function erase( string $email, int $page = 1 ): array {
		global $wpdb;
		$u = get_user_by( 'email', $email );
		$n = 0;
		if ( $u ) {
			$ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . Schema::table( 'ws_interventions' ) . ' WHERE learner_id=%d', $u->ID ) ) ?: array() );
			if ( $ids ) {
				$wpdb->query( 'DELETE FROM ' . Schema::table( 'ws_intervention_notes' ) . ' WHERE intervention_id IN (' . implode( ',', $ids ) . ')' ); // phpcs:ignore WordPress.DB.PreparedSQL -- integer list.
			}
			$n += (int) $wpdb->delete( Schema::table( 'ws_interventions' ), array( 'learner_id' => $u->ID ) );
			$n += (int) $wpdb->delete( Schema::table( 'ws_feedback' ), array( 'user_id' => $u->ID ) );
		}
		return array( 'items_removed' => $n > 0, 'items_retained' => false, 'messages' => array(), 'done' => true );
	}
}
