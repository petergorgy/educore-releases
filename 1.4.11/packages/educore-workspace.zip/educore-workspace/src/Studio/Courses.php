<?php
namespace EduCore\Workspace\Studio;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Curriculum;
use EduCore\Core\I18n;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/**
 * Course Studio service. Authority = WordPress meta capabilities as scoped by EduCore core
 * (edit_post / publish_post / delete_post are limited to the course's teaching team; publishing needs
 * publish_ec_courses). Nothing here widens them.
 */
final class Courses {
	public const EDITABLE = array( 'draft', 'pending', 'publish', 'future', 'private' );

	public static function can_author( int $uid ): bool {
		return $uid > 0 && user_can( $uid, 'edit_ec_courses' );
	}

	public static function can_publish( int $uid ): bool {
		return $uid > 0 && user_can( $uid, 'publish_ec_courses' );
	}

	public static function can_edit( int $uid, int $post_id ): bool {
		return $post_id > 0 && Content::is_content_type( (string) get_post_type( $post_id ) ) && user_can( $uid, 'edit_post', $post_id );
	}

	private static function deny( string $msg = '' ): \WP_Error {
		return new \WP_Error( 'ec_studio_forbidden', $msg ?: __( 'You cannot change this course.', 'educore-workspace' ), array( 'status' => 403 ) );
	}

	/** @return \WP_Post[] courses the user may edit (all for managers, team courses otherwise) */
	public static function mine( int $uid, string $status = '' ): array {
		$st   = $status && in_array( $status, self::EDITABLE, true ) ? array( $status ) : self::EDITABLE;
		$args = array( 'post_type' => Content::COURSE, 'post_status' => $st, 'numberposts' => 300, 'orderby' => 'modified', 'order' => 'DESC' );
		if ( ! user_can( $uid, 'ec_manage_all_courses' ) ) {
			$ids             = array_map( 'intval', Staff::courses_of( $uid ) );
			$own             = get_posts( array( 'post_type' => Content::COURSE, 'post_status' => $st, 'author' => $uid, 'fields' => 'ids', 'numberposts' => 300 ) );
			$args['post__in'] = array_values( array_unique( array_merge( $ids, $own ) ) ) ?: array( 0 );
		}
		return array_values( array_filter( get_posts( $args ), static fn( $p ) => user_can( $uid, 'edit_post', $p->ID ) ) );
	}

	/** Courses waiting for a publisher's decision. */
	public static function review_queue( int $uid ): array {
		if ( ! self::can_publish( $uid ) ) {
			return array();
		}
		return get_posts( array( 'post_type' => Content::COURSE, 'post_status' => 'pending', 'numberposts' => 200, 'orderby' => 'modified', 'order' => 'ASC' ) );
	}

	/** @return int|\WP_Error */
	public static function create( int $uid, array $in ) {
		if ( ! self::can_author( $uid ) ) {
			return self::deny( __( 'You cannot create courses.', 'educore-workspace' ) );
		}
		$title = sanitize_text_field( (string) ( $in['title'] ?? '' ) );
		if ( '' === $title ) {
			return new \WP_Error( 'ec_studio_title', __( 'Give the course a title.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'title' => 'required' ) ) );
		}
		$id = wp_insert_post( array( 'post_type' => Content::COURSE, 'post_status' => 'draft', 'post_title' => $title, 'post_excerpt' => sanitize_textarea_field( (string) ( $in['excerpt'] ?? '' ) ), 'post_author' => $uid, 'meta_input' => array( '_ec_lang' => I18n::sanitize_lang( $in['lang'] ?? I18n::current() ) ) ), true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		if ( ! user_can( $uid, 'ec_manage_all_courses' ) && ! Staff::role_of( $uid, $id ) ) {
			Staff::assign( $id, $uid, 'lead' );
		}
		Audit::log( 'studio.course_created', 'course', $id );
		return (int) $id;
	}

	/** Save one wizard step. Only whitelisted fields; content passes wp_kses_post unless the user has unfiltered_html. */
	public static function save( int $uid, int $course_id, array $in ) {
		if ( ! Content::is_course( $course_id ) || ! self::can_edit( $uid, $course_id ) ) {
			return self::deny();
		}
		$post = array( 'ID' => $course_id );
		if ( isset( $in['title'] ) ) {
			$t = sanitize_text_field( (string) $in['title'] );
			if ( '' === $t ) {
				return new \WP_Error( 'ec_studio_title', __( 'Give the course a title.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'title' => 'required' ) ) );
			}
			$post['post_title'] = $t;
		}
		if ( isset( $in['excerpt'] ) ) {
			$post['post_excerpt'] = sanitize_textarea_field( (string) $in['excerpt'] );
		}
		if ( isset( $in['content'] ) ) {
			$post['post_content'] = user_can( $uid, 'unfiltered_html' ) ? (string) $in['content'] : wp_kses_post( (string) $in['content'] );
		}
		if ( count( $post ) > 1 ) {
			$r = wp_update_post( wp_slash( $post ), true );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		$meta = array(
			'difficulty'     => '_ec_difficulty',
			'grade_level'    => '_ec_grade_level',
			'duration_hours' => '_ec_duration_hours',
			'objectives'     => '_ec_objectives',
			'prerequisites'  => '_ec_prerequisites',
			'assessment_req' => '_ec_assessment_req',
			'enroll_mode'    => '_ec_enroll_mode',
			'lang'           => '_ec_lang',
		);
		$schema = Content::meta_schema( Content::COURSE );
		foreach ( $meta as $k => $key ) {
			if ( array_key_exists( $k, $in ) ) {
				if ( 'enroll_mode' === $k && 'paid' === $in[ $k ] && ! defined( 'EDUCORE_COMMERCE_VERSION' ) ) {
					continue; // Commerce is inactive: paid enrollment cannot be chosen here.
				}
				update_post_meta( $course_id, $key, call_user_func( $schema[ $key ][2], $in[ $k ] ) );
			}
		}
		if ( array_key_exists( 'cover_id', $in ) ) {
			$cover = (int) $in['cover_id'];
			if ( $cover && wp_attachment_is_image( $cover ) && user_can( $uid, 'edit_post', $cover ) ) {
				set_post_thumbnail( $course_id, $cover );
			} elseif ( 0 === $cover ) {
				delete_post_thumbnail( $course_id );
			}
		}
		if ( array_key_exists( 'programme_id', $in ) ) {
			$prog = (int) $in['programme_id'];
			Curriculum::unmap_course( $course_id );
			if ( $prog ) {
				Curriculum::map_course( $course_id, $prog, (int) ( $in['period_id'] ?? 0 ), (int) ( $in['subject_id'] ?? 0 ) );
			}
		}
		Audit::log( 'studio.course_saved', 'course', $course_id, array( 'fields' => array_keys( $in ) ) );
		return true;
	}

	/* ---------- Structure ---------- */

	/** @return int|\WP_Error */
	public static function add_unit( int $uid, int $course_id, string $title ) {
		if ( ! Content::is_course( $course_id ) || ! self::can_edit( $uid, $course_id ) ) {
			return self::deny();
		}
		$title = sanitize_text_field( $title );
		if ( '' === $title ) {
			return new \WP_Error( 'ec_studio_title', __( 'Give the unit a title.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		$order = count( Content::units( $course_id, self::EDITABLE ) );
		$id    = wp_insert_post( array( 'post_type' => Content::UNIT, 'post_status' => 'draft', 'post_title' => $title, 'post_author' => $uid, 'menu_order' => $order, 'meta_input' => array( '_ec_course_id' => $course_id ) ), true );
		Audit::log( 'studio.unit_created', 'course', $course_id, array( 'unit' => is_wp_error( $id ) ? 0 : $id ) );
		return $id;
	}

	/** @return int|\WP_Error */
	public static function add_lesson( int $uid, int $unit_id, string $title ) {
		if ( Content::UNIT !== get_post_type( $unit_id ) || ! self::can_edit( $uid, $unit_id ) ) {
			return self::deny();
		}
		$title = sanitize_text_field( $title );
		if ( '' === $title ) {
			return new \WP_Error( 'ec_studio_title', __( 'Give the lesson a title.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		$course = Content::course_of( $unit_id );
		$order  = count( Content::lessons_of_unit( $unit_id, self::EDITABLE ) );
		$id     = wp_insert_post( array( 'post_type' => Content::LESSON, 'post_status' => 'draft', 'post_title' => $title, 'post_author' => $uid, 'menu_order' => $order, 'meta_input' => array( '_ec_unit_id' => $unit_id, '_ec_course_id' => $course ) ), true );
		Audit::log( 'studio.lesson_created', 'course', $course, array( 'lesson' => is_wp_error( $id ) ? 0 : $id ) );
		return $id;
	}

	public static function rename( int $uid, int $id, string $title ) {
		if ( ! in_array( get_post_type( $id ), array( Content::UNIT, Content::LESSON ), true ) || ! self::can_edit( $uid, $id ) ) {
			return self::deny();
		}
		$title = sanitize_text_field( $title );
		return '' === $title ? new \WP_Error( 'ec_studio_title', __( 'A title is required.', 'educore-workspace' ), array( 'status' => 400 ) ) : ( is_wp_error( $r = wp_update_post( array( 'ID' => $id, 'post_title' => $title ), true ) ) ? $r : true );
	}

	/** Move to trash (recoverable), never a permanent delete. Units are trashed with their lessons. */
	public static function trash( int $uid, int $id ) {
		if ( ! in_array( get_post_type( $id ), array( Content::UNIT, Content::LESSON ), true ) || ! self::can_edit( $uid, $id ) || ! user_can( $uid, 'delete_post', $id ) ) {
			return self::deny();
		}
		$course = Content::course_of( $id );
		if ( Content::UNIT === get_post_type( $id ) ) {
			foreach ( Content::lessons_of_unit( $id, self::EDITABLE ) as $l ) {
				wp_trash_post( $l->ID );
			}
		}
		wp_trash_post( $id );
		Audit::log( 'studio.trashed', (string) get_post_type( $id ), $id, array( 'course' => $course ) );
		return true;
	}

	/**
	 * Apply a full outline order: [ ['unit'=>id, 'lessons'=>[ids…]], … ]. Every id must belong to the course;
	 * lessons may move between units of the same course.
	 */
	public static function reorder( int $uid, int $course_id, array $outline ) {
		if ( ! Content::is_course( $course_id ) || ! self::can_edit( $uid, $course_id ) ) {
			return self::deny();
		}
		foreach ( array_values( $outline ) as $ui => $row ) {
			$unit = (int) ( $row['unit'] ?? 0 );
			if ( Content::UNIT !== get_post_type( $unit ) || Content::course_of( $unit ) !== $course_id ) {
				return new \WP_Error( 'ec_studio_outline', __( 'The outline contains items from another course.', 'educore-workspace' ), array( 'status' => 400 ) );
			}
			wp_update_post( array( 'ID' => $unit, 'menu_order' => $ui ) );
			foreach ( array_values( (array) ( $row['lessons'] ?? array() ) ) as $li => $lid ) {
				$lid = (int) $lid;
				if ( Content::LESSON !== get_post_type( $lid ) || Content::course_of( $lid ) !== $course_id ) {
					return new \WP_Error( 'ec_studio_outline', __( 'The outline contains items from another course.', 'educore-workspace' ), array( 'status' => 400 ) );
				}
				update_post_meta( $lid, '_ec_unit_id', $unit );
				wp_update_post( array( 'ID' => $lid, 'menu_order' => $li ) );
			}
		}
		Content::flush_cache();
		Audit::log( 'studio.reordered', 'course', $course_id );
		return true;
	}

	/* ---------- Lessons ---------- */

	public static function save_lesson( int $uid, int $lesson_id, array $in ) {
		if ( Content::LESSON !== get_post_type( $lesson_id ) || ! self::can_edit( $uid, $lesson_id ) ) {
			return self::deny();
		}
		$post = array( 'ID' => $lesson_id );
		if ( isset( $in['title'] ) ) {
			$t = sanitize_text_field( (string) $in['title'] );
			if ( '' === $t ) {
				return new \WP_Error( 'ec_studio_title', __( 'Give the lesson a title.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'title' => 'required' ) ) );
			}
			$post['post_title'] = $t;
		}
		if ( isset( $in['content'] ) ) {
			$post['post_content'] = user_can( $uid, 'unfiltered_html' ) ? (string) $in['content'] : wp_kses_post( (string) $in['content'] );
		}
		if ( count( $post ) > 1 ) {
			$r = wp_update_post( wp_slash( $post ), true );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		$schema = Content::meta_schema( Content::LESSON );
		foreach ( array( 'minutes' => '_ec_minutes', 'objectives' => '_ec_objectives', 'summary' => '_ec_summary', 'completion_rule' => '_ec_completion_rule', 'completion_secs' => '_ec_completion_secs', 'lang' => '_ec_lang' ) as $k => $key ) {
			if ( array_key_exists( $k, $in ) ) {
				update_post_meta( $lesson_id, $key, call_user_func( $schema[ $key ][2], $in[ $k ] ) );
			}
		}
		if ( isset( $in['unit_id'] ) ) {
			$unit = (int) $in['unit_id'];
			if ( Content::UNIT === get_post_type( $unit ) && Content::course_of( $unit ) === Content::course_of( $lesson_id ) ) {
				update_post_meta( $lesson_id, '_ec_unit_id', $unit );
			}
		}
		delete_post_meta( $lesson_id, '_ec_studio_autosave' );
		Content::flush_cache();
		Audit::log( 'studio.lesson_saved', 'lesson', $lesson_id );
		return true;
	}

	/** Autosave keeps the editor's work without changing the saved lesson (restored on request). */
	public static function autosave( int $uid, int $lesson_id, array $in ) {
		if ( Content::LESSON !== get_post_type( $lesson_id ) || ! self::can_edit( $uid, $lesson_id ) ) {
			return self::deny();
		}
		$content = user_can( $uid, 'unfiltered_html' ) ? (string) ( $in['content'] ?? '' ) : wp_kses_post( (string) ( $in['content'] ?? '' ) );
		update_post_meta( $lesson_id, '_ec_studio_autosave', wp_slash( wp_json_encode( array( 'title' => sanitize_text_field( (string) ( $in['title'] ?? '' ) ), 'content' => $content, 'user' => $uid, 'at' => time() ) ) ) );
		return true;
	}

	public static function autosave_of( int $lesson_id ): ?array {
		$a = json_decode( (string) get_post_meta( $lesson_id, '_ec_studio_autosave', true ), true );
		return is_array( $a ) ? $a : null;
	}

	/** @return array<int,array{id:int,date:string,author:string}> */
	public static function revisions( int $post_id, int $limit = 15 ): array {
		$out = array();
		foreach ( array_slice( wp_get_post_revisions( $post_id, array( 'order' => 'DESC' ) ), 0, $limit ) as $r ) {
			if ( wp_is_post_autosave( $r ) ) {
				continue;
			}
			$a     = get_userdata( (int) $r->post_author );
			$out[] = array( 'id' => (int) $r->ID, 'date' => $r->post_modified_gmt, 'author' => $a ? $a->display_name : '' );
		}
		return $out;
	}

	public static function restore_revision( int $uid, int $revision_id ) {
		$rev = wp_get_post_revision( $revision_id );
		if ( ! $rev || ! self::can_edit( $uid, (int) $rev->post_parent ) ) {
			return self::deny();
		}
		$r = wp_restore_post_revision( $revision_id );
		Audit::log( 'studio.revision_restored', (string) get_post_type( $rev->post_parent ), (int) $rev->post_parent, array( 'revision' => $revision_id ) );
		return $r ? true : new \WP_Error( 'ec_studio_restore', __( 'The version could not be restored.', 'educore-workspace' ) );
	}

	/* ---------- Review and publication ---------- */

	/** @return array<int,string> problems that block submission/publication */
	public static function checklist( int $course_id ): array {
		$p   = array();
		$c   = get_post( $course_id );
		$out = Content::outline( $course_id, array( 'draft', 'pending', 'publish', 'future' ) );
		if ( '' === trim( (string) $c->post_excerpt ) ) {
			$p[] = __( 'Add a short description.', 'educore-workspace' );
		}
		if ( '' === trim( (string) get_post_meta( $course_id, '_ec_objectives', true ) ) ) {
			$p[] = __( 'Add the learning objectives.', 'educore-workspace' );
		}
		if ( ! $out ) {
			$p[] = __( 'Add at least one unit.', 'educore-workspace' );
		}
		foreach ( $out as $row ) {
			if ( ! $row['lessons'] ) {
				/* translators: %s: unit title */
				$p[] = sprintf( __( 'Unit “%s” has no lessons.', 'educore-workspace' ), get_the_title( $row['unit'] ) );
			}
			foreach ( $row['lessons'] as $l ) {
				if ( '' === trim( wp_strip_all_tags( (string) $l->post_content ) ) && ! has_blocks( $l->post_content ) && false === strpos( (string) $l->post_content, '<img' ) && false === strpos( (string) $l->post_content, '<iframe' ) ) {
					/* translators: %s: lesson title */
					$p[] = sprintf( __( 'Lesson “%s” is empty.', 'educore-workspace' ), get_the_title( $l ) );
				}
			}
		}
		return $p;
	}

	/** Content items that move with the course on submit/approve. */
	private static function content_items( int $course_id ): array {
		$ids = array( $course_id );
		foreach ( Content::outline( $course_id, array( 'draft', 'pending', 'future', 'publish' ) ) as $row ) {
			$ids[] = $row['unit']->ID;
			foreach ( $row['lessons'] as $l ) {
				$ids[] = $l->ID;
			}
		}
		return $ids;
	}

	public static function submit( int $uid, int $course_id ) {
		if ( ! Content::is_course( $course_id ) || ! self::can_edit( $uid, $course_id ) ) {
			return self::deny();
		}
		$problems = self::checklist( $course_id );
		if ( $problems ) {
			return new \WP_Error( 'ec_studio_incomplete', implode( ' ', $problems ), array( 'status' => 400 ) );
		}
		foreach ( self::content_items( $course_id ) as $id ) {
			if ( 'draft' === get_post_status( $id ) ) {
				wp_update_post( array( 'ID' => $id, 'post_status' => 'pending' ) );
			}
		}
		if ( 'publish' === get_post_status( $course_id ) ) {
			update_post_meta( $course_id, '_ec_review_requested', time() ); // Changes to a live course: new items wait for review.
		}
		delete_post_meta( $course_id, '_ec_review_note' );
		Audit::log( 'studio.submitted', 'course', $course_id );
		/** Notify publishers (EduCore Notifications or custom handlers). */
		do_action( 'educore/studio/submitted', $course_id, $uid );
		return true;
	}

	/**
	 * Publish now, or schedule (UTC 'Y-m-d H:i:s' in the site's timezone input converted by caller).
	 * Units and lessons waiting for review are published (or scheduled) with the course.
	 */
	public static function publish( int $uid, int $course_id, string $when_gmt = '' ) {
		if ( ! Content::is_course( $course_id ) || ! self::can_publish( $uid ) || ! user_can( $uid, 'publish_post', $course_id ) ) {
			return self::deny( __( 'You cannot publish this course.', 'educore-workspace' ) );
		}
		$problems = self::checklist( $course_id );
		if ( $problems ) {
			return new \WP_Error( 'ec_studio_incomplete', implode( ' ', $problems ), array( 'status' => 400 ) );
		}
		$future = $when_gmt && strtotime( $when_gmt . ' UTC' ) > time() + 60;
		foreach ( self::content_items( $course_id ) as $id ) {
			$st = get_post_status( $id );
			if ( ! in_array( $st, array( 'draft', 'pending', 'future' ), true ) && $id !== $course_id ) {
				continue;
			}
			if ( 'publish' === $st && $id === $course_id && ! $future ) {
				continue;
			}
			$data = array( 'ID' => $id, 'post_status' => $future ? 'future' : 'publish' );
			if ( $future ) {
				$data['post_date_gmt'] = $when_gmt;
				$data['post_date']     = get_date_from_gmt( $when_gmt );
				$data['edit_date']     = true;
			}
			wp_update_post( $data );
		}
		delete_post_meta( $course_id, '_ec_review_requested' );
		delete_post_meta( $course_id, '_ec_review_note' );
		Audit::log( $future ? 'studio.scheduled' : 'studio.published', 'course', $course_id, $future ? array( 'at' => $when_gmt ) : array() );
		do_action( 'educore/studio/published', $course_id, $uid, $future ? $when_gmt : '' );
		return true;
	}

	/** Send back to the authors with a note. Content returns to draft; nothing is deleted. */
	public static function reject( int $uid, int $course_id, string $note ) {
		if ( ! Content::is_course( $course_id ) || ! self::can_publish( $uid ) ) {
			return self::deny( __( 'You cannot review this course.', 'educore-workspace' ) );
		}
		$note = sanitize_textarea_field( $note );
		if ( '' === $note ) {
			return new \WP_Error( 'ec_studio_note', __( 'Explain what needs to change.', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'note' => 'required' ) ) );
		}
		foreach ( self::content_items( $course_id ) as $id ) {
			if ( 'pending' === get_post_status( $id ) ) {
				wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
			}
		}
		update_post_meta( $course_id, '_ec_review_note', wp_slash( wp_json_encode( array( 'note' => $note, 'by' => $uid, 'at' => time() ) ) ) );
		delete_post_meta( $course_id, '_ec_review_requested' );
		Audit::log( 'studio.changes_requested', 'course', $course_id );
		do_action( 'educore/studio/changes_requested', $course_id, $uid, $note );
		return true;
	}

	public static function duplicate( int $uid, int $course_id ) {
		if ( ! Content::is_course( $course_id ) || ! self::can_edit( $uid, $course_id ) || ! self::can_author( $uid ) ) {
			return self::deny();
		}
		$id = Content::duplicate_course( $course_id, $uid );
		return $id ?: new \WP_Error( 'ec_studio_copy', __( 'The course could not be copied.', 'educore-workspace' ) );
	}
}
