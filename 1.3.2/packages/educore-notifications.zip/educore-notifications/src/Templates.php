<?php
namespace EduCore\Notifications;

defined( 'ABSPATH' ) || exit;

/**
 * Message templates in English, French and Arabic. Placeholders: {name} {course} {title}
 * {url} {date} {site}. Each body is a list of paragraphs; an optional call-to-action uses {url}.
 */
final class Templates {

	/** Events that are always sent (cannot be disabled by the learner). */
	public const ESSENTIAL = array( 'guardian_consent', 'password_changed', 'test' );

	/** @return array<string,array<string,array{subject:string,body:string[],cta?:string}>> */
	public static function all(): array {
		/** Other EduCore packages add templates (same {placeholders}, EN/FR/AR). */
		return (array) apply_filters( 'educore/notifications/templates', self::base() );
	}

	/** @return array<string,array<string,array{subject:string,body:string[],cta?:string}>> */
	private static function base(): array {
		return array(
			'enrolled'           => array(
				'en' => array( 'subject' => 'You are enrolled in {course}', 'body' => array( 'Hello {name},', 'You are now enrolled in “{course}”. Your first lesson is ready whenever you are.' ), 'cta' => 'Start learning' ),
				'fr' => array( 'subject' => 'Vous êtes inscrit(e) au cours {course}', 'body' => array( 'Bonjour {name},', 'Vous êtes désormais inscrit(e) au cours « {course} ». Votre première leçon vous attend dès que vous êtes prêt(e).' ), 'cta' => 'Commencer' ),
				'ar' => array( 'subject' => 'تم تسجيلك في {course}', 'body' => array( 'مرحبًا {name}،', 'تم تسجيلك في مقرر «{course}». درسك الأول جاهز متى شئت.' ), 'cta' => 'ابدأ التعلّم' ),
			),
			'announcement'       => array(
				'en' => array( 'subject' => '[{course}] {title}', 'body' => array( 'Hello {name},', 'Your instructor posted a new announcement in “{course}”:', '{message}' ), 'cta' => 'Open the course' ),
				'fr' => array( 'subject' => '[{course}] {title}', 'body' => array( 'Bonjour {name},', 'Votre enseignant(e) a publié une annonce dans « {course} » :', '{message}' ), 'cta' => 'Ouvrir le cours' ),
				'ar' => array( 'subject' => '[{course}] {title}', 'body' => array( 'مرحبًا {name}،', 'نشر مدرّسك إعلانًا جديدًا في «{course}»:', '{message}' ), 'cta' => 'افتح المقرر' ),
			),
			'attempt_received'   => array(
				'en' => array( 'subject' => 'We received your submission: {title}', 'body' => array( 'Hello {name},', 'Your answers for “{title}” were submitted on {date}. You will be notified when your result is released.' ) ),
				'fr' => array( 'subject' => 'Votre copie a bien été reçue : {title}', 'body' => array( 'Bonjour {name},', 'Vos réponses pour « {title} » ont été envoyées le {date}. Vous serez averti(e) dès la publication de votre résultat.' ) ),
				'ar' => array( 'subject' => 'استلمنا إجاباتك: {title}', 'body' => array( 'مرحبًا {name}،', 'تم تسليم إجاباتك في «{title}» بتاريخ {date}. سنخبرك فور إعلان نتيجتك.' ) ),
			),
			'grading_needed'     => array(
				'en' => array( 'subject' => 'Submission waiting for grading: {title}', 'body' => array( 'Hello {name},', 'A new submission for “{title}” in “{course}” needs your review.' ), 'cta' => 'Open grading queue' ),
				'fr' => array( 'subject' => 'Copie à corriger : {title}', 'body' => array( 'Bonjour {name},', 'Une nouvelle copie pour « {title} » dans « {course} » attend votre correction.' ), 'cta' => 'Ouvrir la file de correction' ),
				'ar' => array( 'subject' => 'إجابة بانتظار التصحيح: {title}', 'body' => array( 'مرحبًا {name}،', 'هناك إجابة جديدة في «{title}» ضمن «{course}» تحتاج إلى تصحيحك.' ), 'cta' => 'افتح قائمة التصحيح' ),
			),
			'grade_released'     => array(
				'en' => array( 'subject' => 'Your result is available: {title}', 'body' => array( 'Hello {name},', 'Your result for “{title}” is now available, together with your instructor’s feedback.' ), 'cta' => 'View my result' ),
				'fr' => array( 'subject' => 'Votre résultat est disponible : {title}', 'body' => array( 'Bonjour {name},', 'Votre résultat pour « {title} » est disponible, avec les commentaires de votre enseignant(e).' ), 'cta' => 'Voir mon résultat' ),
				'ar' => array( 'subject' => 'نتيجتك متاحة الآن: {title}', 'body' => array( 'مرحبًا {name}،', 'نتيجتك في «{title}» متاحة الآن مع ملاحظات مدرّسك.' ), 'cta' => 'عرض نتيجتي' ),
			),
			'course_completed'   => array(
				'en' => array( 'subject' => 'Congratulations — you completed {course}!', 'body' => array( 'Hello {name},', 'You have completed every lesson of “{course}”. Well done on your hard work!' ), 'cta' => 'See my progress' ),
				'fr' => array( 'subject' => 'Félicitations, vous avez terminé {course} !', 'body' => array( 'Bonjour {name},', 'Vous avez terminé toutes les leçons du cours « {course} ». Bravo pour votre travail !' ), 'cta' => 'Voir ma progression' ),
				'ar' => array( 'subject' => 'تهانينا — أتممت {course}!', 'body' => array( 'مرحبًا {name}،', 'لقد أتممت جميع دروس «{course}». أحسنت على جهدك!' ), 'cta' => 'عرض تقدّمي' ),
			),
			'certificate_issued' => array(
				'en' => array( 'subject' => 'Your certificate for {course}', 'body' => array( 'Hello {name},', 'Your certificate of completion for “{course}” has been issued. Anyone can verify it with the link below.' ), 'cta' => 'View certificate' ),
				'fr' => array( 'subject' => 'Votre attestation pour {course}', 'body' => array( 'Bonjour {name},', 'Votre attestation de réussite pour « {course} » a été délivrée. Elle peut être vérifiée par tous grâce au lien ci-dessous.' ), 'cta' => 'Voir l’attestation' ),
				'ar' => array( 'subject' => 'شهادتك في {course}', 'body' => array( 'مرحبًا {name}،', 'صدرت شهادة إتمامك لمقرر «{course}». يمكن لأي شخص التحقق منها عبر الرابط أدناه.' ), 'cta' => 'عرض الشهادة' ),
			),
			'guardian_consent'   => array(
				'en' => array( 'subject' => 'Consent request: {name} wants to join EduCore', 'body' => array( 'Hello,', '{name} registered on EduCore and listed you as parent or guardian. Because the learner is under 18, we need your consent before they can start learning.', 'The link is valid for 7 days. If you do not recognise this request, you can ignore this e-mail.' ), 'cta' => 'Review and confirm' ),
				'fr' => array( 'subject' => 'Demande de consentement : {name} souhaite rejoindre EduCore', 'body' => array( 'Bonjour,', '{name} s’est inscrit(e) sur EduCore et vous a désigné(e) comme parent ou tuteur légal. L’apprenant(e) ayant moins de 18 ans, nous avons besoin de votre accord avant qu’il ou elle puisse commencer.', 'Ce lien est valable 7 jours. Si vous ne reconnaissez pas cette demande, ignorez simplement ce message.' ), 'cta' => 'Examiner et confirmer' ),
				'ar' => array( 'subject' => 'طلب موافقة: {name} يرغب في الانضمام إلى EduCore', 'body' => array( 'مرحبًا،', 'سجّل {name} في منصة EduCore وذكرك وليًّا للأمر. ولأن المتعلّم دون الثامنة عشرة، نحتاج إلى موافقتك قبل أن يبدأ التعلّم.', 'الرابط صالح لمدة 7 أيام. إذا لم تكن تعرف هذا الطلب فتجاهل هذه الرسالة.' ), 'cta' => 'المراجعة والتأكيد' ),
			),
			'enrollment_expired' => array(
				'en' => array( 'subject' => 'Your access to {course} has ended', 'body' => array( 'Hello {name},', 'Your access period for “{course}” has ended. Your progress is saved — contact support or renew your access to continue.' ), 'cta' => 'Open EduCore' ),
				'fr' => array( 'subject' => 'Votre accès à {course} est terminé', 'body' => array( 'Bonjour {name},', 'Votre période d’accès au cours « {course} » est terminée. Votre progression est conservée : contactez le support ou renouvelez votre accès pour continuer.' ), 'cta' => 'Ouvrir EduCore' ),
				'ar' => array( 'subject' => 'انتهى وصولك إلى {course}', 'body' => array( 'مرحبًا {name}،', 'انتهت فترة وصولك إلى «{course}». تقدّمك محفوظ — تواصل مع الدعم أو جدّد اشتراكك للمتابعة.' ), 'cta' => 'افتح EduCore' ),
			),
			'entitlement_expiring' => array(
				'en' => array( 'subject' => 'Your access to {course} ends on {date}', 'body' => array( 'Hello {name},', 'Your subscription access to “{course}” ends on {date}. Renew before then to keep learning without interruption.' ), 'cta' => 'Renew access' ),
				'fr' => array( 'subject' => 'Votre accès à {course} se termine le {date}', 'body' => array( 'Bonjour {name},', 'Votre abonnement au cours « {course} » se termine le {date}. Renouvelez-le avant cette date pour continuer sans interruption.' ), 'cta' => 'Renouveler' ),
				'ar' => array( 'subject' => 'ينتهي وصولك إلى {course} بتاريخ {date}', 'body' => array( 'مرحبًا {name}،', 'ينتهي اشتراكك في «{course}» بتاريخ {date}. جدّده قبل ذلك لتواصل التعلّم دون انقطاع.' ), 'cta' => 'تجديد الاشتراك' ),
			),
			'password_changed'   => array(
				'en' => array( 'subject' => 'Your EduCore password was changed', 'body' => array( 'Hello {name},', 'The password of your EduCore account was changed on {date}. If this was not you, reset your password immediately and contact support.' ) ),
				'fr' => array( 'subject' => 'Votre mot de passe EduCore a été modifié', 'body' => array( 'Bonjour {name},', 'Le mot de passe de votre compte EduCore a été modifié le {date}. Si vous n’êtes pas à l’origine de ce changement, réinitialisez-le immédiatement et contactez le support.' ) ),
				'ar' => array( 'subject' => 'تم تغيير كلمة مرور حسابك في EduCore', 'body' => array( 'مرحبًا {name}،', 'تم تغيير كلمة مرور حسابك في EduCore بتاريخ {date}. إن لم تكن أنت من قام بذلك، أعد تعيين كلمة المرور فورًا وتواصل مع الدعم.' ) ),
			),
			'reminder'           => array(
				'en' => array( 'subject' => 'Reminder: {title} is due {date}', 'body' => array( 'Hello {name},', 'A friendly reminder that “{title}” is due on {date}.' ), 'cta' => 'Open' ),
				'fr' => array( 'subject' => 'Rappel : {title} — échéance le {date}', 'body' => array( 'Bonjour {name},', 'Petit rappel : « {title} » est à rendre le {date}.' ), 'cta' => 'Ouvrir' ),
				'ar' => array( 'subject' => 'تذكير: موعد «{title}» في {date}', 'body' => array( 'مرحبًا {name}،', 'تذكير ودّي بأن موعد «{title}» هو {date}.' ), 'cta' => 'فتح' ),
			),
			'test'               => array(
				'en' => array( 'subject' => 'EduCore test e-mail', 'body' => array( 'This is a test message from EduCore. If you can read it, the mail server accepted it and delivered it to your inbox.' ) ),
				'fr' => array( 'subject' => 'E-mail de test EduCore', 'body' => array( 'Ceci est un message de test d’EduCore. Si vous le lisez, le serveur de messagerie l’a accepté et distribué.' ) ),
				'ar' => array( 'subject' => 'رسالة اختبار من EduCore', 'body' => array( 'هذه رسالة اختبار من EduCore. إذا وصلتك فقد قبلها خادم البريد وسلّمها إلى صندوقك.' ) ),
			),
		);
	}

	/** @return string[] */
	public static function events(): array {
		return array_keys( self::all() );
	}

	/** Learner-facing labels for preference checkboxes (non-essential events only). */
	public static function labels(): array {
		return array(
			'enrolled'             => __( 'Enrollment confirmations', 'educore-notifications' ),
			'announcement'         => __( 'Course announcements', 'educore-notifications' ),
			'attempt_received'     => __( 'Submission receipts', 'educore-notifications' ),
			'grade_released'       => __( 'Results and feedback', 'educore-notifications' ),
			'course_completed'     => __( 'Course completion', 'educore-notifications' ),
			'certificate_issued'   => __( 'Certificates', 'educore-notifications' ),
			'reminder'             => __( 'Deadline and exam reminders', 'educore-notifications' ),
			'enrollment_expired'   => __( 'Access ended notices', 'educore-notifications' ),
			'entitlement_expiring' => __( 'Subscription expiry notices', 'educore-notifications' ),
			'grading_needed'       => __( 'Grading requests (staff)', 'educore-notifications' ),
		);
	}

	/**
	 * Render a message. Variables are inserted as escaped text; only {url} becomes a link.
	 *
	 * @return array{subject:string,html:string,text:string}
	 */
	public static function render( string $event, string $lang, array $vars ): array {
		$all  = self::all();
		$lang = isset( $all[ $event ][ $lang ] ) ? $lang : 'en';
		$tpl  = $all[ $event ][ $lang ] ?? array( 'subject' => (string) ( $vars['title'] ?? 'EduCore' ), 'body' => array( (string) ( $vars['message'] ?? '' ) ) );
		$vars = array_merge( array( 'site' => 'EduCore', 'name' => '', 'course' => '', 'title' => '', 'date' => '', 'message' => '', 'url' => '' ), array_map( 'strval', $vars ) );
		$fill = static function ( string $s ) use ( $vars ): string {
			foreach ( $vars as $k => $v ) {
				$s = str_replace( '{' . $k . '}', $v, $s );
			}
			return $s;
		};
		$subject = wp_strip_all_tags( $fill( $tpl['subject'] ) );
		$paras   = array_map( $fill, $tpl['body'] );
		$support = sanitize_email( (string) get_option( 'educore_support_email', 'support@educore.gorgy.org' ) );
		$prefs   = class_exists( '\EduCore\Core\Pages' ) ? \EduCore\Core\Pages::url( 'profile' ) : '';
		$footer  = array(
			'en' => array( 'Questions? Write to %s.', 'Manage your e-mail preferences: %s' ),
			'fr' => array( 'Une question ? Écrivez à %s.', 'Gérer vos préférences e-mail : %s' ),
			'ar' => array( 'لديك سؤال؟ راسلنا على %s.', 'إدارة تفضيلات البريد: %s' ),
		)[ $lang ];
		$dir  = 'ar' === $lang ? 'rtl' : 'ltr';
		$html = '<!doctype html><html lang="' . esc_attr( $lang ) . '" dir="' . $dir . '"><body style="margin:0;background:#F6F3E9;font-family:Arial,Tahoma,sans-serif;color:#102A43">';
		$html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px">';
		$html .= '<table role="presentation" width="600" style="max-width:600px;background:#ffffff;border-radius:12px;border-top:6px solid #126B80" cellpadding="0" cellspacing="0"><tr><td dir="' . $dir . '" style="padding:28px;text-align:' . ( 'rtl' === $dir ? 'right' : 'left' ) . ';font-size:16px;line-height:1.6">';
		$brand = class_exists( '\\EduCore\\Core\\Branding' ) ? \EduCore\Core\Branding::name() : 'EduCore';
		$logo  = class_exists( '\\EduCore\\Core\\Branding' ) ? \EduCore\Core\Branding::asset( 'educore-logo-email.png' ) : '';
		$html .= $logo
			? '<p style="margin:0 0 20px"><img src="' . esc_url( $logo ) . '" width="180" height="53" alt="' . esc_attr( $brand ) . '" style="display:block;border:0;width:180px;height:auto"></p>'
			: '<p style="font-weight:bold;font-size:20px;color:#102A43;margin:0 0 16px">' . esc_html( $brand ) . '</p>';
		foreach ( $paras as $p ) {
			$html .= '<p style="margin:0 0 14px">' . nl2br( esc_html( $p ) ) . '</p>';
		}
		if ( ! empty( $tpl['cta'] ) && '' !== $vars['url'] ) {
			$html .= '<p style="margin:22px 0"><a href="' . esc_url( $vars['url'] ) . '" style="background:#126B80;color:#ffffff;padding:12px 22px;border-radius:999px;text-decoration:none;font-weight:bold;display:inline-block">' . esc_html( $tpl['cta'] ) . '</a></p>';
		}
		$html .= '<hr style="border:0;border-top:1px solid #dcd6c8;margin:24px 0"><p style="font-size:13px;color:#4f5b6e;margin:0">' . esc_html( sprintf( $footer[0], $support ) );
		if ( ! in_array( $event, self::ESSENTIAL, true ) && $prefs ) {
			$html .= '<br>' . esc_html( sprintf( $footer[1], $prefs ) );
		}
		$html .= '</p></td></tr></table></td></tr></table></body></html>';

		$text = implode( "\n\n", $paras );
		if ( ! empty( $tpl['cta'] ) && '' !== $vars['url'] ) {
			$text .= "\n\n" . $tpl['cta'] . ': ' . $vars['url'];
		}
		$text .= "\n\n-- \n" . sprintf( $footer[0], $support );
		if ( ! in_array( $event, self::ESSENTIAL, true ) && $prefs ) {
			$text .= "\n" . sprintf( $footer[1], $prefs );
		}
		return array( 'subject' => $subject, 'html' => $html, 'text' => $text );
	}
}
