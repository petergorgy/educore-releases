<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Teaching Performance Center. Workload (what a teacher does) is reported separately from delivery
 * indicators (what happened in their classes). Raw student scores are shown as distributions with
 * cohort size, never as a single "teacher effectiveness" score.
 */
final class Analytics {

	/** @return array{from:string,to:string,from_utc:string,to_utc:string} */
	public static function range( string $from = '', string $to = '' ): array {
		$to   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ? $to : wp_date( 'Y-m-d' );
		$from = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ? $from : wp_date( 'Y-m-d', strtotime( $to ) - 29 * DAY_IN_SECONDS );
		return array( 'from' => $from, 'to' => $to, 'from_utc' => (string) Plugin::local_to_utc( $from . ' 00:00' ), 'to_utc' => (string) Plugin::local_to_utc( $to . ' 23:59' ) );
	}

	/**
	 * Metrics for a set of classes (a teacher's classes, or a filtered subset).
	 *
	 * @param int[] $class_ids
	 */
	public static function teaching( int $user_id, array $class_ids, array $r ): array {
		global $wpdb;
		$class_ids = array_values( array_filter( array_map( 'intval', $class_ids ) ) );
		$in        = $class_ids ? implode( ',', $class_ids ) : '0';
		$a         = Schema::table( 'th_assignments' );
		$s         = Schema::table( 'th_submissions' );
		$lp        = Schema::table( 'th_lesson_plans' );
		$counts    = Classes::member_counts( $class_ids );

		$plans = $wpdb->get_row( $wpdb->prepare( "SELECT SUM(status<>'cancelled') planned, SUM(status='delivered') delivered FROM {$lp} WHERE is_template=0 AND (class_id IN ({$in}) OR (class_id=0 AND owner_id=%d)) AND teach_date BETWEEN %s AND %s", $user_id, $r['from'], $r['to'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL

		// Expected vs submitted for class assignments due in range (targets = class members).
		$due = $wpdb->get_results( $wpdb->prepare( "SELECT a.id, a.class_id FROM {$a} a WHERE a.class_id IN ({$in}) AND a.status IN ('published','closed') AND a.due_at BETWEEN %s AND %s", $r['from_utc'], $r['to_utc'] ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		$expected = 0;
		foreach ( $due as $d ) {
			$expected += $counts[ (int) $d['class_id'] ] ?? 0;
		}
		$submitted = $due ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$s} WHERE status IN ('submitted','graded','returned') AND assignment_id IN (" . implode( ',', array_map( 'intval', wp_list_pluck( $due, 'id' ) ) ) . ')' ) : 0; // phpcs:ignore WordPress.DB.PreparedSQL

		$turn = $wpdb->get_col( $wpdb->prepare( "SELECT TIMESTAMPDIFF(MINUTE, s.submitted_at, s.graded_at) FROM {$s} s JOIN {$a} a ON a.id=s.assignment_id WHERE a.class_id IN ({$in}) AND s.graded_at BETWEEN %s AND %s AND s.submitted_at IS NOT NULL", $r['from_utc'], $r['to_utc'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		sort( $turn );
		$median_h = $turn ? round( $turn[ intdiv( count( $turn ), 2 ) ] / 60, 1 ) : null;

		$dist = array( '0-49' => 0, '50-69' => 0, '70-84' => 0, '85-100' => 0 );
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT s.score, a.max_score FROM {$s} s JOIN {$a} a ON a.id=s.assignment_id WHERE a.class_id IN ({$in}) AND s.status='graded' AND s.released=1 AND s.graded_at BETWEEN %s AND %s", $r['from_utc'], $r['to_utc'] ), ARRAY_A ) ?: array() as $row ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$p = 100 * (float) $row['score'] / max( 0.01, (float) $row['max_score'] );
			$dist[ $p < 50 ? '0-49' : ( $p < 70 ? '50-69' : ( $p < 85 ? '70-84' : '85-100' ) ) ]++;
		}

		return array(
			'workload' => array(
				'classes'          => count( $class_ids ),
				'active_students'  => array_sum( $counts ),
				'lessons_planned'  => (int) ( $plans['planned'] ?? 0 ),
				'lessons_delivered'=> (int) ( $plans['delivered'] ?? 0 ),
				'assignments_due'  => count( $due ),
				'pending_grading'  => count( Assignments::grading_queue( $user_id, 1000 ) ),
			),
			'delivery' => array(
				'assignment_completion_pct' => $expected ? round( 100 * min( $submitted, $expected ) / $expected, 1 ) : null,
				'grading_turnaround_h'      => $median_h,
				'attendance_rate_pct'       => Attendance::rate( $class_ids, $r['from'] ),
				'score_distribution'        => $dist,
				'graded_in_range'           => array_sum( $dist ),
			),
		);
	}

	public static function tutoring( int $tutor_id, array $r ): array {
		global $wpdb;
		$t   = Schema::table( 'th_sessions' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) total, SUM(status='completed') completed, SUM(status='cancelled') cancelled, SUM(status='no_show') no_show, SUM(status='declined') declined, SUM(CASE WHEN status='completed' THEN TIMESTAMPDIFF(MINUTE,starts_at,ends_at) ELSE 0 END) minutes, COUNT(DISTINCT NULLIF(student_id,0)) learners, SUM(status='completed' AND homework<>'' AND homework IS NOT NULL) homework_set, SUM(status='completed' AND follow_up<>'' AND follow_up IS NOT NULL) follow_up_done, SUM(status IN ('confirmed','completed','no_show')) booked, SUM(CASE WHEN status IN ('confirmed','completed','no_show') THEN TIMESTAMPDIFF(MINUTE,starts_at,ends_at) ELSE 0 END) booked_minutes FROM {$t} WHERE tutor_id=%d AND starts_at BETWEEN %s AND %s", $tutor_id, $r['from_utc'], $r['to_utc'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$total = (int) $row['total'];
		// Available minutes in range from weekly windows (minus unavailable days).
		$avail = 0;
		$wins  = Tutoring::availability( $tutor_id );
		$off   = array_flip( Tutoring::unavailable( $tutor_id ) );
		for ( $d = strtotime( $r['from'] ); $d <= strtotime( $r['to'] ); $d += DAY_IN_SECONDS ) {
			if ( isset( $off[ gmdate( 'Y-m-d', $d ) ] ) ) {
				continue;
			}
			foreach ( $wins as $w ) {
				if ( (int) gmdate( 'w', $d ) === $w[0] ) {
					$avail += ( strtotime( '1970-01-01 ' . $w[2] . ' UTC' ) - strtotime( '1970-01-01 ' . $w[1] . ' UTC' ) ) / 60;
				}
			}
		}
		$completed = (int) $row['completed'];
		return array(
			'sessions_scheduled'  => $total,
			'sessions_completed'  => $completed,
			'cancellation_pct'    => $total ? round( 100 * (int) $row['cancelled'] / $total, 1 ) : null,
			'no_show_pct'         => (int) $row['booked'] ? round( 100 * (int) $row['no_show'] / (int) $row['booked'], 1 ) : null,
			'teaching_hours'      => round( (int) $row['minutes'] / 60, 1 ),
			'active_learners'     => (int) $row['learners'],
			'homework_set_pct'    => $completed ? round( 100 * (int) $row['homework_set'] / $completed, 1 ) : null,
			'follow_up_pct'       => $completed ? round( 100 * (int) $row['follow_up_done'] / $completed, 1 ) : null,
			'utilisation_pct'     => $avail ? round( 100 * (int) $row['booked_minutes'] / $avail, 1 ) : null,
		);
	}

	/** Rows for export: one row per teacher in scope (managers) or the viewer only. */
	public static function export_rows( int $viewer, array $r ): array {
		global $wpdb;
		$users = Caps::is_manager( $viewer ) ? array_map( 'intval', $wpdb->get_col( 'SELECT DISTINCT user_id FROM ' . Schema::table( 'th_class_staff' ) . ' UNION SELECT user_id FROM ' . Schema::table( 'th_tutor_profiles' ) ) ) : array( $viewer ); // phpcs:ignore WordPress.DB.PreparedSQL
		$rows  = array(
			array(
				__( 'Staff member', 'educore-teaching-hub' ), __( 'Classes', 'educore-teaching-hub' ), __( 'Active students', 'educore-teaching-hub' ),
				__( 'Lessons planned', 'educore-teaching-hub' ), __( 'Lessons delivered', 'educore-teaching-hub' ), __( 'Assignments due', 'educore-teaching-hub' ),
				__( 'Pending grading', 'educore-teaching-hub' ), __( 'Assignment completion %', 'educore-teaching-hub' ), __( 'Median grading turnaround (h)', 'educore-teaching-hub' ),
				__( 'Attendance rate %', 'educore-teaching-hub' ), __( 'Graded (released)', 'educore-teaching-hub' ),
				__( 'Tutoring sessions', 'educore-teaching-hub' ), __( 'Completed', 'educore-teaching-hub' ), __( 'Cancellation %', 'educore-teaching-hub' ),
				__( 'No-show %', 'educore-teaching-hub' ), __( 'Tutoring hours', 'educore-teaching-hub' ), __( 'Utilisation %', 'educore-teaching-hub' ),
				__( 'From', 'educore-teaching-hub' ), __( 'To', 'educore-teaching-hub' ),
			),
		);
		foreach ( $users as $uid ) {
			$u = get_userdata( $uid );
			if ( ! $u ) {
				continue;
			}
			$m  = self::teaching( $uid, self::own_classes( $uid ), $r );
			$tm = user_can( $uid, 'ec_tutor_sessions' ) ? self::tutoring( $uid, $r ) : array();
			$rows[] = array(
				$u->display_name, $m['workload']['classes'], $m['workload']['active_students'], $m['workload']['lessons_planned'], $m['workload']['lessons_delivered'],
				$m['workload']['assignments_due'], $m['workload']['pending_grading'], $m['delivery']['assignment_completion_pct'] ?? '', $m['delivery']['grading_turnaround_h'] ?? '',
				$m['delivery']['attendance_rate_pct'] ?? '', $m['delivery']['graded_in_range'],
				$tm['sessions_scheduled'] ?? '', $tm['sessions_completed'] ?? '', $tm['cancellation_pct'] ?? '', $tm['no_show_pct'] ?? '', $tm['teaching_hours'] ?? '', $tm['utilisation_pct'] ?? '',
				$r['from'], $r['to'],
			);
		}
		return $rows;
	}

	/** Classes a user is staff of (not "all", even for managers). @return int[] */
	public static function own_classes( int $user_id ): array {
		global $wpdb;
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT class_id FROM ' . Schema::table( 'th_class_staff' ) . ' WHERE user_id=%d', $user_id ) ) );
	}

	/** Spreadsheet-safe cell (neutralises formula injection). */
	public static function cell( $v ): string {
		$v = (string) $v;
		return preg_match( '/^[=+\-@\t\r]/', $v ) ? "'" . $v : $v;
	}

	/** @param array<int,array<int,mixed>> $rows */
	public static function csv( array $rows ): string {
		$fh = fopen( 'php://temp', 'r+' );
		fwrite( $fh, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		foreach ( $rows as $row ) {
			fputcsv( $fh, array_map( array( self::class, 'cell' ), $row ), ',', '"', '\\' );
		}
		rewind( $fh );
		$out = (string) stream_get_contents( $fh );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $out;
	}

	/** @param array<int,array<int,mixed>> $rows */
	public static function send( array $rows, string $format, string $name ): void {
		\EduCore\Core\Access::no_cache_headers();
		if ( 'xlsx' === $format && class_exists( '\EduCore\Analytics\Xlsx' ) ) {
			$rows = array_map( static fn( $r ) => array_map( array( self::class, 'cell' ), $r ), $rows );
			header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
			header( 'Content-Disposition: attachment; filename="' . $name . '.xlsx"' );
			echo \EduCore\Analytics\Xlsx::build( $rows, 'Report' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- binary file.
			exit;
		}
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '.csv"' );
		echo self::csv( $rows ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSV body, cells neutralised.
		exit;
	}
}
