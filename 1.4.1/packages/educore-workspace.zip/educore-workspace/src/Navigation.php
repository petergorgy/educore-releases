<?php
namespace EduCore\Workspace;

use EduCore\Core\Auth\Router;
use EduCore\Core\Pages as CorePages;

defined( 'ABSPATH' ) || exit;

/**
 * Sidebar, quick actions, notifications and workspace destinations. Menus are a convenience only:
 * every view and endpoint enforces its own capability and object checks server-side.
 */
final class Navigation {

	public static function register(): void {
		add_filter( 'educore/auth/destinations', array( self::class, 'destinations' ), 20, 2 );
		add_filter( 'login_redirect', array( self::class, 'login_redirect' ), 100, 3 );
	}

	public static function can_manage( int $uid = 0 ): bool {
		$uid = $uid ?: get_current_user_id();
		return $uid && ( user_can( $uid, Plugin::CAP_PEOPLE ) || user_can( $uid, 'ec_manage_settings' ) || user_can( $uid, 'manage_options' ) );
	}

	public static function is_tutor_only( int $uid ): bool {
		return user_can( $uid, 'ec_tutor_sessions' ) && ! user_can( $uid, 'ec_teach' ) && ! user_can( $uid, 'ec_manage_all_courses' );
	}

	/** Adds EduCore Management and the Tutor workspace to the core Router (landing + switcher). */
	public static function destinations( array $d, \WP_User $user ): array {
		if ( self::can_manage( (int) $user->ID ) ) {
			$d['manage'] = array( 'label' => __( 'EduCore Management', 'educore-workspace' ), 'url' => Pages::url( 'manage' ), 'priority' => 5 );
		}
		if ( user_can( $user, 'edit_ec_courses' ) ) {
			$d['studio'] = array( 'label' => __( 'Course Studio', 'educore-workspace' ), 'url' => Pages::url( 'studio' ), 'priority' => user_can( $user, 'ec_teach' ) || self::can_manage( (int) $user->ID ) ? 40 : 28 );
		}
		if ( self::is_tutor_only( (int) $user->ID ) ) {
			$d['tutor'] = array( 'label' => __( 'Tutor workspace', 'educore-workspace' ), 'url' => Pages::url( 'tutor' ), 'priority' => 25 );
		}
		if ( isset( $d['wp-admin'] ) ) {
			$d['wp-admin']['label']    = __( 'Technical administration (WordPress)', 'educore-workspace' );
			$d['wp-admin']['priority'] = 90; // Still listed in the switcher; never the default landing.
		}
		return $d;
	}

	/**
	 * Administrators land in EduCore Management after a plain sign-in. A specific destination they asked for
	 * (a wp-admin deep link, a re-authentication) is preserved: the core Router has already validated it.
	 */
	public static function login_redirect( $redirect_to, $requested, $user ) {
		if ( ! $user instanceof \WP_User || ! $user->exists() || ! user_can( $user, 'manage_options' ) || ! self::can_manage( (int) $user->ID ) ) {
			return $redirect_to;
		}
		$req = untrailingslashit( strtok( (string) $requested, '?' ) );
		if ( '' === $req || untrailingslashit( admin_url() ) === $req ) {
			return Pages::url( 'manage' );
		}
		return $redirect_to;
	}

	/** @return array<string,array{label:string,url:string,priority:int}> */
	public static function workspaces( int $uid ): array {
		$u = get_userdata( $uid );
		return $u ? Router::destinations( $u ) : array();
	}

	/**
	 * Sidebar items for a workspace that does not supply its own (the Teaching Hub supplies its own).
	 *
	 * @return array<int,array{key:string,label:string,url:string,icon:string,badge?:int}>
	 */
	public static function items( string $ws, int $uid ): array {
		$items = array();
		switch ( $ws ) {
			case 'manage':
				$m     = static fn( $v, $label, $icon, $cap = true ) => $cap ? array( 'key' => $v, 'label' => $label, 'url' => Pages::url( 'manage', 'overview' === $v ? array() : array( 'v' => $v ) ), 'icon' => $icon ) : null;
				$items = array_filter(
					array(
						$m( 'overview', __( 'Overview', 'educore-workspace' ), 'home' ),
						$m( 'people', __( 'People', 'educore-workspace' ), 'users', user_can( $uid, Plugin::CAP_PEOPLE ) ),
						$m( 'courses', __( 'Courses', 'educore-workspace' ), 'book', user_can( $uid, 'ec_manage_all_courses' ) || user_can( $uid, Plugin::CAP_PEOPLE ) ),
						$m( 'audit', __( 'Audit log', 'educore-workspace' ), 'list', user_can( $uid, 'ec_view_audit_log' ) || user_can( $uid, 'manage_options' ) ),
						$m( 'system', __( 'System status', 'educore-workspace' ), 'gauge', user_can( $uid, 'ec_manage_settings' ) || user_can( $uid, 'manage_options' ) ),
					)
				);
				break;
			case 'studio':
				$st    = static fn( $v, $label, $icon, $args = array() ) => array( 'key' => $v, 'label' => $label, 'url' => Pages::url( 'studio', $args ), 'icon' => $icon );
				$items = array( $st( 'courses', __( 'My courses', 'educore-workspace' ), 'book' ), $st( 'new', __( 'New course', 'educore-workspace' ), 'grid', array( 'v' => 'new' ) ) );
				if ( user_can( $uid, 'publish_ec_courses' ) ) {
					$n       = count( Studio\Courses::review_queue( $uid ) );
					$items[] = $st( 'review', __( 'Review queue', 'educore-workspace' ), 'list', array( 'v' => 'review' ) ) + array( 'badge' => $n );
				}
				if ( user_can( $uid, 'ec_manage_programmes' ) ) {
					$items[] = $st( 'academic', __( 'Academic structure', 'educore-workspace' ), 'gauge', array( 'v' => 'academic' ) );
				}
				break;
			case 'student':
				$items = array(
					array( 'key' => 'dashboard', 'label' => __( 'My learning', 'educore-workspace' ), 'url' => CorePages::url( 'dashboard' ), 'icon' => 'home' ),
					array( 'key' => 'catalog', 'label' => __( 'Course catalogue', 'educore-workspace' ), 'url' => CorePages::url( 'courses' ), 'icon' => 'book' ),
					array( 'key' => 'history', 'label' => __( 'Learning history', 'educore-workspace' ), 'url' => CorePages::url( 'history' ), 'icon' => 'clock' ),
				);
				if ( class_exists( '\EduCore\TeachingHub\Pages' ) ) {
					$items[] = array( 'key' => 'tutors', 'label' => __( 'Find a tutor', 'educore-workspace' ), 'url' => \EduCore\TeachingHub\Pages::url( 'tutors' ), 'icon' => 'chat' );
				}
				break;
			case 'guardian':
				$items = array( array( 'key' => 'guardian', 'label' => __( 'My learners', 'educore-workspace' ), 'url' => CorePages::url( 'guardian' ), 'icon' => 'users' ) );
				break;
			case 'instructor':
				$items = array( array( 'key' => 'workspace', 'label' => __( 'My courses', 'educore-workspace' ), 'url' => CorePages::url( 'workspace' ), 'icon' => 'book' ) );
				break;
		}
		$items[] = array( 'key' => 'profile', 'label' => __( 'My profile', 'educore-workspace' ), 'url' => CorePages::url( 'profile' ), 'icon' => 'user' );
		/**
		 * Packages add or adjust sidebar items.
		 *
		 * @param array  $items
		 * @param string $ws
		 * @param int    $uid
		 */
		return (array) apply_filters( 'educore/shell/nav', $items, $ws, $uid );
	}

	/** @return array<int,array{label:string,count:int,url:string}> */
	public static function notifications( int $uid ): array {
		$n = array();
		if ( class_exists( '\EduCore\Assessments\Grading' ) && user_can( $uid, 'ec_grade_submissions' ) ) {
			$c = count( \EduCore\Assessments\Grading::queue( $uid, 0, 200 ) );
			if ( $c ) {
				$n[] = array( 'label' => __( 'Exam answers to grade', 'educore-workspace' ), 'count' => $c, 'url' => class_exists( '\EduCore\TeachingHub\Portal' ) ? \EduCore\TeachingHub\Portal::url( 'grading' ) : admin_url( 'admin.php?page=educore-grading' ) );
			}
		}
		if ( class_exists( '\EduCore\TeachingHub\Assignments' ) ) {
			if ( user_can( $uid, 'ec_teach' ) || user_can( $uid, 'ec_grade_submissions' ) ) {
				$c = count( \EduCore\TeachingHub\Assignments::grading_queue( $uid, 200 ) );
				if ( $c ) {
					$n[] = array( 'label' => __( 'Assignments to grade', 'educore-workspace' ), 'count' => $c, 'url' => \EduCore\TeachingHub\Portal::url( 'grading' ) );
				}
			}
			if ( user_can( $uid, 'ec_learn' ) ) {
				$soon = 0;
				$now  = time();
				foreach ( \EduCore\TeachingHub\Assignments::for_student( $uid ) as $a ) {
					$due = strtotime( (string) ( $a['due_at'] ?? '' ) . ' UTC' );
					if ( $due && $due > $now && $due < $now + 7 * DAY_IN_SECONDS && in_array( (string) $a['sub_status'], array( '', 'draft' ), true ) ) {
						++$soon;
					}
				}
				if ( $soon ) {
					$n[] = array( 'label' => __( 'Assignments due this week', 'educore-workspace' ), 'count' => $soon, 'url' => CorePages::url( 'dashboard' ) );
				}
			}
		}
		if ( user_can( $uid, 'publish_ec_courses' ) ) {
			$c = count( Studio\Courses::review_queue( $uid ) );
			if ( $c ) {
				$n[] = array( 'label' => __( 'Courses awaiting review', 'educore-workspace' ), 'count' => $c, 'url' => Pages::url( 'studio', array( 'v' => 'review' ) ) );
			}
		}
		return (array) apply_filters( 'educore/shell/notifications', $n, $uid );
	}

	/** @return array<int,array{label:string,url:string}> */
	public static function quick_actions( string $ws, int $uid ): array {
		$q = array();
		if ( 'manage' === $ws && user_can( $uid, Plugin::CAP_PEOPLE ) ) {
			$q[] = array( 'label' => __( 'Add a person', 'educore-workspace' ), 'url' => Pages::url( 'manage', array( 'v' => 'person', 'new' => 1 ) ) );
		}
		if ( user_can( $uid, 'edit_ec_courses' ) ) {
			$q[] = array( 'label' => __( 'New course', 'educore-workspace' ), 'url' => Pages::url( 'studio', array( 'v' => 'new' ) ) );
		}
		if ( class_exists( '\EduCore\TeachingHub\Portal' ) && user_can( $uid, 'ec_teach' ) ) {
			$q[] = array( 'label' => __( 'New assignment', 'educore-workspace' ), 'url' => \EduCore\TeachingHub\Portal::url( 'assignment', array( 'new' => 1 ) ) );
			$q[] = array( 'label' => __( 'Take attendance', 'educore-workspace' ), 'url' => \EduCore\TeachingHub\Portal::url( 'attendance' ) );
		}
		if ( user_can( $uid, 'ec_learn' ) ) {
			$q[] = array( 'label' => __( 'Continue learning', 'educore-workspace' ), 'url' => CorePages::url( 'dashboard' ) );
		}
		return (array) apply_filters( 'educore/shell/quick_actions', $q, $ws, $uid );
	}

	public static function icon( string $name ): string {
		$p = array(
			'home'  => 'M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z',
			'users' => 'M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zM8 12a3 3 0 1 0-3-3 3 3 0 0 0 3 3zm8 2c-3 0-8 1.5-8 4.5V21h16v-2.5c0-3-5-4.5-8-4.5zM8 14c-.6 0-1.3 0-2 .2C3.8 14.7 1 15.9 1 18v3h5v-2.5c0-1.6.8-3 2.3-4.2z',
			'user'  => 'M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5zm0 2c-4 0-9 2-9 5v2h18v-2c0-3-5-5-9-5z',
			'book'  => 'M4 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4zm16 0h-4a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h5z',
			'list'  => 'M4 6h16M4 12h16M4 18h10',
			'gauge' => 'M12 13l4-4M3 17a9 9 0 1 1 18 0',
			'clock' => 'M12 7v5l3 2M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18z',
			'chat'  => 'M4 5h16v11H8l-4 4z',
			'grid'  => 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
		);
		$d = $p[ $name ] ?? $p['grid'];
		return '<svg class="ec-app-ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="' . esc_attr( $d ) . '"/></svg>';
	}
}
