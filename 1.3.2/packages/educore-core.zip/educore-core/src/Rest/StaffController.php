<?php
namespace EduCore\Core\Rest;

use EduCore\Core\Content;
use EduCore\Core\Enrollment;
use EduCore\Core\Progress;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/** Instructor / manager endpoints. Every route checks an object-scoped meta capability. */
final class StaffController {

	public static function routes(): void {
		$id = array( 'id' => Routes::id_arg() );
		register_rest_route(
			Routes::NS,
			'/courses/(?P<id>\d+)/students',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'students' ),
				'permission_callback' => static fn( \WP_REST_Request $r ) => current_user_can( 'ec_view_course_records', (int) $r['id'] ),
				'args'                => $id,
			)
		);
		register_rest_route(
			Routes::NS,
			'/courses/(?P<id>\d+)/enrollments',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'enroll_user' ),
				'permission_callback' => static fn( \WP_REST_Request $r ) => current_user_can( 'ec_manage_course_enrollments', (int) $r['id'] ),
				'args'                => array_merge(
					$id,
					array(
						'email'      => array( 'type' => 'string', 'format' => 'email', 'required' => true ),
						'expires_at' => array( 'type' => 'string', 'default' => '' ),
					)
				),
			)
		);
		register_rest_route(
			Routes::NS,
			'/courses/(?P<id>\d+)/enrollments/(?P<user_id>\d+)',
			array(
				'methods'             => 'PATCH',
				'callback'            => array( self::class, 'set_status' ),
				'permission_callback' => static fn( \WP_REST_Request $r ) => current_user_can( 'ec_manage_course_enrollments', (int) $r['id'] ),
				'args'                => array_merge(
					$id,
					array(
						'user_id' => Routes::id_arg(),
						'status'  => array( 'type' => 'string', 'enum' => Enrollment::STATUSES, 'required' => true ),
					)
				),
			)
		);
		register_rest_route(
			Routes::NS,
			'/courses/(?P<id>\d+)/duplicate',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'duplicate' ),
				'permission_callback' => static fn( \WP_REST_Request $r ) => current_user_can( 'ec_edit_course', (int) $r['id'] ) && current_user_can( 'edit_ec_courses' ),
				'args'                => $id,
			)
		);
		register_rest_route(
			Routes::NS,
			'/courses/(?P<id>\d+)/outline',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'outline' ),
				'permission_callback' => static fn( \WP_REST_Request $r ) => current_user_can( 'ec_edit_course', (int) $r['id'] ),
				'args'                => $id,
			)
		);
		register_rest_route(
			Routes::NS,
			'/reorder',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'reorder' ),
				'permission_callback' => static fn() => current_user_can( 'edit_ec_courses' ),
				'args'                => array( 'ids' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ), 'required' => true ) ),
			)
		);
		register_rest_route(
			Routes::NS,
			'/workspace',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'workspace' ),
				'permission_callback' => static fn() => current_user_can( 'ec_access_workspace' ),
			)
		);
	}

	public static function students( \WP_REST_Request $r ): \WP_REST_Response {
		$cid  = (int) $r['id'];
		$out  = array();
		$rows = Enrollment::for_course( $cid );
		$bulk = Progress::bulk_course_summary( $cid, array_map( static fn( $e ) => (int) $e['user_id'], $rows ) );
		cache_users( array_map( static fn( $e ) => (int) $e['user_id'], $rows ) );
		foreach ( $rows as $e ) {
			$u = get_userdata( (int) $e['user_id'] );
			if ( ! $u ) {
				continue;
			}
			$out[] = array(
				'user_id'  => (int) $u->ID,
				'name'     => $u->display_name,
				'email'    => current_user_can( 'ec_manage_course_enrollments', $cid ) ? $u->user_email : '',
				'status'   => $e['status'],
				'since'    => $e['starts_at'],
				'progress' => $bulk[ (int) $u->ID ],
			);
		}
		return new \WP_REST_Response( $out );
	}

	public static function enroll_user( \WP_REST_Request $r ) {
		$u = get_user_by( 'email', (string) $r['email'] );
		if ( ! $u ) {
			return Routes::error( 'educore_no_user', __( 'No account uses this e-mail address.', 'educore-core' ), 404 );
		}
		$exp = (string) $r['expires_at'];
		$exp = '' === $exp ? null : gmdate( 'Y-m-d H:i:s', strtotime( $exp ) ?: time() );
		$res = Enrollment::enroll( (int) $u->ID, (int) $r['id'], 'admin', $exp );
		return is_wp_error( $res ) ? $res : new \WP_REST_Response( array( 'enrollment_id' => $res ), 201 );
	}

	public static function set_status( \WP_REST_Request $r ) {
		$ok = Enrollment::set_status( (int) $r['user_id'], (int) $r['id'], (string) $r['status'] );
		return $ok ? new \WP_REST_Response( array( 'updated' => true ) ) : Routes::error( 'educore_not_found', __( 'Enrollment not found or unchanged.', 'educore-core' ), 404 );
	}

	public static function duplicate( \WP_REST_Request $r ) {
		$new = Content::duplicate_course( (int) $r['id'], get_current_user_id() );
		return $new ? new \WP_REST_Response( array( 'course_id' => $new, 'edit_url' => get_edit_post_link( $new, 'raw' ) ), 201 ) : Routes::error( 'educore_failed', __( 'Could not duplicate the course.', 'educore-core' ), 400 );
	}

	public static function outline( \WP_REST_Request $r ): \WP_REST_Response {
		$out = array();
		foreach ( Content::outline( (int) $r['id'], array( 'publish', 'draft', 'pending', 'future', 'ec_archived' ) ) as $row ) {
			$out[] = array(
				'id'      => $row['unit']->ID,
				'title'   => $row['unit']->post_title,
				'status'  => $row['unit']->post_status,
				'lessons' => array_map( static fn( $l ) => array( 'id' => $l->ID, 'title' => $l->post_title, 'status' => $l->post_status ), $row['lessons'] ),
			);
		}
		return new \WP_REST_Response( $out );
	}

	public static function reorder( \WP_REST_Request $r ) {
		$ids = array_map( 'absint', (array) $r['ids'] );
		// All items must be EduCore content the user may edit; otherwise reject the whole request.
		foreach ( $ids as $id ) {
			if ( ! Content::is_content_type( (string) get_post_type( $id ) ) || ! current_user_can( 'edit_post', $id ) ) {
				return Routes::error( 'educore_forbidden', __( 'You cannot reorder one or more of these items.', 'educore-core' ), 403 );
			}
		}
		return new \WP_REST_Response( array( 'updated' => Content::reorder( $ids ) ) );
	}

	public static function workspace(): \WP_REST_Response {
		$uid     = get_current_user_id();
		$courses = current_user_can( 'ec_manage_all_courses' )
			? get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'future' ), 'posts_per_page' => 200, 'fields' => 'ids' ) )
			: Staff::courses_of( $uid );
		$out = array();
		foreach ( $courses as $cid ) {
			$out[] = array(
				'id'       => (int) $cid,
				'title'    => get_the_title( $cid ),
				'status'   => get_post_status( $cid ),
				'role'     => Staff::role_of( $uid, (int) $cid ) ?: 'manager',
				'students' => count( Enrollment::for_course( (int) $cid ) ),
				'edit_url' => current_user_can( 'edit_post', $cid ) ? get_edit_post_link( $cid, 'raw' ) : '',
			);
		}
		return new \WP_REST_Response( apply_filters( 'educore/workspace/data', array( 'courses' => $out ), $uid ) );
	}
}
