<?php
namespace EduCore\Experience;

use EduCore\Core\Registry;

defined( 'ABSPATH' ) || exit;

/** Bootstrap: pages, assets, hooks. All features degrade to nothing when their data source is absent. */
final class Plugin {
	public const PAGES_OPTION = 'educore_xp_pages';

	public static function boot(): void {
		Registry::register( 'experience', EDUCORE_XP_VERSION );
		add_action( 'init', static fn() => load_plugin_textdomain( 'educore-experience', false, dirname( plugin_basename( EDUCORE_XP_FILE ) ) . '/languages' ), 1 );
		if ( get_option( 'educore_xp_version' ) !== EDUCORE_XP_VERSION ) {
			add_action( 'init', array( self::class, 'install' ), 20 );
		}
		Prefs::register();
		Appearance::register();
		Welcome::register();
		Resume::register();
		PrefsPage::register();
		Onboarding::register();
		Settings::register();
		Privacy::register();
		add_action( 'wp_enqueue_scripts', array( self::class, 'assets' ), 30 );
		add_filter( 'educore/workspace/own_pages', static fn( $ids ) => array_merge( (array) $ids, array_filter( array( self::page_id( 'preferences' ), self::page_id( 'welcome' ) ) ) ) );
	}

	public static function install(): void {
		$pages = (array) get_option( self::PAGES_OPTION, array() );
		$defs  = array(
			'preferences' => array( 'My EduCore preferences', '<!-- wp:shortcode -->[educore_preferences]<!-- /wp:shortcode -->' ),
			'welcome'     => array( 'Welcome to EduCore', '<!-- wp:shortcode -->[educore_welcome]<!-- /wp:shortcode -->' ),
		);
		foreach ( $defs as $key => $d ) {
			if ( ! empty( $pages[ $key ] ) && get_post( (int) $pages[ $key ] ) ) {
				continue;
			}
			$existing = get_page_by_path( $key );
			if ( $existing && false !== strpos( (string) $existing->post_content, '[educore_' ) ) {
				$pages[ $key ] = (int) $existing->ID;
				continue;
			}
			if ( $existing ) {
				continue; // Never take over a page the owner created.
			}
			$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $d[0], 'post_name' => $key, 'post_content' => $d[1], 'comment_status' => 'closed' ), true );
			if ( ! is_wp_error( $id ) ) {
				$pages[ $key ] = (int) $id;
			}
		}
		update_option( self::PAGES_OPTION, $pages, false );
		add_option( 'educore_xp_installed_at', gmdate( 'Y-m-d H:i:s' ), '', false );
		update_option( 'educore_xp_version', EDUCORE_XP_VERSION, false );
	}

	public static function page_id( string $key ): int {
		return (int) ( ( (array) get_option( self::PAGES_OPTION, array() ) )[ $key ] ?? 0 );
	}

	public static function url( string $key, array $args = array() ): string {
		$id  = self::page_id( $key );
		$url = $id && 'publish' === get_post_status( $id ) ? (string) get_permalink( $id ) : home_url( '/' . $key . '/' );
		return $args ? add_query_arg( $args, $url ) : $url;
	}

	public static function assets(): void {
		wp_enqueue_style( 'educore-xp', EDUCORE_XP_URL . 'assets/css/experience.css', array(), EDUCORE_XP_VERSION );
		wp_enqueue_script( 'educore-xp', EDUCORE_XP_URL . 'assets/js/experience.js', array(), EDUCORE_XP_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		$uid = get_current_user_id();
		wp_localize_script(
			'educore-xp',
			'EduCoreXP',
			array(
				'rest'     => esc_url_raw( rest_url( 'educore/v1/' ) ),
				'nonce'    => $uid ? wp_create_nonce( 'wp_rest' ) : '',
				'user'     => $uid ? 1 : 0,
				'lesson'   => ( $uid && is_singular( 'ec_lesson' ) ) ? (int) get_queried_object_id() : 0,
				'resumeAt' => ( $uid && is_singular( 'ec_lesson' ) ) ? Resume::position( $uid, (int) get_queried_object_id() ) : 0,
				'i18n'     => array(
					'saved' => __( 'Saved.', 'educore-experience' ),
					'error' => __( 'Your change could not be saved. Please try again.', 'educore-experience' ),
					'jump'  => __( 'Jump to where I left off', 'educore-experience' ),
				),
			)
		);
	}

	/** Shared helper: the role "lens" used to decide which greeting, facts and actions apply. */
	public static function lens( int $uid ): string {
		if ( user_can( $uid, 'manage_options' ) ) {
			return 'admin';
		}
		if ( class_exists( '\EduCore\Workspace\Navigation' ) && \EduCore\Workspace\Navigation::can_manage( $uid ) ) {
			return 'manager';
		}
		$roles = (array) ( get_userdata( $uid )->roles ?? array() );
		if ( in_array( 'ec_teacher', $roles, true ) ) {
			return 'teacher';
		}
		if ( user_can( $uid, 'edit_ec_courses' ) ) {
			return 'instructor';
		}
		if ( user_can( $uid, 'ec_tutor_sessions' ) ) {
			return 'tutor';
		}
		if ( user_can( $uid, 'ec_teach' ) ) {
			return 'teacher';
		}
		if ( class_exists( '\EduCore\Workspace\Guardian' ) && \EduCore\Workspace\Guardian::is_guardian( $uid ) && ! user_can( $uid, 'ec_learn' ) ) {
			return 'guardian';
		}
		return user_can( $uid, 'ec_learn' ) ? 'student' : 'account';
	}
}
