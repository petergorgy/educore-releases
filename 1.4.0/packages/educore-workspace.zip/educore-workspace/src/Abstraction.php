<?php
namespace EduCore\Workspace;

use EduCore\Core\Auth\Router;

defined( 'ABSPATH' ) || exit;

/**
 * Keeps WordPress invisible for everyday users. People whose work is fully covered by EduCore workspaces are sent
 * from wp-admin to their workspace. Technical administrators (manage_options) and anyone who still needs an
 * admin-only EduCore tool keep wp-admin; recovery paths (wp-login, admin-ajax, admin-post, uploads, REST, WP-CLI,
 * cron) are never touched.
 */
final class Abstraction {

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'redirect' ), 1 );
		add_action( 'admin_init', array( self::class, 'redirect' ), 2 );
	}

	/** Capabilities that still require wp-admin (shrinks as frontend centers ship). */
	public static function admin_needs(): array {
		return (array) apply_filters( 'educore/workspace/admin_capabilities', array( 'manage_options', 'edit_posts', 'edit_ec_courses', 'ec_manage_question_bank', 'ec_manage_assessments', 'ec_manage_settings', 'ec_manage_programmes', 'ec_manage_certificates', 'ec_manage_backups', 'ec_view_analytics', 'ec_view_audit_log' ) );
	}

	public static function needs_admin( int $uid ): bool {
		foreach ( self::admin_needs() as $cap ) {
			if ( user_can( $uid, $cap ) ) {
				return true;
			}
		}
		return false;
	}

	public static function redirect(): void {
		static $done = false;
		if ( $done || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}
		$done   = true;
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( sanitize_text_field( wp_unslash( $_SERVER['SCRIPT_NAME'] ) ) ) : '';
		if ( in_array( $script, array( 'admin-post.php', 'async-upload.php', 'media-upload.php', 'admin-ajax.php' ), true ) ) {
			return;
		}
		$uid = get_current_user_id();
		if ( ! $uid || self::needs_admin( $uid ) ) {
			return;
		}
		wp_safe_redirect( Router::primary( wp_get_current_user() ) );
		exit;
	}
}
