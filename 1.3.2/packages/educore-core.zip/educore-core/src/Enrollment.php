<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Enrollment lifecycle: active → completed | suspended | expired | withdrawn. */
final class Enrollment {
	public const STATUSES = array( 'active', 'completed', 'suspended', 'expired', 'withdrawn' );
	public const SOURCES  = array( 'admin', 'self', 'commerce', 'import', 'class' );

	/**
	 * Create or reactivate an enrollment.
	 *
	 * @return int|\WP_Error enrollment id
	 */
	public static function enroll( int $user_id, int $course_id, string $source = 'admin', ?string $expires_at = null ) {
		global $wpdb;
		if ( ! get_userdata( $user_id ) ) {
			return new \WP_Error( 'educore_no_user', __( 'User not found.', 'educore-core' ), array( 'status' => 404 ) );
		}
		if ( ! Content::is_course( $course_id ) ) {
			return new \WP_Error( 'educore_no_course', __( 'Course not found.', 'educore-core' ), array( 'status' => 404 ) );
		}
		if ( ! in_array( $source, self::SOURCES, true ) ) {
			$source = 'admin';
		}
		$t   = Schema::table( 'enrollments' );
		$now = Schema::now();
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$t} (user_id,course_id,status,source,starts_at,expires_at,updated_at) VALUES (%d,%d,'active',%s,%s,%s,%s)
				 ON DUPLICATE KEY UPDATE status = IF(status='completed','completed','active'), source = VALUES(source), expires_at = VALUES(expires_at), updated_at = VALUES(updated_at)", // phpcs:ignore WordPress.DB.PreparedSQL
				$user_id,
				$course_id,
				$source,
				$now,
				$expires_at,
				$now
			)
		);
		if ( null === $expires_at ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET expires_at = NULL WHERE user_id=%d AND course_id=%d", $user_id, $course_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE user_id=%d AND course_id=%d", $user_id, $course_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$user = get_userdata( $user_id );
		if ( $user && ! array_intersect( array( 'administrator', 'ec_academic_manager', 'ec_instructor', 'ec_grader' ), (array) $user->roles ) && ! in_array( 'ec_student', (array) $user->roles, true ) ) {
			$user->add_role( 'ec_student' );
		}
		Audit::log( 'enrollment.created', 'course', $course_id, array( 'user_id' => $user_id, 'source' => $source ) );
		do_action( 'educore/events/enrolled', $user_id, $course_id, $source );
		return $id;
	}

	public static function set_status( int $user_id, int $course_id, string $status ): bool {
		global $wpdb;
		if ( ! in_array( $status, self::STATUSES, true ) ) {
			return false;
		}
		$data = array( 'status' => $status, 'updated_at' => Schema::now() );
		if ( 'completed' === $status ) {
			$data['completed_at'] = Schema::now();
		}
		$ok = (bool) $wpdb->update( Schema::table( 'enrollments' ), $data, array( 'user_id' => $user_id, 'course_id' => $course_id ) );
		if ( $ok ) {
			Audit::log( 'enrollment.' . $status, 'course', $course_id, array( 'user_id' => $user_id ) );
			do_action( 'educore/events/enrollment_status', $user_id, $course_id, $status );
		}
		return $ok;
	}

	public static function get( int $user_id, int $course_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'enrollments' ) . ' WHERE user_id=%d AND course_id=%d', $user_id, $course_id ), ARRAY_A );
		return $row ?: null;
	}

	/** True when enrollment exists, is active/completed and not expired. */
	public static function is_enrolled( int $user_id, int $course_id, bool $require_current = true ): bool {
		$row = self::get( $user_id, $course_id );
		if ( ! $row ) {
			return false;
		}
		if ( ! $require_current ) {
			return true;
		}
		if ( ! in_array( $row['status'], array( 'active', 'completed' ), true ) ) {
			return false;
		}
		return empty( $row['expires_at'] ) || strtotime( $row['expires_at'] . ' UTC' ) > time();
	}

	/** @return array<int,array<string,mixed>> */
	public static function for_user( int $user_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'enrollments' ) . ' WHERE user_id=%d ORDER BY updated_at DESC', $user_id ), ARRAY_A ) ?: array();
	}

	/** @return array<int,array<string,mixed>> */
	public static function for_course( int $course_id, int $limit = 500, int $offset = 0 ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'enrollments' ) . ' WHERE course_id=%d ORDER BY id ASC LIMIT %d OFFSET %d', $course_id, $limit, $offset ), ARRAY_A ) ?: array();
	}

	public static function count_for_course( int $course_id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Schema::table( 'enrollments' ) . ' WHERE course_id=%d', $course_id ) );
	}

	/** Cron: mark past-due enrollments as expired. */
	public static function expire_due(): int {
		global $wpdb;
		$t    = Schema::table( 'enrollments' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT user_id, course_id FROM {$t} WHERE status='active' AND expires_at IS NOT NULL AND expires_at <= %s LIMIT 500", Schema::now() ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( $rows as $r ) {
			self::set_status( (int) $r['user_id'], (int) $r['course_id'], 'expired' );
		}
		return count( $rows );
	}
}
