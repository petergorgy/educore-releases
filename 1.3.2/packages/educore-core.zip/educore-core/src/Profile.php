<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Learner profile with validation and data minimisation (all extra fields optional). */
final class Profile {

	/** Egyptian mobile: 01[0125]XXXXXXXX, +201…, 00201… → normalised to +201XXXXXXXXX */
	public static function normalize_eg_mobile( string $raw ): ?string {
		$d = preg_replace( '/[^\d+]/', '', $raw );
		$d = preg_replace( '/^(\+20|0020|20)/', '0', (string) $d );
		if ( ! preg_match( '/^01[0125]\d{8}$/', (string) $d ) ) {
			return null;
		}
		return '+20' . substr( $d, 1 );
	}

	public static function get( int $user_id ): array {
		$u = get_userdata( $user_id );
		if ( ! $u ) {
			return array();
		}
		$avatar_id = (int) get_user_meta( $user_id, 'educore_avatar_id', true );
		return apply_filters(
			'educore/profile/get',
			array(
				'display_name'  => $u->display_name,
				'email'         => $u->user_email,
				'mobile'        => (string) get_user_meta( $user_id, 'educore_mobile', true ),
				'academic_year' => (string) get_user_meta( $user_id, 'educore_academic_year', true ),
				'programme_id'  => (int) get_user_meta( $user_id, 'educore_programme_id', true ),
				'lang'          => I18n::sanitize_lang( get_user_meta( $user_id, 'educore_lang', true ) ?: I18n::DEFAULT ),
				'avatar'        => $avatar_id ? (string) wp_get_attachment_image_url( $avatar_id, 'thumbnail' ) : get_avatar_url( $user_id ),
				'age_band'      => (string) get_user_meta( $user_id, 'educore_age_band', true ),
				'consent_state' => (string) get_user_meta( $user_id, 'educore_consent_state', true ),
			),
			$user_id
		);
	}

	/** @return true|\WP_Error */
	public static function update( int $user_id, array $in ) {
		if ( isset( $in['display_name'] ) ) {
			$name = sanitize_text_field( (string) $in['display_name'] );
			if ( '' === $name || mb_strlen( $name ) > 120 ) {
				return new \WP_Error( 'educore_invalid_name', __( 'Please enter your full name (up to 120 characters).', 'educore-core' ), array( 'status' => 400 ) );
			}
			wp_update_user( array( 'ID' => $user_id, 'display_name' => $name ) );
		}
		if ( array_key_exists( 'mobile', $in ) ) {
			$raw = trim( (string) $in['mobile'] );
			if ( '' === $raw ) {
				delete_user_meta( $user_id, 'educore_mobile' );
			} else {
				$m = self::normalize_eg_mobile( $raw );
				if ( null === $m ) {
					return new \WP_Error( 'educore_invalid_mobile', __( 'Please enter a valid Egyptian mobile number, e.g. 01012345678.', 'educore-core' ), array( 'status' => 400 ) );
				}
				update_user_meta( $user_id, 'educore_mobile', $m );
			}
		}
		if ( isset( $in['academic_year'] ) ) {
			update_user_meta( $user_id, 'educore_academic_year', sanitize_text_field( substr( (string) $in['academic_year'], 0, 60 ) ) );
		}
		if ( isset( $in['programme_id'] ) ) {
			update_user_meta( $user_id, 'educore_programme_id', absint( $in['programme_id'] ) );
		}
		if ( isset( $in['lang'] ) ) {
			update_user_meta( $user_id, 'educore_lang', I18n::sanitize_lang( $in['lang'] ) );
		}
		/** Notifications etc. persist their own fields. */
		$res = apply_filters( 'educore/profile/update', true, $user_id, $in );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		Audit::log( 'profile.updated', 'user', $user_id );
		return true;
	}
}
