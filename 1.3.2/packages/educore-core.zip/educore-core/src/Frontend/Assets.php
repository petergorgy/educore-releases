<?php
namespace EduCore\Core\Frontend;

use EduCore\Core\I18n;

defined( 'ABSPATH' ) || exit;

final class Assets {
	public static function register(): void {
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ) );
		add_action( 'enqueue_block_editor_assets', array( self::class, 'editor' ) );
		add_filter( 'language_attributes', array( self::class, 'dir_attribute' ) );
	}

	public static function enqueue(): void {
		wp_enqueue_style( 'educore-core', EDUCORE_CORE_URL . 'assets/css/educore.css', array(), EDUCORE_CORE_VERSION );
		wp_enqueue_script( 'educore-core', EDUCORE_CORE_URL . 'assets/js/educore.js', array(), EDUCORE_CORE_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script(
			'educore-core',
			'EduCore',
			array(
				'rest'  => esc_url_raw( rest_url( 'educore/v1/' ) ),
				'nonce' => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
				'lang'  => I18n::current(),
				'i18n'  => array(
					'saved'      => __( 'Saved', 'educore-core' ),
					'error'      => __( 'Something went wrong. Please try again.', 'educore-core' ),
					'completed'  => __( 'Lesson completed', 'educore-core' ),
					'bookmarked' => __( 'Bookmarked', 'educore-core' ),
					'deleted'    => __( 'Deleted', 'educore-core' ),
					'confirm'    => __( 'Are you sure?', 'educore-core' ),
					'noNotes'    => __( 'No notes yet.', 'educore-core' ),
					'delete'     => __( 'Delete', 'educore-core' ),
					'enrolled'   => __( 'You are enrolled. Redirecting…', 'educore-core' ),
				),
			)
		);
	}

	public static function editor(): void {
		wp_enqueue_script( 'educore-blocks-editor', EDUCORE_CORE_URL . 'assets/js/blocks-editor.js', array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-i18n', 'wp-block-editor' ), EDUCORE_CORE_VERSION, true );
		wp_localize_script( 'educore-blocks-editor', 'EduCoreBlocks', array( 'blocks' => Blocks::editor_list() ) );
	}

	/** Ensure dir="rtl" for Arabic even when the theme does not handle it. */
	public static function dir_attribute( string $output ): string {
		if ( is_admin() ) {
			return $output;
		}
		$lang = I18n::current();
		$out  = preg_replace( '/\s?(dir|lang)="[^"]*"/', '', $output );
		return trim( $out . ' lang="' . esc_attr( 'ar' === $lang ? 'ar' : ( 'fr' === $lang ? 'fr-FR' : 'en-US' ) ) . '" dir="' . ( 'ar' === $lang ? 'rtl' : 'ltr' ) . '"' );
	}
}
