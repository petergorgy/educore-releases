<?php
namespace EduCore\Assessments\Exchange;

use EduCore\Assessments\Questions;
use EduCore\Assessments\Types;
use EduCore\Core\Content;
use EduCore\Core\I18n;

defined( 'ABSPATH' ) || exit;

/**
 * Validates one exchange record for a target course. Never trusts the file: types, keys, sizes,
 * languages, lessons and publishing rights are all checked server-side.
 */
final class Validator {
	public const MAX_STEM   = 20000;
	public const MAX_POINTS = 1000;

	/**
	 * @return array{record:array,errors:string[],warnings:string[]}
	 */
	public static function check( array $r, int $course_id, array $defaults = array() ): array {
		$r        = Record::normalise( $r );
		$errors   = array();
		$warnings = array();
		$t        = $r['type'];

		if ( ! in_array( $t, Types::ALL, true ) ) {
			return array( 'record' => $r, 'errors' => array( sprintf( /* translators: %s: type */ __( 'Unknown question type "%s".', 'educore-assessments' ), $t ) ), 'warnings' => array() );
		}
		$ext       = 0;
		$r['stem'] = self::clean( $r['stem'], $ext );
		$r['explanation'] = self::clean( $r['explanation'], $ext );
		foreach ( array( 'options', 'left', 'right', 'items' ) as $list ) {
			foreach ( (array) ( $r['payload'][ $list ] ?? array() ) as $i => $o ) {
				if ( is_array( $o ) && isset( $o['text'] ) ) {
					$r['payload'][ $list ][ $i ]['text'] = self::clean( (string) $o['text'], $ext );
				}
			}
		}
		if ( isset( $r['key']['model_answer'] ) ) {
			$r['key']['model_answer'] = self::clean( (string) $r['key']['model_answer'], $ext );
		}
		if ( $ext ) {
			$warnings[] = __( 'Images loaded from other websites were removed (they could track students). Upload images to the media library instead.', 'educore-assessments' );
		}
		if ( '' === trim( wp_strip_all_tags( $r['stem'] ) ) && 'image' !== $t ) {
			$errors[] = __( 'The question text is empty.', 'educore-assessments' );
		}
		if ( mb_strlen( $r['stem'] ) > self::MAX_STEM ) {
			$errors[] = __( 'The question text is too long.', 'educore-assessments' );
		}
		$errors = array_merge( $errors, self::key_errors( $t, $r['payload'], $r['key'], $r['stem'] ) );

		if ( $r['points'] < 0 || $r['points'] > self::MAX_POINTS ) {
			$errors[] = sprintf( /* translators: %d: max */ __( 'Points must be between 0 and %d.', 'educore-assessments' ), self::MAX_POINTS );
		}
		foreach ( array( 'difficulty' => Questions::DIFFICULTY, 'usage' => Questions::USAGES ) as $f => $allowed ) {
			if ( ! in_array( $r[ $f ], $allowed, true ) ) {
				/* translators: 1: field, 2: value, 3: default */
				$warnings[] = sprintf( __( '%1$s "%2$s" is not recognised; "%3$s" will be used.', 'educore-assessments' ), $f, $r[ $f ], 'difficulty' === $f ? 'medium' : 'any' );
				$r[ $f ]    = 'difficulty' === $f ? 'medium' : 'any';
			}
		}
		if ( '' === $r['lang'] ) {
			$r['lang'] = (string) ( $defaults['lang'] ?? I18n::DEFAULT );
		} elseif ( ! isset( I18n::LANGS[ $r['lang'] ] ) ) {
			/* translators: %s: language */
			$warnings[] = sprintf( __( 'Language "%s" is not supported; the default language will be used.', 'educore-assessments' ), $r['lang'] );
			$r['lang']  = (string) ( $defaults['lang'] ?? I18n::DEFAULT );
		}
		if ( $r['lesson_id'] && Content::course_of( $r['lesson_id'] ) !== $course_id ) {
			$warnings[]     = __( 'The lesson does not belong to the target course; the question will not be linked to a lesson.', 'educore-assessments' );
			$r['lesson_id'] = 0;
		}
		$wanted = in_array( $r['status'], array( 'draft', 'review', 'published' ), true ) ? $r['status'] : 'draft';
		if ( isset( $defaults['status'] ) && '' !== $defaults['status'] ) {
			$wanted = $defaults['status'];
		}
		if ( 'published' === $wanted && ! Questions::can_publish( get_current_user_id(), $course_id ) ) {
			$warnings[] = __( 'You may not publish in this course; the question will be submitted for review.', 'educore-assessments' );
			$wanted     = 'review';
		}
		$r['status'] = $wanted;
		if ( 'image' === $t && empty( $r['media'] ) && ! wp_attachment_is_image( (int) ( $r['payload']['image_id'] ?? 0 ) ) ) {
			$errors[] = __( 'The image for this image question is missing (not in the package and not in the media library).', 'educore-assessments' );
		}
		return array( 'record' => $r, 'errors' => $errors, 'warnings' => $warnings );
	}

	/** Safe HTML: WordPress post rules (no scripts, event handlers or javascript:/data: URLs) and no off-site images. */
	public static function clean( string $html, int &$external ): string {
		$html = wp_kses_post( $html );
		if ( false === stripos( $html, '<img' ) ) {
			return $html;
		}
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		return (string) preg_replace_callback(
			'#<img\b[^>]*>#i',
			static function ( $m ) use ( $host, &$external ) {
				if ( preg_match( '#\ssrc\s*=\s*(["\'])(.*?)\1#i', $m[0], $src ) ) {
					$h = wp_parse_url( html_entity_decode( $src[2] ), PHP_URL_HOST );
					if ( null === $h || $h === $host ) {
						return $m[0];
					}
				}
				++$external;
				return '';
			},
			$html
		);
	}

	private static function ids( array $list ): array {
		$ids = array();
		foreach ( $list as $o ) {
			if ( ! is_array( $o ) || ! isset( $o['id'], $o['text'] ) || '' === (string) $o['id'] || '' === trim( (string) $o['text'] ) ) {
				return array();
			}
			$ids[] = (string) $o['id'];
		}
		return count( array_unique( $ids ) ) === count( $ids ) ? $ids : array();
	}

	/** Structural validation of payload + answer key per type. */
	public static function key_errors( string $t, array $p, array $k, string $stem ): array {
		$bad = static fn( string $m ) => array( $m );
		switch ( $t ) {
			case 'single':
			case 'image':
				$ids = self::ids( (array) ( $p['options'] ?? array() ) );
				if ( count( $ids ) < 2 ) {
					return $bad( __( 'At least two non-empty options are required.', 'educore-assessments' ) );
				}
				return in_array( (string) ( $k['correct'] ?? '' ), $ids, true ) ? array() : $bad( __( 'The correct option is missing or does not match an option.', 'educore-assessments' ) );
			case 'multiple':
				$ids = self::ids( (array) ( $p['options'] ?? array() ) );
				$c   = array_map( 'strval', (array) ( $k['correct'] ?? array() ) );
				if ( count( $ids ) < 2 ) {
					return $bad( __( 'At least two non-empty options are required.', 'educore-assessments' ) );
				}
				return ( $c && ! array_diff( $c, $ids ) ) ? array() : $bad( __( 'Mark at least one correct option; every correct option must exist.', 'educore-assessments' ) );
			case 'truefalse':
				return is_bool( $k['correct'] ?? null ) ? array() : $bad( __( 'The answer must be true or false.', 'educore-assessments' ) );
			case 'short':
				return array_filter( array_map( 'strval', (array) ( $k['accepted'] ?? array() ) ), 'strlen' ) ? array() : $bad( __( 'At least one accepted answer is required.', 'educore-assessments' ) );
			case 'essay':
				return array();
			case 'fill_blanks':
				preg_match_all( '/\[\[(\d+)\]\]/', $stem, $m );
				$n = $m[1] ? max( array_map( 'intval', $m[1] ) ) : 0;
				$b = array_values( (array) ( $k['blanks'] ?? array() ) );
				if ( ! $n || (int) ( $p['blanks'] ?? 0 ) !== $n || count( $b ) !== $n ) {
					return $bad( __( 'Blanks [[1]], [[2]]… in the text must match the answers given for each blank.', 'educore-assessments' ) );
				}
				foreach ( $b as $alts ) {
					if ( ! array_filter( array_map( 'strval', (array) $alts ), 'strlen' ) ) {
						return $bad( __( 'Every blank needs at least one accepted answer.', 'educore-assessments' ) );
					}
				}
				return array();
			case 'matching':
				$l = self::ids( (array) ( $p['left'] ?? array() ) );
				$r = self::ids( (array) ( $p['right'] ?? array() ) );
				$pairs = (array) ( $k['pairs'] ?? array() );
				if ( count( $l ) < 2 || count( $r ) < 2 ) {
					return $bad( __( 'At least two pairs are required.', 'educore-assessments' ) );
				}
				foreach ( $l as $id ) {
					if ( ! isset( $pairs[ $id ] ) || ! in_array( (string) $pairs[ $id ], $r, true ) ) {
						return $bad( __( 'Every item on the left needs a matching item on the right.', 'educore-assessments' ) );
					}
				}
				return array();
			case 'ordering':
				$ids   = self::ids( (array) ( $p['items'] ?? array() ) );
				$order = array_map( 'strval', (array) ( $k['order'] ?? array() ) );
				$s1    = $ids;
				$s2    = $order;
				sort( $s1 );
				sort( $s2 );
				return ( count( $ids ) >= 2 && $s1 === $s2 ) ? array() : $bad( __( 'The correct order must list every item exactly once.', 'educore-assessments' ) );
			case 'code':
				if ( '' === trim( (string) ( $p['code'] ?? '' ) ) ) {
					return $bad( __( 'The code snippet is empty.', 'educore-assessments' ) );
				}
				return array_filter( array_map( 'strval', (array) ( $k['expected'] ?? array() ) ), 'strlen' ) ? array() : $bad( __( 'The expected output is missing.', 'educore-assessments' ) );
		}
		return $bad( __( 'Unknown question type.', 'educore-assessments' ) );
	}
}
