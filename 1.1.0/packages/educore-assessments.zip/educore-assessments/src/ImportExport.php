<?php
namespace EduCore\Assessments;

use EduCore\Core\Audit;

defined( 'ABSPATH' ) || exit;

/**
 * Bulk question import/export.
 *
 * CSV (UTF-8, header row required) columns:
 *   type, lesson_id, difficulty, points, usage, lang, tags, status, stem, options, correct,
 *   explanation, model_answer, code, language, image_id, scoring
 * "scoring" (optional, multiple/ordering only): all_or_nothing (default) | partial.
 * Multi-line cells (options, correct) use line breaks inside a quoted cell — see Types::from_authoring()
 * for the meaning of "options" and "correct" per type. Imported questions default to "draft";
 * "published" is only kept when the importer may publish, otherwise it becomes "review".
 *
 * JSON: array of objects { type, lesson_id, difficulty, points, usage, lang, tags[], status, stem,
 *   payload{}, key{}, explanation } — the exact internal structure (lossless round-trip).
 */
final class ImportExport {
	public const CSV_COLUMNS = array( 'type', 'lesson_id', 'difficulty', 'points', 'usage', 'lang', 'tags', 'status', 'stem', 'options', 'correct', 'explanation', 'model_answer', 'code', 'language', 'image_id', 'scoring' );

	private static function status_for( string $wanted, int $course_id ): string {
		if ( 'published' === $wanted && ! Questions::can_publish( get_current_user_id(), $course_id ) ) {
			return 'review';
		}
		return in_array( $wanted, array( 'draft', 'review', 'published' ), true ) ? $wanted : 'draft';
	}

	/** @return array{imported:int,duplicates:int,errors:array<int,string>} */
	public static function import_rows( int $course_id, array $rows, bool $structured ): array {
		$res = array( 'imported' => 0, 'duplicates' => 0, 'errors' => array() );
		foreach ( array_slice( $rows, 0, 2000 ) as $n => $row ) {
			$line = $n + ( $structured ? 1 : 2 );
			$type = (string) ( $row['type'] ?? '' );
			if ( $structured ) {
				$payload = (array) ( $row['payload'] ?? array() );
				$key     = (array) ( $row['key'] ?? array() );
				// Normalise the optional scoring mode (top-level "scoring" or key.scoring); only partial is stored.
				unset( $key['scoring'] );
				if ( in_array( $type, Types::PARTIAL_TYPES, true ) && 'partial' === Types::scoring_of( array( 'scoring' => $row['scoring'] ?? ( $row['key']['scoring'] ?? '' ) ) ) ) {
					$key['scoring'] = 'partial';
				}
				if ( ! in_array( $type, Types::ALL, true ) || ! $key && 'essay' !== $type ) {
					/* translators: %d: row */
					$res['errors'][ $line ] = sprintf( __( 'Row %d: invalid type or missing key.', 'educore-assessments' ), $line );
					continue;
				}
			} else {
				$built = Types::from_authoring( $row );
				if ( is_wp_error( $built ) ) {
					$res['errors'][ $line ] = sprintf( 'Row %d: %s', $line, $built->get_error_message() );
					continue;
				}
				$payload = $built['payload'];
				$key     = $built['key'];
			}
			$stem = (string) ( $row['stem'] ?? '' );
			if ( Questions::duplicates( $course_id, Questions::dedupe_hash( $type, wp_kses_post( $stem ), $payload ) ) ) {
				++$res['duplicates'];
				continue;
			}
			$id = Questions::save(
				array(
					'course_id'   => $course_id,
					'lesson_id'   => absint( $row['lesson_id'] ?? 0 ),
					'type'        => $type,
					'stem'        => $stem,
					'payload'     => $payload,
					'key'         => $key,
					'explanation' => (string) ( $row['explanation'] ?? '' ),
					'points'      => '' === (string) ( $row['points'] ?? '' ) ? 1 : (float) $row['points'],
					'difficulty'  => (string) ( $row['difficulty'] ?? 'medium' ),
					'usage'       => (string) ( $row['usage'] ?? 'any' ),
					'lang'        => (string) ( $row['lang'] ?? 'en' ),
					'tags'        => $row['tags'] ?? array(),
					'status'      => self::status_for( (string) ( $row['status'] ?? 'draft' ), $course_id ),
				)
			);
			if ( is_wp_error( $id ) ) {
				$res['errors'][ $line ] = sprintf( 'Row %d: %s', $line, $id->get_error_message() );
			} else {
				++$res['imported'];
			}
		}
		Audit::log( 'questions.imported', 'course', $course_id, array( 'imported' => $res['imported'], 'duplicates' => $res['duplicates'], 'errors' => count( $res['errors'] ) ) );
		return $res;
	}

	public static function parse_csv( string $csv ): array {
		$csv = preg_replace( '/^\xEF\xBB\xBF/', '', $csv );
		$fh  = fopen( 'php://temp', 'r+' );
		fwrite( $fh, $csv );
		rewind( $fh );
		$head = fgetcsv( $fh, 0, ',', '"', '\\' );
		$rows = array();
		if ( ! $head ) {
			return array();
		}
		$head = array_map( static fn( $h ) => sanitize_key( trim( (string) $h ) ), $head );
		while ( ( $r = fgetcsv( $fh, 0, ',', '"', '\\' ) ) !== false ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
			if ( array( null ) === $r ) {
				continue;
			}
			$rows[] = array_combine( $head, array_pad( array_slice( $r, 0, count( $head ) ), count( $head ), '' ) );
		}
		fclose( $fh );
		return $rows;
	}

	/** @return array<int,array<string,mixed>> */
	public static function export_structured( int $course_id ): array {
		$out  = array();
		$page = 1;
		do {
			$batch = Questions::search( array( 'course_id' => $course_id, 'per_page' => 200, 'page' => $page ) );
			foreach ( $batch['rows'] as $r ) {
				if ( 'archived' === $r['status'] ) {
					continue;
				}
				$full  = Questions::full( (int) $r['id'] );
				$out[] = array(
					'type'        => $full['type'],
					'lesson_id'   => (int) $full['lesson_id'],
					'difficulty'  => $full['difficulty'],
					'points'      => (float) $full['version']['points'],
					'usage'       => $full['usage_scope'],
					'lang'        => $full['version']['lang'],
					'tags'        => $full['tags'],
					'status'      => $full['status'],
					'stem'        => $full['version']['stem'],
					'payload'     => $full['version']['payload'],
					'key'         => $full['version']['answer_key'],
					'scoring'     => in_array( $full['type'], Types::PARTIAL_TYPES, true ) ? Types::scoring_of( (array) $full['version']['answer_key'] ) : '',
					'explanation' => (string) $full['version']['explanation'],
				);
			}
			++$page;
		} while ( count( $batch['rows'] ) === 200 );
		return array_reverse( $out );
	}

	public static function export_csv( int $course_id ): string {
		$fh = fopen( 'php://temp', 'r+' );
		fputcsv( $fh, self::CSV_COLUMNS, ',', '"', '\\' );
		foreach ( self::export_structured( $course_id ) as $q ) {
			$a = Types::to_authoring( $q['type'], $q['payload'], $q['key'] );
			fputcsv(
				$fh,
				array( $q['type'], $q['lesson_id'], $q['difficulty'], $q['points'], $q['usage'], $q['lang'], implode( ',', $q['tags'] ), $q['status'], $q['stem'], $a['options'], $a['correct'], $q['explanation'], $a['model_answer'], $a['code'], $a['language'], $a['image_id'], $a['scoring'] ),
				',',
				'"',
				'\\'
			);
		}
		rewind( $fh );
		$csv = stream_get_contents( $fh );
		fclose( $fh );
		return "\xEF\xBB\xBF" . $csv;
	}
}
