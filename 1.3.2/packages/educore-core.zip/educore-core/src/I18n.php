<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Interface language: English (default), French, Arabic.
 * Resolution order: ?lang= (persisted in a cookie) → user preference → cookie → site default (en).
 */
final class I18n {
	public const LANGS   = array( 'en' => 'en_US', 'fr' => 'fr_FR', 'ar' => 'ar' );
	public const DEFAULT = 'en';
	public const COOKIE  = 'educore_lang';

	private static ?string $current = null;

	public static function register(): void {
		add_filter( 'locale', array( self::class, 'filter_locale' ), 20 );
		add_filter( 'determine_locale', array( self::class, 'filter_locale' ), 20 );
		add_action( 'init', array( self::class, 'persist_choice' ), 1 );
		add_action( 'init', array( self::class, 'load_textdomain' ), 2 );
		add_action( 'wp_head', array( self::class, 'hreflang' ) );
	}

	public static function load_textdomain(): void {
		load_plugin_textdomain( 'educore-core', false, dirname( plugin_basename( EDUCORE_CORE_FILE ) ) . '/languages' );
	}

	public static function sanitize_lang( $v ): string {
		$v = is_string( $v ) ? strtolower( substr( $v, 0, 2 ) ) : '';
		return isset( self::LANGS[ $v ] ) ? $v : self::DEFAULT;
	}

	public static function current(): string {
		if ( null !== self::$current ) {
			return self::$current;
		}
		$lang = null;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public, idempotent language switch.
		if ( isset( $_GET['lang'] ) ) {
			$lang = self::sanitize_lang( sanitize_key( wp_unslash( $_GET['lang'] ) ) );
		} elseif ( function_exists( 'is_user_logged_in' ) && did_action( 'set_current_user' ) && is_user_logged_in() ) {
			$pref = get_user_meta( get_current_user_id(), 'educore_lang', true );
			$lang = $pref ? self::sanitize_lang( $pref ) : null;
		}
		if ( null === $lang && isset( $_COOKIE[ self::COOKIE ] ) ) {
			$lang = self::sanitize_lang( sanitize_key( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) );
		}
		$lang = $lang ?? self::sanitize_lang( get_option( 'educore_default_lang', self::DEFAULT ) );
		if ( did_action( 'set_current_user' ) ) {
			self::$current = $lang;
		}
		return $lang;
	}

	public static function reset(): void {
		self::$current = null;
	}

	public static function filter_locale( $locale ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $locale; // Admin UI follows the WordPress user locale setting.
		}
		return self::LANGS[ self::current() ] ?? $locale;
	}

	public static function persist_choice(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['lang'] ) ) {
			return;
		}
		$lang = self::sanitize_lang( sanitize_key( wp_unslash( $_GET['lang'] ) ) );
		if ( ! headers_sent() ) {
			setcookie( self::COOKIE, $lang, time() + YEAR_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true );
		}
		if ( is_user_logged_in() ) {
			update_user_meta( get_current_user_id(), 'educore_lang', $lang );
		}
	}

	public static function is_rtl(): bool {
		return 'ar' === self::current();
	}

	public static function switch_url( string $lang ): string {
		return esc_url( add_query_arg( 'lang', self::sanitize_lang( $lang ) ) );
	}

	/** @return array<string,string> code => native label */
	public static function labels(): array {
		return array( 'en' => 'English', 'fr' => 'Français', 'ar' => 'العربية' );
	}

	public static function hreflang(): void {
		if ( is_admin() ) {
			return;
		}
		$url = home_url( add_query_arg( array() ) );
		foreach ( array_keys( self::LANGS ) as $code ) {
			printf( '<link rel="alternate" hreflang="%s" href="%s" />' . "\n", esc_attr( $code ), esc_url( add_query_arg( 'lang', $code, remove_query_arg( 'lang', $url ) ) ) );
		}
	}

	/** Translation-group helpers for content (independent from interface strings). */
	public static function link_translation( string $object_type, int $object_id, int $group_id, string $lang ): bool {
		global $wpdb;
		$lang = self::sanitize_lang( $lang );
		$res  = $wpdb->query( $wpdb->prepare( 'INSERT INTO ' . Schema::table( 'translation_groups' ) . ' (object_type,group_id,object_id,lang) VALUES (%s,%d,%d,%s) ON DUPLICATE KEY UPDATE group_id=VALUES(group_id), lang=VALUES(lang)', $object_type, $group_id, $object_id, $lang ) );
		return false !== $res;
	}

	/** @return array<string,int> lang => object id */
	public static function translations( string $object_type, int $object_id ): array {
		global $wpdb;
		$t     = Schema::table( 'translation_groups' );
		$group = (int) $wpdb->get_var( $wpdb->prepare( "SELECT group_id FROM {$t} WHERE object_type=%s AND object_id=%d", $object_type, $object_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( ! $group ) {
			return array();
		}
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT lang, object_id FROM {$t} WHERE object_type=%s AND group_id=%d", $object_type, $group ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ $r['lang'] ] = (int) $r['object_id'];
		}
		return $out;
	}
}
