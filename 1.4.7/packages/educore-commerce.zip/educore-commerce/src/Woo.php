<?php
namespace EduCore\Commerce;

use EduCore\Core\Audit;
use EduCore\Core\Content;

defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce integration: product ↔ course mapping, order lifecycle → entitlements, catalogue price
 * labels and purchase buttons. EduCore never sees or stores card data; payment is handled entirely by
 * the WooCommerce gateway the owner configures (credentials live in WooCommerce settings).
 *
 * Product meta: _educore_course_ids (int[] for the UI) + one _educore_course_id row per course (lookup),
 * _educore_access_days (0 = lifetime), _educore_trial_days (zero-price trial product only).
 */
final class Woo {
	public const PAID_STATUSES   = array( 'processing', 'completed' );
	public const REVOKE_STATUSES = array( 'refunded' => 'refunded', 'cancelled' => 'cancelled', 'failed' => 'cancelled' );

	public static function register(): void {
		add_filter( 'educore/catalog/card', array( self::class, 'card' ), 10, 2 );
		add_filter( 'educore/course/enroll_cta', array( self::class, 'cta' ), 10, 3 );
		if ( ! Plugin::woo_active() ) {
			return;
		}
		add_action( 'woocommerce_order_status_changed', array( self::class, 'status_changed' ), 10, 4 );
		add_filter( 'woocommerce_product_data_tabs', array( self::class, 'tab' ) );
		add_action( 'woocommerce_product_data_panels', array( self::class, 'panel' ) );
		add_action( 'woocommerce_process_product_meta', array( self::class, 'save_product' ) );
	}

	/* ---------- mapping ---------- */

	/** @return int[] */
	public static function courses_of_product( int $product_id ): array {
		return array_values( array_filter( array_map( 'absint', (array) get_post_meta( $product_id, '_educore_course_id', false ) ) ) );
	}

	public static function set_product_courses( int $product_id, array $course_ids, int $access_days = 0, int $trial_days = 0 ): void {
		$course_ids = array_values( array_unique( array_filter( array_map( 'absint', $course_ids ), array( Content::class, 'is_course' ) ) ) );
		delete_post_meta( $product_id, '_educore_course_id' );
		foreach ( $course_ids as $c ) {
			add_post_meta( $product_id, '_educore_course_id', $c );
		}
		update_post_meta( $product_id, '_educore_course_ids', $course_ids );
		update_post_meta( $product_id, '_educore_access_days', max( 0, $access_days ) );
		update_post_meta( $product_id, '_educore_trial_days', max( 0, $trial_days ) );
	}

	/** Purchasable products for a course (lowest price first), trial products included. @return \WC_Product[] */
	public static function all_products_for_course( int $course_id ): array {
		if ( ! Plugin::woo_active() ) {
			return array();
		}
		$ids = get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 20, 'fields' => 'ids', 'meta_key' => '_educore_course_id', 'meta_value' => $course_id ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$out = array();
		foreach ( $ids as $id ) {
			$p = wc_get_product( $id );
			if ( $p && $p->is_purchasable() ) {
				$out[] = $p;
			}
		}
		usort( $out, static fn( $a, $b ) => (float) $a->get_price() <=> (float) $b->get_price() );
		return $out;
	}

	public static function is_trial_product( \WC_Product $p ): bool {
		return (int) get_post_meta( $p->get_id(), '_educore_trial_days', true ) > 0 && 0.0 === (float) $p->get_price();
	}

	/** Access products (trials excluded), lowest price first. @return \WC_Product[] */
	public static function products_for_course( int $course_id ): array {
		return array_values( array_filter( self::all_products_for_course( $course_id ), static fn( $p ) => ! self::is_trial_product( $p ) ) );
	}

	public static function trial_for_course( int $course_id ): ?\WC_Product {
		foreach ( self::all_products_for_course( $course_id ) as $p ) {
			if ( self::is_trial_product( $p ) ) {
				return $p;
			}
		}
		return null;
	}

	/* ---------- order lifecycle ---------- */

	/** @param \WC_Order $order */
	public static function status_changed( $order_id, $from, $to, $order = null ): void {
		$order = $order ?: wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		if ( in_array( $to, self::PAID_STATUSES, true ) && $order->is_paid() ) {
			self::grant_order( $order );
		} elseif ( isset( self::REVOKE_STATUSES[ $to ] ) ) {
			Entitlements::revoke_order( (int) $order->get_id(), self::REVOKE_STATUSES[ $to ] );
		}
	}

	/** @param \WC_Order $order */
	public static function grant_order( $order ): int {
		$user_id = (int) $order->get_customer_id();
		if ( ! $user_id ) {
			$order->add_order_note( __( 'EduCore: guest order — no course access granted. Ask the customer to purchase while logged in, or enroll them manually.', 'educore-commerce' ) );
			Audit::log( 'commerce.guest_order', 'order', (int) $order->get_id() );
			return 0;
		}
		$n = 0;
		foreach ( $order->get_items() as $item ) {
			$product_id = (int) ( $item->get_variation_id() ?: $item->get_product_id() );
			$parent_id  = (int) $item->get_product_id();
			$courses    = self::courses_of_product( $product_id ) ?: self::courses_of_product( $parent_id );
			$meta_from  = self::courses_of_product( $product_id ) ? $product_id : $parent_id;
			$days       = (int) get_post_meta( $meta_from, '_educore_access_days', true );
			$trial      = (int) get_post_meta( $meta_from, '_educore_trial_days', true );
			$is_trial   = $trial > 0 && 0.0 === (float) $item->get_total();
			foreach ( $courses as $course_id ) {
				if ( $is_trial && Entitlements::used_trial( $user_id, $course_id ) ) {
					$order->add_order_note( sprintf( /* translators: %d course id */ __( 'EduCore: trial for course #%d already used by this customer; not granted.', 'educore-commerce' ), $course_id ) );
					continue;
				}
				$len  = $is_trial ? $trial : $days;
				$ends = $len > 0 ? gmdate( 'Y-m-d H:i:s', time() + $len * DAY_IN_SECONDS ) : null;
				Entitlements::grant( $user_id, $course_id, (int) $order->get_id(), $meta_from, $ends, $is_trial ? 'trial' : 'order' );
				++$n;
			}
		}
		return $n;
	}

	/* ---------- catalogue / CTA ---------- */

	public static function card( array $data, \WP_Post $post ): array {
		if ( 'paid' !== $data['enroll_mode'] ) {
			return $data;
		}
		$products = self::products_for_course( $post->ID );
		if ( $products ) {
			$data['price_label'] = html_entity_decode( wp_strip_all_tags( wc_price( (float) $products[0]->get_price() ) ), ENT_QUOTES, 'UTF-8' );
		} elseif ( self::trial_for_course( $post->ID ) ) {
			$data['price_label'] = __( 'Free trial', 'educore-commerce' );
		} else {
			$data['price_label'] = __( 'Not available', 'educore-commerce' );
		}
		return $data;
	}

	public static function cta( string $html, int $course_id, int $user_id ): string {
		if ( ! Gate::is_paid( $course_id ) ) {
			return $html;
		}
		$products = self::products_for_course( $course_id );
		$trial    = self::trial_for_course( $course_id );
		if ( ! $products && ! $trial ) {
			return '<p class="ec-muted">' . esc_html__( 'This course is not available for purchase right now.', 'educore-commerce' ) . '</p>';
		}
		$out = '';
		if ( $products ) {
			$p     = $products[0];
			$price = html_entity_decode( wp_strip_all_tags( wc_price( (float) $p->get_price() ) ), ENT_QUOTES, 'UTF-8' );
			$days  = (int) get_post_meta( $p->get_id(), '_educore_access_days', true );
			if ( $user_id ) {
				/* translators: %s: price */
				$out .= '<a class="ec-btn ec-btn--primary" href="' . esc_url( $p->add_to_cart_url() ) . '" rel="nofollow">' . esc_html( sprintf( __( 'Buy access — %s', 'educore-commerce' ), $price ) ) . '</a>';
			} else {
				/* translators: %s: price */
				$out .= '<p class="ec-price"><strong>' . esc_html( sprintf( __( 'Price: %s', 'educore-commerce' ), $price ) ) . '</strong></p>';
				$out .= '<a class="ec-btn ec-btn--primary" href="' . esc_url( wp_login_url( get_permalink( $course_id ) ) ) . '">' . esc_html__( 'Log in to buy access', 'educore-commerce' ) . '</a>';
			}
			if ( $days ) {
				/* translators: %d: days */
				$out .= '<p class="ec-muted">' . esc_html( sprintf( _n( 'Access for %d day', 'Access for %d days', $days, 'educore-commerce' ), $days ) ) . '</p>';
			}
		}
		if ( $trial && ( ! $user_id || ! Entitlements::used_trial( $user_id, $course_id ) ) ) {
			$len   = (int) get_post_meta( $trial->get_id(), '_educore_trial_days', true );
			$href  = $user_id ? $trial->add_to_cart_url() : wp_login_url( get_permalink( $course_id ) );
			$class = $products ? 'ec-btn ec-btn--ghost' : 'ec-btn ec-btn--primary';
			/* translators: %d: trial length in days */
			$out .= ' <a class="' . $class . '" href="' . esc_url( $href ) . '" rel="nofollow">' . esc_html( sprintf( _n( 'Start a free %d-day trial', 'Start a free %d-day trial', $len, 'educore-commerce' ), $len ) ) . '</a>';
		} elseif ( ! $products ) {
			return '<p class="ec-muted">' . esc_html__( 'Your free trial has been used. This course is not available for purchase right now.', 'educore-commerce' ) . '</p>';
		}
		return $out;
	}

	/* ---------- product admin ---------- */

	public static function tab( array $tabs ): array {
		$tabs['educore'] = array( 'label' => __( 'EduCore access', 'educore-commerce' ), 'target' => 'educore_product_data', 'class' => array(), 'priority' => 70 );
		return $tabs;
	}

	public static function panel(): void {
		global $post;
		$selected = (array) get_post_meta( $post->ID, '_educore_course_ids', true );
		echo '<div id="educore_product_data" class="panel woocommerce_options_panel"><div class="options_group">';
		wp_nonce_field( 'educore_product_' . $post->ID, '_educore_product_nonce' );
		echo '<p class="form-field"><label for="educore_course_ids">' . esc_html__( 'Courses unlocked', 'educore-commerce' ) . '</label><select id="educore_course_ids" name="educore_course_ids[]" multiple style="min-width:60%;min-height:120px">';
		foreach ( get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft' ), 'posts_per_page' => 500 ) ) as $c ) {
			echo '<option value="' . esc_attr( (string) $c->ID ) . '"' . selected( in_array( $c->ID, array_map( 'intval', $selected ), true ), true, false ) . '>' . esc_html( $c->post_title ) . '</option>';
		}
		echo '</select></p>';
		woocommerce_wp_text_input( array( 'id' => '_educore_access_days', 'label' => __( 'Access length (days)', 'educore-commerce' ), 'description' => __( '0 = lifetime access. Use 30 for a monthly plan, 365 for an annual plan.', 'educore-commerce' ), 'desc_tip' => true, 'type' => 'number', 'custom_attributes' => array( 'min' => 0 ) ) );
		woocommerce_wp_text_input( array( 'id' => '_educore_trial_days', 'label' => __( 'Trial length (days)', 'educore-commerce' ), 'description' => __( 'Only for a zero-price trial product; each learner can use one trial per course.', 'educore-commerce' ), 'desc_tip' => true, 'type' => 'number', 'custom_attributes' => array( 'min' => 0 ) ) );
		echo '<p class="description" style="padding:0 12px">' . esc_html__( 'Remember to set each linked course’s Enrollment option to “Paid”.', 'educore-commerce' ) . '</p></div></div>';
	}

	public static function save_product( int $product_id ): void {
		if ( ! isset( $_POST['_educore_product_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_educore_product_nonce'] ) ), 'educore_product_' . $product_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_product', $product_id ) || ! current_user_can( 'ec_manage_commerce' ) ) {
			return;
		}
		$courses = isset( $_POST['educore_course_ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['educore_course_ids'] ) ) : array();
		self::set_product_courses( $product_id, $courses, isset( $_POST['_educore_access_days'] ) ? absint( $_POST['_educore_access_days'] ) : 0, isset( $_POST['_educore_trial_days'] ) ? absint( $_POST['_educore_trial_days'] ) : 0 );
		Audit::log( 'commerce.product_mapped', 'product', $product_id, array( 'courses' => $courses ) );
	}
}
