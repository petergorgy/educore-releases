<?php
namespace EduCore\Commerce;

use EduCore\Core\Registry;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	private static bool $booted = false;

	public static function tables(): array {
		return array(
			'entitlements' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				course_id BIGINT UNSIGNED NOT NULL,
				order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				product_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				starts_at DATETIME NOT NULL,
				ends_at DATETIME NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				source VARCHAR(20) NOT NULL DEFAULT 'order',
				notified_at DATETIME NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY order_product_course (order_id,product_id,course_id,user_id),
				KEY user_course_status (user_id,course_id,status),
				KEY status_ends (status,ends_at)",
		);
	}

	public static function install(): void {
		Schema::migrate( 'educore_commerce_db_version', EDUCORE_COMMERCE_DB_VERSION, self::tables() );
	}

	public static function woo_active(): bool {
		return class_exists( '\WooCommerce' ) && function_exists( 'wc_get_order' );
	}

	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;
		Registry::register( 'commerce', EDUCORE_COMMERCE_VERSION );
		self::install();
		add_action( 'educore/install/repair', static function () {
			delete_option( 'educore_commerce_db_version' );
			self::install();
		} );
		add_action( 'init', static fn() => load_plugin_textdomain( 'educore-commerce', false, dirname( plugin_basename( EDUCORE_COMMERCE_FILE ) ) . '/languages' ) );

		Gate::register();
		Entitlements::register();
		Block::register();
		Woo::register();
		Subscriptions::register();
		add_action( 'admin_notices', array( self::class, 'notice' ) );
		add_filter( 'educore/privacy/export', array( self::class, 'export' ), 10, 2 );
	}

	/**
	 * Personal-data export: course access periods. Orders and billing data are exported by WooCommerce's own exporter.
	 * Erasure: access records are retained with the order they belong to (accounting evidence); WooCommerce's order
	 * retention settings govern the orders.
	 *
	 * @param array<int,array<string,mixed>> $data
	 * @param \WP_User|false                 $user
	 */
	public static function export( array $data, $user ): array {
		if ( ! $user ) {
			return $data;
		}
		foreach ( Entitlements::for_user( (int) $user->ID ) as $row ) {
			$items = array(
				array( 'name' => __( 'Course', 'educore-commerce' ), 'value' => get_the_title( (int) $row['course_id'] ) ),
				array( 'name' => __( 'Order', 'educore-commerce' ), 'value' => (string) $row['order_id'] ),
				array( 'name' => __( 'Status', 'educore-commerce' ), 'value' => (string) $row['status'] ),
				array( 'name' => __( 'Source', 'educore-commerce' ), 'value' => (string) $row['source'] ),
				array( 'name' => __( 'Access from', 'educore-commerce' ), 'value' => (string) $row['starts_at'] ),
				array( 'name' => __( 'Access until', 'educore-commerce' ), 'value' => $row['ends_at'] ? (string) $row['ends_at'] : __( 'Lifetime', 'educore-commerce' ) ),
			);
			$data[] = array( 'group_id' => 'educore-commerce', 'group_label' => __( 'Course access (purchases)', 'educore-commerce' ), 'item_id' => 'entitlement-' . $row['id'], 'data' => $items );
		}
		return $data;
	}

	public static function notice(): void {
		if ( ! self::woo_active() && current_user_can( 'ec_manage_commerce' ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'EduCore Commerce: WooCommerce is not active. Paid courses cannot be purchased; free courses and existing access keep working.', 'educore-commerce' ) . '</p></div>';
		}
	}
}
