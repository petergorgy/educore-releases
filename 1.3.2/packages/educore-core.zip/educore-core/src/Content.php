<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Course / Unit / Lesson content types, statuses, hierarchy and metadata.
 */
final class Content {
	public const COURSE = 'ec_course';
	public const UNIT   = 'ec_unit';
	public const LESSON = 'ec_lesson';

	public const COMPLETION_RULES = array( 'manual', 'view', 'time' );

	public static function register(): void {
		add_action( 'init', array( self::class, 'register_types' ), 5 );
		add_action( 'save_post', array( self::class, 'on_save' ), 20, 2 );
		add_action( 'add_meta_boxes', array( self::class, 'meta_boxes' ) );
		add_action( 'before_delete_post', array( self::class, 'on_delete' ) );
		add_filter( 'display_post_states', array( self::class, 'post_states' ), 10, 2 );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action(
				$hook,
				static function ( $mid, $object_id, $key ) {
					if ( in_array( $key, array( '_ec_course_id', '_ec_unit_id' ), true ) ) {
						self::flush_cache();
					}
				},
				10,
				3
			);
		}
		add_action( 'transition_post_status', array( self::class, 'flush_cache' ) );
	}

	public static function register_types(): void {
		$common = array(
			'public'          => true,
			'show_in_rest'    => true,
			'capability_type' => array( 'ec_course', 'ec_courses' ),
			'map_meta_cap'    => true,
			'show_in_menu'    => 'educore',
			'supports'        => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'page-attributes', 'author', 'custom-fields' ),
		);
		register_post_type(
			self::COURSE,
			array_merge(
				$common,
				array(
					'labels'      => self::labels( __( 'Courses', 'educore-core' ), __( 'Course', 'educore-core' ) ),
					'has_archive' => 'courses',
					'rewrite'     => array( 'slug' => 'course', 'with_front' => false ),
					'menu_icon'   => 'dashicons-welcome-learn-more',
				)
			)
		);
		register_post_type(
			self::UNIT,
			array_merge(
				$common,
				array(
					'labels'             => self::labels( __( 'Units', 'educore-core' ), __( 'Unit', 'educore-core' ) ),
					'publicly_queryable' => false,
					'rewrite'            => false,
				)
			)
		);
		register_post_type(
			self::LESSON,
			array_merge(
				$common,
				array(
					'labels'              => self::labels( __( 'Lessons', 'educore-core' ), __( 'Lesson', 'educore-core' ) ),
					'rewrite'             => array( 'slug' => 'lesson', 'with_front' => false ),
					'exclude_from_search' => true,
				)
			)
		);
		register_post_status(
			'ec_archived',
			array(
				'label'                     => _x( 'Archived', 'post status', 'educore-core' ),
				'public'                    => false,
				'internal'                  => false,
				'protected'                 => true,
				'show_in_admin_all_list'    => false,
				'show_in_admin_status_list' => true,
				/* translators: %s: count */
				'label_count'               => _n_noop( 'Archived <span class="count">(%s)</span>', 'Archived <span class="count">(%s)</span>', 'educore-core' ),
			)
		);
		foreach ( array( self::COURSE, self::UNIT, self::LESSON ) as $type ) {
			foreach ( self::meta_schema( $type ) as $key => $schema ) {
				register_post_meta(
					$type,
					$key,
					array(
						'type'              => $schema[0],
						'single'            => true,
						'show_in_rest'      => true,
						'default'           => $schema[1],
						'sanitize_callback' => $schema[2],
						'auth_callback'     => static fn( $allowed, $meta_key, $post_id ) => current_user_can( 'edit_post', $post_id ),
					)
				);
			}
		}
	}

	/** @return array<string,array{0:string,1:mixed,2:callable}> */
	public static function meta_schema( string $type ): array {
		$text = 'sanitize_textarea_field';
		$int  = 'absint';
		switch ( $type ) {
			case self::COURSE:
				return array(
					'_ec_difficulty'     => array( 'string', 'beginner', array( self::class, 'sanitize_difficulty' ) ),
					'_ec_grade_level'    => array( 'string', '', 'sanitize_text_field' ),
					'_ec_duration_hours' => array( 'integer', 0, $int ),
					'_ec_objectives'     => array( 'string', '', $text ),
					'_ec_prerequisites'  => array( 'string', '', $text ),
					'_ec_assessment_req' => array( 'string', '', $text ),
					'_ec_enroll_mode'    => array( 'string', 'open', array( self::class, 'sanitize_enroll_mode' ) ),
					'_ec_lang'           => array( 'string', 'en', array( I18n::class, 'sanitize_lang' ) ),
				);
			case self::UNIT:
				return array(
					'_ec_course_id' => array( 'integer', 0, $int ),
				);
			case self::LESSON:
				return array(
					'_ec_unit_id'         => array( 'integer', 0, $int ),
					'_ec_course_id'       => array( 'integer', 0, $int ),
					'_ec_minutes'         => array( 'integer', 0, $int ),
					'_ec_objectives'      => array( 'string', '', $text ),
					'_ec_summary'         => array( 'string', '', $text ),
					'_ec_completion_rule' => array( 'string', 'manual', array( self::class, 'sanitize_rule' ) ),
					'_ec_completion_secs' => array( 'integer', 0, $int ),
					'_ec_lang'            => array( 'string', 'en', array( I18n::class, 'sanitize_lang' ) ),
				);
		}
		return array();
	}

	public static function sanitize_difficulty( $v ): string {
		return in_array( $v, array( 'beginner', 'intermediate', 'advanced' ), true ) ? $v : 'beginner';
	}

	public static function sanitize_enroll_mode( $v ): string {
		return in_array( $v, array( 'open', 'closed', 'paid' ), true ) ? $v : 'open';
	}

	public static function sanitize_rule( $v ): string {
		/** Other packages (assessments) may register additional rule types. */
		$allowed = apply_filters( 'educore/progress/completion_rules', self::COMPLETION_RULES );
		return in_array( $v, (array) $allowed, true ) ? $v : 'manual';
	}

	private static function labels( string $plural, string $singular ): array {
		return array(
			'name'          => $plural,
			'singular_name' => $singular,
			/* translators: %s: item type */
			'add_new_item'  => sprintf( __( 'Add new %s', 'educore-core' ), $singular ),
			/* translators: %s: item type */
			'edit_item'     => sprintf( __( 'Edit %s', 'educore-core' ), $singular ),
			'all_items'     => $plural,
		);
	}

	public static function is_content_type( string $type ): bool {
		return in_array( $type, array( self::COURSE, self::UNIT, self::LESSON ), true );
	}

	public static function is_course( int $id ): bool {
		return $id > 0 && get_post_type( $id ) === self::COURSE;
	}

	public static function course_of( int $post_id ): int {
		$type = get_post_type( $post_id );
		if ( self::COURSE === $type ) {
			return $post_id;
		}
		if ( self::UNIT === $type || self::LESSON === $type ) {
			return (int) get_post_meta( $post_id, '_ec_course_id', true );
		}
		return 0;
	}

	/** @return \WP_Post[] */
	public static function units( int $course_id, array $statuses = array( 'publish' ) ): array {
		return get_posts(
			array(
				'post_type'        => self::UNIT,
				'post_status'      => $statuses,
				'posts_per_page'   => 200,
				'meta_key'         => '_ec_course_id', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'       => $course_id, // phpcs:ignore WordPress.DB.SlowDBQuery
				'orderby'          => array( 'menu_order' => 'ASC', 'ID' => 'ASC' ),
				'suppress_filters' => false,
			)
		);
	}

	/** @return \WP_Post[] */
	public static function lessons_of_unit( int $unit_id, array $statuses = array( 'publish' ) ): array {
		return get_posts(
			array(
				'post_type'      => self::LESSON,
				'post_status'    => $statuses,
				'posts_per_page' => 500,
				'meta_key'       => '_ec_unit_id', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $unit_id, // phpcs:ignore WordPress.DB.SlowDBQuery
				'orderby'        => array( 'menu_order' => 'ASC', 'ID' => 'ASC' ),
			)
		);
	}

	/**
	 * Ordered curriculum: [ [unit=>WP_Post, lessons=>WP_Post[]], ... ]
	 */
	public static function outline( int $course_id, array $statuses = array( 'publish' ) ): array {
		$out = array();
		foreach ( self::units( $course_id, $statuses ) as $unit ) {
			$out[] = array( 'unit' => $unit, 'lessons' => self::lessons_of_unit( $unit->ID, $statuses ) );
		}
		return $out;
	}

	/** @var array<int,int[]> per-request cache of published lesson ids per course */
	private static array $lesson_cache = array();

	public static function flush_cache(): void {
		self::$lesson_cache = array();
	}

	/** @return int[] ordered published lesson ids of a course (cached per request; flushed on content save/delete) */
	public static function lesson_ids( int $course_id ): array {
		if ( isset( self::$lesson_cache[ $course_id ] ) ) {
			return self::$lesson_cache[ $course_id ];
		}
		$ids = array();
		foreach ( self::outline( $course_id ) as $row ) {
			foreach ( $row['lessons'] as $l ) {
				$ids[] = (int) $l->ID;
			}
		}
		return self::$lesson_cache[ $course_id ] = $ids;
	}

	/** @return array{prev:int,next:int} */
	public static function neighbours( int $lesson_id ): array {
		$ids = self::lesson_ids( self::course_of( $lesson_id ) );
		$i   = array_search( $lesson_id, $ids, true );
		if ( false === $i ) {
			return array( 'prev' => 0, 'next' => 0 );
		}
		return array( 'prev' => $ids[ $i - 1 ] ?? 0, 'next' => $ids[ $i + 1 ] ?? 0 );
	}

	/** Keep hierarchy metadata consistent; staff the creator; refresh search index. */
	public static function on_save( int $post_id, \WP_Post $post ): void {
		if ( wp_is_post_revision( $post_id ) || ! self::is_content_type( $post->post_type ) ) {
			return;
		}
		self::flush_cache();
		if ( self::LESSON === $post->post_type ) {
			$unit = (int) get_post_meta( $post_id, '_ec_unit_id', true );
			if ( $unit && get_post_type( $unit ) === self::UNIT ) {
				update_post_meta( $post_id, '_ec_course_id', (int) get_post_meta( $unit, '_ec_course_id', true ) );
			}
		}
		if ( self::COURSE === $post->post_type && 'auto-draft' !== $post->post_status ) {
			$author = (int) $post->post_author;
			if ( $author && ! user_can( $author, 'ec_manage_all_courses' ) && user_can( $author, 'ec_edit_assigned_courses' ) && ! Staff::role_of( $author, $post_id ) ) {
				Staff::assign( $post_id, $author, 'lead' );
			}
		}
		Search::index_post( $post );
		if ( 'publish' === $post->post_status ) {
			Audit::log( 'content.saved', $post->post_type, $post_id, array( 'status' => $post->post_status ) );
		}
	}

	public static function on_delete( int $post_id ): void {
		self::flush_cache();
		if ( self::is_content_type( (string) get_post_type( $post_id ) ) ) {
			Search::remove( $post_id );
			Audit::log( 'content.deleted', (string) get_post_type( $post_id ), $post_id );
		}
	}

	/** @param array<string,string> $states */
	public static function post_states( array $states, \WP_Post $post ): array {
		if ( 'ec_archived' === $post->post_status ) {
			$states['ec_archived'] = __( 'Archived', 'educore-core' );
		}
		return $states;
	}

	/** Duplicate a course with its units and lessons (as drafts). Returns new course id. */
	public static function duplicate_course( int $course_id, int $user_id ): int {
		$src = get_post( $course_id );
		if ( ! $src || self::COURSE !== $src->post_type ) {
			return 0;
		}
		$new_id = self::copy_post( $src, $user_id, 0 );
		Staff::assign( $new_id, $user_id, 'lead' );
		foreach ( self::outline( $course_id, array( 'publish', 'draft', 'pending', 'future' ) ) as $row ) {
			$unit_id = self::copy_post( $row['unit'], $user_id, $new_id );
			update_post_meta( $unit_id, '_ec_course_id', $new_id );
			foreach ( $row['lessons'] as $lesson ) {
				$lid = self::copy_post( $lesson, $user_id, $unit_id );
				update_post_meta( $lid, '_ec_unit_id', $unit_id );
				update_post_meta( $lid, '_ec_course_id', $new_id );
			}
		}
		Audit::log( 'course.duplicated', 'course', $new_id, array( 'source' => $course_id ) );
		return $new_id;
	}

	private static function copy_post( \WP_Post $src, int $user_id, int $parent ): int {
		$id = wp_insert_post(
			array(
				'post_type'    => $src->post_type,
				'post_status'  => 'draft',
				'post_title'   => $src->post_title . ( self::COURSE === $src->post_type ? ' ' . __( '(copy)', 'educore-core' ) : '' ),
				'post_content' => $src->post_content,
				'post_excerpt' => $src->post_excerpt,
				'menu_order'   => $src->menu_order,
				'post_parent'  => $parent,
				'post_author'  => $user_id,
			)
		);
		foreach ( array_keys( self::meta_schema( $src->post_type ) ) as $key ) {
			update_post_meta( $id, $key, get_post_meta( $src->ID, $key, true ) );
		}
		return (int) $id;
	}

	/** Reorder: $ids in the desired order. Returns count updated. */
	public static function reorder( array $ids ): int {
		$n = 0;
		foreach ( array_values( $ids ) as $pos => $id ) {
			$id = (int) $id;
			if ( $id && current_user_can( 'edit_post', $id ) ) {
				wp_update_post( array( 'ID' => $id, 'menu_order' => $pos ) );
				self::flush_cache();
				++$n;
			}
		}
		return $n;
	}

	public static function meta_boxes(): void {
		add_meta_box( 'ec_course_details', __( 'Course details', 'educore-core' ), array( Admin\MetaBoxes::class, 'course' ), self::COURSE, 'normal' );
		add_meta_box( 'ec_unit_course', __( 'Course', 'educore-core' ), array( Admin\MetaBoxes::class, 'unit' ), self::UNIT, 'side' );
		add_meta_box( 'ec_lesson_details', __( 'Lesson settings', 'educore-core' ), array( Admin\MetaBoxes::class, 'lesson' ), self::LESSON, 'normal' );
	}
}
