<?php
namespace EduCore\Commerce;

defined( 'ABSPATH' ) || exit;

/** educore/payment-history: the signed-in customer's own orders and course access periods. */
final class Block {

	public static function register(): void {
		add_filter(
			'educore/blocks',
			static function ( array $blocks ) {
				$blocks['payment-history'] = array( 'title' => __( 'EduCore: Payment history', 'educore-commerce' ), 'render' => array( self::class, 'render' ) );
				return $blocks;
			}
		);
	}

	public static function render(): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return '<p class="ec-muted">' . esc_html__( 'Log in to see your payments.', 'educore-commerce' ) . '</p>';
		}
		$out = '<div class="ec-payments">';
		if ( Plugin::woo_active() ) {
			$orders = wc_get_orders( array( 'customer_id' => $uid, 'limit' => 50, 'orderby' => 'date', 'order' => 'DESC' ) );
			$out   .= '<h2>' . esc_html__( 'Orders', 'educore-commerce' ) . '</h2>';
			if ( ! $orders ) {
				$out .= '<p class="ec-muted">' . esc_html__( 'No payments yet.', 'educore-commerce' ) . '</p>';
			} else {
				$out .= '<div class="ec-table-wrap"><table class="ec-table"><thead><tr><th scope="col">' . esc_html__( 'Order', 'educore-commerce' ) . '</th><th scope="col">' . esc_html__( 'Date', 'educore-commerce' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-commerce' ) . '</th><th scope="col">' . esc_html__( 'Items', 'educore-commerce' ) . '</th><th scope="col">' . esc_html__( 'Total', 'educore-commerce' ) . '</th></tr></thead><tbody>';
				foreach ( $orders as $o ) {
					if ( (int) $o->get_customer_id() !== $uid ) {
						continue; // Defence in depth.
					}
					$items = implode( ', ', array_map( static fn( $i ) => $i->get_name(), $o->get_items() ) );
					$out  .= '<tr><td><a href="' . esc_url( $o->get_view_order_url() ) . '">#' . esc_html( $o->get_order_number() ) . '</a></td><td>' . esc_html( $o->get_date_created() ? $o->get_date_created()->date_i18n( get_option( 'date_format' ) ) : '' ) . '</td><td>' . esc_html( wc_get_order_status_name( $o->get_status() ) ) . '</td><td>' . esc_html( $items ) . '</td><td>' . wp_kses_post( $o->get_formatted_order_total() ) . '</td></tr>';
				}
				$out .= '</tbody></table></div>';
			}
		}
		$ents = Entitlements::for_user( $uid );
		if ( $ents ) {
			$labels = array( 'active' => __( 'Active', 'educore-commerce' ), 'expired' => __( 'Expired', 'educore-commerce' ), 'cancelled' => __( 'Cancelled', 'educore-commerce' ), 'refunded' => __( 'Refunded', 'educore-commerce' ) );
			$out   .= '<h2>' . esc_html__( 'Course access', 'educore-commerce' ) . '</h2><div class="ec-table-wrap"><table class="ec-table"><thead><tr><th scope="col">' . esc_html__( 'Course', 'educore-commerce' ) . '</th><th scope="col">' . esc_html__( 'Status', 'educore-commerce' ) . '</th><th scope="col">' . esc_html__( 'Access until', 'educore-commerce' ) . '</th></tr></thead><tbody>';
			foreach ( $ents as $e ) {
				$until = $e['ends_at'] ? date_i18n( get_option( 'date_format' ), strtotime( $e['ends_at'] . ' UTC' ) ) : __( 'Lifetime', 'educore-commerce' );
				$out  .= '<tr><td>' . esc_html( get_the_title( (int) $e['course_id'] ) ) . '</td><td>' . esc_html( $labels[ $e['status'] ] ?? $e['status'] ) . '</td><td>' . esc_html( $until ) . '</td></tr>';
			}
			$out .= '</tbody></table></div>';
		}
		return $out . '</div>';
	}
}
