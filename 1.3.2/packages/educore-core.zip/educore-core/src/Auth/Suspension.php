<?php
namespace EduCore\Core\Auth;

use EduCore\Core\Audit;

defined( 'ABSPATH' ) || exit;

/**
 * Account suspension: a suspended user cannot sign in (password or application password) and loses all
 * open sessions immediately. The data stays intact; reactivation is one checkbox. Administrators cannot
 * suspend themselves (no lock-out of the last recovery path).
 */
final class Suspension {
	public const META = 'educore_suspended';

	public static function register(): void {
		add_filter( 'authenticate', array( self::class, 'block' ), 99 );
		add_action( 'wp_authenticate_application_password_errors', array( self::class, 'block_app_password' ), 10, 2 );
		add_action( 'edit_user_profile', array( self::class, 'field' ) );
		add_action( 'edit_user_profile_update', array( self::class, 'save' ) );
	}

	public static function is_suspended( int $user_id ): bool {
		return (bool) get_user_meta( $user_id, self::META, true );
	}

	public static function message(): string {
		return __( 'This account is not available. Please contact your school or the EduCore support team.', 'educore-core' );
	}

	public static function block( $user ) {
		if ( $user instanceof \WP_User && self::is_suspended( $user->ID ) ) {
			Audit::log( 'security.login_suspended', 'user', $user->ID );
			return new \WP_Error( 'educore_suspended', self::message() );
		}
		return $user;
	}

	public static function block_app_password( \WP_Error $error, \WP_User $user ): void {
		if ( self::is_suspended( $user->ID ) ) {
			$error->add( 'educore_suspended', self::message() );
		}
	}

	public static function set( int $user_id, bool $suspended ): bool {
		if ( $user_id === get_current_user_id() && $suspended ) {
			return false;
		}
		if ( $suspended ) {
			update_user_meta( $user_id, self::META, gmdate( 'c' ) . ' by ' . get_current_user_id() );
			\WP_Session_Tokens::get_instance( $user_id )->destroy_all();
		} else {
			delete_user_meta( $user_id, self::META );
		}
		Audit::log( $suspended ? 'user.suspended' : 'user.reactivated', 'user', $user_id );
		return true;
	}

	public static function field( \WP_User $user ): void {
		if ( ! current_user_can( 'edit_users' ) || $user->ID === get_current_user_id() ) {
			return;
		}
		wp_nonce_field( 'educore_suspend_' . $user->ID, '_ecsuspend' );
		echo '<h2>' . esc_html__( 'EduCore access', 'educore-core' ) . '</h2><table class="form-table" role="presentation"><tr><th scope="row">' . esc_html__( 'Account status', 'educore-core' ) . '</th><td><label><input type="checkbox" name="educore_suspended" value="1"' . checked( self::is_suspended( $user->ID ), true, false ) . '> ' . esc_html__( 'Suspend this account (signs the user out everywhere and blocks sign-in; no data is deleted)', 'educore-core' ) . '</label></td></tr></table>';
	}

	public static function save( int $user_id ): void {
		if ( ! current_user_can( 'edit_users' ) || ! isset( $_POST['_ecsuspend'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_ecsuspend'] ) ), 'educore_suspend_' . $user_id ) ) {
			return;
		}
		$want = ! empty( $_POST['educore_suspended'] );
		if ( $want !== self::is_suspended( $user_id ) ) {
			self::set( $user_id, $want );
		}
	}
}
