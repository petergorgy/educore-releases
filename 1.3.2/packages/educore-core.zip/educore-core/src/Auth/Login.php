<?php
namespace EduCore\Core\Auth;

use EduCore\Core\Audit;
use EduCore\Core\Branding;
use EduCore\Core\I18n;
use EduCore\Core\Pages;
use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/**
 * Branded EduCore sign-in experience on top of the standard WordPress login (wp-login.php).
 *
 * Only supported hooks are used: WordPress still processes every credential, cookie, nonce, password reset,
 * interim (session-expired) login, application password and security/2FA plugin step. EduCore adds the
 * identity, the layout, translations, safer messages and a rate limit on password-reset requests.
 */
final class Login {

	public static function register(): void {
		add_action( 'login_enqueue_scripts', array( self::class, 'assets' ) );
		add_filter( 'login_headerurl', static fn() => home_url( '/' ) );
		add_filter( 'login_headertext', array( Branding::class, 'name' ) );
		add_filter( 'login_title', array( self::class, 'title' ), 10, 2 );
		add_filter( 'login_body_class', array( self::class, 'body_class' ), 10, 2 );
		add_action( 'login_header', array( self::class, 'brand_panel' ) );
		add_filter( 'login_message', array( self::class, 'message' ) );
		add_filter( 'wp_login_errors', array( self::class, 'errors' ) );
		add_filter( 'login_site_html_link', array( self::class, 'back_link' ) );
		add_filter( 'language_attributes', array( self::class, 'language_attributes' ) );
		add_action( 'login_footer', array( self::class, 'footer' ) );
		add_action( 'lostpassword_post', array( self::class, 'lostpassword' ), 10, 2 );
		add_action( 'wp_mail_failed', array( self::class, 'reset_mail_failed' ) );
		add_action( 'login_form_logout', array( self::class, 'logout_confirmation' ) );
		add_action( 'login_form_register', array( self::class, 'register_redirect' ) );
		add_filter( 'register_url', array( self::class, 'register_url' ) );
		add_filter( 'gettext', array( self::class, 'core_strings' ), 10, 3 );
	}

	private static function on_login_screen(): bool {
		return did_action( 'login_init' ) > 0;
	}

	private static function action(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- routing only.
		return isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : 'login';
	}

	public static function assets(): void {
		wp_enqueue_style( 'educore-auth', plugins_url( 'assets/css/auth.css', EDUCORE_CORE_FILE ), array( 'login' ), EDUCORE_CORE_VERSION );
		wp_enqueue_script( 'educore-auth', plugins_url( 'assets/js/auth.js', EDUCORE_CORE_FILE ), array(), EDUCORE_CORE_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script(
			'educore-auth',
			'educoreAuth',
			array(
				'signingIn' => __( 'Signing in…', 'educore-core' ),
				'sending'   => __( 'Sending…', 'educore-core' ),
				'saving'    => __( 'Saving…', 'educore-core' ),
			)
		);
		$fonts = plugins_url( 'assets/fonts/', EDUCORE_CORE_FILE );
		$css   = '';
		foreach ( array( 400, 600, 700 ) as $w ) {
			$css .= "@font-face{font-family:'IBM Plex Sans';font-weight:{$w};font-display:swap;src:url({$fonts}ibm-plex-sans-latin-{$w}-normal.woff2) format('woff2')}";
			$css .= "@font-face{font-family:'IBM Plex Sans Arabic';font-weight:{$w};font-display:swap;src:url({$fonts}ibm-plex-sans-arabic-arabic-{$w}-normal.woff2) format('woff2')}";
		}
		wp_add_inline_style( 'educore-auth', $css );
	}

	public static function title( $title, $reason ) {
		return ( $reason ? $reason : __( 'Sign in', 'educore-core' ) ) . ' ‹ ' . Branding::name();
	}

	public static function body_class( array $classes, $action ): array {
		$classes[] = 'ec-auth';
		$classes[] = 'ec-auth--' . sanitize_html_class( (string) $action );
		if ( I18n::is_rtl() ) {
			$classes[] = 'ec-rtl';
		}
		return $classes;
	}

	/** wp-login.php prints <html> with language_attributes(): make Arabic RTL even without a WordPress core language pack. */
	public static function language_attributes( $output ) {
		if ( ! self::on_login_screen() && ! did_action( 'login_enqueue_scripts' ) ) {
			return $output;
		}
		$lang = str_replace( '_', '-', I18n::LANGS[ I18n::current() ] ?? 'en-US' );
		return 'dir="' . ( I18n::is_rtl() ? 'rtl' : 'ltr' ) . '" lang="' . esc_attr( 'ar' === $lang ? 'ar' : $lang ) . '"';
	}

	/** Left (desktop) / top (mobile) brand panel. Decorative graphics are hidden from assistive tech. */
	public static function brand_panel(): void {
		$langs = '';
		foreach ( I18n::labels() as $code => $label ) {
			$cur    = I18n::current() === $code;
			$langs .= '<li><a href="' . I18n::switch_url( $code ) . '" lang="' . esc_attr( $code ) . '" hreflang="' . esc_attr( $code ) . '"' . ( $cur ? ' aria-current="true"' : '' ) . '>' . esc_html( $label ) . '</a></li>';
		}
		echo '<aside class="ec-auth-brand" aria-label="' . esc_attr( Branding::name() ) . '">';
		echo '<a class="ec-auth-brand__logo" href="' . esc_url( home_url( '/' ) ) . '">' . Branding::logo_html( 'dark', 'ec-auth-logo', 44 ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in logo_html().
		echo '<div class="ec-auth-brand__body"><p class="ec-auth-brand__tagline">' . esc_html( Branding::tagline() ) . '</p>';
		echo '<p class="ec-auth-brand__headline">' . esc_html__( 'Your Learning Journey Starts Here.', 'educore-core' ) . '</p>';
		echo '<p class="ec-auth-brand__text">' . esc_html__( 'Learn, practice, understand, and grow through a smarter educational experience.', 'educore-core' ) . '</p></div>';
		echo self::illustration(); // phpcs:ignore WordPress.Security.EscapeOutput -- static SVG.
		echo '<p class="ec-auth-brand__initiative">' . esc_html( Branding::initiative() ) . '</p>';
		echo '</aside>';
		echo '<nav class="ec-auth-lang" aria-label="' . esc_attr__( 'Language', 'educore-core' ) . '"><ul>' . $langs . '</ul></nav>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
	}

	/** Original abstract artwork: orbits of discovery around an open book, with points of understanding. */
	private static function illustration(): string {
		return '<svg class="ec-auth-art" viewBox="0 0 400 300" aria-hidden="true" focusable="false">'
			. '<g fill="none" stroke-linecap="round">'
			. '<circle class="ec-orbit ec-orbit--1" cx="200" cy="150" r="128" stroke="#43D4DA" stroke-opacity=".18" stroke-width="2" stroke-dasharray="6 12"/>'
			. '<circle class="ec-orbit ec-orbit--2" cx="200" cy="150" r="92" stroke="#43D4DA" stroke-opacity=".35" stroke-width="3" stroke-dasharray="420 160"/>'
			. '<circle cx="200" cy="150" r="56" stroke="#126B80" stroke-width="2"/>'
			. '</g>'
			. '<path d="M166 132q0-6 6-4l24 8q3 1 3 4v34q0 5-5 3l-23-8q-5-2-5-6Z" fill="#FFFFFF"/>'
			. '<path d="M234 132q0-6-6-4l-24 8q-3 1-3 4v34q0 5 5 3l23-8q5-2 5-6Z" fill="#43D4DA"/>'
			. '<circle class="ec-spark ec-spark--1" cx="290" cy="80" r="7" fill="#EBC16D"/>'
			. '<circle class="ec-spark ec-spark--2" cx="96" cy="200" r="4" fill="#43D4DA"/>'
			. '<circle class="ec-spark ec-spark--3" cx="318" cy="218" r="3" fill="#F6F3E9" fill-opacity=".6"/>'
			. '</svg>';
	}

	/** Heading + helpful text for every authentication state. */
	public static function message( $message ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only state flags set by WordPress.
		$a = self::action();
		if ( isset( $_GET['checkemail'] ) ) {
			$h = array( __( 'Check your email', 'educore-core' ), __( 'If an account matches what you entered, a link to choose a new password is on its way. The link works once and expires after a short time.', 'educore-core' ) );
		} elseif ( isset( $_GET['loggedout'] ) ) {
			$h = array( __( 'You are signed out', 'educore-core' ), __( 'Thank you for learning with us. Sign in again whenever you are ready.', 'educore-core' ) );
		} elseif ( in_array( $a, array( 'lostpassword', 'retrievepassword' ), true ) ) {
			$h = array( __( 'Reset your password', 'educore-core' ), __( 'Enter your username or email address. If an account exists, we will email you a secure link.', 'educore-core' ) );
		} elseif ( in_array( $a, array( 'rp', 'resetpass' ), true ) && did_action( 'after_password_reset' ) ) {
			$h = array( __( 'Password changed', 'educore-core' ), __( 'Your new password is active. You can sign in now.', 'educore-core' ) );
		} elseif ( in_array( $a, array( 'validate_2fa', 'backup_2fa', 'revalidate_2fa' ), true ) || ( did_action( 'wp_login' ) && ! is_user_logged_in() ) ) {
			// Second step from a two-factor plugin (e.g. WordPress "Two-Factor"): its own form follows unchanged.
			$h = array( __( 'Two-step verification', 'educore-core' ), __( 'One more step to protect your account. Enter the code from your verification method.', 'educore-core' ) );
		} elseif ( in_array( $a, array( 'rp', 'resetpass' ), true ) ) {
			$h = array( __( 'Choose a new password', 'educore-core' ), __( 'Use at least 12 characters. A short sentence you can remember works well.', 'educore-core' ) );
		} elseif ( isset( $_GET['password'] ) && 'changed' === $_GET['password'] ) {
			$h = array( __( 'Password changed', 'educore-core' ), __( 'Your new password is active. You can sign in now.', 'educore-core' ) );
		} elseif ( isset( $_GET['registration'] ) && 'disabled' === $_GET['registration'] ) {
			$h = array( __( 'Registration is closed', 'educore-core' ), __( 'Accounts are created by your school or by the EduCore team. If you need access, contact support.', 'educore-core' ) );
		} elseif ( isset( $_GET['reauth'] ) || isset( $_REQUEST['interim-login'] ) ) {
			$h = array( __( 'Please sign in again', 'educore-core' ), __( 'Your session has ended, so we need to confirm it is you.', 'educore-core' ) );
		} elseif ( in_array( $a, array( 'confirm_admin_email', 'logout' ), true ) ) {
			return $message;
		} else {
			$h = array( sprintf( /* translators: %s: platform name */ __( 'Welcome Back to %s', 'educore-core' ), Branding::name() ), __( 'Sign in to continue your learning journey.', 'educore-core' ) );
		}
		// phpcs:enable
		return '<header class="ec-auth-head"><h2 class="ec-auth-title">' . esc_html( $h[0] ) . '</h2><p class="ec-auth-sub">' . esc_html( $h[1] ) . '</p></header>' . $message;
	}

	/** One message for unknown user and wrong password (no account discovery). */
	public static function errors( \WP_Error $errors ): \WP_Error {
		$codes = $errors->get_error_codes();
		if ( array_intersect( $codes, array( 'invalid_username', 'invalid_email', 'incorrect_password' ) ) ) {
			$keep = new \WP_Error();
			foreach ( $codes as $c ) {
				if ( ! in_array( $c, array( 'invalid_username', 'invalid_email', 'incorrect_password' ), true ) ) {
					foreach ( $errors->get_error_messages( $c ) as $m ) {
						$keep->add( $c, $m, $errors->get_error_data( $c ) );
					}
				}
			}
			$keep->add( 'educore_invalid_login', __( '<strong>Sign-in failed:</strong> the username, email address or password is not correct. Check them and try again, or reset your password.', 'educore-core' ) );
			return $keep;
		}
		return $errors;
	}

	/** Password-reset requests: same answer whether the account exists or not, and a rate limit. */
	public static function lostpassword( \WP_Error $errors, $user_data ): void {
		if ( ! RateLimiter::hit( 'lostpw' ) ) {
			$errors->add( 'educore_throttled', __( 'Too many reset requests. Please wait a while and try again.', 'educore-core' ) );
			return;
		}
		if ( ! $errors->has_errors() && ! $user_data ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WordPress core form.
			Audit::log( 'security.lostpassword_unknown', 'user', 0, array( 'login_hash' => hash( 'sha256', strtolower( isset( $_POST['user_login'] ) ? sanitize_text_field( wp_unslash( $_POST['user_login'] ) ) : '' ) ) ) );
			wp_safe_redirect( add_query_arg( 'checkemail', 'confirm', wp_login_url() ) );
			exit;
		}
	}

	/**
	 * A reset e-mail that cannot be delivered must not reveal that the account exists (WordPress would show
	 * "The email could not be sent" only for real accounts). Record it for administrators and answer exactly
	 * as for an unknown account.
	 */
	public static function reset_mail_failed( $error ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WordPress core form; read-only routing check.
		if ( ! did_action( 'lostpassword_post' ) || ! isset( $_REQUEST['action'] ) || ! in_array( $_REQUEST['action'], array( 'lostpassword', 'retrievepassword' ), true ) ) {
			return;
		}
		Audit::log( 'security.reset_mail_failed', 'user', 0, array( 'error' => is_wp_error( $error ) ? $error->get_error_code() : 'unknown' ) );
		wp_safe_redirect( add_query_arg( 'checkemail', 'confirm', wp_login_url() ) );
		exit;
	}

	/** "You are about to sign out" — branded confirmation when the logout link has no valid nonce. */
	public static function logout_confirmation(): void {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( add_query_arg( 'loggedout', 'true', wp_login_url() ) );
			exit;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_REQUEST['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ), 'log-out' ) ) {
			return; // Valid link: WordPress signs the user out.
		}
		login_header( __( 'Sign out', 'educore-core' ) );
		echo '<header class="ec-auth-head"><h2 class="ec-auth-title">' . esc_html__( 'Sign out of EduCore?', 'educore-core' ) . '</h2><p class="ec-auth-sub">' . esc_html__( 'Please confirm. This protects you from links that try to sign you out without your knowledge.', 'educore-core' ) . '</p></header>';
		echo '<div class="ec-auth-actions"><a class="button button-primary button-large" href="' . esc_url( wp_logout_url( add_query_arg( 'loggedout', 'true', wp_login_url() ) ) ) . '">' . esc_html__( 'Sign out', 'educore-core' ) . '</a> <a class="button button-large" href="' . esc_url( Router::primary( wp_get_current_user() ) ) . '">' . esc_html__( 'Stay signed in', 'educore-core' ) . '</a></div>';
		login_footer();
		exit;
	}

	/** The WordPress registration screen is never used: EduCore has its own (consent-aware) form. */
	public static function register_redirect(): void {
		if ( Pages::registration_open() ) {
			wp_safe_redirect( Pages::url( 'register' ) );
		} else {
			wp_safe_redirect( add_query_arg( 'registration', 'disabled', wp_login_url() ) );
		}
		exit;
	}

	public static function register_url( $url ) {
		return Pages::registration_open() ? Pages::url( 'register' ) : $url;
	}

	public static function back_link( $html ) {
		return '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( sprintf( /* translators: %s: platform name */ __( '← Back to %s', 'educore-core' ), Branding::name() ) ) . '</a>';
	}

	public static function footer(): void {
		$parts = array();
		if ( Pages::is_published( 'privacy' ) ) {
			$parts[] = '<a href="' . esc_url( Pages::url( 'privacy' ) ) . '">' . esc_html__( 'Privacy', 'educore-core' ) . '</a>';
		}
		if ( Pages::is_published( 'contact' ) ) {
			$parts[] = '<a href="' . esc_url( Pages::url( 'contact' ) ) . '">' . esc_html__( 'Help & support', 'educore-core' ) . '</a>';
		}
		if ( Pages::registration_open() ) {
			$parts[] = '<a href="' . esc_url( Pages::url( 'register' ) ) . '">' . esc_html__( 'Create an account', 'educore-core' ) . '</a>';
		}
		echo '<p class="ec-auth-foot">' . implode( ' · ', $parts ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
	}

	/**
	 * Translate the WordPress core strings shown on the sign-in screens when the site has no WordPress
	 * language pack for the chosen language (EduCore supplies French and Arabic for them).
	 */
	public static function core_strings( $translation, $text, $domain ) {
		if ( 'default' !== $domain || ! self::on_login_screen() ) {
			return $translation;
		}
		$map     = self::core_map();
		$rebrand = array( 'Log In', 'Lost your password?', 'Get New Password', 'Save Password', 'You are now logged out.' );
		if ( ! isset( $map[ $text ] ) ) {
			return $translation;
		}
		// EduCore wording is used in every language for these; the rest only fills gaps in missing language packs.
		if ( in_array( $text, $rebrand, true ) || ( $translation === $text && 'en' !== I18n::current() ) ) {
			return $map[ $text ];
		}
		return $translation;
	}

	private static function core_map(): array {
		static $m = null;
		if ( null === $m ) {
			$m = array(
				'Username or Email Address'  => __( 'Username or Email Address', 'educore-core' ),
				'Password'                   => __( 'Password', 'educore-core' ),
				'Remember Me'                => __( 'Remember Me', 'educore-core' ),
				'Log In'                     => __( 'Sign in securely', 'educore-core' ),
				'Lost your password?'        => __( 'Forgot your password?', 'educore-core' ),
				'Show password'              => __( 'Show password', 'educore-core' ),
				'Hide password'              => __( 'Hide password', 'educore-core' ),
				'Get New Password'           => __( 'Send reset link', 'educore-core' ),
				'Username or Email Address:' => __( 'Username or Email Address', 'educore-core' ),
				'New password'               => __( 'New password', 'educore-core' ),
				'Confirm new password'       => __( 'Confirm new password', 'educore-core' ),
				'Save Password'              => __( 'Save password', 'educore-core' ),
				'Generate Password'          => __( 'Generate a strong password', 'educore-core' ),
				'Confirm use of weak password' => __( 'Confirm use of weak password', 'educore-core' ),
				'You are now logged out.'    => __( 'You are now signed out.', 'educore-core' ),
				/* translators: %s: sign-in page URL */
				'Check your email for the confirmation link, then visit the <a href="%s">login page</a>.' => __( 'Check your email for the confirmation link, then return to the <a href="%s">sign-in page</a>.', 'educore-core' ),
				'Your password has been reset.' => __( 'Your password has been reset.', 'educore-core' ),
				'Log in'                     => __( 'Sign in', 'educore-core' ),
				'Your password reset link appears to be invalid. Please request a new link below.' => __( 'This reset link is not valid. Please request a new one below.', 'educore-core' ),
				'Your password reset link has expired. Please request a new link below.' => __( 'This reset link has expired. Please request a new one below.', 'educore-core' ),
				'Enter your new password below or generate one.' => __( 'Enter your new password below or generate one.', 'educore-core' ),
				'Hint: The password should be at least twelve characters long. To make it stronger, use upper and lower case letters, numbers, and symbols like ! " ? $ % ^ &amp; ).' => __( 'Hint: use at least twelve characters. Mixing upper and lower case letters, numbers and symbols makes it stronger.', 'educore-core' ),
				'Please enter your username or email address. You will receive an email message with instructions on how to reset your password.' => __( 'Please enter your username or email address. You will receive an email message with instructions on how to reset your password.', 'educore-core' ),
				'Session expired'            => __( 'Session expired', 'educore-core' ),
				'Please log in to continue.' => __( 'Please sign in to continue.', 'educore-core' ),
				'Very weak'                  => __( 'Very weak', 'educore-core' ),
				'Weak'                       => __( 'Weak', 'educore-core' ),
				'Medium'                     => __( 'Medium', 'educore-core' ),
				'Strong'                     => __( 'Strong', 'educore-core' ),
				'Error:'                     => __( 'Error:', 'educore-core' ),
				'<strong>Error:</strong> The username field is empty.' => __( '<strong>Error:</strong> please enter your username or email address.', 'educore-core' ),
				'<strong>Error:</strong> The password field is empty.' => __( '<strong>Error:</strong> please enter your password.', 'educore-core' ),
			);
		}
		return $m;
	}
}
