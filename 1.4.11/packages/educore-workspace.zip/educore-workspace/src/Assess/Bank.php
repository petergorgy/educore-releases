<?php
namespace EduCore\Workspace\Assess;

use EduCore\Assessments\Exchange\Center;
use EduCore\Assessments\Exchange\Exporter;
use EduCore\Assessments\Exchange\Formats;
use EduCore\Assessments\Exchange\Jobs;
use EduCore\Assessments\Grading;
use EduCore\Assessments\Questions;
use EduCore\Assessments\Types;
use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Workspace\Studio\Courses;

defined( 'ABSPATH' ) || exit;

/**
 * Question Bank Center service. A thin, authorised layer over the assessments domain (Questions, Types, Grading,
 * Exchange). Authority is exactly the wp-admin rule: `ec_manage_question_bank` AND `ec_edit_course` on the course;
 * publishing additionally needs Questions::can_publish (lead instructor, publisher or academic manager).
 * Every call re-checks the object: a question id is only honoured inside the course it belongs to.
 */
final class Bank {
	public const MAX_UPLOAD = 10 * MB_IN_BYTES;
	public const UPLOAD_EXT = array( 'zip', 'xlsx', 'csv', 'json', 'xml', 'gift', 'txt' );
	public const AUTHORING  = array( 'type', 'stem', 'options', 'correct', 'code', 'language', 'image_id', 'model_answer', 'min_words', 'scoring', 'explanation', 'points', 'difficulty', 'usage', 'lang', 'tags', 'lesson_id', 'status', 'rubric' );

	/**
	 * The Exchange layer was written for wp-admin and uses admin-only helpers (wp_tempnam, unzip/sideload). On the
	 * front end and in REST those files are not loaded, so load them before delegating.
	 */
	private static function admin_includes(): void {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
	}

	public static function available(): bool {
		return class_exists( Questions::class ) && class_exists( Jobs::class );
	}

	public static function can( int $uid, int $course_id ): bool {
		return $uid > 0 && self::available() && Content::is_course( $course_id ) && user_can( $uid, 'ec_manage_question_bank' ) && user_can( $uid, 'ec_edit_course', $course_id );
	}

	public static function can_any( int $uid ): bool {
		return $uid > 0 && self::available() && user_can( $uid, 'ec_manage_question_bank' );
	}

	public static function can_publish( int $uid, int $course_id ): bool {
		return self::can( $uid, $course_id ) && Questions::can_publish( $uid, $course_id );
	}

	/** @return \WP_Post[] courses whose bank the user manages */
	public static function courses( int $uid ): array {
		if ( ! self::can_any( $uid ) ) {
			return array();
		}
		return array_values( array_filter( Courses::mine( $uid ), static fn( $c ) => self::can( $uid, (int) $c->ID ) ) );
	}

	private static function deny(): \WP_Error {
		return new \WP_Error( 'ec_bank_forbidden', __( 'You cannot manage the question bank of this course.', 'educore-workspace' ), array( 'status' => 403 ) );
	}

	/** Question of a course, or null (also when the id belongs to another course). */
	public static function question( int $uid, int $course_id, int $id ): ?array {
		if ( ! self::can( $uid, $course_id ) ) {
			return null;
		}
		$q = Questions::full( $id );
		return ( $q && (int) $q['course_id'] === $course_id ) ? $q : null;
	}

	/** @return array{rows:array,total:int} */
	public static function search( int $uid, int $course_id, array $f ): array {
		if ( ! self::can( $uid, $course_id ) ) {
			return array( 'rows' => array(), 'total' => 0 );
		}
		$clean = array( 'course_id' => $course_id, 'page' => max( 1, (int) ( $f['page'] ?? 1 ) ), 'per_page' => 25 );
		foreach ( array( 'type' => Types::ALL, 'status' => Questions::STATUSES, 'difficulty' => Questions::DIFFICULTY ) as $k => $allowed ) {
			if ( in_array( $f[ $k ] ?? '', $allowed, true ) ) {
				$clean[ $k ] = $f[ $k ];
			}
		}
		if ( ! empty( $f['lesson_id'] ) && Content::course_of( (int) $f['lesson_id'] ) === $course_id ) {
			$clean['lesson_id'] = (int) $f['lesson_id'];
		}
		if ( '' !== trim( (string) ( $f['search'] ?? '' ) ) ) {
			$clean['search'] = mb_substr( sanitize_text_field( (string) $f['search'] ), 0, 100 );
		}
		return Questions::search( $clean );
	}

	/** Parse "Criterion | points" lines. */
	public static function rubric_lines( string $text ): array {
		$out = array();
		foreach ( preg_split( '/\r\n|\n/', $text ) as $line ) {
			$parts = array_map( 'trim', explode( '|', $line ) );
			if ( '' !== $parts[0] ) {
				$out[] = array( 'label' => $parts[0], 'points' => (float) ( $parts[1] ?? 0 ) );
			}
		}
		return $out;
	}

	/**
	 * Create (id 0) or update a question from authoring fields.
	 *
	 * @return array{id:int,duplicates:int[]}|\WP_Error
	 */
	public static function save( int $uid, int $course_id, int $id, array $in ) {
		if ( ! self::can( $uid, $course_id ) ) {
			return self::deny();
		}
		$existing = null;
		if ( $id ) {
			$existing = self::question( $uid, $course_id, $id );
			if ( ! $existing ) {
				return new \WP_Error( 'ec_bank_not_found', __( 'Question not found in this course.', 'educore-workspace' ), array( 'status' => 404 ) );
			}
		}
		$data = array();
		foreach ( self::AUTHORING as $k ) {
			$data[ $k ] = is_scalar( $in[ $k ] ?? null ) ? (string) $in[ $k ] : '';
		}
		$status = in_array( $data['status'], Questions::STATUSES, true ) ? $data['status'] : ( $existing['status'] ?? 'draft' );
		if ( 'published' === $status && ( $existing['status'] ?? '' ) !== 'published' && ! Questions::can_publish( $uid, $course_id ) ) {
			return new \WP_Error( 'ec_bank_publish', __( 'Only a lead instructor or academic manager can publish questions. Submit it for review instead.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$built = Types::from_authoring( $data );
		if ( is_wp_error( $built ) ) {
			return new \WP_Error( 'ec_bank_invalid', $built->get_error_message(), array( 'status' => 400 ) );
		}
		$res = Questions::save(
			array(
				'course_id'   => $course_id,
				'lesson_id'   => absint( $data['lesson_id'] ),
				'type'        => $data['type'],
				'stem'        => $data['stem'],
				'payload'     => $built['payload'],
				'key'         => $built['key'],
				'explanation' => $data['explanation'],
				'points'      => '' === $data['points'] ? 1 : (float) $data['points'],
				'difficulty'  => $data['difficulty'],
				'usage'       => $data['usage'],
				'lang'        => $data['lang'] ?: 'en',
				'tags'        => $data['tags'],
				'status'      => $status,
			),
			$id
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		if ( array_key_exists( 'rubric', $in ) ) {
			Grading::set_rubric( (int) $res, self::rubric_lines( $data['rubric'] ) );
		}
		$q = Questions::get( (int) $res );
		return array( 'id' => (int) $res, 'duplicates' => Questions::duplicates( $course_id, (string) $q['dedupe_hash'], (int) $res ) );
	}

	/** @return true|\WP_Error */
	public static function set_status( int $uid, int $course_id, int $id, string $status ) {
		if ( ! self::question( $uid, $course_id, $id ) ) {
			return self::deny();
		}
		return Questions::set_status( $id, $status );
	}

	/** Copy the current version of a question as a new draft (tags and rubric included). @return int|\WP_Error */
	public static function duplicate( int $uid, int $course_id, int $id ) {
		$q = self::question( $uid, $course_id, $id );
		if ( ! $q || empty( $q['version'] ) ) {
			return self::deny();
		}
		$v   = $q['version'];
		$res = Questions::save(
			array(
				'course_id'   => $course_id,
				'lesson_id'   => (int) $q['lesson_id'],
				'type'        => $q['type'],
				'stem'        => $v['stem'],
				'payload'     => $v['payload'],
				'key'         => $v['answer_key'],
				'explanation' => $v['explanation'],
				'points'      => (float) $v['points'],
				'difficulty'  => $q['difficulty'],
				'usage'       => $q['usage_scope'],
				'lang'        => $v['lang'],
				'tags'        => $q['tags'],
				'status'      => 'draft',
			)
		);
		if ( ! is_wp_error( $res ) ) {
			Grading::set_rubric( (int) $res, Grading::rubric( $id ) );
			Audit::log( 'question.duplicated', 'question', (int) $res, array( 'from' => $id ) );
		}
		return $res;
	}

	/** Authoring view of a question for the edit form. */
	public static function authoring( array $q ): array {
		$v   = $q['version'];
		$row = Types::to_authoring( (string) $q['type'], (array) $v['payload'], (array) $v['answer_key'] );
		return $row + array(
			'type'        => $q['type'],
			'stem'        => $v['stem'],
			'min_words'   => (string) ( $v['payload']['min_words'] ?? '' ),
			'explanation' => $v['explanation'],
			'points'      => (string) (float) $v['points'],
			'difficulty'  => $q['difficulty'],
			'usage'       => $q['usage_scope'],
			'lang'        => $v['lang'],
			'tags'        => implode( ', ', (array) $q['tags'] ),
			'lesson_id'   => (string) $q['lesson_id'],
			'status'      => $q['status'],
			'rubric'      => implode( "\n", array_map( static fn( $c ) => $c['label'] . ' | ' . ( 0.0 + $c['points'] ), Grading::rubric( (int) $q['id'] ) ) ),
		);
	}

	/* ---------- Import (Exchange jobs: upload → validate → preview → confirm) ---------- */

	public static function job( int $uid, int $job_id ): ?array {
		if ( ! self::available() ) {
			return null;
		}
		$job = Jobs::get( $job_id );
		return ( $job && self::can( $uid, (int) $job['course_id'] ) ) ? $job : null;
	}

	/** @return int|\WP_Error job id */
	public static function upload( int $uid, int $course_id, array $file, array $opts ) {
		if ( ! self::can( $uid, $course_id ) || ! Jobs::can_import( $course_id, $uid ) ) {
			return self::deny();
		}
		if ( ! empty( $file['error'] ) || empty( $file['tmp_name'] ) || ! is_uploaded_file( (string) $file['tmp_name'] ) ) {
			return new \WP_Error( 'ec_bank_upload', __( 'No file was uploaded (or it exceeds the server upload limit).', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		if ( (int) $file['size'] > self::MAX_UPLOAD ) {
			return new \WP_Error( 'ec_bank_upload', __( 'The file is larger than 10 MB.', 'educore-workspace' ), array( 'status' => 413 ) );
		}
		$name = sanitize_file_name( (string) $file['name'] );
		$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, self::UPLOAD_EXT, true ) ) {
			return new \WP_Error( 'ec_bank_upload', __( 'Unsupported file type. Use .zip, .xlsx, .csv, .json, .xml or .gift.', 'educore-workspace' ), array( 'status' => 415 ) );
		}
		$format = (string) ( $opts['format'] ?? 'auto' );
		$format = ( 'auto' === $format || isset( Formats::all()[ $format ] ) ) ? $format : 'auto';
		$status = in_array( $opts['status'] ?? '', array( '', 'draft', 'review', 'published' ), true ) ? (string) $opts['status'] : '';
		if ( 'published' === $status && ! Questions::can_publish( $uid, $course_id ) ) {
			return new \WP_Error( 'ec_bank_publish', __( 'Only a lead instructor or academic manager can import questions as published.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		self::admin_includes();
		$r = Jobs::create( $course_id, (string) $file['tmp_name'], $name, $format, array( 'mode' => (string) ( $opts['mode'] ?? 'skip' ), 'status' => $status, 'lang' => (string) ( $opts['lang'] ?? '' ) ) );
		return is_wp_error( $r ) ? new \WP_Error( $r->get_error_code(), $r->get_error_message(), array( 'status' => 400 ) ) : (int) $r;
	}

	/** @return array|\WP_Error summary */
	public static function set_mode( int $uid, int $job_id, string $mode ) {
		$job = self::job( $uid, $job_id );
		if ( ! $job || 'validated' !== $job['status'] ) {
			return self::deny();
		}
		Jobs::set_mode( $job_id, $mode );
		return Jobs::plan( $job_id );
	}

	/** @return array|\WP_Error summary */
	public static function commit( int $uid, int $job_id ) {
		if ( ! self::job( $uid, $job_id ) ) {
			return self::deny();
		}
		self::admin_includes();
		$r = Jobs::commit( $job_id );
		return is_wp_error( $r ) ? new \WP_Error( $r->get_error_code(), $r->get_error_message(), array( 'status' => 409 ) ) : $r;
	}

	/** @return true|\WP_Error */
	public static function cancel( int $uid, int $job_id ) {
		if ( ! self::job( $uid, $job_id ) ) {
			return self::deny();
		}
		Jobs::cancel( $job_id );
		return true;
	}

	/** Recent import jobs in the course. */
	public static function jobs( int $uid, int $course_id, int $limit = 10 ): array {
		if ( ! self::can( $uid, $course_id ) ) {
			return array();
		}
		return array_slice( array_values( array_filter( Jobs::recent( 100 ), static fn( $j ) => (int) $j['course_id'] === $course_id ) ), 0, $limit );
	}

	/* ---------- Downloads (export, import report, template) ---------- */

	public static function download_url( string $what, int $course_id, array $args = array() ): string {
		return add_query_arg( array_merge( array( 'ec_bank_dl' => $what, 'course' => $course_id, '_ecdl' => wp_create_nonce( 'ec_bank_dl_' . $what . '_' . $course_id ) ), $args ), \EduCore\Workspace\Pages::url( 'studio' ) );
	}

	/** template_redirect: stream a download after nonce + capability + object checks. */
	public static function maybe_download(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- verified below.
		if ( empty( $_GET['ec_bank_dl'] ) || ! self::available() ) {
			return;
		}
		$what   = sanitize_key( wp_unslash( $_GET['ec_bank_dl'] ) );
		$course = isset( $_GET['course'] ) ? absint( $_GET['course'] ) : 0;
		$nonce  = isset( $_GET['_ecdl'] ) ? sanitize_text_field( wp_unslash( $_GET['_ecdl'] ) ) : '';
		$uid    = get_current_user_id();
		if ( ! wp_verify_nonce( $nonce, 'ec_bank_dl_' . $what . '_' . $course ) || ! self::can( $uid, $course ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to download this file.', 'educore-workspace' ), '', array( 'response' => 403 ) );
		}
		self::admin_includes();
		if ( 'export' === $what ) {
			$format = isset( $_GET['format'] ) ? sanitize_key( wp_unslash( $_GET['format'] ) ) : 'native';
			if ( ! isset( Formats::all()[ $format ] ) ) {
				wp_die( esc_html__( 'Unknown format.', 'educore-workspace' ), '', array( 'response' => 400 ) );
			}
			$filters = array( 'lesson_id' => isset( $_GET['lesson_id'] ) ? absint( $_GET['lesson_id'] ) : 0 );
			foreach ( array( 'status', 'type', 'difficulty', 'tag' ) as $k ) {
				$filters[ $k ] = isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
			}
			$x = Exporter::export( $course, $format, $filters );
			if ( $x['skipped'] ) {
				set_transient( 'educore_ws_bank_skipped_' . $uid, $x['skipped'], HOUR_IN_SECONDS );
			}
			self::send( $x['bytes'], $x['filename'], $x['mime'] );
		}
		if ( 'report' === $what ) {
			$job = self::job( $uid, isset( $_GET['job'] ) ? absint( $_GET['job'] ) : 0 );
			if ( ! $job || (int) $job['course_id'] !== $course ) {
				wp_die( esc_html__( 'Sorry, you are not allowed to download this file.', 'educore-workspace' ), '', array( 'response' => 403 ) );
			}
			self::send( Jobs::report_csv( (int) $job['id'] ), 'import-report-' . (int) $job['id'] . '.csv', 'text/csv' );
		}
		if ( 'template' === $what ) {
			$f = isset( $_GET['format'] ) && 'xlsx' === $_GET['format'] ? 'xlsx' : 'csv';
			$s = array();
			self::send( Formats::write( $f, Center::examples(), $s ), 'educore-questions-template.' . $f, Formats::all()[ $f ]['mime'] );
		}
		// phpcs:enable
		wp_die( esc_html__( 'Unknown download.', 'educore-workspace' ), '', array( 'response' => 400 ) );
	}

	private static function send( string $bytes, string $name, string $mime ): void {
		nocache_headers();
		header( 'Content-Type: ' . $mime . '; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $name ) . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		echo $bytes; // phpcs:ignore WordPress.Security.EscapeOutput -- file download.
		exit;
	}
}
