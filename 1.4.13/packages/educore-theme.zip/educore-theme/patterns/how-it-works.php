<?php
/**
 * Title: EduCore — how it works
 * Slug: educore-theme/how-it-works
 * Categories: educore-theme, features
 * Description: Three numbered steps from finding a course to tracking progress.
 */
$ect_steps = array(
	array( __( 'Find your course', 'educore-theme' ), __( 'Browse by subject or level. Every course shows what you will learn and how long it takes.', 'educore-theme' ) ),
	array( __( 'Learn and practise', 'educore-theme' ), __( 'Short lessons, practice questions and quizzes with clear rules and instant feedback.', 'educore-theme' ) ),
	array( __( 'Track and celebrate', 'educore-theme' ), __( 'Follow your progress, see your results and earn a certificate when you complete a course.', 'educore-theme' ) ),
);
?>
<!-- wp:group {"align":"full","backgroundColor":"surface","className":"ect-steps-band","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull ect-steps-band has-surface-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:paragraph {"align":"wide","className":"ect-eyebrow ect-eyebrow--dark"} --><p class="alignwide ect-eyebrow ect-eyebrow--dark"><?php esc_html_e( 'How it works', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:heading {"align":"wide","className":"ect-section__title"} --><h2 class="wp-block-heading alignwide ect-section__title"><?php esc_html_e( 'From first lesson to certificate', 'educore-theme' ); ?></h2><!-- /wp:heading -->
<!-- wp:html -->
<ol class="ect-steps alignwide">
<?php foreach ( $ect_steps as $ect_i => $ect_s ) : ?>
<li class="ect-step ect-reveal"><span class="ect-step__n" aria-hidden="true"><?php echo esc_html( number_format_i18n( $ect_i + 1 ) ); ?></span><h3><?php echo esc_html( $ect_s[0] ); ?></h3><p><?php echo esc_html( $ect_s[1] ); ?></p></li>
<?php endforeach; ?>
</ol>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
