<?php
namespace EduCore\Recovery;

use EduCore\Core\Audit;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Integrity verification: outer checksum, decryption/authentication, manifest, per-entry SHA-256, dump completeness. */
final class Verifier {

	/** @return array{ok:bool,errors:string[],checked:int} */
	public static function verify( int $id ): array {
		$b = Backup::get( $id );
		if ( ! $b || 'complete' !== $b->status ) {
			return array( 'ok' => false, 'errors' => array( __( 'Backup not found or not complete.', 'educore-recovery' ) ), 'checked' => 0 );
		}
		$errors  = array();
		$checked = 0;
		$h       = Backup::open( $b );
		if ( is_wp_error( $h ) ) {
			$errors[] = $h->get_error_message();
		} else {
			$zip = $h['zip'];
			$man = $h['manifest'];
			foreach ( (array) $man['entries'] as $name => $meta ) {
				$s = $zip->getStream( $name );
				if ( ! $s ) {
					$errors[] = sprintf( /* translators: %s: entry */ __( 'Missing entry: %s', 'educore-recovery' ), $name );
					continue;
				}
				$ctx = hash_init( 'sha256' );
				hash_update_stream( $ctx, $s );
				fclose( $s ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( ! hash_equals( (string) $meta['sha256'], hash_final( $ctx ) ) ) {
					$errors[] = sprintf( /* translators: %s: entry */ __( 'Checksum mismatch: %s', 'educore-recovery' ), $name );
				}
				++$checked;
			}
			// Every archive entry must be declared in the manifest (no injected files).
			for ( $i = 0; $i < $zip->numFiles; $i++ ) {
				$n = (string) $zip->getNameIndex( $i );
				if ( 'manifest.json' !== $n && ! isset( $man['entries'][ $n ] ) ) {
					$errors[] = sprintf( /* translators: %s: entry */ __( 'Undeclared entry: %s', 'educore-recovery' ), $n );
				}
			}
			if ( ! $errors ) {
				$sql = Backup::extract_sql( $zip );
				$tables = array();
				$fh     = fopen( $sql, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				$last   = '';
				while ( false !== ( $line = fgets( $fh ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
					if ( 0 === strpos( $line, '-- TABLE ' ) ) {
						$tables[] = trim( substr( $line, 9 ) );
					}
					$last = $line;
				}
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				wp_delete_file( $sql );
				if ( "-- END\n" !== $last ) {
					$errors[] = __( 'The database dump is incomplete.', 'educore-recovery' );
				}
				$missing = array_diff( array_keys( (array) $man['tables'] ), $tables );
				if ( $missing ) {
					$errors[] = sprintf( /* translators: %s: tables */ __( 'Tables missing from dump: %s', 'educore-recovery' ), implode( ', ', $missing ) );
				}
			}
			$h['cleanup']();
		}
		$ok = ! $errors;
		Backup::update( $id, array( 'verify_status' => $ok ? 'verified' : 'failed', 'verified_at' => Schema::now(), 'message' => $ok ? (string) $b->message : substr( implode( ' | ', $errors ), 0, 490 ) ) );
		Audit::log( $ok ? 'backup.verified' : 'backup.verify_failed', 'backup', $id, array( 'uid' => $b->uid, 'errors' => $errors ) );
		return array( 'ok' => $ok, 'errors' => $errors, 'checked' => $checked );
	}
}
