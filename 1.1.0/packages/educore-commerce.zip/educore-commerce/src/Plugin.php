<?php
namespace EduCore\Commerce;

use EduCore\Core\Registry;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	private static bool $booted = false;

	public static function tables(): array {
		return array(
			'entitlements' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				course_id BIGINT UNSIGNED NOT NULL,
				order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				product_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				starts_at DATETIME NOT NULL,
				ends_at DATETIME NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				source VARCHAR(20) NOT NULL DEFAULT 'order',
				notified_at DATETIME NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY order_product_course (order_id,product_id,course_id,user_id),
				KEY user_course_status (user_id,course_id,status),
				KEY status_ends (status,ends_at)",
		);
	}

	public static function install(): void {
		Schema::migrate( 'educore_commerce_db_version', EDUCORE_COMMERCE_DB_VERSION, self::tables() );
	}

	public static function woo_active(): bool {
		return class_exists( '\WooCommerce' ) && function_exists( 'wc_get_order' );
	}

	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;
		Registry::register( 'commerce', EDUCORE_COMMERCE_VERSION );
		self::install();
		add_action( 'educore/install/repair', static function () {
			delete_option( 'educore_commerce_db_version' );
			self::install();
		} );
		add_action( 'init', static fn() => load_plugin_textdomain( 'educore-commerce', false, dirname( plugin_basename( EDUCORE_COMMERCE_FILE ) ) . '/languages' ) );

		Gate::register();
		Entitlements::register();
		Block::register();
		Woo::register();
		Subscriptions::register();
		add_action( 'admin_notices', array( self::class, 'notice' ) );
	}

	public static function notice(): void {
		if ( ! self::woo_active() && current_user_can( 'ec_manage_commerce' ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'EduCore Commerce: WooCommerce is not active. Paid courses cannot be purchased; free courses and existing access keep working.', 'educore-commerce' ) . '</p></div>';
		}
	}
}
