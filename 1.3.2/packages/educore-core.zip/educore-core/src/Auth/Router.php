<?php
namespace EduCore\Core\Auth;

use EduCore\Core\Pages;

defined( 'ABSPATH' ) || exit;

/**
 * Role-aware post-login routing and workspace switching.
 *
 * Destinations are resolved from registered, published EduCore pages and real capabilities — never
 * from hard-coded paths. Packages add their own workspaces through the `educore/auth/destinations` filter
 * (e.g. the Teaching Hub adds Teaching and Tutoring). A safe, explicitly requested internal URL always
 * wins; redirects are validated against the site host (no open redirects) and never point a user to a
 * place that would bounce them again (no loops).
 */
final class Router {

	public static function register(): void {
		add_filter( 'login_redirect', array( self::class, 'login_redirect' ), 99, 3 );
		add_action( 'admin_bar_menu', array( self::class, 'admin_bar' ), 80 );
	}

	/**
	 * Workspaces the user may open, best first.
	 *
	 * @return array<string,array{label:string,url:string,priority:int}>
	 */
	public static function destinations( \WP_User $user ): array {
		$d = array();
		if ( user_can( $user, 'manage_options' ) ) {
			$d['wp-admin'] = array( 'label' => __( 'WordPress administration', 'educore-core' ), 'url' => admin_url(), 'priority' => 10 );
		}
		if ( user_can( $user, 'ec_access_workspace' ) || user_can( $user, 'ec_manage_settings' ) ) {
			$label = user_can( $user, 'ec_manage_all_courses' ) ? __( 'Academic management', 'educore-core' ) : __( 'EduCore administration', 'educore-core' );
			$d['educore-admin'] = array( 'label' => $label, 'url' => admin_url( 'admin.php?page=educore' ), 'priority' => user_can( $user, 'ec_manage_all_courses' ) ? 20 : 60 );
		}
		if ( user_can( $user, 'ec_learn' ) && Pages::is_published( 'dashboard' ) ) {
			$d['student'] = array( 'label' => __( 'My learning', 'educore-core' ), 'url' => Pages::url( 'dashboard' ), 'priority' => 50 );
		}
		if ( in_array( 'ec_guardian', (array) $user->roles, true ) && Pages::is_published( 'guardian' ) ) {
			$d['guardian'] = array( 'label' => __( 'Guardian area', 'educore-core' ), 'url' => Pages::url( 'guardian' ), 'priority' => 45 );
		}
		/**
		 * Packages register additional workspaces.
		 *
		 * @param array    $d    key => [label, url, priority]
		 * @param \WP_User $user
		 */
		$d = (array) apply_filters( 'educore/auth/destinations', $d, $user );
		uasort( $d, static fn( $a, $b ) => (int) $a['priority'] <=> (int) $b['priority'] );
		return $d;
	}

	public static function primary( \WP_User $user ): string {
		$d = self::destinations( $user );
		return $d ? (string) reset( $d )['url'] : home_url( '/' );
	}

	/** Can this user actually stay on $url, or would they be bounced (wp-admin for learners)? */
	private static function lands( \WP_User $user, string $url ): bool {
		$admin = admin_url();
		if ( 0 === strpos( $url, $admin ) ) {
			return user_can( $user, 'edit_posts' ) || user_can( $user, 'ec_access_workspace' ) || user_can( $user, 'manage_options' );
		}
		return true;
	}

	/**
	 * @param string           $redirect_to Destination WordPress computed (requested or admin_url()).
	 * @param string           $requested   The raw redirect_to parameter ('' when none was given).
	 * @param \WP_User|\WP_Error $user
	 */
	public static function login_redirect( $redirect_to, $requested, $user ) {
		if ( ! $user instanceof \WP_User || ! $user->exists() ) {
			return $redirect_to;
		}
		$primary   = self::primary( $user );
		$requested = (string) $requested;
		$generic   = '' === $requested || in_array( untrailingslashit( strtok( $requested, '?' ) ), array( untrailingslashit( admin_url() ), untrailingslashit( admin_url( 'profile.php' ) ), untrailingslashit( admin_url( 'index.php' ) ) ), true );
		if ( $generic && ! user_can( $user, 'manage_options' ) ) {
			return $primary;
		}
		$safe = wp_validate_redirect( '' !== $requested ? $requested : (string) $redirect_to, $primary );
		return self::lands( $user, $safe ) ? $safe : $primary;
	}

	/** "My workspaces" switcher in the toolbar for people with more than one responsibility. */
	public static function admin_bar( \WP_Admin_Bar $bar ): void {
		$user = wp_get_current_user();
		if ( ! $user->exists() ) {
			return;
		}
		$d = self::destinations( $user );
		if ( count( $d ) < 2 ) {
			return;
		}
		$bar->add_node( array( 'id' => 'educore-workspaces', 'title' => esc_html__( 'My workspaces', 'educore-core' ), 'href' => false ) );
		foreach ( $d as $key => $w ) {
			$bar->add_node( array( 'parent' => 'educore-workspaces', 'id' => 'educore-ws-' . sanitize_key( $key ), 'title' => esc_html( $w['label'] ), 'href' => esc_url( $w['url'] ) ) );
		}
	}
}
