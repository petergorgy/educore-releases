<?php
namespace EduCore\Workspace;

use EduCore\Core\Audit;
use EduCore\Core\Auth\Suspension;
use EduCore\Core\Content;
use EduCore\Core\Enrollment;
use EduCore\Core\Privacy;
use EduCore\Core\Schema;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/**
 * People & profile management service. Every method re-checks the actor; callers (REST, views) cannot widen access.
 * Passwords are never set, read or returned: new accounts get WordPress's set-password e-mail.
 */
final class People {
	/** EduCore roles staff may assign. The academic manager role is assignable by WordPress administrators only. */
	public const ROLES = array( 'ec_student', 'ec_guardian', 'ec_instructor', 'ec_teacher', 'ec_tutor', 'ec_grader', 'ec_academic_manager' );

	/** Capabilities that make an account a technical (WordPress) account: never assignable or editable here. */
	public const DANGEROUS = array( 'manage_options', 'edit_users', 'create_users', 'promote_users', 'delete_users', 'install_plugins', 'activate_plugins', 'edit_plugins', 'update_core', 'edit_theme_options', 'unfiltered_html', 'switch_themes' );

	public static function role_labels(): array {
		return array(
			'ec_student'          => __( 'Student', 'educore-workspace' ),
			'ec_guardian'         => __( 'Guardian', 'educore-workspace' ),
			'ec_instructor'       => __( 'Instructor', 'educore-workspace' ),
			'ec_teacher'          => __( 'Teacher', 'educore-workspace' ),
			'ec_tutor'            => __( 'Tutor', 'educore-workspace' ),
			'ec_grader'           => __( 'Grader', 'educore-workspace' ),
			'ec_academic_manager' => __( 'Academic manager', 'educore-workspace' ),
		);
	}

	public static function can_manage( int $actor ): bool {
		return $actor > 0 && user_can( $actor, Plugin::CAP_PEOPLE );
	}

	/** @return string[] role slugs this actor may grant */
	public static function assignable( int $actor ): array {
		if ( ! self::can_manage( $actor ) ) {
			return array();
		}
		$out = array();
		foreach ( self::ROLES as $r ) {
			$role = get_role( $r );
			if ( ! $role || array_intersect( array_keys( array_filter( $role->capabilities ) ), self::DANGEROUS ) ) {
				continue; // Defence in depth: a role that ever gains a dangerous capability stops being assignable.
			}
			if ( 'ec_academic_manager' === $r && ! user_can( $actor, 'manage_options' ) ) {
				continue;
			}
			$out[] = $r;
		}
		return $out;
	}

	public static function is_technical( int $user_id ): bool {
		foreach ( self::DANGEROUS as $cap ) {
			if ( user_can( $user_id, $cap ) ) {
				return true;
			}
		}
		return false;
	}

	/** Object-level rule: may $actor change $target? */
	public static function can_edit( int $actor, int $target ): bool {
		if ( ! self::can_manage( $actor ) || ! get_userdata( $target ) ) {
			return false;
		}
		if ( self::is_technical( $target ) ) {
			return false; // Technical accounts are managed in WordPress by administrators.
		}
		if ( user_can( $target, Plugin::CAP_PEOPLE ) && ! user_can( $actor, 'manage_options' ) ) {
			return false; // Managers cannot edit other managers (or their own role); administrators can.
		}
		return true;
	}

	/**
	 * @param array{q?:string,role?:string,status?:string,page?:int} $args
	 * @return array{rows:array<int,array<string,mixed>>,total:int,pages:int}
	 */
	public static function search( int $actor, array $args ): array {
		if ( ! self::can_manage( $actor ) ) {
			return array( 'rows' => array(), 'total' => 0, 'pages' => 0 );
		}
		$per  = 25;
		$page = max( 1, (int) ( $args['page'] ?? 1 ) );
		$q    = array( 'number' => $per, 'paged' => $page, 'orderby' => 'display_name', 'order' => 'ASC', 'count_total' => true );
		$term = trim( (string) ( $args['q'] ?? '' ) );
		if ( '' !== $term ) {
			$q['search']         = '*' . $term . '*';
			$q['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
		}
		$role = (string) ( $args['role'] ?? '' );
		if ( '' !== $role && isset( self::role_labels()[ $role ] ) ) {
			$q['role'] = $role;
		}
		$status = (string) ( $args['status'] ?? '' );
		if ( 'suspended' === $status ) {
			$q['meta_key']     = Suspension::META; // phpcs:ignore WordPress.DB.SlowDBQuery
			$q['meta_compare'] = 'EXISTS';
		}
		$uq   = new \WP_User_Query( $q );
		$rows = array_map( array( self::class, 'summary' ), $uq->get_results() );
		return array( 'rows' => $rows, 'total' => (int) $uq->get_total(), 'pages' => (int) ceil( $uq->get_total() / $per ) );
	}

	public static function summary( \WP_User $u ): array {
		$labels = self::role_labels();
		return array(
			'id'        => (int) $u->ID,
			'name'      => $u->display_name,
			'email'     => $u->user_email,
			'login'     => $u->user_login,
			'roles'     => array_values( array_intersect( (array) $u->roles, array_keys( $labels ) ) ),
			'technical' => self::is_technical( (int) $u->ID ),
			'suspended' => Suspension::is_suspended( (int) $u->ID ),
			'created'   => $u->user_registered,
		);
	}

	/** Full profile for the person page (only for people the actor may see). */
	public static function profile( int $actor, int $id ): ?array {
		$u = get_userdata( $id );
		if ( ! self::can_manage( $actor ) || ! $u ) {
			return null;
		}
		global $wpdb;
		$p                = self::summary( $u );
		$p['first']       = $u->first_name;
		$p['last']        = $u->last_name;
		$p['editable']    = self::can_edit( $actor, $id );
		$p['age_band']    = (string) get_user_meta( $id, 'educore_age_band', true );
		$p['consent']     = (string) get_user_meta( $id, 'educore_consent_state', true );
		$p['enrollments'] = array();
		foreach ( Enrollment::for_user( $id ) as $e ) {
			$p['enrollments'][] = array( 'course_id' => (int) $e['course_id'], 'title' => get_the_title( (int) $e['course_id'] ), 'status' => $e['status'], 'enrolled_at' => $e['starts_at'] ?? '' );
		}
		$p['teaching'] = array();
		foreach ( Staff::courses_of( $id ) as $cid ) {
			$p['teaching'][] = array( 'course_id' => (int) $cid, 'title' => get_the_title( (int) $cid ), 'role' => Staff::role_of( $id, (int) $cid ) );
		}
		$gl              = Schema::table( 'guardian_links' );
		$p['guardians']  = $wpdb->get_results( $wpdb->prepare( "SELECT id, guardian_email, guardian_name, guardian_user_id, status, verified_at FROM {$gl} WHERE student_id=%d ORDER BY id", $id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		$p['learners']   = $wpdb->get_results( $wpdb->prepare( "SELECT id, student_id, status FROM {$gl} WHERE guardian_user_id=%d OR guardian_email=%s ORDER BY id", $id, $u->user_email ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		return $p;
	}

	/**
	 * @param array{first?:string,last?:string,email:string,login?:string,roles:array,age_band?:string,guardian_email?:string,invite?:bool} $in
	 * @return int|\WP_Error
	 */
	public static function create( int $actor, array $in ) {
		if ( ! self::can_manage( $actor ) ) {
			return new \WP_Error( 'ec_ws_forbidden', __( 'You cannot add people.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$email = sanitize_email( (string) ( $in['email'] ?? '' ) );
		if ( ! is_email( $email ) ) {
			return new \WP_Error( 'ec_ws_email', __( 'Enter a valid e-mail address.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		if ( email_exists( $email ) ) {
			return new \WP_Error( 'ec_ws_exists', __( 'An account with this e-mail address already exists.', 'educore-workspace' ), array( 'status' => 409 ) );
		}
		$roles = self::clean_roles( $actor, (array) ( $in['roles'] ?? array() ) );
		if ( is_wp_error( $roles ) ) {
			return $roles;
		}
		$login = sanitize_user( (string) ( $in['login'] ?? '' ), true );
		if ( '' === $login ) {
			$login = sanitize_user( strtok( $email, '@' ), true ) ?: 'user';
		}
		$base = $login;
		for ( $i = 2; username_exists( $login ); $i++ ) {
			$login = $base . $i;
		}
		$first = sanitize_text_field( (string) ( $in['first'] ?? '' ) );
		$last  = sanitize_text_field( (string) ( $in['last'] ?? '' ) );
		$id    = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_email'   => $email,
				'user_pass'    => wp_generate_password( 40, true, true ), // Never shown; the person sets their own.
				'first_name'   => $first,
				'last_name'    => $last,
				'display_name' => trim( $first . ' ' . $last ) ?: $login,
				'role'         => $roles[0],
			)
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$u = new \WP_User( $id );
		foreach ( array_slice( $roles, 1 ) as $r ) {
			$u->add_role( $r );
		}
		if ( in_array( 'ec_student', $roles, true ) ) {
			$band = in_array( $in['age_band'] ?? '', Privacy::AGE_BANDS, true ) ? $in['age_band'] : '18plus';
			update_user_meta( $id, 'educore_age_band', $band );
			if ( Privacy::is_minor( $id ) ) {
				update_user_meta( $id, 'educore_consent_state', 'pending_guardian' );
				$g = sanitize_email( (string) ( $in['guardian_email'] ?? '' ) );
				if ( is_email( $g ) ) {
					Privacy::request_guardian_consent( $id, $g );
				}
			}
		}
		Audit::log( 'people.created', 'user', $id, array( 'roles' => $roles ) );
		if ( ! empty( $in['invite'] ) ) {
			self::invite( $actor, $id );
		}
		return $id;
	}

	/** @return true|\WP_Error */
	public static function update( int $actor, int $id, array $in ) {
		if ( ! self::can_edit( $actor, $id ) ) {
			return new \WP_Error( 'ec_ws_forbidden', __( 'You cannot change this account.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$data = array( 'ID' => $id );
		foreach ( array( 'first' => 'first_name', 'last' => 'last_name', 'name' => 'display_name' ) as $k => $f ) {
			if ( isset( $in[ $k ] ) ) {
				$data[ $f ] = sanitize_text_field( (string) $in[ $k ] );
			}
		}
		if ( isset( $in['email'] ) ) {
			$email = sanitize_email( (string) $in['email'] );
			$owner = email_exists( $email );
			if ( ! is_email( $email ) || ( $owner && (int) $owner !== $id ) ) {
				return new \WP_Error( 'ec_ws_email', __( 'This e-mail address is invalid or already in use.', 'educore-workspace' ), array( 'status' => 400 ) );
			}
			$data['user_email'] = $email;
		}
		$r = wp_update_user( $data );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( isset( $in['roles'] ) ) {
			$roles = self::clean_roles( $actor, (array) $in['roles'] );
			if ( is_wp_error( $roles ) ) {
				return $roles;
			}
			$u = new \WP_User( $id );
			foreach ( self::ROLES as $r ) {
				if ( ! in_array( $r, $roles, true ) && in_array( $r, (array) $u->roles, true ) ) {
					$u->remove_role( $r );
				}
			}
			foreach ( $roles as $r ) {
				if ( ! in_array( $r, (array) $u->roles, true ) ) {
					$u->add_role( $r );
				}
			}
			Audit::log( 'people.roles_changed', 'user', $id, array( 'roles' => $roles ) );
		}
		Audit::log( 'people.updated', 'user', $id, array( 'fields' => array_keys( array_diff_key( $data, array( 'ID' => 1 ) ) ) ) );
		return true;
	}

	/** @return string[]|\WP_Error */
	private static function clean_roles( int $actor, array $roles ) {
		$roles = array_values( array_unique( array_map( 'sanitize_key', $roles ) ) );
		$ok    = self::assignable( $actor );
		if ( ! $roles ) {
			return new \WP_Error( 'ec_ws_role', __( 'Choose at least one role.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		$bad = array_diff( $roles, $ok );
		if ( $bad ) {
			Audit::log( 'security.role_escalation_blocked', 'user', 0, array( 'roles' => array_values( $bad ) ) );
			return new \WP_Error( 'ec_ws_role', __( 'You cannot assign one of these roles.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		return $roles;
	}

	/** @return true|\WP_Error */
	public static function set_suspended( int $actor, int $id, bool $suspended ) {
		if ( ! self::can_edit( $actor, $id ) || $actor === $id ) {
			return new \WP_Error( 'ec_ws_forbidden', __( 'You cannot change this account.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		return Suspension::set( $id, $suspended ) ? true : new \WP_Error( 'ec_ws_failed', __( 'The account status could not be changed.', 'educore-workspace' ) );
	}

	/** Account invitation: WordPress's own set-password e-mail (single-use, expiring link). */
	public static function invite( int $actor, int $id ) {
		if ( ! self::can_edit( $actor, $id ) ) {
			return new \WP_Error( 'ec_ws_forbidden', __( 'You cannot change this account.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		wp_new_user_notification( $id, null, 'user' );
		Audit::log( 'people.invited', 'user', $id );
		return true;
	}

	public static function send_reset( int $actor, int $id ) {
		if ( ! self::can_edit( $actor, $id ) ) {
			return new \WP_Error( 'ec_ws_forbidden', __( 'You cannot change this account.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$r = retrieve_password( get_userdata( $id )->user_login );
		Audit::log( 'people.reset_sent', 'user', $id, array( 'ok' => true === $r ) );
		return true === $r ? true : new \WP_Error( 'ec_ws_mail', __( 'The e-mail could not be sent. Check the site e-mail settings.', 'educore-workspace' ), array( 'status' => 502 ) );
	}

	/**
	 * Staff-verified guardian link (gives the guardian account read access to this learner in the guardian portal).
	 * Does not replace the guardian's consent for a minor's data processing: that stays the e-mail consent flow.
	 *
	 * @return int|\WP_Error link id
	 */
	public static function link_guardian( int $actor, int $student_id, int $guardian_id ) {
		if ( ! self::can_edit( $actor, $student_id ) || ! self::can_edit( $actor, $guardian_id ) ) {
			return new \WP_Error( 'ec_ws_forbidden', __( 'You cannot change these accounts.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$g = get_userdata( $guardian_id );
		if ( ! user_can( $student_id, 'ec_learn' ) || ! in_array( 'ec_guardian', (array) $g->roles, true ) || $student_id === $guardian_id ) {
			return new \WP_Error( 'ec_ws_link', __( 'Link a student account to a guardian account.', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		global $wpdb;
		$t = Schema::table( 'guardian_links' );
		$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE student_id=%d AND guardian_email=%s", $student_id, $g->user_email ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( $existing ) {
			$wpdb->update( $t, array( 'guardian_user_id' => $guardian_id, 'status' => 'verified', 'verified_at' => Schema::now() ), array( 'id' => $existing ) );
			$id = $existing;
		} else {
			$wpdb->insert( $t, array( 'student_id' => $student_id, 'guardian_email' => $g->user_email, 'guardian_name' => $g->display_name, 'guardian_user_id' => $guardian_id, 'status' => 'verified', 'created_at' => Schema::now(), 'verified_at' => Schema::now() ) );
			$id = (int) $wpdb->insert_id;
		}
		Audit::log( 'people.guardian_linked', 'user', $student_id, array( 'guardian_id' => $guardian_id, 'link_id' => $id, 'verified_by' => 'staff' ) );
		return $id;
	}

	public static function unlink_guardian( int $actor, int $link_id ) {
		global $wpdb;
		$t   = Schema::table( 'guardian_links' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $link_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( ! $row || ! self::can_edit( $actor, (int) $row['student_id'] ) ) {
			return new \WP_Error( 'ec_ws_forbidden', __( 'You cannot change this link.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$wpdb->update( $t, array( 'status' => 'revoked' ), array( 'id' => $link_id ) );
		Audit::log( 'people.guardian_unlinked', 'user', (int) $row['student_id'], array( 'link_id' => $link_id ) );
		return true;
	}

	/** Assign (or remove) a teaching role on a course. Needs the course-wide management capability. */
	public static function assign_course( int $actor, int $course_id, int $user_id, string $role ) {
		$may_edit_person = self::can_edit( $actor, $user_id ) || $actor === $user_id;
		if ( ! user_can( $actor, 'ec_manage_all_courses' ) || ! Content::is_course( $course_id ) || ! $may_edit_person ) {
			return new \WP_Error( 'ec_ws_forbidden', __( 'You cannot change the teaching team of this course.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		if ( 'remove' === $role ) {
			Staff::remove( $course_id, $user_id );
			return true;
		}
		if ( ! user_can( $user_id, 'ec_access_workspace' ) ) {
			return new \WP_Error( 'ec_ws_staff', __( 'Give this person a teaching role first (instructor, teacher or grader).', 'educore-workspace' ), array( 'status' => 400 ) );
		}
		return Staff::assign( $course_id, $user_id, $role ) ? true : new \WP_Error( 'ec_ws_staff', __( 'The assignment could not be saved.', 'educore-workspace' ), array( 'status' => 400 ) );
	}

	/** Enroll or change an enrollment (uses the course enrollment capability). */
	public static function enroll( int $actor, int $course_id, int $user_id ) {
		if ( ! user_can( $actor, 'ec_manage_course_enrollments', $course_id ) || ! self::can_edit( $actor, $user_id ) ) {
			return new \WP_Error( 'ec_ws_forbidden', __( 'You cannot enroll people in this course.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$r = Enrollment::enroll( $user_id, $course_id, 'admin' );
		return is_wp_error( $r ) ? $r : true;
	}
}
