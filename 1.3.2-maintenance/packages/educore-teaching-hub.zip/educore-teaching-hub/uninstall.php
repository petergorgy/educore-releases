<?php
/**
 * EduCore Teaching Hub uninstall. Data is removed only when the site owner opted in
 * (EduCore → Settings → "Delete data on uninstall" = yes). Roles/caps are always removed.
 *
 * @package EduCore\TeachingHub
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'ec_teacher', 'ec_tutor' ) as $role ) {
	remove_role( $role );
}
foreach ( wp_roles()->role_objects as $r ) {
	foreach ( array( 'ec_teach', 'ec_tutor_sessions', 'ec_manage_teaching', 'ec_approve_tutors', 'ec_review_reports' ) as $cap ) {
		$r->remove_cap( $cap );
	}
}
wp_clear_scheduled_hook( 'educore_th_daily' );

if ( 'yes' !== get_option( 'educore_uninstall_delete_data' ) ) {
	return;
}
global $wpdb;
foreach ( array( 'th_classes', 'th_class_staff', 'th_class_members', 'th_groups', 'th_group_members', 'th_lesson_plans', 'th_assignments', 'th_assignment_targets', 'th_submissions', 'th_grade_log', 'th_attendance', 'th_tutor_profiles', 'th_availability', 'th_unavailable', 'th_sessions', 'th_slot_locks', 'th_threads', 'th_messages', 'th_reports' ) as $t ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'ec_' . $t ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery.SchemaChange
}
foreach ( array( 'educore_th_db_version', 'educore_th_settings', 'educore_th_pages', 'educore_th_caps_version', 'educore_th_installed' ) as $o ) {
	delete_option( $o );
}
delete_metadata( 'user', 0, 'educore_th_attention', '', true );
$up  = wp_upload_dir( null, false );
$dir = trailingslashit( $up['basedir'] ) . 'educore-teaching-hub';
if ( is_dir( $dir ) ) {
	foreach ( (array) glob( $dir . '/{,.}*', GLOB_BRACE ) as $f ) {
		if ( is_file( $f ) ) {
			wp_delete_file( $f );
		}
	}
	rmdir( $dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions
}
