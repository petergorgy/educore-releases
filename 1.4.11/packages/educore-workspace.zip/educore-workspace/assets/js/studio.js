/* EduCore Course Studio: media picker, accessible outline ordering, rename, lesson autosave. Event delegation, so it
   keeps working after the shell's partial refreshes. */
( function () {
	'use strict';
	var app = window.EduCoreWSApp;
	var t = ( window.EduCoreWS && window.EduCoreWS.i18n ) || {};
	if ( ! app ) { return; }

	// ---------- Media picker (WordPress media library) ----------
	document.addEventListener( 'click', function ( e ) {
		var pick = e.target.closest( '[data-ec-media-pick]' );
		var clear = e.target.closest( '[data-ec-media-clear]' );
		var box = ( pick || clear ) && ( pick || clear ).closest( '[data-ec-media]' );
		if ( ! box ) { return; }
		var input = box.querySelector( 'input[type="hidden"]' );
		var preview = box.querySelector( '.ec-studio-cover__preview' );
		var clr = box.querySelector( '[data-ec-media-clear]' );
		if ( clear ) {
			input.value = '0'; preview.innerHTML = ''; clr.hidden = true; app.setDirty( true ); return;
		}
		if ( ! window.wp || ! wp.media ) { return; }
		var frame = wp.media( { title: box.dataset.ecMediaTitle, library: { type: 'image' }, multiple: false } );
		frame.on( 'select', function () {
			var a = frame.state().get( 'selection' ).first().toJSON();
			input.value = a.id;
			var url = ( a.sizes && a.sizes.medium && a.sizes.medium.url ) || a.url;
			preview.innerHTML = '';
			var img = document.createElement( 'img' ); img.src = url; img.alt = ''; preview.appendChild( img );
			clr.hidden = false; app.setDirty( true );
		} );
		frame.open();
	} );

	// ---------- Outline ordering ----------
	function outlineEl() { return document.querySelector( '[data-ec-outline]' ); }
	function changed() {
		var b = document.querySelector( '[data-ec-save-order]' );
		if ( b ) { b.hidden = false; }
		app.setDirty( true );
		app.toast( t.orderChanged );
	}
	function serialize() {
		return Array.prototype.map.call( outlineEl().querySelectorAll( ':scope > .ec-studio-unit' ), function ( u ) {
			return { unit: Number( u.dataset.unit ), lessons: Array.prototype.map.call( u.querySelectorAll( '.ec-studio-lesson' ), function ( l ) { return Number( l.dataset.lesson ); } ) };
		} );
	}
	document.addEventListener( 'click', function ( e ) {
		var mv = e.target.closest( '[data-ec-move]' );
		if ( mv ) {
			var item = mv.closest( '.ec-studio-lesson' ) || mv.closest( '.ec-studio-unit' );
			var dir = Number( mv.dataset.ecMove );
			var isLesson = item.classList.contains( 'ec-studio-lesson' );
			var sib = dir < 0 ? item.previousElementSibling : item.nextElementSibling;
			if ( sib ) {
				item.parentNode.insertBefore( item, dir < 0 ? sib : sib.nextElementSibling );
			} else if ( isLesson ) {
				// Move a lesson into the previous/next unit.
				var unit = item.closest( '.ec-studio-unit' );
				var other = dir < 0 ? unit.previousElementSibling : unit.nextElementSibling;
				if ( other ) {
					var list = other.querySelector( '.ec-studio-lessons' );
					if ( dir < 0 ) { list.appendChild( item ); } else { list.insertBefore( item, list.firstChild ); }
				} else { return; }
			} else { return; }
			mv.focus();
			changed();
			return;
		}
		var save = e.target.closest( '[data-ec-save-order]' );
		if ( save ) {
			save.setAttribute( 'aria-busy', 'true' );
			app.api( 'studio/courses/' + outlineEl().dataset.ecOutline + '/outline', 'POST', { outline: serialize() } ).then( function () {
				app.setDirty( false ); app.toast( t.saved ); return app.refresh();
			} ).catch( function ( err ) { save.removeAttribute( 'aria-busy' ); app.toast( err.message || t.error, 'error' ); } );
			return;
		}
		var rn = e.target.closest( '[data-ec-rename]' );
		if ( rn ) {
			var v = window.prompt( t.renamePrompt, rn.dataset.ecCurrent || '' );
			if ( v === null || ! v.trim() ) { return; }
			app.api( 'studio/items/' + rn.dataset.ecRename, 'POST', { title: v.trim() } ).then( function () { app.toast( t.saved ); return app.refresh(); } ).catch( function ( err ) { app.toast( err.message || t.error, 'error' ); } );
		}
	} );
	var dragged = null;
	document.addEventListener( 'dragstart', function ( e ) {
		var it = e.target.closest && e.target.closest( '.ec-studio-lesson, .ec-studio-unit' );
		if ( ! it || ! it.closest( '[data-ec-outline]' ) ) { return; }
		e.stopPropagation();
		dragged = it; it.classList.add( 'is-dragging' );
		e.dataTransfer.effectAllowed = 'move';
		try { e.dataTransfer.setData( 'text/plain', '' ); } catch ( err ) { /* old browsers */ }
	} );
	document.addEventListener( 'dragend', function () { if ( dragged ) { dragged.classList.remove( 'is-dragging' ); dragged = null; } } );
	document.addEventListener( 'dragover', function ( e ) {
		if ( ! dragged ) { return; }
		var lessonDrag = dragged.classList.contains( 'ec-studio-lesson' );
		var target = e.target.closest( lessonDrag ? '.ec-studio-lesson, .ec-studio-lessons' : '.ec-studio-unit' );
		if ( ! target || target === dragged || dragged.contains( target ) ) { return; }
		e.preventDefault();
		if ( target.classList.contains( 'ec-studio-lessons' ) ) {
			if ( ! target.children.length ) { target.appendChild( dragged ); }
			return;
		}
		var r = target.getBoundingClientRect();
		var after = e.clientY > r.top + r.height / 2;
		target.parentNode.insertBefore( dragged, after ? target.nextElementSibling : target );
	} );
	document.addEventListener( 'drop', function ( e ) { if ( dragged ) { e.preventDefault(); changed(); } } );

	// ---------- Lesson autosave and restore ----------
	var form = document.querySelector( 'form[data-ec-autosave]' );
	if ( form ) {
		var status = form.querySelector( '[data-ec-autosave-status]' );
		var watch = function () {
			if ( window.tinymce ) {
				window.tinymce.editors.forEach( function ( ed ) { ed.on( 'input change undo redo', function () { app.setDirty( true ); } ); } );
			}
		};
		if ( window.tinymce && window.tinymce.editors.length ) { watch(); } else { setTimeout( watch, 1500 ); }
		setInterval( function () {
			if ( ! app.isDirty() || ! navigator.onLine ) { return; }
			if ( window.tinymce ) { window.tinymce.triggerSave(); }
			var data = { title: ( form.querySelector( '[name="title"]' ) || {} ).value || '', content: ( form.querySelector( '[name="content"]' ) || {} ).value || '' };
			app.api( form.dataset.ecAutosave, 'POST', data ).then( function () {
				if ( status ) { status.textContent = ( t.autosaved || '%s' ).replace( '%s', new Date().toLocaleTimeString() ); }
			} ).catch( function () { /* manual save still available */ } );
		}, 30000 );
	}
	document.addEventListener( 'click', function ( e ) {
		if ( ! e.target.closest( '[data-ec-restore-autosave]' ) ) { return; }
		var raw = document.querySelector( '[data-ec-autosave-data]' );
		if ( ! raw ) { return; }
		var d = JSON.parse( raw.textContent );
		var f = document.querySelector( 'form[data-ec-autosave]' );
		f.querySelector( '[name="title"]' ).value = d.title || f.querySelector( '[name="title"]' ).value;
		var ed = window.tinymce && window.tinymce.get( 'ec-lesson-body' );
		if ( ed && ! ed.isHidden() ) { ed.setContent( d.content || '' ); } else { f.querySelector( '[name="content"]' ).value = d.content || ''; }
		app.setDirty( true );
		var n = document.querySelector( '[data-ec-autosave-notice]' ); if ( n ) { n.hidden = true; }
		app.toast( t.restored );
	} );
}() );
