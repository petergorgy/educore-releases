<?php
namespace EduCore\Analytics;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Daily aggregate cache (ec_analytics_daily). Only completed past days are cached; today and any
 * missing day are computed live, so results are correct with an empty cache.
 * Cached metrics (global, unfiltered scope): dau, wau, lesson_completions (dim course), new_enrollments (dim course).
 */
final class Aggregator {
	public const HOOK = 'educore_analytics_daily';

	public static function register(): void {
		add_action( self::HOOK, array( self::class, 'run' ) );
		add_action(
			'init',
			static function () {
				if ( ! wp_next_scheduled( self::HOOK ) ) {
					wp_schedule_event( time() + 900, 'daily', self::HOOK );
				}
			}
		);
	}

	/** Cron: (re)compute the last 3 complete days. Idempotent upserts. */
	public static function run( ?int $now = null ): int {
		$now = $now ?? time();
		$n   = 0;
		for ( $i = 1; $i <= 3; $i++ ) {
			$n += self::compute_day( gmdate( 'Y-m-d', $now - $i * DAY_IN_SECONDS ) );
		}
		return $n;
	}

	public static function compute_day( string $day ): int {
		global $wpdb;
		$f = new Filters( array( 'from' => $day, 'to' => $day ) );
		self::put( 'dau', 'global', 0, $day, Metrics::dau( $day, $f ) );
		self::put( 'wau', 'global', 0, $day, Metrics::wau( $day, $f ) );
		$n  = 2;
		$lp = Schema::table( 'lesson_progress' );
		$en = Schema::table( 'enrollments' );
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT course_id, COUNT(*) c FROM {$lp} WHERE state='completed' AND completed_at BETWEEN %s AND %s GROUP BY course_id", $day . ' 00:00:00', $day . ' 23:59:59' ), ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			self::put( 'lesson_completions', 'course', (int) $r['course_id'], $day, (int) $r['c'] );
			++$n;
		}
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT course_id, COUNT(*) c FROM {$en} WHERE starts_at BETWEEN %s AND %s GROUP BY course_id", $day . ' 00:00:00', $day . ' 23:59:59' ), ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			self::put( 'new_enrollments', 'course', (int) $r['course_id'], $day, (int) $r['c'] );
			++$n;
		}
		return $n;
	}

	public static function put( string $metric, string $dim_type, int $dim_id, string $day, float $value ): void {
		global $wpdb;
		$t = Schema::table( 'analytics_daily' );
		$wpdb->query( $wpdb->prepare( "INSERT INTO {$t} (metric,dim_type,dim_id,day,value,computed_at) VALUES (%s,%s,%d,%s,%f,%s) ON DUPLICATE KEY UPDATE value=VALUES(value), computed_at=VALUES(computed_at)", $metric, $dim_type, $dim_id, $day, $value, Schema::now() ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function get( string $metric, string $day, string $dim_type = 'global', int $dim_id = 0 ): ?float {
		global $wpdb;
		$v = $wpdb->get_var( $wpdb->prepare( 'SELECT value FROM ' . Schema::table( 'analytics_daily' ) . ' WHERE metric=%s AND dim_type=%s AND dim_id=%d AND day=%s', $metric, $dim_type, $dim_id, $day ) );
		return null === $v ? null : (float) $v;
	}

	/**
	 * Daily DAU/WAU series. Uses the cache only for unfiltered scopes (all courses, no cohort) and
	 * only for completed days; otherwise computes live.
	 *
	 * @return array<string,int> day => value
	 */
	public static function series( string $metric, Filters $f, bool $unfiltered ): array {
		$out   = array();
		$today = gmdate( 'Y-m-d', $f->now );
		$d     = $f->from;
		$guard = 0;
		while ( $d <= $f->to && $guard++ < 400 ) {
			$cached = ( $unfiltered && $d < $today ) ? self::get( $metric, $d ) : null;
			if ( null === $cached ) {
				$val = 'wau' === $metric ? Metrics::wau( $d, $f ) : Metrics::dau( $d, $f );
				if ( $unfiltered && $d < $today ) {
					self::put( $metric, 'global', 0, $d, $val );
				}
				$cached = $val;
			}
			$out[ $d ] = (int) $cached;
			$d         = gmdate( 'Y-m-d', strtotime( $d . ' +1 day' ) );
		}
		return $out;
	}
}
