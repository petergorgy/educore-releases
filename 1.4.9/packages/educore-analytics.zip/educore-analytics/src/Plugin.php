<?php
namespace EduCore\Analytics;

use EduCore\Core\Registry;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	private static bool $booted = false;

	public static function tables(): array {
		return array(
			'analytics_daily' => 'id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				metric VARCHAR(40) NOT NULL,
				dim_type VARCHAR(20) NOT NULL DEFAULT \'global\',
				dim_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				day DATE NOT NULL,
				value DECIMAL(14,4) NOT NULL DEFAULT 0,
				computed_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY metric_dim_day (metric,dim_type,dim_id,day),
				KEY day (day)',
		);
	}

	public static function install(): void {
		Schema::migrate( 'educore_analytics_db_version', EDUCORE_ANALYTICS_DB_VERSION, self::tables() );
	}

	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;
		add_action( 'educore/events/lesson_completed', array( Metrics::class, 'flush_cache' ) );
		add_action( 'educore/events/enrolled', array( Metrics::class, 'flush_cache' ) );
		Registry::register( 'analytics', EDUCORE_ANALYTICS_VERSION );
		self::install();
		add_action( 'educore/install/repair', array( self::class, 'repair' ) );
		add_action( 'init', static fn() => load_plugin_textdomain( 'educore-analytics', false, dirname( plugin_basename( EDUCORE_ANALYTICS_FILE ) ) . '/languages' ) );

		Aggregator::register();
		Rest::register();
		Block::register();
		add_filter( 'educore/admin/overview_tiles', array( Admin::class, 'overview_tiles' ) );
		if ( is_admin() ) {
			Admin::register();
		}
	}

	public static function repair(): void {
		delete_option( 'educore_analytics_db_version' );
		self::install();
	}
}
