<?php
namespace EduCore\Experience;

use EduCore\Core\I18n;
use EduCore\Core\Pages as CorePages;

defined( 'ABSPATH' ) || exit;

/**
 * Welcome tour. After a person's first sign-in their home page opens with an invitation to the tour (new accounts get a
 * prominent banner, existing accounts a line on the welcome card). Sign-in itself is never redirected, so role routing
 * and deep links are unchanged; every step can be skipped and nothing blocks access to learning.
 * School-age learners are never asked for extra personal details.
 */
final class Onboarding {
	public static function register(): void {
		add_shortcode( 'educore_welcome', array( self::class, 'render' ) );
		add_action( 'admin_post_educore_xp_onboard', array( self::class, 'save' ) );
		add_filter( 'educore/experience/facts', array( self::class, 'invite' ), 50, 3 );
	}

	public static function steps( int $uid ): array {
		$s = array(
			'hello'      => __( 'Welcome', 'educore-experience' ),
			'name'       => __( 'Your name', 'educore-experience' ),
			'language'   => __( 'Language and time', 'educore-experience' ),
			'look'       => __( 'Appearance', 'educore-experience' ),
			'access'     => __( 'Reading comfort', 'educore-experience' ),
		);
		if ( user_can( $uid, 'ec_learn' ) ) {
			if ( Prefs::subjects() ) {
				$s['interests'] = __( 'Interests', 'educore-experience' );
			}
			$s['courses'] = __( 'Your courses', 'educore-experience' );
		}
		$s['done'] = __( 'All set', 'educore-experience' );
		return $s;
	}

	public static function needed( int $uid ): bool {
		if ( ! Settings::get( 'onboarding_enabled' ) || '' !== Prefs::get( $uid )['onboarded_at'] ) {
			return false;
		}
		return true;
	}

	/** New account (created after the experience engine was installed) that has not taken or skipped the tour. */
	public static function is_new( int $uid ): bool {
		$installed = (string) get_option( 'educore_xp_installed_at', '' );
		$u         = get_userdata( $uid );
		return $u && '' !== $installed && strtotime( $u->user_registered . ' UTC' ) >= strtotime( $installed . ' UTC' ) && self::needed( $uid );
	}

	/** Prominent first-visit banner for new accounts. */
	public static function banner( int $uid ): string {
		if ( ! self::is_new( $uid ) ) {
			return '';
		}
		return '<section class="ec-xp-firstrun ec-card" aria-labelledby="ec-xp-firstrun-h"><div><h2 id="ec-xp-firstrun-h">' . esc_html__( 'Welcome to EduCore!', 'educore-experience' ) . '</h2><p>' . esc_html__( 'Take a two-minute tour to choose your name, language, time zone and look. Every step is optional.', 'educore-experience' ) . '</p></div>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="ec-xp-firstrun__actions"><input type="hidden" name="action" value="educore_xp_onboard"><input type="hidden" name="step" value="hello">' . wp_nonce_field( 'educore_xp_onboard', '_wpnonce', true, false )
			. '<a class="ec-btn ec-btn--primary" href="' . esc_url( Plugin::url( 'welcome' ) ) . '">' . esc_html__( 'Start the tour', 'educore-experience' ) . '</a> <button type="submit" name="go" value="exit" class="ec-btn ec-btn--ghost">' . esc_html__( 'Not now', 'educore-experience' ) . '</button></form></section>';
	}

	public static function invite( $facts, $uid, $lens ) {
		if ( self::needed( (int) $uid ) && ! self::is_new( (int) $uid ) ) {
			$facts   = (array) $facts;
			$facts[] = array( 'kind' => 'tour', 'text' => __( 'Make EduCore yours: take the two-minute welcome tour.', 'educore-experience' ), 'url' => Plugin::url( 'welcome' ) );
		}
		return $facts;
	}

	public static function render(): string {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return '<div class="ec-card"><p><a class="ec-btn ec-btn--primary" href="' . esc_url( wp_login_url( Plugin::url( 'welcome' ) ) ) . '">' . esc_html__( 'Sign in', 'educore-experience' ) . '</a></p></div>';
		}
		$steps = self::steps( $uid );
		$keys  = array_keys( $steps );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- navigation only.
		$step  = sanitize_key( $_GET['step'] ?? 'hello' );
		$next  = esc_url_raw( wp_unslash( $_GET['next'] ?? '' ) );
		// phpcs:enable
		if ( ! isset( $steps[ $step ] ) ) {
			$step = 'hello';
		}
		$i = array_search( $step, $keys, true );
		if ( class_exists( '\EduCore\Workspace\Shell' ) ) {
			\EduCore\Workspace\Shell::title( __( 'Welcome to EduCore', 'educore-experience' ) );
		}
		$p    = Prefs::get( $uid );
		$o    = '<div class="ec-xp-tour ec-card">';
		/* translators: 1: step number, 2: number of steps */
		$o   .= '<p class="ec-xp-tour__progress">' . esc_html( sprintf( __( 'Step %1$s of %2$s', 'educore-experience' ), number_format_i18n( $i + 1 ), number_format_i18n( count( $keys ) ) ) ) . '</p>';
		$o   .= '<ol class="ec-xp-tour__steps" aria-label="' . esc_attr__( 'Tour steps', 'educore-experience' ) . '">';
		foreach ( $keys as $n => $k ) {
			$o .= '<li class="' . ( $n < $i ? 'is-done' : ( $n === $i ? 'is-current' : '' ) ) . '"' . ( $n === $i ? ' aria-current="step"' : '' ) . '>' . esc_html( $steps[ $k ] ) . '</li>';
		}
		$o .= '</ol><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="ec-xp-tour__form">';
		$o .= '<input type="hidden" name="action" value="educore_xp_onboard"><input type="hidden" name="step" value="' . esc_attr( $step ) . '"><input type="hidden" name="next" value="' . esc_attr( $next ) . '">' . wp_nonce_field( 'educore_xp_onboard', '_wpnonce', true, false );
		$o .= '<h2 class="ec-xp-tour__title">' . esc_html( $steps[ $step ] ) . '</h2>';
		switch ( $step ) {
			case 'hello':
				$o .= '<p class="ec-lead">' . esc_html( self::hello_text( Plugin::lens( $uid ) ) ) . '</p><p class="ec-muted">' . esc_html__( 'A few quick choices make EduCore feel like yours. Every step is optional, and you can change everything later in Preferences.', 'educore-experience' ) . '</p>';
				break;
			case 'name':
				$o .= '<p class="ec-field"><label for="ec-xp-pn">' . esc_html__( 'What should we call you? (optional)', 'educore-experience' ) . '</label><input id="ec-xp-pn" type="text" name="preferred_name" maxlength="60" value="' . esc_attr( $p['preferred_name'] ) . '" autocomplete="off"></p>';
				$o .= '<p class="ec-xp-check"><label><input type="checkbox" name="greet_by_name" value="1"' . checked( $p['greet_by_name'], true, false ) . '> ' . esc_html__( 'Greet me by name', 'educore-experience' ) . '</label></p>';
				break;
			case 'language':
				$lang = I18n::sanitize_lang( get_user_meta( $uid, 'educore_lang', true ) ?: I18n::current() );
				$o   .= '<fieldset class="ec-xp-sub"><legend>' . esc_html__( 'Language', 'educore-experience' ) . '</legend>';
				foreach ( I18n::labels() as $code => $label ) {
					$o .= '<label class="ec-xp-check" lang="' . esc_attr( $code ) . '"><input type="radio" name="lang" value="' . esc_attr( $code ) . '"' . checked( $lang, $code, false ) . '> ' . esc_html( $label ) . '</label>';
				}
				$def = (string) ( Settings::get( 'institution_tz' ) ?: wp_timezone_string() );
				/* translators: %s: time zone */
				$o  .= '</fieldset><p class="ec-field"><label for="ec-xp-tz">' . esc_html__( 'Time zone', 'educore-experience' ) . '</label>' . Settings::tz_select( 'timezone', (string) $p['timezone'], 'ec-xp-tz', sprintf( __( 'School default (%s)', 'educore-experience' ), str_replace( '_', ' ', $def ) ) ) . '<span class="ec-field__help ec-muted" data-ec-xp-tzsuggest></span></p>';
				break;
			case 'look':
				$o .= '<div class="ec-xp-modes" role="radiogroup" aria-label="' . esc_attr__( 'Appearance', 'educore-experience' ) . '">';
				foreach ( array_slice( Appearance::mode_labels(), 0, 5, true ) as $k => $l ) {
					$o .= '<label class="ec-xp-mode" data-ec-xp-swatch="' . esc_attr( $k ) . '"><input type="radio" name="appearance" value="' . esc_attr( $k ) . '"' . checked( $p['appearance'], $k, false ) . '><span class="ec-xp-mode__chip" aria-hidden="true"></span><span>' . esc_html( $l ) . '</span></label>';
				}
				$o .= '</div><p class="ec-muted">' . esc_html__( 'You can also pick one fixed time-of-day look, like Dawn or Night, in Preferences.', 'educore-experience' ) . '</p>';
				break;
			case 'access':
				$o .= '<p class="ec-field"><label for="ec-xp-fs">' . esc_html__( 'Text size', 'educore-experience' ) . '</label><select id="ec-xp-fs" name="font_scale">';
				foreach ( array( 90 => __( 'Smaller', 'educore-experience' ), 100 => __( 'Standard', 'educore-experience' ), 110 => __( 'Larger', 'educore-experience' ), 125 => __( 'Large', 'educore-experience' ), 150 => __( 'Extra large', 'educore-experience' ) ) as $k => $l ) {
					$o .= '<option value="' . esc_attr( (string) $k ) . '"' . selected( $p['font_scale'], $k, false ) . '>' . esc_html( $l ) . '</option>';
				}
				$o .= '</select></p>';
				$o .= '<p class="ec-xp-check"><label><input type="checkbox" name="contrast" value="high"' . checked( 'high' === $p['contrast'], true, false ) . '> ' . esc_html__( 'High contrast', 'educore-experience' ) . '</label></p>';
				$o .= '<p class="ec-xp-check"><label><input type="checkbox" name="motion" value="reduce"' . checked( 'reduce' === $p['motion'], true, false ) . '> ' . esc_html__( 'Reduce motion and animations', 'educore-experience' ) . '</label></p>';
				$o .= '<p class="ec-xp-check"><label><input type="checkbox" name="reading" value="spacious"' . checked( 'spacious' === $p['reading'], true, false ) . '> ' . esc_html__( 'More space between lines in lessons', 'educore-experience' ) . '</label></p>';
				break;
			case 'interests':
				$o .= '<fieldset class="ec-xp-sub"><legend>' . esc_html__( 'Which subjects interest you? (optional)', 'educore-experience' ) . '</legend>';
				foreach ( Prefs::subjects() as $s ) {
					$o .= '<label class="ec-xp-check"><input type="checkbox" name="interests[]" value="' . esc_attr( (string) $s['id'] ) . '"' . checked( in_array( $s['id'], $p['interests'], true ), true, false ) . '> ' . esc_html( $s['name'] ) . '</label>';
				}
				$o .= '</fieldset>';
				break;
			case 'courses':
				$d  = Facts::dashboard( $uid );
				$cs = (array) ( $d['courses'] ?? array() );
				if ( $cs ) {
					$o .= '<p>' . esc_html__( 'These are your courses:', 'educore-experience' ) . '</p><ul class="ec-xp-tour__courses">';
					foreach ( array_slice( $cs, 0, 6 ) as $c ) {
						$o .= '<li><a href="' . esc_url( $c['url'] ) . '">' . esc_html( $c['title'] ) . '</a></li>';
					}
					$o .= '</ul>';
				} else {
					$o .= '<p class="ec-xp-empty">' . esc_html__( 'No courses yet. Your courses will appear here and on My learning once you are enrolled.', 'educore-experience' ) . ' <a href="' . esc_url( CorePages::url( 'courses' ) ) . '">' . esc_html__( 'Browse the course catalogue', 'educore-experience' ) . '</a></p>';
				}
				break;
			case 'done':
				$o .= '<p class="ec-lead">' . esc_html__( 'You are all set. Your choices are saved to your account and follow you on every device.', 'educore-experience' ) . '</p><p class="ec-muted">' . esc_html__( 'Change them any time from your account menu → Preferences.', 'educore-experience' ) . '</p>';
				break;
		}
		$o .= '<div class="ec-xp-tour__nav">';
		if ( $i > 0 && 'done' !== $step ) {
			$o .= '<button type="submit" name="go" value="back" class="ec-btn" formnovalidate>' . esc_html__( 'Back', 'educore-experience' ) . '</button> ';
		}
		$o .= 'done' === $step
			? '<button type="submit" name="go" value="finish" class="ec-btn ec-btn--primary">' . esc_html__( 'Go to my dashboard', 'educore-experience' ) . '</button>'
			: '<button type="submit" name="go" value="next" class="ec-btn ec-btn--primary">' . esc_html( 'hello' === $step ? __( 'Start', 'educore-experience' ) : __( 'Save and continue', 'educore-experience' ) ) . '</button> <button type="submit" name="go" value="skip" class="ec-btn ec-btn--ghost" formnovalidate>' . esc_html__( 'Skip this step', 'educore-experience' ) . '</button>';
		$o .= '</div>';
		if ( 'done' !== $step ) {
			$o .= '<p class="ec-xp-tour__exit"><button type="submit" name="go" value="exit" class="ec-link" formnovalidate>' . esc_html__( 'Skip the tour and go to my dashboard', 'educore-experience' ) . '</button></p>';
		}
		return $o . '</form></div>';
	}

	private static function hello_text( string $lens ): string {
		$t = array(
			'student'    => __( 'EduCore is where you follow your courses, practise, take assessments and see your progress.', 'educore-experience' ),
			'guardian'   => __( 'EduCore shows you the progress, deadlines and results the school shares about your linked learners.', 'educore-experience' ),
			'teacher'    => __( 'EduCore brings your classes, grading, attendance and teaching calendar together in one place.', 'educore-experience' ),
			'instructor' => __( 'EduCore helps you build courses, manage question banks and follow how your learners are doing.', 'educore-experience' ),
			'tutor'      => __( 'EduCore keeps your tutoring sessions, availability and learners in one place.', 'educore-experience' ),
			'manager'    => __( 'EduCore Management gives you programmes, people, courses and learning analytics in one place.', 'educore-experience' ),
			'admin'      => __( 'EduCore Management gives you programmes, people, platform health and settings in one place.', 'educore-experience' ),
		);
		return $t[ $lens ] ?? $t['student'];
	}

	public static function save(): void {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'educore_xp_onboard' ) ) {
			wp_die( esc_html__( 'Please sign in again.', 'educore-experience' ), 403 );
		}
		$in    = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validated in Prefs::update().
		$step  = sanitize_key( (string) ( $in['step'] ?? 'hello' ) );
		$go    = sanitize_key( (string) ( $in['go'] ?? 'next' ) );
		$next  = wp_validate_redirect( (string) ( $in['next'] ?? '' ), '' );
		$keys  = array_keys( self::steps( $uid ) );
		$i     = (int) array_search( $step, $keys, true );
		$home  = $next ?: ( class_exists( '\EduCore\Core\Auth\Router' ) ? \EduCore\Core\Auth\Router::primary( get_userdata( $uid ) ) : home_url( '/' ) );
		if ( 'next' === $go ) {
			$u = array();
			switch ( $step ) {
				case 'name':
					$u = array( 'preferred_name' => (string) ( $in['preferred_name'] ?? '' ), 'greet_by_name' => ! empty( $in['greet_by_name'] ) );
					break;
				case 'language':
					$u = array( 'timezone' => (string) ( $in['timezone'] ?? '' ) );
					if ( isset( $in['lang'] ) ) {
						update_user_meta( $uid, 'educore_lang', I18n::sanitize_lang( (string) $in['lang'] ) );
					}
					break;
				case 'look':
					$u = array( 'appearance' => (string) ( $in['appearance'] ?? 'auto' ) );
					break;
				case 'access':
					$u = array( 'font_scale' => (int) ( $in['font_scale'] ?? 100 ), 'contrast' => empty( $in['contrast'] ) ? 'standard' : 'high', 'motion' => empty( $in['motion'] ) ? 'system' : 'reduce', 'reading' => empty( $in['reading'] ) ? 'standard' : 'spacious' );
					break;
				case 'interests':
					$u = array( 'interests' => (array) ( $in['interests'] ?? array() ) );
					break;
			}
			if ( $u ) {
				$res = Prefs::update( $uid, $u );
				if ( is_wp_error( $res ) ) {
					wp_safe_redirect( add_query_arg( array( 'step' => $step, 'next' => rawurlencode( $next ) ), Plugin::url( 'welcome' ) ) );
					exit;
				}
			}
		}
		if ( in_array( $go, array( 'exit', 'finish' ), true ) ) {
			Prefs::update( $uid, array( 'onboarded' => true ) );
			\EduCore\Core\Audit::log( 'experience.onboarding_' . ( 'finish' === $go ? 'completed' : 'skipped' ), 'user', $uid, array( 'step' => $step ) );
			wp_safe_redirect( $home );
			exit;
		}
		$to = 'back' === $go ? max( 0, $i - 1 ) : min( count( $keys ) - 1, $i + 1 );
		$args = array( 'step' => $keys[ $to ] );
		if ( $next ) {
			$args['next'] = rawurlencode( $next );
		}
		if ( 'language' === $step && isset( $in['lang'] ) ) {
			$args['lang'] = I18n::sanitize_lang( (string) $in['lang'] );
		}
		wp_safe_redirect( add_query_arg( $args, Plugin::url( 'welcome' ) ) );
		exit;
	}
}
