<?php
namespace EduCore\Workspace;

use EduCore\Core\Access;
use EduCore\Core\Branding;
use EduCore\Core\I18n;

defined( 'ABSPATH' ) || exit;

/**
 * The EduCore application shell. Workspace pages render their content first (existing blocks and views), then the
 * layout prints around it: sidebar, top bar (search, notifications, quick actions, workspace switcher, language,
 * theme, account), breadcrumbs. `?partial=1` returns only the main region for in-place refreshes.
 */
final class Shell {
	private static ?string $ws        = null;
	private static ?array $nav        = null;
	private static string $nav_label  = '';
	private static array $crumbs      = array();
	private static string $title      = '';
	private static string $page_acts  = '';

	public static function register(): void {
		add_filter( 'template_include', array( self::class, 'template' ), 99 );
		add_action( 'wp_enqueue_scripts', array( self::class, 'assets' ), 20 );
		add_filter( 'show_admin_bar', array( self::class, 'admin_bar' ), 20 );
	}

	/** True while a workspace page is being rendered inside the shell. */
	public static function active(): bool {
		return null !== self::$ws;
	}

	public static function workspace(): ?string {
		return self::$ws;
	}

	/** Called by modules (e.g. the Teaching Hub) that bring their own section navigation. */
	public static function nav( array $items, string $label = '' ): void {
		self::$nav       = $items;
		self::$nav_label = $label;
	}

	/** @param array<int,array{0:string,1?:string}> $crumbs [label, url] pairs, last one is the current page. */
	public static function crumbs( array $crumbs ): void {
		self::$crumbs = $crumbs;
	}

	public static function title( string $title, string $actions_html = '' ): void {
		self::$title     = $title;
		self::$page_acts = $actions_html;
	}

	/** Decide whether the current request is a workspace page. */
	public static function resolve(): ?string {
		if ( ! is_user_logged_in() || ! is_page() ) {
			return null;
		}
		$ws = Pages::workspace_of( (int) get_queried_object_id() );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing flag.
		if ( 'guardian' === $ws && ( isset( $_GET['educore_guardian'] ) || ! Guardian::is_guardian( get_current_user_id() ) ) ) {
			return null; // Consent links keep the public page; the portal is for signed-in guardians.
		}
		$uid = get_current_user_id();
		$own = user_can( $uid, 'ec_learn' ) ? 'student' : ( Guardian::is_guardian( $uid ) ? 'guardian' : 'account' );
		if ( 'help' === $ws ) {
			// The user guide opens inside the visitor's own workspace navigation.
			return Navigation::can_manage( $uid ) ? 'manage' : ( user_can( $uid, 'edit_ec_courses' ) ? 'studio' : $own );
		}
		if ( 'student' === $ws && ! user_can( $uid, 'ec_learn' ) ) {
			$ws = 'account'; // Profile/history for staff: account pages inside their shell.
		} elseif ( in_array( $ws, array( 'teaching-hub', 'tutor', 'instructor', 'studio' ), true ) && ! user_can( $uid, 'ec_access_workspace' ) && ! user_can( $uid, 'manage_options' ) ) {
			$ws = $own; // The page explains it is for staff; navigation stays the visitor's own.
		} elseif ( 'manage' === $ws && ! Navigation::can_manage( $uid ) ) {
			$ws = user_can( $uid, 'ec_access_workspace' ) ? 'account' : $own;
		}
		return $ws;
	}

	public static function template( $template ) {
		$ws = self::resolve();
		if ( null === $ws ) {
			return $template;
		}
		self::$ws = $ws;
		// The shell's account menu and workspace switcher replace the WordPress toolbar on workspace pages.
		remove_action( 'wp_body_open', 'wp_admin_bar_render', 0 );
		remove_action( 'wp_footer', 'wp_admin_bar_render', 1000 );
		remove_action( 'wp_enqueue_scripts', 'wp_enqueue_admin_bar_bump_styles' );
		remove_action( 'wp_head', '_admin_bar_bump_cb' );
		add_filter( 'body_class', static fn( $c ) => array_diff( $c, array( 'admin-bar' ) ) );
		return EDUCORE_WS_DIR . 'templates/app.php';
	}

	public static function admin_bar( $show ) {
		// The shell has its own account menu; the WordPress toolbar stays for technical administrators only.
		return is_admin() ? $show : ( current_user_can( 'manage_options' ) ? $show : false );
	}

	public static function assets(): void {
		wp_register_style( 'educore-ws', EDUCORE_WS_URL . 'assets/css/workspace.css', array( 'educore-core' ), EDUCORE_WS_VERSION );
		wp_register_script( 'educore-ws', EDUCORE_WS_URL . 'assets/js/workspace.js', array(), EDUCORE_WS_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		if ( null === self::resolve() ) {
			return;
		}
		wp_enqueue_style( 'educore-ws' );
		wp_enqueue_script( 'educore-ws' );
		if ( in_array( self::resolve(), array( 'studio', 'manage' ), true ) ) {
			wp_enqueue_script( 'educore-ws-studio', EDUCORE_WS_URL . 'assets/js/studio.js', array( 'educore-ws' ), EDUCORE_WS_VERSION, array( 'in_footer' => true ) );
			wp_enqueue_script( 'educore-ws-bank', EDUCORE_WS_URL . 'assets/js/bank.js', array( 'educore-ws' ), EDUCORE_WS_VERSION, array( 'in_footer' => true ) ); // Also handles CSV uploads in Management.
		}
		wp_localize_script(
			'educore-ws',
			'EduCoreWS',
			array(
				'rest'  => esc_url_raw( rest_url( 'educore/v1/' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
				'i18n'  => array(
					'saved'   => __( 'Saved.', 'educore-workspace' ),
					'error'   => __( 'Something went wrong. Please try again.', 'educore-workspace' ),
					'offline' => __( 'You appear to be offline. Your changes were not sent.', 'educore-workspace' ),
					'confirm' => __( 'Are you sure?', 'educore-workspace' ),
					'unsaved' => __( 'You have unsaved changes.', 'educore-workspace' ),
					'working' => __( 'Working…', 'educore-workspace' ),
					/* translators: %s: time */
					'autosaved' => __( 'Draft saved automatically at %s.', 'educore-workspace' ),
					'orderChanged' => __( 'Order changed. Select “Save order” to keep it.', 'educore-workspace' ),
					'moved' => __( 'Moved.', 'educore-workspace' ),
					'renamePrompt' => __( 'New title', 'educore-workspace' ),
					'restored' => __( 'Automatically saved version restored. Save the lesson to keep it.', 'educore-workspace' ),
					'pool'       => __( 'Question pool', 'educore-workspace' ),
					'poolMax'    => __( 'An assessment can have at most 30 pools.', 'educore-workspace' ),
					'chooseFile' => __( 'Choose a file to import.', 'educore-workspace' ),
					'tooLarge'   => __( 'The file is larger than 10 MB.', 'educore-workspace' ),
				),
			)
		);
	}

	/** Render the page content once (blocks/shortcodes register nav, crumbs and title as they run). */
	public static function content(): string {
		Access::no_cache_headers();
		$html = '';
		while ( have_posts() ) {
			the_post();
			$html .= apply_filters( 'the_content', get_the_content() ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals -- core filter.
		}
		if ( '' === self::$title ) {
			self::$title = (string) get_the_title( get_queried_object_id() );
		}
		return $html;
	}

	public static function sidebar( int $uid ): string {
		$ws    = (string) self::$ws;
		$items = self::$nav ?? Navigation::items( $ws, $uid );
		$here  = self::current_url();
		$out   = '<nav class="ec-app-nav" aria-label="' . esc_attr( self::$nav_label ?: __( 'Workspace', 'educore-workspace' ) ) . '"><ul>';
		$flag  = (bool) array_filter( $items, static fn( $it ) => ! empty( $it['current'] ) );
		foreach ( $items as $it ) {
			// An item that declares itself current wins; otherwise fall back to URL matching (exactly one item is current).
			$cur  = $flag ? ! empty( $it['current'] ) : self::same_page( (string) $it['url'], $here );
			$out .= '<li><a href="' . esc_url( $it['url'] ) . '"' . ( $cur ? ' aria-current="page"' : '' ) . '>' . Navigation::icon( (string) ( $it['icon'] ?? 'grid' ) ) . '<span>' . esc_html( $it['label'] ) . '</span>' . ( ! empty( $it['badge'] ) ? '<span class="ec-app-badge">' . esc_html( number_format_i18n( (int) $it['badge'] ) ) . '</span>' : '' ) . '</a></li>';
		}
		$out .= '</ul></nav>';
		$wss  = Navigation::workspaces( $uid );
		if ( count( $wss ) > 1 ) {
			$out .= '<nav class="ec-app-nav ec-app-nav--ws" aria-label="' . esc_attr__( 'Switch workspace', 'educore-workspace' ) . '"><p class="ec-app-nav__head">' . esc_html__( 'Workspaces', 'educore-workspace' ) . '</p><ul>';
			foreach ( $wss as $w ) {
				$out .= '<li><a href="' . esc_url( $w['url'] ) . '"' . ( self::same_page( $w['url'], $here ) ? ' aria-current="true"' : '' ) . '>' . Navigation::icon( 'grid' ) . '<span>' . esc_html( $w['label'] ) . '</span></a></li>';
			}
			$out .= '</ul></nav>';
		}
		return $out;
	}

	public static function topbar( int $uid ): string {
		$user  = wp_get_current_user();
		$notes = Navigation::notifications( $uid );
		$total = array_sum( wp_list_pluck( $notes, 'count' ) );
		$qa    = Navigation::quick_actions( (string) self::$ws, $uid );
		$search_url = Navigation::can_manage( $uid ) ? Pages::url( 'manage' ) : home_url( '/' );
		$o  = '<header class="ec-app-top">';
		$o .= '<button type="button" class="ec-app-burger" aria-controls="ec-app-side" aria-expanded="false" data-ec-burger><span class="screen-reader-text">' . esc_html__( 'Menu', 'educore-workspace' ) . '</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18M3 12h18M3 18h18"/></svg></button>';
		$o .= '<form class="ec-app-search" role="search" method="get" action="' . esc_url( $search_url ) . '">';
		if ( Navigation::can_manage( $uid ) ) {
			$o .= '<input type="hidden" name="v" value="search">';
		} else {
			$o .= '<input type="hidden" name="post_type" value="ec_course">';
		}
		$o .= '<label class="screen-reader-text" for="ec-app-q">' . esc_html__( 'Search', 'educore-workspace' ) . '</label><input id="ec-app-q" type="search" name="' . ( Navigation::can_manage( $uid ) ? 'q' : 's' ) . '" placeholder="' . esc_attr( Navigation::can_manage( $uid ) ? __( 'Search people and courses…', 'educore-workspace' ) : __( 'Search courses…', 'educore-workspace' ) ) . '" autocomplete="off"></form>';
		$o .= '<div class="ec-app-tools">';
		if ( $qa ) {
			$o .= self::menu( 'ec-app-qa', '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg><span class="ec-app-tool__label">' . esc_html__( 'Quick actions', 'educore-workspace' ) . '</span>', array_map( static fn( $a ) => '<a href="' . esc_url( $a['url'] ) . '">' . esc_html( $a['label'] ) . '</a>', $qa ), __( 'Quick actions', 'educore-workspace' ) );
		}
		$items = $notes ? array_map( static fn( $n ) => '<a href="' . esc_url( $n['url'] ) . '"><span>' . esc_html( $n['label'] ) . '</span><span class="ec-app-badge">' . esc_html( number_format_i18n( $n['count'] ) ) . '</span></a>', $notes ) : array( '<p class="ec-app-menu__empty">' . esc_html__( 'You are all caught up.', 'educore-workspace' ) . '</p>' );
		/* translators: %d: number of notifications */
		$nlabel = $total ? sprintf( _n( '%d notification', '%d notifications', $total, 'educore-workspace' ), $total ) : __( 'Notifications', 'educore-workspace' );
		$o     .= self::menu( 'ec-app-notes', '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 17V11a6 6 0 1 1 12 0v6l2 2H4zM10 21h4"/></svg>' . ( $total ? '<span class="ec-app-dot">' . esc_html( number_format_i18n( $total ) ) . '</span>' : '' ), $items, $nlabel );
		$langs = array();
		foreach ( I18n::labels() as $code => $label ) {
			$langs[] = '<a href="' . I18n::switch_url( $code ) . '" lang="' . esc_attr( $code ) . '" hreflang="' . esc_attr( $code ) . '"' . ( I18n::current() === $code ? ' aria-current="true"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		$o .= self::menu( 'ec-app-lang', '<span class="ec-app-lang">' . esc_html( strtoupper( I18n::current() ) ) . '</span>', $langs, __( 'Language', 'educore-workspace' ) );
		$o .= '<button type="button" class="ec-app-tool" data-ec-theme-toggle aria-pressed="false" title="' . esc_attr__( 'Dark mode', 'educore-workspace' ) . '"><span class="screen-reader-text">' . esc_html__( 'Dark mode', 'educore-workspace' ) . '</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 15A8 8 0 0 1 9 4a8 8 0 1 0 11 11z"/></svg></button>';
		$acct  = array(
			'<p class="ec-app-menu__who"><strong>' . esc_html( $user->display_name ) . '</strong><span>' . esc_html( $user->user_email ) . '</span></p>',
			'<a href="' . esc_url( \EduCore\Core\Pages::url( 'profile' ) ) . '">' . esc_html__( 'My profile', 'educore-workspace' ) . '</a>',
		);
		foreach ( Navigation::workspaces( $uid ) as $w ) {
			$acct[] = '<a href="' . esc_url( $w['url'] ) . '">' . esc_html( $w['label'] ) . '</a>';
		}
		$acct[] = '<a href="' . esc_url( Pages::url( 'help' ) ) . '">' . esc_html__( 'User guide', 'educore-workspace' ) . '</a>';
		$acct[] = '<a href="' . esc_url( Help::about_url() ) . '">' . esc_html__( 'About EduCore', 'educore-workspace' ) . '</a>';
		$acct[] = '<a href="' . esc_url( wp_logout_url( wp_login_url() ) ) . '">' . esc_html__( 'Sign out', 'educore-workspace' ) . '</a>';
		$o     .= self::menu( 'ec-app-acct', self::initials( $user->display_name ) . '<span class="ec-app-tool__label">' . esc_html( $user->display_name ) . '</span>', $acct, __( 'Account', 'educore-workspace' ) );
		return $o . '</div></header>';
	}

	/** Local initials avatar: no third-party avatar service is contacted from the application. */
	private static function initials( string $name ): string {
		$parts = preg_split( '/\s+/u', trim( $name ) ) ?: array();
		$ini   = mb_strtoupper( mb_substr( (string) ( $parts[0] ?? '?' ), 0, 1 ) . ( count( $parts ) > 1 ? mb_substr( (string) end( $parts ), 0, 1 ) : '' ) );
		return '<span class="ec-app-avatar" aria-hidden="true">' . esc_html( $ini ) . '</span>';
	}

	private static function menu( string $id, string $button, array $items, string $label ): string {
		$o = '<div class="ec-app-menu"><button type="button" class="ec-app-tool" aria-haspopup="true" aria-expanded="false" aria-controls="' . esc_attr( $id ) . '" data-ec-menu><span class="screen-reader-text">' . esc_html( $label ) . '</span>' . $button . '</button>';
		$o .= '<div class="ec-app-menu__panel" id="' . esc_attr( $id ) . '" hidden><ul role="list">';
		foreach ( $items as $i ) {
			$o .= '<li>' . $i . '</li>';
		}
		return $o . '</ul></div></div>';
	}

	public static function breadcrumbs(): string {
		$c = self::$crumbs ?: array( array( self::$title ) );
		$o = '<nav class="ec-app-crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'educore-workspace' ) . '"><ol>';
		$n = count( $c );
		foreach ( array_values( $c ) as $i => $cr ) {
			$last = $i === $n - 1;
			$o   .= '<li>' . ( ! $last && ! empty( $cr[1] ) ? '<a href="' . esc_url( $cr[1] ) . '">' . esc_html( $cr[0] ) . '</a>' : '<span' . ( $last ? ' aria-current="page"' : '' ) . '>' . esc_html( $cr[0] ) . '</span>' ) . '</li>';
		}
		return $o . '</ol></nav>';
	}

	public static function heading(): string {
		return '<div class="ec-app-head"><h1 class="ec-app-title">' . esc_html( self::$title ) . '</h1>' . ( self::$page_acts ? '<div class="ec-app-head__actions">' . self::$page_acts . '</div>' : '' ) . '</div>';
	}

	public static function brand(): string {
		return '<a class="ec-app-brand" href="' . esc_url( \EduCore\Core\Auth\Router::primary( wp_get_current_user() ) ) . '">' . Branding::logo_html( 'dark', 'ec-app-logo', 30 ) . '</a>';
	}

	public static function current_url(): string {
		$req = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		return home_url( remove_query_arg( array( 'partial', 'ec_msg', 'ec_err' ), $req ) );
	}

	private static function same_page( string $a, string $b ): bool {
		$pa = wp_parse_url( $a );
		$pb = wp_parse_url( $b );
		if ( untrailingslashit( $pa['path'] ?? '' ) !== untrailingslashit( $pb['path'] ?? '' ) ) {
			return false;
		}
		parse_str( $pa['query'] ?? '', $qa );
		parse_str( $pb['query'] ?? '', $qb );
		return ( $qa['v'] ?? '' ) === ( $qb['v'] ?? '' );
	}
}
