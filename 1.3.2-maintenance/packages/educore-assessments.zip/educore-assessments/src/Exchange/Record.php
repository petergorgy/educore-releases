<?php
namespace EduCore\Assessments\Exchange;

use EduCore\Assessments\Questions;
use EduCore\Assessments\Types;

defined( 'ABSPATH' ) || exit;

/**
 * The canonical exchange record: one question in a format-independent, lossless shape.
 * Every reader produces records; every writer consumes them.
 */
final class Record {
	public const FIELDS = array( 'external_id', 'type', 'stem', 'payload', 'key', 'explanation', 'points', 'difficulty', 'usage', 'lang', 'tags', 'status', 'lesson_id' );

	/** Record of an existing question (current version). */
	public static function from_question( int $id ): ?array {
		$q = Questions::full( $id );
		if ( ! $q || ! $q['version'] ) {
			return null;
		}
		$ext = (string) $q['external_id'];
		return array(
			'external_id' => '' !== $ext ? $ext : self::default_external_id( (int) $q['id'] ),
			'type'        => $q['type'],
			'stem'        => (string) $q['version']['stem'],
			'payload'     => (array) $q['version']['payload'],
			'key'         => (array) $q['version']['answer_key'],
			'explanation' => (string) $q['version']['explanation'],
			'points'      => (float) $q['version']['points'],
			'difficulty'  => $q['difficulty'],
			'usage'       => $q['usage_scope'],
			'lang'        => $q['version']['lang'],
			'tags'        => array_values( (array) $q['tags'] ),
			'status'      => $q['status'],
			'lesson_id'   => (int) $q['lesson_id'],
		);
	}

	/** Site-unique default identifier for questions that never had one. */
	public static function default_external_id( int $question_id ): string {
		return 'ec-' . substr( md5( home_url() ), 0, 8 ) . '-q' . $question_id;
	}

	/** Resolve an external id to a question in the course (stored id, or this site's default id form). */
	public static function resolve( int $course_id, string $external_id ): int {
		$id = Questions::by_external_id( $course_id, $external_id );
		if ( ! $id && preg_match( '/^ec-([a-f0-9]{8})-q(\d+)$/', $external_id, $m ) && substr( md5( home_url() ), 0, 8 ) === $m[1] ) {
			$q  = Questions::get( (int) $m[2] );
			$id = ( $q && (int) $q['course_id'] === $course_id && '' === (string) $q['external_id'] && 'archived' !== $q['status'] ) ? (int) $q['id'] : 0;
		}
		return $id;
	}

	/** Fill defaults and types for a record produced by a reader. */
	public static function normalise( array $r ): array {
		$out = array(
			'external_id' => Questions::external_id( (string) ( $r['external_id'] ?? '' ) ),
			'type'        => sanitize_key( (string) ( $r['type'] ?? '' ) ),
			'stem'        => (string) ( $r['stem'] ?? '' ),
			'payload'     => is_array( $r['payload'] ?? null ) ? $r['payload'] : array(),
			'key'         => is_array( $r['key'] ?? null ) ? $r['key'] : array(),
			'explanation' => (string) ( $r['explanation'] ?? '' ),
			'points'      => ( isset( $r['points'] ) && '' !== $r['points'] ) ? (float) $r['points'] : 1.0,
			'difficulty'  => (string) ( $r['difficulty'] ?? 'medium' ),
			'usage'       => (string) ( $r['usage'] ?? 'any' ),
			'lang'        => (string) ( $r['lang'] ?? '' ),
			'tags'        => self::tags( $r['tags'] ?? array() ),
			'status'      => (string) ( $r['status'] ?? 'draft' ),
			'lesson_id'   => absint( $r['lesson_id'] ?? 0 ),
		);
		if ( isset( $r['media'] ) && is_array( $r['media'] ) ) {
			$out['media'] = $r['media'];
		}
		return $out;
	}

	public static function tags( $tags ): array {
		$list = is_array( $tags ) ? $tags : explode( ',', (string) $tags );
		$list = array_values( array_unique( array_filter( array_map( static fn( $x ) => substr( sanitize_title( (string) $x ), 0, 60 ), $list ) ) ) );
		sort( $list );
		return $list;
	}

	/**
	 * Content fingerprint: identical questions produce identical fingerprints regardless of the format
	 * they travelled through. Option ids are replaced by positions so re-generated ids do not matter.
	 */
	public static function fingerprint( array $r, bool $with_meta = true ): string {
		$r    = self::normalise( $r );
		$auth = Types::to_authoring( $r['type'], $r['payload'], $r['key'] );
		unset( $auth['image_id'] ); // Media ids are site-specific; image content is compared by the package checksum.
		$base = array(
			'type'   => $r['type'],
			'stem'   => self::text( $r['stem'] ),
			'auth'   => array_map( static fn( $v ) => self::text( (string) $v ), $auth ),
			'expl'   => self::text( $r['explanation'] ),
			'points' => round( $r['points'], 2 ),
			'min'    => (int) ( $r['payload']['min_words'] ?? 0 ),
		);
		if ( $with_meta ) {
			$base += array( 'diff' => $r['difficulty'], 'usage' => $r['usage'], 'lang' => $r['lang'], 'tags' => $r['tags'] );
		}
		return hash( 'sha256', (string) wp_json_encode( $base, JSON_UNESCAPED_UNICODE ) );
	}

	private static function text( string $s ): string {
		return trim( (string) preg_replace( '/\s+/u', ' ', html_entity_decode( str_replace( "\r", '', $s ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
	}

	/** Content hash compatible with Questions::dedupe_hash (duplicate detection in the bank). */
	public static function dedupe_hash( array $r ): string {
		return Questions::dedupe_hash( $r['type'], wp_kses_post( $r['stem'] ), $r['payload'] );
	}
}
