<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Registry;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	public const DB_OPTION = 'educore_th_db_version';
	public const DAILY     = 'educore_th_daily';

	/** @return array<string,string> All Teaching Hub tables ({prefix}ec_th_*). */
	public static function tables(): array {
		return array(
			'th_classes'           => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				name VARCHAR(190) NOT NULL,
				code VARCHAR(40) NOT NULL DEFAULT '',
				academic_year VARCHAR(20) NOT NULL DEFAULT '',
				programme_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				period_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				subject_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				course_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				schedule TEXT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY course_id (course_id),
				KEY status (status)",
			'th_class_staff'       => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				class_id BIGINT UNSIGNED NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				staff_role VARCHAR(20) NOT NULL DEFAULT 'teacher',
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY class_user (class_id,user_id),
				KEY user_id (user_id)",
			'th_class_members'     => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				class_id BIGINT UNSIGNED NOT NULL,
				student_id BIGINT UNSIGNED NOT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				joined_at DATETIME NOT NULL,
				left_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY class_student (class_id,student_id),
				KEY student_status (student_id,status)",
			'th_groups'            => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				class_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				group_type VARCHAR(20) NOT NULL DEFAULT 'study',
				name VARCHAR(190) NOT NULL,
				owner_id BIGINT UNSIGNED NOT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY class_id (class_id),
				KEY owner_id (owner_id)",
			'th_group_members'     => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				group_id BIGINT UNSIGNED NOT NULL,
				student_id BIGINT UNSIGNED NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY group_student (group_id,student_id),
				KEY student_id (student_id)",
			'th_lesson_plans'      => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				class_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				lesson_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				owner_id BIGINT UNSIGNED NOT NULL,
				title VARCHAR(190) NOT NULL,
				objectives TEXT NULL,
				target VARCHAR(190) NOT NULL DEFAULT '',
				teach_date DATE NULL,
				duration_min SMALLINT UNSIGNED NOT NULL DEFAULT 45,
				materials TEXT NULL,
				activities TEXT NULL,
				exercises TEXT NULL,
				assessment TEXT NULL,
				homework TEXT NULL,
				notes TEXT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'planned',
				is_template TINYINT(1) NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY class_date (class_id,teach_date),
				KEY owner_template (owner_id,is_template)",
			'th_assignments'       => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				class_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				course_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				lesson_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				title VARCHAR(190) NOT NULL,
				instructions LONGTEXT NULL,
				attachments TEXT NULL,
				opens_at DATETIME NULL,
				due_at DATETIME NULL,
				max_score DECIMAL(7,2) NOT NULL DEFAULT 100,
				rubric TEXT NULL,
				allow_resubmit TINYINT(1) NOT NULL DEFAULT 0,
				allow_late TINYINT(1) NOT NULL DEFAULT 1,
				allow_files TINYINT(1) NOT NULL DEFAULT 1,
				status VARCHAR(20) NOT NULL DEFAULT 'draft',
				created_by BIGINT UNSIGNED NOT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY class_status (class_id,status),
				KEY course_id (course_id),
				KEY due_at (due_at)",
			'th_assignment_targets' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				assignment_id BIGINT UNSIGNED NOT NULL,
				target_type VARCHAR(10) NOT NULL,
				target_id BIGINT UNSIGNED NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY target (assignment_id,target_type,target_id),
				KEY by_target (target_type,target_id)",
			'th_submissions'       => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				assignment_id BIGINT UNSIGNED NOT NULL,
				student_id BIGINT UNSIGNED NOT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'draft',
				answer LONGTEXT NULL,
				files TEXT NULL,
				attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
				is_late TINYINT(1) NOT NULL DEFAULT 0,
				submitted_at DATETIME NULL,
				score DECIMAL(7,2) NULL,
				rubric_scores TEXT NULL,
				feedback LONGTEXT NULL,
				graded_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				graded_at DATETIME NULL,
				released TINYINT(1) NOT NULL DEFAULT 0,
				released_at DATETIME NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY assignment_student (assignment_id,student_id),
				KEY student_id (student_id),
				KEY status (status)",
			'th_grade_log'         => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				submission_id BIGINT UNSIGNED NOT NULL,
				actor_id BIGINT UNSIGNED NOT NULL,
				action VARCHAR(20) NOT NULL,
				old_score DECIMAL(7,2) NULL,
				new_score DECIMAL(7,2) NULL,
				comment TEXT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY submission_id (submission_id)",
			'th_attendance'        => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				context_type VARCHAR(10) NOT NULL,
				context_id BIGINT UNSIGNED NOT NULL,
				occurs_on DATE NOT NULL,
				student_id BIGINT UNSIGNED NOT NULL,
				status VARCHAR(12) NOT NULL,
				note VARCHAR(255) NOT NULL DEFAULT '',
				recorded_by BIGINT UNSIGNED NOT NULL,
				recorded_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY mark (context_type,context_id,occurs_on,student_id),
				KEY student_day (student_id,occurs_on)",
			'th_tutor_profiles'    => "user_id BIGINT UNSIGNED NOT NULL,
				headline VARCHAR(190) NOT NULL DEFAULT '',
				bio TEXT NULL,
				subjects VARCHAR(255) NOT NULL DEFAULT '',
				languages VARCHAR(60) NOT NULL DEFAULT '',
				experience VARCHAR(255) NOT NULL DEFAULT '',
				qualifications TEXT NULL,
				formats VARCHAR(40) NOT NULL DEFAULT 'online',
				session_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 60,
				notice_hours SMALLINT UNSIGNED NOT NULL DEFAULT 24,
				capacity TINYINT UNSIGNED NOT NULL DEFAULT 1,
				is_public TINYINT(1) NOT NULL DEFAULT 0,
				status VARCHAR(20) NOT NULL DEFAULT 'draft',
				reviewed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				reviewed_at DATETIME NULL,
				review_note VARCHAR(255) NOT NULL DEFAULT '',
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (user_id),
				KEY status_public (status,is_public)",
			'th_availability'      => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				tutor_id BIGINT UNSIGNED NOT NULL,
				weekday TINYINT UNSIGNED NOT NULL,
				start_time TIME NOT NULL,
				end_time TIME NOT NULL,
				PRIMARY KEY  (id),
				KEY tutor_day (tutor_id,weekday)",
			'th_unavailable'       => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				tutor_id BIGINT UNSIGNED NOT NULL,
				day DATE NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY tutor_day (tutor_id,day)",
			'th_sessions'          => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				tutor_id BIGINT UNSIGNED NOT NULL,
				student_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				group_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				subject VARCHAR(190) NOT NULL DEFAULT '',
				starts_at DATETIME NOT NULL,
				ends_at DATETIME NOT NULL,
				format VARCHAR(12) NOT NULL DEFAULT 'online',
				status VARCHAR(20) NOT NULL DEFAULT 'requested',
				guardian_ok TINYINT(1) NOT NULL DEFAULT 1,
				objectives TEXT NULL,
				notes TEXT NULL,
				homework TEXT NULL,
				feedback TEXT NULL,
				follow_up TEXT NULL,
				meeting_url VARCHAR(255) NOT NULL DEFAULT '',
				location VARCHAR(190) NOT NULL DEFAULT '',
				series_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				requested_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				status_note VARCHAR(255) NOT NULL DEFAULT '',
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY tutor_time (tutor_id,starts_at),
				KEY student_time (student_id,starts_at),
				KEY status (status)",
			'th_slot_locks'        => "tutor_id BIGINT UNSIGNED NOT NULL,
				slot_start DATETIME NOT NULL,
				session_id BIGINT UNSIGNED NOT NULL,
				PRIMARY KEY  (tutor_id,slot_start),
				KEY session_id (session_id)",
			'th_threads'           => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				context_type VARCHAR(12) NOT NULL,
				context_id BIGINT UNSIGNED NOT NULL,
				student_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				subject VARCHAR(190) NOT NULL,
				status VARCHAR(12) NOT NULL DEFAULT 'open',
				created_by BIGINT UNSIGNED NOT NULL,
				created_at DATETIME NOT NULL,
				last_post_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY context (context_type,context_id),
				KEY student_id (student_id)",
			'th_messages'          => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				thread_id BIGINT UNSIGNED NOT NULL,
				author_id BIGINT UNSIGNED NOT NULL,
				body TEXT NOT NULL,
				hidden TINYINT(1) NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY thread_id (thread_id)",
			'th_reports'           => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				reporter_id BIGINT UNSIGNED NOT NULL,
				thread_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				message_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				reason TEXT NOT NULL,
				status VARCHAR(12) NOT NULL DEFAULT 'open',
				handled_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				resolution TEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY status (status)",
		);
	}

	public static function migrate(): void {
		Schema::migrate( self::DB_OPTION, EDUCORE_TH_DB_VERSION, self::tables() );
	}

	public static function install(): void {
		self::migrate();
		Caps::install();
		Pages::create_missing();
		add_option( 'educore_th_settings', Settings::defaults(), '', false );
		Files::ensure_dir();
		self::schedule();
		update_option( 'educore_th_installed', EDUCORE_TH_VERSION, false );
	}

	public static function boot(): void {
		Registry::register( 'teaching-hub', EDUCORE_TH_VERSION );
		self::migrate();
		if ( get_option( 'educore_th_caps_version' ) !== EDUCORE_TH_VERSION ) {
			Caps::install();
		}
		add_action( 'educore/install/repair', array( self::class, 'repair' ) );
		add_action( 'init', array( self::class, 'textdomain' ) );
		add_action( 'init', array( self::class, 'schedule' ) );
		add_action( self::DAILY, array( Alerts::class, 'daily' ) );
		Caps::register();
		Notify::register();
		Rest::register();
		Portal::register();
		Student::register();
		Tutoring::register();
		Privacy::register();
		if ( is_admin() ) {
			Admin::register();
		}
	}

	public static function repair(): void {
		self::migrate();
		Caps::install();
		Pages::create_missing();
		Files::ensure_dir();
	}

	public static function textdomain(): void {
		load_plugin_textdomain( 'educore-teaching-hub', false, dirname( plugin_basename( EDUCORE_TH_FILE ) ) . '/languages' );
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::DAILY ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::DAILY );
		}
	}

	/** True for POST requests (sanitised read of REQUEST_METHOD). */
	public static function is_post(): bool {
		return isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) );
	}

	/** UTC "now" in MySQL format. */
	public static function now(): string {
		return Schema::now();
	}

	/** Convert a site-local "Y-m-d H:i" (Africa/Cairo by default) to UTC MySQL datetime. */
	public static function local_to_utc( string $local ): ?string {
		$local = trim( $local );
		if ( '' === $local ) {
			return null;
		}
		$dt = date_create_immutable( str_replace( 'T', ' ', $local ), wp_timezone() );
		return $dt ? $dt->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ) : null;
	}

	/** Format a UTC MySQL datetime in the site timezone. */
	public static function local( ?string $utc, string $format = '' ): string {
		if ( ! $utc ) {
			return '—';
		}
		$ts = strtotime( $utc . ' UTC' );
		return $ts ? wp_date( $format ?: get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $ts ) : '—';
	}
}
