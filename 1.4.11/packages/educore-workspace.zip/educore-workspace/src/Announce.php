<?php
namespace EduCore\Workspace;

use EduCore\Core\Access;
use EduCore\Core\Announcements;
use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\RateLimiter;
use EduCore\Workspace\Studio\Courses;
use EduCore\Workspace\Studio\View as F;

defined( 'ABSPATH' ) || exit;

/**
 * Course announcements in the Course Studio (`/studio/?v=announcements&course=ID`) and on the learner side
 * (course page, My learning). Storage and e-mail delivery stay in EduCore Core / Notifications
 * (`Announcements::publish` fires `educore/events/announcement_published`). Team members and academic managers
 * post; the author or a manager can withdraw. Learners only see announcements of courses they can access.
 */
final class Announce {

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
		add_filter( 'educore/course/after_details', array( self::class, 'course_box' ), 5, 2 );
		add_filter( 'educore/dashboard/student', array( self::class, 'dashboard' ), 20, 2 );
	}

	public static function can( int $uid, int $course_id ): bool {
		return $uid > 0 && Content::is_course( $course_id ) && ( user_can( $uid, 'ec_manage_all_courses' ) || Courses::can_edit( $uid, $course_id ) );
	}

	/** @return \WP_Post[] newest first */
	public static function of_course( int $course_id, int $limit = 50 ): array {
		return get_posts( array( 'post_type' => Announcements::TYPE, 'post_status' => 'publish', 'post_parent' => $course_id, 'posts_per_page' => $limit, 'orderby' => 'date', 'order' => 'DESC' ) );
	}

	/** @return int|\WP_Error */
	public static function post( int $uid, int $course_id, string $title, string $body ) {
		if ( ! self::can( $uid, $course_id ) ) {
			return new \WP_Error( 'ec_announce_forbidden', __( 'You cannot post announcements in this course.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		$title = mb_substr( sanitize_text_field( $title ), 0, 150 );
		$body  = mb_substr( sanitize_textarea_field( $body ), 0, 3000 );
		if ( mb_strlen( $title ) < 3 || mb_strlen( $body ) < 5 ) {
			return new \WP_Error( 'ec_announce_empty', __( 'Add a title (at least 3 characters) and a message (at least 5 characters).', 'educore-workspace' ), array( 'status' => 400, 'params' => array( 'title' => 'required', 'body' => 'required' ) ) );
		}
		if ( 'publish' !== get_post_status( $course_id ) ) {
			return new \WP_Error( 'ec_announce_unpublished', __( 'Publish the course before posting announcements; no learner can see it yet.', 'educore-workspace' ), array( 'status' => 409 ) );
		}
		$id = Announcements::publish( $course_id, $title, $body );
		if ( ! $id ) {
			return new \WP_Error( 'ec_announce_failed', __( 'The announcement could not be saved.', 'educore-workspace' ), array( 'status' => 500 ) );
		}
		wp_update_post( array( 'ID' => $id, 'post_author' => $uid ) );
		return $id;
	}

	/** @return true|\WP_Error */
	public static function withdraw( int $uid, int $id ) {
		$p = get_post( $id );
		if ( ! $p || Announcements::TYPE !== $p->post_type || 'publish' !== $p->post_status || ! self::can( $uid, (int) $p->post_parent ) ) {
			return new \WP_Error( 'ec_announce_forbidden', __( 'Announcement not found.', 'educore-workspace' ), array( 'status' => 404 ) );
		}
		if ( (int) $p->post_author !== $uid && ! user_can( $uid, 'ec_manage_all_courses' ) ) {
			return new \WP_Error( 'ec_announce_owner', __( 'Only the author or an academic manager can withdraw this announcement.', 'educore-workspace' ), array( 'status' => 403 ) );
		}
		wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
		Audit::log( 'announcement.withdrawn', 'course', (int) $p->post_parent, array( 'id' => $id ) );
		return true;
	}

	public static function routes(): void {
		$perm = static fn() => is_user_logged_in();
		register_rest_route( 'educore/v1', '/announcements/(?P<course>\d+)', array( 'methods' => 'POST', 'callback' => array( self::class, 'rest_post' ), 'permission_callback' => $perm, 'args' => array( 'course' => array( 'type' => 'integer', 'required' => true, 'minimum' => 1 ), 'title' => array( 'type' => 'string', 'required' => true ), 'body' => array( 'type' => 'string', 'required' => true ) ) ) );
		register_rest_route( 'educore/v1', '/announcements/withdraw/(?P<id>\d+)', array( 'methods' => 'POST', 'callback' => array( self::class, 'rest_withdraw' ), 'permission_callback' => $perm, 'args' => array( 'id' => array( 'type' => 'integer', 'required' => true, 'minimum' => 1 ) ) ) );
	}

	private static function guard() {
		return RateLimiter::hit( 'rest_write' ) ? null : new \WP_Error( 'ec_ws_rate', __( 'Too many changes in a short time. Please wait a moment.', 'educore-workspace' ), array( 'status' => 429 ) );
	}

	public static function rest_post( \WP_REST_Request $q ) {
		$r = self::guard() ?? self::post( get_current_user_id(), (int) $q['course'], (string) $q['title'], (string) $q['body'] );
		return is_wp_error( $r ) ? $r : new \WP_REST_Response( array( 'ok' => true, 'id' => $r ), 201 );
	}

	public static function rest_withdraw( \WP_REST_Request $q ) {
		$r = self::guard() ?? self::withdraw( get_current_user_id(), (int) $q['id'] );
		return is_wp_error( $r ) ? $r : new \WP_REST_Response( array( 'ok' => true ) );
	}

	private static function when( \WP_Post $p ): string {
		return get_date_from_gmt( $p->post_date_gmt, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
	}

	/* ---------- Studio view ---------- */

	public static function render( int $uid, int $course_id ): string {
		$studio = Pages::url( 'studio' );
		Shell::crumbs( array( array( __( 'Course Studio', 'educore-workspace' ), $studio ), array( get_the_title( $course_id ) ?: '—', add_query_arg( 'course', $course_id, $studio ) ), array( __( 'Announcements', 'educore-workspace' ) ) ) );
		Shell::title( __( 'Announcements', 'educore-workspace' ) );
		if ( ! self::can( $uid, $course_id ) ) {
			return F::notice( __( 'You cannot post announcements in this course.', 'educore-workspace' ), 'error' );
		}
		/* translators: %s: course title */
		$o = '<p class="ec-muted">' . esc_html( sprintf( __( 'Course: %s. Enrolled learners see announcements on the course page and in My learning, and receive an e-mail if they have not turned course announcements off.', 'educore-workspace' ), get_the_title( $course_id ) ) ) . '</p><div class="ec-ws-cols"><div>';
		if ( 'publish' !== get_post_status( $course_id ) ) {
			$o .= F::notice( __( 'Publish the course before posting announcements; no learner can see it yet.', 'educore-workspace' ), 'info' );
		} else {
			$o .= '<form class="ec-card ec-ws-form" data-ec-api="announcements/' . (int) $course_id . '" data-ec-method="POST" data-ec-after="' . esc_attr( add_query_arg( array( 'v' => 'announcements', 'course' => $course_id ), $studio ) ) . '" data-ec-confirm="' . esc_attr__( 'Send this announcement to every enrolled learner?', 'educore-workspace' ) . '" novalidate><h2>' . esc_html__( 'New announcement', 'educore-workspace' ) . '</h2>';
			$o .= F::field_text( 'title', __( 'Title', 'educore-workspace' ), '', true );
			$o .= F::field_area( 'body', __( 'Message', 'educore-workspace' ), '', 5, __( 'Plain text. Learners receive it by e-mail as well.', 'educore-workspace' ) );
			$o .= '<div class="ec-ws-actions"><button class="ec-btn ec-btn--primary" type="submit">' . esc_html__( 'Publish announcement', 'educore-workspace' ) . '</button></div></form>';
		}
		$o   .= '</div><div><section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Published', 'educore-workspace' ) . '</h2>';
		$list = self::of_course( $course_id );
		if ( ! $list ) {
			$o .= '<p class="ec-muted">' . esc_html__( 'No announcements yet.', 'educore-workspace' ) . '</p>';
		} else {
			$o .= '<ol class="ec-ws-timeline">';
			foreach ( $list as $p ) {
				$can = (int) $p->post_author === $uid || user_can( $uid, 'ec_manage_all_courses' );
				$o  .= '<li><p class="ec-muted">' . esc_html( self::when( $p ) . ' · ' . ( get_userdata( (int) $p->post_author )->display_name ?? '' ) ) . '</p><p><strong>' . esc_html( $p->post_title ) . '</strong></p><p>' . nl2br( esc_html( $p->post_content ) ) . '</p>';
				if ( $can ) {
					$o .= '<p><button class="ec-btn ec-btn--small" type="button" data-ec-call="announcements/withdraw/' . (int) $p->ID . '" data-ec-method="POST" data-ec-confirm="' . esc_attr__( 'Withdraw this announcement? Learners will no longer see it (e-mails already sent cannot be recalled).', 'educore-workspace' ) . '">' . esc_html__( 'Withdraw', 'educore-workspace' ) . '</button></p>';
				}
				$o .= '</li>';
			}
			$o .= '</ol>';
		}
		return $o . '</section></div></div>';
	}

	/* ---------- learner side ---------- */

	public static function course_box( $html, $course_id ) {
		$uid = get_current_user_id();
		if ( ! $uid || ! Access::can_access_course( $uid, (int) $course_id ) ) {
			return $html;
		}
		$list = self::of_course( (int) $course_id, 3 );
		if ( ! $list ) {
			return $html;
		}
		$o = '<section id="ec-announcements" class="ec-card ec-list-card ec-announcements" aria-labelledby="ec-ann-h"><h2 id="ec-ann-h">' . esc_html__( 'Announcements', 'educore-workspace' ) . '</h2><ul>';
		foreach ( $list as $p ) {
			$o .= '<li><p><strong>' . esc_html( $p->post_title ) . '</strong> <span class="ec-muted"><time datetime="' . esc_attr( mysql2date( 'c', $p->post_date_gmt, false ) ) . '">' . esc_html( self::when( $p ) ) . '</time></span></p><p>' . nl2br( esc_html( $p->post_content ) ) . '</p></li>';
		}
		return $html . $o . '</ul></section>';
	}

	/** Richer My learning items (link to the course's announcement section, date) replacing core's plain entries. */
	public static function dashboard( array $data, int $uid ): array {
		$ids = array();
		foreach ( $data['courses'] as $c ) {
			if ( $c['accessible'] ) {
				$ids[] = (int) $c['course_id'];
			}
		}
		$items = array();
		foreach ( Announcements::for_courses( $ids ) as $a ) {
			$items[] = array( 'title' => $a->post_title, 'meta' => get_the_title( $a->post_parent ) . ' · ' . get_date_from_gmt( $a->post_date_gmt, get_option( 'date_format' ) ), 'url' => get_permalink( $a->post_parent ) . '#ec-announcements' );
		}
		$data['announcements'] = $items;
		return $data;
	}
}
