<?php
namespace EduCore\Experience;

use EduCore\Core\Audit;

defined( 'ABSPATH' ) || exit;

/**
 * Platform defaults for the experience engine. Edited by academic managers / administrators in
 * EduCore Management → Experience (branded), and by technical administrators in WordPress → EduCore → Experience.
 */
final class Settings {
	public const OPTION = 'educore_xp_settings';
	public const CAP    = 'ec_manage_settings';


	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 40 );
		foreach ( array( 'add_option_', 'update_option_', 'delete_option_' ) as $h ) {
			add_action( $h . self::OPTION, array( self::class, 'flush' ) );
		}
		add_action( 'admin_post_educore_xp_settings', array( self::class, 'save' ) );
		add_filter( 'educore/manage/views', static fn( $v ) => (array) $v + array( 'experience' => array( self::class, 'manage_view' ) ) );
		add_filter( 'educore/shell/nav', array( self::class, 'nav' ), 30, 3 );
	}

	public static function defaults(): array {
		return array(
			'default_mode'       => 'system',
			'institution_tz'     => '',
			'schedule'           => Clock::FIXED,
			'evening_hours'      => 3,
			'greetings'          => array(),
			'welcome_enabled'    => true,
			'onboarding_enabled' => true,
			'defer_in_exams'     => true,
		);
	}

	private static ?array $cache = null;

	public static function get( string $key ) {
		if ( null === self::$cache ) {
			$raw         = get_option( self::OPTION, array() );
			self::$cache = array_merge( self::defaults(), is_array( $raw ) ? $raw : array() );
		}
		return self::$cache[ $key ] ?? null;
	}

	public static function flush(): void {
		self::$cache = null;
	}

	public static function all(): array {
		$raw = get_option( self::OPTION, array() );
		return array_merge( self::defaults(), is_array( $raw ) ? $raw : array() );
	}

	public static function can( int $uid ): bool {
		// Academic managers (programme managers) may tune the learning experience; platform settings stay with administrators.
		return user_can( $uid, self::CAP ) || user_can( $uid, 'ec_manage_programmes' ) || user_can( $uid, 'manage_options' );
	}

	/** @return array|\WP_Error */
	public static function sanitize( array $in ) {
		$s = self::all();
		if ( isset( $in['default_mode'] ) ) {
			$s['default_mode'] = in_array( $in['default_mode'], array( 'auto', 'system', 'light', 'dark' ), true ) ? $in['default_mode'] : 'system';
		}
		if ( isset( $in['institution_tz'] ) ) {
			$tz = (string) $in['institution_tz'];
			if ( '' !== $tz && ! Clock::valid_tz( $tz ) ) {
				return new \WP_Error( 'educore_xp_tz', __( 'Please choose a time zone from the list.', 'educore-experience' ) );
			}
			$s['institution_tz'] = $tz;
		}
		if ( isset( $in['schedule'] ) && is_array( $in['schedule'] ) ) {
			$mins = array();
			foreach ( Clock::STATES as $st ) {
				$mins[ $st ] = Clock::minutes( (string) ( $in['schedule'][ $st ] ?? '' ) );
			}
			if ( ! Clock::valid_schedule( $mins ) ) {
				return new \WP_Error( 'educore_xp_schedule', __( 'Each period must start later than the one before it, and Midnight must start at 00:00.', 'educore-experience' ) );
			}
			$s['schedule'] = array_map( static fn( $m ) => sprintf( '%02d:%02d', intdiv( $m, 60 ), $m % 60 ), $mins );
		}
		if ( isset( $in['evening_hours'] ) ) {
			$s['evening_hours'] = max( 1, min( 6, absint( $in['evening_hours'] ) ) );
		}
		if ( isset( $in['greetings'] ) && is_array( $in['greetings'] ) ) {
			$g = array();
			foreach ( array( 'en', 'fr', 'ar' ) as $lang ) {
				foreach ( Clock::STATES as $st ) {
					$t = trim( sanitize_text_field( (string) ( $in['greetings'][ $lang ][ $st ] ?? '' ) ) );
					if ( '' !== $t ) {
						$g[ $lang ][ $st ] = mb_substr( $t, 0, 140 );
					}
				}
			}
			$s['greetings'] = $g;
		}
		foreach ( array( 'welcome_enabled', 'onboarding_enabled', 'defer_in_exams' ) as $b ) {
			if ( array_key_exists( $b, $in ) ) {
				$s[ $b ] = (bool) $in[ $b ];
			}
		}
		return $s;
	}

	public static function menu(): void {
		add_submenu_page( 'educore', __( 'Experience', 'educore-experience' ), __( 'Experience', 'educore-experience' ), 'manage_options', 'educore-experience', array( self::class, 'admin_page' ) );
	}

	public static function admin_page(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'EduCore Experience', 'educore-experience' ) . '</h1>' . self::form( admin_url( 'admin.php?page=educore-experience' ) ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in form().
	}

	public static function manage_view( int $uid ): string {
		if ( class_exists( '\EduCore\Workspace\Shell' ) ) {
			\EduCore\Workspace\Shell::title( __( 'Experience settings', 'educore-experience' ) );
		}
		if ( ! self::can( $uid ) ) {
			return '<div class="ec-notice ec-notice--error" role="alert">' . esc_html__( 'You do not have access to this section.', 'educore-experience' ) . '</div>';
		}
		$back = class_exists( '\EduCore\Workspace\Pages' ) ? \EduCore\Workspace\Pages::url( 'manage', array( 'v' => 'experience' ) ) : home_url( '/' );
		return self::form( $back );
	}

	public static function nav( $items, $ws, $uid ) {
		$items = (array) $items;
		if ( 'manage' === $ws && self::can( (int) $uid ) && class_exists( '\EduCore\Workspace\Pages' ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- highlight only.
			$items[] = array( 'key' => 'experience', 'label' => __( 'Experience', 'educore-experience' ), 'url' => \EduCore\Workspace\Pages::url( 'manage', array( 'v' => 'experience' ) ), 'icon' => 'gauge', 'current' => 'experience' === sanitize_key( wp_unslash( $_GET['v'] ?? '' ) ) );
		}
		return $items;
	}

	private static function form( string $back ): string {
		$s     = self::all();
		$sched = Clock::schedule();
		$names = Appearance::labels();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
		$msg   = sanitize_key( $_GET['ec_xp'] ?? '' );
		$o     = '';
		if ( 'saved' === $msg ) {
			$o .= '<div class="ec-notice ec-notice--success notice notice-success" role="status"><p>' . esc_html__( 'Experience settings saved.', 'educore-experience' ) . '</p></div>';
		} elseif ( '' !== $msg ) {
			$o .= '<div class="ec-notice ec-notice--error notice notice-error" role="alert"><p>' . esc_html( get_transient( 'educore_xp_settings_error_' . get_current_user_id() ) ?: __( 'The settings were not saved.', 'educore-experience' ) ) . '</p></div>';
		}
		$o .= '<form class="ec-xp-settings" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		$o .= '<input type="hidden" name="action" value="educore_xp_settings"><input type="hidden" name="back" value="' . esc_attr( $back ) . '">' . wp_nonce_field( 'educore_xp_settings', '_wpnonce', true, false );

		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Appearance and time', 'educore-experience' ) . '</h2>';
		$o .= '<p><label for="ec-xp-mode"><strong>' . esc_html__( 'Default appearance for new users and visitors', 'educore-experience' ) . '</strong></label><br><select id="ec-xp-mode" name="default_mode">';
		foreach ( array( 'auto' => __( 'Automatic — time of day', 'educore-experience' ), 'system' => __( 'Follow the device (light or dark)', 'educore-experience' ), 'light' => __( 'Light', 'educore-experience' ), 'dark' => __( 'Dark', 'educore-experience' ) ) as $k => $l ) {
			$o .= '<option value="' . esc_attr( $k ) . '"' . selected( $s['default_mode'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		$o .= '</select></p>';
		$o .= '<p><label for="ec-xp-tz"><strong>' . esc_html__( 'Institution time zone', 'educore-experience' ) . '</strong></label><br>' . self::tz_select( 'institution_tz', (string) $s['institution_tz'], 'ec-xp-tz', __( 'Use the WordPress time zone', 'educore-experience' ) . ' (' . wp_timezone_string() . ')' ) . '<br><span class="ec-muted description">' . esc_html__( 'Used for people who have not chosen their own time zone.', 'educore-experience' ) . '</span></p>';
		$o .= '<fieldset><legend><strong>' . esc_html__( 'Time-of-day periods (start times)', 'educore-experience' ) . '</strong></legend><p class="ec-muted description">' . esc_html__( 'Each period lasts until the next one starts. These are display periods, not astronomical definitions.', 'educore-experience' ) . '</p><div class="ec-xp-grid">';
		foreach ( Clock::STATES as $st ) {
			$v  = sprintf( '%02d:%02d', intdiv( $sched[ $st ], 60 ), $sched[ $st ] % 60 );
			$o .= '<label class="ec-field"><span>' . esc_html( $names[ $st ] ) . '</span><input type="time" name="schedule[' . esc_attr( $st ) . ']" value="' . esc_attr( $v ) . '"' . ( 'midnight' === $st ? ' readonly' : '' ) . ' required></label>';
		}
		$o .= '</div></fieldset>';
		$o .= '<p><label for="ec-xp-eh"><strong>' . esc_html__( 'Sunrise/sunset mode: hours of Evening after twilight', 'educore-experience' ) . '</strong></label><br><input id="ec-xp-eh" type="number" min="1" max="6" name="evening_hours" value="' . esc_attr( (string) $s['evening_hours'] ) . '"></p>';
		$o .= '<p><label><input type="checkbox" name="defer_in_exams" value="1"' . checked( $s['defer_in_exams'], true, false ) . '> ' . esc_html__( 'Do not change the appearance while a timed assessment is open', 'educore-experience' ) . '</label></p></section>';

		$o .= '<section class="ec-card ec-ws-section"><h2>' . esc_html__( 'Welcome and onboarding', 'educore-experience' ) . '</h2>';
		$o .= '<p><label><input type="checkbox" name="welcome_enabled" value="1"' . checked( $s['welcome_enabled'], true, false ) . '> ' . esc_html__( 'Show the personal welcome card on workspace home pages', 'educore-experience' ) . '</label></p>';
		$o .= '<p><label><input type="checkbox" name="onboarding_enabled" value="1"' . checked( $s['onboarding_enabled'], true, false ) . '> ' . esc_html__( 'Offer the welcome tour after a person’s first sign-in', 'educore-experience' ) . '</label></p>';
		$o .= '<details><summary>' . esc_html__( 'Greeting texts (leave empty to use the built-in, translated texts)', 'educore-experience' ) . '</summary><p class="ec-muted description">' . esc_html__( 'Use {name} where the person’s preferred name should appear. It is left out when they asked not to be greeted by name.', 'educore-experience' ) . '</p>';
		foreach ( array( 'en' => 'English', 'fr' => 'Français', 'ar' => 'العربية' ) as $lang => $ln ) {
			$o .= '<fieldset' . ( 'ar' === $lang ? ' dir="rtl"' : '' ) . ' lang="' . esc_attr( $lang ) . '"><legend>' . esc_html( $ln ) . '</legend><div class="ec-xp-grid">';
			foreach ( Clock::STATES as $st ) {
				$o .= '<label class="ec-field"><span>' . esc_html( $names[ $st ] ) . '</span><input type="text" maxlength="140" name="greetings[' . esc_attr( $lang ) . '][' . esc_attr( $st ) . ']" value="' . esc_attr( (string) ( $s['greetings'][ $lang ][ $st ] ?? '' ) ) . '" placeholder="' . esc_attr( Greeting::builtin( $st, true, $lang ) ) . '"></label>';
			}
			$o .= '</div></fieldset>';
		}
		$o .= '</details></section>';
		$o .= '<p class="ec-ws-actions"><button type="submit" class="ec-btn ec-btn--primary button button-primary">' . esc_html__( 'Save settings', 'educore-experience' ) . '</button></p></form>';
		return $o;
	}

	public static function tz_select( string $name, string $value, string $id, string $empty_label ): string {
		$o = '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"><option value="">' . esc_html( $empty_label ) . '</option>';
		foreach ( \DateTimeZone::listIdentifiers() as $tz ) {
			$o .= '<option value="' . esc_attr( $tz ) . '"' . selected( $value, $tz, false ) . '>' . esc_html( str_replace( '_', ' ', $tz ) ) . '</option>';
		}
		return $o . '</select>';
	}

	public static function save(): void {
		$uid = get_current_user_id();
		if ( ! self::can( $uid ) || ! check_admin_referer( 'educore_xp_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to change these settings.', 'educore-experience' ), 403 );
		}
		$in = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized field by field.
		foreach ( array( 'welcome_enabled', 'onboarding_enabled', 'defer_in_exams' ) as $b ) {
			$in[ $b ] = ! empty( $in[ $b ] );
		}
		$in['schedule']['midnight'] = '00:00';
		$res  = self::sanitize( (array) $in );
		$back = wp_validate_redirect( (string) ( $in['back'] ?? '' ), admin_url( 'admin.php?page=educore-experience' ) );
		if ( is_wp_error( $res ) ) {
			set_transient( 'educore_xp_settings_error_' . $uid, $res->get_error_message(), 120 );
			wp_safe_redirect( add_query_arg( 'ec_xp', 'error', $back ) );
			exit;
		}
		update_option( self::OPTION, $res, false );
		self::flush();
		do_action( 'educore_xp_settings_saved' );
		Audit::log( 'experience.settings_saved', 'option', 0, array( 'default_mode' => $res['default_mode'], 'institution_tz' => $res['institution_tz'] ) );
		wp_safe_redirect( add_query_arg( 'ec_xp', 'saved', $back ) );
		exit;
	}
}
