<?php
namespace EduCore\Identity;

use EduCore\Core\Audit;
use EduCore\Core\Pages as CorePages;
use EduCore\Core\RateLimiter;

defined( 'ABSPATH' ) || exit;

/**
 * Sign-in, registration hand-off and account linking.
 *
 *   wp-login.php?action=educore_sso&provider=google   → provider's own consent screen (authorization code flow)
 *   /wp-json/educore/v1/identity/callback/google        → state + cookie binding, single use, code exchange,
 *                                                          ID-token verification (OIDC) or token inspection (Facebook)
 *   → linked account: normal WordPress sign-in (wp_login fires, so two-factor and suspension rules still apply)
 *   → no linked account: never auto-linked by e-mail. Open registration → EduCore's own registration form (age band and
 *     guardian consent unchanged); the identity is connected after that form succeeds. Closed registration → refused.
 */
final class Flow {
	public const COOKIE  = 'educore_sso_state';
	public const PENDING = 'educore_sso_pending';
	public const TTL     = 600;

	public static function register(): void {
		add_action( 'login_form_educore_sso', array( self::class, 'start' ) );
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
		add_action( 'admin_post_educore_sso_link', array( self::class, 'link_request' ) );
		add_action( 'admin_post_educore_sso_unlink', array( self::class, 'unlink_request' ) );
		add_action( 'educore/events/registered', array( self::class, 'complete_registration' ), 5 );
	}

	public static function start_url( string $p, string $redirect = '' ): string {
		return add_query_arg( array_filter( array( 'action' => 'educore_sso', 'provider' => $p, 'redirect_to' => $redirect ) ), wp_login_url() );
	}

	private static function fail( string $code, string $provider = '', array $ctx = array() ): void {
		Audit::log( 'identity.failed', 'identity', 0, array_merge( array( 'provider' => $provider, 'reason' => $code ), $ctx ) );
		self::go( add_query_arg( 'educore_sso_error', $code, wp_login_url() ) );
	}

	/**
	 * Every exit from the flow is a redirect. The action lets automated tests observe the destination
	 * (they throw from it); it carries no secret (the URL is what the browser would see anyway).
	 */
	private static function go( string $url, bool $safe = true ): void {
		do_action( 'educore/identity/redirect', $url );
		if ( $safe ) {
			wp_safe_redirect( $url );
		} else {
			wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect -- provider host validated by the caller.
		}
		exit;
	}

	private static function set_cookie( string $name, string $value, int $ttl ): void {
		if ( ! headers_sent() ) {
			setcookie( $name, $value, array( 'expires' => $ttl ? time() + $ttl : time() - 3600, 'path' => COOKIEPATH ?: '/', 'domain' => COOKIE_DOMAIN ?: '', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
		}
		if ( $ttl ) {
			$_COOKIE[ $name ] = $value;
		} else {
			unset( $_COOKIE[ $name ] );
		}
	}

	private static function b64url( string $raw ): string {
		return rtrim( strtr( base64_encode( $raw ), '+/', '-_' ), '=' );
	}

	/** Begin a sign-in (or, with $link_uid, a linking) round-trip. */
	public static function begin( string $p, string $mode, int $link_uid = 0, string $redirect = '' ): void {
		if ( ! Providers::available( $p ) && ! ( 'test' === $mode && Providers::configured( $p ) ) ) {
			self::fail( 'unavailable', $p );
		}
		if ( ! RateLimiter::hit( 'sso_start', RateLimiter::client_key() ) ) {
			self::fail( 'throttled', $p );
		}
		$def      = Providers::def( $p );
		$state    = self::b64url( random_bytes( 32 ) );
		$nonce    = self::b64url( random_bytes( 24 ) );
		$verifier = $def['pkce'] ? self::b64url( random_bytes( 48 ) ) : '';
		set_transient(
			'educore_sso_' . hash( 'sha256', $state ),
			array( 'p' => $p, 'nonce' => $nonce, 'verifier' => $verifier, 'mode' => $mode, 'uid' => $link_uid, 'redirect' => $redirect, 'ip' => hash( 'sha256', RateLimiter::client_key() ) ),
			self::TTL
		);
		self::set_cookie( self::COOKIE, $state, self::TTL );
		$c    = Providers::config( $p );
		$args = array( 'response_type' => 'code', 'client_id' => (string) $c['client_id'], 'redirect_uri' => Providers::callback_url( $p ), 'scope' => $def['scope'], 'state' => $state );
		if ( 'facebook' === $def['type'] ) {
			$auth = Providers::expand( (string) $def['authorize'], $p );
		} else {
			$disc = Oidc::discovery( $p );
			if ( is_wp_error( $disc ) ) {
				self::fail( 'provider_down', $p, array( 'detail' => $disc->get_error_message() ) );
			}
			$auth           = (string) $disc['authorization_endpoint'];
			$args['nonce']  = $nonce;
			$args['prompt'] = 'select_account';
			if ( $verifier ) {
				$args['code_challenge']        = self::b64url( hash( 'sha256', $verifier, true ) );
				$args['code_challenge_method'] = 'S256';
			}
		}
		$url = add_query_arg( array_map( 'rawurlencode', $args ), $auth );
		if ( ! Providers::url_allowed( $url, $p ) ) {
			self::fail( 'provider_down', $p );
		}
		self::go( $url, false );
	}

	public static function start(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- sign-in start is protected by state + cookie binding.
		$p        = sanitize_key( wp_unslash( $_GET['provider'] ?? '' ) );
		$redirect = wp_validate_redirect( esc_url_raw( wp_unslash( $_GET['redirect_to'] ?? '' ) ), '' );
		// phpcs:enable
		if ( ! in_array( $p, Providers::KEYS, true ) ) {
			self::fail( 'unavailable' );
		}
		if ( is_user_logged_in() ) {
			self::go( $redirect ?: admin_url() );
		}
		self::begin( $p, 'login', 0, $redirect );
	}

	public static function routes(): void {
		register_rest_route(
			'educore/v1',
			'/identity/callback/(?P<provider>[a-z]+)',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true', // Public by nature; protected by state, cookie binding and single use.
				'callback'            => array( self::class, 'callback' ),
			)
		);
	}

	/** @return array{sub:string,email:string,email_verified:bool,name:string}|\WP_Error */
	public static function identity_from_code( string $p, string $code, array $st ) {
		$def = Providers::def( $p );
		if ( 'facebook' === $def['type'] ) {
			return Facebook::identity( $p, $code );
		}
		$disc = Oidc::discovery( $p );
		if ( is_wp_error( $disc ) ) {
			return $disc;
		}
		$tok = Oidc::exchange( $p, (string) $disc['token_endpoint'], $code, (string) $st['verifier'] );
		if ( is_wp_error( $tok ) ) {
			return $tok;
		}
		$cl = Oidc::verify_id_token( $p, (string) $tok['id_token'], $disc, (string) $st['nonce'] );
		if ( is_wp_error( $cl ) ) {
			return $cl;
		}
		$ev = $cl['email_verified'] ?? false;
		return array(
			'sub'            => (string) $cl['sub'],
			'email'          => sanitize_email( (string) ( $cl['email'] ?? '' ) ),
			// Only providers whose e-mail claim is documented as verifiable may report it verified.
			'email_verified' => $def['trust_email'] && ( true === $ev || 'true' === $ev ),
			'name'           => sanitize_text_field( (string) ( $cl['name'] ?? trim( ( $cl['given_name'] ?? '' ) . ' ' . ( $cl['family_name'] ?? '' ) ) ) ),
		);
	}

	public static function callback( \WP_REST_Request $r ) {
		$p = sanitize_key( (string) $r['provider'] );
		if ( ! in_array( $p, Providers::KEYS, true ) ) {
			self::fail( 'unavailable' );
		}
		if ( ! RateLimiter::hit( 'sso_callback', RateLimiter::client_key() ) ) {
			self::fail( 'throttled', $p );
		}
		$state  = (string) $r->get_param( 'state' );
		$cookie = isset( $_COOKIE[ self::COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) : '';
		$key    = 'educore_sso_' . hash( 'sha256', $state );
		$st     = '' !== $state ? get_transient( $key ) : false;
		delete_transient( $key ); // Single use: a replayed callback finds nothing.
		self::set_cookie( self::COOKIE, '', 0 );
		if ( '' === $state || '' === $cookie || ! hash_equals( $cookie, $state ) || ! is_array( $st ) || $st['p'] !== $p ) {
			self::fail( 'state', $p );
		}
		// WordPress core removes "error" from $_GET while parsing pretty-permalink requests, so read the provider's
		// OAuth error from the raw query string as well (DEF-15-03).
		$raw = array();
		wp_parse_str( isset( $_SERVER['QUERY_STRING'] ) ? (string) wp_unslash( $_SERVER['QUERY_STRING'] ) : '', $raw ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- parsed, then each value sanitised.
		$err = sanitize_key( (string) ( $r->get_param( 'error' ) ?: ( $raw['error'] ?? '' ) ) );
		if ( '' !== $err ) {
			self::fail( 'access_denied' === $err ? 'cancelled' : 'provider_error', $p, array( 'error' => $err ) );
		}
		$code = (string) $r->get_param( 'code' );
		if ( '' === $code ) {
			self::fail( 'provider_error', $p );
		}
		$id = self::identity_from_code( $p, $code, $st );
		if ( is_wp_error( $id ) ) {
			self::fail( 'verify', $p, array( 'detail' => $id->get_error_code() ) );
		}
		if ( 'test' === $st['mode'] ) {
			Admin::record_test( $p, $id, (int) $st['uid'] );
			self::go( admin_url( 'admin.php?page=educore-identity&tested=' . $p ) );
		}
		if ( 'link' === $st['mode'] ) {
			return self::finish_link( $p, $id, (int) $st['uid'] );
		}
		return self::finish_login( $p, $id, (string) $st['redirect'] );
	}

	private static function finish_login( string $p, array $id, string $redirect ) {
		$link = Links::find( $p, $id['sub'] );
		if ( $link ) {
			$user = get_userdata( (int) $link['user_id'] );
			if ( ! $user ) {
				Links::remove_user( (int) $link['user_id'] );
				self::fail( 'not_linked', $p );
			}
			if ( class_exists( '\EduCore\Core\Auth\Suspension' ) && \EduCore\Core\Auth\Suspension::is_suspended( $user->ID ) ) {
				self::fail( 'suspended', $p, array( 'user' => $user->ID ) );
			}
			Links::touch( (int) $link['id'] );
			Audit::log( 'identity.login', 'user', $user->ID, array( 'provider' => $p ) );
			wp_set_current_user( $user->ID );
			wp_set_auth_cookie( $user->ID, false, is_ssl() );
			$_REQUEST['redirect_to'] = $redirect; // Two-factor (if enabled) reads this when it takes over.
			// The callback is a REST route (JSON by default). Plugins that take over on wp_login (two-factor) render an
			// HTML page, so switch the response type before handing over (DEF-15-04).
			if ( ! headers_sent() ) {
				header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
			}
			/** Same hook as a password sign-in: two-factor, audit and routing plugins run as usual. */
			do_action( 'wp_login', $user->user_login, $user );
			$to = apply_filters( 'login_redirect', $redirect ?: admin_url(), $redirect, $user );
			self::go( wp_validate_redirect( (string) $to, CorePages::url( 'dashboard' ) ) );
		}
		// Unknown identity. Never matched to an existing account by e-mail.
		if ( CorePages::registration_open() && $id['email_verified'] && '' !== $id['email'] ) {
			$token = self::b64url( random_bytes( 24 ) );
			set_transient( 'educore_sso_pending_' . hash( 'sha256', $token ), array( 'p' => $p, 'id' => $id ), 15 * MINUTE_IN_SECONDS );
			self::set_cookie( self::PENDING, $token, 15 * MINUTE_IN_SECONDS );
			Audit::log( 'identity.registration_started', 'identity', 0, array( 'provider' => $p ) );
			self::go( add_query_arg( array( 'educore_sso' => 'register', 'provider' => $p ), CorePages::url( 'register' ) ) );
		}
		self::fail( 'not_linked', $p );
	}

	private static function finish_link( string $p, array $id, int $uid ) {
		$current = (int) wp_validate_auth_cookie( '', 'logged_in' );
		$back    = Connected::url();
		if ( ! $uid || $current !== $uid ) {
			self::fail( 'state', $p, array( 'mode' => 'link' ) );
		}
		$res = Links::add( $uid, $p, $id );
		if ( is_wp_error( $res ) ) {
			Audit::log( 'identity.link_refused', 'user', $uid, array( 'provider' => $p, 'reason' => $res->get_error_code() ) );
			self::go( add_query_arg( 'educore_sso_msg', $res->get_error_code(), $back ) );
		}
		Audit::log( 'identity.linked', 'user', $uid, array( 'provider' => $p ) );
		self::go( add_query_arg( 'educore_sso_msg', 'linked', $back ) );
	}

	/** Called after EduCore's own registration succeeded in the browser that started a social sign-in. */
	public static function complete_registration( $uid ): void {
		$token = isset( $_COOKIE[ self::PENDING ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::PENDING ] ) ) : '';
		if ( '' === $token ) {
			return;
		}
		$key = 'educore_sso_pending_' . hash( 'sha256', $token );
		$pen = get_transient( $key );
		delete_transient( $key );
		self::set_cookie( self::PENDING, '', 0 );
		if ( is_array( $pen ) && in_array( $pen['p'], Providers::KEYS, true ) ) {
			$res = Links::add( (int) $uid, (string) $pen['p'], (array) $pen['id'] );
			Audit::log( is_wp_error( $res ) ? 'identity.link_refused' : 'identity.linked', 'user', (int) $uid, array( 'provider' => $pen['p'], 'via' => 'registration' ) );
		}
	}

	/** Password re-confirmation for connecting / disconnecting (sensitive account changes). */
	private static function confirm_password( int $uid ): bool {
		$u  = get_userdata( $uid );
		$pw = isset( $_POST['current_password'] ) ? (string) wp_unslash( $_POST['current_password'] ) : ''; // phpcs:ignore WordPress.Security -- verified by caller; passwords are not sanitised.
		return $u && '' !== $pw && wp_check_password( $pw, $u->user_pass, $uid );
	}

	public static function link_request(): void {
		$uid = get_current_user_id();
		$p   = sanitize_key( wp_unslash( $_POST['provider'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification -- checked next.
		if ( ! $uid || ! check_admin_referer( 'educore_sso_link_' . $p ) || ! in_array( $p, Providers::KEYS, true ) ) {
			wp_die( esc_html__( 'Please sign in again.', 'educore-identity' ), 403 );
		}
		if ( ! RateLimiter::hit( 'sso_link', (string) $uid ) ) {
			self::go( add_query_arg( 'educore_sso_msg', 'throttled', Connected::url() ) );
		}
		if ( ! self::confirm_password( $uid ) ) {
			Audit::log( 'identity.link_refused', 'user', $uid, array( 'provider' => $p, 'reason' => 'password' ) );
			self::go( add_query_arg( 'educore_sso_msg', 'password', Connected::url() ) );
		}
		self::begin( $p, 'link', $uid );
	}

	public static function unlink_request(): void {
		$uid = get_current_user_id();
		$p   = sanitize_key( wp_unslash( $_POST['provider'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification -- checked next.
		if ( ! $uid || ! check_admin_referer( 'educore_sso_unlink_' . $p ) ) {
			wp_die( esc_html__( 'Please sign in again.', 'educore-identity' ), 403 );
		}
		if ( ! self::confirm_password( $uid ) ) {
			self::go( add_query_arg( 'educore_sso_msg', 'password', Connected::url() ) );
		}
		// The EduCore password always remains a working way to sign in, so removing a connection never locks anyone out.
		$ok = Links::remove( $uid, $p );
		Audit::log( 'identity.unlinked', 'user', $uid, array( 'provider' => $p ) );
		self::go( add_query_arg( 'educore_sso_msg', $ok ? 'unlinked' : 'nothing', Connected::url() ) );
	}
}
