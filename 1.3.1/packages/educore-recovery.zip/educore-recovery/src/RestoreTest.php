<?php
namespace EduCore\Recovery;

use EduCore\Core\Audit;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Non-destructive restore test: the dump is loaded into isolated scratch tables ({prefix}ecrt_*),
 * every table's row count and content fingerprint is compared with the manifest, then the scratch
 * tables are dropped. Live tables are never read for writing, renamed or replaced.
 */
final class RestoreTest {
	public const SCRATCH = 'ecrt_';

	/** @return array{ok:bool,report:array} */
	public static function run( int $id ): array {
		global $wpdb;
		$started = microtime( true );
		$b       = Backup::get( $id );
		$report  = array( 'tables' => array(), 'errors' => array() );
		if ( ! $b || 'complete' !== $b->status ) {
			return array( 'ok' => false, 'report' => array( 'errors' => array( __( 'Backup not found or not complete.', 'educore-recovery' ) ) ) );
		}
		$v = Verifier::verify( $id );
		if ( ! $v['ok'] ) {
			$report['errors'] = $v['errors'];
			return self::finish( $b, false, $report, $started );
		}
		$h = Backup::open( $b );
		if ( is_wp_error( $h ) ) {
			$report['errors'][] = $h->get_error_message();
			return self::finish( $b, false, $report, $started );
		}
		$man    = $h['manifest'];
		$sql    = Backup::extract_sql( $h['zip'] );
		$h['cleanup']();
		$prefix = $wpdb->prefix . self::SCRATCH;
		$rels   = array_keys( (array) $man['tables'] );
		self::drop( $prefix, $rels );
		$loaded = Dumper::load( $sql, $prefix, $rels );
		wp_delete_file( $sql );
		if ( is_wp_error( $loaded ) ) {
			$report['errors'][] = $loaded->get_error_message();
		} else {
			foreach ( $man['tables'] as $rel => $exp ) {
				$name = $prefix . substr( $rel, strlen( Dumper::PH ) );
				$got  = Dumper::fingerprint( $name );
				$ok   = $got['rows'] === (int) $exp['rows'] && hash_equals( (string) $exp['sha256'], $got['sha256'] );
				$report['tables'][ substr( $rel, strlen( Dumper::PH ) ) ] = array( 'expected' => (int) $exp['rows'], 'restored' => $got['rows'], 'match' => $ok );
				if ( ! $ok ) {
					$report['errors'][] = sprintf( /* translators: %s: table */ __( 'Restored data differs for table %s', 'educore-recovery' ), $rel );
				}
			}
		}
		self::drop( $prefix, $rels );
		return self::finish( $b, ! $report['errors'], $report, $started );
	}

	public static function drop( string $prefix, array $rels ): void {
		global $wpdb;
		foreach ( $rels as $rel ) {
			$name = $prefix . substr( $rel, strlen( Dumper::PH ) );
			$wpdb->query( "DROP TABLE IF EXISTS `{$name}`" ); // phpcs:ignore WordPress.DB.PreparedSQL -- name built from our prefix + manifest table name.
		}
	}

	private static function finish( object $b, bool $ok, array $report, float $started ): array {
		$report['seconds'] = round( microtime( true ) - $started, 2 );
		$report['rows']    = array_sum( array_column( $report['tables'] ?? array(), 'restored' ) );
		Backup::update(
			(int) $b->id,
			array(
				'restore_test_status' => $ok ? 'passed' : 'failed',
				'restore_tested_at'   => Schema::now(),
				'restore_test_report' => wp_json_encode( $report ),
			)
		);
		Audit::log( $ok ? 'backup.restore_test_passed' : 'backup.restore_test_failed', 'backup', (int) $b->id, array( 'uid' => $b->uid, 'seconds' => $report['seconds'] ) );
		return array( 'ok' => $ok, 'report' => $report );
	}
}
