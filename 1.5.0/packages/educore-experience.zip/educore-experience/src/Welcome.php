<?php
namespace EduCore\Experience;

use EduCore\Core\Pages as CorePages;

defined( 'ABSPATH' ) || exit;

/**
 * Personal welcome card (greeting + verified facts + role actions), learner widgets (suggestions, goals),
 * widget visibility, the Preferences link in the shell and role-specific quick actions.
 */
final class Welcome {
	/** Query parameters that mean "a sub-view", where the welcome card would get in the way. */
	/** Query parameters that do not change which screen is shown. Any other parameter means a sub-view (editor, detail…). */
	private const NEUTRAL = array( 'lang', 'ec_xp', 'ec_resume', 'msg', 'updated', 'utm_source', 'utm_medium', 'utm_campaign' );

	public static function register(): void {
		add_filter( 'educore/shell/before_body', array( self::class, 'before_body' ), 10, 3 );
		add_filter( 'educore/dashboard/student', array( self::class, 'hide_widgets' ), 99, 2 );
		add_filter( 'educore/shell/quick_actions', array( self::class, 'quick_actions' ), 20, 3 );
		add_filter( 'educore/shell/account_links', array( self::class, 'account_links' ), 10, 2 );
		add_filter( 'educore/shell/nav', array( self::class, 'nav' ), 20, 3 );
	}

	public static function is_home_view(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- routing check only (keys, no values used).
		return ! array_diff( array_map( 'strval', array_keys( $_GET ) ), self::NEUTRAL ); // DEF-15-05: allowlist, not denylist.
	}

	public static function before_body( $html, $ws, $uid ) {
		$uid = (int) $uid;
		if ( ! $uid || ! Settings::get( 'welcome_enabled' ) || ! self::is_home_view() || in_array( $ws, array( 'help', 'account' ), true ) ) {
			return $html;
		}
		$own = array( Plugin::page_id( 'preferences' ), Plugin::page_id( 'welcome' ) );
		if ( in_array( (int) get_queried_object_id(), $own, true ) ) {
			return $html;
		}
		$p      = Prefs::get( $uid );
		$lens   = 'student' === $ws ? 'student' : Plugin::lens( $uid );
		$blocks = array();
		foreach ( $p['widget_order'] as $w ) {
			if ( in_array( $w, $p['hidden_widgets'], true ) ) {
				continue;
			}
			if ( 'welcome' === $w ) {
				$blocks[] = self::card( $uid, $lens );
			} elseif ( 'student' === $lens && 'suggestions' === $w ) {
				$blocks[] = self::suggestions( $uid );
			} elseif ( 'student' === $lens && 'goals' === $w ) {
				$blocks[] = self::goals( $uid );
			}
		}
		array_unshift( $blocks, Onboarding::banner( $uid ) );
		$blocks = array_filter( $blocks );
		return $blocks ? $html . '<div class="ec-xp-stack" data-ec-xp-stack>' . implode( '', $blocks ) . '</div>' : $html;
	}

	public static function card( int $uid, string $lens ): string {
		$st    = Clock::state( $uid );
		$facts = array_slice( Facts::collect( $uid, $lens ), 0, 3 );
		$tz    = new \DateTimeZone( $st['tz'] );
		$o     = '<section class="ec-xp-welcome ec-card" data-ec-xp-widget="welcome" data-ec-xp-state="' . esc_attr( $st['state'] ) . '" aria-labelledby="ec-xp-welcome-h">';
		$o    .= '<div class="ec-xp-welcome__art" aria-hidden="true">' . Appearance::icon( $st['state'] ) . '</div><div class="ec-xp-welcome__body">';
		$o    .= '<p class="ec-xp-welcome__date"><time datetime="' . esc_attr( wp_date( 'c', time(), $tz ) ) . '">' . esc_html( Clock::format( time(), $st['tz'], false, true ) ) . '</time></p>';
		$o    .= '<h2 id="ec-xp-welcome-h" class="ec-xp-welcome__title">' . esc_html( Greeting::line( $uid, $st['state'] ) ) . '</h2>';
		if ( $facts ) {
			$o .= '<ul class="ec-xp-facts">';
			foreach ( $facts as $f ) {
				$o .= '<li class="ec-xp-fact ec-xp-fact--' . esc_attr( $f['kind'] ) . '">' . ( $f['url'] ? '<a href="' . esc_url( $f['url'] ) . '">' . esc_html( $f['text'] ) . '</a>' : esc_html( $f['text'] ) ) . '</li>';
			}
			$o .= '</ul>';
		}
		$o .= '</div></section>';
		return $o;
	}

	public static function suggestions( int $uid ): string {
		$items = Recommend::for_student( $uid );
		$o     = '<section class="ec-xp-suggest ec-card" id="ec-xp-suggestions" data-ec-xp-widget="suggestions" aria-labelledby="ec-xp-suggest-h"><h2 id="ec-xp-suggest-h">' . esc_html__( 'Suggested for you', 'educore-experience' ) . '</h2>';
		if ( ! $items ) {
			$has_courses = ! empty( Facts::dashboard( $uid )['courses'] );
			return $o . '<p class="ec-xp-empty">' . ( $has_courses
				? esc_html__( 'You are up to date. New suggestions appear here when lessons, assessments or feedback are waiting for you.', 'educore-experience' )
				: esc_html__( 'No courses yet. Your suggestions will appear here once you are enrolled in a course.', 'educore-experience' ) . ' <a href="' . esc_url( CorePages::url( 'courses' ) ) . '">' . esc_html__( 'Browse the course catalogue', 'educore-experience' ) . '</a>' ) . '</p></section>';
		}
		$o .= '<ol class="ec-xp-suggest__list">';
		foreach ( $items as $it ) {
			$o .= '<li class="ec-xp-suggest__item ec-xp-suggest__item--' . esc_attr( $it['kind'] ) . '"><a href="' . esc_url( $it['url'] ) . '"><span class="ec-xp-suggest__title">' . esc_html( $it['title'] ) . '</span>' . ( '' !== $it['context'] ? '<span class="ec-xp-suggest__ctx">' . esc_html( $it['context'] ) . '</span>' : '' ) . '</a><p class="ec-xp-suggest__why"><span class="screen-reader-text">' . esc_html__( 'Why:', 'educore-experience' ) . ' </span>' . esc_html( $it['reason'] ) . '</p></li>';
		}
		return $o . '</ol></section>';
	}

	public static function goals( int $uid ): string {
		$p  = Prefs::get( $uid );
		$o  = '<section class="ec-xp-goals ec-card" data-ec-xp-widget="goals" aria-labelledby="ec-xp-goals-h"><h2 id="ec-xp-goals-h">' . esc_html__( 'My study goals', 'educore-experience' ) . '</h2>';
		$ed = Plugin::url( 'preferences' ) . '#ec-xp-s-goals';
		if ( $p['goals_paused'] ) {
			return $o . '<p class="ec-xp-empty">' . esc_html__( 'Your goals are paused. Nothing is counted while they are paused.', 'educore-experience' ) . ' <a href="' . esc_url( $ed ) . '">' . esc_html__( 'Resume or change goals', 'educore-experience' ) . '</a></p></section>';
		}
		$g   = Facts::dashboard( $uid )['goal'] ?? array( 'done' => 0, 'target' => $p['lessons_goal'] );
		$o  .= '<ul class="ec-xp-goals__list">' . self::meter( __( 'Lessons this week', 'educore-experience' ), (int) $g['done'], (int) $g['target'] );
		if ( $p['practice_goal'] > 0 ) {
			$done = Recommend::practice_done( $uid );
			if ( null !== $done ) {
				$o .= self::meter( __( 'Practice questions this week', 'educore-experience' ), $done, (int) $p['practice_goal'] );
			}
		}
		return $o . '</ul><p><a href="' . esc_url( $ed ) . '">' . esc_html__( 'Change or pause my goals', 'educore-experience' ) . '</a></p></section>';
	}

	private static function meter( string $label, int $done, int $target ): string {
		$pct = (int) min( 100, round( $done * 100 / max( 1, $target ) ) );
		/* translators: 1: done, 2: target */
		$val = sprintf( __( '%1$s of %2$s', 'educore-experience' ), number_format_i18n( $done ), number_format_i18n( $target ) );
		return '<li class="ec-xp-meter' . ( $done >= $target ? ' is-met' : '' ) . '"><span class="ec-xp-meter__label">' . esc_html( $label ) . '</span><span class="ec-xp-meter__value">' . esc_html( $val ) . '</span><span class="ec-xp-meter__bar" role="progressbar" aria-label="' . esc_attr( $label ) . '" aria-valuemin="0" aria-valuemax="' . esc_attr( (string) $target ) . '" aria-valuenow="' . esc_attr( (string) min( $done, $target ) ) . '" aria-valuetext="' . esc_attr( $val ) . '"><span style="inline-size:' . esc_attr( (string) $pct ) . '%"></span></span></li>';
	}

	/** Core dashboard sections the learner chose to hide (their data is simply not passed to the renderer). */
	public static function hide_widgets( $data, $uid ) {
		$hidden = Prefs::get( (int) $uid )['hidden_widgets'];
		foreach ( array( 'upcoming', 'pending', 'results', 'announcements', 'certificates', 'achievements' ) as $k ) {
			if ( in_array( $k, $hidden, true ) && isset( $data[ $k ] ) ) {
				$data[ $k ] = array();
			}
		}
		return $data;
	}

	public static function quick_actions( $q, $ws, $uid ) {
		$q   = (array) $q;
		$uid = (int) $uid;
		$th  = class_exists( '\EduCore\TeachingHub\Portal' );
		if ( $th && user_can( $uid, 'ec_teach' ) ) {
			$q[] = array( 'label' => __( 'Review submissions', 'educore-experience' ), 'url' => \EduCore\TeachingHub\Portal::url( 'grading' ) );
		}
		if ( user_can( $uid, 'ec_tutor_sessions' ) && class_exists( '\EduCore\Workspace\Pages' ) ) {
			$q[] = array( 'label' => __( 'My tutoring sessions', 'educore-experience' ), 'url' => \EduCore\Workspace\Pages::url( 'tutor' ) );
		}
		if ( user_can( $uid, 'ec_learn' ) ) {
			$q[] = array( 'label' => __( 'Course catalogue', 'educore-experience' ), 'url' => CorePages::url( 'courses' ) );
		}
		if ( user_can( $uid, 'manage_options' ) && class_exists( '\EduCore\Workspace\Pages' ) ) {
			$q[] = array( 'label' => __( 'Platform health', 'educore-experience' ), 'url' => \EduCore\Workspace\Pages::url( 'manage', array( 'v' => 'system' ) ) );
		}
		$q[] = array( 'label' => __( 'My preferences', 'educore-experience' ), 'url' => Plugin::url( 'preferences' ) );
		return $q;
	}

	public static function account_links( $links, $uid ) {
		$links   = (array) $links;
		$links[] = array( __( 'Preferences', 'educore-experience' ), Plugin::url( 'preferences' ) );
		return $links;
	}

	public static function nav( $items, $ws, $uid ) {
		$items = (array) $items;
		$cur   = (int) get_queried_object_id() === Plugin::page_id( 'preferences' );
		$items[] = array( 'key' => 'preferences', 'label' => __( 'Preferences', 'educore-experience' ), 'url' => Plugin::url( 'preferences' ), 'icon' => 'gauge', 'current' => $cur );
		return $items;
	}
}
