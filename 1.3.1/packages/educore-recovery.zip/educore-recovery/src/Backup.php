<?php
namespace EduCore\Recovery;

use EduCore\Core\Audit;
use EduCore\Core\Registry;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Creates backups: consistent database snapshot + files, packaged with a checksummed manifest,
 * optionally encrypted with a key held in wp-config (never in the database or the archive).
 */
final class Backup {
	public const FORMAT = 1;

	/** Backup kinds → [database scope, file roots]. */
	public static function kinds(): array {
		return array(
			'full'          => array( 'label' => __( 'Full (database + EduCore code + uploads)', 'educore-recovery' ), 'db' => 'all', 'files' => array( 'plugins', 'themes', 'uploads' ) ),
			'academic'      => array( 'label' => __( 'Academic data (EduCore + users, content, settings)', 'educore-recovery' ), 'db' => 'academic', 'files' => array() ),
			'configuration' => array( 'label' => __( 'Configuration (site settings only)', 'educore-recovery' ), 'db' => 'configuration', 'files' => array() ),
			'predeploy'     => array( 'label' => __( 'Pre-deployment (database + EduCore code)', 'educore-recovery' ), 'db' => 'all', 'files' => array( 'plugins', 'themes' ) ),
		);
	}

	public static function table(): string {
		return Schema::table( 'rc_backups' );
	}

	public static function get( int $id ): ?object {
		global $wpdb;
		$t = self::table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ) ) ?: null; // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function by_uid( string $uid ): ?object {
		global $wpdb;
		$t = self::table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE uid = %s", $uid ) ) ?: null; // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function list( int $limit = 50 ): array {
		global $wpdb;
		$t = self::table();
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} ORDER BY id DESC LIMIT %d", $limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function update( int $id, array $data ): void {
		global $wpdb;
		$wpdb->update( self::table(), $data, array( 'id' => $id ) );
	}

	private static function db_tables( string $scope ): array {
		global $wpdb;
		if ( 'configuration' === $scope ) {
			return array( $wpdb->options );
		}
		return Dumper::tables( 'academic' === $scope ? 'academic' : 'all' );
	}

	/** File roots for a kind: rel prefix → absolute dir. */
	public static function roots( array $which ): array {
		$out = array();
		if ( in_array( 'plugins', $which, true ) ) {
			foreach ( (array) glob( WP_PLUGIN_DIR . '/educore-*', GLOB_ONLYDIR ) as $d ) {
				$out[ 'plugins/' . basename( $d ) ] = $d;
			}
		}
		if ( in_array( 'themes', $which, true ) && is_dir( get_theme_root() . '/educore-theme' ) ) {
			$out['themes/educore-theme'] = get_theme_root() . '/educore-theme';
		}
		if ( in_array( 'uploads', $which, true ) ) {
			$up = wp_upload_dir( null, false );
			if ( is_dir( $up['basedir'] ) ) {
				$out['uploads'] = $up['basedir'];
			}
		}
		return $out;
	}

	/** @return array<string,string> rel path => absolute path */
	private static function collect( array $roots, array &$skipped ): array {
		$files = array();
		$max   = (int) Settings::get( 'max_file_mb' ) * 1048576;
		$self  = wp_normalize_path( Store::dir() );
		foreach ( $roots as $rel => $abs ) {
			$it = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $abs, \FilesystemIterator::SKIP_DOTS ) );
			foreach ( $it as $f ) {
				/** @var \SplFileInfo $f */
				$p = wp_normalize_path( $f->getPathname() );
				if ( ! $f->isFile() || $f->isLink() || 0 === strpos( $p, $self . '/' ) || preg_match( '#/educore-backups-[a-z0-9]+/#', $p ) ) {
					continue;
				}
				if ( $max > 0 && $f->getSize() > $max ) {
					$skipped[] = $rel . substr( $p, strlen( wp_normalize_path( $abs ) ) );
					continue;
				}
				$files[ $rel . substr( $p, strlen( wp_normalize_path( $abs ) ) ) ] = $p;
			}
		}
		ksort( $files );
		return $files;
	}

	/** Versions of every registered EduCore component and every EduCore schema. */
	public static function versions(): array {
		global $wpdb;
		$schemas = $wpdb->get_results( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE 'educore\\_%db\\_version'", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return array(
			'wordpress'  => get_bloginfo( 'version' ),
			'php'        => PHP_VERSION,
			'mysql'      => (string) $wpdb->db_version(),
			'components' => Registry::all(),
			'schemas'    => wp_list_pluck( $schemas, 'option_value', 'option_name' ),
			'theme'      => wp_get_theme()->get_stylesheet() . ' ' . wp_get_theme()->get( 'Version' ),
		);
	}

	/**
	 * @return int|\WP_Error Backup id.
	 */
	public static function create( string $kind, string $trigger = 'manual', int $user = 0 ) {
		global $wpdb;
		$kinds = self::kinds();
		if ( ! isset( $kinds[ $kind ] ) ) {
			return new \WP_Error( 'ec_rc_kind', __( 'Unknown backup type.', 'educore-recovery' ) );
		}
		$dir = Store::dir();
		if ( '' === $dir ) {
			return new \WP_Error( 'ec_rc_dir', __( 'No writable backup storage is available.', 'educore-recovery' ) );
		}
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new \WP_Error( 'ec_rc_zip', __( 'The PHP zip extension is required.', 'educore-recovery' ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		wp_raise_memory_limit( 'admin' );
		$uid = Plugin::uid();
		$wpdb->insert(
			self::table(),
			array(
				'uid'            => $uid,
				'kind'           => $kind,
				'trigger_source' => sanitize_key( $trigger ),
				'status'         => 'running',
				'created_by'     => $user ?: get_current_user_id(),
				'created_at'     => Schema::now(),
			)
		);
		$id   = (int) $wpdb->insert_id;
		$sql  = Store::tmp( '.sql' );
		$zipf = $dir . "/educore-{$kind}-{$uid}.zip";
		try {
			$def     = $kinds[ $kind ];
			$tables  = self::db_tables( $def['db'] );
			$fp      = Dumper::dump( $tables, $sql );
			$skipped = array();
			$files   = self::collect( self::roots( $def['files'] ), $skipped );

			$zip = new \ZipArchive();
			if ( true !== $zip->open( $zipf, \ZipArchive::CREATE | \ZipArchive::OVERWRITE ) ) {
				throw new \RuntimeException( __( 'Could not create the archive.', 'educore-recovery' ) );
			}
			$entries = array( 'database.sql' => array( 'size' => filesize( $sql ), 'sha256' => hash_file( 'sha256', $sql ) ) );
			$zip->addFile( $sql, 'database.sql' );
			foreach ( $files as $rel => $abs ) {
				$entries[ 'files/' . $rel ] = array( 'size' => filesize( $abs ), 'sha256' => hash_file( 'sha256', $abs ) );
				$zip->addFile( $abs, 'files/' . $rel );
			}
			$manifest = array(
				'format'       => self::FORMAT,
				'generator'    => 'educore-recovery ' . EDUCORE_RC_VERSION,
				'backup_id'    => $uid,
				'kind'         => $kind,
				'trigger'      => $trigger,
				'created_at'   => gmdate( 'c' ),
				'site'         => array( 'home' => home_url(), 'multisite' => is_multisite() ),
				'versions'     => self::versions(),
				'scope'        => array( 'database' => $def['db'], 'files' => array_keys( self::roots( $def['files'] ) ) ),
				'tables'       => $fp,
				'entries'      => $entries,
				'skipped'      => $skipped,
				'excluded'     => array( 'wp-config.php', 'backup storage', 'backup history table', 'encryption key' ),
				'consistency'  => 'InnoDB consistent snapshot (single read view)',
			);
			$zip->addFromString( 'manifest.json', (string) wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
			if ( ! $zip->close() ) {
				throw new \RuntimeException( __( 'Could not write the archive (disk full?).', 'educore-recovery' ) );
			}
			wp_delete_file( $sql );

			$final = $zipf;
			$key   = Settings::key();
			if ( $key ) {
				$final = $zipf . '.enc';
				Store::encrypt( $zipf, $final, $key );
				wp_delete_file( $zipf );
			}
			$summary = $manifest;
			unset( $summary['entries'] );
			$summary['file_count'] = count( $files );
			self::update(
				$id,
				array(
					'status'      => 'complete',
					'file'        => basename( $final ),
					'size'        => filesize( $final ),
					'sha256'      => hash_file( 'sha256', $final ),
					'encrypted'   => $key ? 1 : 0,
					'manifest'    => wp_json_encode( $summary ),
					'message'     => $skipped ? sprintf( /* translators: %d: count */ _n( '%d file skipped (size limit).', '%d files skipped (size limit).', count( $skipped ), 'educore-recovery' ), count( $skipped ) ) : '',
					'finished_at' => Schema::now(),
				)
			);
			Audit::log( 'backup.created', 'backup', $id, array( 'uid' => $uid, 'kind' => $kind, 'trigger' => $trigger ) );
			/** Fires after a backup archive is written. */
			do_action( 'educore/recovery/backup_created', $id, $kind, $trigger );
			return $id;
		} catch ( \Throwable $e ) {
			file_exists( $sql ) && wp_delete_file( $sql );
			file_exists( $zipf ) && wp_delete_file( $zipf );
			self::update( $id, array( 'status' => 'failed', 'message' => substr( $e->getMessage(), 0, 490 ), 'finished_at' => Schema::now() ) );
			Audit::log( 'backup.failed', 'backup', $id, array( 'uid' => $uid, 'error' => $e->getMessage() ) );
			return new \WP_Error( 'ec_rc_failed', $e->getMessage() );
		}
	}

	public static function delete( int $id ): bool {
		global $wpdb;
		$b = self::get( $id );
		if ( ! $b ) {
			return false;
		}
		$p = $b->file ? Store::path( $b->file ) : null;
		$p && wp_delete_file( $p );
		$wpdb->delete( self::table(), array( 'id' => $id ) );
		Audit::log( 'backup.deleted', 'backup', $id, array( 'uid' => $b->uid ) );
		return true;
	}

	/**
	 * Open a backup for reading: verifies the outer checksum, decrypts if needed.
	 *
	 * @return array{zip:\ZipArchive,manifest:array,cleanup:callable}|\WP_Error
	 */
	public static function open( object $b ) {
		$path = $b->file ? Store::path( $b->file ) : null;
		if ( ! $path ) {
			return new \WP_Error( 'ec_rc_missing', __( 'The backup file is missing from storage.', 'educore-recovery' ) );
		}
		if ( ! hash_equals( (string) $b->sha256, (string) hash_file( 'sha256', $path ) ) ) {
			return new \WP_Error( 'ec_rc_checksum', __( 'Backup file checksum mismatch: the file was modified or damaged.', 'educore-recovery' ) );
		}
		$tmp     = null;
		$zippath = $path;
		if ( (int) $b->encrypted ) {
			$key = Settings::key();
			if ( ! $key ) {
				return new \WP_Error( 'ec_rc_key', __( 'This backup is encrypted and EDUCORE_BACKUP_KEY is not configured.', 'educore-recovery' ) );
			}
			$tmp = Store::tmp( '.zip' );
			$r   = Store::decrypt( $path, $tmp, $key );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$zippath = $tmp;
		}
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $zippath, \ZipArchive::RDONLY ) ) {
			$tmp && wp_delete_file( $tmp );
			return new \WP_Error( 'ec_rc_zip', __( 'The archive cannot be opened.', 'educore-recovery' ) );
		}
		$manifest = json_decode( (string) $zip->getFromName( 'manifest.json' ), true );
		if ( ! is_array( $manifest ) || (int) ( $manifest['format'] ?? 0 ) !== self::FORMAT || ( $manifest['backup_id'] ?? '' ) !== $b->uid ) {
			$zip->close();
			$tmp && wp_delete_file( $tmp );
			return new \WP_Error( 'ec_rc_manifest', __( 'The manifest is missing, unreadable or belongs to another backup.', 'educore-recovery' ) );
		}
		return array(
			'zip'      => $zip,
			'manifest' => $manifest,
			'cleanup'  => static function () use ( $zip, $tmp ) {
				@$zip->close(); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				$tmp && file_exists( $tmp ) && wp_delete_file( $tmp );
			},
		);
	}

	/** Extract database.sql to a temp file. */
	public static function extract_sql( \ZipArchive $zip ): string {
		$out = Store::tmp( '.sql' );
		$in  = $zip->getStream( 'database.sql' );
		$w   = fopen( $out, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		stream_copy_to_stream( $in, $w );
		fclose( $w ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $in ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $out;
	}
}
