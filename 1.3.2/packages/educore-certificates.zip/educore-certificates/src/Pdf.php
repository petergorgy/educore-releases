<?php
namespace EduCore\Certificates;

use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * PDF rendering with the bundled mPDF (loaded only here). Arabic text is shaped with
 * OpenType layout using the XB Riyaz font; Latin text uses DejaVu Sans.
 */
final class Pdf {

	private static function load(): void {
		if ( ! class_exists( '\Mpdf\Mpdf' ) ) {
			require_once EDUCORE_CERTIFICATES_DIR . 'lib/autoload.php';
		}
	}

	public static function has_arabic( string $s ): bool {
		return (bool) preg_match( '/[\x{0600}-\x{06FF}\x{0750}-\x{077F}\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}]/u', $s );
	}

	/** Build the certificate HTML (all variable text escaped). */
	public static function html( array $tpl, array $vars ): string {
		$rtl     = 'ar' === $tpl['lang'] || self::has_arabic( $tpl['heading'] . $tpl['body'] );
		$dir     = $rtl ? 'rtl' : 'ltr';
		$base    = $rtl ? 'xbriyaz' : 'dejavusans';
		$accent  = $tpl['accent'];
		$lines   = explode( "\n", $tpl['body'] );
		$body    = '';
		$emph    = array( '{student_name}' => 30, '{course_title}' => 22 );
		foreach ( $lines as $line ) {
			$size = 15;
			foreach ( $emph as $ph => $s ) {
				if ( false !== strpos( $line, $ph ) ) {
					$size = $s;
				}
			}
			$text  = esc_html( Templates::fill( trim( $line ), $vars ) );
			$font  = self::has_arabic( $text ) ? 'xbriyaz' : $base;
			$body .= '<p style="font-family:' . $font . ';font-size:' . $size . 'pt;margin:4mm 0;' . ( $size > 15 ? 'font-weight:bold;color:#102A43;' : '' ) . '">' . $text . '</p>';
		}
		$footer_font = 'dejavusans';
		$html  = '<html><body dir="' . $dir . '" style="font-family:' . $base . ';color:#102A43">';
		$inner = 'P' === $tpl['orientation'] ? '240mm' : '152mm';
		$html .= '<div style="border:3mm solid ' . $accent . ';padding:8mm;">';
		$html .= '<div style="border:0.6mm solid #c9a227;padding:10mm 12mm;text-align:center;height:' . $inner . ';">';
		$logo  = class_exists( '\\EduCore\\Core\\Branding' ) ? \EduCore\Core\Branding::asset_path( 'educore-logo-horizontal.svg' ) : '';
		$html .= ( $logo && is_readable( $logo ) )
			? '<p style="margin:0"><img src="' . esc_attr( $logo ) . '" style="height:13mm" alt="EduCore"></p>'
			: '<p style="font-family:dejavusans;font-size:12pt;letter-spacing:2pt;color:' . $accent . ';margin:0">EDUCORE</p>';
		$html .= '<h1 style="font-family:' . ( self::has_arabic( $tpl['heading'] ) ? 'xbriyaz' : $base ) . ';font-size:34pt;color:#102A43;margin:6mm 0 4mm">' . esc_html( $tpl['heading'] ) . '</h1>';
		$html .= $body;
		$html .= '<table width="100%" style="margin-top:12mm"><tr><td width="50%" style="text-align:center;font-size:12pt">';
		if ( $tpl['sig_name'] ) {
			$sig_font = self::has_arabic( $tpl['sig_name'] . $tpl['sig_title'] ) ? 'xbriyaz' : $base;
			$html    .= '<div style="border-top:0.4mm solid #102A43;width:60mm;margin:0 auto;padding-top:2mm;font-family:' . $sig_font . '">' . esc_html( $tpl['sig_name'] ) . '<br><span style="color:#4f5b6e;font-size:10pt">' . esc_html( $tpl['sig_title'] ) . '</span></div>';
		}
		// QR code to the public verification page (versions 1–10 are bundled; longer URLs fall back to text only).
		$qr = strlen( (string) $vars['verify_url'] ) <= 150 && class_exists( '\\Mpdf\\QrCode\\QrCode' )
			? '<barcode code="' . esc_attr( $vars['verify_url'] ) . '" type="QR" size="0.7" error="M" disableborder="1" /><br>'
			: '';
		$html .= '</td><td width="50%" style="text-align:center;font-family:' . $footer_font . ';font-size:9pt;color:#4f5b6e" dir="ltr">' . $qr . 'ID: ' . esc_html( $vars['certificate_id'] ) . '<br>' . esc_html( $vars['verify_url'] ) . '</td></tr></table>';
		$html .= '</div></div></body></html>';
		return $html;
	}

	/** Render bytes for arbitrary template data (used for previews and tests). */
	public static function render( array $tpl, array $vars ): string {
		self::load();
		$tmp = Storage::ensure_dir() . '/tmp';
		$mpdf = new \Mpdf\Mpdf(
			array(
				'mode'           => 'utf-8',
				'format'         => 'A4-' . ( 'P' === $tpl['orientation'] ? 'P' : 'L' ),
				'tempDir'        => $tmp,
				'fontDir'        => array( EDUCORE_CERTIFICATES_DIR . 'lib/ttfonts' ),
				'fontdata'       => array(
					'dejavusans' => array( 'R' => 'DejaVuSans.ttf', 'B' => 'DejaVuSans-Bold.ttf', 'useOTL' => 0xFF ),
					'xbriyaz'    => array( 'R' => 'XB Riyaz.ttf', 'B' => 'XB RiyazBd.ttf', 'useOTL' => 0xFF, 'useKashida' => 75 ),
				),
				'default_font'   => 'dejavusans',
				'margin_left'    => 8,
				'margin_right'   => 8,
				'margin_top'     => 8,
				'margin_bottom'  => 8,
			)
		);
		$mpdf->SetTitle( $tpl['heading'] . ' — ' . $vars['student_name'] );
		$mpdf->SetAuthor( 'EduCore' );
		$mpdf->SetCreator( 'EduCore Certificates ' . EDUCORE_CERTIFICATES_VERSION );
		if ( 'ar' === $tpl['lang'] ) {
			$mpdf->SetDirectionality( 'rtl' );
		}
		$mpdf->WriteHTML( self::html( $tpl, $vars ) );
		return $mpdf->Output( '', \Mpdf\Output\Destination::STRING_RETURN );
	}

	/** Generate and store the PDF for a certificate. Returns absolute path. */
	public static function generate( int $id ): string {
		global $wpdb;
		$c = Certificates::get( $id );
		if ( ! $c ) {
			throw new \RuntimeException( 'Unknown certificate.' );
		}
		$tpl  = Templates::get( (int) $c['template_id'] );
		$vars = array(
			'student_name'   => $c['student_name'],
			'course_title'   => $c['course_title'],
			'issue_date'     => wp_date( 'ar' === $tpl['lang'] ? 'j F Y' : get_option( 'date_format', 'F j, Y' ), strtotime( $c['issued_at'] . ' UTC' ) ),
			'certificate_id' => $c['uid'],
			'verify_url'     => Verify::url( $c['uid'] ),
		);
		$bytes = self::render( $tpl, $vars );
		$name  = $c['uid'] . '.pdf';
		$path  = Storage::path( $name );
		file_put_contents( $path, $bytes ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$wpdb->update( Schema::table( 'certificates' ), array( 'pdf_path' => $name, 'sha256' => hash( 'sha256', $bytes ) ), array( 'id' => $id ) );
		return $path;
	}
}
