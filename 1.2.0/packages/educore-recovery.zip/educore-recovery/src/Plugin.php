<?php
namespace EduCore\Recovery;

use EduCore\Core\Registry;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	public const CAP  = 'ec_manage_backups';
	public const TICK = 'educore_rc_tick';

	public static function tables(): array {
		return array(
			'rc_backups' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				uid CHAR(20) NOT NULL,
				kind VARCHAR(20) NOT NULL,
				trigger_source VARCHAR(20) NOT NULL DEFAULT 'manual',
				status VARCHAR(20) NOT NULL DEFAULT 'running',
				file VARCHAR(190) NOT NULL DEFAULT '',
				size BIGINT UNSIGNED NOT NULL DEFAULT 0,
				sha256 CHAR(64) NOT NULL DEFAULT '',
				encrypted TINYINT(1) NOT NULL DEFAULT 0,
				manifest LONGTEXT NULL,
				message VARCHAR(500) NOT NULL DEFAULT '',
				verify_status VARCHAR(20) NOT NULL DEFAULT 'not_verified',
				verified_at DATETIME NULL,
				restore_test_status VARCHAR(20) NOT NULL DEFAULT 'not_tested',
				restore_tested_at DATETIME NULL,
				restore_test_report LONGTEXT NULL,
				created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				finished_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY uid (uid),
				KEY kind_status (kind,status)",
		);
	}

	public static function install(): void {
		Schema::migrate( 'educore_rc_db_version', EDUCORE_RC_DB_VERSION, self::tables() );
		foreach ( array( 'administrator' ) as $r ) {
			$role = get_role( $r );
			$role && $role->add_cap( self::CAP );
		}
		add_option( Settings::OPTION, Settings::defaults(), '', false );
		Store::dir();
		if ( ! wp_next_scheduled( self::TICK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::TICK );
		}
	}

	public static function boot(): void {
		Registry::register( 'recovery', EDUCORE_RC_VERSION );
		Schema::migrate( 'educore_rc_db_version', EDUCORE_RC_DB_VERSION, self::tables() );
		add_action( 'educore/install/repair', array( self::class, 'install' ) );
		add_action( 'init', static fn() => load_plugin_textdomain( 'educore-recovery', false, dirname( plugin_basename( EDUCORE_RC_FILE ) ) . '/languages' ) );
		add_action( self::TICK, array( Scheduler::class, 'run_due' ) );
		add_action( 'init', array( Scheduler::class, 'cron_endpoint' ), 1 );
		add_filter( 'upgrader_pre_install', array( Scheduler::class, 'pre_deployment' ), 5, 2 );
		add_filter( 'educore/install/checks', array( Admin::class, 'checks' ) );
		if ( is_admin() ) {
			Admin::register();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'educore backup', Cli::class );
		}
	}

	public static function uid(): string {
		return gmdate( 'Ymd\THis' ) . '-' . substr( bin2hex( random_bytes( 3 ) ), 0, 4 );
	}
}
