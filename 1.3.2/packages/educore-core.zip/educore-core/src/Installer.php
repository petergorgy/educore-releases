<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

final class Installer {
	public const MIN_PHP = '8.1';
	public const MIN_WP  = '6.8';

	public static function activate(): void {
		$problems = array_filter( self::environment_checks(), static fn( $c ) => 'fail' === $c['status'] );
		if ( $problems ) {
			deactivate_plugins( plugin_basename( EDUCORE_CORE_FILE ) );
			wp_die( esc_html( implode( ' ', wp_list_pluck( $problems, 'message' ) ) ), esc_html__( 'EduCore cannot be activated', 'educore-core' ), array( 'back_link' => true ) );
		}
		Schema::migrate( 'educore_core_db_version', EDUCORE_CORE_DB_VERSION, Schema::core_tables() );
		Roles::install();
		update_option( 'educore_core_roles_version', EDUCORE_CORE_VERSION, false );
		add_option( 'educore_default_lang', 'en' );
		add_option( 'educore_consent_version', '1.0' );
		add_option( 'educore_support_email', 'support@educore.gorgy.org' );
		add_option( 'educore_leaderboards', 'off' );
		add_option( 'educore_audit_retention_days', 730 );
		Content::register_types();
		flush_rewrite_rules();
		Cron::schedule();
		set_transient( 'educore_activation_redirect', 1, 60 );
	}

	public static function deactivate(): void {
		Cron::unschedule();
		flush_rewrite_rules();
	}

	/** @return array<int,array{label:string,status:string,message:string}> status pass|warn|fail */
	public static function environment_checks(): array {
		global $wpdb, $wp_version;
		$checks   = array();
		$checks[] = array(
			'label'   => 'PHP',
			'status'  => version_compare( PHP_VERSION, self::MIN_PHP, '>=' ) ? 'pass' : 'fail',
			/* translators: 1: found, 2: required */
			'message' => sprintf( __( 'PHP %1$s (requires %2$s+).', 'educore-core' ), PHP_VERSION, self::MIN_PHP ),
		);
		$checks[] = array(
			'label'   => 'WordPress',
			'status'  => version_compare( $wp_version, self::MIN_WP, '>=' ) ? 'pass' : 'fail',
			/* translators: 1: found, 2: required */
			'message' => sprintf( __( 'WordPress %1$s (requires %2$s+).', 'educore-core' ), $wp_version, self::MIN_WP ),
		);
		$db_version = (string) $wpdb->db_server_info();
		$is_maria   = false !== stripos( $db_version, 'mariadb' );
		preg_match( '/(\d+\.\d+(\.\d+)?)/', $is_maria ? (string) preg_replace( '/^5\.5\.5-/', '', $db_version ) : $db_version, $m );
		$num      = $m[1] ?? '0';
		$db_ok    = $is_maria ? version_compare( $num, '10.6', '>=' ) : version_compare( $num, '8.0', '>=' );
		$checks[] = array(
			'label'   => 'Database',
			'status'  => $db_ok ? 'pass' : 'warn',
			/* translators: %s: version */
			'message' => sprintf( __( 'Database server %s (recommended MySQL 8.0+ or MariaDB 10.6+).', 'educore-core' ), $db_version ),
		);
		foreach ( array( 'mbstring', 'intl', 'zip', 'gd' ) as $ext ) {
			$checks[] = array(
				'label'   => 'ext-' . $ext,
				'status'  => extension_loaded( $ext ) ? 'pass' : ( 'mbstring' === $ext ? 'fail' : 'warn' ),
				/* translators: %s: extension */
				'message' => sprintf( __( 'PHP extension %s', 'educore-core' ), $ext ) . ( extension_loaded( $ext ) ? '' : ' ' . __( 'is missing.', 'educore-core' ) ),
			);
		}
		$checks[] = array(
			'label'   => 'HTTPS',
			'status'  => is_ssl() || 0 === strpos( home_url(), 'https://' ) ? 'pass' : 'warn',
			'message' => __( 'Site should be served over HTTPS in production.', 'educore-core' ),
		);
		$checks[] = array(
			'label'   => 'Cron',
			'status'  => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? 'pass' : 'warn',
			'message' => __( 'For reliable background jobs set DISABLE_WP_CRON and add a cPanel cron job calling wp-cron.php every 5 minutes.', 'educore-core' ),
		);
		$checks[] = array(
			'label'   => 'Tables',
			'status'  => empty( Schema::missing_tables( Schema::core_tables() ) ) ? 'pass' : 'warn',
			'message' => __( 'EduCore database tables.', 'educore-core' ),
		);
		return apply_filters( 'educore/install/checks', $checks );
	}
}
