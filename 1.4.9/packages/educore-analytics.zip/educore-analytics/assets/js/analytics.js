/* EduCore analytics charts. Every chart has an equivalent data table; animation off for reduced motion. */
(function () {
	'use strict';
	if (!window.Chart) { return; }
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var palette = ['#0b7f7a', '#0b1f3a', '#8a6d12', '#5b6b85'];
	var rtl = document.documentElement.dir === 'rtl';
	document.querySelectorAll('canvas[data-ec-chart]').forEach(function (el) {
		var cfg;
		try { cfg = JSON.parse(el.getAttribute('data-ec-chart')); } catch (e) { return; }
		new window.Chart(el, {
			type: cfg.type,
			data: {
				labels: cfg.labels,
				datasets: cfg.datasets.map(function (d, i) {
					return { label: d.label, data: d.data, backgroundColor: palette[i % palette.length], borderColor: palette[i % palette.length], tension: 0.25, fill: false };
				})
			},
			options: {
				animation: reduce ? false : { duration: 500 },
				maintainAspectRatio: false,
				locale: document.documentElement.lang || 'en',
				plugins: { legend: { rtl: rtl, display: cfg.datasets.length > 1 } },
				scales: { x: { reverse: rtl }, y: { beginAtZero: true } }
			}
		});
	});
})();
