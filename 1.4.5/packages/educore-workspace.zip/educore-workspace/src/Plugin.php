<?php
namespace EduCore\Workspace;

use EduCore\Core\Registry;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	/** Manage people (create, roles, suspend, invite, guardian links, staff assignment). */
	public const CAP_PEOPLE = 'ec_manage_people';

	public static function boot(): void {
		Registry::register( 'workspace', EDUCORE_WS_VERSION );
		add_action( 'init', static fn() => load_plugin_textdomain( 'educore-workspace', false, dirname( plugin_basename( EDUCORE_WS_FILE ) ) . '/languages' ), 1 );
		if ( get_option( 'educore_ws_version' ) !== EDUCORE_WS_VERSION ) {
			add_action( 'init', array( self::class, 'install' ), 20 );
		}
		Pages::register();
		Shell::register();
		Navigation::register();
		Manage::register();
		Rest::register();
		Guardian::register();
		Tutor::register();
		Abstraction::register();
		Studio\View::register();
		Studio\Rest::register();
		Assess\Rest::register();
		Settings::register();
		Certs::register();
		Programmes::register();
	}

	public static function install(): void {
		foreach ( array( 'administrator', 'ec_academic_manager' ) as $r ) {
			$role = get_role( $r );
			if ( $role && ! $role->has_cap( self::CAP_PEOPLE ) ) {
				$role->add_cap( self::CAP_PEOPLE );
			}
		}
		Pages::create_missing();
		update_option( 'educore_ws_version', EDUCORE_WS_VERSION, false );
	}
}
