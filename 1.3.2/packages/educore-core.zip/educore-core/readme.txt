=== EduCore Core ===
Contributors: gorgyorg
Tags: lms, learning management, courses, education, e-learning
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The EduCore learning management core: curriculum, courses, lessons, enrollment, progress, roles, privacy and REST API.

== Description ==

EduCore Core is the required foundation of the EduCore LMS (https://educore.gorgy.org), an initiative of GORGY.ORG.

* Curriculum hierarchy: Programme → Academic year → Semester → Subject → Course → Unit → Lesson.
* Draft, review (pending), scheduled, published and archived states; drag-and-drop reordering with keyboard alternative; course duplication.
* Enrollment lifecycle with expiry; server-side access gate on every channel (pages, REST, feeds, excerpts).
* Lesson reader with progress, notes, bookmarks, configurable completion rules (manual, view, active time; assessments add "quiz passed").
* Roles: Academic Manager, Instructor, Grader, Student, Guardian — instructors only see the courses they are assigned to.
* Guardian consent for learners under 18, consent records, WordPress personal-data export and erasure.
* Interface in English (default), French and Arabic (RTL); Arabic-aware search.
* Audit log, login throttling and rate limiting that work on shared hosting.

Optional packages: EduCore Assessments, Analytics, Notifications, Certificates and Commerce.

== Installation ==

1. Upload and activate EduCore Core (and the EduCore theme).
2. Follow EduCore → Setup wizard: environment checks, database & roles, default pages.
3. On cPanel hosting add `define( 'DISABLE_WP_CRON', true );` to wp-config.php and a cron job every 5 minutes: `wget -q -O - https://educore.gorgy.org/wp-cron.php?doing_wp_cron >/dev/null 2>&1`.

== Frequently Asked Questions ==

= Does uninstalling delete student records? =
No. Academic data is kept unless an administrator explicitly confirms deletion twice under EduCore → Settings.

= Does it create demo data? =
Never in production. `wp educore sample-data` is refused when WP_ENVIRONMENT_TYPE is production.

== Changelog ==
= 1.1.0 =
* Fix: "Sign up" / "Create an account" calls to action now follow the registration setting (live defect D-02).
* Security: anonymous visitors can no longer list users or enumerate author slugs (REST users, author archives, oEmbed, sitemaps) (D-03); security headers nosniff, frame, referrer and permissions policy (D-04); health check for WP_DEBUG_DISPLAY (D-06).
* Signed updates: administrator-approved install of new signed packages (dependency-aware); automatic updates limited to maintenance releases of the same major.minor.
* Extension points: educore/dashboard/student_sections; enrolment source "class".
* Verified on PHP 8.5.12.


= 1.0.2 =
* New: signed release channel. EduCore plugins and theme can update themselves from a configured manifest; every manifest is verified with Ed25519 and every package against its signed SHA-256 before WordPress installs it. Automatic installation is opt-in (EduCore → Settings).

= 1.0.1 =
* New: daily activity log (exact daily/weekly active learners and learning consistency). Database schema v2, migrates automatically.
* New: content translations — "Create French/Arabic copy" of a course (units and lessons linked), "Also available in" links, catalogue course-language filter.
* New: optional leaderboard block — off by default; lists only adult learners (declared 18+) who opt in from their profile.
* Performance: per-request lesson cache and bulk progress queries (instructor workspace 5.6 s → 0.5 s at 1,500 students).
* Fix: lesson pager arrows mirror in Arabic; default page titles follow the interface language.

= 1.0.0 =
* First release.
