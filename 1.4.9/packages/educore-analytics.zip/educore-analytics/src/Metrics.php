<?php
namespace EduCore\Analytics;

use EduCore\Core\Content;
use EduCore\Core\Enrollment;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Metric implementations. Every method maps 1:1 to an entry in Dictionary::all().
 * Percentages are rounded to 1 decimal. null = not computable (no data / package absent).
 */
final class Metrics {

	/* ================= helpers ================= */

	private static function lp(): string {
		return Schema::table( 'lesson_progress' );
	}

	private static function en(): string {
		return Schema::table( 'enrollments' );
	}

	private static function pct( float $num, float $den ): ?float {
		return $den > 0 ? round( $num * 100 / $den, 1 ) : null;
	}

	/** Activity rows (user_id, day) from first_seen/last_seen/completed timestamps. */
	/** @var array<string,bool> */
	private static array $tables = array();

	private static function table_exists( string $t ): bool {
		global $wpdb;
		if ( ! isset( self::$tables[ $t ] ) ) {
			self::$tables[ $t ] = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) === $t;
		}
		return self::$tables[ $t ];
	}

	private static function activity_sql( string $course_in, string $from_dt, string $to_dt, bool $with_course = false ): string {
		global $wpdb;
		$lp    = self::lp();
		$cc    = $with_course ? 'course_id, ' : '';
		$parts = array();
		foreach ( array( 'first_seen_at', 'last_seen_at', 'completed_at' ) as $col ) {
			$parts[] = $wpdb->prepare( "SELECT {$cc}user_id, DATE({$col}) AS d FROM {$lp} WHERE course_id IN ({$course_in}) AND {$col} IS NOT NULL AND {$col} BETWEEN %s AND %s", $from_dt, $to_dt ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		// Core 1.0.1+: exact daily activity log (every active day, not just first/last/completed).
		$act = Schema::table( 'activity' );
		if ( self::table_exists( $act ) ) {
			$parts[] = $wpdb->prepare( "SELECT {$cc}user_id, day AS d FROM {$act} WHERE course_id IN ({$course_in}) AND day BETWEEN %s AND %s", substr( $from_dt, 0, 10 ), substr( $to_dt, 0, 10 ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		return implode( ' UNION ', $parts );
	}

	/** @return int[] users enrolled (active|completed) in a course, cohort-filtered */
	public static function enrolled_users( int $course_id, Filters $f, array $statuses = array( 'active', 'completed' ) ): array {
		global $wpdb;
		$st = "'" . implode( "','", array_map( 'esc_sql', $statuses ) ) . "'";
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT user_id FROM ' . self::en() . " WHERE course_id=%d AND status IN ({$st})", $course_id ) . $f->cohort_sql( 'user_id' ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/* ================= student ================= */

	/** S1 */
	public static function course_completion( int $user_id, int $course_id ): ?float {
		$ids = Content::lesson_ids( $course_id );
		if ( ! $ids ) {
			return null;
		}
		return self::pct( self::completed_counts( $course_id )[ $user_id ] ?? 0, count( $ids ) );
	}

	/** @var array<int,array<int,int>> per-request: course => [user => completed published lessons] */
	private static array $completed_cache = array();

	public static function flush_cache(): void {
		self::$completed_cache = array();
	}

	/** One grouped query per course instead of one query per learner (avoids N+1 at scale). */
	private static function completed_counts( int $course_id ): array {
		global $wpdb;
		if ( isset( self::$completed_cache[ $course_id ] ) ) {
			return self::$completed_cache[ $course_id ];
		}
		$ids = Content::lesson_ids( $course_id );
		$out = array();
		if ( $ids ) {
			$in   = implode( ',', array_map( 'intval', $ids ) );
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT user_id, COUNT(*) n FROM ' . self::lp() . " WHERE course_id=%d AND state='completed' AND lesson_id IN ({$in}) GROUP BY user_id", $course_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL -- integer list.
			foreach ( $rows as $r ) {
				$out[ (int) $r['user_id'] ] = (int) $r['n'];
			}
		}
		return self::$completed_cache[ $course_id ] = $out;
	}

	/** S2: per enrolled course: total, started, completed (published lessons only). */
	public static function lesson_progress( int $user_id, Filters $f ): array {
		global $wpdb;
		$out = array();
		foreach ( Enrollment::for_user( $user_id ) as $e ) {
			$cid = (int) $e['course_id'];
			if ( ! in_array( $cid, $f->courses(), true ) ) {
				continue;
			}
			$ids = Content::lesson_ids( $cid );
			$in  = AssessmentSource::in_list( $ids );
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT COUNT(*) started, SUM(state=\'completed\') completed FROM ' . self::lp() . " WHERE user_id=%d AND lesson_id IN ({$in})", $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
			$out[] = array(
				'course_id'  => $cid,
				'title'      => get_the_title( $cid ),
				'total'      => count( $ids ),
				'started'    => (int) $row['started'],
				'completed'  => (int) $row['completed'],
				'completion' => self::pct( (int) $row['completed'], count( $ids ) ),
			);
		}
		return $out;
	}

	/** S3 */
	public static function assessment_mean( int $user_id, Filters $f ): ?float {
		return self::mean_of_rows( AssessmentSource::scored_attempts( $f, $user_id ) ?: array() );
	}

	/** Mean % of scored attempt rows (null when none). */
	private static function mean_of_rows( array $rows ): ?float {
		if ( ! $rows ) {
			return null;
		}
		return round( array_sum( array_map( 'floatval', wp_list_pluck( $rows, 'pct' ) ) ) / count( $rows ), 1 );
	}

	/**
	 * Scored attempts of the filter, grouped by learner, original order kept (submitted_at, id).
	 * One query for a whole course instead of one per learner (PERF-147-01).
	 *
	 * @return array<int,array<int,array<string,mixed>>>|null
	 */
	private static function attempts_by_user( Filters $f ): ?array {
		$rows = AssessmentSource::scored_attempts( $f );
		if ( null === $rows ) {
			return null;
		}
		$by = array();
		foreach ( $rows as $r ) {
			$by[ (int) $r['user_id'] ][] = $r;
		}
		return $by;
	}

	/** S4: mean over assessments with ≥2 scored attempts of (last % − first %). */
	public static function score_improvement( int $user_id, Filters $f ): ?float {
		return self::improvement_of_rows( AssessmentSource::scored_attempts( $f, $user_id ) ?: array() );
	}

	/** S4 from one learner's scored attempt rows (ordered by submitted_at, id). */
	private static function improvement_of_rows( array $rows ): ?float {
		if ( ! $rows ) {
			return null;
		}
		$by = array();
		foreach ( $rows as $r ) { // Rows are ordered by submitted_at, id.
			$by[ (int) $r['assessment_id'] ][] = (float) $r['pct'];
		}
		$deltas = array();
		foreach ( $by as $list ) {
			if ( count( $list ) >= 2 ) {
				$deltas[] = end( $list ) - reset( $list );
			}
		}
		return $deltas ? round( array_sum( $deltas ) / count( $deltas ), 1 ) : null;
	}

	/** S5: per lesson mean item % → strength (≥75), weakness (<50), developing otherwise. */
	public static function topic_strengths( int $user_id, Filters $f ): ?array {
		$rows = AssessmentSource::scored_items( $f, $user_id );
		if ( null === $rows ) {
			return null;
		}
		$by = array();
		foreach ( $rows as $r ) {
			$by[ (int) $r['lesson_id'] ][] = (float) $r['pct'];
		}
		$out = array();
		foreach ( $by as $lesson => $list ) {
			$mean  = round( array_sum( $list ) / count( $list ), 1 );
			$out[] = array(
				'lesson_id' => $lesson,
				'lesson'    => $lesson ? get_the_title( $lesson ) : __( '(no lesson)', 'educore-analytics' ),
				'mean'      => $mean,
				'items'     => count( $list ),
				'band'      => $mean >= 75 ? 'strength' : ( $mean < 50 ? 'weakness' : 'developing' ),
			);
		}
		usort( $out, static fn( $a, $b ) => $b['mean'] <=> $a['mean'] );
		return $out;
	}

	/** S6: submitted (non-open) attempts per assessment within range. */
	public static function attempts_per_assessment( int $user_id, Filters $f ): ?array {
		global $wpdb;
		if ( ! AssessmentSource::attempts_available() ) {
			return null;
		}
		$at   = Schema::table( 'attempts' );
		$as   = Schema::table( 'assessments' );
		$in   = AssessmentSource::in_list( $f->courses() );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT t.assessment_id, COUNT(*) n FROM {$at} t JOIN {$as} a ON a.id=t.assessment_id WHERE t.user_id=%d AND a.course_id IN ({$in}) AND t.state <> 'open' AND t.submitted_at BETWEEN %s AND %s GROUP BY t.assessment_id ORDER BY t.assessment_id", $user_id, $f->from_dt(), $f->to_dt() ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ (int) $r['assessment_id'] ] = (int) $r['n'];
		}
		return $out;
	}

	/** S7: distinct active days in the 28 days ending at $f->now. */
	public static function consistency( int $user_id, Filters $f ): array {
		global $wpdb;
		$from = gmdate( 'Y-m-d 00:00:00', $f->now - 27 * DAY_IN_SECONDS );
		$to   = gmdate( 'Y-m-d 23:59:59', $f->now );
		$sql  = 'SELECT COUNT(DISTINCT d) FROM (' . self::activity_sql( AssessmentSource::in_list( $f->courses() ), $from, $to ) . ') x WHERE user_id = %d';
		$days = (int) $wpdb->get_var( $wpdb->prepare( $sql, $user_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		return array( 'active_days' => $days, 'window' => 28, 'ratio' => self::pct( $days, 28 ) );
	}

	/** S8: incomplete published lessons + unattempted assessments in currently accessible enrollments. */
	public static function pending_activities( int $user_id, Filters $f ): array {
		$lessons     = 0;
		$assessments = 0;
		$course_ids  = array();
		foreach ( Enrollment::for_user( $user_id ) as $e ) {
			$cid = (int) $e['course_id'];
			if ( ! in_array( $cid, $f->courses(), true ) || ! Enrollment::is_enrolled( $user_id, $cid ) ) {
				continue;
			}
			$course_ids[] = $cid;
			$lessons     += count( array_diff( Content::lesson_ids( $cid ), \EduCore\Core\Progress::completed_ids( $user_id, $cid ) ) );
		}
		$ids = AssessmentSource::assessment_ids( $course_ids );
		if ( null !== $ids ) {
			$done        = AssessmentSource::attempted_assessments( $user_id );
			$assessments = count( array_diff( array_map( 'intval', wp_list_pluck( $ids, 'id' ) ), $done ) );
		}
		return array( 'lessons' => $lessons, 'assessments' => null === $ids ? null : $assessments );
	}

	/* ================= instructor (per course) ================= */

	/** I1: active learners (7/30 days) ÷ enrolled. */
	public static function engagement( int $course_id, Filters $f ): array {
		global $wpdb;
		$users = self::enrolled_users( $course_id, $f );
		$out   = array( 'enrolled' => count( $users ) );
		foreach ( array( 7, 30 ) as $days ) {
			$active = 0;
			if ( $users ) {
				$from   = gmdate( 'Y-m-d 00:00:00', $f->now - ( $days - 1 ) * DAY_IN_SECONDS );
				$sql    = 'SELECT COUNT(DISTINCT user_id) FROM (' . self::activity_sql( (string) $course_id, $from, gmdate( 'Y-m-d 23:59:59', $f->now ) ) . ') x WHERE user_id IN (' . AssessmentSource::in_list( $users ) . ')';
				$active = (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
			}
			$out[ "active_{$days}" ] = $active;
			$out[ "rate_{$days}" ]   = self::pct( $active, count( $users ) );
		}
		return $out;
	}

	/** I2: per published lesson, completed by enrolled learners ÷ enrolled. */
	public static function lesson_completion_rates( int $course_id, Filters $f ): array {
		global $wpdb;
		$users = self::enrolled_users( $course_id, $f );
		$in    = AssessmentSource::in_list( $users );
		$out   = array();
		foreach ( Content::lesson_ids( $course_id ) as $lid ) {
			$n     = $users ? (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::lp() . " WHERE lesson_id=%d AND state='completed' AND user_id IN ({$in})", $lid ) ) : 0; // phpcs:ignore WordPress.DB.PreparedSQL
			$out[] = array( 'lesson_id' => $lid, 'lesson' => get_the_title( $lid ), 'completed' => $n, 'enrolled' => count( $users ), 'rate' => self::pct( $n, count( $users ) ) );
		}
		return $out;
	}

	/** I3: scored-attempt percentages in 10 buckets [0-10) … [90-100]. */
	public static function score_distribution( Filters $f ): ?array {
		$rows = AssessmentSource::scored_attempts( $f );
		if ( null === $rows ) {
			return null;
		}
		$b = array_fill( 0, 10, 0 );
		foreach ( $rows as $r ) {
			$b[ (int) min( 9, max( 0, floor( (float) $r['pct'] / 10 ) ) ) ]++;
		}
		return $b;
	}

	/** Per-question p-values (share correct) for questions with ≥ $min responses. */
	public static function question_stats( Filters $f, int $min = 5 ): ?array {
		$rows = AssessmentSource::scored_items( $f );
		if ( null === $rows ) {
			return null;
		}
		$by = array();
		foreach ( $rows as $r ) {
			$q = (int) $r['question_id'];
			$by[ $q ]['n']      = ( $by[ $q ]['n'] ?? 0 ) + 1;
			$by[ $q ]['c']      = ( $by[ $q ]['c'] ?? 0 ) + (int) $r['correct'];
			$by[ $q ]['lesson'] = (int) $r['lesson_id'];
		}
		$out = array();
		foreach ( $by as $q => $s ) {
			if ( $s['n'] >= $min ) {
				$out[] = array( 'question_id' => $q, 'lesson_id' => $s['lesson'], 'responses' => $s['n'], 'correct' => $s['c'], 'p' => round( $s['c'] / $s['n'], 3 ) );
			}
		}
		usort( $out, static fn( $a, $b ) => $a['p'] <=> $b['p'] ?: $a['question_id'] <=> $b['question_id'] );
		return $out;
	}

	/** I4: p < 0.40 with ≥5 responses. */
	public static function difficult_questions( Filters $f ): ?array {
		$s = self::question_stats( $f );
		return null === $s ? null : array_values( array_filter( $s, static fn( $q ) => $q['p'] < 0.4 ) );
	}

	/** I5: mean of per-student score improvement (students with a computable S4). */
	public static function course_improvement( int $course_id, Filters $f ): ?float {
		if ( ! AssessmentSource::attempts_available() ) {
			return null;
		}
		$cf             = clone $f;
		$cf->course_ids = array( $course_id );
		$vals           = array();
		$by             = self::attempts_by_user( $cf ) ?? array();
		foreach ( self::enrolled_users( $course_id, $f ) as $u ) {
			$v = self::improvement_of_rows( $by[ $u ] ?? array() );
			if ( null !== $v ) {
				$vals[] = $v;
			}
		}
		return $vals ? round( array_sum( $vals ) / count( $vals ), 1 ) : null;
	}

	/** I6 */
	public static function grading_backlog( Filters $f ): ?array {
		$rows = AssessmentSource::pending( $f->courses() );
		if ( null === $rows ) {
			return null;
		}
		$oldest = $rows ? strtotime( $rows[0]['submitted_at'] . ' UTC' ) : null;
		return array( 'count' => count( $rows ), 'oldest_hours' => $oldest ? (int) floor( ( $f->now - $oldest ) / HOUR_IN_SECONDS ) : null );
	}

	/**
	 * I7: active learners matching any risk rule.
	 * Batched (PERF-147-01): last activity, enrollment start, completion and score mean are read with one query each
	 * for the whole course, instead of about five queries per learner. Results are identical to the per-learner rules.
	 */
	public static function at_risk( int $course_id, Filters $f ): array {
		global $wpdb;
		$cf             = clone $f;
		$cf->course_ids = array( $course_id );
		$cf->from       = '1970-01-01';
		$cf->to         = gmdate( 'Y-m-d', $f->now );
		$users          = self::enrolled_users( $course_id, $f, array( 'active' ) );
		if ( ! $users ) {
			return array();
		}
		$in    = AssessmentSource::in_list( $users );
		$last  = array();
		$start = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT user_id, GREATEST(MAX(last_seen_at), COALESCE(MAX(completed_at), MAX(last_seen_at))) last_at FROM ' . self::lp() . " WHERE course_id=%d AND user_id IN ({$in}) GROUP BY user_id", $course_id ), ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL -- integer list.
			$last[ (int) $r['user_id'] ] = $r['last_at'];
		}
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT user_id, starts_at FROM ' . self::en() . " WHERE course_id=%d AND user_id IN ({$in})", $course_id ), ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL -- integer list.
			$start[ (int) $r['user_id'] ] = $r['starts_at'];
		}
		$attempts = self::attempts_by_user( $cf ) ?? array();
		$out      = array();
		foreach ( $users as $u ) {
			$reasons = array();
			$l       = $last[ $u ] ?? null;
			if ( ! $l || strtotime( $l . ' UTC' ) < $f->now - 14 * DAY_IN_SECONDS ) {
				$reasons[] = 'inactive_14d';
			}
			$comp = self::course_completion( $u, $course_id );
			if ( isset( $start[ $u ] ) && strtotime( $start[ $u ] . ' UTC' ) <= $f->now - 30 * DAY_IN_SECONDS && null !== $comp && $comp < 25 ) {
				$reasons[] = 'low_progress';
			}
			$mean = self::mean_of_rows( $attempts[ $u ] ?? array() );
			if ( null !== $mean && $mean < 50 ) {
				$reasons[] = 'low_scores';
			}
			if ( $reasons ) {
				$out[] = array( 'user_id' => $u, 'completion' => $comp, 'mean' => $mean, 'last_active' => $l, 'reasons' => $reasons );
			}
		}
		return $out;
	}

	/* ================= administration ================= */

	/** A1 */
	public static function active_enrollments( Filters $f ): int {
		global $wpdb;
		$in = AssessmentSource::in_list( $f->courses() );
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::en() . " WHERE course_id IN ({$in}) AND status='active' AND (expires_at IS NULL OR expires_at > %s)", gmdate( 'Y-m-d H:i:s', $f->now ) ) . $f->cohort_sql( 'user_id' ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/**
	 * A2: per course enrolled, active learners in range, completions in range.
	 * Three grouped queries for all courses (was three per course; PERF-149-01). Same results.
	 */
	public static function participation( Filters $f ): array {
		global $wpdb;
		$courses = $f->courses();
		if ( ! $courses ) {
			return array();
		}
		$in       = AssessmentSource::in_list( $courses );
		$enrolled = array();
		foreach ( $wpdb->get_results( 'SELECT course_id, COUNT(*) n FROM ' . self::en() . " WHERE course_id IN ({$in}) AND status IN ('active','completed')" . $f->cohort_sql( 'user_id' ) . ' GROUP BY course_id', ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$enrolled[ (int) $r['course_id'] ] = (int) $r['n'];
		}
		$active = array();
		$sql    = 'SELECT x.course_id, COUNT(DISTINCT x.user_id) n FROM (' . self::activity_sql( $in, $f->from_dt(), $f->to_dt(), true ) . ') x JOIN ' . self::en() . " e ON e.course_id = x.course_id AND e.user_id = x.user_id AND e.status IN ('active','completed')" . $f->cohort_sql( 'e.user_id' ) . ' GROUP BY x.course_id';
		foreach ( $wpdb->get_results( $sql, ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$active[ (int) $r['course_id'] ] = (int) $r['n'];
		}
		$done = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT course_id, COUNT(*) n FROM ' . self::en() . " WHERE course_id IN ({$in}) AND status='completed' AND completed_at BETWEEN %s AND %s", $f->from_dt(), $f->to_dt() ) . $f->cohort_sql( 'user_id' ) . ' GROUP BY course_id', ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$done[ (int) $r['course_id'] ] = (int) $r['n'];
		}
		$out = array();
		foreach ( $courses as $cid ) {
			$n     = $enrolled[ $cid ] ?? 0;
			$a     = $n ? ( $active[ $cid ] ?? 0 ) : 0;
			$out[] = array( 'course_id' => $cid, 'course' => get_the_title( $cid ), 'enrolled' => $n, 'active' => $a, 'participation' => self::pct( $a, $n ), 'completions' => $done[ $cid ] ?? 0 );
		}
		return $out;
	}

	/** A3: course completions per calendar month (YYYY-MM => n). */
	public static function completion_trend( Filters $f ): array {
		global $wpdb;
		$in   = AssessmentSource::in_list( $f->courses() );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT DATE_FORMAT(completed_at,'%%Y-%%m') m, COUNT(*) n FROM " . self::en() . " WHERE course_id IN ({$in}) AND status='completed' AND completed_at BETWEEN %s AND %s", $f->from_dt(), $f->to_dt() ) . $f->cohort_sql( 'user_id' ) . ' GROUP BY m ORDER BY m', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ $r['m'] ] = (int) $r['n'];
		}
		return $out;
	}

	/** A4: by programme or academic year: learners and mean course completion % over their enrollments. */
	public static function cohorts( Filters $f, string $by = 'programme' ): array {
		global $wpdb;
		$key  = 'year' === $by ? 'educore_academic_year' : 'educore_programme_id';
		$in   = AssessmentSource::in_list( $f->courses() );
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT e.user_id, e.course_id, COALESCE(m.meta_value, \'\') cohort FROM ' . self::en() . " e LEFT JOIN {$wpdb->usermeta} m ON m.user_id=e.user_id AND m.meta_key=%s WHERE e.course_id IN ({$in}) AND e.status IN ('active','completed')", $key ) . $f->cohort_sql( 'e.user_id' ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$agg  = array();
		foreach ( $rows as $r ) {
			$c = (string) $r['cohort'];
			$v = self::course_completion( (int) $r['user_id'], (int) $r['course_id'] );
			$agg[ $c ]['users'][ (int) $r['user_id'] ] = true;
			if ( null !== $v ) {
				$agg[ $c ]['vals'][] = $v;
			}
		}
		$out = array();
		foreach ( $agg as $c => $a ) {
			$label = '' === $c ? __( '(not set)', 'educore-analytics' ) : $c;
			if ( 'programme' === $by && '' !== $c ) {
				$name  = $wpdb->get_var( $wpdb->prepare( 'SELECT name FROM ' . Schema::table( 'programmes' ) . ' WHERE id=%d', (int) $c ) );
				$label = $name ?: $c;
			}
			$vals  = $a['vals'] ?? array();
			$out[] = array( 'cohort' => $c, 'label' => $label, 'learners' => count( $a['users'] ), 'mean_completion' => $vals ? round( array_sum( $vals ) / count( $vals ), 1 ) : null );
		}
		usort( $out, static fn( $x, $y ) => strcmp( $x['cohort'], $y['cohort'] ) );
		return $out;
	}

	/** A5: questions with ≥5 responses and p < 0.20 (too hard) or p > 0.95 (too easy). */
	public static function assessment_quality( Filters $f ): ?array {
		$s = self::question_stats( $f );
		if ( null === $s ) {
			return null;
		}
		$out = array();
		foreach ( $s as $q ) {
			if ( $q['p'] < 0.2 || $q['p'] > 0.95 ) {
				$q['flag'] = $q['p'] < 0.2 ? 'too_hard' : 'too_easy';
				$out[]     = $q;
			}
		}
		return $out;
	}

	/** A6: published lessons never opened by anyone. */
	public static function unused_lessons( Filters $f ): array {
		global $wpdb;
		$out = array();
		$all = array();
		foreach ( $f->courses() as $cid ) {
			$all[ $cid ] = Content::lesson_ids( $cid );
		}
		$every  = array_values( array_unique( array_merge( array(), ...array_values( $all ) ) ) );
		$opened = $every ? array_map( 'intval', $wpdb->get_col( 'SELECT DISTINCT lesson_id FROM ' . self::lp() . ' WHERE lesson_id IN (' . implode( ',', array_map( 'intval', $every ) ) . ')' ) ) : array(); // phpcs:ignore WordPress.DB.PreparedSQL -- integer list; one scan for all courses (PERF-149-01).
		foreach ( $all as $cid => $ids ) {
			if ( ! $ids ) {
				continue;
			}
			foreach ( array_diff( $ids, $opened ) as $lid ) {
				$out[] = array( 'lesson_id' => $lid, 'lesson' => get_the_title( $lid ), 'course_id' => $cid, 'course' => get_the_title( $cid ) );
			}
		}
		return $out;
	}

	/** A7: DAU for one day (live). */
	public static function dau( string $day, Filters $f ): int {
		global $wpdb;
		$sql = 'SELECT COUNT(DISTINCT user_id) FROM (' . self::activity_sql( AssessmentSource::in_list( $f->courses() ), $day . ' 00:00:00', $day . ' 23:59:59' ) . ') x WHERE 1=1' . $f->cohort_sql( 'user_id' );
		return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** A7: WAU = distinct active users in the 7 days ending on $day. */
	public static function wau( string $day, Filters $f ): int {
		global $wpdb;
		$from = gmdate( 'Y-m-d', strtotime( $day . ' -6 days' ) );
		$sql  = 'SELECT COUNT(DISTINCT user_id) FROM (' . self::activity_sql( AssessmentSource::in_list( $f->courses() ), $from . ' 00:00:00', $day . ' 23:59:59' ) . ') x WHERE 1=1' . $f->cohort_sql( 'user_id' );
		return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
	}
}
