<?php
namespace EduCore\Assessments\Exchange;

use EduCore\Assessments\Questions;
use EduCore\Core\Audit;

defined( 'ABSPATH' ) || exit;

/** Course question-bank export with filters, in any supported format. */
final class Exporter {

	/** @param array $f status ('' = all but archived), type, lesson_id, tag, difficulty */
	public static function records( int $course_id, array $f = array() ): array {
		$out  = array();
		$page = 1;
		$args = array( 'course_id' => $course_id, 'per_page' => 200 );
		foreach ( array( 'status', 'type', 'lesson_id', 'difficulty' ) as $k ) {
			if ( ! empty( $f[ $k ] ) ) {
				$args[ $k ] = $f[ $k ];
			}
		}
		do {
			$batch = Questions::search( $args + array( 'page' => $page ) );
			foreach ( $batch['rows'] as $row ) {
				if ( empty( $f['status'] ) && 'archived' === $row['status'] ) {
					continue;
				}
				$r = Record::from_question( (int) $row['id'] );
				if ( $r && ( empty( $f['tag'] ) || in_array( sanitize_title( (string) $f['tag'] ), $r['tags'], true ) ) ) {
					$out[ (int) $row['id'] ] = $r;
				}
			}
			++$page;
		} while ( count( $batch['rows'] ) === 200 );
		ksort( $out );
		return array_values( $out );
	}

	/** @return array{bytes:string,filename:string,mime:string,count:int,skipped:string[]} */
	public static function export( int $course_id, string $format, array $filters = array() ): array {
		$records = self::records( $course_id, $filters );
		$skipped = array();
		$fmt     = Formats::all()[ $format ];
		$bytes   = Formats::write( $format, $records, $skipped, array( 'course_id' => $course_id, 'course_title' => get_the_title( $course_id ) ) );
		$slug    = sanitize_title( get_the_title( $course_id ) ) ?: 'course-' . $course_id;
		Audit::log( 'questions.exported', 'course', $course_id, array( 'format' => $format, 'count' => count( $records ) - count( $skipped ), 'skipped' => count( $skipped ) ) );
		return array(
			'bytes'    => $bytes,
			'filename' => 'questions-' . $slug . '-' . gmdate( 'Ymd-His' ) . '.' . $fmt['ext'],
			'mime'     => $fmt['mime'],
			'count'    => count( $records ),
			'skipped'  => $skipped,
		);
	}
}
