<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Signed release channel for all EduCore packages (plugins + theme).
 *
 * - The manifest (JSON) lists each package's version, download URL and SHA-256 and is signed with
 *   Ed25519. Only the public key below is shipped; a manifest that does not verify is ignored.
 * - Downloads are verified against the signed SHA-256 before WordPress installs them; a mismatch
 *   aborts the update. The hosting location therefore does not need to be trusted.
 * - Optional automatic installation through WordPress's native auto-updater (runs on cron).
 */
final class Updater {
	public const PUBLIC_KEY = 'wnG3eFq9qP96czwqUJ5/qtUDzA1ZPync7tR9wQnh+So=';
	public const CACHE      = 'educore_update_manifest';
	/** Package slug tail: educore-<word>(-<word>)*, e.g. educore-core, educore-teaching-hub. */
	public const SLUG       = '[a-z]+(?:-[a-z]+)*';
	public const TTL        = 6 * HOUR_IN_SECONDS;

	public static function register(): void {
		add_filter( 'pre_set_site_transient_update_plugins', array( self::class, 'inject_plugins' ) );
		add_filter( 'pre_set_site_transient_update_themes', array( self::class, 'inject_themes' ) );
		add_filter( 'upgrader_pre_download', array( self::class, 'verified_download' ), 10, 4 );
		add_filter( 'auto_update_plugin', array( self::class, 'auto_update_plugin' ), 20, 2 );
		add_filter( 'auto_update_theme', array( self::class, 'auto_update_theme' ), 20, 2 );
		add_action( 'educore/admin/settings_rows', array( self::class, 'settings_rows' ) );
		add_action( 'educore/admin/settings_save', array( self::class, 'settings_save' ) );
	}

	public static function manifest_url(): string {
		return trim( (string) get_option( 'educore_update_manifest_url', '' ) );
	}

	public static function auto_enabled(): bool {
		return 'on' === get_option( 'educore_auto_update', 'off' ) && '' !== self::manifest_url();
	}

	/* ---------- signature ---------- */

	/** Canonical JSON: keys sorted recursively, unescaped slashes/unicode. Must match tools/sign-release.php. */
	public static function canonical( array $data ): string {
		$sort = static function ( $v ) use ( &$sort ) {
			if ( is_array( $v ) ) {
				if ( array_keys( $v ) !== range( 0, count( $v ) - 1 ) ) {
					ksort( $v );
				}
				return array_map( $sort, $v );
			}
			return $v;
		};
		return (string) wp_json_encode( $sort( $data ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	}

	/** @return array<string,mixed>|\WP_Error verified manifest */
	public static function verify_manifest( string $json, string $public_key_b64 = self::PUBLIC_KEY ) {
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) || empty( $data['signature'] ) || empty( $data['packages'] ) || ! is_array( $data['packages'] ) ) {
			return new \WP_Error( 'educore_update_format', 'Update manifest is malformed.' );
		}
		$sig = base64_decode( (string) $data['signature'], true );
		$key = base64_decode( $public_key_b64, true );
		unset( $data['signature'] );
		if ( false === $sig || false === $key || SODIUM_CRYPTO_SIGN_BYTES !== strlen( $sig ) || SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES !== strlen( $key )
			|| ! sodium_crypto_sign_verify_detached( $sig, self::canonical( $data ), $key ) ) {
			return new \WP_Error( 'educore_update_signature', 'Update manifest signature is invalid.' );
		}
		foreach ( $data['packages'] as $slug => $p ) {
			if ( ! preg_match( '/^educore-' . self::SLUG . '$/', (string) $slug ) || empty( $p['version'] ) || empty( $p['url'] ) || ! preg_match( '/^[a-f0-9]{64}$/', (string) ( $p['sha256'] ?? '' ) ) ) {
				return new \WP_Error( 'educore_update_format', 'Update manifest entry is invalid.' );
			}
		}
		return $data;
	}

	/* ---------- manifest retrieval ---------- */

	private static function url_allowed( string $url ): bool {
		$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
		return 'https' === $scheme || ( 'http' === $scheme && defined( 'EDUCORE_UPDATES_ALLOW_HTTP' ) && EDUCORE_UPDATES_ALLOW_HTTP );
	}

	/** @return array<string,mixed>|null verified manifest (cached) */
	public static function manifest( bool $force = false ): ?array {
		$url = self::manifest_url();
		if ( '' === $url || ! self::url_allowed( $url ) ) {
			return null;
		}
		if ( ! $force ) {
			$cached = get_site_transient( self::CACHE );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}
		$res = wp_remote_get( $url, array( 'timeout' => 15, 'redirection' => 3 ) );
		if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
			self::status( 'error', is_wp_error( $res ) ? $res->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $res ) );
			return null;
		}
		$m = self::verify_manifest( (string) wp_remote_retrieve_body( $res ) );
		if ( is_wp_error( $m ) ) {
			self::status( 'error', $m->get_error_message() );
			Audit::log( 'updates.manifest_rejected', 'updates', 0, array( 'reason' => $m->get_error_code() ) );
			return null;
		}
		set_site_transient( self::CACHE, $m, self::TTL );
		self::status( 'ok', 'Manifest verified (' . count( $m['packages'] ) . ' packages).' );
		return $m;
	}

	private static function status( string $state, string $message ): void {
		update_option( 'educore_update_status', array( 'state' => $state, 'message' => $message, 'checked_at' => Schema::now() ), false );
	}

	/** @return array<string,string> slug => installed version, for installed EduCore packages */
	public static function installed(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$out = array();
		foreach ( get_plugins() as $file => $data ) {
			$slug = dirname( $file );
			if ( preg_match( '/^educore-' . self::SLUG . '$/', $slug ) && $file === $slug . '/' . $slug . '.php' ) {
				$out[ $slug ] = (string) $data['Version'];
			}
		}
		$theme = wp_get_theme( 'educore-theme' );
		if ( $theme->exists() ) {
			$out['educore-theme'] = (string) $theme->get( 'Version' );
		}
		return $out;
	}

	/* ---------- WordPress update integration ---------- */

	public static function inject_plugins( $transient ) {
		$m = self::manifest();
		if ( ! $m || ! is_object( $transient ) ) {
			return $transient;
		}
		foreach ( self::installed() as $slug => $version ) {
			if ( 'educore-theme' === $slug || empty( $m['packages'][ $slug ] ) ) {
				continue;
			}
			$p    = $m['packages'][ $slug ];
			$file = $slug . '/' . $slug . '.php';
			$item = (object) array(
				'id'           => 'educore/' . $slug,
				'slug'         => $slug,
				'plugin'       => $file,
				'new_version'  => (string) $p['version'],
				'url'          => 'https://educore.gorgy.org',
				'package'      => (string) $p['url'],
				'tested'       => (string) ( $p['tested'] ?? '' ),
				'requires'     => (string) ( $p['requires'] ?? '' ),
				'requires_php' => (string) ( $p['requires_php'] ?? '' ),
			);
			if ( version_compare( (string) $p['version'], $version, '>' ) ) {
				$transient->response[ $file ] = $item;
			} else {
				$transient->no_update[ $file ] = $item;
			}
		}
		return $transient;
	}

	public static function inject_themes( $transient ) {
		$m = self::manifest();
		$v = self::installed()['educore-theme'] ?? null;
		if ( ! $m || ! is_object( $transient ) || null === $v || empty( $m['packages']['educore-theme'] ) ) {
			return $transient;
		}
		$p    = $m['packages']['educore-theme'];
		$item = array( 'theme' => 'educore-theme', 'new_version' => (string) $p['version'], 'url' => 'https://educore.gorgy.org', 'package' => (string) $p['url'], 'requires' => (string) ( $p['requires'] ?? '' ), 'requires_php' => (string) ( $p['requires_php'] ?? '' ) );
		if ( version_compare( (string) $p['version'], $v, '>' ) ) {
			$transient->response['educore-theme'] = $item;
		} else {
			$transient->no_update['educore-theme'] = $item;
		}
		return $transient;
	}

	/**
	 * Download EduCore packages ourselves and refuse any file whose SHA-256 differs from the
	 * signed manifest. Non-EduCore packages are left to WordPress.
	 */
	public static function verified_download( $reply, $package, $upgrader = null, $hook_extra = array() ) {
		if ( false !== $reply || ! is_string( $package ) ) {
			return $reply;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $reply;
		}
		$entry = null;
		foreach ( $m['packages'] as $slug => $p ) {
			if ( hash_equals( (string) $p['url'], $package ) ) {
				$entry = array( 'slug' => $slug ) + $p;
				break;
			}
		}
		if ( ! $entry ) {
			return $reply;
		}
		if ( ! self::url_allowed( $package ) ) {
			return new \WP_Error( 'educore_update_insecure', 'EduCore packages must be downloaded over HTTPS.' );
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $package, 300 );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		$hash = hash_file( 'sha256', $tmp );
		if ( ! hash_equals( (string) $entry['sha256'], (string) $hash ) ) {
			wp_delete_file( $tmp );
			Audit::log( 'updates.package_rejected', 'updates', 0, array( 'package' => $entry['slug'], 'version' => $entry['version'] ) );
			return new \WP_Error( 'educore_update_checksum', sprintf( 'EduCore package %s %s failed signature verification and was not installed.', $entry['slug'], $entry['version'] ) );
		}
		Audit::log( 'updates.package_verified', 'updates', 0, array( 'package' => $entry['slug'], 'version' => $entry['version'] ) );
		return $tmp;
	}

	/**
	 * Automatic updates are limited to maintenance/security releases (same MAJOR.MINOR as installed).
	 * Functional releases (new MINOR or MAJOR) always wait for an administrator — approval gate.
	 */
	public static function is_maintenance( string $installed, string $new ): bool {
		$a = array_map( 'intval', explode( '.', $installed ) + array( 0, 0, 0 ) );
		$b = array_map( 'intval', explode( '.', $new ) + array( 0, 0, 0 ) );
		return $a[0] === $b[0] && $a[1] === $b[1] && version_compare( $new, $installed, '>' );
	}

	public static function auto_update_plugin( $update, $item ) {
		if ( is_object( $item ) && isset( $item->plugin ) && preg_match( '#^(educore-' . self::SLUG . ')/\1\.php$#', (string) $item->plugin, $mm ) ) {
			$installed = self::installed()[ $mm[1] ] ?? '';
			return self::auto_enabled() && '' !== $installed && isset( $item->new_version ) && self::is_maintenance( $installed, (string) $item->new_version );
		}
		return $update;
	}

	public static function auto_update_theme( $update, $item ) {
		if ( is_object( $item ) && isset( $item->theme ) && 'educore-theme' === $item->theme ) {
			$installed = self::installed()['educore-theme'] ?? '';
			$new       = is_object( $item ) ? (string) ( $item->new_version ?? '' ) : '';
			return self::auto_enabled() && '' !== $installed && self::is_maintenance( $installed, $new );
		}
		return $update;
	}

	/** Signed packages listed in the manifest but not installed (new EduCore plugins). @return array<string,array<string,mixed>> */
	public static function available_new(): array {
		$m = self::manifest();
		if ( ! $m ) {
			return array();
		}
		$installed = self::installed();
		$out       = array();
		foreach ( $m['packages'] as $slug => $p ) {
			if ( 'educore-theme' !== $slug && ! isset( $installed[ $slug ] ) ) {
				$out[ $slug ] = $p;
			}
		}
		return $out;
	}

	/**
	 * Administrator-approved install of a NEW signed package (e.g. the Teaching Hub). The package is
	 * downloaded through verified_download(): SHA-256 from the Ed25519-signed manifest must match.
	 *
	 * @return true|\WP_Error
	 */
	public static function install_signed( string $slug, bool $activate = true ) {
		if ( ! current_user_can( 'install_plugins' ) || ! current_user_can( 'ec_manage_settings' ) ) {
			return new \WP_Error( 'educore_update_forbidden', __( 'You are not allowed to install plugins.', 'educore-core' ) );
		}
		$new = self::available_new();
		if ( ! isset( $new[ $slug ] ) ) {
			return new \WP_Error( 'educore_update_unknown', __( 'This package is not offered by the verified release channel.', 'educore-core' ) );
		}
		$p = $new[ $slug ];
		if ( ! empty( $p['requires_core'] ) && version_compare( EDUCORE_CORE_VERSION, (string) $p['requires_core'], '<' ) ) {
			/* translators: 1: package, 2: version */
			return new \WP_Error( 'educore_update_dependency', sprintf( __( '%1$s needs EduCore Core %2$s or newer. Update EduCore Core first.', 'educore-core' ), $slug, $p['requires_core'] ) );
		}
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$upgrader = new \Plugin_Upgrader( new \Automatic_Upgrader_Skin() );
		$res      = $upgrader->install( (string) $p['url'] );
		if ( is_wp_error( $res ) || ! $res ) {
			$err = is_wp_error( $res ) ? $res : ( $upgrader->skin->get_errors()->has_errors() ? $upgrader->skin->get_errors() : new \WP_Error( 'educore_update_failed', __( 'The package could not be installed.', 'educore-core' ) ) );
			Audit::log( 'updates.install_failed', 'updates', 0, array( 'package' => $slug, 'error' => $err->get_error_code() ) );
			return $err;
		}
		Audit::log( 'updates.package_installed', 'updates', 0, array( 'package' => $slug, 'version' => $p['version'] ) );
		if ( $activate ) {
			$act = activate_plugin( $slug . '/' . $slug . '.php' );
			if ( is_wp_error( $act ) ) {
				return $act;
			}
		}
		return true;
	}

	/* ---------- settings ---------- */

	public static function settings_rows(): void {
		$st = (array) get_option( 'educore_update_status', array() );
		echo '<tr><th>' . esc_html__( 'Release channel (manifest URL)', 'educore-core' ) . '</th><td><input type="url" class="large-text" name="educore_update_manifest_url" value="' . esc_attr( self::manifest_url() ) . '" placeholder="https://…/manifest.json"><p class="description">' . esc_html__( 'Signed EduCore release manifest. Packages are installed only if their Ed25519 signature and SHA-256 checksum verify.', 'educore-core' ) . '</p>';
		if ( $st ) {
			/* translators: 1: state, 2: message, 3: time */
			echo '<p class="description">' . esc_html( sprintf( __( 'Last check: %1$s — %2$s (%3$s UTC)', 'educore-core' ), $st['state'] ?? '', $st['message'] ?? '', $st['checked_at'] ?? '' ) ) . '</p>';
		}
		echo '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Automatic updates', 'educore-core' ) . '</th><td><label><input type="checkbox" name="educore_auto_update" value="on"' . checked( 'on', get_option( 'educore_auto_update', 'off' ), false ) . '> ' . esc_html__( 'Install verified maintenance and security releases automatically (same major.minor version). New feature releases always wait for an administrator.', 'educore-core' ) . '</label></td></tr>';
		$new = self::manifest_url() ? self::available_new() : array();
		if ( $new && current_user_can( 'install_plugins' ) ) {
			echo '<tr><th>' . esc_html__( 'New signed packages', 'educore-core' ) . '</th><td>';
			foreach ( $new as $slug => $p ) {
				echo '<p><code>' . esc_html( $slug ) . '</code> ' . esc_html( (string) $p['version'] ) . ' <button class="button" name="educore_install_package" value="' . esc_attr( $slug ) . '">' . esc_html__( 'Verify, install & activate', 'educore-core' ) . '</button></p>';
			}
			echo '<p class="description">' . esc_html__( 'Back up the site first. The package is installed only if its signature and checksum verify.', 'educore-core' ) . '</p></td></tr>';
		}
	}

	public static function settings_save(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified by Admin\Menu::handle().
		$url = isset( $_POST['educore_update_manifest_url'] ) ? trim( esc_url_raw( wp_unslash( $_POST['educore_update_manifest_url'] ) ) ) : '';
		update_option( 'educore_update_manifest_url', self::url_allowed( $url ) ? $url : '' );
		update_option( 'educore_auto_update', ! empty( $_POST['educore_auto_update'] ) ? 'on' : 'off' );
		// phpcs:enable
		delete_site_transient( self::CACHE );
		if ( '' !== self::manifest_url() ) {
			self::manifest( true );
			delete_site_transient( 'update_plugins' );
			delete_site_transient( 'update_themes' );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified by Admin\Menu::handle().
		$pkg = isset( $_POST['educore_install_package'] ) ? sanitize_key( wp_unslash( $_POST['educore_install_package'] ) ) : '';
		if ( '' !== $pkg && preg_match( '/^educore-' . self::SLUG . '$/', $pkg ) ) {
			$res = self::install_signed( $pkg );
			self::status( is_wp_error( $res ) ? 'error' : 'ok', is_wp_error( $res ) ? $res->get_error_message() : sprintf( 'Installed %s.', $pkg ) );
		}
	}
}
