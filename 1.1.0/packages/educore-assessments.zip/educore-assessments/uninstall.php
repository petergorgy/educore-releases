<?php
/** EduCore Assessments uninstall — data kept unless the administrator opted in via EduCore settings. */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

wp_clear_scheduled_hook( 'educore_assessments_expire' );
if ( 'yes' !== get_option( 'educore_uninstall_delete_data' ) ) {
	return;
}
global $wpdb;
foreach ( array( 'question_banks', 'questions', 'question_versions', 'question_tags', 'assessments', 'assessment_pools', 'attempts', 'attempt_items', 'responses', 'rubrics', 'practice_tries' ) as $t ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'ec_' . $t ); // phpcs:ignore WordPress.DB.PreparedSQL
}
delete_option( 'educore_assessments_db_version' );
