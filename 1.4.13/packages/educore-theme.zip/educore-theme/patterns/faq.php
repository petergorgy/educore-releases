<?php
/**
 * Title: EduCore — frequently asked questions
 * Slug: educore-theme/faq
 * Categories: educore-theme, text
 * Description: Short answers to common questions, using accessible native disclosure widgets.
 */
$ect_open = educore_theme_registration_open();
$ect_faq  = array(
	array(
		__( 'Who can join EduCore?', 'educore-theme' ),
		$ect_open
			? __( 'Anyone can create a free account. Learners under 18 join with a parent or guardian’s consent.', 'educore-theme' )
			: __( 'Accounts are currently created by your school or by our support team. Contact us to request access.', 'educore-theme' ),
	),
	array( __( 'Which languages are available?', 'educore-theme' ), __( 'English, French and Arabic. You can switch at any time; in Arabic the whole interface reads from right to left.', 'educore-theme' ) ),
	array( __( 'Does it work on my phone?', 'educore-theme' ), __( 'Yes. EduCore works in any modern browser on a phone, tablet or computer, and your progress is saved to your account.', 'educore-theme' ) ),
	array( __( 'When do I see my results?', 'educore-theme' ), __( 'Automatically marked questions are scored as soon as you submit. Work marked by a teacher appears once the teacher releases it.', 'educore-theme' ) ),
	array( __( 'Who can see my information?', 'educore-theme' ), __( 'Only the people who need it: you see your own work, guardians see their linked children, and staff see the classes and courses they are responsible for.', 'educore-theme' ) ),
);
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|30"}}},"className":"ect-section ect-faq","layout":{"type":"constrained"}} -->
<div class="wp-block-group ect-section ect-faq" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--30)">
<!-- wp:columns {"align":"wide","className":"ect-faq__grid"} -->
<div class="wp-block-columns alignwide ect-faq__grid">
<!-- wp:column {"width":"34%"} -->
<div class="wp-block-column" style="flex-basis:34%">
<!-- wp:paragraph {"className":"ect-eyebrow ect-eyebrow--dark"} --><p class="ect-eyebrow ect-eyebrow--dark"><?php esc_html_e( 'Help', 'educore-theme' ); ?></p><!-- /wp:paragraph -->
<!-- wp:heading {"className":"ect-section__title"} --><h2 class="wp-block-heading ect-section__title"><?php esc_html_e( 'Questions and answers', 'educore-theme' ); ?></h2><!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color"><?php esc_html_e( 'Something else on your mind?', 'educore-theme' ); ?> <a href="<?php echo esc_url( educore_theme_url( 'contact' ) ); ?>"><?php esc_html_e( 'Contact us', 'educore-theme' ); ?></a></p><!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column {"width":"66%"} -->
<div class="wp-block-column" style="flex-basis:66%">
<?php foreach ( $ect_faq as $ect_q ) : ?>
<!-- wp:details {"className":"ect-faq__item"} -->
<details class="wp-block-details ect-faq__item"><summary><?php echo esc_html( $ect_q[0] ); ?></summary><!-- wp:paragraph --><p><?php echo esc_html( $ect_q[1] ); ?></p><!-- /wp:paragraph --></details>
<!-- /wp:details -->
<?php endforeach; ?>
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
