=== EduCore Certificates ===
Contributors: gorgyorg
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: lms, certificate, pdf, verification

Completion certificates with PDF generation and public verification for EduCore.

== Description ==

Part of the EduCore LMS (https://educore.gorgy.org), an initiative of GORGY.ORG.

* Automatic issue on course completion (idempotent), manual issue, revoke and reinstate with reasons.
* Templates in English, French and Arabic (Arabic text correctly shaped).
* Unique certificate IDs and a public verification page that shows only name, course, date and status.
* PDFs stored in a protected folder and downloadable only by the owner, course staff and certificate managers.

Requires EduCore Core. Bundles mPDF 8.2.5 (GPL-2.0) and its MIT-licensed dependencies — see lib/README.md.

== Installation ==

1. Install and activate EduCore Core first.
2. Upload and activate this plugin.
3. Run EduCore → Setup wizard → "Run database & roles setup".

== Changelog ==

= 1.0.1 =
* New: QR code on certificates linking to the public verification page (bundles mpdf/qrcode 1.2.1, LGPL-2.1-or-later).

= 1.0.0 =
* First release.
