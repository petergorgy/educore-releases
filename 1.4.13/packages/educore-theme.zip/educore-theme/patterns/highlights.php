<?php
/**
 * Title: EduCore highlights
 * Slug: educore-theme/highlights
 * Categories: educore-theme, features
 * Description: Four key facts about the platform, shown as a strip under the hero.
 */
$ect_items = array(
	array( '3', __( 'languages, including right-to-left Arabic', 'educore-theme' ) ),
	array( '10', __( 'question types for quizzes and exams', 'educore-theme' ) ),
	array( '6', __( 'workspaces, one for each role in the school', 'educore-theme' ) ),
	array( '1', __( 'account that keeps your progress on every device', 'educore-theme' ) ),
);
?>
<!-- wp:group {"align":"wide","className":"ect-highlights","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide ect-highlights">
<!-- wp:html -->
<ul class="ect-highlights__list">
<?php foreach ( $ect_items as $ect_it ) : ?>
<li class="ect-reveal"><strong><?php echo esc_html( $ect_it[0] ); ?></strong><span><?php echo esc_html( $ect_it[1] ); ?></span></li>
<?php endforeach; ?>
</ul>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
