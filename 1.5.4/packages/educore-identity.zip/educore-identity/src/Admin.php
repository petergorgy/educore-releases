<?php
namespace EduCore\Identity;

use EduCore\Core\Audit;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * WordPress → EduCore → Identity Providers (technical administrators only).
 * A provider appears on the sign-in screen only when: enabled + client ID + secret + a successful test sign-in.
 */
final class Admin {
	public const CAP = 'manage_options';

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 45 );
		add_action( 'admin_post_educore_id_save', array( self::class, 'save' ) );
		add_action( 'admin_post_educore_id_check', array( self::class, 'check' ) );
		add_action( 'admin_post_educore_id_test', array( self::class, 'test' ) );
	}

	public static function menu(): void {
		add_submenu_page( 'educore', __( 'Identity Providers', 'educore-identity' ), __( 'Identity Providers', 'educore-identity' ), self::CAP, 'educore-identity', array( self::class, 'page' ) );
	}

	private static function guard( string $nonce ): void {
		if ( ! current_user_can( self::CAP ) || ! check_admin_referer( $nonce ) ) {
			wp_die( esc_html__( 'You do not have permission to change identity providers.', 'educore-identity' ), 403 );
		}
	}

	private static function back( string $p, string $msg ): void {
		$url = add_query_arg( array( 'page' => 'educore-identity', 'msg' => $msg, 'p' => $p ), admin_url( 'admin.php' ) ) . '#ec-id-' . $p;
		do_action( 'educore/identity/redirect', $url );
		wp_safe_redirect( $url );
		exit;
	}

	public static function save(): void {
		$p = sanitize_key( wp_unslash( $_POST['provider'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification -- guard() next.
		self::guard( 'educore_id_save_' . $p );
		if ( ! in_array( $p, Providers::KEYS, true ) ) {
			self::back( $p, 'error' );
		}
		$c       = Providers::config( $p );
		$before  = array( $c['client_id'], $c['tenant'], $c['graph'] );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- guard() above.
		$c['enabled']   = ! empty( $_POST['enabled'] );
		$c['client_id'] = trim( sanitize_text_field( wp_unslash( $_POST['client_id'] ?? '' ) ) );
		$secret         = isset( $_POST['client_secret'] ) ? trim( (string) wp_unslash( $_POST['client_secret'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- secrets are stored encrypted as entered.
		if ( '' !== $secret ) {
			$c['secret'] = Providers::encrypt( $secret ); // Rotation: a new secret replaces the old one.
		} elseif ( ! empty( $_POST['clear_secret'] ) ) {
			$c['secret'] = '';
		}
		if ( 'microsoft' === $p ) {
			$t           = sanitize_text_field( wp_unslash( $_POST['tenant'] ?? 'consumers' ) );
			$c['tenant'] = Providers::valid_tenant( $t ) ? $t : 'consumers';
		}
		if ( 'facebook' === $p ) {
			$g          = sanitize_text_field( wp_unslash( $_POST['graph'] ?? 'v25.0' ) );
			$c['graph'] = preg_match( '/^v\d{1,2}\.\d$/', $g ) ? $g : 'v25.0';
		}
		// phpcs:enable
		if ( '' !== $secret || array( $c['client_id'], $c['tenant'], $c['graph'] ) !== $before ) {
			$c['health'] = array( 'ok' => false, 'at' => '', 'message' => __( 'Configuration changed: run the test sign-in again.', 'educore-identity' ) );
		}
		Providers::save_config( $p, $c );
		Audit::log( 'identity.provider_saved', 'identity', 0, array( 'provider' => $p, 'enabled' => $c['enabled'], 'secret_changed' => '' !== $secret ) );
		self::back( $p, 'saved' );
	}

	/** Server-side configuration check: discovery + signing keys (OIDC) or app credentials (Facebook). */
	public static function check(): void {
		$p = sanitize_key( wp_unslash( $_POST['provider'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification -- guard() next.
		self::guard( 'educore_id_check_' . $p );
		if ( ! Providers::configured( $p ) ) {
			self::back( $p, 'incomplete' );
		}
		$def = Providers::def( $p );
		if ( 'facebook' === $def['type'] ) {
			$r  = Oidc::get_json( add_query_arg( array( 'client_id' => rawurlencode( (string) Providers::config( $p )['client_id'] ), 'client_secret' => rawurlencode( Providers::secret( $p ) ), 'grant_type' => 'client_credentials' ), Providers::expand( (string) $def['token'], $p ) ), $p );
			$ok = ! is_wp_error( $r ) && ! empty( $r['access_token'] );
		} else {
			$d  = Oidc::discovery( $p, true );
			$ok = ! is_wp_error( $d ) && ! is_wp_error( Oidc::jwks( $p, (string) $d['jwks_uri'], true ) );
			$r  = $d;
		}
		Audit::log( 'identity.provider_checked', 'identity', 0, array( 'provider' => $p, 'ok' => $ok ) );
		self::back( $p, $ok ? 'checked' : 'check_failed' );
	}

	/** Round-trip test sign-in for the administrator: proves redirect URI, credentials and token checks. No sign-in or link happens. */
	public static function test(): void {
		$p = sanitize_key( wp_unslash( $_POST['provider'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification -- guard() next.
		self::guard( 'educore_id_test_' . $p );
		if ( ! Providers::configured( $p ) ) {
			self::back( $p, 'incomplete' );
		}
		Flow::begin( $p, 'test', get_current_user_id() );
	}

	public static function record_test( string $p, array $id, int $uid ): void {
		$current = (int) wp_validate_auth_cookie( '', 'logged_in' );
		if ( ! $uid || $current !== $uid || ! user_can( $uid, self::CAP ) ) {
			wp_die( esc_html__( 'The test sign-in must be finished by the administrator who started it.', 'educore-identity' ), 403 );
		}
		$c           = Providers::config( $p );
		$c['health'] = array(
			'ok'      => true,
			'at'      => Schema::now(),
			/* translators: 1: whether an e-mail was received, 2: whether it is verified */
			'message' => sprintf( __( 'Test sign-in succeeded. Subject received; e-mail %1$s (%2$s).', 'educore-identity' ), '' !== $id['email'] ? __( 'received', 'educore-identity' ) : __( 'not provided', 'educore-identity' ), $id['email_verified'] ? __( 'verified', 'educore-identity' ) : __( 'not used for matching', 'educore-identity' ) ),
		);
		Providers::save_config( $p, $c );
		Audit::log( 'identity.provider_tested', 'identity', 0, array( 'provider' => $p, 'ok' => true ) );
	}

	public static function page(): void {
		wp_enqueue_style( 'educore-identity', EDUCORE_ID_URL . 'assets/css/identity.css', array(), EDUCORE_ID_VERSION );
		wp_print_styles( 'educore-identity' );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display only.
		$msg  = sanitize_key( wp_unslash( $_GET['msg'] ?? '' ) );
		$mp   = sanitize_key( wp_unslash( $_GET['p'] ?? ( $_GET['tested'] ?? '' ) ) );
		$test = sanitize_key( wp_unslash( $_GET['tested'] ?? '' ) );
		// phpcs:enable
		$notes = array(
			'saved'        => array( 'success', __( 'Saved.', 'educore-identity' ) ),
			'checked'      => array( 'success', __( 'Configuration check passed. Now run a test sign-in to make the button visible.', 'educore-identity' ) ),
			'check_failed' => array( 'error', __( 'Configuration check failed. Check the client ID, secret and (for Microsoft) the tenant.', 'educore-identity' ) ),
			'incomplete'   => array( 'error', __( 'Enter the client ID and secret first.', 'educore-identity' ) ),
			'error'        => array( 'error', __( 'Nothing was saved.', 'educore-identity' ) ),
		);
		echo '<div class="wrap"><h1>' . esc_html__( 'Identity Providers', 'educore-identity' ) . '</h1>';
		echo '<p>' . esc_html__( 'People can sign in with these accounts in addition to their EduCore password. Social sign-in never opens registration, never grants a role, and never replaces guardian consent or two-factor verification. A button appears on the sign-in screen only after the provider is enabled, configured and a test sign-in has passed.', 'educore-identity' ) . '</p>';
		if ( $test ) {
			echo '<div class="notice notice-success"><p>' . esc_html( (string) Providers::config( $test )['health']['message'] ) . '</p></div>';
		} elseif ( isset( $notes[ $msg ] ) ) {
			echo '<div class="notice notice-' . esc_attr( $notes[ $msg ][0] ) . '"><p>' . esc_html( Providers::label( $mp ) . ': ' . $notes[ $msg ][1] ) . '</p></div>';
		}
		$reg = \EduCore\Core\Pages::registration_open();
		echo '<p><strong>' . esc_html__( 'Registration policy:', 'educore-identity' ) . '</strong> ' . esc_html( $reg ? __( 'open — a new person signing in with Google or LinkedIn (verified e-mail) is sent to EduCore’s registration form, including age and guardian consent; the provider is connected afterwards.', 'educore-identity' ) : __( 'closed — only accounts already connected can sign in with a provider. Others are told to sign in with their password and connect from Preferences.', 'educore-identity' ) ) . '</p>';
		foreach ( Providers::KEYS as $p ) {
			$def = Providers::def( $p );
			$c   = Providers::config( $p );
			$st  = Providers::available( $p ) ? __( 'Visible on the sign-in screen', 'educore-identity' ) : ( ! empty( $c['enabled'] ) ? __( 'Enabled, waiting for configuration or a successful test', 'educore-identity' ) : __( 'Disabled', 'educore-identity' ) );
			echo '<div class="card" id="ec-id-' . esc_attr( $p ) . '" style="max-width:900px"><h2>' . LoginUi::mark( $p ) . ' ' . esc_html( $def['label'] ) . ' <small>— ' . esc_html( $st ) . '</small></h2>'; // phpcs:ignore WordPress.Security.EscapeOutput -- static SVG.
			echo '<p>' . esc_html__( 'Redirect (callback) URL to register with the provider:', 'educore-identity' ) . ' <code>' . esc_html( Providers::callback_url( $p ) ) . '</code> · <a href="' . esc_url( $def['console'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open the provider’s developer console', 'educore-identity' ) . '</a></p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="educore_id_save"><input type="hidden" name="provider" value="' . esc_attr( $p ) . '">';
			wp_nonce_field( 'educore_id_save_' . $p );
			echo '<table class="form-table" role="presentation"><tr><th scope="row">' . esc_html__( 'Enabled', 'educore-identity' ) . '</th><td><label><input type="checkbox" name="enabled" value="1"' . checked( ! empty( $c['enabled'] ), true, false ) . '> ' . esc_html__( 'Allow sign-in with this provider', 'educore-identity' ) . '</label></td></tr>';
			echo '<tr><th scope="row"><label for="ec-id-cid-' . esc_attr( $p ) . '">' . esc_html__( 'Client ID / App ID', 'educore-identity' ) . '</label></th><td><input class="regular-text" id="ec-id-cid-' . esc_attr( $p ) . '" name="client_id" value="' . esc_attr( (string) $c['client_id'] ) . '" autocomplete="off"></td></tr>';
			$const = '' !== Providers::constant( $p );
			echo '<tr><th scope="row"><label for="ec-id-sec-' . esc_attr( $p ) . '">' . esc_html__( 'Client secret', 'educore-identity' ) . '</label></th><td>' . ( $const
				? '<p>' . esc_html__( 'Set in wp-config.php (recommended). It cannot be changed here.', 'educore-identity' ) . '</p>'
				: '<input class="regular-text" type="password" id="ec-id-sec-' . esc_attr( $p ) . '" name="client_secret" value="" autocomplete="new-password" placeholder="' . esc_attr( Providers::has_secret( $p ) ? __( 'Stored (encrypted). Enter a new one to rotate.', 'educore-identity' ) : __( 'Not set', 'educore-identity' ) ) . '">' . ( Providers::has_secret( $p ) ? ' <label><input type="checkbox" name="clear_secret" value="1"> ' . esc_html__( 'Remove the stored secret', 'educore-identity' ) . '</label>' : '' )
				. '<p class="description">' . esc_html( sprintf( /* translators: %s: constant name */ __( 'Preferably define %s in wp-config.php instead. Secrets are never shown again or sent to browsers.', 'educore-identity' ), 'EDUCORE_SSO_' . strtoupper( $p ) . '_SECRET' ) ) . '</p>' ) . '</td></tr>';
			if ( 'microsoft' === $p ) {
				echo '<tr><th scope="row"><label for="ec-id-ten">' . esc_html__( 'Accounts accepted', 'educore-identity' ) . '</label></th><td><input class="regular-text" id="ec-id-ten" name="tenant" value="' . esc_attr( (string) $c['tenant'] ) . '"><p class="description">' . esc_html__( '“consumers” = personal Microsoft accounts; “organizations” = any work or school account; “common” = both; or your institution’s tenant ID (recommended for school accounts). Organisation membership is never trusted on its own: accounts still have to be connected.', 'educore-identity' ) . '</p></td></tr>';
			}
			if ( 'facebook' === $p ) {
				echo '<tr><th scope="row"><label for="ec-id-gv">' . esc_html__( 'Graph API version', 'educore-identity' ) . '</label></th><td><input id="ec-id-gv" name="graph" value="' . esc_attr( (string) $c['graph'] ) . '" size="8"></td></tr>';
			}
			$h = (array) $c['health'];
			echo '<tr><th scope="row">' . esc_html__( 'Health', 'educore-identity' ) . '</th><td>' . esc_html( ! empty( $h['ok'] ) ? '✓ ' . $h['message'] . ' (' . $h['at'] . ' UTC)' : ( $h['message'] ?: __( 'Not tested yet.', 'educore-identity' ) ) ) . '</td></tr></table>';
			submit_button( __( 'Save', 'educore-identity' ), 'primary', 'submit', false );
			echo '</form><p>';
			foreach ( array( 'check' => __( 'Check configuration', 'educore-identity' ), 'test' => __( 'Run a test sign-in', 'educore-identity' ) ) as $a => $l ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin-inline-end:.5rem"><input type="hidden" name="action" value="educore_id_' . esc_attr( $a ) . '"><input type="hidden" name="provider" value="' . esc_attr( $p ) . '">';
				wp_nonce_field( 'educore_id_' . $a . '_' . $p );
				submit_button( $l, 'secondary', 'submit', false, Providers::configured( $p ) ? array() : array( 'disabled' => 'disabled' ) );
				echo '</form>';
			}
			echo '</p></div>';
		}
		echo '<h2>' . esc_html__( 'Recent identity events', 'educore-identity' ) . '</h2>' . wp_kses_post( self::events() ) . '</div>';
	}

	private static function events(): string {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT action, actor_id, object_id, context, created_at FROM " . Schema::table( 'audit_events' ) . " WHERE action LIKE 'identity.%' ORDER BY id DESC LIMIT 30", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery
		if ( ! $rows ) {
			return '<p>' . esc_html__( 'No identity events yet.', 'educore-identity' ) . '</p>';
		}
		$o = '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'When (UTC)', 'educore-identity' ) . '</th><th>' . esc_html__( 'Event', 'educore-identity' ) . '</th><th>' . esc_html__( 'Details', 'educore-identity' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$ctx = json_decode( (string) $r['context'], true );
			$o  .= '<tr><td>' . esc_html( $r['created_at'] ) . '</td><td>' . esc_html( $r['action'] ) . '</td><td><code>' . esc_html( is_array( $ctx ) ? wp_json_encode( $ctx ) : '' ) . '</code></td></tr>';
		}
		return $o . '</tbody></table>';
	}
}
