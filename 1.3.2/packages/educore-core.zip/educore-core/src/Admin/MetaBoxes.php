<?php
namespace EduCore\Core\Admin;

use EduCore\Core\Content;
use EduCore\Core\Curriculum;
use EduCore\Core\I18n;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

final class MetaBoxes {

	public static function register(): void {
		add_action( 'save_post', array( self::class, 'save' ), 10, 2 );
	}

	private static function field( string $label, string $html ): void {
		echo '<p><label><strong>' . esc_html( $label ) . '</strong><br>' . $html . '</label></p>'; // phpcs:ignore WordPress.Security.EscapeOutput -- $html built from escaped parts.
	}

	public static function course( \WP_Post $post ): void {
		wp_nonce_field( 'educore_meta_' . $post->ID, '_ec_meta_nonce' );
		$m = static fn( $k ) => get_post_meta( $post->ID, $k, true );
		$sel = static function ( string $name, array $opts, $cur ): string {
			$h = '<select name="' . esc_attr( $name ) . '">';
			foreach ( $opts as $v => $l ) {
				$h .= '<option value="' . esc_attr( $v ) . '"' . selected( (string) $cur, (string) $v, false ) . '>' . esc_html( $l ) . '</option>';
			}
			return $h . '</select>';
		};
		self::field( __( 'Difficulty', 'educore-core' ), $sel( '_ec_difficulty', array( 'beginner' => __( 'Beginner', 'educore-core' ), 'intermediate' => __( 'Intermediate', 'educore-core' ), 'advanced' => __( 'Advanced', 'educore-core' ) ), $m( '_ec_difficulty' ) ) );
		self::field( __( 'Grade / level label', 'educore-core' ), '<input class="regular-text" name="_ec_grade_level" value="' . esc_attr( $m( '_ec_grade_level' ) ) . '">' );
		self::field( __( 'Estimated duration (hours)', 'educore-core' ), '<input type="number" min="0" name="_ec_duration_hours" value="' . esc_attr( (string) (int) $m( '_ec_duration_hours' ) ) . '">' );
		self::field( __( 'Enrollment', 'educore-core' ), $sel( '_ec_enroll_mode', array( 'open' => __( 'Open — students can self-enroll', 'educore-core' ), 'closed' => __( 'Closed — staff enroll students', 'educore-core' ), 'paid' => __( 'Paid — via EduCore Commerce', 'educore-core' ) ), $m( '_ec_enroll_mode' ) ?: 'open' ) );
		self::field( __( 'Content language', 'educore-core' ), $sel( '_ec_lang', I18n::labels(), $m( '_ec_lang' ) ?: 'en' ) );
		self::field( __( 'Learning objectives (one per line)', 'educore-core' ), '<textarea class="large-text" rows="4" name="_ec_objectives">' . esc_textarea( $m( '_ec_objectives' ) ) . '</textarea>' );
		self::field( __( 'Prerequisites', 'educore-core' ), '<textarea class="large-text" rows="2" name="_ec_prerequisites">' . esc_textarea( $m( '_ec_prerequisites' ) ) . '</textarea>' );
		self::field( __( 'Assessment requirements', 'educore-core' ), '<textarea class="large-text" rows="2" name="_ec_assessment_req">' . esc_textarea( $m( '_ec_assessment_req' ) ) . '</textarea>' );
		if ( current_user_can( 'ec_manage_programmes' ) ) {
			$maps = Curriculum::mappings_for_course( $post->ID );
			$cur  = $maps[0] ?? array();
			$h    = '<select name="_ec_map_subject"><option value="0">—</option>';
			foreach ( Curriculum::programmes() as $prog ) {
				foreach ( Curriculum::periods( (int) $prog['id'] ) as $per ) {
					if ( 'year' === $per['type'] ) {
						continue;
					}
					foreach ( Curriculum::subjects( (int) $prog['id'] ) as $sub ) {
						$val = $prog['id'] . ':' . $per['id'] . ':' . $sub['id'];
						$h  .= '<option value="' . esc_attr( $val ) . '"' . selected( isset( $cur['subject_id'] ) && (int) $cur['period_id'] === (int) $per['id'] && (int) $cur['subject_id'] === (int) $sub['id'], true, false ) . '>' . esc_html( $prog['name'] . ' › ' . $per['label'] . ' › ' . $sub['name'] ) . '</option>';
					}
				}
			}
			self::field( __( 'Curriculum mapping', 'educore-core' ), $h . '</select>' );
		}
	}

	public static function unit( \WP_Post $post ): void {
		wp_nonce_field( 'educore_meta_' . $post->ID, '_ec_meta_nonce' );
		echo self::course_select( (int) get_post_meta( $post->ID, '_ec_course_id', true ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	}

	private static function course_select( int $current ): string {
		$ids = current_user_can( 'ec_manage_all_courses' )
			? get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'future' ), 'posts_per_page' => 500, 'fields' => 'ids' ) )
			: Staff::courses_of( get_current_user_id() );
		$h   = '<select name="_ec_course_id" required><option value="">' . esc_html__( 'Select a course', 'educore-core' ) . '</option>';
		foreach ( $ids as $id ) {
			$h .= '<option value="' . esc_attr( (string) $id ) . '"' . selected( $current, (int) $id, false ) . '>' . esc_html( get_the_title( $id ) ) . '</option>';
		}
		return $h . '</select>';
	}

	public static function lesson( \WP_Post $post ): void {
		wp_nonce_field( 'educore_meta_' . $post->ID, '_ec_meta_nonce' );
		$m       = static fn( $k ) => get_post_meta( $post->ID, $k, true );
		$current = (int) $m( '_ec_unit_id' );
		$courses = current_user_can( 'ec_manage_all_courses' ) ? get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'future' ), 'posts_per_page' => 500, 'fields' => 'ids' ) ) : Staff::courses_of( get_current_user_id() );
		$h       = '<select name="_ec_unit_id" required><option value="">' . esc_html__( 'Select a unit', 'educore-core' ) . '</option>';
		foreach ( $courses as $cid ) {
			$h .= '<optgroup label="' . esc_attr( get_the_title( $cid ) ) . '">';
			foreach ( Content::units( (int) $cid, array( 'publish', 'draft', 'pending', 'future' ) ) as $u ) {
				$h .= '<option value="' . esc_attr( (string) $u->ID ) . '"' . selected( $current, $u->ID, false ) . '>' . esc_html( $u->post_title ) . '</option>';
			}
			$h .= '</optgroup>';
		}
		self::field( __( 'Unit', 'educore-core' ), $h . '</select>' );
		self::field( __( 'Estimated time (minutes)', 'educore-core' ), '<input type="number" min="0" name="_ec_minutes" value="' . esc_attr( (string) (int) $m( '_ec_minutes' ) ) . '">' );
		$rules = apply_filters( 'educore/progress/rule_labels', array( 'manual' => __( 'Student marks complete', 'educore-core' ), 'view' => __( 'Opening the lesson completes it', 'educore-core' ), 'time' => __( 'After active reading time (seconds below)', 'educore-core' ) ) );
		$sel   = '<select name="_ec_completion_rule">';
		foreach ( $rules as $v => $l ) {
			$sel .= '<option value="' . esc_attr( $v ) . '"' . selected( $m( '_ec_completion_rule' ) ?: 'manual', $v, false ) . '>' . esc_html( $l ) . '</option>';
		}
		self::field( __( 'Completion rule', 'educore-core' ), $sel . '</select>' );
		self::field( __( 'Required active seconds (time rule)', 'educore-core' ), '<input type="number" min="0" name="_ec_completion_secs" value="' . esc_attr( (string) (int) $m( '_ec_completion_secs' ) ) . '">' );
		self::field( __( 'Content language', 'educore-core' ), '<select name="_ec_lang">' . implode( '', array_map( static fn( $c, $l ) => '<option value="' . esc_attr( $c ) . '"' . selected( $m( '_ec_lang' ) ?: 'en', $c, false ) . '>' . esc_html( $l ) . '</option>', array_keys( I18n::labels() ), I18n::labels() ) ) . '</select>' );
		self::field( __( 'Learning objectives (one per line)', 'educore-core' ), '<textarea class="large-text" rows="3" name="_ec_objectives">' . esc_textarea( $m( '_ec_objectives' ) ) . '</textarea>' );
		self::field( __( 'Lesson summary', 'educore-core' ), '<textarea class="large-text" rows="3" name="_ec_summary">' . esc_textarea( $m( '_ec_summary' ) ) . '</textarea>' );
		echo '<p class="description">' . esc_html__( 'Attach PDFs or other files to this lesson via “Add media” — they appear as downloadable resources.', 'educore-core' ) . '</p>';
		do_action( 'educore/admin/lesson_meta_box', $post );
	}

	public static function save( int $post_id, \WP_Post $post ): void {
		if ( ! Content::is_content_type( $post->post_type ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
			return;
		}
		if ( ! isset( $_POST['_ec_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_ec_meta_nonce'] ) ), 'educore_meta_' . $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		// Hierarchy changes: the target course must be editable by this user.
		if ( Content::UNIT === $post->post_type && isset( $_POST['_ec_course_id'] ) ) {
			$cid = absint( $_POST['_ec_course_id'] );
			if ( $cid && current_user_can( 'ec_edit_course', $cid ) ) {
				update_post_meta( $post_id, '_ec_course_id', $cid );
			}
		}
		if ( Content::LESSON === $post->post_type && isset( $_POST['_ec_unit_id'] ) ) {
			$unit = absint( $_POST['_ec_unit_id'] );
			if ( $unit && get_post_type( $unit ) === Content::UNIT && current_user_can( 'ec_edit_course', Content::course_of( $unit ) ) ) {
				update_post_meta( $post_id, '_ec_unit_id', $unit );
				update_post_meta( $post_id, '_ec_course_id', Content::course_of( $unit ) );
			}
		}
		foreach ( Content::meta_schema( $post->post_type ) as $key => $schema ) {
			if ( in_array( $key, array( '_ec_course_id', '_ec_unit_id' ), true ) || ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitised by schema callback.
			update_post_meta( $post_id, $key, call_user_func( $schema[2], $raw ) );
		}
		if ( Content::COURSE === $post->post_type && isset( $_POST['_ec_map_subject'] ) && current_user_can( 'ec_manage_programmes' ) ) {
			$parts = array_map( 'absint', explode( ':', sanitize_text_field( wp_unslash( $_POST['_ec_map_subject'] ) ) ) );
			Curriculum::unmap_course( $post_id );
			if ( 3 === count( $parts ) && $parts[0] ) {
				Curriculum::map_course( $post_id, $parts[0], $parts[1], $parts[2] );
			}
		}
		do_action( 'educore/admin/save_content_meta', $post_id, $post );
	}
}
