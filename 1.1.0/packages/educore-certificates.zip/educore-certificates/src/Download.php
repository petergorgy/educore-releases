<?php
namespace EduCore\Certificates;

use EduCore\Core\Audit;

defined( 'ABSPATH' ) || exit;

/** Authenticated PDF download: ?educore_certificate={uid}. Never served from a public URL. */
final class Download {

	public static function url( string $uid ): string {
		return add_query_arg( 'educore_certificate', $uid, home_url( '/' ) );
	}

	public static function can_download( int $user_id, array $c ): bool {
		if ( ! $user_id ) {
			return false;
		}
		if ( (int) $c['user_id'] === $user_id ) {
			return true;
		}
		return user_can( $user_id, 'ec_manage_certificates' ) || user_can( $user_id, 'ec_view_student', (int) $c['user_id'] );
	}

	/**
	 * Resolve a download for a user. Returns the file path or a WP_Error with an HTTP status.
	 *
	 * @return string|\WP_Error
	 */
	public static function resolve( string $uid, int $user_id ) {
		$c = Certificates::by_uid( $uid );
		if ( ! $c ) {
			return new \WP_Error( 'educore_not_found', __( 'Certificate not found.', 'educore-certificates' ), array( 'status' => 404 ) );
		}
		if ( ! $user_id ) {
			return new \WP_Error( 'educore_login', __( 'Please log in to download this certificate.', 'educore-certificates' ), array( 'status' => 401 ) );
		}
		if ( ! self::can_download( $user_id, $c ) ) {
			Audit::log( 'security.certificate_download_denied', 'certificate', (int) $c['id'] );
			return new \WP_Error( 'educore_forbidden', __( 'You are not allowed to download this certificate.', 'educore-certificates' ), array( 'status' => 403 ) );
		}
		if ( $c['revoked_at'] && (int) $c['user_id'] === $user_id && ! user_can( $user_id, 'ec_manage_certificates' ) ) {
			return new \WP_Error( 'educore_revoked', __( 'This certificate has been revoked.', 'educore-certificates' ), array( 'status' => 410 ) );
		}
		$path = $c['pdf_path'] ? Storage::path( $c['pdf_path'] ) : null;
		if ( ! $path || ! is_readable( $path ) ) {
			$path = Pdf::generate( (int) $c['id'] );
		}
		return $path;
	}

	public static function handle(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- authorisation is checked per user and object.
		if ( ! isset( $_GET['educore_certificate'] ) ) {
			return;
		}
		$uid  = sanitize_key( wp_unslash( $_GET['educore_certificate'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$res  = self::resolve( $uid, get_current_user_id() );
		if ( is_wp_error( $res ) ) {
			$status = (int) ( $res->get_error_data()['status'] ?? 403 );
			if ( 401 === $status ) {
				wp_safe_redirect( wp_login_url( self::url( $uid ) ) );
				exit;
			}
			wp_die( esc_html( $res->get_error_message() ), '', array( 'response' => $status ) );
		}
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: inline; filename="certificate-' . $uid . '.pdf"' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Length: ' . filesize( $res ) );
		readfile( $res ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}
}
