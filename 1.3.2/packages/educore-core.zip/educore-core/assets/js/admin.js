/* EduCore admin: accessible sortable lists (drag & drop + Alt+Arrow keys). */
(function () {
	'use strict';
	var cfg = window.EduCoreAdmin || {};
	var live = document.getElementById('ec-live');
	function announce(msg) { if (live) { live.textContent = msg; } }
	function save(listEl) {
		var ids = Array.prototype.map.call(listEl.children, function (li) { return parseInt(li.getAttribute('data-id'), 10); }).filter(Boolean);
		return fetch(cfg.rest + 'reorder', {
			method: 'POST', credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
			body: JSON.stringify({ ids: ids })
		}).then(function (r) { announce(r.ok ? cfg.saved : cfg.error); });
	}
	document.querySelectorAll('[data-ec-sortable]').forEach(function (list) {
		var dragging = null;
		Array.prototype.forEach.call(list.children, function (item) {
			if (!item.classList.contains('ec-sort-item')) { return; }
			item.addEventListener('dragstart', function (e) { if (e.target !== item) { return; } dragging = item; item.classList.add('is-dragging'); e.stopPropagation(); });
			item.addEventListener('dragend', function (e) { if (dragging !== item) { return; } item.classList.remove('is-dragging'); dragging = null; save(list); e.stopPropagation(); });
			item.addEventListener('dragover', function (e) {
				if (!dragging || dragging.parentNode !== list) { return; }
				e.preventDefault(); e.stopPropagation();
				var r = item.getBoundingClientRect();
				list.insertBefore(dragging, (e.clientY - r.top) > r.height / 2 ? item.nextSibling : item);
			});
			item.addEventListener('keydown', function (e) {
				if (!e.altKey || (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') || e.target !== item) { return; }
				e.preventDefault();
				if (e.key === 'ArrowUp' && item.previousElementSibling) { list.insertBefore(item, item.previousElementSibling); }
				else if (e.key === 'ArrowDown' && item.nextElementSibling) { list.insertBefore(item.nextElementSibling, item); }
				item.focus(); save(list);
			});
		});
	});
})();
