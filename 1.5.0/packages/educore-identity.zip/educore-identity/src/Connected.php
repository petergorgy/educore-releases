<?php
namespace EduCore\Identity;

defined( 'ABSPATH' ) || exit;

/** "Connected sign-in methods" in My EduCore → Preferences (or on My profile when the experience package is absent). */
final class Connected {
	public static function register(): void {
		add_filter( 'educore/experience/preferences_sections', array( self::class, 'section' ), 10, 2 );
		add_filter( 'the_content', array( self::class, 'profile_fallback' ), 20 );
	}

	public static function url(): string {
		if ( class_exists( '\EduCore\Experience\Plugin' ) ) {
			return \EduCore\Experience\Plugin::url( 'preferences' ) . '#ec-xp-s-signin';
		}
		return \EduCore\Core\Pages::url( 'profile' ) . '#ec-sso-connected';
	}

	public static function section( $sections, $uid ) {
		$sections = (array) $sections;
		$html     = self::html( (int) $uid );
		if ( '' !== $html ) {
			$sections['signin'] = array(
				'label' => __( 'Connected sign-in methods', 'educore-identity' ),
				'intro' => __( 'Use another account to sign in to EduCore. Your EduCore password always keeps working, so you can disconnect at any time.', 'educore-identity' ),
				'html'  => $html,
			);
		}
		return $sections;
	}

	public static function profile_fallback( $content ) {
		if ( class_exists( '\EduCore\Experience\Plugin' ) || ! is_user_logged_in() || ! is_page() || (int) get_queried_object_id() !== \EduCore\Core\Pages::id( 'profile' ) ) {
			return $content;
		}
		$h = self::html( get_current_user_id() );
		return '' === $h ? $content : $content . '<section class="ec-card" id="ec-sso-connected"><h2>' . esc_html__( 'Connected sign-in methods', 'educore-identity' ) . '</h2>' . $h . '</section>';
	}

	public static function html( int $uid ): string {
		$links = array();
		foreach ( Links::for_user( $uid ) as $l ) {
			$links[ $l['provider'] ] = $l;
		}
		$show = array_values( array_unique( array_merge( Providers::available_list(), array_keys( $links ) ) ) );
		if ( ! $show ) {
			return '';
		}
		wp_enqueue_style( 'educore-identity', EDUCORE_ID_URL . 'assets/css/identity.css', array(), EDUCORE_ID_VERSION );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
		$msg = sanitize_key( wp_unslash( $_GET['educore_sso_msg'] ?? '' ) );
		$m   = array(
			'linked'              => array( 'success', __( 'Connected. You can now use it to sign in.', 'educore-identity' ) ),
			'unlinked'            => array( 'success', __( 'Disconnected. Your EduCore password still works.', 'educore-identity' ) ),
			'password'            => array( 'error', __( 'Your current password was not correct, so nothing was changed.', 'educore-identity' ) ),
			'educore_id_taken'    => array( 'error', __( 'That account is already connected to a different EduCore account.', 'educore-identity' ) ),
			'educore_id_one_per_provider' => array( 'error', __( 'You already have a connection for this provider.', 'educore-identity' ) ),
			'throttled'           => array( 'error', __( 'Too many attempts. Please wait and try again.', 'educore-identity' ) ),
		);
		$o = isset( $m[ $msg ] ) ? '<div class="ec-notice ec-notice--' . esc_attr( $m[ $msg ][0] ) . '" role="' . ( 'error' === $m[ $msg ][0] ? 'alert' : 'status' ) . '">' . esc_html( $m[ $msg ][1] ) . '</div>' : '';
		$o .= '<ul class="ec-sso-connected">';
		foreach ( $show as $p ) {
			$l     = $links[ $p ] ?? null;
			$label = Providers::label( $p );
			$o    .= '<li>' . LoginUi::mark( $p ) . '<span class="ec-sso-connected__name">' . esc_html( $label ) . '</span>';
			if ( $l ) {
				/* translators: 1: e-mail or name at the provider, 2: date */
				$o .= '<span class="ec-sso-connected__meta">' . esc_html( sprintf( __( 'Connected as %1$s since %2$s', 'educore-identity' ), $l['email'] ?: ( $l['display_name'] ?: __( 'your account', 'educore-identity' ) ), mysql2date( get_option( 'date_format' ), $l['created_at'] ) ) ) . '</span>';
				$o .= self::form( 'educore_sso_unlink', $p, __( 'Disconnect', 'educore-identity' ), 'ec-btn' );
			} else {
				$o .= '<span class="ec-sso-connected__meta">' . esc_html__( 'Not connected', 'educore-identity' ) . '</span>';
				if ( Providers::available( $p ) ) {
					/* translators: %s: provider */
					$o .= self::form( 'educore_sso_link', $p, sprintf( __( 'Connect %s', 'educore-identity' ), $label ), 'ec-btn ec-btn--primary' );
				}
			}
			$o .= '</li>';
		}
		return $o . '</ul>';
	}

	private static function form( string $action, string $p, string $button, string $class ): string {
		$id = 'ec-sso-pw-' . $action . '-' . $p;
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="' . esc_attr( $action ) . '"><input type="hidden" name="provider" value="' . esc_attr( $p ) . '">'
			. wp_nonce_field( $action . '_' . $p, '_wpnonce', true, false )
			. '<label for="' . esc_attr( $id ) . '">' . esc_html__( 'Confirm with your EduCore password', 'educore-identity' ) . '<input type="password" id="' . esc_attr( $id ) . '" name="current_password" autocomplete="current-password" required></label>'
			. '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $button ) . '</button></form>';
	}
}
