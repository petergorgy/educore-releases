<?php
namespace EduCore\Assessments;

use EduCore\Core\Access;
use EduCore\Core\Content;
use EduCore\Core\Schema as CoreSchema;

defined( 'ABSPATH' ) || exit;

/**
 * Quick practice (D-05): per-question tries — MCQ 3, True/False 1, essay 1 submission (others 3).
 * The model answer and explanation are revealed when solved or when tries are exhausted.
 */
final class Practice {

	/** Published practice-eligible questions mapped to a lesson. */
	public static function questions_for_lesson( int $lesson_id, int $limit = 5 ): array {
		global $wpdb;
		$limit = (int) apply_filters( 'educore/assessments/quick_practice_count', $limit, $lesson_id );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Schema::t( 'questions' ) . " WHERE lesson_id=%d AND status='published' AND usage_scope IN ('any','practice') ORDER BY id LIMIT %d", $lesson_id, $limit ), ARRAY_A ) ?: array();
	}

	public static function state( int $user_id, int $question_id ): array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT tries, solved, revealed FROM ' . Schema::t( 'practice_tries' ) . ' WHERE user_id=%d AND question_id=%d', $user_id, $question_id ), ARRAY_A );
		return array( 'tries' => (int) ( $row['tries'] ?? 0 ), 'solved' => (bool) ( $row['solved'] ?? false ), 'revealed' => (bool) ( $row['revealed'] ?? false ) );
	}

	public static function can_practise( int $user_id, array $q ): bool {
		return 'published' === $q['status']
			&& in_array( $q['usage_scope'], array( 'any', 'practice' ), true )
			&& (int) $q['lesson_id'] > 0
			&& Access::can_view_lesson( $user_id, (int) $q['lesson_id'] );
	}

	/** Student-safe item, plus reveal data only when allowed. */
	public static function item( int $user_id, array $q ): array {
		$ver   = Questions::version( (int) $q['current_version_id'] );
		$state = self::state( $user_id, (int) $q['id'] );
		$limit = Types::practice_limit( $q['type'] );
		$item  = array(
			'id'         => (int) $q['id'],
			'type'       => $q['type'],
			'stem'       => $ver['stem'],
			'view'       => Types::public_view( $q['type'], $ver['payload'], null, 'p' . $q['id'] . '|' . $user_id ),
			'tries'      => $state['tries'],
			'tries_left' => max( 0, $limit - $state['tries'] ),
			'solved'     => $state['solved'],
		);
		if ( $state['solved'] || $state['revealed'] ) {
			$item['reveal'] = self::reveal_data( $q['type'], $ver );
		}
		return $item;
	}

	private static function reveal_data( string $type, array $ver ): array {
		$a = Types::to_authoring( $type, $ver['payload'], $ver['answer_key'] );
		return array(
			'correct'      => $a['correct'],
			'key'          => $ver['answer_key'],
			'model_answer' => (string) ( $ver['answer_key']['model_answer'] ?? '' ),
			'explanation'  => (string) $ver['explanation'],
		);
	}

	/** @return array|\WP_Error */
	public static function check( int $user_id, int $question_id, $answer ) {
		global $wpdb;
		$q = Questions::get( $question_id );
		if ( ! $q || ! self::can_practise( $user_id, $q ) ) {
			return new \WP_Error( 'educore_forbidden', __( 'This practice question is not available.', 'educore-assessments' ), array( 'status' => 403 ) );
		}
		$state = self::state( $user_id, $question_id );
		$limit = Types::practice_limit( $q['type'] );
		if ( $state['solved'] || $state['tries'] >= $limit ) {
			return new \WP_Error( 'educore_no_tries', __( 'No tries left for this question.', 'educore-assessments' ), array( 'status' => 409 ) );
		}
		$ver   = Questions::version( (int) $q['current_version_id'] );
		$clean = Types::sanitize_answer( $q['type'], $answer );
		$frac  = Types::grade( $q['type'], $ver['answer_key'], $clean );
		$ok    = null !== $frac && $frac >= 0.999;
		$tries = $state['tries'] + 1;
		$rev   = $ok || $tries >= $limit;
		$wpdb->query( $wpdb->prepare( 'INSERT INTO ' . Schema::t( 'practice_tries' ) . ' (user_id,question_id,tries,solved,revealed,last_answer,updated_at) VALUES (%d,%d,%d,%d,%d,%s,%s) ON DUPLICATE KEY UPDATE tries=VALUES(tries), solved=VALUES(solved), revealed=VALUES(revealed), last_answer=VALUES(last_answer), updated_at=VALUES(updated_at)', $user_id, $question_id, $tries, $ok ? 1 : 0, $rev ? 1 : 0, wp_json_encode( $clean ), CoreSchema::now() ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$out = array(
			'correct'    => null === $frac ? null : $ok,
			'partial'    => null !== $frac && $frac > 0 && ! $ok ? round( $frac, 2 ) : null,
			'manual'     => null === $frac,
			'tries_left' => max( 0, $limit - $tries ),
		);
		if ( $rev ) {
			$out['reveal'] = self::reveal_data( $q['type'], $ver );
		}
		do_action( 'educore/events/practice_answered', $user_id, $question_id, $ok );
		return $out;
	}

	public static function lesson_items( int $user_id, int $lesson_id ): array {
		if ( get_post_type( $lesson_id ) !== Content::LESSON || ! Access::can_view_lesson( $user_id, $lesson_id ) ) {
			return array();
		}
		return array_map( static fn( $q ) => self::item( $user_id, $q ), self::questions_for_lesson( $lesson_id ) );
	}
}
