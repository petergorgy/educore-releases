<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Course catalogue queries and public representations (no lesson bodies, no private data). */
final class Catalog {

	/** @return array{posts:\WP_Post[],total:int,pages:int} */
	public static function search( array $p ): array {
		$args = array(
			'post_type'      => Content::COURSE,
			'post_status'    => 'publish',
			'posts_per_page' => max( 1, min( 48, (int) ( $p['per_page'] ?? 12 ) ) ),
			'paged'          => max( 1, (int) ( $p['page'] ?? 1 ) ),
			'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
			'meta_query'     => array(), // phpcs:ignore WordPress.DB.SlowDBQuery
		);
		$ids = null;
		if ( ! empty( $p['q'] ) ) {
			$ids = Search::find( (string) $p['q'], Content::COURSE );
		}
		if ( ! empty( $p['subject'] ) || ! empty( $p['programme'] ) ) {
			$mapped = Curriculum::courses_matching( (int) ( $p['programme'] ?? 0 ), (int) ( $p['subject'] ?? 0 ) );
			$ids    = null === $ids ? $mapped : array_values( array_intersect( $ids, $mapped ) );
		}
		if ( ! empty( $p['instructor'] ) ) {
			$staffed = Staff::courses_of( (int) $p['instructor'] );
			$ids     = null === $ids ? $staffed : array_values( array_intersect( $ids, $staffed ) );
		}
		if ( null !== $ids ) {
			$args['post__in'] = $ids ?: array( 0 );
		}
		if ( ! empty( $p['difficulty'] ) ) {
			$args['meta_query'][] = array( 'key' => '_ec_difficulty', 'value' => sanitize_key( $p['difficulty'] ) );
		}
		if ( ! empty( $p['lang'] ) && isset( I18n::LANGS[ $p['lang'] ] ) ) {
			$args['meta_query'][] = I18n::DEFAULT === $p['lang']
				? array( 'relation' => 'OR', array( 'key' => '_ec_lang', 'value' => $p['lang'] ), array( 'key' => '_ec_lang', 'compare' => 'NOT EXISTS' ) )
				: array( 'key' => '_ec_lang', 'value' => $p['lang'] );
		}
		if ( ! empty( $p['price'] ) ) {
			$args['meta_query'][] = 'paid' === $p['price']
				? array( 'key' => '_ec_enroll_mode', 'value' => 'paid' )
				: array( 'relation' => 'OR', array( 'key' => '_ec_enroll_mode', 'value' => 'paid', 'compare' => '!=' ), array( 'key' => '_ec_enroll_mode', 'compare' => 'NOT EXISTS' ) );
		}
		$q = new \WP_Query( $args );
		return array( 'posts' => $q->posts, 'total' => (int) $q->found_posts, 'pages' => (int) $q->max_num_pages );
	}

	public static function card( \WP_Post $post ): array {
		$lessons = Content::lesson_ids( $post->ID );
		$maps    = Curriculum::mappings_for_course( $post->ID );
		$data    = array(
			'id'           => $post->ID,
			'title'        => get_the_title( $post ),
			'excerpt'      => wp_strip_all_tags( get_the_excerpt( $post ) ),
			'url'          => get_permalink( $post ),
			'image'        => get_the_post_thumbnail_url( $post, 'medium_large' ) ?: '',
			'difficulty'   => (string) get_post_meta( $post->ID, '_ec_difficulty', true ),
			'grade_level'  => (string) get_post_meta( $post->ID, '_ec_grade_level', true ),
			'hours'        => (int) get_post_meta( $post->ID, '_ec_duration_hours', true ),
			'lesson_count' => count( $lessons ),
			'subject'      => $maps[0]['subject'] ?? '',
			'programme'    => $maps[0]['programme'] ?? '',
			'enroll_mode'  => (string) ( get_post_meta( $post->ID, '_ec_enroll_mode', true ) ?: 'open' ),
			'price_label'  => '',
			'lang'         => I18n::sanitize_lang( get_post_meta( $post->ID, '_ec_lang', true ) ?: I18n::DEFAULT ),
			'instructors'  => self::instructors( $post->ID ),
		);
		/** Commerce adds price labels here. */
		return apply_filters( 'educore/catalog/card', $data, $post );
	}

	/** @return array<int,array{id:int,name:string}> */
	public static function instructors( int $course_id ): array {
		$out = array();
		foreach ( Staff::of_course( $course_id ) as $row ) {
			if ( in_array( $row['staff_role'], array( 'lead', 'instructor' ), true ) ) {
				$u = get_userdata( (int) $row['user_id'] );
				if ( $u ) {
					$out[] = array( 'id' => (int) $u->ID, 'name' => $u->display_name, 'bio' => wp_strip_all_tags( (string) get_user_meta( $u->ID, 'description', true ) ) );
				}
			}
		}
		return $out;
	}

	public static function details( int $course_id ): array {
		$post    = get_post( $course_id );
		$card    = self::card( $post );
		$outline = array();
		$minutes = 0;
		foreach ( Content::outline( $course_id ) as $row ) {
			$lessons = array();
			foreach ( $row['lessons'] as $l ) {
				$m        = (int) get_post_meta( $l->ID, '_ec_minutes', true );
				$minutes += $m;
				$lessons[] = array( 'id' => $l->ID, 'title' => get_the_title( $l ), 'minutes' => $m );
			}
			$outline[] = array( 'id' => $row['unit']->ID, 'title' => get_the_title( $row['unit'] ), 'lessons' => $lessons );
		}
		return array_merge(
			$card,
			array(
				'objectives'      => array_values( array_filter( array_map( 'trim', explode( "\n", (string) get_post_meta( $course_id, '_ec_objectives', true ) ) ) ) ),
				'prerequisites'   => (string) get_post_meta( $course_id, '_ec_prerequisites', true ),
				'assessment_reqs' => (string) get_post_meta( $course_id, '_ec_assessment_req', true ),
				'description'     => apply_filters( 'the_content', $post->post_content ),
				'outline'         => $outline,
				'total_minutes'   => $minutes,
			)
		);
	}
}
