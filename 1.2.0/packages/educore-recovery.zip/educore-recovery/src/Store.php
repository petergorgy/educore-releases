<?php
namespace EduCore\Recovery;

defined( 'ABSPATH' ) || exit;

/**
 * Backup storage. Prefers a directory OUTSIDE the web root (next to the WordPress folder); otherwise a
 * random-named folder under uploads with deny-all rules. Files are never served by URL — only streamed
 * to authorised administrators.
 */
final class Store {

	public static function dir(): string {
		$saved = (string) get_option( 'educore_rc_dir', '' );
		if ( $saved && is_dir( $saved ) && wp_is_writable( $saved ) ) {
			return $saved;
		}
		$suffix = substr( bin2hex( random_bytes( 8 ) ), 0, 12 );
		$candidates = array( dirname( untrailingslashit( ABSPATH ) ) . '/educore-backups-' . $suffix );
		$up         = wp_upload_dir( null, false );
		$candidates[] = trailingslashit( $up['basedir'] ) . 'educore-backups-' . $suffix;
		foreach ( $candidates as $dir ) {
			if ( ( is_dir( $dir ) || @wp_mkdir_p( $dir ) ) && wp_is_writable( $dir ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors -- open_basedir may forbid the parent.
				self::guard( $dir );
				update_option( 'educore_rc_dir', $dir, false );
				return $dir;
			}
		}
		return '';
	}

	public static function outside_webroot(): bool {
		$d = self::dir();
		return '' !== $d && 0 !== strpos( wp_normalize_path( $d ), wp_normalize_path( ABSPATH ) );
	}

	private static function guard( string $dir ): void {
		$files = array(
			'.htaccess'  => "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n",
			'index.php'  => "<?php\n// Silence is golden.\n",
			'web.config' => "<?xml version=\"1.0\"?><configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
		);
		foreach ( $files as $f => $c ) {
			if ( ! file_exists( "$dir/$f" ) ) {
				file_put_contents( "$dir/$f", $c ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
		}
	}

	/** Absolute path for a stored backup file name (rejects anything but our generated names). */
	public static function path( string $file ): ?string {
		if ( ! preg_match( '/^educore-[a-z]+-\d{8}T\d{6}-[a-f0-9]{4}\.zip(\.enc)?$/', $file ) ) {
			return null;
		}
		$p = self::dir() . '/' . $file;
		return is_file( $p ) ? $p : null;
	}

	public static function tmp( string $suffix ): string {
		return self::dir() . '/tmp-' . bin2hex( random_bytes( 6 ) ) . $suffix;
	}

	/* ---------- encryption (libsodium secretstream, chunked) ---------- */

	public static function encrypt( string $in, string $out, string $key ): void {
		[ $state, $header ] = sodium_crypto_secretstream_xchacha20poly1305_init_push( $key );
		$r = fopen( $in, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$w = fopen( $out, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $w, "ECBK1\n" . $header ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		while ( ! feof( $r ) ) {
			$chunk = (string) fread( $r, 1048576 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$tag   = feof( $r ) ? SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL : SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_MESSAGE;
			$enc   = sodium_crypto_secretstream_xchacha20poly1305_push( $state, $chunk, '', $tag );
			fwrite( $w, pack( 'N', strlen( $enc ) ) . $enc ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $w ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/** @return true|\WP_Error */
	public static function decrypt( string $in, string $out, string $key ) {
		$r = fopen( $in, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( "ECBK1\n" !== fread( $r, 6 ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return new \WP_Error( 'ec_rc_format', __( 'Not an EduCore encrypted backup.', 'educore-recovery' ) );
		}
		$state = sodium_crypto_secretstream_xchacha20poly1305_init_pull( (string) fread( $r, SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_HEADERBYTES ), $key ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$w     = fopen( $out, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$final = false;
		while ( ! feof( $r ) ) {
			$len = fread( $r, 4 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( 4 !== strlen( (string) $len ) ) {
				break;
			}
			$res = sodium_crypto_secretstream_xchacha20poly1305_pull( $state, (string) fread( $r, unpack( 'N', $len )[1] ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( false === $res ) {
				fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				fclose( $w ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				wp_delete_file( $out );
				return new \WP_Error( 'ec_rc_tamper', __( 'The encrypted backup is damaged or was modified (authentication failed).', 'educore-recovery' ) );
			}
			fwrite( $w, $res[0] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$final = SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL === $res[1];
		}
		fclose( $r ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $w ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $final ) {
			wp_delete_file( $out );
			return new \WP_Error( 'ec_rc_truncated', __( 'The encrypted backup is incomplete (truncated).', 'educore-recovery' ) );
		}
		return true;
	}
}
