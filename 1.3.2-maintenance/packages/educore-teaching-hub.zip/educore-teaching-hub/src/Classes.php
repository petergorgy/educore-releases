<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Audit;
use EduCore\Core\Content;
use EduCore\Core\Enrollment;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/** Classes, class staff, class membership (enrol/remove/transfer) and student groups. */
final class Classes {
	public const GROUP_TYPES = array( 'class', 'study', 'tutoring', 'remedial', 'advanced' );

	private static function t( string $n ): string {
		return Schema::table( $n );
	}

	/** @return int|\WP_Error */
	public static function create( array $in, int $actor ) {
		global $wpdb;
		$name = sanitize_text_field( (string) ( $in['name'] ?? '' ) );
		if ( '' === $name ) {
			return new \WP_Error( 'ec_th_name', __( 'A class name is required.', 'educore-teaching-hub' ) );
		}
		$course = absint( $in['course_id'] ?? 0 );
		if ( $course && ! Content::is_course( $course ) ) {
			return new \WP_Error( 'ec_th_course', __( 'Unknown course.', 'educore-teaching-hub' ) );
		}
		$now = Schema::now();
		$wpdb->insert(
			self::t( 'th_classes' ),
			array(
				'name'          => mb_substr( $name, 0, 190 ),
				'code'          => mb_substr( sanitize_text_field( (string) ( $in['code'] ?? '' ) ), 0, 40 ),
				'academic_year' => mb_substr( sanitize_text_field( (string) ( $in['academic_year'] ?? '' ) ), 0, 20 ),
				'programme_id'  => absint( $in['programme_id'] ?? 0 ),
				'period_id'     => absint( $in['period_id'] ?? 0 ),
				'subject_id'    => absint( $in['subject_id'] ?? 0 ),
				'course_id'     => $course,
				'schedule'      => sanitize_textarea_field( (string) ( $in['schedule'] ?? '' ) ),
				'status'        => 'active',
				'created_by'    => $actor,
				'created_at'    => $now,
				'updated_at'    => $now,
			)
		);
		$id = (int) $wpdb->insert_id;
		Audit::log( 'class.created', 'class', $id, array( 'name' => $name, 'course_id' => $course ) );
		return $id;
	}

	/** @var array<int,array<string,mixed>|null> per-request class cache */
	private static array $cache = array();

	public static function get( int $id ): ?array {
		global $wpdb;
		if ( ! array_key_exists( $id, self::$cache ) ) {
			self::$cache[ $id ] = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_classes' ) . ' WHERE id=%d', $id ), ARRAY_A ) ?: null;
		}
		return self::$cache[ $id ];
	}

	/** Load many classes in one query. @param int[] $ids */
	public static function prime( array $ids ): void {
		global $wpdb;
		$ids = array_values( array_diff( array_filter( array_map( 'intval', $ids ) ), array_keys( self::$cache ) ) );
		if ( ! $ids ) {
			return;
		}
		foreach ( $wpdb->get_results( 'SELECT * FROM ' . self::t( 'th_classes' ) . ' WHERE id IN (' . implode( ',', $ids ) . ')', ARRAY_A ) ?: array() as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL
			self::$cache[ (int) $r['id'] ] = $r;
		}
	}

	public static function flush(): void {
		self::$cache = array();
	}

	public static function set_status( int $id, string $status ): bool {
		global $wpdb;
		if ( ! in_array( $status, array( 'active', 'archived' ), true ) ) {
			return false;
		}
		$ok = (bool) $wpdb->update( self::t( 'th_classes' ), array( 'status' => $status, 'updated_at' => Schema::now() ), array( 'id' => $id ) );
		self::flush();
		Audit::log( 'class.status', 'class', $id, array( 'status' => $status ) );
		Caps::flush();
		return $ok;
	}

	public static function assign_staff( int $class_id, int $user_id, string $role = 'teacher' ): bool {
		global $wpdb;
		if ( ! in_array( $role, Caps::CLASS_ROLES, true ) || ! self::get( $class_id ) || ! get_userdata( $user_id ) ) {
			return false;
		}
		$ok = false !== $wpdb->query( $wpdb->prepare( 'INSERT INTO ' . self::t( 'th_class_staff' ) . ' (class_id,user_id,staff_role,created_at) VALUES (%d,%d,%s,%s) ON DUPLICATE KEY UPDATE staff_role=VALUES(staff_role)', $class_id, $user_id, $role, Schema::now() ) );
		Caps::flush();
		Audit::log( 'class.staff_assigned', 'class', $class_id, array( 'user_id' => $user_id, 'role' => $role ) );
		return $ok;
	}

	public static function remove_staff( int $class_id, int $user_id ): void {
		global $wpdb;
		$wpdb->delete( self::t( 'th_class_staff' ), array( 'class_id' => $class_id, 'user_id' => $user_id ) );
		Caps::flush();
		Audit::log( 'class.staff_removed', 'class', $class_id, array( 'user_id' => $user_id ) );
	}

	/** @return array<int,array{user_id:int,staff_role:string}> */
	public static function staff( int $class_id ): array {
		global $wpdb;
		return array_map(
			static fn( $r ) => array( 'user_id' => (int) $r['user_id'], 'staff_role' => $r['staff_role'] ),
			$wpdb->get_results( $wpdb->prepare( 'SELECT user_id, staff_role FROM ' . self::t( 'th_class_staff' ) . ' WHERE class_id=%d', $class_id ), ARRAY_A ) ?: array()
		);
	}

	/**
	 * Enrol a student in a class (and in the class course through core enrolment — no duplicate store).
	 *
	 * @return true|\WP_Error
	 */
	public static function add_member( int $class_id, int $student_id, int $actor ) {
		global $wpdb;
		$class = self::get( $class_id );
		$user  = get_userdata( $student_id );
		if ( ! $class || 'active' !== $class['status'] ) {
			return new \WP_Error( 'ec_th_class', __( 'This class is not active.', 'educore-teaching-hub' ) );
		}
		if ( ! $user || ! in_array( 'ec_student', (array) $user->roles, true ) ) {
			return new \WP_Error( 'ec_th_student', __( 'Only student accounts can join a class.', 'educore-teaching-hub' ) );
		}
		$wpdb->query( $wpdb->prepare( 'INSERT INTO ' . self::t( 'th_class_members' ) . " (class_id,student_id,status,joined_at) VALUES (%d,%d,'active',%s) ON DUPLICATE KEY UPDATE status='active', left_at=NULL", $class_id, $student_id, Schema::now() ) );
		if ( (int) $class['course_id'] && ! Enrollment::is_enrolled( $student_id, (int) $class['course_id'] ) ) {
			Enrollment::enroll( $student_id, (int) $class['course_id'], 'class' );
		}
		Caps::flush();
		Audit::log( 'class.member_added', 'class', $class_id, array( 'student_id' => $student_id, 'by' => $actor ) );
		do_action( 'educore/th/class_member_added', $class_id, $student_id );
		return true;
	}

	/** Remove from class (history kept: status=removed). Course enrolment is left to core/admin. */
	public static function remove_member( int $class_id, int $student_id, int $actor, string $status = 'removed' ): bool {
		global $wpdb;
		$ok = (bool) $wpdb->update( self::t( 'th_class_members' ), array( 'status' => $status, 'left_at' => Schema::now() ), array( 'class_id' => $class_id, 'student_id' => $student_id, 'status' => 'active' ) );
		Caps::flush();
		Audit::log( 'class.member_' . $status, 'class', $class_id, array( 'student_id' => $student_id, 'by' => $actor ) );
		return $ok;
	}

	/** @return true|\WP_Error */
	public static function transfer( int $from_class, int $to_class, int $student_id, int $actor ) {
		if ( $from_class === $to_class ) {
			return new \WP_Error( 'ec_th_same', __( 'Choose a different class.', 'educore-teaching-hub' ) );
		}
		if ( ! self::is_member( $from_class, $student_id ) ) {
			return new \WP_Error( 'ec_th_member', __( 'The student is not in the source class.', 'educore-teaching-hub' ) );
		}
		$res = self::add_member( $to_class, $student_id, $actor );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		self::remove_member( $from_class, $student_id, $actor, 'transferred' );
		Audit::log( 'class.member_transferred', 'class', $to_class, array( 'student_id' => $student_id, 'from' => $from_class, 'by' => $actor ) );
		return true;
	}

	public static function is_member( int $class_id, int $student_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM ' . self::t( 'th_class_members' ) . " WHERE class_id=%d AND student_id=%d AND status='active'", $class_id, $student_id ) );
	}

	/** @return int[] */
	public static function members( int $class_id ): array {
		global $wpdb;
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT m.student_id FROM ' . self::t( 'th_class_members' ) . ' m JOIN ' . $wpdb->users . " u ON u.ID=m.student_id WHERE m.class_id=%d AND m.status='active' ORDER BY u.display_name", $class_id ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** @return int[] active classes of a student */
	public static function of_student( int $student_id ): array {
		global $wpdb;
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT m.class_id FROM ' . self::t( 'th_class_members' ) . ' m JOIN ' . self::t( 'th_classes' ) . " c ON c.id=m.class_id WHERE m.student_id=%d AND m.status='active' AND c.status='active'", $student_id ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Count active students across classes in one query. @param int[] $class_ids @return array<int,int> */
	public static function member_counts( array $class_ids ): array {
		global $wpdb;
		$class_ids = array_filter( array_map( 'intval', $class_ids ) );
		if ( ! $class_ids ) {
			return array();
		}
		$rows = $wpdb->get_results( 'SELECT class_id, COUNT(*) n FROM ' . self::t( 'th_class_members' ) . " WHERE status='active' AND class_id IN (" . implode( ',', $class_ids ) . ') GROUP BY class_id', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$out  = array_fill_keys( $class_ids, 0 );
		foreach ( $rows as $r ) {
			$out[ (int) $r['class_id'] ] = (int) $r['n'];
		}
		return $out;
	}

	/* ---------- Groups ---------- */

	/** @return int|\WP_Error */
	public static function create_group( int $class_id, string $type, string $name, int $owner ) {
		global $wpdb;
		if ( ! in_array( $type, self::GROUP_TYPES, true ) || '' === trim( $name ) ) {
			return new \WP_Error( 'ec_th_group', __( 'Choose a group type and name.', 'educore-teaching-hub' ) );
		}
		$wpdb->insert( self::t( 'th_groups' ), array( 'class_id' => $class_id, 'group_type' => $type, 'name' => mb_substr( sanitize_text_field( $name ), 0, 190 ), 'owner_id' => $owner, 'created_at' => Schema::now() ) );
		$id = (int) $wpdb->insert_id;
		Audit::log( 'group.created', 'group', $id, array( 'class_id' => $class_id, 'type' => $type ) );
		return $id;
	}

	public static function group( int $id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'th_groups' ) . ' WHERE id=%d', $id ), ARRAY_A ) ?: null;
	}

	/** Can $user manage this group? Owner, class staff of its class, or manager. */
	public static function can_manage_group( int $user_id, int $group_id ): bool {
		$g = self::group( $group_id );
		if ( ! $g ) {
			return false;
		}
		if ( Caps::is_manager( $user_id ) || (int) $g['owner_id'] === $user_id ) {
			return true;
		}
		return (int) $g['class_id'] > 0 && null !== Caps::class_role( $user_id, (int) $g['class_id'] );
	}

	/** @return true|\WP_Error Students must belong to the group's class (scope rule). */
	public static function add_to_group( int $group_id, int $student_id ) {
		global $wpdb;
		$g = self::group( $group_id );
		if ( ! $g ) {
			return new \WP_Error( 'ec_th_group', __( 'Unknown group.', 'educore-teaching-hub' ) );
		}
		if ( (int) $g['class_id'] && ! self::is_member( (int) $g['class_id'], $student_id ) ) {
			return new \WP_Error( 'ec_th_scope', __( 'The student is not a member of this class.', 'educore-teaching-hub' ) );
		}
		// Groups outside a class (tutoring groups): only students the owner already teaches/tutors.
		if ( ! (int) $g['class_id'] && ! Caps::is_manager( (int) $g['owner_id'] ) && ! Caps::teaches_student( (int) $g['owner_id'], $student_id ) ) {
			return new \WP_Error( 'ec_th_scope', __( 'You can add only students you already teach or tutor.', 'educore-teaching-hub' ) );
		}
		$wpdb->query( $wpdb->prepare( 'INSERT IGNORE INTO ' . self::t( 'th_group_members' ) . ' (group_id,student_id) VALUES (%d,%d)', $group_id, $student_id ) );
		Audit::log( 'group.member_added', 'group', $group_id, array( 'student_id' => $student_id ) );
		return true;
	}

	public static function remove_from_group( int $group_id, int $student_id ): void {
		global $wpdb;
		$wpdb->delete( self::t( 'th_group_members' ), array( 'group_id' => $group_id, 'student_id' => $student_id ) );
		Audit::log( 'group.member_removed', 'group', $group_id, array( 'student_id' => $student_id ) );
	}

	/** @return array<int,array<string,mixed>> */
	public static function groups_of_class( int $class_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT g.*, (SELECT COUNT(*) FROM ' . self::t( 'th_group_members' ) . ' gm WHERE gm.group_id=g.id) members FROM ' . self::t( 'th_groups' ) . ' g WHERE g.class_id=%d ORDER BY g.name', $class_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** @return int[] */
	public static function group_members( int $group_id ): array {
		global $wpdb;
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT student_id FROM ' . self::t( 'th_group_members' ) . ' WHERE group_id=%d', $group_id ) ) );
	}

	/** @return int[] */
	public static function groups_of_student( int $student_id ): array {
		global $wpdb;
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT group_id FROM ' . self::t( 'th_group_members' ) . ' WHERE student_id=%d', $student_id ) ) );
	}
}
