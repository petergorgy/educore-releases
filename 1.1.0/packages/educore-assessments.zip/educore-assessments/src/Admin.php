<?php
namespace EduCore\Assessments;

use EduCore\Core\Content;
use EduCore\Core\Staff;

defined( 'ABSPATH' ) || exit;

/** Administration: question bank, assessments, grading. All actions: nonce + capability + course scope. */
final class Admin {

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 20 );
		add_action( 'admin_init', array( self::class, 'handle' ) );
		add_action( 'admin_post_educore_questions_export', array( self::class, 'export' ) );
	}

	public static function menu(): void {
		add_submenu_page( 'educore', __( 'Question bank', 'educore-assessments' ), __( 'Question bank', 'educore-assessments' ), 'ec_manage_question_bank', 'educore-questions', array( self::class, 'questions_page' ) );
		add_submenu_page( 'educore', __( 'Assessments', 'educore-assessments' ), __( 'Assessments', 'educore-assessments' ), 'ec_manage_assessments', 'educore-assess', array( self::class, 'assessments_page' ) );
		add_submenu_page( 'educore', __( 'Grading', 'educore-assessments' ), __( 'Grading', 'educore-assessments' ), 'ec_grade_submissions', 'educore-grading', array( self::class, 'grading_page' ) );
	}

	/** Courses the current user may edit. */
	private static function my_courses(): array {
		$ids = current_user_can( 'ec_manage_all_courses' )
			? get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending', 'future' ), 'posts_per_page' => 500, 'fields' => 'ids' ) )
			: array_values( array_filter( Staff::courses_of( get_current_user_id() ), static fn( $c ) => current_user_can( 'ec_edit_course', $c ) ) );
		return array_map( 'intval', $ids );
	}

	private static function course_param(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$c = isset( $_REQUEST['course'] ) ? absint( $_REQUEST['course'] ) : 0;
		$mine = self::my_courses();
		return in_array( $c, $mine, true ) ? $c : ( $mine[0] ?? 0 );
	}

	private static function course_picker( string $page, int $course ): void {
		echo '<form method="get" class="ec-course-pick"><input type="hidden" name="page" value="' . esc_attr( $page ) . '"><label>' . esc_html__( 'Course', 'educore-assessments' ) . ' <select name="course" onchange="this.form.submit()">';
		foreach ( self::my_courses() as $id ) {
			echo '<option value="' . esc_attr( (string) $id ) . '"' . selected( $course, $id, false ) . '>' . esc_html( get_the_title( $id ) ) . '</option>';
		}
		echo '</select></label> <noscript><button class="button">' . esc_html__( 'Open', 'educore-assessments' ) . '</button></noscript></form>';
	}

	private static function notice(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ec_msg'] ) ) {
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['ec_msg'] ) ) ) . '</p></div>';
		}
		// phpcs:enable
	}

	private static function lessons_select( int $course, int $current, string $name = 'lesson_id' ): string {
		$h = '<select name="' . esc_attr( $name ) . '"><option value="0">' . esc_html__( '(no lesson)', 'educore-assessments' ) . '</option>';
		foreach ( Content::outline( $course, array( 'publish', 'draft', 'pending', 'future' ) ) as $row ) {
			$h .= '<optgroup label="' . esc_attr( $row['unit']->post_title ) . '">';
			foreach ( $row['lessons'] as $l ) {
				$h .= '<option value="' . esc_attr( (string) $l->ID ) . '"' . selected( $current, $l->ID, false ) . '>' . esc_html( $l->post_title ) . '</option>';
			}
			$h .= '</optgroup>';
		}
		return $h . '</select>';
	}

	private static function select( string $name, array $options, string $cur ): string {
		$h = '<select name="' . esc_attr( $name ) . '">';
		foreach ( $options as $v => $l ) {
			$h .= '<option value="' . esc_attr( (string) $v ) . '"' . selected( $cur, (string) $v, false ) . '>' . esc_html( $l ) . '</option>';
		}
		return $h . '</select>';
	}

	/* ===================== Question bank ===================== */

	public static function questions_page(): void {
		$course = self::course_param();
		echo '<div class="wrap ec-admin"><h1>' . esc_html__( 'Question bank', 'educore-assessments' ) . '</h1>';
		self::notice();
		if ( ! $course ) {
			echo '<p>' . esc_html__( 'No courses are assigned to you.', 'educore-assessments' ) . '</p></div>';
			return;
		}
		self::course_picker( 'educore-questions', $course );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$action = isset( $_GET['ec_action'] ) ? sanitize_key( wp_unslash( $_GET['ec_action'] ) ) : '';
		if ( 'edit' === $action || 'new' === $action ) {
			$qid = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
			self::question_form( $course, $qid );
			echo '</div>';
			return;
		}
		$f = array(
			'course_id' => $course,
			'type'      => isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '',
			'status'    => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '',
			'lesson_id' => isset( $_GET['lesson'] ) ? absint( $_GET['lesson'] ) : 0,
			'search'    => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
			'page'      => isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1,
		);
		// phpcs:enable
		$base = admin_url( 'admin.php?page=educore-questions&course=' . $course );
		echo '<p><a class="button button-primary" href="' . esc_url( $base . '&ec_action=new' ) . '">' . esc_html__( 'Add question', 'educore-assessments' ) . '</a> ';
		$exp = wp_nonce_url( admin_url( 'admin-post.php?action=educore_questions_export&course=' . $course ), 'educore_q_export_' . $course );
		echo '<a class="button" href="' . esc_url( $exp . '&format=csv' ) . '">' . esc_html__( 'Export CSV', 'educore-assessments' ) . '</a> <a class="button" href="' . esc_url( $exp . '&format=json' ) . '">' . esc_html__( 'Export JSON', 'educore-assessments' ) . '</a></p>';
		echo '<form method="get"><input type="hidden" name="page" value="educore-questions"><input type="hidden" name="course" value="' . esc_attr( (string) $course ) . '">';
		echo self::select( 'type', array( '' => __( 'All types', 'educore-assessments' ) ) + Types::labels(), $f['type'] ) . ' '; // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::select( 'status', array( '' => __( 'All statuses', 'educore-assessments' ), 'draft' => __( 'Draft', 'educore-assessments' ), 'review' => __( 'In review', 'educore-assessments' ), 'published' => __( 'Published', 'educore-assessments' ), 'archived' => __( 'Archived', 'educore-assessments' ) ), $f['status'] ) . ' '; // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::lessons_select( $course, $f['lesson_id'], 'lesson' ) . ' <input type="search" name="s" value="' . esc_attr( $f['search'] ) . '"> <button class="button">' . esc_html__( 'Filter', 'educore-assessments' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		$res    = Questions::search( $f );
		$labels = Types::labels();
		echo '<table class="widefat striped"><thead><tr><th>ID</th><th>' . esc_html__( 'Question', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Type', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Lesson', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Status', 'educore-assessments' ) . '</th><th>v</th><th></th></tr></thead><tbody>';
		foreach ( $res['rows'] as $q ) {
			echo '<tr><td>' . esc_html( $q['id'] ) . '</td><td>' . esc_html( wp_trim_words( wp_strip_all_tags( $q['stem'] ), 16 ) ) . '</td><td>' . esc_html( $labels[ $q['type'] ] ?? $q['type'] ) . '</td><td>' . esc_html( $q['lesson_id'] ? get_the_title( (int) $q['lesson_id'] ) : '—' ) . '</td><td>' . esc_html( $q['status'] ) . '</td><td>' . esc_html( $q['version_no'] ) . '</td><td><a href="' . esc_url( $base . '&ec_action=edit&id=' . $q['id'] ) . '">' . esc_html__( 'Edit', 'educore-assessments' ) . '</a>';
			foreach ( array( 'review' => __( 'Submit for review', 'educore-assessments' ), 'published' => __( 'Publish', 'educore-assessments' ), 'archived' => __( 'Archive', 'educore-assessments' ) ) as $st => $label ) {
				if ( $st === $q['status'] || ( 'published' === $st && ! Questions::can_publish( get_current_user_id(), $course ) ) ) {
					continue;
				}
				echo ' | <form method="post" style="display:inline">';
				wp_nonce_field( 'educore_q_status_' . $q['id'], '_ecnonce' );
				echo '<input type="hidden" name="ec_assess_action" value="q_status"><input type="hidden" name="id" value="' . esc_attr( $q['id'] ) . '"><input type="hidden" name="status" value="' . esc_attr( $st ) . '"><button class="button-link">' . esc_html( $label ) . '</button></form>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		/* translators: %d: total */
		echo '<p>' . esc_html( sprintf( __( '%d questions', 'educore-assessments' ), $res['total'] ) ) . ( $res['total'] > $f['page'] * 50 ? ' <a href="' . esc_url( add_query_arg( 'paged', $f['page'] + 1 ) ) . '">' . esc_html__( 'Next page', 'educore-assessments' ) . '</a>' : '' ) . '</p>';

		echo '<h2>' . esc_html__( 'Bulk import', 'educore-assessments' ) . '</h2><form method="post" enctype="multipart/form-data">';
		wp_nonce_field( 'educore_q_import_' . $course, '_ecnonce' );
		echo '<input type="hidden" name="ec_assess_action" value="q_import"><input type="hidden" name="course" value="' . esc_attr( (string) $course ) . '">';
		echo self::select( 'format', array( 'csv' => 'CSV', 'json' => 'JSON' ), 'csv' ) . ' <input type="file" name="file" accept=".csv,.json,text/csv,application/json" required> <button class="button">' . esc_html__( 'Import', 'educore-assessments' ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<p class="description">' . esc_html( 'CSV columns: ' . implode( ', ', ImportExport::CSV_COLUMNS ) . '. ' ) . esc_html__( 'Use line breaks inside quoted cells for options and answers. Duplicates are skipped. Questions are imported as drafts (or "review" if you cannot publish).', 'educore-assessments' ) . '</p></form>';

		echo '<h2>' . esc_html__( 'Blueprint coverage (published questions vs target)', 'educore-assessments' ) . '</h2><table class="widefat striped"><thead><tr><th>' . esc_html__( 'Lesson', 'educore-assessments' ) . '</th><th>MCQ</th><th>' . esc_html__( 'True/False', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Essay', 'educore-assessments' ) . '</th></tr></thead><tbody>';
		foreach ( Questions::coverage( $course ) as $c ) {
			echo '<tr><td>' . esc_html( $c['title'] ) . '</td>';
			foreach ( array( 'mcq', 'truefalse', 'essay' ) as $fam ) {
				$v = $c[ $fam ] ?? array( 'have' => 0, 'target' => 0 );
				echo '<td>' . esc_html( $v['have'] . ' / ' . $v['target'] ) . '</td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table><p class="description">' . esc_html__( 'Targets are planning goals only; EduCore never generates question content.', 'educore-assessments' ) . '</p></div>';
	}

	private static function question_form( int $course, int $qid ): void {
		$q = $qid ? Questions::full( $qid ) : null;
		if ( $qid && ( ! $q || (int) $q['course_id'] !== $course ) ) {
			echo '<p>' . esc_html__( 'Question not found.', 'educore-assessments' ) . '</p>';
			return;
		}
		$v    = $q['version'] ?? array( 'stem' => '', 'payload' => array(), 'answer_key' => array(), 'explanation' => '', 'points' => 1, 'lang' => 'en' );
		$type = $q['type'] ?? 'single';
		$a    = $q ? Types::to_authoring( $type, $v['payload'], $v['answer_key'] ) : array( 'options' => '', 'correct' => '', 'model_answer' => '', 'code' => '', 'image_id' => '', 'language' => 'python', 'scoring' => 'all_or_nothing' );
		echo '<h2>' . esc_html( $q ? sprintf( /* translators: %d id */ __( 'Edit question #%d', 'educore-assessments' ), $qid ) : __( 'New question', 'educore-assessments' ) ) . '</h2>';
		if ( $q && ! empty( $v['used'] ) ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'This version has been used in attempts. Saving creates a new version; past attempts keep the original.', 'educore-assessments' ) . '</p></div>';
		}
		echo '<form method="post"><input type="hidden" name="ec_assess_action" value="q_save"><input type="hidden" name="id" value="' . esc_attr( (string) $qid ) . '"><input type="hidden" name="course" value="' . esc_attr( (string) $course ) . '">';
		wp_nonce_field( 'educore_q_save_' . $course, '_ecnonce' );
		$row = static function ( string $label, string $html, string $help = '' ) {
			echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>' . $html . ( $help ? '<p class="description">' . esc_html( $help ) . '</p>' : '' ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		};
		echo '<table class="form-table"><tbody>';
		$row( __( 'Type', 'educore-assessments' ), self::select( 'type', Types::labels(), $type ) );
		$row( __( 'Lesson', 'educore-assessments' ), self::lessons_select( $course, (int) ( $q['lesson_id'] ?? 0 ) ) );
		$row( __( 'Question text', 'educore-assessments' ), '<textarea name="stem" rows="4" class="large-text" required>' . esc_textarea( $v['stem'] ) . '</textarea>', __( 'For fill-in-the-blanks mark blanks as [[1]], [[2]] …', 'educore-assessments' ) );
		$row( __( 'Options / pairs / items', 'educore-assessments' ), '<textarea name="options" rows="5" class="large-text">' . esc_textarea( $a['options'] ) . '</textarea>', __( 'One per line. Matching: "left | right". Ordering: items in the correct order.', 'educore-assessments' ) );
		$row( __( 'Correct answer', 'educore-assessments' ), '<textarea name="correct" rows="3" class="large-text">' . esc_textarea( $a['correct'] ) . '</textarea>', __( 'Single/image: option number. Multiple: numbers, e.g. 1,3. True/False: true or false. Short answer: accepted answers, one per line. Blanks: "1: answer|alternative" per line. Code: expected output.', 'educore-assessments' ) );
		$row(
			__( 'Scoring (multiple answers / ordering)', 'educore-assessments' ),
			self::select( 'scoring', array( 'all_or_nothing' => __( 'All or nothing', 'educore-assessments' ), 'partial' => __( 'Partial credit', 'educore-assessments' ) ), ( $a['scoring'] ?? '' ) ?: 'all_or_nothing' ),
			__( 'Partial credit — multiple answers: (correct choices − wrong choices) ÷ number of correct choices, never below zero. Ordering: share of items in the correct position.', 'educore-assessments' )
		);
		$row( __( 'Code snippet', 'educore-assessments' ), '<textarea name="code" rows="5" class="large-text code" dir="ltr">' . esc_textarea( $a['code'] ) . '</textarea> ' . self::select( 'language', array( 'python' => 'Python', 'javascript' => 'JavaScript', 'pseudocode' => 'Pseudocode', 'c' => 'C', 'java' => 'Java' ), $a['language'] ?: 'python' ) );
		$row( __( 'Image (media ID)', 'educore-assessments' ), '<input type="number" min="0" name="image_id" value="' . esc_attr( (string) $a['image_id'] ) . '">' );
		$row( __( 'Model answer (essay)', 'educore-assessments' ), '<textarea name="model_answer" rows="4" class="large-text">' . esc_textarea( $a['model_answer'] ) . '</textarea>' );
		$rub = $qid ? Grading::rubric( $qid ) : array();
		$row( __( 'Rubric (essay)', 'educore-assessments' ), '<textarea name="rubric" rows="3" class="large-text">' . esc_textarea( implode( "\n", array_map( static fn( $c ) => $c['label'] . ' | ' . $c['points'], $rub ) ) ) . '</textarea>', __( 'One criterion per line: "criterion | points".', 'educore-assessments' ) );
		$row( __( 'Explanation', 'educore-assessments' ), '<textarea name="explanation" rows="3" class="large-text">' . esc_textarea( (string) $v['explanation'] ) . '</textarea>' );
		$row( __( 'Points', 'educore-assessments' ), '<input type="number" step="0.5" min="0" name="points" value="' . esc_attr( (string) $v['points'] ) . '">' );
		$row( __( 'Difficulty', 'educore-assessments' ), self::select( 'difficulty', array( 'easy' => __( 'Easy', 'educore-assessments' ), 'medium' => __( 'Medium', 'educore-assessments' ), 'hard' => __( 'Hard', 'educore-assessments' ) ), $q['difficulty'] ?? 'medium' ) );
		$row( __( 'Use in', 'educore-assessments' ), self::select( 'usage', array( 'any' => __( 'Practice and assessments', 'educore-assessments' ), 'practice' => __( 'Practice only', 'educore-assessments' ), 'assessment' => __( 'Assessments only (hidden from practice)', 'educore-assessments' ) ), $q['usage_scope'] ?? 'any' ) );
		$row( __( 'Language', 'educore-assessments' ), self::select( 'lang', \EduCore\Core\I18n::labels(), $v['lang'] ?? 'en' ) );
		$row( __( 'Tags', 'educore-assessments' ), '<input class="regular-text" name="tags" value="' . esc_attr( implode( ', ', $q['tags'] ?? array() ) ) . '">' );
		echo '</tbody></table><p><button class="button button-primary">' . esc_html__( 'Save question', 'educore-assessments' ) . '</button></p></form>';
		if ( $qid ) {
			echo '<h3>' . esc_html__( 'Version history', 'educore-assessments' ) . '</h3><ul>';
			foreach ( Questions::history( $qid ) as $h ) {
				echo '<li>v' . esc_html( $h['version_no'] ) . ' — ' . esc_html( $h['created_at'] ) . ( $h['used'] ? ' — ' . esc_html__( 'used in attempts (locked)', 'educore-assessments' ) : '' ) . '</li>';
			}
			echo '</ul>';
		}
	}

	/* ===================== Assessments ===================== */

	public static function assessments_page(): void {
		$course = self::course_param();
		echo '<div class="wrap ec-admin"><h1>' . esc_html__( 'Assessments', 'educore-assessments' ) . '</h1>';
		self::notice();
		if ( ! $course ) {
			echo '<p>' . esc_html__( 'No courses are assigned to you.', 'educore-assessments' ) . '</p></div>';
			return;
		}
		self::course_picker( 'educore-assess', $course );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$edit = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : -1;
		$base = admin_url( 'admin.php?page=educore-assess&course=' . $course );
		if ( $edit >= 0 ) {
			self::assessment_form( $course, $edit );
			echo '</div>';
			return;
		}
		echo '<p><a class="button button-primary" href="' . esc_url( $base . '&id=0' ) . '">' . esc_html__( 'New assessment', 'educore-assessments' ) . '</a></p>';
		echo '<form method="post" style="margin-bottom:1em">';
		wp_nonce_field( 'educore_a_template_' . $course, '_ecnonce' );
		echo '<input type="hidden" name="ec_assess_action" value="a_template"><input type="hidden" name="course" value="' . esc_attr( (string) $course ) . '">' . self::lessons_select( $course, 0 ) . ' <button class="button">' . esc_html__( 'Create "Chapter 1 Examination" template (15 MCQ + 15 T/F + 5 essay, 45 min, draft)', 'educore-assessments' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Title', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Kind', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Status', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Questions', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Results', 'educore-assessments' ) . '</th><th></th></tr></thead><tbody>';
		$stats = array();
		foreach ( ReadModel::assessment_stats( $course ) as $s ) {
			$stats[ (int) $s['id'] ] = $s;
		}
		foreach ( Assessments::for_course( $course, Assessments::STATUSES ) as $a ) {
			$n  = array_sum( array_map( 'intval', array_column( Assessments::pools( (int) $a['id'] ), 'draw_count' ) ) );
			$st = $stats[ (int) $a['id'] ] ?? array( 'attempts' => 0, 'mean_percent' => null );
			echo '<tr><td><a href="' . esc_url( $base . '&id=' . $a['id'] ) . '">' . esc_html( $a['title'] ) . '</a></td><td>' . esc_html( $a['kind'] ) . '</td><td>' . esc_html( $a['status'] ) . '</td><td>' . esc_html( (string) $n ) . '</td><td>' . esc_html( $st['attempts'] . ' / ' . ( null === $st['mean_percent'] ? '—' : round( (float) $st['mean_percent'], 1 ) . '%' ) ) . '</td><td>';
			if ( current_user_can( 'ec_release_grades' ) ) {
				echo '<form method="post" style="display:inline">';
				wp_nonce_field( 'educore_a_release_' . $a['id'], '_ecnonce' );
				echo '<input type="hidden" name="ec_assess_action" value="a_release"><input type="hidden" name="id" value="' . esc_attr( $a['id'] ) . '"><button class="button button-small">' . esc_html__( 'Release graded results', 'educore-assessments' ) . '</button></form>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	private static function assessment_form( int $course, int $id ): void {
		$a = $id ? Assessments::get( $id ) : null;
		if ( $id && ( ! $a || (int) $a['course_id'] !== $course ) ) {
			echo '<p>' . esc_html__( 'Assessment not found.', 'educore-assessments' ) . '</p>';
			return;
		}
		$s     = $a['settings'] ?? Assessments::defaults( 'quiz' );
		$pools = $a ? Assessments::pools( $id ) : array();
		echo '<form method="post"><input type="hidden" name="ec_assess_action" value="a_save"><input type="hidden" name="id" value="' . esc_attr( (string) $id ) . '"><input type="hidden" name="course" value="' . esc_attr( (string) $course ) . '">';
		wp_nonce_field( 'educore_a_save_' . $course, '_ecnonce' );
		echo '<table class="form-table"><tbody>';
		$r = static function ( string $l, string $h ) {
			echo '<tr><th scope="row">' . esc_html( $l ) . '</th><td>' . $h . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		};
		$r( __( 'Title', 'educore-assessments' ), '<input class="regular-text" name="title" required value="' . esc_attr( $a['title'] ?? '' ) . '">' );
		$r( __( 'Kind', 'educore-assessments' ), self::select( 'kind', array( 'quiz' => __( 'Quiz', 'educore-assessments' ), 'exam' => __( 'Examination', 'educore-assessments' ), 'practice' => __( 'Practice set', 'educore-assessments' ) ), $a['kind'] ?? 'quiz' ) );
		$statuses = array( 'draft' => __( 'Draft', 'educore-assessments' ), 'archived' => __( 'Archived', 'educore-assessments' ) );
		if ( current_user_can( 'ec_publish_courses' ) || Staff::has_role( get_current_user_id(), $course, array( 'lead' ) ) ) {
			$statuses = array( 'draft' => $statuses['draft'], 'published' => __( 'Published', 'educore-assessments' ), 'archived' => $statuses['archived'] );
		}
		$r( __( 'Status', 'educore-assessments' ), self::select( 'status', $statuses, $a['status'] ?? 'draft' ) );
		$r( __( 'Lesson', 'educore-assessments' ), self::lessons_select( $course, (int) ( $a['lesson_id'] ?? 0 ) ) );
		$r( __( 'Duration (minutes, 0 = untimed)', 'educore-assessments' ), '<input type="number" min="0" name="s[duration]" value="' . esc_attr( (string) $s['duration'] ) . '">' );
		$r( __( 'Attempts allowed (0 = unlimited)', 'educore-assessments' ), '<input type="number" min="0" name="s[attempts]" value="' . esc_attr( (string) $s['attempts'] ) . '">' );
		$r( __( 'Shuffle', 'educore-assessments' ), '<label><input type="checkbox" name="s[shuffle_questions]" value="1"' . checked( $s['shuffle_questions'], true, false ) . '> ' . esc_html__( 'questions', 'educore-assessments' ) . '</label> <label><input type="checkbox" name="s[shuffle_options]" value="1"' . checked( $s['shuffle_options'], true, false ) . '> ' . esc_html__( 'answer options', 'educore-assessments' ) . '</label>' );
		$r( __( 'Answer review', 'educore-assessments' ), self::select( 's[feedback]', array( 'after_release' => __( 'Show correct answers once results are released', 'educore-assessments' ), 'after_attempts_exhausted' => __( 'Show correct answers only after all attempts are used', 'educore-assessments' ), 'none' => __( 'Never show correct answers', 'educore-assessments' ) ), $s['feedback'] ) );
		$r( __( 'Result release', 'educore-assessments' ), self::select( 's[release]', array( 'auto' => __( 'Automatic when fully graded', 'educore-assessments' ), 'manual' => __( 'Manual by instructor', 'educore-assessments' ) ), $s['release'] ) );
		$r( __( 'Pass mark (%)', 'educore-assessments' ), '<input type="number" min="0" max="100" step="0.5" name="s[pass_mark]" value="' . esc_attr( (string) $s['pass_mark'] ) . '">' );
		$r( __( 'Total mark (0 = raw points)', 'educore-assessments' ), '<input type="number" min="0" step="0.5" name="s[total_mark]" value="' . esc_attr( (string) $s['total_mark'] ) . '">' );
		/* translators: %s: site timezone, e.g. Africa/Cairo */
		$r( sprintf( __( 'Opens / closes (site time: %s)', 'educore-assessments' ), Assessments::timezone_label() ), '<input type="datetime-local" name="s[opens_at]" value="' . esc_attr( Assessments::utc_to_local_input( (string) $s['opens_at'] ) ) . '"> → <input type="datetime-local" name="s[closes_at]" value="' . esc_attr( Assessments::utc_to_local_input( (string) $s['closes_at'] ) ) . '">' . ( $s['closes_at'] ? ' <span class="description">' . esc_html( Assessments::format_local( (string) $s['closes_at'] ) ) . '</span>' : '' ) );
		$r( __( 'Instructions', 'educore-assessments' ), '<textarea name="s[instructions]" rows="3" class="large-text">' . esc_textarea( $s['instructions'] ) . '</textarea>' );
		echo '</tbody></table><h2>' . esc_html__( 'Question pools', 'educore-assessments' ) . '</h2><p class="description">' . esc_html__( 'Each row draws N published questions matching the filters (or one fixed question ID). Points per question override the question\'s own points when above 0.', 'educore-assessments' ) . '</p>';
		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Type', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Lesson', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Tag', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Difficulty', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Fixed question ID', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Draw', 'educore-assessments' ) . '</th><th>' . esc_html__( 'Points each', 'educore-assessments' ) . '</th></tr></thead><tbody>';
		$rows = array_pad( $pools, count( $pools ) + 3, array() );
		foreach ( $rows as $i => $p ) {
			$n = 'pools[' . $i . ']';
			echo '<tr><td>' . self::select( $n . '[qtype]', array( '' => __( 'Any', 'educore-assessments' ) ) + Types::labels(), (string) ( $p['qtype'] ?? '' ) ) . '</td><td>' . self::lessons_select( $course, (int) ( $p['lesson_id'] ?? 0 ), $n . '[lesson_id]' ) . '</td><td><input size="10" name="' . esc_attr( $n ) . '[tag]" value="' . esc_attr( (string) ( $p['tag'] ?? '' ) ) . '"></td><td>' . self::select( $n . '[difficulty]', array( '' => __( 'Any', 'educore-assessments' ), 'easy' => 'easy', 'medium' => 'medium', 'hard' => 'hard' ), (string) ( $p['difficulty'] ?? '' ) ) . '</td><td><input type="number" min="0" style="width:7em" name="' . esc_attr( $n ) . '[question_id]" value="' . esc_attr( (string) ( $p['question_id'] ?? '' ) ) . '"></td><td><input type="number" min="0" style="width:5em" name="' . esc_attr( $n ) . '[draw_count]" value="' . esc_attr( (string) ( $p['draw_count'] ?? '' ) ) . '"></td><td><input type="number" min="0" step="0.5" style="width:6em" name="' . esc_attr( $n ) . '[points_each]" value="' . esc_attr( (string) ( $p['points_each'] ?? '' ) ) . '"></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</tbody></table><p><button class="button button-primary">' . esc_html__( 'Save assessment', 'educore-assessments' ) . '</button></p></form>';
		if ( $a ) {
			/* translators: %s: shortcode */
			echo '<p class="description">' . esc_html( sprintf( __( 'Embed anywhere with the "EduCore: Assessment" block or the shortcode %s. Learners also find it on the course page.', 'educore-assessments' ), '[educore_assessment assessmentId="' . $id . '"]' ) ) . '</p>';
		}
	}

	/* ===================== Grading ===================== */

	public static function grading_page(): void {
		echo '<div class="wrap ec-admin"><h1>' . esc_html__( 'Grading queue', 'educore-assessments' ) . '</h1>';
		self::notice();
		echo '<p class="description">' . esc_html__( 'Essay answers are graded by instructors. Automatic (AI) marking is not enabled; any future AI suggestion will always require instructor confirmation here.', 'educore-assessments' ) . '</p>';
		$queue = Grading::queue( get_current_user_id() );
		if ( ! $queue ) {
			echo '<p>' . esc_html__( 'Nothing to grade. Well done!', 'educore-assessments' ) . '</p></div>';
			return;
		}
		foreach ( $queue as $row ) {
			$ver    = Questions::version( (int) $row['question_version_id'] );
			$rubric = Grading::rubric( (int) $ver['question_id'] );
			$u      = get_userdata( (int) $row['user_id'] );
			echo '<div class="ec-panel"><h3>' . esc_html( $row['title'] ) . ' — ' . esc_html( $u ? $u->display_name : '#' . $row['user_id'] ) . ' <small>' . esc_html( $row['submitted_at'] ) . '</small></h3>';
			echo '<div><strong>' . esc_html__( 'Question', 'educore-assessments' ) . ':</strong> ' . wp_kses_post( $ver['stem'] ) . '</div>';
			echo '<div style="white-space:pre-wrap;background:#f6f7f7;padding:8px;margin:8px 0"><strong>' . esc_html__( 'Answer', 'educore-assessments' ) . ':</strong> ' . esc_html( (string) json_decode( (string) $row['answer'], true ) ) . '</div>';
			if ( ! empty( $ver['answer_key']['model_answer'] ) ) {
				echo '<details><summary>' . esc_html__( 'Model answer', 'educore-assessments' ) . '</summary>' . wp_kses_post( $ver['answer_key']['model_answer'] ) . '</details>';
			}
			echo '<form method="post"><input type="hidden" name="ec_assess_action" value="grade"><input type="hidden" name="response_id" value="' . esc_attr( $row['response_id'] ) . '">';
			wp_nonce_field( 'educore_grade_' . $row['response_id'], '_ecnonce' );
			foreach ( $rubric as $i => $c ) {
				echo '<label style="display:block">' . esc_html( $c['label'] ) . ' (' . esc_html( (string) $c['points'] ) . ') <input type="number" step="0.5" min="0" max="' . esc_attr( (string) $c['points'] ) . '" name="rubric[' . esc_attr( (string) $i ) . ']" data-ec-rubric></label>';
			}
			/* translators: %s: max */
			echo '<label>' . esc_html( sprintf( __( 'Score (max %s)', 'educore-assessments' ), $row['points'] ) ) . ' <input type="number" step="0.25" min="0" max="' . esc_attr( $row['points'] ) . '" name="score" required></label> ';
			echo '<label>' . esc_html__( 'Feedback', 'educore-assessments' ) . '<br><textarea name="feedback" rows="2" class="large-text"></textarea></label><button class="button button-primary">' . esc_html__( 'Save grade', 'educore-assessments' ) . '</button></form></div>';
		}
		echo '</div>';
	}

	/* ===================== POST handling ===================== */

	private static function back( string $msg, array $args = array() ): void {
		$ref = wp_get_referer() ?: admin_url( 'admin.php?page=educore-questions' );
		wp_safe_redirect( add_query_arg( array_merge( array( 'ec_msg' => rawurlencode( $msg ) ), $args ), remove_query_arg( array( 'ec_msg', 'ec_action', 'id' ), $ref ) ) );
		exit;
	}

	public static function handle(): void {
		if ( empty( $_POST['ec_assess_action'] ) ) {
			return;
		}
		$act   = sanitize_key( wp_unslash( $_POST['ec_assess_action'] ) );
		$nonce = isset( $_POST['_ecnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_ecnonce'] ) ) : '';
		$int   = static fn( $k ) => isset( $_POST[ $k ] ) ? absint( $_POST[ $k ] ) : 0;
		$txt   = static fn( $k ) => isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitised by the domain layer.
		switch ( $act ) {
			case 'q_save':
				$course = $int( 'course' );
				if ( ! wp_verify_nonce( $nonce, 'educore_q_save_' . $course ) || ! current_user_can( 'ec_manage_question_bank' ) || ! current_user_can( 'ec_edit_course', $course ) ) {
					wp_die( '', 403 );
				}
				$id   = $int( 'id' );
				$data = array();
				foreach ( array( 'type', 'stem', 'options', 'correct', 'code', 'language', 'image_id', 'model_answer', 'explanation', 'points', 'difficulty', 'usage', 'lang', 'tags', 'lesson_id', 'scoring' ) as $k ) {
					$data[ $k ] = $txt( $k );
				}
				if ( $id ) {
					$q = Questions::get( $id );
					if ( ! $q || (int) $q['course_id'] !== $course ) {
						wp_die( '', 403 );
					}
				}
				$data['course_id'] = $course;
				$built             = Types::from_authoring( $data );
				if ( is_wp_error( $built ) ) {
					self::back( $built->get_error_message(), array( 'ec_action' => $id ? 'edit' : 'new', 'id' => $id ) );
				}
				$data['payload'] = $built['payload'];
				$data['key']     = $built['key'];
				$res             = Questions::save( $data, $id );
				if ( is_wp_error( $res ) ) {
					self::back( $res->get_error_message() );
				}
				$rub = array();
				foreach ( preg_split( '/\r\n|\n/', (string) $txt( 'rubric' ) ) as $line ) {
					$parts = array_map( 'trim', explode( '|', $line ) );
					if ( '' !== $parts[0] ) {
						$rub[] = array( 'label' => $parts[0], 'points' => (float) ( $parts[1] ?? 0 ) );
					}
				}
				Grading::set_rubric( $res, $rub );
				$q   = Questions::get( $res );
				$dup = Questions::duplicates( $course, $q['dedupe_hash'], $res );
				/* translators: %s: ids */
				self::back( $dup ? sprintf( __( 'Saved. Warning: possible duplicate of question(s) %s.', 'educore-assessments' ), implode( ', ', $dup ) ) : __( 'Question saved.', 'educore-assessments' ) );
				break;
			case 'q_status':
				$id = $int( 'id' );
				$q  = Questions::get( $id );
				if ( ! $q || ! wp_verify_nonce( $nonce, 'educore_q_status_' . $id ) || ! current_user_can( 'ec_manage_question_bank' ) || ! current_user_can( 'ec_edit_course', (int) $q['course_id'] ) ) {
					wp_die( '', 403 );
				}
				$res = Questions::set_status( $id, sanitize_key( (string) $txt( 'status' ) ) );
				self::back( is_wp_error( $res ) ? $res->get_error_message() : __( 'Status updated.', 'educore-assessments' ) );
				break;
			case 'q_import':
				$course = $int( 'course' );
				if ( ! wp_verify_nonce( $nonce, 'educore_q_import_' . $course ) || ! current_user_can( 'ec_manage_question_bank' ) || ! current_user_can( 'ec_edit_course', $course ) ) {
					wp_die( '', 403 );
				}
				$file = $_FILES['file'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				if ( ! is_array( $file ) || ! empty( $file['error'] ) || (int) $file['size'] > 5 * MB_IN_BYTES || ! is_uploaded_file( $file['tmp_name'] ) ) {
					self::back( __( 'Upload failed (max 5 MB).', 'educore-assessments' ) );
				}
				$raw = (string) file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				$fmt = 'json' === $txt( 'format' ) ? 'json' : 'csv';
				$res = 'csv' === $fmt ? ImportExport::import_rows( $course, ImportExport::parse_csv( $raw ), false ) : ImportExport::import_rows( $course, (array) json_decode( $raw, true ), true );
				/* translators: 1: imported, 2: duplicates, 3: errors */
				$msg = sprintf( __( 'Imported %1$d, skipped %2$d duplicates, %3$d errors.', 'educore-assessments' ), $res['imported'], $res['duplicates'], count( $res['errors'] ) ) . ( $res['errors'] ? ' ' . implode( ' ', array_slice( $res['errors'], 0, 5 ) ) : '' );
				self::back( $msg );
				break;
			case 'a_save':
				$course = $int( 'course' );
				if ( ! wp_verify_nonce( $nonce, 'educore_a_save_' . $course ) || ! current_user_can( 'ec_manage_assessments' ) || ! current_user_can( 'ec_edit_course', $course ) ) {
					wp_die( '', 403 );
				}
				$id = $int( 'id' );
				if ( $id ) {
					$a = Assessments::get( $id );
					if ( ! $a || (int) $a['course_id'] !== $course ) {
						wp_die( '', 403 );
					}
				}
				$s      = (array) $txt( 's' );
				$status = sanitize_key( (string) $txt( 'status' ) );
				if ( 'published' === $status && ! current_user_can( 'ec_publish_courses' ) && ! Staff::has_role( get_current_user_id(), $course, array( 'lead' ) ) ) {
					$status = 'draft';
				}
				$settings = array(
					'duration'          => $s['duration'] ?? 0,
					'attempts'          => $s['attempts'] ?? 1,
					'shuffle_questions' => ! empty( $s['shuffle_questions'] ),
					'shuffle_options'   => ! empty( $s['shuffle_options'] ),
					'feedback'          => $s['feedback'] ?? 'after_release',
					'release'           => $s['release'] ?? 'auto',
					'pass_mark'         => $s['pass_mark'] ?? 50,
					'total_mark'        => $s['total_mark'] ?? 0,
					'opens_at'          => $s['opens_at'] ?? '',
					'closes_at'         => $s['closes_at'] ?? '',
					'instructions'      => $s['instructions'] ?? '',
				);
				$res = Assessments::save( array( 'course_id' => $course, 'title' => $txt( 'title' ), 'kind' => sanitize_key( (string) $txt( 'kind' ) ), 'status' => $status, 'lesson_id' => $int( 'lesson_id' ), 'settings' => $settings, 'pools' => (array) $txt( 'pools' ) ), $id );
				self::back( is_wp_error( $res ) ? $res->get_error_message() : __( 'Assessment saved.', 'educore-assessments' ), is_wp_error( $res ) ? array() : array( 'id' => $res ) );
				break;
			case 'a_template':
				$course = $int( 'course' );
				if ( ! wp_verify_nonce( $nonce, 'educore_a_template_' . $course ) || ! current_user_can( 'ec_manage_assessments' ) || ! current_user_can( 'ec_edit_course', $course ) ) {
					wp_die( '', 403 );
				}
				$res = Assessments::chapter_one_template( $course, $int( 'lesson_id' ) );
				self::back( is_wp_error( $res ) ? $res->get_error_message() : __( 'Chapter 1 Examination created as a draft.', 'educore-assessments' ) );
				break;
			case 'a_release':
				$id = $int( 'id' );
				$a  = Assessments::get( $id );
				if ( ! $a || ! wp_verify_nonce( $nonce, 'educore_a_release_' . $id ) || ! current_user_can( 'ec_release_grades' ) || ! current_user_can( 'ec_grade_course', (int) $a['course_id'] ) ) {
					wp_die( '', 403 );
				}
				/* translators: %d: count */
				self::back( sprintf( __( 'Released %d results.', 'educore-assessments' ), Grading::release_assessment( $id ) ) );
				break;
			case 'grade':
				$rid = $int( 'response_id' );
				if ( ! wp_verify_nonce( $nonce, 'educore_grade_' . $rid ) || ! current_user_can( 'ec_grade_submissions' ) || ! current_user_can( 'ec_grade_course', Grading::course_of_response( $rid ) ) ) {
					wp_die( '', 403 );
				}
				$rub = array_map( 'floatval', (array) ( $_POST['rubric'] ?? array() ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				$res = Grading::grade( $rid, (float) ( $_POST['score'] ?? 0 ), sanitize_textarea_field( (string) $txt( 'feedback' ) ), $rub ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				self::back( is_wp_error( $res ) ? $res->get_error_message() : __( 'Grade saved.', 'educore-assessments' ) );
				break;
		}
	}

	public static function export(): void {
		$course = isset( $_GET['course'] ) ? absint( $_GET['course'] ) : 0;
		check_admin_referer( 'educore_q_export_' . $course );
		if ( ! current_user_can( 'ec_manage_question_bank' ) || ! current_user_can( 'ec_edit_course', $course ) ) {
			wp_die( '', 403 );
		}
		$fmt = isset( $_GET['format'] ) && 'json' === $_GET['format'] ? 'json' : 'csv';
		nocache_headers();
		header( 'Content-Type: ' . ( 'json' === $fmt ? 'application/json' : 'text/csv' ) . '; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="educore-questions-' . $course . '.' . $fmt . '"' );
		echo 'json' === $fmt ? wp_json_encode( ImportExport::export_structured( $course ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) : ImportExport::export_csv( $course ); // phpcs:ignore WordPress.Security.EscapeOutput -- file download.
		exit;
	}
}
