<?php
/**
 * Plugin Name:       EduCore Experience
 * Plugin URI:        https://educore.gorgy.org
 * Description:       The EduCore Personal Experience Engine: preferences, onboarding, time-aware greetings built only from verified data, explained recommendations, study goals, resume-where-you-left-off and the adaptive daylight appearance (eight time-of-day themes).
 * Version:           1.0.2
 * Requires at least: 6.8
 * Requires PHP:      8.1
 * Requires Plugins:  educore-core
 * EduCore Requires Core: 1.2.0
 * Author:            GORGY.ORG
 * License:           GPL-2.0-or-later
 * Text Domain:       educore-experience
 * Domain Path:       /languages
 *
 * @package EduCore\Experience
 */

defined( 'ABSPATH' ) || exit;

define( 'EDUCORE_XP_VERSION', '1.0.2' );
define( 'EDUCORE_XP_FILE', __FILE__ );
define( 'EDUCORE_XP_DIR', plugin_dir_path( __FILE__ ) );
define( 'EDUCORE_XP_URL', plugin_dir_url( __FILE__ ) );

add_action(
	'educore/core/loaded',
	static function () {
		if ( ! \EduCore\Core\Plugin::requirement_met( 'EduCore Experience', '1.2.0' ) ) {
			return;
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Experience\\', EDUCORE_XP_DIR . 'src/' );
		\EduCore\Experience\Plugin::boot();
	}
);

register_activation_hook(
	__FILE__,
	static function () {
		if ( ! defined( 'EDUCORE_CORE_VERSION' ) || version_compare( EDUCORE_CORE_VERSION, '1.2.0', '<' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die( esc_html__( 'EduCore Experience needs EduCore Core 1.2.0 or newer.', 'educore-experience' ), '', array( 'back_link' => true ) );
		}
		\EduCore\Core\Autoloader::register( 'EduCore\\Experience\\', EDUCORE_XP_DIR . 'src/' );
		\EduCore\Experience\Plugin::install();
	}
);
