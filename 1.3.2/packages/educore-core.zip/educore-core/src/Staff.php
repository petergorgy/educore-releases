<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/** Course staff assignments (object-level permission source). */
final class Staff {
	public const ROLES = array( 'lead', 'instructor', 'grader' );

	/** @var array<string,mixed> */
	private static array $cache = array();

	public static function assign( int $course_id, int $user_id, string $role = 'instructor' ): bool {
		global $wpdb;
		if ( ! in_array( $role, self::ROLES, true ) || ! get_userdata( $user_id ) || ! Content::is_course( $course_id ) ) {
			return false;
		}
		$ok = false !== $wpdb->query(
			$wpdb->prepare(
				'INSERT INTO ' . Schema::table( 'course_staff' ) . ' (course_id,user_id,staff_role,created_at) VALUES (%d,%d,%s,%s) ON DUPLICATE KEY UPDATE staff_role = VALUES(staff_role)',
				$course_id,
				$user_id,
				$role,
				Schema::now()
			)
		);
		self::$cache = array();
		Audit::log( 'staff.assigned', 'course', $course_id, array( 'user_id' => $user_id, 'role' => $role ) );
		return $ok;
	}

	public static function remove( int $course_id, int $user_id ): void {
		global $wpdb;
		$wpdb->delete( Schema::table( 'course_staff' ), array( 'course_id' => $course_id, 'user_id' => $user_id ), array( '%d', '%d' ) );
		self::$cache = array();
		Audit::log( 'staff.removed', 'course', $course_id, array( 'user_id' => $user_id ) );
	}

	public static function role_of( int $user_id, int $course_id ): ?string {
		global $wpdb;
		$key = "r{$user_id}_{$course_id}";
		if ( ! array_key_exists( $key, self::$cache ) ) {
			self::$cache[ $key ] = $wpdb->get_var( $wpdb->prepare( 'SELECT staff_role FROM ' . Schema::table( 'course_staff' ) . ' WHERE user_id = %d AND course_id = %d', $user_id, $course_id ) );
		}
		return self::$cache[ $key ] ?: null;
	}

	/** @param string[] $roles */
	public static function has_role( int $user_id, int $course_id, array $roles ): bool {
		$role = self::role_of( $user_id, $course_id );
		return null !== $role && in_array( $role, $roles, true );
	}

	/** @return int[] */
	public static function courses_of( int $user_id ): array {
		global $wpdb;
		$key = "c{$user_id}";
		if ( ! array_key_exists( $key, self::$cache ) ) {
			self::$cache[ $key ] = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT course_id FROM ' . Schema::table( 'course_staff' ) . ' WHERE user_id = %d', $user_id ) ) );
		}
		return self::$cache[ $key ];
	}

	/** @return array<int,array{user_id:int,staff_role:string}> */
	public static function of_course( int $course_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT user_id, staff_role FROM ' . Schema::table( 'course_staff' ) . ' WHERE course_id = %d', $course_id ), ARRAY_A ) ?: array();
	}

	public static function flush(): void {
		self::$cache = array();
	}
}
