<?php
namespace EduCore\Core\Frontend;

defined( 'ABSPATH' ) || exit;

/** Dynamic (server-rendered) blocks. Each also works as a shortcode [educore_<name>]. */
final class Blocks {

	/** @return array<string,array{title:string,render:callable,attrs?:array}> */
	public static function definitions(): array {
		return apply_filters(
			'educore/blocks',
			array(
				'course-catalog'       => array( 'title' => __( 'EduCore: Course catalogue', 'educore-core' ), 'render' => array( Views::class, 'catalog' ), 'attrs' => array( 'perPage' => array( 'type' => 'number', 'default' => 12 ) ) ),
				'featured-courses'     => array( 'title' => __( 'EduCore: Featured courses', 'educore-core' ), 'render' => array( Views::class, 'featured' ), 'attrs' => array( 'count' => array( 'type' => 'number', 'default' => 3 ) ) ),
				'subject-list'         => array( 'title' => __( 'EduCore: Subjects', 'educore-core' ), 'render' => array( Views::class, 'subjects' ) ),
				'course-outline'       => array( 'title' => __( 'EduCore: Course details & syllabus', 'educore-core' ), 'render' => array( Views::class, 'course_block' ) ),
				'lesson-reader'        => array( 'title' => __( 'EduCore: Lesson reader', 'educore-core' ), 'render' => array( Views::class, 'lesson_block' ) ),
				'student-dashboard'    => array( 'title' => __( 'EduCore: Student dashboard', 'educore-core' ), 'render' => array( Views::class, 'dashboard' ) ),
				'learning-history'     => array( 'title' => __( 'EduCore: Learning history', 'educore-core' ), 'render' => array( Views::class, 'history' ) ),
				'profile'              => array( 'title' => __( 'EduCore: Profile', 'educore-core' ), 'render' => array( Views::class, 'profile' ) ),
				'register'             => array( 'title' => __( 'EduCore: Registration', 'educore-core' ), 'render' => array( Views::class, 'register' ) ),
				'guardian-consent'     => array( 'title' => __( 'EduCore: Guardian consent', 'educore-core' ), 'render' => array( Views::class, 'guardian' ) ),
				'instructor-workspace' => array( 'title' => __( 'EduCore: Instructor workspace', 'educore-core' ), 'render' => array( Views::class, 'workspace' ) ),
				'contact-form'         => array( 'title' => __( 'EduCore: Contact form', 'educore-core' ), 'render' => array( Views::class, 'contact' ) ),
				'language-switcher'    => array( 'title' => __( 'EduCore: Language switcher', 'educore-core' ), 'render' => array( Views::class, 'language_switcher' ) ),
				'leaderboard'          => array( 'title' => __( 'EduCore: Leaderboard (opt-in adults only)', 'educore-core' ), 'render' => array( Views::class, 'leaderboard' ), 'attrs' => array( 'courseId' => array( 'type' => 'number', 'default' => 0 ) ) ),
				'user-menu'            => array( 'title' => __( 'EduCore: Account menu', 'educore-core' ), 'render' => array( Views::class, 'user_menu' ) ),
			)
		);
	}

	public static function register(): void {
		add_action( 'init', array( self::class, 'register_blocks' ) );
		add_action( 'init', array( Patterns::class, 'register' ) );
	}

	public static function register_blocks(): void {
		foreach ( self::definitions() as $name => $def ) {
			$render = $def['render'];
			register_block_type(
				'educore/' . $name,
				array(
					'api_version'     => 3,
					'title'           => $def['title'],
					'category'        => 'widgets',
					'attributes'      => $def['attrs'] ?? array(),
					'render_callback' => static fn( $attrs = array() ) => (string) call_user_func( $render, (array) $attrs ),
					'supports'        => array( 'html' => false, 'align' => array( 'wide', 'full' ) ),
				)
			);
			add_shortcode( 'educore_' . str_replace( '-', '_', $name ), static fn( $attrs = array() ) => (string) call_user_func( $render, (array) $attrs ) );
		}
	}

	/** @return array<int,array{name:string,title:string}> */
	public static function editor_list(): array {
		$out = array();
		foreach ( self::definitions() as $name => $def ) {
			$out[] = array( 'name' => 'educore/' . $name, 'title' => $def['title'] );
		}
		return $out;
	}
}
