<?php
namespace EduCore\TeachingHub;

use EduCore\Core\Access;
use EduCore\Core\Content;
use EduCore\Core\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * /teaching-hub/ — frontend workspace for teachers, instructors and tutors. Server-rendered (works without
 * JavaScript; hub.js adds progressive enhancements). Navigation adapts to the user's responsibilities.
 * All writes are POST + nonce + capability/object checks, followed by redirect (PRG).
 */
final class Portal {

	public static function register(): void {
		add_action( 'template_redirect', array( self::class, 'handle' ), 9 );
		add_filter( 'login_redirect', array( self::class, 'login_redirect' ), 21, 3 ); // Superseded by the core Router (priority 99) when present.
		add_filter( 'educore/auth/destinations', array( self::class, 'destination' ), 10, 2 );
	}

	/** Teachers/tutors without back-office editing rights land in the Teaching Hub, not wp-admin/profile.php. */
	public static function login_redirect( $redirect_to, $requested, $user ) {
		if ( ! $user instanceof \WP_User || ! $user->exists() || user_can( $user, 'edit_posts' ) || user_can( $user, 'manage_options' ) ) {
			return $redirect_to;
		}
		if ( ! user_can( $user, 'ec_teach' ) && ! user_can( $user, 'ec_tutor_sessions' ) ) {
			return $redirect_to;
		}
		return ( '' === (string) $requested || 0 === strpos( (string) $redirect_to, (string) admin_url() ) ) ? self::url() : $redirect_to;
	}

	public static function url( string $view = '', array $args = array() ): string {
		return add_query_arg( array_merge( $view ? array( 'v' => $view ) : array(), $args ), Pages::url( 'teaching-hub' ) );
	}

	/** Registers the Teaching Hub as a sign-in destination for teachers, tutors and graders (core Router). */
	public static function destination( array $d, \WP_User $user ): array {
		if ( self::can_enter( (int) $user->ID ) && 'publish' === get_post_status( Pages::id( 'teaching-hub' ) ) ) {
			$d['teaching-hub'] = array( 'label' => __( 'Teaching Hub', 'educore-teaching-hub' ), 'url' => self::url(), 'priority' => 30 );
		}
		return $d;
	}

	private static function can_enter( int $uid ): bool {
		return $uid > 0 && ( user_can( $uid, 'ec_teach' ) || user_can( $uid, 'ec_tutor_sessions' ) || user_can( $uid, 'ec_manage_teaching' ) || user_can( $uid, 'ec_grade_submissions' ) );
	}

	/** @return array<string,string> view => label, filtered by responsibilities */
	private static function nav( int $uid ): array {
		$r   = Caps::responsibilities( $uid );
		$t   = in_array( 'teacher', $r, true ) || in_array( 'manager', $r, true );
		$g   = $t || user_can( $uid, 'ec_grade_submissions' );
		$tut = in_array( 'tutor', $r, true ) || in_array( 'manager', $r, true );
		$nav = array( 'overview' => __( 'Overview', 'educore-teaching-hub' ) );
		if ( in_array( 'instructor', $r, true ) ) {
			$nav['courses'] = __( 'My courses', 'educore-teaching-hub' );
		}
		if ( $t ) {
			$nav += array( 'classes' => __( 'My classes', 'educore-teaching-hub' ), 'students' => __( 'Students', 'educore-teaching-hub' ), 'planner' => __( 'Lesson planner', 'educore-teaching-hub' ), 'assignments' => __( 'Assignments', 'educore-teaching-hub' ) );
		}
		if ( $g ) {
			$nav['grading'] = __( 'Grading center', 'educore-teaching-hub' );
		}
		$nav['calendar'] = __( 'Teaching calendar', 'educore-teaching-hub' );
		if ( $tut ) {
			$nav['tutoring'] = __( 'Tutoring', 'educore-teaching-hub' );
		}
		if ( $t ) {
			$nav['attendance'] = __( 'Attendance', 'educore-teaching-hub' );
		}
		$nav['analytics'] = __( 'Analytics', 'educore-teaching-hub' );
		$nav['messages']  = __( 'Communications', 'educore-teaching-hub' );
		return $nav;
	}

	public static function render(): string {
		$uid = get_current_user_id();
		Access::no_cache_headers();
		if ( ! $uid ) {
			return '<div class="ec-card ec-gate"><p>' . esc_html__( 'Log in to open the Teaching Hub.', 'educore-teaching-hub' ) . '</p><p><a class="ec-btn ec-btn--primary" href="' . esc_url( wp_login_url( self::url() ) ) . '">' . esc_html__( 'Log in', 'educore-teaching-hub' ) . '</a></p></div>';
		}
		if ( ! self::can_enter( $uid ) ) {
			return '<div class="ec-notice ec-notice--info">' . esc_html__( 'The Teaching Hub is for teachers, instructors and tutors. Your learning dashboard is under “My learning”.', 'educore-teaching-hub' ) . '</div>';
		}
		wp_enqueue_style( 'educore-th' );
		wp_enqueue_script( 'educore-th' );
		$nav  = self::nav( $uid );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$view = isset( $_GET['v'] ) ? sanitize_key( wp_unslash( $_GET['v'] ) ) : 'overview';
		$sub  = array( 'class' => 'classes', 'student' => 'students', 'assignment' => 'assignments', 'session' => 'tutoring', 'thread' => 'messages', 'profile' => 'tutoring' );
		$top  = $sub[ $view ] ?? $view;
		if ( ! isset( $nav[ $top ] ) ) {
			$view = 'overview';
			$top  = 'overview';
		}
		$att  = get_user_meta( $uid, 'educore_th_attention', true );
		$out  = '<div class="ec-th" data-ec-th><nav class="ec-th-nav" aria-label="' . esc_attr__( 'Teaching Hub', 'educore-teaching-hub' ) . '"><button type="button" class="ec-th-nav__toggle" aria-expanded="false" data-ec-th-nav>' . esc_html__( 'Menu', 'educore-teaching-hub' ) . '</button><ul>';
		foreach ( $nav as $k => $label ) {
			$badge = 'overview' === $k && is_array( $att ) && $att['high'] ? ' <span class="ec-th-badge" title="' . esc_attr__( 'Students needing attention', 'educore-teaching-hub' ) . '">' . esc_html( number_format_i18n( (int) $att['high'] ) ) . '</span>' : '';
			if ( 'grading' === $k ) {
				$n     = count( self::grading_items( $uid, 500 ) );
				$badge = $n ? ' <span class="ec-th-badge">' . esc_html( number_format_i18n( $n ) ) . '</span>' : '';
			}
			$out .= '<li><a href="' . esc_url( self::url( $k ) ) . '"' . ( $k === $top ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . $badge . '</a></li>';
		}
		$out .= '</ul></nav><main class="ec-th-main" id="ec-th-main">' . self::flash();
		$method = 'view_' . $view;
		$out   .= method_exists( self::class, $method ) ? self::$method( $uid ) : self::view_overview( $uid );
		return $out . '</main></div>';
	}

	/* ---------- helpers ---------- */

	private static function flash(): string {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$ok  = isset( $_GET['th_ok'] ) ? sanitize_key( wp_unslash( $_GET['th_ok'] ) ) : '';
		$err = isset( $_GET['th_err'] ) ? sanitize_text_field( wp_unslash( $_GET['th_err'] ) ) : '';
		// phpcs:enable
		$out = $ok ? '<div class="ec-notice ec-notice--success ec-th-toast" role="status">' . esc_html__( 'Saved.', 'educore-teaching-hub' ) . '</div>' : '';
		return $out . ( $err ? '<div class="ec-notice ec-notice--error" role="alert">' . esc_html( $err ) . '</div>' : '' );
	}

	private static function h( string $title, string $actions = '' ): string {
		return '<header class="ec-th-head"><h2>' . esc_html( $title ) . '</h2>' . $actions . '</header>';
	}

	private static function form( string $action, array $hidden, string $inner, string $class = '', bool $files = false ): string {
		return Student::form( $action, $hidden, $inner, $class, $files );
	}

	private static function field( string $label, string $control ): string {
		return '<p class="ec-th-field"><label>' . esc_html( $label ) . ' ' . $control . '</label></p>';
	}

	/** Load user rows + meta for many ids in two queries (avoids one lookup per name). @param int[] $ids */
	public static function prime_users( array $ids ): void {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		if ( $ids ) {
			cache_users( $ids );
		}
	}

	private static function name( int $uid ): string {
		$u = get_userdata( $uid );
		return $u ? $u->display_name : '#' . $uid;
	}

	private static function class_options( int $uid, int $selected = 0, bool $any = false ): string {
		$out = $any ? '<option value="0">' . esc_html__( 'All my classes', 'educore-teaching-hub' ) . '</option>' : '';
		foreach ( Caps::classes_of( $uid ) as $cid ) {
			$c    = Classes::get( $cid );
			$out .= '<option value="' . esc_attr( (string) $cid ) . '"' . selected( $selected, $cid, false ) . '>' . esc_html( $c['name'] ) . '</option>';
		}
		return $out;
	}

	private static function range_filter( string $view, array $r, int $class = 0, int $uid = 0 ): string {
		$out = '<form method="get" class="ec-th-filters"><input type="hidden" name="v" value="' . esc_attr( $view ) . '"><label>' . esc_html__( 'From', 'educore-teaching-hub' ) . ' <input type="date" name="from" value="' . esc_attr( $r['from'] ) . '"></label> <label>' . esc_html__( 'To', 'educore-teaching-hub' ) . ' <input type="date" name="to" value="' . esc_attr( $r['to'] ) . '"></label>';
		if ( $uid && Caps::classes_of( $uid ) ) {
			$out .= ' <label>' . esc_html__( 'Class', 'educore-teaching-hub' ) . ' <select name="class">' . self::class_options( $uid, $class, true ) . '</select></label>';
		}
		return $out . ' <button class="ec-btn">' . esc_html__( 'Apply', 'educore-teaching-hub' ) . '</button></form>';
	}

	private static function req_range(): array {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		return Analytics::range( isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '', isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '' );
		// phpcs:enable
	}

	private static function req_int( string $k ): int {
		return isset( $_GET[ $k ] ) ? absint( $_GET[ $k ] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	private static function scoped_classes( int $uid ): array {
		$cls = Caps::classes_of( $uid );
		$one = self::req_int( 'class' );
		return $one ? ( in_array( $one, $cls, true ) ? array( $one ) : array() ) : $cls;
	}

	private static function stat( string $label, $value, string $hint = '', string $url = '' ): string {
		$v = null === $value || '' === $value ? '—' : ( is_numeric( $value ) ? number_format_i18n( (float) $value, is_float( $value ) ? 1 : 0 ) : (string) $value );
		$t = '<span class="ec-th-tile__v">' . esc_html( $v ) . '</span><span class="ec-th-tile__l">' . esc_html( $label ) . '</span>' . ( $hint ? '<span class="ec-th-tile__h">' . esc_html( $hint ) . '</span>' : '' );
		return '<li class="ec-th-tile">' . ( $url ? '<a href="' . esc_url( $url ) . '">' . $t . '</a>' : $t ) . '</li>';
	}

	private static function bar( int $pct ): string {
		$pct = max( 0, min( 100, $pct ) );
		return '<span class="ec-th-bar" role="img" aria-label="' . esc_attr( $pct . '%' ) . '"><span style="inline-size:' . esc_attr( (string) $pct ) . '%"></span></span>';
	}

	/* ---------- Overview ---------- */

	private static function view_overview( int $uid ): string {
		$r       = self::req_range();
		$resp    = Caps::responsibilities( $uid );
		$teaches = in_array( 'teacher', $resp, true ) || in_array( 'manager', $resp, true );
		$out     = self::h( __( 'Overview', 'educore-teaching-hub' ) ) . self::range_filter( 'overview', $r, self::req_int( 'class' ), $uid );
		if ( $teaches ) {
			$out .= self::teaching_widgets( $uid, $r );
		}
		if ( user_can( $uid, 'ec_tutor_sessions' ) ) {
			$t    = Analytics::tutoring( $uid, $r );
			$req  = count( array_filter( Tutoring::for_tutor( $uid ), static fn( $s ) => 'requested' === $s['status'] ) );
			$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Tutoring', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-tiles">'
				. self::stat( __( 'Requests to answer', 'educore-teaching-hub' ), $req, '', self::url( 'tutoring' ) )
				. self::stat( __( 'Upcoming sessions', 'educore-teaching-hub' ), count( Tutoring::for_tutor( $uid ) ), '', self::url( 'tutoring' ) )
				. self::stat( __( 'Sessions completed', 'educore-teaching-hub' ), $t['sessions_completed'] )
				. self::stat( __( 'Teaching hours', 'educore-teaching-hub' ), $t['teaching_hours'] )
				. self::stat( __( 'Active learners', 'educore-teaching-hub' ), $t['active_learners'] )
				. '</ul></section>';
		}
		if ( ! $teaches && ! user_can( $uid, 'ec_tutor_sessions' ) ) {
			$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Grading', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-tiles">' . self::stat( __( 'Pending grading', 'educore-teaching-hub' ), count( self::grading_items( $uid, 500 ) ), '', self::url( 'grading' ) ) . '</ul></section>';
		}
		$up   = Planner::calendar( $uid, wp_date( 'Y-m-d' ), wp_date( 'Y-m-d', time() + 7 * DAY_IN_SECONDS ) );
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Next 7 days', 'educore-teaching-hub' ) . '</h3>' . self::agenda( $up ) . '</section>';
		return $out;
	}

	/** Workload, performance, engagement, academic performance and attention widgets (teachers/managers). */
	private static function teaching_widgets( int $uid, array $r ): string {
		$classes = self::scoped_classes( $uid );
		$m       = Analytics::teaching( $uid, $classes, $r );
		$w       = $m['workload'];
		$d       = $m['delivery'];
		$out     = '<section class="ec-th-widget"><h3>' . esc_html__( 'Workload', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-tiles">'
			. self::stat( __( 'Active classes', 'educore-teaching-hub' ), $w['classes'], '', self::url( 'classes' ) )
			. self::stat( __( 'Enrolled students', 'educore-teaching-hub' ), $w['active_students'], '', self::url( 'students' ) )
			. self::stat( __( 'Pending grading', 'educore-teaching-hub' ), count( self::grading_items( $uid, 500 ) ), '', self::url( 'grading' ) )
			. self::stat( __( 'Assignments due', 'educore-teaching-hub' ), $w['assignments_due'], __( 'in selected period', 'educore-teaching-hub' ), self::url( 'assignments' ) )
			. '</ul></section>';
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Teaching performance', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-tiles">'
			. self::stat( __( 'Lessons planned', 'educore-teaching-hub' ), $w['lessons_planned'], '', self::url( 'planner' ) )
			. self::stat( __( 'Lessons delivered', 'educore-teaching-hub' ), $w['lessons_delivered'] )
			. self::stat( __( 'Median grading turnaround (hours)', 'educore-teaching-hub' ), $d['grading_turnaround_h'] )
			. '</ul></section>';
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Student engagement', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-tiles">'
			. self::stat( __( 'Assignment completion', 'educore-teaching-hub' ), null === $d['assignment_completion_pct'] ? null : $d['assignment_completion_pct'] . '%' )
			. self::stat( __( 'Attendance rate', 'educore-teaching-hub' ), null === $d['attendance_rate_pct'] ? null : $d['attendance_rate_pct'] . '%', '', self::url( 'attendance' ) )
			. '</ul></section>';
		$dist = $d['score_distribution'];
		$tot  = max( 1, array_sum( $dist ) );
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Academic performance', 'educore-teaching-hub' ) . '</h3>';
		if ( array_sum( $dist ) ) {
			$out .= '<table class="ec-th-table"><caption>' . esc_html( sprintf( /* translators: %d: count */ __( 'Released assignment scores (n = %d)', 'educore-teaching-hub' ), array_sum( $dist ) ) ) . '</caption><tbody>';
			foreach ( $dist as $band => $n ) {
				$out .= '<tr><th scope="row">' . esc_html( $band ) . '%</th><td>' . self::bar( (int) round( 100 * $n / $tot ) ) . '</td><td>' . esc_html( number_format_i18n( $n ) ) . '</td></tr>';
			}
			$out .= '</tbody></table>';
		} else {
			$out .= '<p class="ec-muted">' . esc_html__( 'No released assignment scores in this period.', 'educore-teaching-hub' ) . '</p>';
		}
		$out  .= '</section>';
		$flags = Alerts::for_classes( $classes );
		$out  .= '<section class="ec-th-widget ec-th-attention"><h3>' . esc_html__( 'Attention center', 'educore-teaching-hub' ) . '</h3>';
		if ( ! $flags ) {
			return $out . '<p class="ec-muted">' . esc_html__( 'Nothing needs your attention right now.', 'educore-teaching-hub' ) . '</p></section>';
		}
		$labels = Alerts::labels();
		$out   .= '<ul class="ec-th-list">';
		foreach ( array_slice( $flags, 0, 25 ) as $f ) {
			$out .= '<li class="ec-th-sev-' . esc_attr( (string) $f['severity'] ) . '"><a href="' . esc_url( self::url( 'student', array( 'id' => $f['student_id'] ) ) ) . '">' . esc_html( $f['name'] ) . '</a> — <strong>' . esc_html( $labels[ $f['rule'] ] ?? $f['rule'] ) . '</strong>: ' . esc_html( $f['detail'] ) . ' <span class="ec-muted">(' . esc_html( Classes::get( $f['class_id'] )['name'] ?? '' ) . ')</span></li>';
		}
		return $out . '</ul></section>';
	}

	private static function agenda( array $days ): string {
		if ( ! $days ) {
			return '<p class="ec-muted">' . esc_html__( 'Nothing scheduled.', 'educore-teaching-hub' ) . '</p>';
		}
		$out = '<ul class="ec-th-agenda">';
		foreach ( $days as $day => $items ) {
			foreach ( $items as $i ) {
				$out .= '<li><time>' . esc_html( wp_date( get_option( 'date_format' ), strtotime( $day ) ) . ( $i['time'] ? ' ' . $i['time'] : '' ) ) . '</time> <span class="ec-chip ec-th-type--' . esc_attr( $i['type'] ) . '">' . esc_html( self::type_label( $i['type'] ) ) . '</span> <a href="' . esc_url( $i['url'] ) . '">' . esc_html( $i['title'] ) . '</a></li>';
			}
		}
		return $out . '</ul>';
	}

	private static function type_label( string $t ): string {
		$map = array( 'lesson' => __( 'Lesson', 'educore-teaching-hub' ), 'deadline' => __( 'Deadline', 'educore-teaching-hub' ), 'exam' => __( 'Exam', 'educore-teaching-hub' ), 'session-requested' => __( 'Session request', 'educore-teaching-hub' ), 'session-confirmed' => __( 'Tutoring', 'educore-teaching-hub' ), 'session-completed' => __( 'Tutoring (done)', 'educore-teaching-hub' ) );
		return $map[ $t ] ?? $t;
	}

	/* ---------- Courses (instructor) ---------- */

	private static function view_courses( int $uid ): string {
		$ids = user_can( $uid, 'ec_manage_all_courses' ) ? get_posts( array( 'post_type' => Content::COURSE, 'post_status' => array( 'publish', 'draft', 'pending' ), 'numberposts' => 200, 'fields' => 'ids' ) ) : \EduCore\Core\Staff::courses_of( $uid );
		$out = self::h( __( 'My courses', 'educore-teaching-hub' ) ) . '<p class="ec-muted">' . esc_html__( 'Course content is edited in the curriculum editor; previews show exactly what students see.', 'educore-teaching-hub' ) . '</p>';
		if ( ! $ids ) {
			return $out . '<p>' . esc_html__( 'No courses are assigned to you yet.', 'educore-teaching-hub' ) . '</p>';
		}
		$out .= '<table class="ec-th-table"><thead><tr><th>' . esc_html__( 'Course', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Status', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Students', 'educore-teaching-hub' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( $ids as $cid ) {
			$out .= '<tr><td>' . esc_html( get_the_title( $cid ) ) . '</td><td>' . Student::chip( (string) get_post_status( $cid ) ) . '</td><td>' . esc_html( number_format_i18n( \EduCore\Core\Enrollment::count_for_course( (int) $cid ) ) ) . '</td><td>';
			if ( user_can( $uid, 'ec_edit_course', $cid ) ) {
				$out .= '<a class="ec-btn ec-btn--ghost" href="' . esc_url( admin_url( 'admin.php?page=educore-curriculum&course=' . $cid ) ) . '">' . esc_html__( 'Curriculum', 'educore-teaching-hub' ) . '</a> ';
			}
			$out .= '<a class="ec-btn ec-btn--ghost" href="' . esc_url( get_preview_post_link( $cid ) ?: get_permalink( $cid ) ) . '">' . esc_html__( 'Preview as student', 'educore-teaching-hub' ) . '</a>';
			if ( user_can( $uid, 'ec_manage_assessments' ) && class_exists( '\EduCore\Assessments\Plugin' ) ) {
				$out .= ' <a class="ec-btn ec-btn--ghost" href="' . esc_url( admin_url( 'admin.php?page=educore-assess&course=' . $cid ) ) . '">' . esc_html__( 'Assessments', 'educore-teaching-hub' ) . '</a>';
			}
			$out .= '</td></tr>';
		}
		return $out . '</tbody></table>';
	}

	/* ---------- Classes ---------- */

	private static function view_classes( int $uid ): string {
		$ids    = Caps::classes_of( $uid );
		$counts = Classes::member_counts( $ids );
		$out    = self::h( __( 'My classes', 'educore-teaching-hub' ), Caps::is_manager( $uid ) ? '<a class="ec-btn" href="' . esc_url( admin_url( 'admin.php?page=educore-teaching&tab=classes' ) ) . '">' . esc_html__( 'Create a class', 'educore-teaching-hub' ) . '</a>' : '' );
		if ( ! $ids ) {
			return $out . '<p>' . esc_html__( 'You are not assigned to a class yet. An administrator assigns classes in the Teaching Management Center.', 'educore-teaching-hub' ) . '</p>';
		}
		$out .= '<ul class="ec-th-cards">';
		foreach ( $ids as $cid ) {
			$c    = Classes::get( $cid );
			$out .= '<li class="ec-card"><h3><a href="' . esc_url( self::url( 'class', array( 'id' => $cid ) ) ) . '">' . esc_html( $c['name'] ) . '</a></h3><p class="ec-muted">' . esc_html( trim( $c['academic_year'] . ' · ' . ( $c['course_id'] ? get_the_title( (int) $c['course_id'] ) : '' ), ' ·' ) ) . '</p><p>' . esc_html( sprintf( /* translators: %d: students */ _n( '%d student', '%d students', $counts[ $cid ] ?? 0, 'educore-teaching-hub' ), $counts[ $cid ] ?? 0 ) ) . '</p></li>';
		}
		return $out . '</ul>';
	}

	private static function view_class( int $uid ): string {
		$id = self::req_int( 'id' );
		if ( ! user_can( $uid, 'ec_teach_class', $id ) || ! ( $c = Classes::get( $id ) ) ) {
			return '<div class="ec-notice ec-notice--error">' . esc_html__( 'Class not found.', 'educore-teaching-hub' ) . '</div>';
		}
		$manage = user_can( $uid, 'ec_manage_class', $id );
		$out    = self::h( $c['name'], '<a class="ec-btn" href="' . esc_url( self::url( 'attendance', array( 'class' => $id ) ) ) . '">' . esc_html__( 'Take attendance', 'educore-teaching-hub' ) . '</a> <a class="ec-btn" href="' . esc_url( self::url( 'assignments', array( 'class' => $id ) ) ) . '">' . esc_html__( 'Assignments', 'educore-teaching-hub' ) . '</a>' );
		$staff  = array_map( static fn( $s ) => self::name( $s['user_id'] ) . ' (' . $s['staff_role'] . ')', Classes::staff( $id ) );
		$out   .= '<p class="ec-muted">' . esc_html( implode( ', ', $staff ) ) . ( $c['schedule'] ? ' · ' . esc_html( $c['schedule'] ) : '' ) . '</p>';
		$members = Classes::members( $id );
		self::prime_users( array_merge( $members, wp_list_pluck( Classes::staff( $id ), 'user_id' ) ) );
		$out    .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Students', 'educore-teaching-hub' ) . ' (' . esc_html( number_format_i18n( count( $members ) ) ) . ')</h3><table class="ec-th-table"><tbody>';
		foreach ( $members as $sid ) {
			$out .= '<tr><td><a href="' . esc_url( self::url( 'student', array( 'id' => $sid ) ) ) . '">' . esc_html( self::name( $sid ) ) . '</a></td><td>';
			if ( $manage ) {
				$out .= self::form( 'remove_member', array( 'class_id' => $id, 'student_id' => $sid ), '<button class="ec-btn ec-btn--ghost" data-ec-th-confirm="' . esc_attr__( 'Remove this student from the class?', 'educore-teaching-hub' ) . '">' . esc_html__( 'Remove', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' );
				$others = array_diff( Caps::classes_of( $uid ), array( $id ) );
				if ( $others ) {
					$opts = '';
					foreach ( $others as $o ) {
						if ( user_can( $uid, 'ec_manage_class', $o ) ) {
							$opts .= '<option value="' . esc_attr( (string) $o ) . '">' . esc_html( Classes::get( $o )['name'] ) . '</option>';
						}
					}
					if ( $opts ) {
						$out .= self::form( 'transfer', array( 'class_id' => $id, 'student_id' => $sid ), '<select name="to_class" aria-label="' . esc_attr__( 'Transfer to', 'educore-teaching-hub' ) . '">' . $opts . '</select> <button class="ec-btn ec-btn--ghost">' . esc_html__( 'Transfer', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' );
					}
				}
			}
			$out .= '</td></tr>';
		}
		$out .= '</tbody></table>';
		if ( $manage ) {
			$out .= '<details class="ec-th-details"><summary>' . esc_html__( 'Enrol a student', 'educore-teaching-hub' ) . '</summary>' . self::form( 'add_member', array( 'class_id' => $id ), self::field( __( 'Student e-mail or username', 'educore-teaching-hub' ), '<input name="student" required autocomplete="off">' ) . '<p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Enrol', 'educore-teaching-hub' ) . '</button></p>' ) . '</details>';
		}
		$out .= '</section>';
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Groups', 'educore-teaching-hub' ) . '</h3>';
		foreach ( Classes::groups_of_class( $id ) as $g ) {
			$gm   = array_map( array( self::class, 'name' ), Classes::group_members( (int) $g['id'] ) );
			$out .= '<div class="ec-th-group"><strong>' . esc_html( $g['name'] ) . '</strong> <span class="ec-chip">' . esc_html( $g['group_type'] ) . '</span><br><span class="ec-muted">' . esc_html( implode( ', ', $gm ) ?: __( 'No members yet', 'educore-teaching-hub' ) ) . '</span>';
			if ( Classes::can_manage_group( $uid, (int) $g['id'] ) && $members ) {
				$opts = '';
				foreach ( array_diff( $members, Classes::group_members( (int) $g['id'] ) ) as $sid ) {
					$opts .= '<option value="' . esc_attr( (string) $sid ) . '">' . esc_html( self::name( $sid ) ) . '</option>';
				}
				if ( $opts ) {
					$out .= self::form( 'group_add', array( 'group_id' => $g['id'] ), '<select name="student_id" aria-label="' . esc_attr__( 'Student', 'educore-teaching-hub' ) . '">' . $opts . '</select> <button class="ec-btn ec-btn--ghost">' . esc_html__( 'Add to group', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' );
				}
			}
			$out .= '</div>';
		}
		$types = '';
		foreach ( Classes::GROUP_TYPES as $t ) {
			$types .= '<option value="' . esc_attr( $t ) . '">' . esc_html( ucfirst( $t ) ) . '</option>';
		}
		$out .= '<details class="ec-th-details"><summary>' . esc_html__( 'New group', 'educore-teaching-hub' ) . '</summary>' . self::form( 'create_group', array( 'class_id' => $id ), self::field( __( 'Name', 'educore-teaching-hub' ), '<input name="name" required maxlength="190">' ) . self::field( __( 'Type', 'educore-teaching-hub' ), '<select name="group_type">' . $types . '</select>' ) . '<p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Create group', 'educore-teaching-hub' ) . '</button></p>' ) . '</details></section>';
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Class announcements', 'educore-teaching-hub' ) . '</h3>' . self::form( 'announce', array( 'class_id' => $id ), self::field( __( 'Title', 'educore-teaching-hub' ), '<input name="subject" required maxlength="190">' ) . self::field( __( 'Message', 'educore-teaching-hub' ), '<textarea name="body" rows="3" required></textarea>' ) . '<p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Post to class', 'educore-teaching-hub' ) . '</button></p>' ) . '</section>';
		return $out;
	}

	/* ---------- Students ---------- */

	private static function view_students( int $uid ): string {
		$out = self::h( __( 'Students', 'educore-teaching-hub' ) );
		$ids = array();
		foreach ( Caps::classes_of( $uid ) as $cid ) {
			$cname = Classes::get( $cid )['name'];
			foreach ( Classes::members( $cid ) as $sid ) {
				$ids[ $sid ][] = $cname;
			}
		}
		self::prime_users( array_keys( $ids ) );
		if ( ! $ids ) {
			return $out . '<p>' . esc_html__( 'No students in your classes yet.', 'educore-teaching-hub' ) . '</p>';
		}
		$out .= '<table class="ec-th-table" data-ec-th-sortable><thead><tr><th>' . esc_html__( 'Student', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Classes', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>';
		foreach ( $ids as $sid => $cls ) {
			$out .= '<tr><td><a href="' . esc_url( self::url( 'student', array( 'id' => $sid ) ) ) . '">' . esc_html( self::name( $sid ) ) . '</a></td><td>' . esc_html( implode( ', ', $cls ) ) . '</td></tr>';
		}
		return $out . '</tbody></table>';
	}

	/** Permitted academic summary of one student for a staff viewer (caller checks ec_view_hub_student). */
	public static function student_summary( int $sid, int $viewer ): array {
		$classes  = array_values( array_intersect( Classes::of_student( $sid ), Caps::is_manager( $viewer ) ? Classes::of_student( $sid ) : Caps::classes_of( $viewer ) ) );
		$assigned = array_values( array_filter( Assignments::for_student( $sid ), static fn( $a ) => Caps::can_grade_assignment( $viewer, (int) $a['id'] ) ) );
		$courses  = array();
		foreach ( \EduCore\Core\Enrollment::for_user( $sid ) as $e ) {
			$cid = (int) $e['course_id'];
			if ( Caps::is_manager( $viewer ) || user_can( $viewer, 'ec_view_course_records', $cid ) || in_array( $cid, array_map( static fn( $c ) => (int) Classes::get( $c )['course_id'], $classes ), true ) ) {
				$courses[] = array( 'id' => $cid, 'title' => get_the_title( $cid ), 'progress' => \EduCore\Core\Progress::course_summary( $sid, $cid ) );
			}
		}
		return array(
			'id'          => $sid,
			'name'        => self::name( $sid ),
			'classes'     => array_map( static fn( $c ) => Classes::get( $c )['name'], $classes ),
			'courses'     => $courses,
			'assignments' => array_map( static fn( $a ) => array( 'id' => (int) $a['id'], 'title' => $a['title'], 'due_at' => $a['due_at'], 'status' => Assignments::learner_status( $a, $a['sub_status'] ? array( 'status' => $a['sub_status'], 'released' => $a['released'], 'is_late' => $a['is_late'] ) : null ), 'score' => null === $a['score'] ? null : (float) $a['score'], 'max' => (float) $a['max_score'] ), $assigned ),
			'attendance'  => Attendance::student_summary( $sid, wp_date( 'Y-m-d', time() - 90 * DAY_IN_SECONDS ) ),
			'flags'       => array_values( array_filter( Alerts::for_classes( $classes ), static fn( $f ) => $f['student_id'] === $sid ) ),
		);
	}

	private static function view_student( int $uid ): string {
		$sid = self::req_int( 'id' );
		if ( ! user_can( $uid, 'ec_view_hub_student', $sid ) || ! get_userdata( $sid ) ) {
			return '<div class="ec-notice ec-notice--error">' . esc_html__( 'Student not found.', 'educore-teaching-hub' ) . '</div>';
		}
		$s   = self::student_summary( $sid, $uid );
		$out = self::h( $s['name'] ) . '<p class="ec-muted">' . esc_html( implode( ', ', $s['classes'] ) ) . '</p>';
		if ( $s['flags'] ) {
			$labels = Alerts::labels();
			$out   .= '<section class="ec-th-widget ec-th-attention"><h3>' . esc_html__( 'Needs attention', 'educore-teaching-hub' ) . '</h3><ul>';
			foreach ( $s['flags'] as $f ) {
				$out .= '<li><strong>' . esc_html( $labels[ $f['rule'] ] ?? $f['rule'] ) . '</strong>: ' . esc_html( $f['detail'] ) . '</li>';
			}
			$out .= '</ul></section>';
		}
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Learning progress', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-list">';
		foreach ( $s['courses'] as $c ) {
			$pct  = (int) ( $c['progress']['percent'] ?? 0 );
			$out .= '<li>' . esc_html( $c['title'] ) . ' ' . self::bar( $pct ) . ' ' . esc_html( $pct . '%' ) . '</li>';
		}
		$out .= '</ul></section><section class="ec-th-widget"><h3>' . esc_html__( 'Assignments', 'educore-teaching-hub' ) . '</h3><table class="ec-th-table"><tbody>';
		foreach ( $s['assignments'] as $a ) {
			$out .= '<tr><td><a href="' . esc_url( self::url( 'assignment', array( 'id' => $a['id'] ) ) ) . '">' . esc_html( $a['title'] ) . '</a></td><td>' . esc_html( Plugin::local( $a['due_at'] ) ) . '</td><td>' . Student::chip( $a['status'] ) . '</td><td>' . esc_html( null === $a['score'] ? '—' : number_format_i18n( $a['score'], 1 ) . ' / ' . number_format_i18n( $a['max'], 0 ) ) . '</td></tr>';
		}
		$out .= '</tbody></table></section><section class="ec-th-widget"><h3>' . esc_html__( 'Attendance (90 days)', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-stats">';
		foreach ( $s['attendance'] as $st => $n ) {
			$out .= '<li><span class="ec-th-stat__n">' . esc_html( number_format_i18n( $n ) ) . '</span> ' . esc_html( Student::status_label( $st ) ) . '</li>';
		}
		return $out . '</ul></section>';
	}

	/* ---------- Planner ---------- */

	private static function plan_form( int $uid, array $p = array() ): string {
		$f   = static fn( $k ) => esc_textarea( (string) ( $p[ $k ] ?? '' ) );
		$st  = '';
		foreach ( Planner::STATUSES as $s ) {
			$st .= '<option value="' . esc_attr( $s ) . '"' . selected( $p['status'] ?? 'planned', $s, false ) . '>' . esc_html( Student::status_label( $s ) ) . '</option>';
		}
		$inner = '<div class="ec-th-grid">'
			. self::field( __( 'Lesson title', 'educore-teaching-hub' ), '<input name="title" required maxlength="190" value="' . esc_attr( (string) ( $p['title'] ?? '' ) ) . '">' )
			. self::field( __( 'Class', 'educore-teaching-hub' ), '<select name="class_id"><option value="0">—</option>' . self::class_options( $uid, (int) ( $p['class_id'] ?? 0 ) ) . '</select>' )
			. self::field( __( 'Curriculum lesson ID (optional)', 'educore-teaching-hub' ), '<input type="number" min="0" name="lesson_id" value="' . esc_attr( (string) ( $p['lesson_id'] ?? '' ) ) . '">' )
			. self::field( __( 'Teaching date', 'educore-teaching-hub' ), '<input type="date" name="teach_date" value="' . esc_attr( (string) ( $p['teach_date'] ?? '' ) ) . '">' )
			. self::field( __( 'Duration (minutes)', 'educore-teaching-hub' ), '<input type="number" min="5" max="600" name="duration_min" value="' . esc_attr( (string) ( $p['duration_min'] ?? 45 ) ) . '">' )
			. self::field( __( 'Target students', 'educore-teaching-hub' ), '<input name="target" maxlength="190" value="' . esc_attr( (string) ( $p['target'] ?? '' ) ) . '">' )
			. self::field( __( 'Status', 'educore-teaching-hub' ), '<select name="status">' . $st . '</select>' )
			. '</div>';
		foreach ( array( 'objectives' => __( 'Learning objectives', 'educore-teaching-hub' ), 'materials' => __( 'Teaching materials', 'educore-teaching-hub' ), 'activities' => __( 'Instructional activities', 'educore-teaching-hub' ), 'exercises' => __( 'Practical exercises', 'educore-teaching-hub' ), 'assessment' => __( 'Assessment strategy', 'educore-teaching-hub' ), 'homework' => __( 'Homework', 'educore-teaching-hub' ), 'notes' => __( 'Teacher notes', 'educore-teaching-hub' ) ) as $k => $label ) {
			$inner .= self::field( $label, '<textarea name="' . esc_attr( $k ) . '" rows="2">' . $f( $k ) . '</textarea>' );
		}
		$inner .= '<p><label><input type="checkbox" name="is_template" value="1"' . checked( ! empty( $p['is_template'] ), true, false ) . '> ' . esc_html__( 'Save as reusable template', 'educore-teaching-hub' ) . '</label></p><p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Save lesson plan', 'educore-teaching-hub' ) . '</button></p>';
		return self::form( 'save_plan', array( 'plan_id' => (int) ( $p['id'] ?? 0 ) ), $inner );
	}

	private static function view_planner( int $uid ): string {
		$pid = self::req_int( 'plan' );
		if ( $pid ) {
			$p = Planner::get( $pid );
			if ( ! $p || ! Planner::can_edit( $uid, $p ) ) {
				return '<div class="ec-notice ec-notice--error">' . esc_html__( 'Lesson plan not found.', 'educore-teaching-hub' ) . '</div>';
			}
			$preview = (int) $p['lesson_id'] && Content::LESSON === get_post_type( (int) $p['lesson_id'] ) ? ' <a class="ec-btn ec-btn--ghost" href="' . esc_url( get_preview_post_link( (int) $p['lesson_id'] ) ?: get_permalink( (int) $p['lesson_id'] ) ) . '">' . esc_html__( 'Preview lesson as student', 'educore-teaching-hub' ) . '</a>' : '';
			return self::h( $p['title'], '<a class="ec-btn ec-btn--ghost" href="' . esc_url( self::url( 'planner' ) ) . '">← ' . esc_html__( 'All plans', 'educore-teaching-hub' ) . '</a>' . $preview ) . self::plan_form( $uid, $p );
		}
		$plans = Planner::list_for( $uid, Caps::classes_of( $uid ), wp_date( 'Y-m-d', time() - 14 * DAY_IN_SECONDS ) );
		$out   = self::h( __( 'Lesson planner', 'educore-teaching-hub' ) );
		$out  .= '<table class="ec-th-table"><thead><tr><th>' . esc_html__( 'Date', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Lesson', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Class', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Status', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>';
		foreach ( $plans as $p ) {
			$out .= '<tr><td>' . esc_html( $p['teach_date'] ?: '—' ) . '</td><td><a href="' . esc_url( self::url( 'planner', array( 'plan' => $p['id'] ) ) ) . '">' . esc_html( $p['title'] ) . '</a></td><td>' . esc_html( (int) $p['class_id'] ? ( Classes::get( (int) $p['class_id'] )['name'] ?? '' ) : '—' ) . '</td><td>' . Student::chip( $p['status'] ) . '</td></tr>';
		}
		$out      .= '</tbody></table>';
		$templates = Planner::list_for( $uid, array(), '', '', true );
		if ( $templates ) {
			$opts = '';
			foreach ( $templates as $t ) {
				$opts .= '<option value="' . esc_attr( (string) $t['id'] ) . '">' . esc_html( $t['title'] ) . '</option>';
			}
			$out .= '<details class="ec-th-details"><summary>' . esc_html__( 'Plan from a template', 'educore-teaching-hub' ) . '</summary>' . self::form( 'plan_from_template', array(), self::field( __( 'Template', 'educore-teaching-hub' ), '<select name="template_id">' . $opts . '</select>' ) . self::field( __( 'Class', 'educore-teaching-hub' ), '<select name="class_id">' . self::class_options( $uid ) . '</select>' ) . self::field( __( 'Teaching date', 'educore-teaching-hub' ), '<input type="date" name="teach_date" required>' ) . '<p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Create plan', 'educore-teaching-hub' ) . '</button></p>' ) . '</details>';
		}
		return $out . '<details class="ec-th-details" open><summary>' . esc_html__( 'New lesson plan', 'educore-teaching-hub' ) . '</summary>' . self::plan_form( $uid ) . '</details>';
	}

	/* ---------- Assignments ---------- */

	private static function view_assignments( int $uid ): string {
		$classes = self::scoped_classes( $uid );
		$rows    = Assignments::for_classes( $classes );
		$out     = self::h( __( 'Assignments', 'educore-teaching-hub' ) );
		$out    .= '<table class="ec-th-table"><thead><tr><th>' . esc_html__( 'Assignment', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Class', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Deadline', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Status', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $a ) {
			$out .= '<tr><td><a href="' . esc_url( self::url( 'assignment', array( 'id' => $a['id'] ) ) ) . '">' . esc_html( $a['title'] ) . '</a></td><td>' . esc_html( Classes::get( (int) $a['class_id'] )['name'] ?? '' ) . '</td><td>' . esc_html( Plugin::local( $a['due_at'] ) ) . '</td><td>' . Student::chip( $a['status'] ) . '</td></tr>';
		}
		$out .= '</tbody></table>';
		if ( ! Caps::classes_of( $uid ) ) {
			return $out;
		}
		return $out . '<details class="ec-th-details"><summary>' . esc_html__( 'New assignment', 'educore-teaching-hub' ) . '</summary>' . self::assignment_form( $uid, array( 'class_id' => self::req_int( 'class' ) ) ) . '</details>';
	}

	private static function assignment_form( int $uid, array $a ): string {
		$local  = static fn( $utc ) => $utc ? Plugin::local( $utc, 'Y-m-d\TH:i' ) : '';
		$rubric = '';
		foreach ( Assignments::rubric( $a + array( 'rubric' => null ) ) as $c ) {
			$rubric .= $c['label'] . ' | ' . $c['points'] . "\n";
		}
		$st = '';
		foreach ( Assignments::STATUSES as $s ) {
			$st .= '<option value="' . esc_attr( $s ) . '"' . selected( $a['status'] ?? 'draft', $s, false ) . '>' . esc_html( Student::status_label( $s ) ) . '</option>';
		}
		$targets = '';
		if ( ! empty( $a['class_id'] ) ) {
			foreach ( Classes::groups_of_class( (int) $a['class_id'] ) as $g ) {
				$targets .= '<label><input type="checkbox" name="groups[]" value="' . esc_attr( (string) $g['id'] ) . '"> ' . esc_html( $g['name'] ) . '</label> ';
			}
		}
		$inner = '<div class="ec-th-grid">'
			. self::field( __( 'Title', 'educore-teaching-hub' ), '<input name="title" required maxlength="190" value="' . esc_attr( (string) ( $a['title'] ?? '' ) ) . '">' )
			. self::field( __( 'Class', 'educore-teaching-hub' ), '<select name="class_id" required>' . self::class_options( $uid, (int) ( $a['class_id'] ?? 0 ) ) . '</select>' )
			. self::field( __( 'Linked lesson ID (optional)', 'educore-teaching-hub' ), '<input type="number" min="0" name="lesson_id" value="' . esc_attr( (string) ( $a['lesson_id'] ?? '' ) ) . '">' )
			. self::field( __( 'Opens', 'educore-teaching-hub' ), '<input type="datetime-local" name="opens_at" value="' . esc_attr( $local( $a['opens_at'] ?? null ) ) . '">' )
			. self::field( __( 'Deadline', 'educore-teaching-hub' ), '<input type="datetime-local" name="due_at" value="' . esc_attr( $local( $a['due_at'] ?? null ) ) . '">' )
			. self::field( __( 'Maximum score', 'educore-teaching-hub' ), '<input type="number" step="0.5" min="1" name="max_score" value="' . esc_attr( (string) ( $a['max_score'] ?? 100 ) ) . '">' )
			. self::field( __( 'Status', 'educore-teaching-hub' ), '<select name="status">' . $st . '</select>' )
			. '</div>'
			. self::field( __( 'Instructions', 'educore-teaching-hub' ), '<textarea name="instructions" rows="5">' . esc_textarea( (string) ( $a['instructions'] ?? '' ) ) . '</textarea>' )
			. self::field( __( 'Rubric — one criterion per line: “Criterion | points” (must add up to the maximum score)', 'educore-teaching-hub' ), '<textarea name="rubric" rows="3">' . esc_textarea( $rubric ) . '</textarea>' )
			. ( $targets ? '<fieldset><legend>' . esc_html__( 'Assign only to groups (leave empty for the whole class)', 'educore-teaching-hub' ) . '</legend>' . $targets . '</fieldset>' : '' )
			. '<p><label><input type="checkbox" name="allow_resubmit" value="1"' . checked( ! empty( $a['allow_resubmit'] ), true, false ) . '> ' . esc_html__( 'Allow resubmission before grading', 'educore-teaching-hub' ) . '</label> <label><input type="checkbox" name="allow_late" value="1"' . checked( ! isset( $a['allow_late'] ) || (int) $a['allow_late'], true, false ) . '> ' . esc_html__( 'Accept late submissions', 'educore-teaching-hub' ) . '</label> <label><input type="checkbox" name="allow_files" value="1"' . checked( ! isset( $a['allow_files'] ) || (int) $a['allow_files'], true, false ) . '> ' . esc_html__( 'Allow file uploads', 'educore-teaching-hub' ) . '</label></p>'
			. self::field( __( 'Attach documents', 'educore-teaching-hub' ), '<input type="file" name="attachments[]" multiple>' )
			. '<p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Save assignment', 'educore-teaching-hub' ) . '</button></p>';
		return self::form( 'save_assignment', array( 'assignment_id' => (int) ( $a['id'] ?? 0 ) ), $inner, '', true );
	}

	private static function view_assignment( int $uid ): string {
		$id = self::req_int( 'id' );
		$a  = Assignments::get( $id );
		if ( ! $a || ! user_can( $uid, 'ec_grade_assignment', $id ) ) {
			return '<div class="ec-notice ec-notice--error">' . esc_html__( 'Assignment not found.', 'educore-teaching-hub' ) . '</div>';
		}
		$out    = self::h( $a['title'], self::form( 'release', array( 'assignment_id' => $id ), '<button class="ec-btn">' . esc_html__( 'Release all graded results', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' ) );
		$out   .= '<p class="ec-muted">' . esc_html__( 'Deadline', 'educore-teaching-hub' ) . ': ' . esc_html( Plugin::local( $a['due_at'] ) ) . ' · ' . Student::chip( $a['status'] ) . '</p>';
		$rubric = Assignments::rubric( $a );
		$focus  = self::req_int( 'sub' );
		$out   .= '<table class="ec-th-table"><thead><tr><th>' . esc_html__( 'Student', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Status', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Submitted', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Score', 'educore-teaching-hub' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( Assignments::roster( $id ) as $r ) {
			$s    = $r['submission'];
			$st   = $s && 'graded' === $s['status'] && ! (int) $s['released'] ? 'graded-unreleased' : $r['status'];
			$out .= '<tr' . ( $s && (int) $s['id'] === $focus ? ' class="is-focus"' : '' ) . '><td>' . esc_html( $r['name'] ) . '</td><td>' . ( 'graded-unreleased' === $st ? '<span class="ec-chip">' . esc_html__( 'Graded — not released', 'educore-teaching-hub' ) . '</span>' : Student::chip( $st ) ) . '</td><td>' . esc_html( $s ? Plugin::local( $s['submitted_at'] ) : '—' ) . '</td><td>' . esc_html( $s && null !== $s['score'] ? number_format_i18n( (float) $s['score'], 1 ) . ' / ' . number_format_i18n( (float) $a['max_score'], 0 ) : '—' ) . '</td><td>';
			if ( $s && in_array( $s['status'], array( 'submitted', 'graded', 'returned' ), true ) ) {
				$out .= '<details class="ec-th-details"' . ( (int) $s['id'] === $focus ? ' open' : '' ) . '><summary>' . esc_html__( 'Review & grade', 'educore-teaching-hub' ) . '</summary><div class="ec-th-answer">' . wp_kses_post( wpautop( (string) $s['answer'] ) ) . '</div>';
				foreach ( (array) json_decode( (string) $s['files'], true ) as $i => $f ) {
					$out .= '<a href="' . esc_url( wp_nonce_url( add_query_arg( array( 'ec_th_file' => $i, 'sub' => $s['id'] ), home_url( '/' ) ), 'ec_th_file' ) ) . '">' . esc_html( $f['name'] ) . '</a> ';
				}
				$inner  = '';
				$scores = (array) json_decode( (string) $s['rubric_scores'], true );
				$used   = Assignments::rubric_for( $a, $s );
				if ( ! empty( $s['rubric_snapshot'] ) && $used !== $rubric ) {
					$inner .= '<p class="ec-muted">' . esc_html__( 'Graded with earlier criteria:', 'educore-teaching-hub' ) . ' ' . esc_html( implode( ' · ', array_map( static fn( $c, $i ) => $c['label'] . ' ' . number_format_i18n( (float) ( $scores[ $i ] ?? 0 ), 1 ) . '/' . number_format_i18n( (float) $c['points'], 1 ), $used, array_keys( $used ) ) ) ) . '</p>';
				}
				if ( $rubric ) {
					foreach ( $rubric as $i => $c ) {
						$inner .= self::field( $c['label'] . ' (/' . $c['points'] . ')', '<input type="number" step="0.5" min="0" max="' . esc_attr( (string) $c['points'] ) . '" name="rubric_scores[' . (int) $i . ']" value="' . esc_attr( (string) ( $scores[ $i ] ?? '' ) ) . '">' );
					}
				} else {
					$inner .= self::field( __( 'Score', 'educore-teaching-hub' ) . ' (/' . $a['max_score'] . ')', '<input type="number" step="0.5" min="0" max="' . esc_attr( (string) $a['max_score'] ) . '" name="score" value="' . esc_attr( (string) ( $s['score'] ?? '' ) ) . '">' );
				}
				$inner .= self::field( __( 'Feedback', 'educore-teaching-hub' ), '<textarea name="feedback" rows="3">' . esc_textarea( (string) $s['feedback'] ) . '</textarea>' );
				$inner .= '<p><button class="ec-btn" name="mode" value="grade">' . esc_html__( 'Save grade', 'educore-teaching-hub' ) . '</button> <button class="ec-btn ec-btn--primary" name="mode" value="release">' . esc_html__( 'Save & release', 'educore-teaching-hub' ) . '</button> <button class="ec-btn ec-btn--ghost" name="mode" value="return">' . esc_html__( 'Return for revision', 'educore-teaching-hub' ) . '</button></p>';
				$out   .= self::form( 'grade', array( 'submission_id' => $s['id'] ), $inner );
				$log    = Assignments::grade_log( (int) $s['id'] );
				if ( $log ) {
					$out .= '<details><summary>' . esc_html__( 'Grade history', 'educore-teaching-hub' ) . '</summary><ul class="ec-th-log">';
					foreach ( $log as $l ) {
						$out .= '<li>' . esc_html( Plugin::local( $l['created_at'] ) . ' — ' . self::name( (int) $l['actor_id'] ) . ' — ' . $l['action'] . ( null !== $l['new_score'] ? ': ' . ( null === $l['old_score'] ? '' : $l['old_score'] . ' → ' ) . $l['new_score'] : '' ) ) . '</li>';
					}
					$out .= '</ul></details>';
				}
				$out .= '</details>';
			}
			$out .= '</td></tr>';
		}
		$out .= '</tbody></table>';
		return $out . '<details class="ec-th-details"><summary>' . esc_html__( 'Edit assignment', 'educore-teaching-hub' ) . '</summary>' . self::assignment_form( $uid, $a ) . '</details>';
	}

	/* ---------- Grading center ---------- */

	/** Unified queue: Teaching Hub submissions + EduCore Assessments essays awaiting manual grading. */
	public static function grading_items( int $uid, int $limit = 200 ): array {
		static $memo = array();
		$key = $uid . ':' . $limit;
		if ( isset( $memo[ $key ] ) && ! defined( 'EDUCORE_TH_TESTING' ) ) {
			return $memo[ $key ];
		}
		$q1 = Assignments::grading_queue( $uid, $limit );
		$q2 = class_exists( '\EduCore\Assessments\Grading' ) ? \EduCore\Assessments\Grading::queue( $uid, 0, $limit ) : array();
		self::prime_users( array_merge( wp_list_pluck( $q1, 'student_id' ), wp_list_pluck( $q2, 'user_id' ) ) );
		$items = array();
		foreach ( $q1 as $r ) {
			$items[] = array( 'kind' => 'assignment', 'title' => $r['title'], 'student' => self::name( (int) $r['student_id'] ), 'submitted_at' => $r['submitted_at'], 'late' => (bool) $r['is_late'], 'url' => self::url( 'assignment', array( 'id' => $r['assignment_id'], 'sub' => $r['submission_id'] ) ), 'course_id' => (int) $r['course_id'] );
		}
		if ( $q2 ) {
			foreach ( $q2 as $r ) {
				$items[] = array( 'kind' => 'essay', 'title' => $r['title'], 'student' => self::name( (int) $r['user_id'] ), 'submitted_at' => $r['submitted_at'], 'late' => false, 'url' => admin_url( 'admin.php?page=educore-grading&attempt=' . (int) $r['attempt_id'] ), 'course_id' => (int) $r['course_id'] );
			}
		}
		usort( $items, static fn( $a, $b ) => strcmp( (string) $a['submitted_at'], (string) $b['submitted_at'] ) );
		$memo[ $key ] = $items;
		return $items;
	}

	private static function view_grading( int $uid ): string {
		$items = self::grading_items( $uid );
		$out   = self::h( __( 'Grading center', 'educore-teaching-hub' ) ) . '<p class="ec-muted">' . esc_html__( 'Oldest first. An assessment counts as fully graded only when every manual question has a score.', 'educore-teaching-hub' ) . '</p>';
		if ( ! $items ) {
			return $out . '<p>' . esc_html__( 'Nothing to grade. Well done!', 'educore-teaching-hub' ) . '</p>';
		}
		$out .= '<table class="ec-th-table"><thead><tr><th>' . esc_html__( 'Type', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Item', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Student', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Course', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Submitted', 'educore-teaching-hub' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( $items as $i ) {
			$out .= '<tr><td>' . esc_html( 'essay' === $i['kind'] ? __( 'Exam essay', 'educore-teaching-hub' ) : __( 'Assignment', 'educore-teaching-hub' ) ) . '</td><td>' . esc_html( $i['title'] ) . '</td><td>' . esc_html( $i['student'] ) . '</td><td>' . esc_html( $i['course_id'] ? get_the_title( $i['course_id'] ) : '—' ) . '</td><td>' . esc_html( Plugin::local( $i['submitted_at'] ) ) . ( $i['late'] ? ' ' . Student::chip( 'late' ) : '' ) . '</td><td><a class="ec-btn ec-btn--ghost" href="' . esc_url( $i['url'] ) . '">' . esc_html__( 'Grade', 'educore-teaching-hub' ) . '</a></td></tr>';
		}
		return $out . '</tbody></table>';
	}

	/* ---------- Calendar ---------- */

	private static function view_calendar( int $uid ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$month = isset( $_GET['m'] ) && preg_match( '/^\d{4}-\d{2}$/', sanitize_text_field( wp_unslash( $_GET['m'] ) ) ) ? sanitize_text_field( wp_unslash( $_GET['m'] ) ) : wp_date( 'Y-m' );
		$first = strtotime( $month . '-01' );
		$last  = strtotime( gmdate( 'Y-m-t', $first ) );
		$days  = Planner::calendar( $uid, gmdate( 'Y-m-d', $first ), gmdate( 'Y-m-d', $last ) );
		$prev  = gmdate( 'Y-m', strtotime( '-1 month', $first ) );
		$next  = gmdate( 'Y-m', strtotime( '+1 month', $first ) );
		$out   = self::h( wp_date( 'F Y', $first ), '<a class="ec-btn ec-btn--ghost" href="' . esc_url( self::url( 'calendar', array( 'm' => $prev ) ) ) . '">‹ ' . esc_html__( 'Previous', 'educore-teaching-hub' ) . '</a> <a class="ec-btn ec-btn--ghost" href="' . esc_url( self::url( 'calendar', array( 'm' => $next ) ) ) . '">' . esc_html__( 'Next', 'educore-teaching-hub' ) . ' ›</a>' );
		$start = (int) get_option( 'start_of_week', 6 );
		$out  .= '<div class="ec-th-cal" role="grid"><div class="ec-th-cal__row" role="row">';
		for ( $i = 0; $i < 7; $i++ ) {
			$out .= '<div role="columnheader" class="ec-th-cal__dow">' . esc_html( $GLOBALS['wp_locale']->get_weekday_abbrev( $GLOBALS['wp_locale']->get_weekday( ( $start + $i ) % 7 ) ) ) . '</div>';
		}
		$out .= '</div><div class="ec-th-cal__row" role="row">';
		$pad  = ( (int) gmdate( 'w', $first ) - $start + 7 ) % 7;
		$out .= str_repeat( '<div class="ec-th-cal__cell is-empty" role="gridcell"></div>', $pad );
		$col  = $pad;
		for ( $d = $first; $d <= $last; $d += DAY_IN_SECONDS ) {
			$key  = gmdate( 'Y-m-d', $d );
			$out .= '<div class="ec-th-cal__cell' . ( wp_date( 'Y-m-d' ) === $key ? ' is-today' : '' ) . '" role="gridcell"><span class="ec-th-cal__d">' . esc_html( number_format_i18n( (int) gmdate( 'j', $d ) ) ) . '</span>';
			foreach ( $days[ $key ] ?? array() as $i ) {
				$out .= '<a class="ec-th-cal__item ec-th-type--' . esc_attr( $i['type'] ) . '" href="' . esc_url( $i['url'] ) . '">' . esc_html( ( $i['time'] ? $i['time'] . ' ' : '' ) . $i['title'] ) . '</a>';
			}
			$out .= '</div>';
			if ( 6 === $col % 7 && $d < $last ) {
				$out .= '</div><div class="ec-th-cal__row" role="row">';
			}
			++$col;
		}
		return $out . '</div></div><h3>' . esc_html__( 'Agenda', 'educore-teaching-hub' ) . '</h3>' . self::agenda( $days );
	}

	/* ---------- Tutoring ---------- */

	private static function view_tutoring( int $uid ): string {
		$p   = Tutoring::profile( $uid );
		$out = self::h( __( 'Tutoring', 'educore-teaching-hub' ) );
		if ( ! user_can( $uid, 'ec_tutor_sessions' ) ) {
			return $out . '<p>' . esc_html__( 'Tutoring tools are available to accounts with the tutor responsibility.', 'educore-teaching-hub' ) . '</p>';
		}
		$status = $p['status'] ?? 'draft';
		$note   = array( 'draft' => __( 'Your profile is a draft. Submit it for approval to appear in the tutor directory.', 'educore-teaching-hub' ), 'pending' => __( 'Your profile is waiting for administrator approval.', 'educore-teaching-hub' ), 'approved' => __( 'Your profile is approved.', 'educore-teaching-hub' ), 'rejected' => __( 'Your profile needs changes before approval.', 'educore-teaching-hub' ), 'suspended' => __( 'Your profile is suspended. Contact the EduCore team.', 'educore-teaching-hub' ) );
		$out   .= '<p class="ec-notice ec-notice--info">' . esc_html( $note[ $status ] ) . ( ! empty( $p['review_note'] ) ? ' ' . esc_html( $p['review_note'] ) : '' ) . '</p>';
		$up     = Tutoring::for_tutor( $uid );
		$out   .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Requests & upcoming sessions', 'educore-teaching-hub' ) . '</h3>';
		if ( ! $up ) {
			$out .= '<p class="ec-muted">' . esc_html__( 'No upcoming sessions.', 'educore-teaching-hub' ) . '</p>';
		} else {
			$out .= '<table class="ec-th-table"><tbody>';
			foreach ( $up as $s ) {
				$who  = (int) $s['group_id'] ? ( Classes::group( (int) $s['group_id'] )['name'] ?? '' ) : self::name( (int) $s['student_id'] );
				$out .= '<tr><td>' . esc_html( Plugin::local( $s['starts_at'] ) ) . '</td><td><a href="' . esc_url( self::url( 'session', array( 'id' => $s['id'] ) ) ) . '">' . esc_html( $who . ( $s['subject'] ? ' — ' . $s['subject'] : '' ) ) . '</a></td><td>' . Student::chip( $s['status'] ) . ( 'requested' === $s['status'] && ! (int) $s['guardian_ok'] ? ' <span class="ec-chip">' . esc_html__( 'Awaiting guardian', 'educore-teaching-hub' ) . '</span>' : '' ) . '</td></tr>';
			}
			$out .= '</tbody></table>';
		}
		$out .= '</section>';
		if ( 'approved' === $status ) {
			$opts = '';
			foreach ( Tutoring::for_tutor( $uid, 'past', 300 ) as $s ) {
				if ( (int) $s['student_id'] && in_array( $s['status'], array( 'completed', 'confirmed', 'no_show' ), true ) ) {
					$opts .= '<option value="' . esc_attr( 's' . $s['student_id'] ) . '">' . esc_html( self::name( (int) $s['student_id'] ) ) . '</option>';
				}
			}
			global $wpdb;
			foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT id, name FROM ' . Schema::table( 'th_groups' ) . " WHERE owner_id=%d AND group_type='tutoring'", $uid ), ARRAY_A ) ?: array() as $g ) {
				$opts .= '<option value="' . esc_attr( 'g' . $g['id'] ) . '">' . esc_html( __( 'Group', 'educore-teaching-hub' ) . ': ' . $g['name'] ) . '</option>';
			}
			$opts = implode( '', array_unique( explode( '</option>', $opts ) ) );
			if ( $opts ) {
				$out .= '<details class="ec-th-details"><summary>' . esc_html__( 'Schedule a session (existing students or your tutoring groups)', 'educore-teaching-hub' ) . '</summary>' . self::form( 'create_session', array(), '<div class="ec-th-grid">' . self::field( __( 'With', 'educore-teaching-hub' ), '<select name="who" required>' . $opts . '</select>' ) . self::field( __( 'Start', 'educore-teaching-hub' ), '<input type="datetime-local" name="start" required step="900">' ) . self::field( __( 'Minutes', 'educore-teaching-hub' ), '<input type="number" name="minutes" value="60" min="15" max="240" step="15">' ) . self::field( __( 'Repeat weekly (weeks)', 'educore-teaching-hub' ), '<input type="number" name="repeat_weeks" value="1" min="1" max="26">' ) . self::field( __( 'Format', 'educore-teaching-hub' ), '<select name="format"><option value="online">' . esc_html__( 'Online', 'educore-teaching-hub' ) . '</option><option value="in_person">' . esc_html__( 'In person', 'educore-teaching-hub' ) . '</option></select>' ) . self::field( __( 'Subject', 'educore-teaching-hub' ), '<input name="subject" maxlength="190">' ) . self::field( __( 'Meeting link (approved services only)', 'educore-teaching-hub' ), '<input type="url" name="meeting_url">' ) . self::field( __( 'Location', 'educore-teaching-hub' ), '<input name="location" maxlength="190">' ) . '</div><p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Schedule', 'educore-teaching-hub' ) . '</button></p>' ) . '</details>';
			}
		}
		// Profile.
		$p       = $p ?: array();
		$langs   = explode( ',', (string) ( $p['languages'] ?? '' ) );
		$formats = explode( ',', (string) ( $p['formats'] ?? 'online' ) );
		$inner   = self::field( __( 'Headline', 'educore-teaching-hub' ), '<input name="headline" maxlength="190" value="' . esc_attr( (string) ( $p['headline'] ?? '' ) ) . '">' )
			. self::field( __( 'Biography', 'educore-teaching-hub' ), '<textarea name="bio" rows="4">' . esc_textarea( (string) ( $p['bio'] ?? '' ) ) . '</textarea>' )
			. self::field( __( 'Subjects taught', 'educore-teaching-hub' ), '<input name="subjects" maxlength="255" value="' . esc_attr( (string) ( $p['subjects'] ?? '' ) ) . '">' )
			. self::field( __( 'Experience', 'educore-teaching-hub' ), '<input name="experience" maxlength="255" value="' . esc_attr( (string) ( $p['experience'] ?? '' ) ) . '">' )
			. self::field( __( 'Qualifications (verified by an administrator)', 'educore-teaching-hub' ), '<textarea name="qualifications" rows="3">' . esc_textarea( (string) ( $p['qualifications'] ?? '' ) ) . '</textarea>' )
			. '<fieldset><legend>' . esc_html__( 'Teaching languages', 'educore-teaching-hub' ) . '</legend>';
		foreach ( array( 'en' => 'English', 'fr' => 'Français', 'ar' => 'العربية' ) as $k => $l ) {
			$inner .= '<label><input type="checkbox" name="languages[]" value="' . esc_attr( $k ) . '"' . checked( in_array( $k, $langs, true ), true, false ) . '> ' . esc_html( $l ) . '</label> ';
		}
		$inner .= '</fieldset><fieldset><legend>' . esc_html__( 'Formats', 'educore-teaching-hub' ) . '</legend><label><input type="checkbox" name="formats[]" value="online"' . checked( in_array( 'online', $formats, true ), true, false ) . '> ' . esc_html__( 'Online', 'educore-teaching-hub' ) . '</label> <label><input type="checkbox" name="formats[]" value="in_person"' . checked( in_array( 'in_person', $formats, true ), true, false ) . '> ' . esc_html__( 'In person', 'educore-teaching-hub' ) . '</label></fieldset><div class="ec-th-grid">'
			. self::field( __( 'Session length (minutes)', 'educore-teaching-hub' ), '<input type="number" name="session_minutes" min="15" max="240" step="15" value="' . esc_attr( (string) ( $p['session_minutes'] ?? 60 ) ) . '">' )
			. self::field( __( 'Booking notice (hours)', 'educore-teaching-hub' ), '<input type="number" name="notice_hours" min="0" max="336" value="' . esc_attr( (string) ( $p['notice_hours'] ?? 24 ) ) . '">' )
			. self::field( __( 'Maximum students per session', 'educore-teaching-hub' ), '<input type="number" name="capacity" min="1" max="20" value="' . esc_attr( (string) ( $p['capacity'] ?? 1 ) ) . '">' )
			. '</div><p><label><input type="checkbox" name="is_public" value="1"' . checked( ! empty( $p['is_public'] ), true, false ) . '> ' . esc_html__( 'List me in the public tutor directory (after approval)', 'educore-teaching-hub' ) . '</label></p><p><button class="ec-btn" name="submit_review" value="0">' . esc_html__( 'Save', 'educore-teaching-hub' ) . '</button> <button class="ec-btn ec-btn--primary" name="submit_review" value="1">' . esc_html__( 'Save & submit for approval', 'educore-teaching-hub' ) . '</button></p>';
		$out .= '<details class="ec-th-details"' . ( 'draft' === $status ? ' open' : '' ) . '><summary>' . esc_html__( 'My tutor profile', 'educore-teaching-hub' ) . '</summary>' . self::form( 'save_profile', array(), $inner ) . '</details>';
		// Availability.
		$rows = '';
		$wins = Tutoring::availability( $uid );
		for ( $i = 0; $i < max( 3, count( $wins ) + 2 ); $i++ ) {
			$w     = $wins[ $i ] ?? array( -1, '', '' );
			$days  = '<option value="">—</option>';
			for ( $d = 0; $d < 7; $d++ ) {
				$days .= '<option value="' . $d . '"' . selected( $w[0], $d, false ) . '>' . esc_html( $GLOBALS['wp_locale']->get_weekday( $d ) ) . '</option>';
			}
			$rows .= '<tr><td><select name="win_day[]" aria-label="' . esc_attr__( 'Day', 'educore-teaching-hub' ) . '">' . $days . '</select></td><td><input type="time" step="900" name="win_start[]" value="' . esc_attr( $w[1] ) . '" aria-label="' . esc_attr__( 'From', 'educore-teaching-hub' ) . '"></td><td><input type="time" step="900" name="win_end[]" value="' . esc_attr( $w[2] ) . '" aria-label="' . esc_attr__( 'To', 'educore-teaching-hub' ) . '"></td></tr>';
		}
		$out .= '<details class="ec-th-details"><summary>' . esc_html__( 'Weekly availability', 'educore-teaching-hub' ) . ' (' . esc_html( wp_timezone_string() ) . ')</summary>' . self::form( 'save_availability', array(), '<table class="ec-th-table"><tbody>' . $rows . '</tbody></table>' . self::field( __( 'Unavailable dates (YYYY-MM-DD, comma-separated)', 'educore-teaching-hub' ), '<input name="unavailable" value="' . esc_attr( implode( ', ', Tutoring::unavailable( $uid ) ) ) . '">' ) . '<p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Save availability', 'educore-teaching-hub' ) . '</button></p>' ) . '</details>';
		$past = Tutoring::for_tutor( $uid, 'past', 30 );
		if ( $past ) {
			$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Tutoring history', 'educore-teaching-hub' ) . '</h3><table class="ec-th-table"><tbody>';
			foreach ( $past as $s ) {
				$out .= '<tr><td>' . esc_html( Plugin::local( $s['starts_at'] ) ) . '</td><td><a href="' . esc_url( self::url( 'session', array( 'id' => $s['id'] ) ) ) . '">' . esc_html( (int) $s['student_id'] ? self::name( (int) $s['student_id'] ) : ( Classes::group( (int) $s['group_id'] )['name'] ?? '' ) ) . '</a></td><td>' . Student::chip( $s['status'] ) . '</td></tr>';
			}
			$out .= '</tbody></table></section>';
		}
		return $out;
	}

	private static function view_profile( int $uid ): string {
		return self::view_tutoring( $uid );
	}

	private static function view_session( int $uid ): string {
		$id = self::req_int( 'id' );
		$s  = Tutoring::get( $id );
		if ( ! $s || ! user_can( $uid, 'ec_manage_session', $id ) ) {
			return '<div class="ec-notice ec-notice--error">' . esc_html__( 'Session not found.', 'educore-teaching-hub' ) . '</div>';
		}
		$who = (int) $s['group_id'] ? ( Classes::group( (int) $s['group_id'] )['name'] ?? '' ) : self::name( (int) $s['student_id'] );
		$out = self::h( $who . ( $s['subject'] ? ' — ' . $s['subject'] : '' ), '<a class="ec-btn ec-btn--ghost" href="' . esc_url( self::url( 'tutoring' ) ) . '">← ' . esc_html__( 'Tutoring', 'educore-teaching-hub' ) . '</a>' );
		$out .= '<p>' . esc_html( Plugin::local( $s['starts_at'] ) . ' – ' . Plugin::local( $s['ends_at'], get_option( 'time_format' ) ) ) . ' · ' . esc_html( 'in_person' === $s['format'] ? __( 'In person', 'educore-teaching-hub' ) : __( 'Online', 'educore-teaching-hub' ) ) . ' ' . Student::chip( $s['status'] ) . ( 'rescheduled' === $s['status_note'] ? ' <span class="ec-chip">' . esc_html__( 'Rescheduled', 'educore-teaching-hub' ) . '</span>' : '' ) . '</p>';
		if ( 'requested' === $s['status'] ) {
			if ( ! (int) $s['guardian_ok'] ) {
				$out .= '<p class="ec-notice ec-notice--info">' . esc_html__( 'This learner is under 18. You can confirm once a parent or guardian has authorised the session.', 'educore-teaching-hub' ) . '</p>';
			}
			$out .= self::form( 'session_status', array( 'session_id' => $id, 'to' => 'confirmed' ), self::field( __( 'Meeting link (approved services only)', 'educore-teaching-hub' ), '<input type="url" name="meeting_url">' ) . self::field( __( 'Location (in person)', 'educore-teaching-hub' ), '<input name="location" maxlength="190">' ) . '<p><button class="ec-btn ec-btn--primary"' . disabled( ! (int) $s['guardian_ok'], true, false ) . '>' . esc_html__( 'Confirm', 'educore-teaching-hub' ) . '</button></p>' );
			$out .= self::form( 'session_status', array( 'session_id' => $id, 'to' => 'declined' ), '<p><button class="ec-btn ec-btn--ghost">' . esc_html__( 'Decline', 'educore-teaching-hub' ) . '</button></p>', 'ec-th-inline' );
		}
		$started = strtotime( $s['starts_at'] . ' UTC' ) <= time();
		if ( 'confirmed' === $s['status'] ) {
			if ( $started ) {
				$out .= self::form( 'session_status', array( 'session_id' => $id, 'to' => 'completed' ), '<button class="ec-btn ec-btn--primary">' . esc_html__( 'Mark completed', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' ) . ' ' . self::form( 'session_status', array( 'session_id' => $id, 'to' => 'no_show' ), '<button class="ec-btn ec-btn--ghost">' . esc_html__( 'Student did not attend', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' );
			} else {
				$out .= self::form( 'reschedule', array( 'session_id' => $id ), '<label>' . esc_html__( 'New start', 'educore-teaching-hub' ) . ' <input type="datetime-local" name="start" step="900" required></label> <button class="ec-btn">' . esc_html__( 'Reschedule', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' ) . ' ' . self::form( 'session_status', array( 'session_id' => $id, 'to' => 'cancelled' ), '<button class="ec-btn ec-btn--ghost" data-ec-th-confirm="' . esc_attr__( 'Cancel this session?', 'educore-teaching-hub' ) . '">' . esc_html__( 'Cancel session', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' );
			}
			if ( $s['meeting_url'] ) {
				$out .= '<p><a class="ec-btn" rel="noopener" target="_blank" href="' . esc_url( $s['meeting_url'] ) . '">' . esc_html__( 'Open meeting', 'educore-teaching-hub' ) . '</a></p>';
			}
		}
		if ( (int) $s['group_id'] && in_array( $s['status'], array( 'confirmed', 'completed' ), true ) && $started ) {
			$out .= self::attendance_form( 'session', $id, Plugin::local( $s['starts_at'], 'Y-m-d' ), Tutoring::participants( $id ) );
		}
		$inner = '';
		foreach ( array( 'objectives' => __( 'Learning objectives', 'educore-teaching-hub' ), 'notes' => __( 'Session notes (private to tutors and administrators)', 'educore-teaching-hub' ), 'homework' => __( 'Homework', 'educore-teaching-hub' ), 'feedback' => __( 'Feedback & progress update for the student', 'educore-teaching-hub' ), 'follow_up' => __( 'Follow-up actions', 'educore-teaching-hub' ) ) as $k => $label ) {
			$inner .= self::field( $label, '<textarea name="' . esc_attr( $k ) . '" rows="2">' . esc_textarea( (string) $s[ $k ] ) . '</textarea>' );
		}
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Session workspace', 'educore-teaching-hub' ) . '</h3>' . self::form( 'session_workspace', array( 'session_id' => $id ), $inner . '<p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Save', 'educore-teaching-hub' ) . '</button></p>' ) . '</section>';
		$t    = self::session_thread( $id );
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Session messages', 'educore-teaching-hub' ) . '</h3>' . ( $t ? self::thread_html( $uid, $t ) : '<p class="ec-muted">' . esc_html__( 'No messages yet. The student can write here; messages stay on EduCore.', 'educore-teaching-hub' ) . '</p>' ) . '</section>';
		return $out;
	}

	private static function session_thread( int $session_id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'th_threads' ) . " WHERE context_type='session' AND context_id=%d ORDER BY id LIMIT 1", $session_id ), ARRAY_A ) ?: null;
	}

	/* ---------- Attendance ---------- */

	private static function attendance_form( string $ctx, int $cid, string $day, array $students ): string {
		$cur = Attendance::for_context( $ctx, $cid, $day );
		self::prime_users( $students );
		$rows = '';
		foreach ( $students as $sid ) {
			$opts = '<option value="">' . esc_html__( 'Not recorded', 'educore-teaching-hub' ) . '</option>';
			foreach ( Attendance::STATUSES as $st ) {
				$opts .= '<option value="' . esc_attr( $st ) . '"' . selected( $cur[ $sid ]['status'] ?? '', $st, false ) . '>' . esc_html( Student::status_label( $st ) ) . '</option>';
			}
			$rows .= '<tr><td>' . esc_html( self::name( $sid ) ) . '</td><td><select name="marks[' . (int) $sid . ']" aria-label="' . esc_attr( self::name( $sid ) ) . '">' . $opts . '</select></td><td><input name="notes[' . (int) $sid . ']" maxlength="255" value="' . esc_attr( $cur[ $sid ]['note'] ?? '' ) . '" aria-label="' . esc_attr__( 'Note', 'educore-teaching-hub' ) . '"></td></tr>';
		}
		return self::form( 'attendance', array( 'context' => $ctx, 'context_id' => $cid, 'date' => $day ), '<table class="ec-th-table"><thead><tr><th>' . esc_html__( 'Student', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Status', 'educore-teaching-hub' ) . '</th><th>' . esc_html__( 'Note', 'educore-teaching-hub' ) . '</th></tr></thead><tbody>' . $rows . '</tbody></table><p><button type="button" class="ec-btn ec-btn--ghost" data-ec-th-all-present>' . esc_html__( 'Mark all present', 'educore-teaching-hub' ) . '</button> <button class="ec-btn ec-btn--primary">' . esc_html__( 'Save attendance', 'educore-teaching-hub' ) . '</button></p>' );
	}

	private static function view_attendance( int $uid ): string {
		$cls   = Caps::classes_of( $uid );
		$class = self::req_int( 'class' ) ?: ( $cls[0] ?? 0 );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$day   = isset( $_GET['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', sanitize_text_field( wp_unslash( $_GET['date'] ) ) ) ? sanitize_text_field( wp_unslash( $_GET['date'] ) ) : wp_date( 'Y-m-d' );
		$out   = self::h( __( 'Attendance', 'educore-teaching-hub' ) );
		if ( ! $class || ! user_can( $uid, 'ec_teach_class', $class ) ) {
			return $out . '<p>' . esc_html__( 'No class selected.', 'educore-teaching-hub' ) . '</p>';
		}
		$out .= '<form method="get" class="ec-th-filters"><input type="hidden" name="v" value="attendance"><label>' . esc_html__( 'Class', 'educore-teaching-hub' ) . ' <select name="class">' . self::class_options( $uid, $class ) . '</select></label> <label>' . esc_html__( 'Date', 'educore-teaching-hub' ) . ' <input type="date" name="date" max="' . esc_attr( wp_date( 'Y-m-d' ) ) . '" value="' . esc_attr( $day ) . '"></label> <button class="ec-btn">' . esc_html__( 'Open', 'educore-teaching-hub' ) . '</button></form>';
		$out .= self::attendance_form( 'class', $class, $day, Classes::members( $class ) );
		$r    = Analytics::range( wp_date( 'Y-m-d', time() - 29 * DAY_IN_SECONDS ), wp_date( 'Y-m-d' ) );
		$sum  = Attendance::class_summary( $class, $r['from'], $r['to'] );
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Last 30 days', 'educore-teaching-hub' ) . '</h3><table class="ec-th-table"><thead><tr><th>' . esc_html__( 'Student', 'educore-teaching-hub' ) . '</th>';
		foreach ( Attendance::STATUSES as $st ) {
			$out .= '<th>' . esc_html( Student::status_label( $st ) ) . '</th>';
		}
		$out .= '</tr></thead><tbody>';
		foreach ( Classes::members( $class ) as $sid ) {
			$out .= '<tr><td>' . esc_html( self::name( $sid ) ) . '</td>';
			foreach ( Attendance::STATUSES as $st ) {
				$out .= '<td>' . esc_html( number_format_i18n( $sum[ $sid ][ $st ] ?? 0 ) ) . '</td>';
			}
			$out .= '</tr>';
		}
		$out .= '</tbody></table>' . self::form( 'export_attendance', array( 'class_id' => $class, 'from' => $r['from'], 'to' => $r['to'] ), '<button class="ec-btn ec-btn--ghost">' . esc_html__( 'Export CSV', 'educore-teaching-hub' ) . '</button>', 'ec-th-inline' ) . '</section>';
		return $out;
	}

	/* ---------- Analytics ---------- */

	private static function view_analytics( int $uid ): string {
		$r   = self::req_range();
		$cls = self::scoped_classes( $uid );
		$m   = Analytics::teaching( $uid, $cls, $r );
		$out = self::h( __( 'Teaching performance', 'educore-teaching-hub' ) ) . self::range_filter( 'analytics', $r, self::req_int( 'class' ), $uid );
		$out .= '<p class="ec-muted">' . esc_html__( 'Workload shows what was done; delivery indicators describe what happened in your classes. Scores depend on cohort and course difficulty and are not a measure of teaching quality on their own.', 'educore-teaching-hub' ) . '</p>';
		$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Workload', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-tiles">';
		$wl   = array( 'classes' => __( 'Classes', 'educore-teaching-hub' ), 'active_students' => __( 'Active students', 'educore-teaching-hub' ), 'lessons_planned' => __( 'Lessons planned', 'educore-teaching-hub' ), 'lessons_delivered' => __( 'Lessons delivered', 'educore-teaching-hub' ), 'assignments_due' => __( 'Assignments due', 'educore-teaching-hub' ), 'pending_grading' => __( 'Pending grading', 'educore-teaching-hub' ) );
		foreach ( $wl as $k => $l ) {
			$out .= self::stat( $l, $m['workload'][ $k ] );
		}
		$d    = $m['delivery'];
		$out .= '</ul></section><section class="ec-th-widget"><h3>' . esc_html__( 'Delivery indicators', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-tiles">'
			. self::stat( __( 'Assignment completion', 'educore-teaching-hub' ), null === $d['assignment_completion_pct'] ? null : $d['assignment_completion_pct'] . '%' )
			. self::stat( __( 'Median grading turnaround (hours)', 'educore-teaching-hub' ), $d['grading_turnaround_h'] )
			. self::stat( __( 'Attendance rate', 'educore-teaching-hub' ), null === $d['attendance_rate_pct'] ? null : $d['attendance_rate_pct'] . '%' )
			. self::stat( __( 'Results released', 'educore-teaching-hub' ), $d['graded_in_range'] ) . '</ul></section>';
		if ( user_can( $uid, 'ec_tutor_sessions' ) ) {
			$t    = Analytics::tutoring( $uid, $r );
			$out .= '<section class="ec-th-widget"><h3>' . esc_html__( 'Tutoring', 'educore-teaching-hub' ) . '</h3><ul class="ec-th-tiles">';
			foreach ( array( 'sessions_scheduled' => __( 'Sessions scheduled', 'educore-teaching-hub' ), 'sessions_completed' => __( 'Sessions completed', 'educore-teaching-hub' ), 'cancellation_pct' => __( 'Cancellation rate %', 'educore-teaching-hub' ), 'no_show_pct' => __( 'No-show rate %', 'educore-teaching-hub' ), 'teaching_hours' => __( 'Teaching hours', 'educore-teaching-hub' ), 'active_learners' => __( 'Active learners', 'educore-teaching-hub' ), 'homework_set_pct' => __( 'Sessions with homework %', 'educore-teaching-hub' ), 'follow_up_pct' => __( 'Follow-up recorded %', 'educore-teaching-hub' ), 'utilisation_pct' => __( 'Availability used %', 'educore-teaching-hub' ) ) as $k => $l ) {
				$out .= self::stat( $l, $t[ $k ] );
			}
			$out .= '</ul></section>';
		}
		return $out . self::form( 'export_analytics', array( 'from' => $r['from'], 'to' => $r['to'] ), '<button class="ec-btn" name="format" value="csv">' . esc_html__( 'Export CSV', 'educore-teaching-hub' ) . '</button> ' . ( class_exists( '\EduCore\Analytics\Xlsx' ) ? '<button class="ec-btn" name="format" value="xlsx">' . esc_html__( 'Export XLSX', 'educore-teaching-hub' ) . '</button>' : '' ), 'ec-th-inline' );
	}

	/* ---------- Communications ---------- */

	public static function thread_html( int $uid, array $t ): string {
		$access = Comms::access( $uid, $t );
		$msgs   = Comms::messages( (int) $t['id'], $uid );
		$out    = '<article class="ec-card ec-th-thread"><h3>' . esc_html( $t['subject'] ) . ( 'closed' === $t['status'] ? ' <span class="ec-chip">' . esc_html__( 'Closed', 'educore-teaching-hub' ) . '</span>' : '' ) . '</h3><ol class="ec-th-msgs">';
		foreach ( $msgs as $m ) {
			$out .= '<li class="ec-th-msg' . ( (int) $m['author_id'] === $uid ? ' is-own' : '' ) . ( (int) $m['hidden'] ? ' is-hidden' : '' ) . '"><header><strong>' . esc_html( self::name( (int) $m['author_id'] ) ) . '</strong> <time>' . esc_html( Plugin::local( $m['created_at'] ) ) . '</time></header><div>' . wp_kses_post( wpautop( esc_html( $m['body'] ) ) ) . '</div>';
			if ( (int) $m['author_id'] !== $uid ) {
				$out .= '<details class="ec-th-report"><summary>' . esc_html__( 'Report a concern', 'educore-teaching-hub' ) . '</summary>' . Student::form( 'report', array( 'thread_id' => $t['id'], 'message_id' => $m['id'] ), '<p><label>' . esc_html__( 'What worries you about this message?', 'educore-teaching-hub' ) . ' <textarea name="reason" rows="2" required></textarea></label></p><p><button class="ec-btn ec-btn--ghost">' . esc_html__( 'Send to safeguarding team', 'educore-teaching-hub' ) . '</button></p>' ) . '</details>';
			}
			$out .= '</li>';
		}
		$out .= '</ol>';
		if ( 'post' === $access && ( (int) $t['student_id'] || in_array( $uid, Comms::context_staff( $t['context_type'], (int) $t['context_id'] ), true ) || Caps::is_manager( $uid ) ) ) {
			$out .= Student::form( 'reply', array( 'thread_id' => $t['id'] ), '<p><label>' . esc_html__( 'Reply', 'educore-teaching-hub' ) . ' <textarea name="body" rows="3" required></textarea></label></p><p><button class="ec-btn ec-btn--primary">' . esc_html__( 'Send', 'educore-teaching-hub' ) . '</button></p>' );
		}
		return $out . '</article>';
	}

	private static function view_messages( int $uid ): string {
		$out     = self::h( __( 'Communications', 'educore-teaching-hub' ) ) . '<p class="ec-muted">' . esc_html__( 'Conversations belong to a class, assignment or tutoring session. They are kept on EduCore, visible to guardians of learners under 18, and can be reviewed by the safeguarding team.', 'educore-teaching-hub' ) . '</p>';
		$threads = Comms::threads_for( $uid, 100 );
		if ( ! $threads ) {
			return $out . '<p>' . esc_html__( 'No conversations yet.', 'educore-teaching-hub' ) . '</p>';
		}
		$out .= '<ul class="ec-th-list">';
		foreach ( $threads as $t ) {
			$who  = (int) $t['student_id'] ? self::name( (int) $t['student_id'] ) : __( 'Whole class', 'educore-teaching-hub' );
			$out .= '<li><a href="' . esc_url( self::url( 'thread', array( 'id' => $t['id'] ) ) ) . '">' . esc_html( $t['subject'] ) . '</a> <span class="ec-muted">' . esc_html( $who . ' · ' . Plugin::local( $t['last_post_at'] ) ) . '</span></li>';
		}
		return $out . '</ul>';
	}

	private static function view_thread( int $uid ): string {
		$t = Comms::thread( self::req_int( 'id' ) );
		if ( ! $t || 'none' === Comms::access( $uid, $t ) ) {
			return '<div class="ec-notice ec-notice--error">' . esc_html__( 'Conversation not found.', 'educore-teaching-hub' ) . '</div>';
		}
		return '<p><a href="' . esc_url( self::url( 'messages' ) ) . '">← ' . esc_html__( 'All conversations', 'educore-teaching-hub' ) . '</a></p>' . self::thread_html( $uid, $t );
	}

	/* ---------- POST handler ---------- */

	private static function back( string $err = '', array $args = array() ): void {
		$ref = remove_query_arg( array( 'th_ok', 'th_err' ), wp_validate_redirect( (string) wp_get_raw_referer(), self::url() ) );
		wp_safe_redirect( add_query_arg( array_merge( $args, $err ? array( 'th_err' => $err ) : array( 'th_ok' => 1 ) ), $ref ) );
		exit;
	}

	public static function handle(): void {
		if ( ! Plugin::is_post() || empty( $_POST['ec_th_action'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- routing check; nonce verified below.
			return;
		}
		$action  = sanitize_key( wp_unslash( $_POST['ec_th_action'] ) );
		$actions = array( 'add_member', 'remove_member', 'transfer', 'create_group', 'group_add', 'save_plan', 'plan_from_template', 'save_assignment', 'grade', 'release', 'attendance', 'save_profile', 'save_availability', 'create_session', 'session_status', 'reschedule', 'session_workspace', 'announce', 'export_analytics', 'export_attendance' );
		if ( ! in_array( $action, $actions, true ) ) {
			return;
		}
		$uid = get_current_user_id();
		if ( ! self::can_enter( $uid ) || ! isset( $_POST['_ecthnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_ecthnonce'] ) ), 'ec_th_' . $action ) ) {
			wp_die( esc_html__( 'Your session expired or you do not have access. Please reload the page.', 'educore-teaching-hub' ), '', array( 'response' => 403 ) );
		}
		$in  = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- each service sanitises its fields.
		$int = static fn( string $k ) => isset( $in[ $k ] ) ? absint( $in[ $k ] ) : 0;
		$res = null;
		switch ( $action ) {
			case 'add_member':
				if ( ! user_can( $uid, 'ec_manage_class', $int( 'class_id' ) ) ) {
					self::back( __( 'Only the lead teacher or an administrator can enrol students.', 'educore-teaching-hub' ) );
				}
				$who = sanitize_text_field( (string) ( $in['student'] ?? '' ) );
				$u   = is_email( $who ) ? get_user_by( 'email', $who ) : get_user_by( 'login', $who );
				$res = $u ? Classes::add_member( $int( 'class_id' ), (int) $u->ID, $uid ) : new \WP_Error( 'x', __( 'No student account matches.', 'educore-teaching-hub' ) );
				break;
			case 'remove_member':
				if ( ! user_can( $uid, 'ec_manage_class', $int( 'class_id' ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				Classes::remove_member( $int( 'class_id' ), $int( 'student_id' ), $uid );
				break;
			case 'transfer':
				if ( ! user_can( $uid, 'ec_manage_class', $int( 'class_id' ) ) || ! user_can( $uid, 'ec_manage_class', $int( 'to_class' ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				$res = Classes::transfer( $int( 'class_id' ), $int( 'to_class' ), $int( 'student_id' ), $uid );
				break;
			case 'create_group':
				if ( ! user_can( $uid, 'ec_teach_class', $int( 'class_id' ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				$res = Classes::create_group( $int( 'class_id' ), sanitize_key( (string) ( $in['group_type'] ?? '' ) ), (string) ( $in['name'] ?? '' ), $uid );
				break;
			case 'group_add':
				if ( ! Classes::can_manage_group( $uid, $int( 'group_id' ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				$res = Classes::add_to_group( $int( 'group_id' ), $int( 'student_id' ) );
				break;
			case 'save_plan':
				$pid = $int( 'plan_id' );
				if ( $pid && ( ! ( $p = Planner::get( $pid ) ) || ! Planner::can_edit( $uid, $p ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				if ( $int( 'class_id' ) && ! user_can( $uid, 'ec_teach_class', $int( 'class_id' ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				$res = Planner::save( $in, $uid, $pid );
				if ( ! is_wp_error( $res ) ) {
					self::back( '', array( 'v' => 'planner', 'plan' => $res ) );
				}
				break;
			case 'plan_from_template':
				if ( ! user_can( $uid, 'ec_teach_class', $int( 'class_id' ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				$res = Planner::from_template( $int( 'template_id' ), $int( 'class_id' ), sanitize_text_field( (string) ( $in['teach_date'] ?? '' ) ), $uid );
				break;
			case 'save_assignment':
				$aid   = $int( 'assignment_id' );
				$class = $int( 'class_id' );
				if ( ! $class || ! user_can( $uid, 'ec_teach_class', $class ) || ( $aid && ! user_can( $uid, 'ec_grade_assignment', $aid ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				$groups = array_map( 'absint', (array) ( $in['groups'] ?? array() ) );
				$in['targets'] = Rest::scoped_targets( $groups ? array_map( static fn( $g ) => array( 'group', $g ), $groups ) : array( array( 'class', $class ) ), $class );
				foreach ( array( 'allow_resubmit', 'allow_late', 'allow_files' ) as $k ) {
					$in[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
				}
				$res = Assignments::save( $in, $uid, $aid );
				if ( ! is_wp_error( $res ) ) {
					$a     = Assignments::get( $res );
					$files = (array) json_decode( (string) $a['attachments'], true );
					foreach ( Files::from_request( 'attachments' ) as $f ) {
						$st = Files::store( $f );
						if ( is_wp_error( $st ) ) {
							self::back( $st->get_error_message(), array( 'v' => 'assignment', 'id' => $res ) );
						}
						$files[] = $st;
					}
					global $wpdb;
					$wpdb->update( Schema::table( 'th_assignments' ), array( 'attachments' => wp_json_encode( $files ) ), array( 'id' => $res ) );
					self::back( '', array( 'v' => 'assignment', 'id' => $res ) );
				}
				break;
			case 'grade':
				$mode  = sanitize_key( (string) ( $in['mode'] ?? 'grade' ) );
				$score = isset( $in['score'] ) && '' !== $in['score'] ? (float) $in['score'] : null;
				$res   = Assignments::grade( $int( 'submission_id' ), $score, (string) ( $in['feedback'] ?? '' ), array_map( 'floatval', (array) ( $in['rubric_scores'] ?? array() ) ), $uid, 'return' === $mode ? 'return' : 'grade' );
				if ( ! is_wp_error( $res ) && 'release' === $mode ) {
					Assignments::release( (int) $res['assignment_id'], $uid, (int) $res['id'] );
				}
				break;
			case 'release':
				if ( ! user_can( $uid, 'ec_grade_assignment', $int( 'assignment_id' ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				Assignments::release( $int( 'assignment_id' ), $uid );
				break;
			case 'attendance':
				$ctx = sanitize_key( (string) ( $in['context'] ?? '' ) );
				$cid = $int( 'context_id' );
				if ( ! ( 'class' === $ctx ? user_can( $uid, 'ec_teach_class', $cid ) : ( 'session' === $ctx && user_can( $uid, 'ec_manage_session', $cid ) ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				$res = Attendance::record( $ctx, $cid, sanitize_text_field( (string) ( $in['date'] ?? '' ) ), array_map( 'sanitize_key', (array) ( $in['marks'] ?? array() ) ), $uid, array_map( 'sanitize_text_field', (array) ( $in['notes'] ?? array() ) ) );
				break;
			case 'save_profile':
				if ( ! user_can( $uid, 'ec_tutor_sessions' ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				Tutoring::save_profile( $uid, $in, ! empty( $in['submit_review'] ) );
				break;
			case 'save_availability':
				if ( ! user_can( $uid, 'ec_tutor_sessions' ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				$wins = array();
				foreach ( (array) ( $in['win_day'] ?? array() ) as $i => $d ) {
					if ( '' !== (string) $d && ! empty( $in['win_start'][ $i ] ) && ! empty( $in['win_end'][ $i ] ) ) {
						$wins[] = array( (int) $d, sanitize_text_field( (string) $in['win_start'][ $i ] ), sanitize_text_field( (string) $in['win_end'][ $i ] ) );
					}
				}
				$res = Tutoring::set_availability( $uid, $wins );
				if ( ! is_wp_error( $res ) ) {
					Tutoring::set_unavailable( $uid, array_map( 'trim', explode( ',', sanitize_text_field( (string) ( $in['unavailable'] ?? '' ) ) ) ) );
				}
				break;
			case 'create_session':
				$who = sanitize_key( (string) ( $in['who'] ?? '' ) );
				$in['group_id']   = 'g' === substr( $who, 0, 1 ) ? absint( substr( $who, 1 ) ) : 0;
				$in['student_id'] = 's' === substr( $who, 0, 1 ) ? absint( substr( $who, 1 ) ) : 0;
				$res              = Tutoring::create_by_tutor( $uid, $in );
				break;
			case 'session_status':
				$res = Tutoring::transition( $int( 'session_id' ), sanitize_key( (string) ( $in['to'] ?? '' ) ), $uid, $in );
				break;
			case 'reschedule':
				$res = Tutoring::reschedule( $int( 'session_id' ), (string) Plugin::local_to_utc( sanitize_text_field( (string) ( $in['start'] ?? '' ) ) ), $uid );
				break;
			case 'session_workspace':
				$res = Tutoring::update_workspace( $int( 'session_id' ), $in, $uid ) ? true : new \WP_Error( 'x', __( 'Not allowed.', 'educore-teaching-hub' ) );
				break;
			case 'announce':
				$res = Comms::start( $uid, 'class', $int( 'class_id' ), (string) ( $in['subject'] ?? '' ), (string) ( $in['body'] ?? '' ) );
				break;
			case 'export_analytics':
				$r = Analytics::range( sanitize_text_field( (string) ( $in['from'] ?? '' ) ), sanitize_text_field( (string) ( $in['to'] ?? '' ) ) );
				\EduCore\Core\Audit::log( 'th.export', 'report', 0, array( 'type' => 'teaching', 'from' => $r['from'], 'to' => $r['to'] ) );
				Analytics::send( Analytics::export_rows( $uid, $r ), 'xlsx' === ( $in['format'] ?? '' ) ? 'xlsx' : 'csv', 'educore-teaching-' . $r['from'] . '-' . $r['to'] );
				break;
			case 'export_attendance':
				if ( ! user_can( $uid, 'ec_teach_class', $int( 'class_id' ) ) ) {
					self::back( __( 'Not allowed.', 'educore-teaching-hub' ) );
				}
				\EduCore\Core\Audit::log( 'th.export', 'class', $int( 'class_id' ), array( 'type' => 'attendance' ) );
				Analytics::send( Attendance::export_rows( $int( 'class_id' ), sanitize_text_field( (string) $in['from'] ), sanitize_text_field( (string) $in['to'] ) ), 'csv', 'attendance-' . $int( 'class_id' ) );
				break;
		}
		if ( is_wp_error( $res ) ) {
			self::back( $res->get_error_message() );
		}
		self::back();
	}
}
