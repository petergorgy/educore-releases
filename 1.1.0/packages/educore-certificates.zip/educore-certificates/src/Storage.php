<?php
namespace EduCore\Certificates;

defined( 'ABSPATH' ) || exit;

/** Private storage under uploads/educore-certificates (web access denied). */
final class Storage {

	public static function dir(): string {
		$up = wp_upload_dir( null, false );
		return trailingslashit( $up['basedir'] ) . 'educore-certificates';
	}

	public static function ensure_dir(): string {
		$dir = self::dir();
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! is_dir( $dir . '/tmp' ) ) {
			wp_mkdir_p( $dir . '/tmp' );
		}
		$guards = array(
			'.htaccess'  => "# EduCore: certificates are served only through the authenticated download endpoint.\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n",
			'index.php'  => "<?php\n// Silence is golden.\n",
			'web.config' => "<?xml version=\"1.0\"?><configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
		);
		foreach ( $guards as $file => $content ) {
			if ( ! file_exists( $dir . '/' . $file ) ) {
				file_put_contents( $dir . '/' . $file, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
		}
		return $dir;
	}

	/** Absolute path for a stored relative file name, refusing traversal. */
	public static function path( string $relative ): ?string {
		$name = basename( $relative );
		if ( ! preg_match( '/^[a-f0-9]{32}\.pdf$/', $name ) ) {
			return null;
		}
		return self::dir() . '/' . $name;
	}
}
