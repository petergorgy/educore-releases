<?php
/**
 * EduCore application shell (workspace pages). Content renders first so modules can register navigation.
 *
 * @package EduCore\Workspace
 */

use EduCore\Workspace\Shell;

defined( 'ABSPATH' ) || exit;

$ec_uid     = get_current_user_id();
$ec_content = Shell::content();

// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only partial refresh flag.
if ( isset( $_GET['partial'] ) ) {
	header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
	echo Shell::breadcrumbs() . Shell::heading() . '<div class="ec-app-body">' . $ec_content . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped by the renderers.
	return;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>try{var t=localStorage.getItem('educore-theme');if(t){document.documentElement.setAttribute('data-theme',t);}}catch(e){}</script>
<?php wp_head(); ?>
</head>
<body <?php body_class( array( 'ec-app', 'ec-app--' . sanitize_html_class( (string) Shell::workspace() ) ) ); ?>>
<?php wp_body_open(); ?>
<a class="ec-app-skip" href="#ec-app-main"><?php esc_html_e( 'Skip to main content', 'educore-workspace' ); ?></a>
<div class="ec-app-frame">
	<aside class="ec-app-side" id="ec-app-side" aria-label="<?php esc_attr_e( 'EduCore navigation', 'educore-workspace' ); ?>">
		<?php echo Shell::brand(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<?php echo Shell::sidebar( $ec_uid ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<p class="ec-app-side__foot"><?php echo esc_html( \EduCore\Core\Branding::initiative() ); ?></p>
	</aside>
	<div class="ec-app-col">
		<?php echo Shell::topbar( $ec_uid ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<main class="ec-app-main" id="ec-app-main" tabindex="-1" data-ec-main>
			<?php echo Shell::breadcrumbs() . Shell::heading(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<div class="ec-app-body"><?php echo $ec_content; // phpcs:ignore WordPress.Security.EscapeOutput -- block/shortcode output. ?></div>
		</main>
	</div>
</div>
<div class="ec-app-toast" role="status" aria-live="polite" data-ec-toast hidden></div>
<?php wp_footer(); ?>
</body>
</html>
