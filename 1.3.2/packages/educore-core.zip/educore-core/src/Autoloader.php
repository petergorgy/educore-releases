<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Minimal PSR-4 autoloader shared by all EduCore packages (each registers its own prefix).
 */
final class Autoloader {
	/** @var array<string,string> */
	private static array $map = array();

	public static function register( string $prefix, string $dir ): void {
		if ( empty( self::$map ) ) {
			spl_autoload_register( array( self::class, 'load' ) );
		}
		self::$map[ $prefix ] = rtrim( $dir, '/' ) . '/';
	}

	public static function load( string $class ): void {
		foreach ( self::$map as $prefix => $dir ) {
			if ( 0 === strpos( $class, $prefix ) ) {
				$file = $dir . str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) ) . '.php';
				if ( is_readable( $file ) ) {
					require_once $file;
				}
				return;
			}
		}
	}
}
