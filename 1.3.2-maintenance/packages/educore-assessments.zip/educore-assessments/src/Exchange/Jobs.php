<?php
namespace EduCore\Assessments\Exchange;

use EduCore\Assessments\Questions;
use EduCore\Assessments\Schema;
use EduCore\Core\Audit;
use EduCore\Core\Schema as CoreSchema;

defined( 'ABSPATH' ) || exit;

/**
 * Import jobs: upload → parse → validate → plan (preview) → commit → report.
 * Nothing is written to the question bank before commit; commit is resumable item by item.
 * Questions whose current version was used in an attempt are never overwritten: a new version is created.
 */
final class Jobs {
	public const MODES = array( 'skip', 'update', 'duplicate' );

	public static function modes(): array {
		return array(
			'skip'      => __( 'Add new questions; skip duplicates and questions that already exist (safe default)', 'educore-assessments' ),
			'update'    => __( 'Add new questions and update existing ones with the same ID (used questions get a new version)', 'educore-assessments' ),
			'duplicate' => __( 'Add every valid question, even duplicates', 'educore-assessments' ),
		);
	}

	/** Savepoints inside an outer transaction (test harness), real transactions otherwise. */
	private static function tx( string $op ): void {
		global $wpdb;
		static $nested = false;
		if ( 'begin' === $op ) {
			$v      = $wpdb->get_var( 'SELECT @@in_transaction' );
			$nested = null !== $v && (int) $v > 0;
		}
		$sql = $nested
			? array( 'begin' => 'SAVEPOINT ec_qx_item', 'commit' => 'RELEASE SAVEPOINT ec_qx_item', 'rollback' => 'ROLLBACK TO SAVEPOINT ec_qx_item' )
			: array( 'begin' => 'START TRANSACTION', 'commit' => 'COMMIT', 'rollback' => 'ROLLBACK' );
		$wpdb->query( $sql[ $op ] ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** Atomic per-job lock (INSERT IGNORE on the unique option name); a stale lock (> 30 min) is taken over. */
	private static function lock( int $job_id ): bool {
		global $wpdb;
		$name = 'educore_qx_lock_' . $job_id;
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value < %d", $name, time() - 30 * MINUTE_IN_SECONDS ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %d, 'off')", $name, time() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return 1 === (int) $wpdb->rows_affected;
	}

	private static function unlock( int $job_id ): void {
		global $wpdb;
		$wpdb->delete( $wpdb->options, array( 'option_name' => 'educore_qx_lock_' . $job_id ) );
	}

	private static function jt(): string {
		return Schema::t( 'exchange_jobs' );
	}

	private static function it(): string {
		return Schema::t( 'exchange_items' );
	}

	public static function can_import( int $course_id, int $user = 0 ): bool {
		$user = $user ?: get_current_user_id();
		return user_can( $user, 'ec_manage_question_bank' ) && user_can( $user, 'ec_edit_course', $course_id );
	}

	public static function storage(): string {
		$saved = (string) get_option( 'educore_exchange_dir', '' );
		if ( $saved && is_dir( $saved ) ) {
			return $saved;
		}
		$up  = wp_upload_dir( null, false );
		$dir = trailingslashit( $up['basedir'] ) . 'educore-exchange-' . bin2hex( random_bytes( 6 ) );
		wp_mkdir_p( $dir );
		file_put_contents( $dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		update_option( 'educore_exchange_dir', $dir, false );
		return $dir;
	}

	public static function get( int $id ): ?array {
		global $wpdb;
		$t   = self::jt();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( ! $row ) {
			return null;
		}
		$row['options'] = (array) json_decode( (string) $row['options'], true );
		$row['summary'] = (array) json_decode( (string) $row['summary'], true );
		return $row;
	}

	public static function items( int $job_id, int $limit = 5000, int $offset = 0 ): array {
		global $wpdb;
		$t = self::it();
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE job_id=%d ORDER BY id LIMIT %d OFFSET %d", $job_id, $limit, $offset ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function recent( int $limit = 30 ): array {
		global $wpdb;
		$t = self::jt();
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL
		return array_values( array_filter( $rows, static fn( $r ) => self::can_import( (int) $r['course_id'] ) ) );
	}

	/**
	 * Stage 1+2: parse and validate a file into a job (no question is written).
	 *
	 * @param array $opts mode, status (''|draft|review|published), lang
	 * @return int|\WP_Error job id
	 */
	public static function create( int $course_id, string $path, string $filename, string $format, array $opts ) {
		global $wpdb;
		if ( ! self::can_import( $course_id ) ) {
			return new \WP_Error( 'ec_x_forbidden', __( 'You are not allowed to import questions into this course.', 'educore-assessments' ) );
		}
		$format = '' === $format || 'auto' === $format ? Formats::detect( $filename, $path ) : $format;
		if ( ! isset( Formats::all()[ $format ] ) ) {
			return new \WP_Error( 'ec_x_format', __( 'Unknown format.', 'educore-assessments' ) );
		}
		$items = Formats::read( $format, $path );
		if ( is_wp_error( $items ) ) {
			Audit::log( 'questions.import_rejected', 'course', $course_id, array( 'format' => $format, 'file' => sanitize_file_name( $filename ), 'error' => $items->get_error_message() ) );
			return $items;
		}
		$mode = in_array( $opts['mode'] ?? '', self::MODES, true ) ? $opts['mode'] : 'skip';
		$opts = array(
			'status' => in_array( $opts['status'] ?? '', array( 'draft', 'review', 'published' ), true ) ? $opts['status'] : '',
			'lang'   => sanitize_key( $opts['lang'] ?? '' ),
		);
		$package = '';
		if ( 'native' === $format ) {
			$package = 'job-' . bin2hex( random_bytes( 8 ) ) . '.zip';
			copy( $path, self::storage() . '/' . $package );
		}
		$wpdb->insert(
			self::jt(),
			array(
				'course_id'  => $course_id,
				'user_id'    => get_current_user_id(),
				'format'     => $format,
				'filename'   => mb_substr( sanitize_file_name( $filename ), 0, 190 ),
				'mode'       => $mode,
				'status'     => 'validated',
				'options'    => wp_json_encode( $opts ),
				'package'    => $package,
				'created_at' => CoreSchema::now(),
			)
		);
		$job = (int) $wpdb->insert_id;
		foreach ( $items as $it ) {
			$msgs = array_map( static fn( $w ) => array( 'w', $w ), (array) $it['warnings'] );
			$rec  = $it['record'];
			$st   = 'invalid';
			if ( $it['error'] ) {
				$msgs[] = array( 'e', $it['error'] );
			} elseif ( $rec ) {
				$v   = Validator::check( $rec, $course_id, $opts );
				$rec = $v['record'];
				foreach ( $v['warnings'] as $w ) {
					$msgs[] = array( 'w', $w );
				}
				foreach ( $v['errors'] as $e ) {
					$msgs[] = array( 'e', $e );
				}
				$st = $v['errors'] ? 'invalid' : 'valid';
			}
			$wpdb->insert(
				self::it(),
				array(
					'job_id'      => $job,
					'line'        => (int) $it['line'],
					'status'      => $st,
					'record'      => wp_json_encode( $rec, JSON_UNESCAPED_UNICODE ),
					'messages'    => wp_json_encode( $msgs, JSON_UNESCAPED_UNICODE ),
					'hash'        => ( 'valid' === $st ) ? Record::dedupe_hash( $rec ) : '',
					'external_id' => (string) ( $rec['external_id'] ?? '' ),
				)
			);
		}
		self::plan( $job );
		Audit::log( 'questions.import_validated', 'course', $course_id, array( 'job' => $job, 'format' => $format, 'file' => sanitize_file_name( $filename ) ) + self::get( $job )['summary'] );
		return $job;
	}

	public static function set_mode( int $job_id, string $mode ): void {
		global $wpdb;
		if ( in_array( $mode, self::MODES, true ) ) {
			$wpdb->update( self::jt(), array( 'mode' => $mode ), array( 'id' => $job_id, 'status' => 'validated' ) );
			self::plan( $job_id );
		}
	}

	/** Decide the action for every valid item against the current bank. */
	public static function plan( int $job_id ): array {
		global $wpdb;
		$job  = self::get( $job_id );
		$seen = array();
		foreach ( self::items( $job_id ) as $it ) {
			if ( 'valid' !== $it['status'] ) {
				if ( 'invalid' === $it['status'] && 'invalid' !== $it['action'] ) {
					$wpdb->update( self::it(), array( 'action' => 'invalid' ), array( 'id' => $it['id'] ) );
				}
				continue;
			}
			$rec    = (array) json_decode( (string) $it['record'], true );
			$action = 'create';
			$target = 0;
			$in_file = isset( $seen[ $it['hash'] ] );
			$seen[ $it['hash'] ] = true;
			if ( 'duplicate' !== $job['mode'] ) {
				$by_ext = Record::resolve( (int) $job['course_id'], (string) $it['external_id'] );
				$by_hash = Questions::duplicates( (int) $job['course_id'], (string) $it['hash'] );
				if ( 'update' === $job['mode'] && $by_ext ) {
					$target = $by_ext;
					$cur    = Record::from_question( $by_ext );
					$q      = Questions::full( $by_ext );
					if ( $cur && Record::fingerprint( $cur ) === Record::fingerprint( $rec ) && $cur['status'] === $rec['status'] && (int) $cur['lesson_id'] === (int) $rec['lesson_id'] ) {
						$action = 'unchanged';
					} elseif ( $q && ( ! empty( $q['version']['used'] ) || $q['type'] !== $rec['type'] ) ) {
						$action = 'new_version';
					} else {
						$action = 'update';
					}
				} elseif ( $by_ext || $by_hash ) {
					$action = 'skip_existing';
					$target = $by_ext ?: (int) $by_hash[0];
				} elseif ( $in_file ) {
					$action = 'skip_in_file';
				}
			}
			$wpdb->update( self::it(), array( 'action' => $action, 'question_id' => $target ), array( 'id' => $it['id'] ) );
		}
		return self::summarise( $job_id );
	}

	public static function summarise( int $job_id ): array {
		global $wpdb;
		$t    = self::it();
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT status, action, COUNT(*) n FROM {$t} WHERE job_id=%d GROUP BY status, action", $job_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$warn = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE job_id=%d AND messages LIKE %s", $job_id, '%["w",%' ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$s    = array( 'total' => 0, 'valid' => 0, 'invalid' => 0, 'with_warnings' => $warn, 'actions' => array(), 'results' => array() );
		foreach ( $rows as $r ) {
			$n           = (int) $r['n'];
			$s['total'] += $n;
			if ( 'invalid' === $r['status'] ) {
				$s['invalid'] += $n;
				continue;
			}
			if ( 'valid' === $r['status'] ) {
				$s['valid']                    += $n;
				$s['actions'][ $r['action'] ] = ( $s['actions'][ $r['action'] ] ?? 0 ) + $n;
			} else {
				$s['valid']                   += $n;
				$s['results'][ $r['status'] ] = ( $s['results'][ $r['status'] ] ?? 0 ) + $n;
			}
		}
		$wpdb->update( self::jt(), array( 'summary' => wp_json_encode( $s ) ), array( 'id' => $job_id ) );
		return $s;
	}

	/**
	 * Stage 3: commit. Re-plans first (the bank may have changed since the preview), then applies each item.
	 *
	 * @return array|\WP_Error summary
	 */
	public static function commit( int $job_id ) {
		global $wpdb;
		$job = self::get( $job_id );
		if ( ! $job || ! in_array( $job['status'], array( 'validated', 'importing' ), true ) ) {
			return new \WP_Error( 'ec_x_job', __( 'This import cannot be run (already finished or cancelled).', 'educore-assessments' ) );
		}
		if ( ! self::can_import( (int) $job['course_id'] ) ) {
			return new \WP_Error( 'ec_x_forbidden', __( 'You are not allowed to import questions into this course.', 'educore-assessments' ) );
		}
		if ( ! self::lock( $job_id ) ) {
			return new \WP_Error( 'ec_x_busy', __( 'This import is already running. Wait for it to finish, then reload.', 'educore-assessments' ) );
		}
		try {
			if ( function_exists( 'set_time_limit' ) ) {
				@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}
			$wpdb->update( self::jt(), array( 'status' => 'importing' ), array( 'id' => $job_id ) );
			self::plan( $job_id );
			$course  = (int) $job['course_id'];
			$package = $job['package'] ? self::storage() . '/' . $job['package'] : '';
			foreach ( self::items( $job_id ) as $it ) {
				if ( 'valid' !== $it['status'] ) {
					continue; // Already applied (resume after interruption) or invalid.
				}
				self::apply_item( $it, $course, $package );
			}
			$summary = self::summarise( $job_id );
			$wpdb->update( self::jt(), array( 'status' => 'completed', 'finished_at' => CoreSchema::now(), 'package' => '' ), array( 'id' => $job_id ) );
			$package && file_exists( $package ) && wp_delete_file( $package );
			Audit::log( 'questions.imported', 'course', $course, array( 'job' => $job_id, 'format' => $job['format'], 'mode' => $job['mode'] ) + $summary['results'] );
			return $summary;
		} finally {
			self::unlock( $job_id );
		}
	}

	/** Apply one item atomically: the question write and the item's status change commit together. */
	private static function apply_item( array $it, int $course, string $package ): void {
		global $wpdb;
		$rec    = (array) json_decode( (string) $it['record'], true );
		$action = $it['action'];
		$msgs   = (array) json_decode( (string) $it['messages'], true );
		if ( ! in_array( $action, array( 'create', 'update', 'new_version' ), true ) ) {
			$wpdb->update( self::it(), array( 'status' => 'unchanged' === $action ? 'unchanged' : 'skipped' ), array( 'id' => $it['id'] ) );
			return;
		}
		$fail = static function ( string $m ) use ( $wpdb, $it, $msgs ) {
			$msgs[] = array( 'e', $m );
			$wpdb->update( self::it(), array( 'status' => 'failed', 'messages' => wp_json_encode( $msgs, JSON_UNESCAPED_UNICODE ) ), array( 'id' => $it['id'] ) );
		};
		if ( 'image' === $rec['type'] && ! empty( $rec['media']['image'] ) ) {
			$img = $package ? Formats::import_media( $package, (string) $rec['media']['image'] ) : 0; // Content-addressed: safe to repeat.
			if ( ! $img ) {
				$fail( __( 'The image could not be added to the media library.', 'educore-assessments' ) );
				return;
			}
			$rec['payload']['image_id'] = $img;
		}
		$data = array(
			'course_id'   => $course,
			'lesson_id'   => (int) $rec['lesson_id'],
			'type'        => $rec['type'],
			'stem'        => $rec['stem'],
			'payload'     => $rec['payload'],
			'key'         => $rec['key'],
			'explanation' => $rec['explanation'],
			'points'      => $rec['points'],
			'difficulty'  => $rec['difficulty'],
			'usage'       => $rec['usage'],
			'lang'        => $rec['lang'],
			'tags'        => $rec['tags'],
			'status'      => $rec['status'],
		);
		if ( '' !== (string) $rec['external_id'] ) {
			$data['external_id'] = $rec['external_id'];
		}
		self::tx( 'begin' );
		try {
			$res = Questions::save( $data, 'create' === $action ? 0 : (int) $it['question_id'] );
			if ( is_wp_error( $res ) ) {
				self::tx( 'rollback' );
				$fail( $res->get_error_message() );
				return;
			}
			if ( 'create' === $action && '' === (string) $rec['external_id'] ) {
				$wpdb->update( Schema::t( 'questions' ), array( 'external_id' => Record::default_external_id( (int) $res ) ), array( 'id' => (int) $res ) );
			}
			$wpdb->update( self::it(), array( 'status' => 'create' === $action ? 'created' : ( 'update' === $action ? 'updated' : 'new_version' ), 'question_id' => (int) $res ), array( 'id' => $it['id'] ) );
			/** Fires inside the per-item transaction, before it commits (used by tests to simulate a crash). */
			do_action( 'educore/exchange/before_item_commit', $it, (int) $res );
			self::tx( 'commit' );
		} catch ( \Throwable $e ) {
			self::tx( 'rollback' );
			throw $e;
		}
	}

	public static function cancel( int $job_id ): void {
		global $wpdb;
		$job = self::get( $job_id );
		if ( $job && 'validated' === $job['status'] ) {
			$job['package'] && wp_delete_file( self::storage() . '/' . $job['package'] );
			$wpdb->update( self::jt(), array( 'status' => 'cancelled', 'package' => '', 'finished_at' => CoreSchema::now() ), array( 'id' => $job_id ) );
			Audit::log( 'questions.import_cancelled', 'course', (int) $job['course_id'], array( 'job' => $job_id ) );
		}
	}

	/** Validation / result report as CSV. */
	public static function report_csv( int $job_id ): string {
		$fh = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fputcsv( $fh, array( 'line', 'status', 'action', 'question_id', 'external_id', 'type', 'question', 'errors', 'warnings' ), ',', '"', '' );
		foreach ( self::items( $job_id ) as $it ) {
			$rec  = (array) json_decode( (string) $it['record'], true );
			$msgs = (array) json_decode( (string) $it['messages'], true );
			$e    = implode( ' | ', array_map( static fn( $m ) => $m[1], array_filter( $msgs, static fn( $m ) => 'e' === $m[0] ) ) );
			$w    = implode( ' | ', array_map( static fn( $m ) => $m[1], array_filter( $msgs, static fn( $m ) => 'w' === $m[0] ) ) );
			fputcsv( $fh, array_map( array( Tabular::class, 'guard' ), array( $it['line'], $it['status'], $it['action'], $it['question_id'] ?: '', $it['external_id'], $rec['type'] ?? '', mb_substr( wp_strip_all_tags( (string) ( $rec['stem'] ?? '' ) ), 0, 120 ), $e, $w ) ), ',', '"', '' );
		}
		rewind( $fh );
		$csv = (string) stream_get_contents( $fh );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return "\xEF\xBB\xBF" . $csv;
	}
}
