<?php
namespace EduCore\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Gentle gamification: XP, milestone badges, a weekly goal. No punitive streaks, no loss
 * notifications. Leaderboards are off by default and never include learners under 18.
 */
final class Gamification {
	public const XP_LESSON = 10;
	public const XP_COURSE = 100;

	public static function enabled(): bool {
		return 'off' !== get_option( 'educore_gamification', 'on' );
	}

	public static function xp( int $user_id ): int {
		global $wpdb;
		if ( ! self::enabled() ) {
			return 0;
		}
		$lessons = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Schema::table( 'lesson_progress' ) . " WHERE user_id=%d AND state='completed'", $user_id ) );
		$courses = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Schema::table( 'enrollments' ) . " WHERE user_id=%d AND status='completed'", $user_id ) );
		return (int) apply_filters( 'educore/gamification/xp', $lessons * self::XP_LESSON + $courses * self::XP_COURSE, $user_id );
	}

	/** @return array{target:int,done:int,met:bool} lessons completed this ISO week vs target */
	public static function weekly_goal( int $user_id ): array {
		global $wpdb;
		$target = max( 1, (int) ( get_user_meta( $user_id, 'educore_weekly_goal', true ) ?: 3 ) );
		$monday = gmdate( 'Y-m-d 00:00:00', strtotime( 'monday this week' ) );
		$done   = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Schema::table( 'lesson_progress' ) . " WHERE user_id=%d AND state='completed' AND completed_at >= %s", $user_id, $monday ) );
		return array( 'target' => $target, 'done' => $done, 'met' => $done >= $target );
	}

	/** @return array<int,array{key:string,label:string,earned:bool}> */
	public static function achievements( int $user_id ): array {
		global $wpdb;
		if ( ! self::enabled() ) {
			return array();
		}
		$lessons = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Schema::table( 'lesson_progress' ) . " WHERE user_id=%d AND state='completed'", $user_id ) );
		$courses = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Schema::table( 'enrollments' ) . " WHERE user_id=%d AND status='completed'", $user_id ) );
		$list    = array(
			array( 'key' => 'first_lesson', 'label' => __( 'First lesson completed', 'educore-core' ), 'earned' => $lessons >= 1 ),
			array( 'key' => 'ten_lessons', 'label' => __( '10 lessons completed', 'educore-core' ), 'earned' => $lessons >= 10 ),
			array( 'key' => 'first_course', 'label' => __( 'First course completed', 'educore-core' ), 'earned' => $courses >= 1 ),
			array( 'key' => 'weekly_goal', 'label' => __( 'Weekly goal reached', 'educore-core' ), 'earned' => self::weekly_goal( $user_id )['met'] ),
		);
		return apply_filters( 'educore/gamification/achievements', $list, $user_id );
	}

	public static function leaderboards_on(): bool {
		return 'on' === get_option( 'educore_leaderboards', 'off' ) && self::enabled();
	}

	/**
	 * Leaderboard eligibility: global switch on, learner opted in, AND an explicitly declared
	 * 18+ age band (accounts with no age recorded — e.g. created by a school — are never listed).
	 */
	public static function leaderboard_eligible( int $user_id ): bool {
		return self::leaderboards_on()
			&& 'yes' === get_user_meta( $user_id, 'educore_leaderboard_optin', true )
			&& '18plus' === get_user_meta( $user_id, 'educore_age_band', true );
	}

	/**
	 * Top learners by XP among eligible users, optionally within one course.
	 *
	 * @return array<int,array{user_id:int,name:string,xp:int}>
	 */
	public static function leaderboard( int $course_id = 0, int $limit = 10 ): array {
		global $wpdb;
		if ( ! self::leaderboards_on() ) {
			return array();
		}
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT a.user_id FROM {$wpdb->usermeta} a JOIN {$wpdb->usermeta} b ON b.user_id=a.user_id AND b.meta_key='educore_age_band' AND b.meta_value='18plus' WHERE a.meta_key=%s AND a.meta_value='yes'", 'educore_leaderboard_optin' ) );
		if ( $course_id ) {
			$ids = array_values( array_filter( $ids, static fn( $u ) => Enrollment::is_enrolled( (int) $u, $course_id, false ) ) );
		}
		if ( ! $ids ) {
			return array();
		}
		$in   = implode( ',', array_map( 'intval', $ids ) );
		$lp   = Schema::table( 'lesson_progress' );
		$en   = Schema::table( 'enrollments' );
		$cw   = $course_id ? $wpdb->prepare( ' AND course_id=%d', $course_id ) : '';
		$less = $wpdb->get_results( "SELECT user_id, COUNT(*) n FROM {$lp} WHERE state='completed' AND user_id IN ({$in}){$cw} GROUP BY user_id", OBJECT_K ); // phpcs:ignore WordPress.DB.PreparedSQL -- integer list + prepared fragment.
		$crs  = $wpdb->get_results( "SELECT user_id, COUNT(*) n FROM {$en} WHERE status='completed' AND user_id IN ({$in}){$cw} GROUP BY user_id", OBJECT_K ); // phpcs:ignore WordPress.DB.PreparedSQL
		$rows = array();
		foreach ( $ids as $u ) {
			$xp = (int) ( $less[ $u ]->n ?? 0 ) * self::XP_LESSON + (int) ( $crs[ $u ]->n ?? 0 ) * self::XP_COURSE;
			if ( $xp > 0 ) {
				$user   = get_userdata( (int) $u );
				$parts  = explode( ' ', trim( (string) ( $user ? $user->display_name : '' ) ) );
				$rows[] = array( 'user_id' => (int) $u, 'name' => $parts[0] . ( isset( $parts[1] ) ? ' ' . mb_substr( $parts[1], 0, 1 ) . '.' : '' ), 'xp' => $xp );
			}
		}
		usort( $rows, static fn( $a, $b ) => $b['xp'] <=> $a['xp'] ?: $a['user_id'] <=> $b['user_id'] );
		return array_slice( $rows, 0, $limit );
	}
}
