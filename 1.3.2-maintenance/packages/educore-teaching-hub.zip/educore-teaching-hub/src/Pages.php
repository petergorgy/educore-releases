<?php
namespace EduCore\TeachingHub;

defined( 'ABSPATH' ) || exit;

/** Pages owned by the Teaching Hub (idempotent creation; never overwritten). */
final class Pages {
	public const OPTION = 'educore_th_pages';

	public static function definitions(): array {
		return array(
			'teaching-hub' => array( 'title' => 'Teaching Hub', 'content' => '<!-- wp:educore/teaching-hub /-->', 'status' => 'publish' ),
			'tutors'       => array( 'title' => 'Tutors', 'content' => '<!-- wp:educore/tutors /-->', 'status' => 'publish' ),
		);
	}

	public static function create_missing(): array {
		$pages = (array) get_option( self::OPTION, array() );
		foreach ( self::definitions() as $key => $def ) {
			if ( ! empty( $pages[ $key ] ) && get_post( (int) $pages[ $key ] ) ) {
				continue;
			}
			$existing = get_page_by_path( $key );
			if ( $existing && false !== strpos( (string) $existing->post_content, 'wp:educore/' ) ) {
				$pages[ $key ] = (int) $existing->ID;
				continue;
			}
			$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => $def['status'], 'post_title' => $def['title'], 'post_name' => $key, 'post_content' => $def['content'], 'comment_status' => 'closed' ), true );
			if ( ! is_wp_error( $id ) ) {
				$pages[ $key ] = (int) $id;
			}
		}
		update_option( self::OPTION, $pages, false );
		self::flush();
		return $pages;
	}

	public static function id( string $key ): int {
		$pages = (array) get_option( self::OPTION, array() );
		return (int) ( $pages[ $key ] ?? 0 );
	}

	/** @var array<string,string> per-request URL memo (links are built many times per screen). */
	private static array $urls = array();

	public static function url( string $key ): string {
		if ( ! isset( self::$urls[ $key ] ) ) {
			$id                 = self::id( $key );
			self::$urls[ $key ] = $id && 'publish' === get_post_status( $id ) ? (string) get_permalink( $id ) : home_url( '/' . $key . '/' );
		}
		return self::$urls[ $key ];
	}

	public static function flush(): void {
		self::$urls = array();
	}
}
